# Scott D-Completable Spaces: Cartesian Closedness and Maximality — Lean 4

This is the Lean project for the earlier version of the paper. It includes Cartesian closedness, finite limits, strict enlargement of the category of monotone determined spaces, and largestness under canonical dcpo exponentials. The finite-source argument here uses a six-element poset. The revised manuscript's stronger two-element test is not formalized in this archive.

Extract the ZIP and open [index.html](index.html) to read the proof files
offline, or use an editor in the `lean/` folder. The reader never runs Lean.

With Elan and Git installed, compile the project from the extracted folder:

    cd lean
    lake build

Alternatively run `sh Check.command` on macOS/Linux or `Check.cmd` on Windows.
The first build needs network access if the pinned Lean toolchain or
dependencies are not already available. To use Mathlib's precompiled cache,
run `lake exe cache get` from `lean/` before `lake build`.

- Lean: `leanprover/lean4:v4.30.0-rc2`
- Mathlib: `5450b53e5ddc75d46418fabb605edbf36bd0beb6` (the other dependency commits are in the lockfile).
- 31 project and supporting Lean modules. No Mathlib copy, compiled
  files, or manuscript sources are included.
- `SHA256SUMS` covers every other file in the archive.
- Verification of the encoded proofs is separate from verification of the
  written manuscript. Independent human review is pending.
