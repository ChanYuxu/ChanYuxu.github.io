import ScottDCompletable.Order
import PMRVerifier

/-!
The standard completion is the directed-supremum closure of the points in the
sobrification, equipped with its lower Vietoris subspace topology. The
construction and universal property proved in the earlier manuscript run are
re-exposed through the named interfaces of the current manuscript.
-/

noncomputable section
open scoped Topology

universe u v w
namespace ScottDCompletable

open Set Topology

section LegacyBridge

theorem legacy_dClosed_iff {P : Type u} [PartialOrder P] (A : Set P) :
    (PMRVerifier.node_N002 P inferInstance).1 A ↔ DirSupClosed A := by
  constructor
  · intro h D hDA hne hdir a ha
    exact h D hDA ⟨hne, hdir⟩ a ha
  · intro h D hDA hdir a ha
    exact h hDA hdir.1 hdir.2 ha

theorem legacy_dClosure_eq_generated {P : Type u} [PartialOrder P] (A : Set P) :
    (PMRVerifier.node_N002 P inferInstance).2.2.1 A = generated A := by
  let t := (PMRVerifier.node_N002 P inferInstance).2.1
  have hclosed (K : Set P) :
      @IsClosed P t K ↔ (PMRVerifier.node_N002 P inferInstance).1 K := by
    letI : TopologicalSpace P := t
    rw [← isOpen_compl_iff]
    change (PMRVerifier.node_N002 P inferInstance).1 (Kᶜ)ᶜ ↔
      (PMRVerifier.node_N002 P inferInstance).1 K
    rw [compl_compl]
  change ⋂₀ {K : Set P | @IsClosed P t K ∧ A ⊆ K} = _
  unfold generated
  apply congrArg Set.sInter
  apply Set.ext
  intro K
  change (@IsClosed P t K ∧ A ⊆ K) ↔ (A ⊆ K ∧ DirSupClosed K)
  rw [hclosed, legacy_dClosed_iff, and_comm]

/-- The topology whose closed sets contain all their existing directed suprema. -/
@[implicit_reducible] def dTopology (P : Type u) [PartialOrder P] : TopologicalSpace P :=
  (PMRVerifier.node_N002 P inferInstance).2.1

def dClosure {P : Type u} [PartialOrder P] (A : Set P) : Set P :=
  @closure P (dTopology P) A

theorem isClosed_dTopology_iff {P : Type u} [PartialOrder P] (A : Set P) :
    IsClosed[dTopology P] A ↔ SubDcpo A := by
  letI : TopologicalSpace P := dTopology P
  rw [← isOpen_compl_iff]
  change (PMRVerifier.node_N002 P inferInstance).1 (Aᶜ)ᶜ ↔ SubDcpo A
  rw [compl_compl, legacy_dClosed_iff]

theorem dClosure_eq_generated {P : Type u} [PartialOrder P] (A : Set P) :
    dClosure A = generated A :=
  legacy_dClosure_eq_generated A

theorem dClosure_prod {P : Type u} {Q : Type v} [PartialOrder P] [PartialOrder Q]
    (A : Set P) (B : Set Q) :
    dClosure (A ×ˢ B) = dClosure A ×ˢ dClosure B := by
  simp only [dClosure_eq_generated]
  exact generated_prod A B

/-- The specialization dcpo exists and each original open set is Scott open. -/
def IsMonotoneConvergence (M : Type v) [t : TopologicalSpace M] [T0Space M] : Prop :=
  @IsDCPO M (specializationOrder M) ∧
    @scott M (specializationOrder M).toPreorder ≤ t

/-- The same condition expressed by convergence of each directed net to its supremum. -/
theorem isMonotoneConvergence_iff_directedSupConverges (M : Type v)
    [TopologicalSpace M] [T0Space M] :
    letI : PartialOrder M := specializationOrder M
    IsMonotoneConvergence M ↔ IsDCPO M ∧
      ∀ (A : Set M), A.Nonempty → DirectedOn (· ≤ ·) A → ∀ a, IsLUB A a →
      ∀ U : Set M, IsOpen U → a ∈ U →
        ∃ x ∈ A, ∀ y ∈ A, x ≤ y → y ∈ U := by
  letI : PartialOrder M := specializationOrder M
  constructor
  · rintro ⟨hD, hScott⟩
    refine ⟨hD, fun A hne hdir a ha U hU haU => ?_⟩
    have hOpen := (scott_isOpen_iff U).mp (hScott U hU)
    obtain ⟨x, hx, hxU⟩ := hOpen.2 hne hdir ha haU
    exact ⟨x, hx, fun _ _ hxy => hOpen.1 hxy hxU⟩
  · rintro ⟨hD, hConverges⟩
    refine ⟨hD, fun U hU => (scott_isOpen_iff U).mpr ⟨?_, ?_⟩⟩
    · intro x y hxy hx
      exact (show Specializes y x from hxy).mem_open hU hx
    · intro A hne hdir a ha haU
      obtain ⟨x, hx, htail⟩ := hConverges A hne hdir a ha U hU haU
      exact ⟨x, hx, htail x hx le_rfl⟩

theorem legacy_monotoneConvergence_iff (M : Type v)
    [t : TopologicalSpace M] [hM : T0Space M] :
    (PMRVerifier.node_N003.{v,v}).1 M t hM ↔ IsMonotoneConvergence M := by
  letI : PartialOrder M := specializationOrder M
  constructor
  · rintro ⟨h, hopen⟩
    exact ⟨⟨fun D hne hdir => h D ⟨hne, hdir⟩⟩, hopen⟩
  · rintro ⟨h, hopen⟩
    exact ⟨fun D hdir => h.lub D hdir.1 hdir.2, hopen⟩

/-- An embedding into a monotone convergence space with directed-supremum dense image. -/
def IsDCompletion {X : Type u} [TopologicalSpace X]
    {M : Type v} [TopologicalSpace M] [T0Space M] (η : X → M) : Prop :=
  IsEmbedding η ∧ IsMonotoneConvergence M ∧
    @generated M (specializationOrder M).toPreorder (range η) = univ

theorem legacy_isDCompletion_iff {X : Type u} [tX : TopologicalSpace X] [hX : T0Space X]
    {M : Type v} [tM : TopologicalSpace M] [hM : T0Space M] (η : X → M) :
    (PMRVerifier.node_N003.{u,v}).2 X tX hX M tM hM η ↔ IsDCompletion η := by
  constructor
  · rintro ⟨hinj, hind, hMC, hd⟩
    refine ⟨⟨⟨hind⟩, hinj⟩, (legacy_monotoneConvergence_iff M).mp hMC, ?_⟩
    letI : PartialOrder M := specializationOrder M
    exact (legacy_dClosure_eq_generated (range η)) ▸ hd
  · rintro ⟨hemb, hMC, hd⟩
    refine ⟨hemb.injective, hemb.isInducing.eq_induced,
      (legacy_monotoneConvergence_iff M).mpr hMC, ?_⟩
    letI : PartialOrder M := specializationOrder M
    exact (legacy_dClosure_eq_generated (range η)).symm ▸ hd

end LegacyBridge

/-- The same D-completion condition with d-density written using topological closure. -/
theorem isDCompletion_iff_dDense {X : Type u} [TopologicalSpace X]
    {M : Type v} [TopologicalSpace M] [T0Space M] (η : X → M) :
    letI : PartialOrder M := specializationOrder M
    IsDCompletion η ↔ IsEmbedding η ∧ IsMonotoneConvergence M ∧ dClosure (range η) = univ := by
  letI : PartialOrder M := specializationOrder M
  rw [dClosure_eq_generated]
  rfl

/-- Continuity between monotone convergence spaces preserves directed suprema. -/
theorem monotoneConvergence_continuous_scott {M : Type u} {N : Type v}
    [tM : TopologicalSpace M] [tN : TopologicalSpace N] [hM : T0Space M] [hN : T0Space N]
    (hMC : IsMonotoneConvergence M) (hNC : IsMonotoneConvergence N)
    {f : M → N} (hf : Continuous f) :
    @ScottContinuous M N (specializationOrder M).toPreorder (specializationOrder N).toPreorder f := by
  intro E hne hdir a ha
  exact ((PMRVerifier.node_N004.{u,u,v} M tM hM).2.2.1 M tM hM N tN hN
    ((legacy_monotoneConvergence_iff M).mpr hMC)
    ((legacy_monotoneConvergence_iff N).mpr hNC) f hf).2 E ⟨hne, hdir⟩ a ha

/-- The extension property for a genuine D-completion, in arbitrary universes. -/
theorem isDCompletion_existsUnique_extension {X : Type u}
    [tX : TopologicalSpace X] [hX : T0Space X]
    {M : Type v} [tM : TopologicalSpace M] [hM : T0Space M]
    {N : Type w} [tN : TopologicalSpace N] [hN : T0Space N]
    (η : X → M) (hη : IsDCompletion η) (hMC : IsMonotoneConvergence N)
    (f : X → N) (hf : Continuous f) :
    ∃! g : M → N, Continuous g ∧ ∀ x, g (η x) = f x :=
  (PMRVerifier.node_N004.{u,v,w} X tX hX).2.1 M tM hM η
    ((legacy_isDCompletion_iff η).mpr hη)
    N tN hN ((legacy_monotoneConvergence_iff N).mpr hMC) f hf

/-- The homeomorphism commutes with the actual completion units. -/
theorem isDCompletion_existsUnique_homeomorph {X : Type u}
    [tX : TopologicalSpace X] [hX : T0Space X]
    {M : Type v} [tM : TopologicalSpace M] [hM : T0Space M]
    {N : Type w} [tN : TopologicalSpace N] [hN : T0Space N]
    (η : X → M) (ι : X → N) (hη : IsDCompletion η) (hι : IsDCompletion ι) :
    ∃! e : M ≃ₜ N, ∀ x, e (η x) = ι x :=
  (PMRVerifier.node_N004.{u,v,w} X tX hX).1.2 M tM hM N tN hN η ι
    ((legacy_isDCompletion_iff η).mpr hη) ((legacy_isDCompletion_iff ι).mpr hι)

/-- A chosen genuine D-completion. Its topology need not be Scott. -/
structure DCompletion (X : Type u) [TopologicalSpace X] where
  Carrier : Type u
  topology : TopologicalSpace Carrier
  t0 : @T0Space Carrier topology
  unit : X → Carrier
  isCompletion : @IsDCompletion X _ Carrier topology t0 unit

namespace DCompletion

variable {X : Type u} [TopologicalSpace X] (C : DCompletion X)

abbrev order : PartialOrder C.Carrier := @specializationOrder C.Carrier C.topology C.t0

theorem dcpo : @IsDCPO C.Carrier C.order := C.isCompletion.2.1.1

theorem embedding : @IsEmbedding X C.Carrier _ C.topology C.unit := C.isCompletion.1

theorem dense : @generated C.Carrier C.order.toPreorder (range C.unit) = univ :=
  C.isCompletion.2.2

theorem topology_le_scott : @scott C.Carrier C.order.toPreorder ≤ C.topology :=
  C.isCompletion.2.1.2

variable [hX : T0Space X]

theorem existsUnique_extension {N : Type v} [tN : TopologicalSpace N] [hN : T0Space N]
    (hMC : IsMonotoneConvergence N) (f : X → N) (hf : Continuous f) :
    ∃! g : C.Carrier → N, @Continuous C.Carrier N C.topology tN g ∧
      ∀ x, g (C.unit x) = f x := by
  letI : TopologicalSpace C.Carrier := C.topology
  letI : T0Space C.Carrier := C.t0
  exact (PMRVerifier.node_N004.{u,u,v} X inferInstance hX).2.1
    C.Carrier C.topology C.t0 C.unit ((legacy_isDCompletion_iff C.unit).mpr C.isCompletion)
    N tN hN ((legacy_monotoneConvergence_iff N).mpr hMC) f hf

theorem existsUnique_homeomorph (D : DCompletion X) :
    ∃! e : @Homeomorph C.Carrier D.Carrier C.topology D.topology,
      ∀ x, e (C.unit x) = D.unit x := by
  letI : TopologicalSpace C.Carrier := C.topology
  letI : T0Space C.Carrier := C.t0
  letI : TopologicalSpace D.Carrier := D.topology
  letI : T0Space D.Carrier := D.t0
  exact (PMRVerifier.node_N004.{u,u,u} X inferInstance hX).1.2
    C.Carrier C.topology C.t0 D.Carrier D.topology D.t0 C.unit D.unit
    ((legacy_isDCompletion_iff C.unit).mpr C.isCompletion)
    ((legacy_isDCompletion_iff D.unit).mpr D.isCompletion)

theorem topology_eq_scott_of_continuous_unit
    (h : @Continuous X C.Carrier _ (@scott C.Carrier C.order.toPreorder) C.unit) :
    C.topology = @scott C.Carrier C.order.toPreorder := by
  letI : TopologicalSpace C.Carrier := C.topology
  letI : T0Space C.Carrier := C.t0
  exact (PMRVerifier.node_N004.{u,u,u} X inferInstance hX).2.2.2.2.2
    C.Carrier C.topology C.t0 C.unit ((legacy_isDCompletion_iff C.unit).mpr C.isCompletion) h

end DCompletion

/-- Lower Vietoris topology on the irreducible closed sets of X. -/
@[implicit_reducible] noncomputable def sobrificationTopology (X : Type u) [TopologicalSpace X] :
    TopologicalSpace (TopologicalSpace.IrreducibleCloseds X) :=
  TopologicalSpace.generateFrom
    {V : Set (TopologicalSpace.IrreducibleCloseds X) | ∃ U : Set X, IsOpen U ∧
      V = {F : TopologicalSpace.IrreducibleCloseds X | ((F : Set X) ∩ U).Nonempty}}

noncomputable def sobrificationPoint (X : Type u) [TopologicalSpace X]
    (x : X) : TopologicalSpace.IrreducibleCloseds X :=
  ⟨closure ({x} : Set X), (isIrreducible_singleton (x := x)).closure, isClosed_closure⟩

/-- The d-closure of the embedded points in the sobrification. -/
noncomputable def standardCompletionSet (X : Type u) [TopologicalSpace X] :
    Set (TopologicalSpace.IrreducibleCloseds X) :=
  ⋂₀ {K | range (sobrificationPoint X) ⊆ K ∧
    ∀ E, E ⊆ K → (PMRVerifier.node_N043).2 _ inferInstance E →
      ∀ s, IsLUB E s → s ∈ K}

abbrev StandardCarrier (X : Type u) [TopologicalSpace X] :=
  {F // F ∈ standardCompletionSet X}

@[implicit_reducible] noncomputable def standardCompletionTopology (X : Type u) [TopologicalSpace X] :
    TopologicalSpace (StandardCarrier X) :=
  TopologicalSpace.induced Subtype.val (sobrificationTopology X)

noncomputable def standardCompletionUnit (X : Type u) [TopologicalSpace X] (x : X) :
    StandardCarrier X :=
  ⟨sobrificationPoint X x, mem_sInter.mpr (fun _K hK => hK.1 ⟨x, rfl⟩)⟩

private theorem standardCompletion_exists (X : Type u) [tX : TopologicalSpace X] [hX : T0Space X] :
    ∃ hT0 : @T0Space (StandardCarrier X) (standardCompletionTopology X),
      @IsDCompletion X tX (StandardCarrier X) (standardCompletionTopology X) hT0
        (standardCompletionUnit X) := by
  letI : TopologicalSpace (StandardCarrier X) := standardCompletionTopology X
  obtain ⟨hD, hcomp, _⟩ := PMRVerifier.node_N040 X tX hX
  letI : T0Space (StandardCarrier X) := hD
  exact ⟨hD, (legacy_isDCompletion_iff (standardCompletionUnit X)).mp hcomp⟩

/-- Keimel–Lawson standard D-completion on the specified carrier, topology and unit. -/
noncomputable def standardCompletion (X : Type u) [TopologicalSpace X] [T0Space X] :
    DCompletion X where
  Carrier := StandardCarrier X
  topology := standardCompletionTopology X
  t0 := Classical.choose (standardCompletion_exists X)
  unit := standardCompletionUnit X
  isCompletion := Classical.choose_spec (standardCompletion_exists X)

theorem standardCompletionSet_eq_generated (X : Type u) [TopologicalSpace X] :
    standardCompletionSet X = generated (range (sobrificationPoint X)) := by
  unfold standardCompletionSet generated
  apply congrArg Set.sInter
  apply Set.ext
  intro K
  constructor
  · rintro ⟨hK, hclosed⟩
    exact ⟨hK, (legacy_dClosed_iff K).mp hclosed⟩
  · rintro ⟨hK, hclosed⟩
    exact ⟨hK, (legacy_dClosed_iff K).mpr hclosed⟩

/-- The completion topology already is the Scott topology of the stored order. -/
structure ScottCompletion (X : Type u) [TopologicalSpace X] where
  Carrier : Type u
  order : PartialOrder Carrier
  dcpo : @IsDCPO Carrier order
  unit : X → Carrier
  embedding : @IsEmbedding X Carrier _ (@scott Carrier order.toPreorder) unit
  dense : @generated Carrier order.toPreorder (range unit) = univ

def IsSDC (X : Type u) [TopologicalSpace X] : Prop := Nonempty (ScottCompletion X)

theorem specializationOrder_scott (P : Type u) [o : PartialOrder P] :
    @specializationOrder P (scott P) (scott_t0 P) = o := by
  letI : TopologicalSpace P := scott P
  letI : Topology.IsScott P (Set.univ : Set (Set P)) := ⟨rfl⟩
  letI : T0Space P := scott_t0 P
  apply PartialOrder.ext
  intro x y
  change y ⤳ x ↔ x ≤ y
  rw [specializes_iff_mem_closure, Topology.IsScott.closure_singleton]
  rfl

theorem scott_isMonotoneConvergence (P : Type u) [PartialOrder P] [IsDCPO P] :
    @IsMonotoneConvergence P (scott P) (scott_t0 P) := by
  unfold IsMonotoneConvergence
  rw [specializationOrder_scott]
  exact ⟨inferInstance, le_rfl⟩

namespace ScottCompletion

variable {X : Type u} [TopologicalSpace X] (C : ScottCompletion X)

instance : PartialOrder C.Carrier := C.order
instance : IsDCPO C.Carrier := C.dcpo

noncomputable def toDCompletion : DCompletion X := by
  letI : PartialOrder C.Carrier := C.order
  letI : IsDCPO C.Carrier := C.dcpo
  refine ⟨C.Carrier, scott C.Carrier, scott_t0 C.Carrier, C.unit,
    C.embedding, scott_isMonotoneConvergence C.Carrier, ?_⟩
  rw [specializationOrder_scott]
  exact C.dense

variable {N : Type v} [PartialOrder N] [IsDCPO N]

theorem existsUnique_extension (f : X → N) (hf : @Continuous X N _ (scott N) f) :
    ∃! g : C.Carrier → N, @ScottContinuous C.Carrier N C.order.toPreorder _ g ∧
      ∀ x, g (C.unit x) = f x := by
  letI : PartialOrder C.Carrier := C.order
  letI : TopologicalSpace C.Carrier := scott C.Carrier
  letI : T0Space C.Carrier := scott_t0 C.Carrier
  letI : T0Space X := C.embedding.t0Space
  letI : TopologicalSpace N := scott N
  letI : T0Space N := scott_t0 N
  have h := C.toDCompletion.existsUnique_extension (scott_isMonotoneConvergence N) f hf
  change ∃! g : C.Carrier → N, @Continuous C.Carrier N (scott C.Carrier) (scott N) g ∧
    ∀ x, g (C.unit x) = f x at h
  obtain ⟨g, hg, hu⟩ := h
  refine ⟨g, ⟨scott_iff_continuous.mpr hg.1, hg.2⟩, ?_⟩
  intro k hk
  exact hu k ⟨scott_iff_continuous.mp hk.1, hk.2⟩

end ScottCompletion

namespace DCompletion

variable {X : Type u} [TopologicalSpace X] (C : DCompletion X)

noncomputable def toScottCompletion
    (h : C.topology = @scott C.Carrier C.order.toPreorder) : ScottCompletion X where
  Carrier := C.Carrier
  order := C.order
  dcpo := C.dcpo
  unit := C.unit
  embedding := h ▸ C.embedding
  dense := C.dense

end DCompletion

/-- Every D-completion of an SDC space has the Scott topology of its own order. -/
theorem DCompletion.topology_eq_scott_of_sdc {X : Type u} [TopologicalSpace X]
    (D : DCompletion X) (h : IsSDC X) :
    D.topology = @scott D.Carrier D.order.toPreorder := by
  letI : TopologicalSpace D.Carrier := D.topology
  letI : T0Space D.Carrier := D.t0
  letI : T0Space X := D.embedding.t0Space
  obtain ⟨C⟩ := h
  let J := C.toDCompletion
  obtain ⟨e, he, _⟩ := J.existsUnique_homeomorph D
  letI : PartialOrder D.Carrier := D.order
  letI : TopologicalSpace J.Carrier := J.topology
  have hMC_J := (@legacy_monotoneConvergence_iff.{u} J.Carrier J.topology J.t0).mpr
    J.isCompletion.2.1
  have hMC_D := (@legacy_monotoneConvergence_iff.{u} D.Carrier D.topology D.t0).mpr
    D.isCompletion.2.1
  let g : C.Carrier → D.Carrier := e.toFun
  have hSC : @ScottContinuous J.Carrier D.Carrier J.order.toPreorder
      D.order.toPreorder g := by
    intro E hne hdir a ha
    exact ((PMRVerifier.node_N004.{u,u,u} X inferInstance inferInstance).2.2.1
      J.Carrier J.topology J.t0 D.Carrier D.topology D.t0 hMC_J hMC_D
      (e : J.Carrier → D.Carrier) e.continuous).2 E ⟨hne, hdir⟩ a ha
  have hOrder : J.order = C.order := specializationOrder_scott C.Carrier
  rw [hOrder] at hSC
  have hg : @ScottContinuous C.Carrier D.Carrier C.order.toPreorder D.order.toPreorder g := hSC
  have hu : g ∘ C.unit = D.unit := funext he
  have hunit : @Continuous X D.Carrier _ (scott D.Carrier) D.unit := by
    letI : TopologicalSpace C.Carrier := scott C.Carrier
    letI : TopologicalSpace D.Carrier := scott D.Carrier
    have hc : Continuous (g ∘ C.unit) := (scott_iff_continuous.mp hg).comp C.embedding.continuous
    simpa only [hu] using hc
  exact D.topology_eq_scott_of_continuous_unit hunit

/-- The identity of a monotone convergence space is its own D-completion. -/
def identityDCompletion (X : Type u) [TopologicalSpace X] [T0Space X]
    (h : IsMonotoneConvergence X) : DCompletion X where
  Carrier := X
  topology := inferInstance
  t0 := inferInstance
  unit := id
  isCompletion := by
    refine ⟨⟨⟨(induced_id (α := X)).symm⟩, Function.injective_id⟩, h, ?_⟩
    letI : PartialOrder X := specializationOrder X
    apply Set.eq_univ_of_forall
    intro x
    exact subset_generated _ ⟨x, rfl⟩

/-- The definition in the manuscript, using the specified standard completion. -/
def IsScottStandardCompletion (X : Type u) [TopologicalSpace X] [T0Space X] : Prop :=
  (standardCompletion X).topology =
    @scott (standardCompletion X).Carrier (standardCompletion X).order.toPreorder

theorem isSDC_iff_standard (X : Type u) [TopologicalSpace X] [T0Space X] :
    IsSDC X ↔ IsScottStandardCompletion X :=
  ⟨(standardCompletion X).topology_eq_scott_of_sdc,
    fun h => ⟨(standardCompletion X).toScottCompletion h⟩⟩

/-- Transport the same completion along a homeomorphism of input spaces. -/
def ScottCompletion.transport {X Y : Type u} [TopologicalSpace X] [TopologicalSpace Y]
    (C : ScottCompletion X) (e : X ≃ₜ Y) : ScottCompletion Y where
  Carrier := C.Carrier
  order := C.order
  dcpo := C.dcpo
  unit := C.unit ∘ e.symm
  embedding := by
    letI : TopologicalSpace C.Carrier := scott C.Carrier
    exact C.embedding.comp e.symm.isEmbedding
  dense := by
    have h : Set.range (C.unit ∘ e.symm) = Set.range C.unit := by
      ext d
      constructor
      · rintro ⟨y, rfl⟩
        exact ⟨e.symm y, rfl⟩
      · rintro ⟨x, rfl⟩
        exact ⟨e x, by simp⟩
    rw [h]
    exact C.dense

theorem isSDC_homeomorph {X Y : Type u} [TopologicalSpace X] [TopologicalSpace Y]
    (e : X ≃ₜ Y) : IsSDC X ↔ IsSDC Y :=
  ⟨fun ⟨C⟩ => ⟨C.transport e⟩, fun ⟨C⟩ => ⟨C.transport e.symm⟩⟩

end ScottDCompletable
