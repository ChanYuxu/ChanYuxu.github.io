import ScottDCompletable.CategoryPresentation
import ScottDCompletable.Limits

noncomputable section
open Set Topology
open scoped Topology
universe u
namespace ScottDCompletable

abbrev completionOf {X : Space.{u}} (hX : SDCSpace X) :
    @ScottCompletion X.Carrier X.topology := Classical.choice hX

def Cont.toContinuousMap {X Y : Space.{u}} (f : Cont X Y) :
    @ContinuousMap X.Carrier Y.Carrier X.topology Y.topology := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  exact ⟨f.val,by exact f.property⟩

def sdcProducts : ProductChoices (SDCSpace : SpaceClass.{u}) := by
  intro X Y hX hY
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  let CX := completionOf hX
  let CY := completionOf hY
  refine ⟨productTopology CX CY, ⟨productCompletion CX CY⟩,
    product_fst CX CY, product_snd CX CY, ?_⟩
  intro Z hZ f g
  letI : TopologicalSpace Z.Carrier := Z.topology
  exact product_pair (completionOf hZ) CX CY f.toContinuousMap g.toContinuousMap

@[implicit_reducible] def sdcExponentialTopology {X Y : Space.{u}}
    (hX : SDCSpace X) (hY : SDCSpace Y) : TopologicalSpace (Cont X Y) :=
  TopologicalSpace.induced Cont.toContinuousMap
    (@exponentialTopology X.Carrier Y.Carrier X.topology Y.topology (completionOf hX) (completionOf hY))

def sdcExponentialCompletion {X Y : Space.{u}} (hX : SDCSpace X) (hY : SDCSpace Y) :
    @ScottCompletion (Cont X Y) (sdcExponentialTopology hX hY) := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  let CX := completionOf hX
  let CY := completionOf hY
  letI : TopologicalSpace C(X.Carrier,Y.Carrier) := exponentialTopology CX CY
  letI : TopologicalSpace (Cont X Y) := sdcExponentialTopology hX hY
  let E := exponentialCompletion CX CY
  have he : IsEmbedding (Cont.toContinuousMap (X:=X) (Y:=Y)) := by
    refine ⟨⟨rfl⟩, ?_⟩
    intro f g h
    apply Subtype.ext
    exact congrArg ContinuousMap.toFun h
  refine ⟨E.Carrier,E.order,E.dcpo,E.unit ∘ Cont.toContinuousMap,E.embedding.comp he,?_⟩
  have hr : Set.range (E.unit ∘ Cont.toContinuousMap (X:=X) (Y:=Y)) = Set.range E.unit := by
    ext z
    constructor
    · rintro ⟨f,rfl⟩; exact ⟨f.toContinuousMap,rfl⟩
    · rintro ⟨f,rfl⟩; exact ⟨⟨f.toFun,f.continuous⟩,rfl⟩
  rw [hr]
  exact E.dense

private theorem sdcExpoEval {X Y : Space.{u}} (hX : SDCSpace X) (hY : SDCSpace Y) :
    let hE : SDCSpace ⟨Cont X Y,sdcExponentialTopology hX hY⟩ := ⟨sdcExponentialCompletion hX hY⟩
    @Continuous (Cont X Y × X.Carrier) Y.Carrier (sdcProducts hE hX).spaceTopology
      Y.topology (fun p => p.1.val p.2) := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  letI : TopologicalSpace (Cont X Y) := sdcExponentialTopology hX hY
  let CX := completionOf hX
  let CY := completionOf hY
  letI : TopologicalSpace C(X.Carrier,Y.Carrier) := exponentialTopology CX CY
  let E := exponentialCompletion CX CY
  let hE : SDCSpace ⟨Cont X Y,sdcExponentialTopology hX hY⟩ := ⟨sdcExponentialCompletion hX hY⟩
  let P := sdcProducts hE hX
  letI : TopologicalSpace (Cont X Y × X.Carrier) := P.spaceTopology
  letI : TopologicalSpace (C(X.Carrier,Y.Carrier) × X.Carrier) := evaluationTopology CX CY
  let Cdom := completionOf P.belongs
  have hF : Continuous (Cont.toContinuousMap (X:=X) (Y:=Y)) := continuous_induced_dom
  have hpair := product_pair Cdom E CX
    ⟨Cont.toContinuousMap ∘ Prod.fst, hF.comp P.fst_continuous⟩ ⟨Prod.snd,P.snd_continuous⟩
  change @Continuous _ _ P.spaceTopology Y.topology (fun p : Cont X Y × X.Carrier => p.1.val p.2)
  exact (exponential_evaluation CX CY).comp hpair

def sdcExponents {X Y : Space.{u}} (hX : SDCSpace X) (hY : SDCSpace Y) :
    ExponentialPresentation SDCSpace sdcProducts hX hY where
  spaceTopology := sdcExponentialTopology hX hY
  belongs := ⟨sdcExponentialCompletion hX hY⟩
  evaluation_continuous := sdcExpoEval hX hY
  transpose_continuous := by
    intro Z hZ f
    letI : TopologicalSpace X.Carrier := X.topology
    letI : TopologicalSpace Y.Carrier := Y.topology
    letI : TopologicalSpace Z.Carrier := Z.topology
    let CX := completionOf hX
    let CY := completionOf hY
    let CZ := completionOf hZ
    letI : TopologicalSpace (Z.Carrier × X.Carrier) := productTopology CZ CX
    letI : TopologicalSpace C(X.Carrier,Y.Carrier) := exponentialTopology CX CY
    letI : TopologicalSpace (Cont X Y) := sdcExponentialTopology hX hY
    apply continuous_induced_rng.mpr
    exact (exponentialCurry CZ CX CY (Cont.toContinuousMap f)).continuous

def sdcClosedPresentation : ClosedPresentation (SDCSpace : SpaceClass.{u}) where
  t0 := by
    intro X hX
    letI : TopologicalSpace X.Carrier := X.topology
    let C := completionOf hX
    letI : TopologicalSpace C.Carrier := scott C.Carrier
    letI : T0Space C.Carrier := scott_t0 C.Carrier
    exact C.embedding.t0Space
  products := sdcProducts
  exponents := sdcExponents

theorem sdcContainsScott : ContainsScott (SDCSpace : SpaceClass.{u}) :=
  fun P _ _ => ⟨scottCompletion P⟩

end ScottDCompletable
