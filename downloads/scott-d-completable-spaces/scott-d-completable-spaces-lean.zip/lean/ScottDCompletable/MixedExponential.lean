import ScottDCompletable.CategoryPresentation
import ScottDCompletable.FiniteSource
import Mathlib.Order.Bounds.OrderIso
import Mathlib.Topology.Sets.Opens

/-! The mixed exponential of the supplied manuscript, equation
`eq:mixed-exponential` and proof lines 580–618. The proof computes the
topology on the actual hom-set of X and the Scott dcpo, then uses the
extension order isomorphism to exhibit the required homeomorphism. -/

noncomputable section
open Set Topology
open scoped Topology
universe u

namespace ScottDCompletable

/-- The two-element Scott dcpo in the universe of the ambient category. -/
abbrev Sierpinski := ULift.{u} Bool

abbrev sierZero : Sierpinski.{u} := ⟨false⟩
abbrev sierOne : Sierpinski.{u} := ⟨true⟩

private def sierOneSet : Set Sierpinski.{u} := {s | s.down = true}

private theorem sierOneSet_open : IsOpen[scott Sierpinski.{u}] sierOneSet.{u} := by
  have h : sierOneSet.{u} = (Iic sierZero.{u})ᶜ := by
    ext ⟨s⟩
    change (s = true) ↔ ¬s ≤ false
    cases s <;> decide
  rw [h]
  have hclosed : IsClosed[scott Sierpinski.{u}] (Iic sierZero.{u}) :=
    (scott_isClosed_iff _).mpr ⟨isLowerSet_Iic _, dirSupClosed_Iic _⟩
  exact hclosed.isOpen_compl

/-- The Scott opens of the two-element chain, including the unique proper
nonempty open. -/
theorem sierpinski_isOpen_iff (U : Set Sierpinski.{u}) :
    IsOpen[scott Sierpinski.{u}] U ↔ U = ∅ ∨ U = {sierOne.{u}} ∨ U = univ := by
  constructor
  · intro hU
    have hUpper := ((scott_isOpen_iff U).mp hU).1
    by_cases hzero : sierZero.{u} ∈ U
    · right
      right
      apply Set.eq_univ_of_forall
      intro x
      exact hUpper (show sierZero ≤ x from bot_le) hzero
    · by_cases hone : sierOne.{u} ∈ U
      · right
        left
        ext ⟨x⟩
        cases x with
        | false => exact iff_of_false hzero (by decide)
        | true => exact iff_of_true hone rfl
      · left
        apply Set.eq_empty_iff_forall_notMem.mpr
        rintro ⟨x⟩
        cases x
        · exact hzero
        · exact hone
  · letI : TopologicalSpace Sierpinski.{u} := scott _
    rintro (rfl | rfl | rfl)
    · exact isOpen_empty
    · have h : ({sierOne.{u}} : Set Sierpinski.{u}) = sierOneSet.{u} := by
        ext ⟨x⟩
        exact ⟨congrArg ULift.down, congrArg ULift.up⟩
      rw [h]
      exact sierOneSet_open
    · exact isOpen_univ

/-- The characteristic map of an open set into the Sierpiński space. -/
def sierpinskiCharacteristic (X : Space.{u}) (U : @TopologicalSpace.Opens X.Carrier X.topology) :
    Cont X (scottSpace Sierpinski.{u}) := by
  classical
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Sierpinski.{u} := scott _
  refine ⟨fun x => if x ∈ U then sierOne else sierZero, continuous_def.mpr ?_⟩
  intro V hV
  rcases (sierpinski_isOpen_iff V).mp hV with rfl | rfl | rfl
  · rw [preimage_empty]
    exact isOpen_empty
  · have hpre : (fun x : X.Carrier => if x ∈ U then sierOne.{u} else sierZero.{u}) ⁻¹'
        ({sierOne.{u}} : Set Sierpinski.{u}) = U := by
      ext x
      by_cases hx : x ∈ U <;> simp [hx]
    rw [hpre]
    exact U.isOpen
  · rw [preimage_univ]
    exact isOpen_univ

/-- The characteristic-map identification in the source preliminaries. -/
def sierpinskiOpensEquiv (X : Space.{u}) :
    @TopologicalSpace.Opens X.Carrier X.topology ≃ Cont X (scottSpace Sierpinski.{u}) := by
  classical
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Sierpinski.{u} := scott _
  refine ⟨sierpinskiCharacteristic X,
    fun f => ⟨f.val ⁻¹' sierOneSet, sierOneSet_open.preimage f.property⟩, ?_, ?_⟩
  · intro U
    ext x
    change ((if x ∈ U then sierOne.{u} else sierZero.{u}) : Sierpinski.{u}).down = true ↔ x ∈ U
    by_cases hx : x ∈ U <;> simp [hx]
  · intro f
    apply Subtype.ext
    funext x
    change (if x ∈ f.val ⁻¹' sierOneSet then sierOne.{u} else sierZero.{u}) = f.val x
    rcases hf : f.val x with ⟨b⟩
    cases b <;> simp [sierOneSet, hf]

variable {X : Space.{u}} {Q : Type u} [PartialOrder Q]

/-- The case map used in the specialization-order calculation. -/
def sierpinskiCase (f g : Cont X (scottSpace Q)) : Sierpinski.{u} × X.Carrier → Q :=
  fun p => if p.1.down then g.val p.2 else f.val p.2

theorem sierpinskiCase_continuous (f g : Cont X (scottSpace Q)) (hfg : f ≤ g) :
    @Continuous _ _ (ordinaryProductSpace (scottSpace Sierpinski.{u}) X).topology
      (scott Q) (sierpinskiCase f g) := by
  letI : TopologicalSpace Sierpinski.{u} := scott _
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Q := scott Q
  apply continuous_def.mpr
  intro U hU
  have hup := ((scott_isOpen_iff U).mp hU).1
  have hpre : sierpinskiCase f g ⁻¹' U =
      (univ ×ˢ (f.val ⁻¹' U)) ∪ (sierOneSet ×ˢ (g.val ⁻¹' U)) := by
    ext p
    rcases p with ⟨⟨s⟩, x⟩
    have hImp : f.val x ∈ U → g.val x ∈ U := hup (hfg x)
    cases s with
    | false => simp [sierpinskiCase, sierOneSet]
    | true =>
        simpa [sierpinskiCase, sierOneSet] using
          (show g.val x ∈ U ↔ f.val x ∈ U ∨ g.val x ∈ U from
            ⟨Or.inr, fun h => h.elim hImp id⟩)
  rw [hpre]
  exact (isOpen_univ.prod (hU.preimage f.property)).union
    (sierOneSet_open.prod (hU.preimage g.property))

variable [IsDCPO Q]

local instance : TopologicalSpace X.Carrier := X.topology

def restrictScottHom (CX : @ScottCompletion X.Carrier X.topology)
    (u : ScottHom CX.Carrier Q) : Cont X (scottSpace Q) := by
  letI : TopologicalSpace Q := scott Q
  exact ⟨fun x => u.val (CX.unit x),
    (scott_iff_continuous.mp u.isScott).comp CX.embedding.continuous⟩

theorem extend_le_iff (CX : @ScottCompletion X.Carrier X.topology)
    (f g : Cont X (scottSpace Q)) :
    CX.extend f.val f.property ≤ CX.extend g.val g.property ↔ f ≤ g := by
  constructor
  · intro h x
    have hu := h (CX.unit x)
    change (CX.extend f.val f.property).val (CX.unit x) ≤
      (CX.extend g.val g.property).val (CX.unit x) at hu
    rwa [CX.extend_unit, CX.extend_unit] at hu
  · intro h
    let F := CX.extend f.val f.property
    let G := CX.extend g.val g.property
    let A : Set CX.Carrier := {x | F.val x ≤ G.val x}
    have hA : SubDcpo A := by
      intro S hS hne hdir s hs
      apply (F.isScott hne hdir hs).2
      rintro _ ⟨p, hp, rfl⟩
      exact (hS hp).trans (G.isScott.monotone (hs.1 hp))
    have hX : Set.range CX.unit ⊆ A := by
      rintro _ ⟨x, rfl⟩
      change F.val (CX.unit x) ≤ G.val (CX.unit x)
      rw [CX.extend_unit, CX.extend_unit]
      exact h x
    have hAll := generated_eq_of_superset CX.dense hX hA
    intro x
    have hx : x ∈ A := hAll.symm ▸ (Set.mem_univ x)
    exact hx

/-- Restriction and extension identify both the carrier and pointwise order. -/
def extensionOrderIso (CX : @ScottCompletion X.Carrier X.topology) :
    Cont X (scottSpace Q) ≃o ScottHom CX.Carrier Q where
  toFun f := CX.extend f.val f.property
  invFun := restrictScottHom CX
  left_inv f := Subtype.ext (funext (CX.extend_unit f.val f.property))
  right_inv g := by
    symm
    exact CX.extension_unique _ _ g (fun _ => rfl)
  map_rel_iff' := by
    intro f g
    exact extend_le_iff CX f g

private theorem dcpo_of_orderIso {P H : Type*} [PartialOrder P] [PartialOrder H]
    [IsDCPO H] (e : P ≃o H) : IsDCPO P where
  lub A hne hd := by
    obtain ⟨b, hb⟩ := IsDCPO.lub (e '' A) (hne.image e)
      (directedOn_image.mpr (hd.mono (fun _ _ h => e.monotone h)))
    exact ⟨e.symm b, e.isLUB_image.mp hb⟩

variable {C : SpaceClass.{u}}

theorem mixed_restriction_continuous (K : ClosedPresentation C)
    (hScott : ContainsScott C) (hSDC : ∀ X, C X → SDCSpace X)
    (hX : C X) (CX : @ScottCompletion X.Carrier X.topology) :
    @Continuous (ScottHom CX.Carrier Q) (Cont X (scottSpace Q)) (scott _)
      (K.exponents hX (hScott Q)).spaceTopology (restrictScottHom CX) := by
  let H := ScottHom CX.Carrier Q
  let F : Space := scottSpace H
  have hF : C F := hScott H
  let P := K.products hF hX
  letI : TopologicalSpace (H × X.Carrier) := P.spaceTopology
  letI : TopologicalSpace H := scott H
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Q := scott Q
  obtain ⟨CP⟩ := hSDC P.space P.belongs
  let CF := scottCompletion H
  have hcomp : @Continuous _ _ P.spaceTopology (productTopology CF CX) id :=
    product_pair CP CF CX ⟨Prod.fst, P.fst_continuous⟩ ⟨Prod.snd, P.snd_continuous⟩
  have hev : @Continuous _ _ (productTopology CF CX) (scott Q)
      (fun p : H × X.Carrier => p.1.val (CX.unit p.2)) := by
    letI : TopologicalSpace (H × X.Carrier) := productTopology CF CX
    letI : TopologicalSpace (H × CX.Carrier) := scott _
    exact (scott_iff_continuous.mp scott_eval).comp (productCompletion CF CX).embedding.continuous
  let f : Cont P.space (scottSpace Q) :=
    ⟨fun p => p.1.val (CX.unit p.2),
      @Continuous.comp _ _ _ P.spaceTopology (productTopology CF CX) (scott Q) id _ hev hcomp⟩
  exact (K.exponents hX (hScott Q)).transpose_continuous hF f

/-- Specialization on the exponential hom-set is pointwise. This uses the
ordinary-product case map only after the canonical continuous comparison. -/
theorem mixed_specializes_iff (K : ClosedPresentation C) (hScott : ContainsScott C)
    (hX : C X) (f g : Cont X (scottSpace Q)) :
    @Specializes _ (K.exponents hX (hScott Q)).spaceTopology g f ↔ f ≤ g := by
  let E := K.exponents hX (hScott Q)
  letI : TopologicalSpace (Cont X (scottSpace Q)) := E.spaceTopology
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Q := scott Q
  change Specializes g f ↔ f ≤ g
  constructor
  · intro h x
    let P := K.products E.belongs hX
    letI : TopologicalSpace (Cont X (scottSpace Q) × X.Carrier) := P.spaceTopology
    have hsection : Continuous (fun f : Cont X (scottSpace Q) => (f, x)) :=
      P.pair_continuous E.space E.belongs ⟨id, continuous_id⟩ ⟨fun _ => x, continuous_const⟩
    have hev : Continuous (fun f : Cont X (scottSpace Q) => f.val x) :=
      E.evaluation_continuous.comp hsection
    exact (specializes_scott_iff (f.val x) (g.val x)).mp (h.map hev)
  · intro h
    let S : Space := scottSpace Sierpinski.{u}
    letI : TopologicalSpace Sierpinski.{u} := scott _
    have hS : C S := hScott Sierpinski.{u}
    let P := K.products hS hX
    letI : TopologicalSpace (Sierpinski.{u} × X.Carrier) := P.spaceTopology
    have hB := @Continuous.comp _ _ _ P.spaceTopology (ordinaryProductSpace S X).topology
      (scott Q) id (sierpinskiCase f g) (sierpinskiCase_continuous f g h) P.comparison
    let B : Cont P.space (scottSpace Q) :=
      ⟨sierpinskiCase f g, hB⟩
    have htranspose := E.transpose_continuous hS B
    have hz : @Specializes Sierpinski.{u} (scott _) sierOne sierZero :=
      (specializes_scott_iff sierZero sierOne).mpr bot_le
    have h := hz.map htranspose
    change Specializes (transpose P hX B sierOne) (transpose P hX B sierZero) at h
    have h₁ : transpose P hX B sierOne = g := Subtype.ext rfl
    have h₀ : transpose P hX B sierZero = f := Subtype.ext rfl
    rwa [h₁, h₀] at h

/-- Equation `eq:mixed-exponential`: the canonical homeomorphism sends each map to its
unique extension to the completion. -/
theorem mixedExponential_homeomorph (K : ClosedPresentation C) (hScott : ContainsScott C)
    (hSDC : ∀ X, C X → SDCSpace X) (hX : C X)
    (CX : @ScottCompletion X.Carrier X.topology) (Q : Type u) [PartialOrder Q] [IsDCPO Q] :
    ∃ e : @Homeomorph (Cont X (scottSpace Q)) (ScottHom CX.Carrier Q)
      (K.exponents hX (hScott Q)).spaceTopology (scott _),
      ∀ f, e f = CX.extend f.val f.property := by
  let E := K.exponents hX (hScott Q)
  let T := Cont X (scottSpace Q)
  letI : TopologicalSpace T := E.spaceTopology
  letI : TopologicalSpace (ScottHom CX.Carrier Q) := scott _
  letI : T0Space T := K.t0 E.belongs
  let e : T ≃o ScottHom CX.Carrier Q := extensionOrderIso CX
  have ho : specializationOrder T = (inferInstance : PartialOrder T) := by
    apply PartialOrder.ext
    intro a b
    exact mixed_specializes_iff K hScott hX a b
  have hdcpo : IsDCPO T := dcpo_of_orderIso e
  have hrestrict : @Continuous _ _ (scott (ScottHom CX.Carrier Q)) E.spaceTopology e.symm :=
    mixed_restriction_continuous K hScott hSDC hX CX
  have hcomp : @Continuous T T (scott T) E.spaceTopology id := by
    have h := @Continuous.comp _ _ _ (scott T) (scott _) E.spaceTopology e e.symm
      hrestrict (scott_iff_continuous.mp (orderIso_scott e))
    convert h using 1
    funext f
    exact (e.symm_apply_apply f).symm
  have hcoarse : scott T ≤ E.spaceTopology := fun U hU => continuous_def.mp hcomp U hU
  have hMC : IsMonotoneConvergence T := by
    unfold IsMonotoneConvergence
    rw [ho]
    exact ⟨hdcpo, hcoarse⟩
  have hEq := (identityDCompletion T hMC).topology_eq_scott_of_sdc (hSDC E.space E.belongs)
  change E.spaceTopology = @scott T (specializationOrder T).toPreorder at hEq
  rw [ho] at hEq
  refine ⟨{ e.toEquiv with continuous_toFun := ?_, continuous_invFun := hrestrict }, fun _ => rfl⟩
  rw [hEq]
  exact scott_iff_continuous.mp (orderIso_scott e)

end ScottDCompletable
