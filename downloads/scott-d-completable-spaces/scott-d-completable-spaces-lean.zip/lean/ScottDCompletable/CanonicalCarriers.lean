import ScottDCompletable.CategoryPresentation

/-! The canonical set identifications for products and exponentials in full
subcategories containing the one-point space. -/

noncomputable section

open scoped Topology
universe u

namespace ScottDCompletable

abbrev canonicalPointSpace : Space.{u} := scottSpace PUnit.{u + 1}

private def pointOf (X : Space.{u}) (x : X.Carrier) : Cont canonicalPointSpace X := by
  letI : TopologicalSpace PUnit.{u + 1} := canonicalPointSpace.topology
  letI : TopologicalSpace X.Carrier := X.topology
  exact ⟨fun _ => x, continuous_const⟩

/-- Closure under homeomorphism permits replacing a categorical object by
its canonical carrier with the transported topology. -/
def CanonicalHomeomorphClosed (C : SpaceClass.{u}) : Prop :=
  ∀ (X Y : Space.{u}), C X →
    @Homeomorph X.Carrier Y.Carrier X.topology Y.topology → C Y

private def transportAlongEquiv {A B : Type u} (t : TopologicalSpace A) (e : A ≃ B) :
    @Homeomorph A B t (TopologicalSpace.induced (fun b : B => e.symm b) t) := by
  letI : TopologicalSpace A := t
  letI : TopologicalSpace B := TopologicalSpace.induced (fun b : B => e.symm b) t
  refine ⟨e, continuous_induced_rng.mpr ?_, continuous_induced_dom⟩
  have h : e.symm ∘ e = (id : A → A) := funext e.symm_apply_apply
  change Continuous (e.symm ∘ e)
  rw [h]
  exact continuous_id

/-- An arbitrary carrier for the product of `X` and `Y`. -/
structure RawProductPresentation (C : SpaceClass.{u}) (X Y : Space.{u}) where
  space : Space.{u}
  belongs : C space
  fst : Cont space X
  snd : Cont space Y
  universal : ∀ (Z : Space.{u}), C Z → ∀ (f : Cont Z X) (g : Cont Z Y),
    ∃! h : Cont Z space, ∀ z, fst.val (h.val z) = f.val z ∧ snd.val (h.val z) = g.val z

namespace RawProductPresentation

variable {C : SpaceClass.{u}} {X Y : Space.{u}} (P : RawProductPresentation C X Y)

/-- Test the product universal property with maps from the one-point object. -/
theorem carrier_bijective (hPoint : C canonicalPointSpace) :
    Function.Bijective (fun p : P.space.Carrier => (P.fst.val p, P.snd.val p)) := by
  constructor
  · intro p q hpq
    obtain ⟨k, _, hu⟩ := P.universal canonicalPointSpace hPoint
      (pointOf X (P.fst.val p)) (pointOf Y (P.snd.val p))
    have hp := hu (pointOf P.space p) fun _ => ⟨rfl, rfl⟩
    have hq := hu (pointOf P.space q) fun _ =>
      ⟨(congrArg Prod.fst hpq).symm, (congrArg Prod.snd hpq).symm⟩
    exact congrArg (fun h : Cont canonicalPointSpace P.space => h.val PUnit.unit) (hp.trans hq.symm)
  · intro p
    obtain ⟨k, hk, _⟩ := P.universal canonicalPointSpace hPoint
      (pointOf X p.1) (pointOf Y p.2)
    exact ⟨k.val PUnit.unit, Prod.ext (hk PUnit.unit).1 (hk PUnit.unit).2⟩

def carrierEquiv (hPoint : C canonicalPointSpace) : P.space.Carrier ≃ X.Carrier × Y.Carrier :=
  Equiv.ofBijective _ (P.carrier_bijective hPoint)

/-- The transported product has its usual set projections and pairing. -/
def normalize (hPoint : C canonicalPointSpace) (hClosed : CanonicalHomeomorphClosed C) :
    ProductPresentation C X Y := by
  let e := P.carrierEquiv hPoint
  let T := TopologicalSpace.induced e.symm P.space.topology
  let h := transportAlongEquiv P.space.topology e
  letI : TopologicalSpace P.space.Carrier := P.space.topology
  letI : TopologicalSpace (X.Carrier × Y.Carrier) := T
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  have hInv : Continuous (e.symm : X.Carrier × Y.Carrier → P.space.Carrier) :=
    continuous_induced_dom
  have hFwd : Continuous (e : P.space.Carrier → X.Carrier × Y.Carrier) :=
    h.continuous_toFun
  refine ⟨T, hClosed P.space ⟨_,T⟩ P.belongs h, ?_, ?_, ?_⟩
  · have he : P.fst.val ∘ e.symm = Prod.fst :=
      funext fun p => congrArg Prod.fst (e.apply_symm_apply p)
    rw [← he]
    exact P.fst.property.comp hInv
  · have he : P.snd.val ∘ e.symm = Prod.snd :=
      funext fun p => congrArg Prod.snd (e.apply_symm_apply p)
    rw [← he]
    exact P.snd.property.comp hInv
  · intro Z hZ f g
    letI : TopologicalSpace Z.Carrier := Z.topology
    obtain ⟨k, hk, _⟩ := P.universal Z hZ f g
    have he : e ∘ k.val = fun z => (f.val z, g.val z) :=
      funext fun z => Prod.ext (hk z).1 (hk z).2
    rw [← he]
    exact hFwd.comp k.property

/-- The canonical projection map is a homeomorphism onto the transported product. -/
def normalizeHomeomorph (hPoint : C canonicalPointSpace) (hClosed : CanonicalHomeomorphClosed C) :
    @Homeomorph P.space.Carrier (X.Carrier × Y.Carrier) P.space.topology
      (P.normalize hPoint hClosed).spaceTopology :=
  transportAlongEquiv P.space.topology (P.carrierEquiv hPoint)

end RawProductPresentation

abbrev RawProductChoices (C : SpaceClass.{u}) :=
  ∀ {X Y : Space.{u}}, C X → C Y → RawProductPresentation C X Y

def RawProductChoices.normalize {C : SpaceClass.{u}} (raw : RawProductChoices C)
    (hPoint : C canonicalPointSpace) (hClosed : CanonicalHomeomorphClosed C) : ProductChoices C :=
  fun hX hY => (raw hX hY).normalize hPoint hClosed

/-- An arbitrary exponential carrier over canonical set products. -/
structure RawExponentialPresentation (C : SpaceClass.{u}) (products : ProductChoices C)
    {X Y : Space.{u}} (hX : C X) (hY : C Y) where
  space : Space.{u}
  belongs : C space
  evaluation : Cont (products belongs hX).space Y
  universal : ∀ (Z : Space.{u}) (hZ : C Z) (f : Cont (products hZ hX).space Y),
    ∃! k : Cont Z space, ∀ z x, evaluation.val (k.val z,x) = f.val (z,x)

namespace RawExponentialPresentation

variable {C : SpaceClass.{u}} {products : ProductChoices C} {X Y : Space.{u}}
  {hX : C X} {hY : C Y} (E : RawExponentialPresentation C products hX hY)

/-- Identify a point of the exponential with its evaluation section. -/
def evaluationSection (p : E.space.Carrier) : Cont X Y :=
  transpose (products E.belongs hX) hX E.evaluation p

/-- Test exponential transposition with the one-point object. -/
theorem section_bijective (hPoint : C canonicalPointSpace) : Function.Bijective E.evaluationSection := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  constructor
  · intro p q hpq
    let P := products hPoint hX
    letI : TopologicalSpace P.space.Carrier := P.spaceTopology
    let f : Cont P.space Y := ⟨(E.evaluationSection p).val ∘ Prod.snd,
      (E.evaluationSection p).property.comp P.snd_continuous⟩
    obtain ⟨k, _, hu⟩ := E.universal canonicalPointSpace hPoint f
    have hp := hu (pointOf E.space p) fun _ _ => rfl
    have hq := hu (pointOf E.space q) fun _ x =>
      (congrArg (fun h : Cont X Y => h.val x) hpq).symm
    exact congrArg (fun h : Cont canonicalPointSpace E.space => h.val PUnit.unit) (hp.trans hq.symm)
  · intro f
    let P := products hPoint hX
    letI : TopologicalSpace P.space.Carrier := P.spaceTopology
    let g : Cont P.space Y := ⟨f.val ∘ Prod.snd, f.property.comp P.snd_continuous⟩
    obtain ⟨k, hk, _⟩ := E.universal canonicalPointSpace hPoint g
    exact ⟨k.val PUnit.unit, Subtype.ext (funext (hk PUnit.unit))⟩

def carrierEquiv (hPoint : C canonicalPointSpace) : E.space.Carrier ≃ Cont X Y :=
  Equiv.ofBijective E.evaluationSection (E.section_bijective hPoint)

/-- The transported exponential has its usual set evaluation and transposition. -/
def normalize (hPoint : C canonicalPointSpace) (hClosed : CanonicalHomeomorphClosed C) :
    ExponentialPresentation C products hX hY := by
  let e := E.carrierEquiv hPoint
  let T := TopologicalSpace.induced e.symm E.space.topology
  let h := transportAlongEquiv E.space.topology e
  letI : TopologicalSpace E.space.Carrier := E.space.topology
  letI : TopologicalSpace (Cont X Y) := T
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  have hInv : Continuous (e.symm : Cont X Y → E.space.Carrier) := continuous_induced_dom
  have hFwd : Continuous (e : E.space.Carrier → Cont X Y) := h.continuous_toFun
  have hNew : C ⟨Cont X Y,T⟩ := hClosed E.space ⟨_,T⟩ E.belongs h
  refine ⟨T, hNew, ?_, ?_⟩
  · let P := products hNew hX
    let Pold := products E.belongs hX
    letI : TopologicalSpace (Cont X Y × X.Carrier) := P.spaceTopology
    letI : TopologicalSpace (E.space.Carrier × X.Carrier) := Pold.spaceTopology
    let f : Cont P.space E.space := ⟨e.symm ∘ Prod.fst, hInv.comp P.fst_continuous⟩
    let g : Cont P.space X := ⟨Prod.snd, P.snd_continuous⟩
    have hc := Pold.pair_continuous P.space P.belongs f g
    have he : E.evaluation.val ∘ (fun p : Cont X Y × X.Carrier => (e.symm p.1,p.2)) =
        fun p => p.1.val p.2 :=
      funext fun p => congrArg (fun k : Cont X Y => k.val p.2) (e.apply_symm_apply p.1)
    rw [← he]
    exact E.evaluation.property.comp hc
  · intro Z hZ f
    letI : TopologicalSpace Z.Carrier := Z.topology
    obtain ⟨k, hk, _⟩ := E.universal Z hZ f
    have he : e ∘ k.val = transpose (products hZ hX) hX f := by
      funext z
      exact Subtype.ext (funext (hk z))
    rw [← he]
    exact hFwd.comp k.property

/-- Evaluation sections are a homeomorphism onto the transported exponential. -/
def normalizeHomeomorph (hPoint : C canonicalPointSpace) (hClosed : CanonicalHomeomorphClosed C) :
    @Homeomorph E.space.Carrier (Cont X Y) E.space.topology
      (E.normalize hPoint hClosed).spaceTopology :=
  transportAlongEquiv E.space.topology (E.carrierEquiv hPoint)

end RawExponentialPresentation

/-- An exponential described using products with arbitrary carriers. The two
projection equations express pairing with the section map and the identity. -/
structure AbstractExponentialPresentation (C : SpaceClass.{u}) (raw : RawProductChoices C)
    {X Y : Space.{u}} (hX : C X) (hY : C Y) where
  space : Space.{u}
  belongs : C space
  evaluation : Cont (raw belongs hX).space Y
  universal : ∀ (Z : Space.{u}) (hZ : C Z) (f : Cont (raw hZ hX).space Y),
    ∃! k : Cont Z space,
      ∀ (p : (raw hZ hX).space.Carrier) (q : (raw belongs hX).space.Carrier),
        (raw belongs hX).fst.val q = k.val ((raw hZ hX).fst.val p) →
        (raw belongs hX).snd.val q = (raw hZ hX).snd.val p → evaluation.val q = f.val p

namespace AbstractExponentialPresentation

variable {C : SpaceClass.{u}} {raw : RawProductChoices C} {X Y : Space.{u}}
  {hX : C X} {hY : C Y} (E : AbstractExponentialPresentation C raw hX hY)

/-- Replace each arbitrary product by its canonical set product in the
exponential universal property, retaining the original exponential object. -/
def overCanonicalProducts (hPoint : C canonicalPointSpace) (hClosed : CanonicalHomeomorphClosed C) :
    RawExponentialPresentation C (raw.normalize hPoint hClosed) hX hY := by
  let Eprod := raw E.belongs hX
  let e := Eprod.carrierEquiv hPoint
  let h := Eprod.normalizeHomeomorph hPoint hClosed
  letI : TopologicalSpace Eprod.space.Carrier := Eprod.space.topology
  letI : TopologicalSpace (E.space.Carrier × X.Carrier) := (Eprod.normalize hPoint hClosed).spaceTopology
  letI : TopologicalSpace Y.Carrier := Y.topology
  have hInv : Continuous (e.symm : E.space.Carrier × X.Carrier → Eprod.space.Carrier) :=
    h.continuous_invFun
  refine ⟨E.space, E.belongs, ⟨E.evaluation.val ∘ e.symm, E.evaluation.property.comp hInv⟩, ?_⟩
  intro Z hZ f
  let Zprod := raw hZ hX
  let eZ := Zprod.carrierEquiv hPoint
  let hZprod := Zprod.normalizeHomeomorph hPoint hClosed
  letI : TopologicalSpace Zprod.space.Carrier := Zprod.space.topology
  letI : TopologicalSpace (Z.Carrier × X.Carrier) := (Zprod.normalize hPoint hClosed).spaceTopology
  have hFwd : Continuous (eZ : Zprod.space.Carrier → Z.Carrier × X.Carrier) := hZprod.continuous_toFun
  let f' : Cont Zprod.space Y := ⟨f.val ∘ eZ, f.property.comp hFwd⟩
  obtain ⟨k, hk, hu⟩ := E.universal Z hZ f'
  refine ⟨k, ?_, ?_⟩
  · intro z x
    have hp := eZ.apply_symm_apply (z,x)
    have hq := e.apply_symm_apply (k.val z,x)
    have hp1 : Zprod.fst.val (eZ.symm (z,x)) = z := congrArg Prod.fst hp
    have hp2 : Zprod.snd.val (eZ.symm (z,x)) = x := congrArg Prod.snd hp
    have hq1 : Eprod.fst.val (e.symm (k.val z,x)) = k.val z := congrArg Prod.fst hq
    have hq2 : Eprod.snd.val (e.symm (k.val z,x)) = x := congrArg Prod.snd hq
    change E.evaluation.val (e.symm (k.val z,x)) = f.val (z,x)
    rw [← hp]
    exact hk (eZ.symm (z,x)) (e.symm (k.val z,x)) (by rw [hp1]; exact hq1) (hq2.trans hp2.symm)
  · intro l hl
    apply hu l
    intro p q hq1 hq2
    have hEq : e q = (l.val (Zprod.fst.val p), Zprod.snd.val p) := Prod.ext hq1 hq2
    have he : q = e.symm (l.val (Zprod.fst.val p), Zprod.snd.val p) :=
      (e.symm_apply_apply q).symm.trans (congrArg e.symm hEq)
    change E.evaluation.val q = f.val (eZ p)
    rw [he]
    exact hl (Zprod.fst.val p) (Zprod.snd.val p)

end AbstractExponentialPresentation

/-- Present a full Cartesian closed subcategory using its canonical set
carriers, starting from arbitrary choices of products and exponentials. -/
def closedPresentation_of_abstract {C : SpaceClass.{u}}
    (hT0 : ∀ {X : Space.{u}}, C X → @T0Space X.Carrier X.topology)
    (hPoint : C canonicalPointSpace) (hClosed : CanonicalHomeomorphClosed C)
    (raw : RawProductChoices C)
    (rawExponents : ∀ {X Y : Space.{u}} (hX : C X) (hY : C Y),
      AbstractExponentialPresentation C raw hX hY) : ClosedPresentation C where
  t0 := hT0
  products := raw.normalize hPoint hClosed
  exponents := fun hX hY =>
    ((rawExponents hX hY).overCanonicalProducts hPoint hClosed).normalize hPoint hClosed

end ScottDCompletable
