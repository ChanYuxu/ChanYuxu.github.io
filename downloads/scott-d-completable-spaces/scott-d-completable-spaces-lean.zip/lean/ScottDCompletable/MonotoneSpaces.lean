import ScottDCompletable.StrictExample
import ScottDCompletable.Completion

/-! Section 3, Proposition `prop:DTop-SDC`: directed-open sets, Scott
spaces of arbitrary posets, and c-spaces. The continuity step in the
D-completion inclusion uses the specialization inequality from convergence
of the image directed net, as in the original cited result. -/

noncomputable section
open Set Topology

namespace ScottDCompletable

/-- The principal upper set in the paper's specialization order. -/
def specializationUp {X : Type*} [TopologicalSpace X] (y : X) : Set X :=
  {z | Specializes z y}

/-- The c-space property on the paper's T₀ carriers. -/
def IsCSpace (X : Type*) [TopologicalSpace X] : Prop :=
  ∀ (x : X) (U : Set X), IsOpen U → x ∈ U →
    ∃ y : X, x ∈ interior (specializationUp y) ∧ specializationUp y ⊆ U

theorem directedOpen_of_isOpen {X : Type*} [TopologicalSpace X] {U : Set X}
    (hU : IsOpen U) : DirectedOpen U := by
  intro A _ _ x hx hconv
  obtain ⟨a, ha, htail⟩ := hconv U hU hx
  exact ⟨a, ha, htail a ha (specializes_refl a)⟩

theorem directedOpen_upper {X : Type*} [TopologicalSpace X] {U : Set X}
    (hU : DirectedOpen U) {x y : X} (hxy : Specializes y x) (hx : x ∈ U) :
    y ∈ U := by
  have hdir : DirectedOn (fun a b : X => Specializes b a) {y} := by
    intro a ha b hb
    have ha' : a = y := ha
    have hb' : b = y := hb
    subst a
    subst b
    exact ⟨y, mem_singleton y, specializes_refl y, specializes_refl y⟩
  have hconv : DirectedConverges {y} x := by
    intro V hV hxV
    refine ⟨y, mem_singleton y, ?_⟩
    intro b hb _
    have hb' : b = y := hb
    subst b
    exact hxy.mem_open hV hxV
  obtain ⟨z, hz, hzU⟩ := hU {y} (singleton_nonempty y) hdir x hx hconv
  exact (show z = y from hz) ▸ hzU

theorem monotoneDetermined_scott (P : Type*) [PartialOrder P] :
    @MonotoneDetermined P (scott P) := by
  letI : TopologicalSpace P := scott P
  letI : Topology.IsScott P Set.univ := ⟨rfl⟩
  have hspec {a b : P} : Specializes b a ↔ a ≤ b := by
    rw [specializes_iff_mem_closure, Topology.IsScott.closure_singleton]
    rfl
  intro U hU
  refine (scott_isOpen_iff U).2 ⟨?_, ?_⟩
  · intro x y hxy hx
    exact directedOpen_upper hU (hspec.mpr hxy) hx
  · intro A hne hd x hlub hx
    apply hU A hne (hd.mono (fun _ _ h => hspec.mpr h)) x hx
    intro V hV hxV
    obtain ⟨a, ha, haV⟩ := ((scott_isOpen_iff V).1 hV).2 hne hd hlub hxV
    exact ⟨a, ha, fun b _ hab => ((scott_isOpen_iff V).1 hV).1 (hspec.mp hab) haV⟩

theorem monotoneDetermined_of_cSpace {X : Type*} [TopologicalSpace X]
    (hX : IsCSpace X) : MonotoneDetermined X := by
  intro U hU
  rw [isOpen_iff_mem_nhds]
  intro x hx
  let A : Set X := {a | x ∈ interior (specializationUp a)}
  have hne : A.Nonempty := by
    obtain ⟨a, ha, _⟩ := hX x univ isOpen_univ (mem_univ x)
    exact ⟨a, ha⟩
  have hd : DirectedOn (fun a b : X => Specializes b a) A := by
    intro a ha b hb
    obtain ⟨c, hc, hsub⟩ := hX x
      (interior (specializationUp a) ∩ interior (specializationUp b))
      (isOpen_interior.inter isOpen_interior) ⟨ha, hb⟩
    have hcin := hsub (show c ∈ specializationUp c from specializes_refl c)
    exact ⟨c, hc, interior_subset hcin.1, interior_subset hcin.2⟩
  have hconv : DirectedConverges A x := by
    intro V hV hxV
    obtain ⟨a, ha, hsub⟩ := hX x V hV hxV
    exact ⟨a, ha, fun _ _ hab => hsub hab⟩
  obtain ⟨a, ha, haU⟩ := hU A hne hd x hx hconv
  exact mem_nhds_iff.mpr ⟨interior (specializationUp a),
    fun _ hb => directedOpen_upper hU (interior_subset hb) haU, isOpen_interior, ha⟩

/-- A map out of a monotone determined space into a dcpo with its
specialization order remains continuous when the codomain receives its
intrinsic Scott topology. -/
theorem continuous_to_scott_of_monotoneDetermined
    {X D : Type*} [TopologicalSpace X] [TopologicalSpace D]
    [PartialOrder D] [IsDCPO D]
    (hX : MonotoneDetermined X)
    (horder : ∀ {a b : D}, Specializes b a ↔ a ≤ b)
    {f : X → D} (hf : Continuous f) :
    @Continuous X D _ (scott D) f := by
  apply continuous_def.2
  intro U hU
  apply hX
  intro A hne hd x hx hconv
  have hm : ∀ a b, Specializes b a → f a ≤ f b :=
    fun _ _ hab => horder.mp (hab.map hf)
  have hdi : DirectedOn (· ≤ ·) (f '' A) :=
    directedOn_image.mpr (hd.mono hm)
  obtain ⟨s, hs⟩ := IsDCPO.lub (f '' A) (hne.image f) hdi
  have hxs : f x ≤ s := by
    by_contra hn
    have hc : IsClosed (Iic s) := by
      have eq : Iic s = closure {s} :=
        Set.ext fun _ => horder.symm.trans specializes_iff_mem_closure
      exact eq ▸ isClosed_closure
    have hopen : IsOpen (f ⁻¹' (Iic s)ᶜ) := hc.isOpen_compl.preimage hf
    obtain ⟨a, ha, htail⟩ := hconv _ hopen hn
    exact (htail a ha (specializes_refl a)) (hs.1 ⟨a, ha, rfl⟩)
  obtain ⟨_, ⟨a, ha, rfl⟩, haU⟩ :=
    ((scott_isOpen_iff U).1 hU).2 (hne.image f) hdi hs
      (((scott_isOpen_iff U).1 hU).1 hxs hx)
  exact ⟨a, ha, haU⟩

/-- Proposition 3: every monotone determined T₀ space has a Scott D-completion. -/
theorem isSDC_of_monotoneDetermined (X : Type*) [TopologicalSpace X] [T0Space X]
    (hX : MonotoneDetermined X) : IsSDC X := by
  let C := standardCompletion X
  letI : TopologicalSpace C.Carrier := C.topology
  letI : T0Space C.Carrier := C.t0
  letI : PartialOrder C.Carrier := C.order
  letI : IsDCPO C.Carrier := C.dcpo
  have hcont : @Continuous X C.Carrier _ (scott C.Carrier) C.unit :=
    continuous_to_scott_of_monotoneDetermined hX (fun {_ _} => Iff.rfl)
      C.embedding.continuous
  exact ⟨C.toScottCompletion (C.topology_eq_scott_of_continuous_unit hcont)⟩

theorem isSDC_of_cSpace (X : Type*) [TopologicalSpace X] [T0Space X]
    (hX : IsCSpace X) : IsSDC X :=
  isSDC_of_monotoneDetermined X (monotoneDetermined_of_cSpace hX)

theorem isSDC_scott (P : Type*) [PartialOrder P] : @IsSDC P (scott P) := by
  letI : TopologicalSpace P := scott P
  letI : T0Space P := scott_t0 P
  exact isSDC_of_monotoneDetermined P (monotoneDetermined_scott P)

namespace StrictExample

universe u

/-- The exact indicated completion of the manuscript witness. -/
def scottCompletion : ScottCompletion X where
  Carrier := D
  order := inferInstance
  dcpo := inferInstance
  unit := Subtype.val
  embedding := embed
  dense := generates _ (generated_closed _) (subset_generated _)

theorem isSDC : IsSDC X := ⟨scottCompletion⟩

theorem strict_witness : IsSDC X.{u} ∧ ¬ MonotoneDetermined X.{u} :=
  ⟨isSDC, not_monotoneDetermined⟩

end StrictExample

end ScottDCompletable
