import ScottDCompletable.Order
import Mathlib.Order.Preorder.Finite
import Mathlib.Order.Bounds.OrderIso
import Mathlib.Topology.Constructions.SumProd
import Mathlib.Tactic.DeriveFintype

/-! The six-point test and the bounded target from the upper-encoding lemma. -/

open Set
open scoped Topology

noncomputable section

universe u v
namespace ScottDCompletable

/-- The fixed source of §4.2. The two middle ranks each consist of two
incomparable points. -/
inductive SixSource : Type u
  | zero | alpha | beta | gamma | delta | one
  deriving DecidableEq, Fintype

namespace SixSource

theorem card : Fintype.card SixSource.{u} = 6 := by decide

def rank : SixSource → Nat
  | zero => 0
  | alpha | beta => 1
  | gamma | delta => 2
  | one => 3

def below (x y : SixSource) : Prop := x = y ∨ rank x < rank y

instance : PartialOrder SixSource where
  le := below
  le_refl x := Or.inl rfl
  le_trans _ _ _ h₁ h₂ := by
    rcases h₁ with h₁ | h₁
    · cases h₁
      exact h₂
    rcases h₂ with h₂ | h₂
    · cases h₂
      exact Or.inr h₁
    exact Or.inr (h₁.trans h₂)
  le_antisymm _ _ h₁ h₂ := by
    rcases h₁ with h₁ | h₁
    · exact h₁
    rcases h₂ with h₂ | h₂
    · exact h₂.symm
    exact False.elim ((Nat.lt_asymm h₁) h₂)

instance (x y : SixSource) : Decidable (x ≤ y) := by
  change Decidable (x = y ∨ rank x < rank y)
  infer_instance

instance : OrderBot SixSource.{u} where
  bot := zero
  bot_le x := by cases x <;> decide

instance : OrderTop SixSource.{u} where
  top := one
  le_top x := by cases x <;> decide

end SixSource

private theorem finite_directed_greatest {P : Type*} [PartialOrder P] {E : Set P}
    (hf : E.Finite) (hne : E.Nonempty) (hdir : DirectedOn (· ≤ ·) E) :
    ∃ e, IsGreatest E e := by
  obtain ⟨e, he⟩ := hf.exists_maximal hne
  exact ⟨e, hdir.maximal_iff_isGreatest.mp he⟩

instance sixSourceDCPO : IsDCPO SixSource.{u} where
  lub E hne hdir := by
    obtain ⟨e, he⟩ := finite_directed_greatest E.toFinite hne hdir
    exact ⟨e, he.isLUB⟩

/-- The Scott-open sets of the source are exactly its upper sets. -/
theorem sixSource_isOpen_iff (U : Set SixSource.{u}) :
    IsOpen[scott SixSource.{u}] U ↔ IsUpperSet U := by
  rw [scott_isOpen_iff]
  refine ⟨And.left, fun hu => ⟨hu, ?_⟩⟩
  intro D hne hdir s hs hsU
  obtain ⟨a, ha⟩ := finite_directed_greatest D.toFinite hne hdir
  exact ⟨a, ha.1, hs.unique ha.isLUB ▸ hsU⟩

section ScottSubspace

variable {P : Type*} [PartialOrder P] [IsDCPO P] {B : Set P}

omit [PartialOrder P] [IsDCPO P] in
private theorem image_subtype_preimage_of_subset {D : Set P} (hD : D ⊆ B) :
    (Subtype.val : B → P) '' (Subtype.val ⁻¹' D) = D := by
  ext x
  constructor
  · rintro ⟨y, hy, rfl⟩
    exact hy
  · intro hx
    exact ⟨⟨x, hD hx⟩, hx, rfl⟩

omit [IsDCPO P] in
private theorem subtype_inacc {U : Set B} (hU : DirSupInacc U)
    {D : Set P} (hD : D ⊆ B) (hne : D.Nonempty) (hdir : DirectedOn (· ≤ ·) D)
    {p : B} (hp : p ∈ U) (hlub : IsLUB D p.val) :
    ∃ d ∈ D, d ∈ (Subtype.val : B → P) '' U := by
  let E : Set B := Subtype.val ⁻¹' D
  have hE : E.Nonempty := by
    obtain ⟨x, hx⟩ := hne
    exact ⟨⟨x, hD hx⟩, hx⟩
  have hdirE : DirectedOn (· ≤ ·) E := by
    intro x hx y hy
    obtain ⟨z, hz, hxz, hyz⟩ := hdir x.val hx y.val hy
    exact ⟨⟨z, hD hz⟩, hz, hxz, hyz⟩
  have hlubE : IsLUB E p := isLUB_subtype (by
    change IsLUB ((Subtype.val : B → P) '' (Subtype.val ⁻¹' D)) p.val
    rw [image_subtype_preimage_of_subset hD]
    exact hlub)
  obtain ⟨d, hd, hdU⟩ := hU hE hdirE hlubE hp
  exact ⟨d.val, hd, ⟨d, hdU, rfl⟩⟩

private theorem embedding_of_open_extensions (hB : DirSupClosed B)
    (extend : ∀ U : Set B, IsOpen[scott B] U →
      ∃ V : Set P, IsOpen[scott P] V ∧ Subtype.val ⁻¹' V = U) :
    @Topology.IsEmbedding B P (scott B) (scott P) Subtype.val := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace B := scott B
  refine ⟨⟨?_⟩, Subtype.val_injective⟩
  apply TopologicalSpace.ext
  funext U
  apply propext
  change IsOpen U ↔ ∃ V : Set P, IsOpen V ∧ Subtype.val ⁻¹' V = U
  refine ⟨extend U, ?_⟩
  rintro ⟨V, hV, rfl⟩
  exact hV.preimage (scott_iff_continuous.mp (subtype_scott hB))

/-- For a Scott-open subset the intrinsic Scott topology equals the
subspace topology. The map is the literal inclusion. -/
theorem scott_subspace_of_open (hB : IsOpen[scott P] B) :
    @Topology.IsEmbedding B P (scott B) (scott P) Subtype.val := by
  have hb := (scott_isOpen_iff B).mp hB
  apply embedding_of_open_extensions hb.1.dirSupClosed
  intro U hU
  have hu := (scott_isOpen_iff U).mp hU
  refine ⟨Subtype.val '' U, ?_, ?_⟩
  · apply (scott_isOpen_iff _).mpr
    constructor
    · rintro _ q hpq ⟨p, hp, rfl⟩
      let q' : B := ⟨q, hb.1 hpq p.property⟩
      exact ⟨q', hu.1 hpq hp, rfl⟩
    · intro D hne hdir _ hlub hp
      obtain ⟨p, hpU, rfl⟩ := hp
      obtain ⟨d, hd, hdB⟩ := hb.2 hne hdir hlub p.property
      have hcofinal : ∀ x ∈ D, ∃ y ∈ D ∩ B, x ≤ y := by
        intro x hx
        obtain ⟨y, hy, hxy, hdy⟩ := hdir x hx d hd
        exact ⟨y, ⟨hy, hb.1 hdy hdB⟩, hxy⟩
      have hdir' : DirectedOn (· ≤ ·) (D ∩ B) := by
        intro x hx y hy
        obtain ⟨z, hz, hxz, hyz⟩ := hdir x hx.1 y hy.1
        obtain ⟨q, hq, hzq⟩ := hcofinal z hz
        exact ⟨q, hq, hxz.trans hzq, hyz.trans hzq⟩
      have hlub' : IsLUB (D ∩ B) p.val := by
        refine ⟨fun _ hx => hlub.1 hx.1, fun q hq => hlub.2 ?_⟩
        intro x hx
        obtain ⟨y, hy, hxy⟩ := hcofinal x hx
        exact hxy.trans (hq hy)
      obtain ⟨e, he, heU⟩ :=
        subtype_inacc (D := D ∩ B) hu.2 (fun _ hx => hx.2) ⟨d, hd, hdB⟩ hdir' hpU hlub'
      exact ⟨e, he.1, heU⟩
  · ext x
    constructor
    · rintro ⟨y, hy, heq⟩
      exact (Subtype.ext heq : y = x) ▸ hy
    · intro hx
      exact ⟨x, hx, rfl⟩

/-- For a Scott-closed subset the intrinsic Scott topology equals the
subspace topology. The map is the literal inclusion. -/
theorem scott_subspace_of_closed (hB : IsClosed[scott P] B) :
    @Topology.IsEmbedding B P (scott B) (scott P) Subtype.val := by
  have hb := (scott_isClosed_iff B).mp hB
  apply embedding_of_open_extensions hb.2
  intro U hU
  have hu := (scott_isOpen_iff U).mp hU
  refine ⟨Subtype.val '' U ∪ Bᶜ, ?_, ?_⟩
  · apply (scott_isOpen_iff _).mpr
    constructor
    · intro p q hpq hp
      by_cases hq : q ∈ B
      · have hpB := hb.1 hpq hq
        rcases hp with hp | hp
        · obtain ⟨x, hx, rfl⟩ := hp
          exact Or.inl ⟨⟨q, hq⟩, hu.1 hpq hx, rfl⟩
        · exact False.elim (hp hpB)
      · exact Or.inr hq
    · intro D hne hdir p hlub hp
      rcases hp with hp | hp
      · obtain ⟨q, hq, rfl⟩ := hp
        have hDB : D ⊆ B := fun _ hx => hb.1 (hlub.1 hx) q.property
        obtain ⟨x, hx, hxU⟩ := subtype_inacc hu.2 hDB hne hdir hq hlub
        exact ⟨x, hx, Or.inl hxU⟩
      · classical
        by_contra h
        apply hp
        apply hb.2 _ hne hdir hlub
        intro x hx
        by_contra hxb
        exact h ⟨x, hx, Or.inr hxb⟩
  · ext x
    constructor
    · intro hx
      rcases hx with hx | hx
      · obtain ⟨y, hy, heq⟩ := hx
        exact (Subtype.ext heq : y = x) ▸ hy
      · exact False.elim (hx x.property)
    · intro hx
      exact Or.inl ⟨x, hx, rfl⟩

end ScottSubspace

namespace Encoding

/-- The five additional elements below the adjoined top in the target. -/
inductive Tag
  | zero | a | b | c | d
  deriving DecidableEq, Fintype

def Tag.toSix : Tag → SixSource.{0}
  | .zero => .zero
  | .a => .alpha
  | .b => .beta
  | .c => .gamma
  | .d => .delta

private theorem Tag.toSix_injective : Function.Injective Tag.toSix := by
  intro x y h
  cases x <;> cases y <;> simp_all [Tag.toSix]

instance : PartialOrder Tag := PartialOrder.lift Tag.toSix Tag.toSix_injective

instance (x y : Tag) : Decidable (x ≤ y) :=
  inferInstanceAs (Decidable (x.toSix ≤ y.toSix))

/-- The literal target (P\sqcup\{0_R,a,b,c,d,\infty\}) of the manuscript.
The order depends on the upper subset (A). -/
inductive Target {P : Type u} [PartialOrder P] (A : Set P) (hA : IsUpperSet A)
  | tag : Tag → Target A hA
  | point : P → Target A hA
  | infinity : Target A hA

variable {P : Type u} [PartialOrder P] {A : Set P} {hA : IsUpperSet A}

def Tag.belowPoint (t : Tag) (p : P) : Prop :=
  match t with
  | .zero | .a | .b => True
  | .c | .d => p ∈ A

omit [PartialOrder P] in
private theorem Tag.belowPoint_of_le {s t : Tag} (hst : s ≤ t)
    (p : P) (ht : t.belowPoint (A := A) p) : s.belowPoint (A := A) p := by
  cases s <;> cases t <;> simp_all [Tag.belowPoint] <;>
    exact False.elim ((by decide : ¬ (_ ≤ _)) hst)

private theorem Tag.belowPoint_mono (hA : IsUpperSet A) (t : Tag) {p q : P} (hpq : p ≤ q)
    (hp : t.belowPoint (A := A) p) : t.belowPoint (A := A) q := by
  cases t <;> simp_all [Tag.belowPoint] <;> exact hA hpq hp

def Target.below : Target A hA → Target A hA → Prop
  | _, .infinity => True
  | .tag t, .tag s => t ≤ s
  | .tag t, .point p => t.belowPoint (A := A) p
  | .point p, .point q => p ≤ q
  | _, _ => False

instance targetPartialOrder : PartialOrder (Target A hA) where
  le := Target.below
  le_refl x := by cases x <;> simp [Target.below]
  le_trans x y z hxy hyz := by
    cases x <;> cases y <;> cases z <;> simp only [Target.below] at hxy hyz ⊢ <;>
      first | contradiction | trivial | exact le_trans hxy hyz |
      exact Tag.belowPoint_of_le hxy _ hyz | exact Tag.belowPoint_mono hA _ hyz hxy
  le_antisymm x y hxy hyx := by
    cases x <;> cases y <;> simp only [Target.below] at hxy hyx ⊢ <;>
      first | contradiction | rfl | exact congrArg _ (le_antisymm hxy hyx)

@[simp] theorem tag_le_tag {s t : Tag} :
    (Target.tag s : Target A hA) ≤ .tag t ↔ s ≤ t := Iff.rfl

@[simp] theorem tag_le_point {t : Tag} {p : P} :
    (Target.tag t : Target A hA) ≤ .point p ↔ t.belowPoint (A := A) p := Iff.rfl

@[simp] theorem point_le_point {p q : P} :
    (Target.point p : Target A hA) ≤ .point q ↔ p ≤ q := Iff.rfl

@[simp] theorem point_not_le_tag (p : P) (t : Tag) :
    ¬ (Target.point p : Target A hA) ≤ .tag t := id

@[simp] theorem infinity_not_le_point (p : P) :
    ¬ (Target.infinity : Target A hA) ≤ .point p := id

@[simp] theorem infinity_not_le_tag (t : Tag) :
    ¬ (Target.infinity : Target A hA) ≤ .tag t := id

instance targetOrderBot : OrderBot (Target A hA) where
  bot := .tag .zero
  bot_le x := by
    cases x with
    | tag t =>
      change Tag.zero ≤ t
      cases t <;> decide
    | point _ => trivial
    | infinity => trivial

instance targetOrderTop : OrderTop (Target A hA) where
  top := .infinity
  le_top _ := trivial

/-- The inclusion of the old points preserves all existing directed suprema. -/
def pointOrderEmbedding : P ↪o Target A hA where
  toFun := Target.point
  inj' := by intro a b h; cases h; rfl
  map_rel_iff' := Iff.rfl

theorem point_isLUB {E : Set P} (hne : E.Nonempty) {p : P} (hp : IsLUB E p) :
    IsLUB (Target.point (A := A) (hA := hA) '' E) (Target.point p) := by
  refine ⟨?_, ?_⟩
  · rintro _ ⟨q, hq, rfl⟩
    exact hp.1 hq
  · intro z hz
    cases z with
    | tag t =>
      obtain ⟨q, hq⟩ := hne
      exact False.elim (point_not_le_tag q t (hz ⟨q, hq, rfl⟩))
    | point q =>
      exact hp.2 (fun r hr => hz ⟨r, hr, rfl⟩)
    | infinity => exact le_top

instance targetDCPO [IsDCPO P] : IsDCPO (Target A hA) where
  lub E hne hdir := by
    classical
    by_cases hinf : Target.infinity ∈ E
    · exact ⟨Target.infinity, (show IsGreatest E Target.infinity from
          ⟨hinf, fun _ _ => le_top⟩).isLUB⟩
    let D : Set P := Target.point ⁻¹' E
    by_cases hd : D.Nonempty
    · have hcofinal : ∀ e ∈ E, ∃ d ∈ D, e ≤ Target.point d := by
        intro e he
        obtain ⟨d, hdm⟩ := hd
        obtain ⟨z, hz, hez, hdz⟩ := hdir e he (Target.point d) hdm
        cases z with
        | tag t => exact False.elim (point_not_le_tag d t hdz)
        | point p => exact ⟨p, hz, hez⟩
        | infinity => exact False.elim (hinf hz)
      have hdDir : DirectedOn (· ≤ ·) D := by
        intro a ha b hb
        obtain ⟨e, he, hae, hbe⟩ := hdir (Target.point a) ha (Target.point b) hb
        obtain ⟨d, hd, hed⟩ := hcofinal e he
        exact ⟨d, hd, hae.trans hed, hbe.trans hed⟩
      obtain ⟨p, hp⟩ := IsDCPO.lub D hd hdDir
      have hp' := point_isLUB (A := A) (hA := hA) hd hp
      refine ⟨Target.point p, ?_, ?_⟩
      · intro e he
        obtain ⟨d, hd, hed⟩ := hcofinal e he
        exact hed.trans (hp'.1 ⟨d, hd, rfl⟩)
      · intro q hq
        exact hp'.2 (by rintro _ ⟨d, hd, rfl⟩; exact hq hd)
    · have heTags : E ⊆ Set.range Target.tag := by
        intro e he
        cases e with
        | tag t => exact ⟨t, rfl⟩
        | point p => exact False.elim (hd ⟨p, he⟩)
        | infinity => exact False.elim (hinf he)
      obtain ⟨e, he⟩ := finite_directed_greatest ((Set.finite_range _).subset heTags) hne hdir
      exact ⟨e, he.isLUB⟩

/-- The upper interval of `a` has exactly the two excluded points of the manuscript. -/
theorem compl_Ici_a :
    (Ici (Target.tag .a : Target A hA))ᶜ = {Target.tag .zero, Target.tag .b} := by
  ext x
  cases x with
  | tag t =>
    cases t <;>
      simp only [mem_compl_iff, mem_Ici, tag_le_tag, mem_insert_iff, mem_singleton_iff,
        Target.tag.injEq] <;> decide
  | point p => simp [mem_compl_iff, mem_Ici, Tag.belowPoint]
  | infinity =>
    have h : (Target.tag .a : Target A hA) ≤ .infinity := trivial
    simp [h]

/-- The upper interval of `b` has exactly the two excluded points of the manuscript. -/
theorem compl_Ici_b :
    (Ici (Target.tag .b : Target A hA))ᶜ = {Target.tag .zero, Target.tag .a} := by
  ext x
  cases x with
  | tag t =>
    cases t <;>
      simp only [mem_compl_iff, mem_Ici, tag_le_tag, mem_insert_iff, mem_singleton_iff,
        Target.tag.injEq] <;> decide
  | point p => simp [mem_compl_iff, mem_Ici, Tag.belowPoint]
  | infinity =>
    have h : (Target.tag .b : Target A hA) ≤ .infinity := trivial
    simp [h]

/-- The exact downset used to force the gamma coordinate. -/
theorem Iic_c :
    Iic (Target.tag .c : Target A hA) =
      {Target.tag .zero, Target.tag .a, Target.tag .b, Target.tag .c} := by
  ext x
  cases x with
  | tag t =>
    cases t <;>
      simp only [mem_Iic, tag_le_tag, mem_insert_iff, mem_singleton_iff,
        Target.tag.injEq] <;> decide
  | point _ => simp
  | infinity => simp

/-- The exact downset used to force the delta coordinate. -/
theorem Iic_d :
    Iic (Target.tag .d : Target A hA) =
      {Target.tag .zero, Target.tag .a, Target.tag .b, Target.tag .d} := by
  ext x
  cases x with
  | tag t =>
    cases t <;>
      simp only [mem_Iic, tag_le_tag, mem_insert_iff, mem_singleton_iff,
        Target.tag.injEq] <;> decide
  | point _ => simp
  | infinity => simp

private theorem scott_open_of_finite_compl {Q : Type*} [PartialOrder Q] {U : Set Q}
    (hu : IsUpperSet U) (hf : Uᶜ.Finite) : IsOpen[scott Q] U := by
  refine (scott_isOpen_iff U).mpr ⟨hu, ?_⟩
  intro D hne hdir q hq hqU
  classical
  by_contra h
  have hD : D ⊆ Uᶜ := by
    intro d hd hdU
    exact h ⟨d, hd, hdU⟩
  obtain ⟨d, hd⟩ := finite_directed_greatest (hf.subset hD) hne hdir
  have he : q = d := hq.unique hd.isLUB
  exact hD hd.1 (he ▸ hqU)

theorem a_compact : IsOpen[scott (Target A hA)] (Ici (.tag .a)) := by
  apply scott_open_of_finite_compl (isUpperSet_Ici _)
  rw [compl_Ici_a]
  exact (Set.finite_singleton _).insert _

theorem b_compact : IsOpen[scott (Target A hA)] (Ici (.tag .b)) := by
  apply scott_open_of_finite_compl (isUpperSet_Ici _)
  rw [compl_Ici_b]
  exact (Set.finite_singleton _).insert _

/-- The copy of `A` with its fresh greatest element, inside the target. -/
def capSet : Set (Target A hA) := Ici (.tag .c) ∩ Ici (.tag .d)

abbrev Caps (A : Set P) (hA : IsUpperSet A) := ↥(capSet (A := A) (hA := hA))

def capPoint (p : A) : Caps A hA := ⟨.point p.val, p.property, p.property⟩

def capInfinity : Caps A hA := ⟨.infinity, True.intro, True.intro⟩

theorem cap_cases (x : Caps A hA) :
    x = capInfinity ∨ ∃ p : A, x = capPoint p := by
  rcases x with ⟨r, hr⟩
  cases r with
  | tag t =>
    have h₁ : Tag.c ≤ t := hr.1
    have h₂ : Tag.d ≤ t := hr.2
    cases t <;> exact False.elim (by
      first | exact (by decide : ¬ (Tag.c ≤ _)) h₁ | exact (by decide : ¬ (Tag.d ≤ _)) h₂)
  | point p => exact Or.inr ⟨⟨p, hr.1⟩, rfl⟩
  | infinity => exact Or.inl rfl

theorem capSet_eq : capSet (A := A) (hA := hA) =
    Target.point '' A ∪ {Target.infinity} := by
  ext r
  constructor
  · intro hr
    rcases cap_cases (⟨r, hr⟩ : Caps A hA) with he | ⟨p, he⟩
    · exact Or.inr (congrArg Subtype.val he)
    · exact Or.inl ⟨p.val, p.property, (congrArg Subtype.val he).symm⟩
  · rintro (⟨p, hp, rfl⟩ | h)
    · exact ⟨hp, hp⟩
    · have he : r = Target.infinity := h
      rw [he]
      exact ⟨True.intro, True.intro⟩

instance capsDCPO [IsDCPO P] : IsDCPO (Caps A hA) :=
  subDcpo_dcpo ((isUpperSet_Ici _).inter (isUpperSet_Ici _)).dirSupClosed

/-- The graph with the five fixed coordinates and prescribed last coordinate. -/
def sectionMap (q : Caps A hA) : SixSource.{u} → Target A hA
  | .zero => .tag .zero
  | .alpha => .tag .a
  | .beta => .tag .b
  | .gamma => .tag .c
  | .delta => .tag .d
  | .one => q.val

theorem sectionMap_monotone (q : Caps A hA) : Monotone (sectionMap q) := by
  have hac : (Target.tag .a : Target A hA) ≤ .tag .c := tag_le_tag.mpr (by decide)
  have hbc : (Target.tag .b : Target A hA) ≤ .tag .c := tag_le_tag.mpr (by decide)
  intro t s hts
  cases t <;> cases s <;>
    first | exact le_rfl | exact bot_le | exact tag_le_tag.mpr (by decide) |
      exact q.property.1 | exact q.property.2 |
      exact hac.trans q.property.1 | exact hbc.trans q.property.1 |
      exact False.elim ((by decide : ¬ (_ ≤ _)) hts)

private theorem finiteSource_scott {Q : Type*} [PartialOrder Q] {f : SixSource.{u} → Q}
    (hf : Monotone f) : ScottContinuous f := by
  intro D hne hdir t ht
  obtain ⟨d, hd⟩ := finite_directed_greatest D.toFinite hne hdir
  rw [ht.unique hd.isLUB]
  apply IsGreatest.isLUB
  refine ⟨⟨d, hd.1, rfl⟩, ?_⟩
  rintro _ ⟨s, hs, rfl⟩
  exact hf (hd.2 hs)

def sectionHom (q : Caps A hA) : ScottHom SixSource.{u} (Target A hA) :=
  ScottHom.ofScott _ (finiteSource_scott (sectionMap_monotone q))

/-- The maximal graph `w` in the proof. -/
def w : ScottHom SixSource.{u} (Target A hA) := sectionHom capInfinity

/-- The Scott-closed principal downset of the maximal graph. -/
abbrev Principal := ↥(Iic (w (A := A) (hA := hA)))

theorem principal_closed :
    IsClosed[scott (ScottHom SixSource.{u} (Target A hA))] (Iic (w (A := A) (hA := hA))) :=
  (scott_isClosed_iff _).mpr ⟨isLowerSet_Iic _, dirSupClosed_Iic _⟩

instance principalDCPO [IsDCPO P] : IsDCPO (Principal (A := A) (hA := hA)) :=
  subDcpo_dcpo (dirSupClosed_Iic _)

/-- The two compact coordinate tests inside the principal downset. -/
def omegaSet : Set (Principal (A := A) (hA := hA)) :=
  {u | (.tag .a : Target A hA) ≤ u.val.val .alpha ∧
       (.tag .b : Target A hA) ≤ u.val.val .beta}

abbrev Omega := ↥(omegaSet (A := A) (hA := hA))

private theorem eval_scott [IsDCPO P] (t : SixSource.{u}) :
    ScottContinuous (fun u : ScottHom SixSource.{u} (Target A hA) => u.val t) := by
  intro E hne hdir p hp
  obtain ⟨f, hf, hpoint⟩ := scottHom_lub E hne hdir
  rw [hp.unique hf]
  exact hpoint t

theorem omega_open [IsDCPO P] :
    IsOpen[scott (Principal (A := A) (hA := hA))] (omegaSet (A := A) (hA := hA)) := by
  letI : TopologicalSpace (Principal (A := A) (hA := hA)) :=
    scott (Principal (A := A) (hA := hA))
  letI : TopologicalSpace (Target A hA) := scott (Target A hA)
  have h(t : SixSource.{u}) :
      Continuous (fun u : Principal (A := A) (hA := hA) => u.val.val t) :=
    scott_iff_continuous.mp ((subtype_scott (dirSupClosed_Iic _)).comp (eval_scott t))
  exact (a_compact.preimage (h .alpha)).inter (b_compact.preimage (h .beta))

private theorem sectionHom_le_w (q : Caps A hA) :
    sectionHom q ≤ w (A := A) (hA := hA) := by
  intro t
  cases t <;> first | exact le_rfl | exact le_top

def intoOmega (q : Caps A hA) : Omega (A := A) (hA := hA) :=
  ⟨⟨sectionHom q, sectionHom_le_w q⟩, le_rfl, le_rfl⟩

private theorem only_tag_ab_below {r : Target A hA} {s : Tag}
    (hs : s = .c ∨ s = .d)
    (ha : (Target.tag .a : Target A hA) ≤ r)
    (hb : (Target.tag .b : Target A hA) ≤ r) (hr : r ≤ .tag s) :
    r = .tag s := by
  cases r with
  | tag t =>
    have hta : Tag.a ≤ t := ha
    have htb : Tag.b ≤ t := hb
    have hts : t ≤ s := hr
    rcases hs with rfl | rfl <;> cases t <;>
      first | rfl | exact False.elim ((by decide : ¬ (_ ≤ _)) hta) |
        exact False.elim ((by decide : ¬ (_ ≤ _)) htb) |
        exact False.elim ((by decide : ¬ (_ ≤ _)) hts)
  | point p => exact False.elim (point_not_le_tag p s hr)
  | infinity => exact False.elim (infinity_not_le_tag s hr)

private theorem shape_of_omega (u : Omega (A := A) (hA := hA)) :
    u.val.val.val .zero = .tag .zero ∧
    u.val.val.val .alpha = .tag .a ∧
    u.val.val.val .beta = .tag .b ∧
    u.val.val.val .gamma = .tag .c ∧
    u.val.val.val .delta = .tag .d ∧
    u.val.val.val .one ∈ capSet := by
  let f := u.val.val
  have hle : f ≤ w (A := A) (hA := hA) := u.val.property
  have hz : f.val .zero = .tag .zero := le_antisymm (hle .zero) bot_le
  have ha : f.val .alpha = .tag .a := le_antisymm (hle .alpha) u.property.1
  have hb : f.val .beta = .tag .b := le_antisymm (hle .beta) u.property.2
  have hmono := f.isScott.monotone
  have hc : f.val .gamma = .tag .c := by
    apply only_tag_ab_below (Or.inl rfl) _ _ (hle .gamma)
    · rw [← ha]
      exact hmono (by decide : SixSource.alpha.{u} ≤ .gamma)
    · rw [← hb]
      exact hmono (by decide : SixSource.beta.{u} ≤ .gamma)
  have hd : f.val .delta = .tag .d := by
    apply only_tag_ab_below (Or.inr rfl) _ _ (hle .delta)
    · rw [← ha]
      exact hmono (by decide : SixSource.alpha.{u} ≤ .delta)
    · rw [← hb]
      exact hmono (by decide : SixSource.beta.{u} ≤ .delta)
  refine ⟨hz, ha, hb, hc, hd, ?_, ?_⟩
  · change Target.tag .c ≤ f.val .one
    rw [← hc]
    exact hmono (by decide : SixSource.gamma.{u} ≤ .one)
  · change Target.tag .d ≤ f.val .one
    rw [← hd]
    exact hmono (by decide : SixSource.delta.{u} ≤ .one)

/-- The order isomorphism with inverse given by evaluation at `one`. -/
def capOmegaIso : Caps A hA ≃o Omega (A := A) (hA := hA) where
  toFun := intoOmega
  invFun u := ⟨u.val.val.val .one, (shape_of_omega u).2.2.2.2.2⟩
  left_inv _ := rfl
  right_inv u := by
    apply Subtype.ext
    apply Subtype.ext
    apply Subtype.ext
    funext t
    obtain ⟨hz, ha, hb, hc, hd, _⟩ := shape_of_omega u
    cases t
    · exact hz.symm
    · exact ha.symm
    · exact hb.symm
    · exact hc.symm
    · exact hd.symm
    · rfl
  map_rel_iff' := by
    intro q r
    constructor
    · intro h
      exact h .one
    · intro h t
      cases t <;> first | exact le_rfl | exact h

theorem point_scott : ScottContinuous (Target.point (A := A) (hA := hA)) :=
  fun _ hne _ _ hp => point_isLUB hne hp

private theorem orderEmbedding_range_dirSupClosed {M N : Type*}
    [PartialOrder M] [PartialOrder N] [IsDCPO M] (e : M ↪o N)
    (he : ScottContinuous e) : DirSupClosed (Set.range e) := by
  intro D hD hne hdir d hd
  let E : Set M := e ⁻¹' D
  have hneE : E.Nonempty := by
    obtain ⟨x, hx⟩ := hne
    obtain ⟨y, rfl⟩ := hD hx
    exact ⟨y, hx⟩
  have hdirE : DirectedOn (· ≤ ·) E := by
    intro x hx y hy
    obtain ⟨z, hz, hxz, hyz⟩ := hdir (e x) hx (e y) hy
    obtain ⟨w, rfl⟩ := hD hz
    exact ⟨w, hz, e.le_iff_le.mp hxz, e.le_iff_le.mp hyz⟩
  have him : e '' E = D := by
    ext x
    constructor
    · rintro ⟨y, hy, rfl⟩
      exact hy
    · intro hx
      obtain ⟨y, rfl⟩ := hD hx
      exact ⟨y, hx, rfl⟩
  obtain ⟨x, hx⟩ := IsDCPO.lub E hneE hdirE
  have hlub := he hneE hdirE hx
  rw [him] at hlub
  exact ⟨x, hlub.unique hd⟩

theorem point_subDcpo [IsDCPO P] :
    SubDcpo (Set.range (Target.point (A := A) (hA := hA))) :=
  orderEmbedding_range_dirSupClosed pointOrderEmbedding point_scott

def capPointOrderEmbedding : A ↪o Caps A hA where
  toFun := capPoint
  inj' := by
    intro p q h
    apply Subtype.ext
    exact Target.point.inj (congrArg Subtype.val h)
  map_rel_iff' := Iff.rfl

/-- Removing the fresh top from the copy of `A` leaves a Scott-closed set. -/
theorem capPoint_closed [IsDCPO P] :
    IsClosed[scott (Caps A hA)] (Set.range capPointOrderEmbedding) := by
  letI : IsDCPO A := subDcpo_dcpo hA.dirSupClosed
  let e : A ↪o Caps A hA := capPointOrderEmbedding
  have hm : ScottContinuous (e : A → Caps A hA) :=
    scott_corestrict (A := capSet (A := A) (hA := hA))
      (f := fun p : A => Target.point p.val)
      ((subtype_scott hA.dirSupClosed).comp point_scott)
      (fun p => ⟨p.property, p.property⟩)
  apply (scott_isClosed_iff _).mpr
  refine ⟨?_, orderEmbedding_range_dirSupClosed e hm⟩
  intro y x hxy hy
  obtain ⟨p, rfl⟩ := hy
  rcases cap_cases x with hx | ⟨q, hq⟩
  · exact False.elim (infinity_not_le_point p.val (hx ▸ hxy))
  · exact ⟨q, hq.symm⟩

private theorem scott_orderIso_continuous {M N : Type*}
    [PartialOrder M] [PartialOrder N] (e : M ≃o N) :
    @Continuous M N (scott M) (scott N) e := by
  apply scott_iff_continuous.mp
  intro E _ _ x hx
  exact e.isLUB_image'.mpr hx

private theorem scott_orderIso_embedding {M N : Type*}
    [PartialOrder M] [PartialOrder N] (e : M ≃o N) :
    @Topology.IsEmbedding M N (scott M) (scott N) e := by
  letI : TopologicalSpace M := scott M
  letI : TopologicalSpace N := scott N
  let h : M ≃ₜ N :=
    ⟨e.toEquiv, scott_orderIso_continuous e, scott_orderIso_continuous e.symm⟩
  exact h.isEmbedding

private theorem scott_closedRange_embedding {M N : Type*}
    [PartialOrder M] [PartialOrder N] [IsDCPO N] (e : M ↪o N)
    (he : IsClosed[scott N] (Set.range e)) :
    @Topology.IsEmbedding M N (scott M) (scott N) e := by
  letI : TopologicalSpace M := scott M
  letI : TopologicalSpace N := scott N
  letI : TopologicalSpace (Set.range e) := scott (Set.range e)
  let E : M ≃o Set.range e := {
    Equiv.ofInjective e e.injective with
    map_rel_iff' := e.le_iff_le
  }
  exact (scott_subspace_of_closed he).comp (scott_orderIso_embedding E)

/-- The map `j(q)=u_q` from the source proof. -/
def j (q : A) : ScottHom SixSource.{u} (Target A hA) := sectionHom (capPoint q)

@[simp] theorem j_one (q : A) : (j (hA := hA) q).val .one = Target.point q.val := rfl

theorem j_isEmbedding [IsDCPO P] :
    @Topology.IsEmbedding A (ScottHom SixSource.{u} (Target A hA))
      (scott A) (scott (ScottHom SixSource.{u} (Target A hA))) (j (A := A) (hA := hA)) := by
  letI : TopologicalSpace A := scott A
  letI : TopologicalSpace (Caps A hA) := scott (Caps A hA)
  letI : TopologicalSpace (Omega (A := A) (hA := hA)) :=
    scott (Omega (A := A) (hA := hA))
  letI : TopologicalSpace (Principal (A := A) (hA := hA)) :=
    scott (Principal (A := A) (hA := hA))
  letI : TopologicalSpace (ScottHom SixSource.{u} (Target A hA)) :=
    scott (ScottHom SixSource.{u} (Target A hA))
  have h₁ : Topology.IsEmbedding
      (Subtype.val : Principal (A := A) (hA := hA) → ScottHom SixSource.{u} (Target A hA)) :=
    scott_subspace_of_closed principal_closed
  have h₂ : Topology.IsEmbedding
      (Subtype.val : Omega (A := A) (hA := hA) → Principal (A := A) (hA := hA)) :=
    scott_subspace_of_open omega_open
  have h₃ := scott_orderIso_embedding (capOmegaIso (A := A) (hA := hA))
  have h₄ := scott_closedRange_embedding (capPointOrderEmbedding (A := A) (hA := hA))
    (capPoint_closed (A := A) (hA := hA))
  exact h₁.comp (h₂.comp (h₃.comp h₄))

/-- The test map is assembled on the ordinary topological product. -/
def H {X : Type v} (f : X → P) (hmem : ∀ x, f x ∈ A) :
    X × SixSource.{u} → Target A hA :=
  fun xt => (j ⟨f xt.1, hmem xt.1⟩).val xt.2

theorem continuous_H {X : Type v} [TopologicalSpace X] {f : X → P}
    (hf : @Continuous X P _ (scott P) f) (hmem : ∀ x, f x ∈ A) :
    letI : TopologicalSpace SixSource.{u} := scott SixSource.{u}
    letI : TopologicalSpace (Target A hA) := scott (Target A hA)
    Continuous (H (A := A) (hA := hA) f hmem) := by
  letI : TopologicalSpace SixSource.{u} := scott SixSource.{u}
  letI : TopologicalSpace (Target A hA) := scott (Target A hA)
  letI : TopologicalSpace P := scott P
  change Continuous (H (A := A) (hA := hA) f hmem)
  let h := H (A := A) (hA := hA) f hmem
  have hs (t : SixSource.{u}) : Continuous (fun x : X => h (x, t)) := by
    cases t
    · exact continuous_const
    · exact continuous_const
    · exact continuous_const
    · exact continuous_const
    · exact continuous_const
    · exact (scott_iff_continuous.mp point_scott).comp hf
  apply continuous_def.mpr
  intro V hV
  have hVu := ((scott_isOpen_iff V).mp hV).1
  have he : h ⁻¹' V =
      ⋃ t : SixSource.{u}, (((fun x : X => h (x,t)) ⁻¹' V) ×ˢ Ici t) := by
    ext x
    constructor
    · intro hx
      exact Set.mem_iUnion.mpr ⟨x.2, hx, Set.mem_Ici.mpr le_rfl⟩
    · intro hx
      obtain ⟨t, ht⟩ := Set.mem_iUnion.mp hx
      exact hVu ((j (A := A) (hA := hA) ⟨f x.1, hmem x.1⟩).isScott.monotone ht.2)
        ht.1
  rw [show H (A := A) (hA := hA) f hmem ⁻¹' V = h ⁻¹' V from rfl, he]
  apply isOpen_iUnion
  intro t
  exact (hV.preimage (hs t)).prod ((sixSource_isOpen_iff (Ici t)).mpr (isUpperSet_Ici t))

end Encoding

/-- Source-facing upper-encoding lemma. It returns the literal bounded target,
the sub-dcpo embedding of the original dcpo, the topological encoding and
the continuity assertion for every ordinary-product test map. -/
theorem upper_encoding {P : Type u} [PartialOrder P] [IsDCPO P]
    (A : Set P) (hA : IsUpperSet A) (_hne : A.Nonempty) :
    ∃ (R : Type u) (oR : PartialOrder R), letI := oR
      IsDCPO R ∧ Nonempty (OrderBot R) ∧ Nonempty (OrderTop R) ∧
      ∃ (i : P ↪o R) (j : A → ScottHom SixSource.{u} R),
        ScottContinuous i ∧ SubDcpo (Set.range i) ∧
        @Topology.IsEmbedding A (ScottHom SixSource.{u} R)
          (scott A) (scott (ScottHom SixSource.{u} R)) j ∧
        ∀ (X : Type v) [TopologicalSpace X] (f : X → P),
          @Continuous X P _ (scott P) f → ∀ hmem : ∀ x, f x ∈ A,
            letI : TopologicalSpace SixSource.{u} := scott SixSource.{u}
            letI : TopologicalSpace R := scott R
            Continuous (fun xt : X × SixSource.{u} => (j ⟨f xt.1, hmem xt.1⟩).val xt.2) := by
  refine ⟨Encoding.Target A hA, inferInstance, inferInstance, ⟨inferInstance⟩, ⟨inferInstance⟩,
    Encoding.pointOrderEmbedding, Encoding.j, Encoding.point_scott,
    Encoding.point_subDcpo, Encoding.j_isEmbedding, ?_⟩
  intro X _ f hf hmem
  exact Encoding.continuous_H hf hmem

end ScottDCompletable
