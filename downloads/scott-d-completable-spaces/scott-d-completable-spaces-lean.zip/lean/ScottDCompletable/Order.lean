import Mathlib.Topology.Order.ScottTopology
import Mathlib.Order.ScottContinuity.Prod

noncomputable section
open Set
open scoped Topology

namespace ScottDCompletable

class IsDCPO (P : Type*) [PartialOrder P] : Prop where
  lub : ∀ (A : Set P), A.Nonempty → DirectedOn (· ≤ ·) A → ∃ a, IsLUB A a

abbrev scott (P : Type*) [Preorder P] : TopologicalSpace P := Topology.scott P Set.univ

abbrev SubDcpo {P : Type*} [Preorder P] (A : Set P) : Prop := DirSupClosed A

def generated {P : Type*} [Preorder P] (A : Set P) : Set P :=
  ⋂₀ {B | A ⊆ B ∧ SubDcpo B}

theorem subset_generated {P : Type*} [Preorder P] (A : Set P) : A ⊆ generated A :=
  fun _ hx => Set.mem_sInter.mpr fun _ h => h.1 hx

theorem generated_subset {P : Type*} [Preorder P] {A B : Set P}
    (h : A ⊆ B) (hB : SubDcpo B) : generated A ⊆ B :=
  fun _ hx => Set.mem_sInter.mp hx B ⟨h, hB⟩

theorem generated_closed {P : Type*} [Preorder P] (A : Set P) : SubDcpo (generated A) := by
  intro E hE hne hdir s hs
  exact Set.mem_sInter.mpr fun B hB => hB.2 (hE.trans (generated_subset hB.1 hB.2)) hne hdir hs

theorem scott_iff_continuous {P Q : Type*} [Preorder P] [Preorder Q] {f : P → Q} :
    ScottContinuous f ↔ @Continuous P Q (scott P) (scott Q) f := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  letI : Topology.IsScott P Set.univ := ⟨rfl⟩
  letI : Topology.IsScott Q Set.univ := ⟨rfl⟩
  simpa only [scottContinuousOn_univ] using
    (Topology.IsScott.scottContinuousOn_iff_continuous (D := Set.univ) (f := f)
      (fun _ _ _ => mem_univ _))

theorem scott_isOpen_iff {P : Type*} [Preorder P] (U : Set P) :
    IsOpen[scott P] U ↔ IsUpperSet U ∧ DirSupInacc U := by
  letI : TopologicalSpace P := scott P
  letI : Topology.IsScott P Set.univ := ⟨rfl⟩
  simpa only [dirSupInaccOn_univ] using
    (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn (D := Set.univ) (s := U))

theorem scott_isClosed_iff {P : Type*} [Preorder P] (U : Set P) :
    IsClosed[scott P] U ↔ IsLowerSet U ∧ DirSupClosed U := by
  letI : TopologicalSpace P := scott P
  letI : Topology.IsScott P Set.univ := ⟨rfl⟩
  exact Topology.IsScott.isClosed_iff_isLowerSet_and_dirSupClosed

theorem scott_t0 (P : Type*) [PartialOrder P] : @T0Space P (scott P) := by
  letI : TopologicalSpace P := scott P
  letI : Topology.IsScott P Set.univ := ⟨rfl⟩
  infer_instance

instance (P : Type*) [CompleteLattice P] : IsDCPO P :=
  ⟨fun A _ _ => ⟨sSup A, isLUB_sSup A⟩⟩

instance (P Q : Type*) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q] :
    IsDCPO (P × Q) where
  lub A hne hdir := by
    obtain ⟨p, hp⟩ := IsDCPO.lub (Prod.fst '' A) (hne.image _) hdir.fst
    obtain ⟨q, hq⟩ := IsDCPO.lub (Prod.snd '' A) (hne.image _) hdir.snd
    exact ⟨(p, q), isLUB_prod.mpr ⟨hp, hq⟩⟩

theorem subDcpo_preimage {P Q : Type*} [Preorder P] [Preorder Q]
    {f : P → Q} (hf : ScottContinuous f) {A : Set Q} (hA : SubDcpo A) :
    SubDcpo (f ⁻¹' A) := by
  intro D hD hne hdir a ha
  exact hA (image_subset_iff.mpr hD) (hne.image _) (directedOn_image.mpr (hdir.mono hf.monotone)) (hf hne hdir ha)

theorem upper_subDcpo {P : Type*} [Preorder P] {A : Set P} (hA : IsUpperSet A) :
    SubDcpo A := by
  intro E hE hne _ x hx
  obtain ⟨e, he⟩ := hne
  exact hA (hx.1 he) (hE he)

theorem isLUB_subtype {P : Type*} [Preorder P] {A : Set P} {E : Set A} {p : A}
    (h : IsLUB (Subtype.val '' E) p.val) : IsLUB E p := by
  refine ⟨fun x hx => h.1 ⟨x, hx, rfl⟩, fun b hb => h.2 ?_⟩
  rintro _ ⟨x, hx, rfl⟩
  exact hb hx

theorem subDcpo_dcpo {P : Type*} [PartialOrder P] [IsDCPO P] {A : Set P}
    (hA : SubDcpo A) : IsDCPO A where
  lub E hne hdir := by
    have hd : DirectedOn (· ≤ ·) (Subtype.val '' E) := directedOn_image.mpr (hdir.mono (fun _ _ h => h))
    obtain ⟨p, hp⟩ := IsDCPO.lub (Subtype.val '' E) (hne.image _) hd
    have hm : p ∈ A := hA (by rintro _ ⟨x, _, rfl⟩; exact x.property) (hne.image _) hd hp
    exact ⟨⟨p, hm⟩, isLUB_subtype hp⟩

theorem subtype_scott {P : Type*} [PartialOrder P] [IsDCPO P] {A : Set P}
    (hA : SubDcpo A) : ScottContinuous (Subtype.val : A → P) := by
  intro E hne hdir a ha
  have hd : DirectedOn (· ≤ ·) (Subtype.val '' E) := directedOn_image.mpr (hdir.mono (fun _ _ h => h))
  obtain ⟨p, hp⟩ := IsDCPO.lub (Subtype.val '' E) (hne.image _) hd
  have hm : p ∈ A := hA (by rintro _ ⟨x, _, rfl⟩; exact x.property) (hne.image _) hd hp
  have eq := ha.unique (isLUB_subtype (p := ⟨p, hm⟩) hp)
  simpa only [eq] using hp

theorem scott_corestrict {P Q : Type*} [Preorder P] [Preorder Q] {A : Set Q}
    {f : P → Q} (hf : ScottContinuous f) (hm : ∀ x, f x ∈ A) :
    ScottContinuous (fun x => (⟨f x, hm x⟩ : A)) := by
  intro E hne hdir a ha
  apply isLUB_subtype
  rw [Set.image_image]
  exact hf hne hdir ha

theorem generated_eq_of_superset {P : Type*} [Preorder P] {A B : Set P}
    (hA : generated A = univ) (hAB : A ⊆ B) (hB : SubDcpo B) : B = univ :=
  Set.eq_univ_of_univ_subset (hA ▸ generated_subset hAB hB)

theorem generated_subtype {P : Type*} [PartialOrder P] [IsDCPO P] (A : Set P)
    (B : Set (generated A)) (hB : Subtype.val '' B = A) : generated B = univ := by
  apply Set.eq_univ_of_forall
  intro p
  have hc : SubDcpo (Subtype.val '' (generated B) : Set P) := by
    intro E hE hne hdir s hs
    let C : Set (generated A) := {x | x.val ∈ E ∧ x ∈ generated B}
    have him : Subtype.val '' C = E := by
      ext x
      constructor
      · rintro ⟨q, hq, rfl⟩; exact hq.1
      · intro hx
        obtain ⟨q, hq, rfl⟩ := hE hx
        exact ⟨q, ⟨hx, hq⟩, rfl⟩
    have hsub : E ⊆ generated A := by
      intro x hx
      obtain ⟨q, _, rfl⟩ := hE hx
      exact q.property
    let t : generated A := ⟨s, generated_closed A hsub hne hdir hs⟩
    have hneC : C.Nonempty := by
      obtain ⟨x, hx⟩ := hne
      rw [← him] at hx
      obtain ⟨q, hq, _⟩ := hx
      exact ⟨q, hq⟩
    have hdC : DirectedOn (· ≤ ·) C := by
      intro x hx y hy
      obtain ⟨z, hz, hxz, hyz⟩ := hdir x.val hx.1 y.val hy.1
      rw [← him] at hz
      obtain ⟨q, hq, rfl⟩ := hz
      exact ⟨q, hq, hxz, hyz⟩
    have hl : IsLUB C t := isLUB_subtype (by change IsLUB (Subtype.val '' C) s; rw [him]; exact hs)
    exact ⟨t, generated_closed B (fun _ h => h.2) hneC hdC hl, rfl⟩
  have hs : A ⊆ (Subtype.val '' (generated B) : Set P) := by
    intro x hx
    have hxB : x ∈ Subtype.val '' B := by rw [hB]; exact hx
    exact Set.image_mono (subset_generated B) hxB
  obtain ⟨q, hq, hqp⟩ := generated_subset hs hc p.property
  exact (Subtype.ext hqp : q = p) ▸ hq

theorem generated_prod {P Q : Type*} [Preorder P] [Preorder Q] (A : Set P) (B : Set Q) :
    generated (A ×ˢ B) = generated A ×ˢ generated B := by
  apply Set.Subset.antisymm
  · apply generated_subset (Set.prod_mono (subset_generated A) (subset_generated B))
    intro E hE hne hdir x hx
    have hp := isLUB_prod.mp hx
    exact ⟨generated_closed A (by rintro _ ⟨p, hp, rfl⟩; exact (hE hp).1)
      (hne.image _) hdir.fst hp.1,
      generated_closed B (by rintro _ ⟨p, hp, rfl⟩; exact (hE hp).2)
      (hne.image _) hdir.snd hp.2⟩
  · rintro ⟨p,q⟩ ⟨hp,hq⟩
    have hleft (y : Q) (hy : y ∈ B) : (p,y) ∈ generated (A ×ˢ B) :=
      generated_subset (B := (fun x => (x,y)) ⁻¹' generated (A ×ˢ B))
        (fun x hx => subset_generated _ ⟨hx,hy⟩)
        (subDcpo_preimage (ScottContinuous.id.prodMk (ScottContinuous.const y))
          (generated_closed _)) hp
    exact generated_subset (B := (fun y => (p,y)) ⁻¹' generated (A ×ˢ B)) hleft
      (subDcpo_preimage ((ScottContinuous.const p).prodMk ScottContinuous.id) (generated_closed _)) hq

abbrev ScottHom (P Q : Type*) [Preorder P] [Preorder Q] :=
  {f : P → Q // @Continuous P Q (scott P) (scott Q) f}

def ScottHom.ofScott {P Q : Type*} [Preorder P] [Preorder Q]
    (f : P → Q) (hf : ScottContinuous f) : ScottHom P Q := ⟨f, scott_iff_continuous.mp hf⟩

theorem ScottHom.isScott {P Q : Type*} [Preorder P] [Preorder Q]
    (f : ScottHom P Q) : ScottContinuous f.val := scott_iff_continuous.mpr f.property

theorem scottHom_lub {P Q : Type*} [PartialOrder P] [PartialOrder Q] [IsDCPO Q]
    (A : Set (ScottHom P Q)) (hne : A.Nonempty) (hd : DirectedOn (· ≤ ·) A) :
    ∃ f : ScottHom P Q, IsLUB A f ∧ ∀ p, IsLUB ((fun g : ScottHom P Q => g.val p) '' A) (f.val p) := by
  classical
  have H (p : P) : ∃ q, IsLUB ((fun g : ScottHom P Q => g.val p) '' A) q :=
    IsDCPO.lub _ (hne.image _) (directedOn_image.mpr (hd.mono (fun _ _ h => h p)))
  choose f hf using H
  have hc : ScottContinuous f := by
    intro D hD hdir d hL
    constructor
    · rintro _ ⟨x,hx,rfl⟩
      apply (hf x).2
      rintro _ ⟨g,hg,rfl⟩
      exact (g.isScott.monotone (hL.1 hx)).trans ((hf d).1 ⟨g,hg,rfl⟩)
    · intro b hb
      apply (hf d).2
      rintro _ ⟨g,hg,rfl⟩
      apply (g.isScott hD hdir hL).2
      rintro _ ⟨x,hx,rfl⟩
      exact ((hf x).1 ⟨g,hg,rfl⟩).trans (hb ⟨x,hx,rfl⟩)
  refine ⟨ScottHom.ofScott f hc, ⟨?_, ?_⟩, hf⟩
  · intro g hg p
    exact (hf p).1 ⟨g,hg,rfl⟩
  · intro g hg p
    apply (hf p).2
    rintro _ ⟨h,hh,rfl⟩
    exact hg hh p

instance (P Q : Type*) [PartialOrder P] [PartialOrder Q] [IsDCPO Q] :
    IsDCPO (ScottHom P Q) where
  lub A hne hd := by
    obtain ⟨f,hf,_⟩ := scottHom_lub A hne hd
    exact ⟨f,hf⟩

theorem scott_eval {P Q : Type*} [PartialOrder P] [PartialOrder Q] [IsDCPO Q] :
    ScottContinuous (fun p : ScottHom P Q × P => p.1.val p.2) := by
  apply ScottContinuous.fromProd (fun f => f.isScott)
  intro p D hne hd a ha
  obtain ⟨f,hf,hpoint⟩ := scottHom_lub D hne hd
  rw [ha.unique hf]
  exact hpoint p

def scottCurry {P Q R : Type*} [PartialOrder P] [PartialOrder Q] [PartialOrder R]
    (f : ScottHom (P × Q) R) (p : P) : ScottHom Q R :=
  ScottHom.ofScott _ (((ScottContinuous.const p).prodMk ScottContinuous.id).comp f.isScott)

theorem scott_curry {P Q R : Type*} [PartialOrder P] [PartialOrder Q] [PartialOrder R]
    (f : ScottHom (P × Q) R) : ScottContinuous (scottCurry f) := by
  intro A hne hdir p hp
  have hpoint (q : Q) : IsLUB ((fun x : P => f.val (x,q)) '' A) (f.val (p,q)) :=
    ((ScottContinuous.id.prodMk (ScottContinuous.const q)).comp f.isScott) hne hdir hp
  constructor
  · rintro _ ⟨x,hx,rfl⟩ q
    exact (hpoint q).1 ⟨x,hx,rfl⟩
  · intro g hg q
    apply (hpoint q).2
    rintro _ ⟨x,hx,rfl⟩
    exact hg ⟨x,hx,rfl⟩ q

end ScottDCompletable
