import ScottDCompletable.CategoricalLimits
import ScottDCompletable.Compatibility
import Mathlib.CategoryTheory.Functor.FullyFaithful

/-! Categorical finite-limit preservation of the Scott-topology functor. -/

noncomputable section

open CategoryTheory CategoryTheory.Limits
universe u

namespace ScottDCompletable

/-- The category whose objects are dcpos and arrows are Scott-continuous maps. -/
structure DcpoObject where
  Carrier : Type u
  order : PartialOrder Carrier
  dcpo : @IsDCPO Carrier order

instance (P : DcpoObject) : PartialOrder P.Carrier := P.order
instance (P : DcpoObject) : IsDCPO P.Carrier := P.dcpo

abbrev dcpoObject (P : Type u) [PartialOrder P] [IsDCPO P] : DcpoObject.{u} :=
  ⟨P, inferInstance, inferInstance⟩

instance : Category.{u} DcpoObject.{u} where
  Hom P Q := ScottHom P.Carrier Q.Carrier
  id _ := ScottHom.ofScott id ScottContinuous.id
  comp f g := ScottHom.ofScott _ (f.isScott.comp g.isScott)
  id_comp _ := rfl
  comp_id _ := rfl
  assoc _ _ _ := rfl

/-- The Scott-topology functor on exactly the Scott-continuous functions. -/
def sigmaFunctor {C : SpaceClass.{u}} (hScott : ContainsScott C) : DcpoObject.{u} ⥤ FullSpace C where
  obj P := ⟨scottSpace P.Carrier, hScott P.Carrier⟩
  map f := f
  map_id _ := rfl
  map_comp _ _ := rfl

/-- Full faithfulness uses the identical continuous function on both sides. -/
def sigmaFullyFaithful {C : SpaceClass.{u}} (hScott : ContainsScott C) :
    (sigmaFunctor hScott).FullyFaithful where
  preimage f := f
  map_preimage _ := rfl
  preimage_map _ := rfl

abbrev dcpoTerminal : DcpoObject.{u} := dcpoObject PUnit.{u+1}

def dcpoTerminalIsTerminal : IsTerminal dcpoTerminal.{u} := by
  refine IsTerminal.ofUniqueHom (fun P => ?_) ?_
  · exact ScottHom.ofScott (fun _ : P.Carrier => PUnit.unit) (ScottContinuous.const _)
  · intro P f
    apply Subtype.ext
    funext x
    exact @Subsingleton.elim PUnit.{u+1} inferInstance _ _

instance : HasTerminal DcpoObject.{u} := dcpoTerminalIsTerminal.hasTerminal

abbrev dcpoProduct (P Q : DcpoObject.{u}) : DcpoObject.{u} := dcpoObject (P.Carrier × Q.Carrier)

def dcpoProductFst (P Q : DcpoObject.{u}) : dcpoProduct P Q ⟶ P :=
  ScottHom.ofScott Prod.fst ScottContinuous.fst

def dcpoProductSnd (P Q : DcpoObject.{u}) : dcpoProduct P Q ⟶ Q :=
  ScottHom.ofScott Prod.snd ScottContinuous.snd

def dcpoBinaryFan (P Q : DcpoObject.{u}) : BinaryFan P Q :=
  BinaryFan.mk (dcpoProductFst P Q) (dcpoProductSnd P Q)

def dcpoBinaryFanIsLimit (P Q : DcpoObject.{u}) : IsLimit (dcpoBinaryFan P Q) := by
  refine BinaryFan.IsLimit.mk _ (fun {_} f g =>
    ScottHom.ofScott _ (f.isScott.prodMk g.isScott)) (fun _ _ => rfl) (fun _ _ => rfl) ?_
  intro R f g m hf hg
  apply Subtype.ext
  funext x
  exact Prod.ext (congrFun (congrArg Subtype.val hf) x) (congrFun (congrArg Subtype.val hg) x)

instance : HasBinaryProducts DcpoObject.{u} := by
  letI {P Q : DcpoObject.{u}} : HasLimit (pair P Q) := HasLimit.mk ⟨_,dcpoBinaryFanIsLimit P Q⟩
  exact hasBinaryProducts_of_hasLimit_pair DcpoObject.{u}

abbrev dcpoEqualizer {P Q : DcpoObject.{u}} (f g : P ⟶ Q) : DcpoObject.{u} :=
  @dcpoObject (scottEqualizerSet f g) inferInstance (scottEqualizer_dcpo f g)

def dcpoEqualizerInclusion {P Q : DcpoObject.{u}} (f g : P ⟶ Q) : dcpoEqualizer f g ⟶ P :=
  ScottHom.ofScott Subtype.val (scottEqualizer_inclusion f g)

theorem dcpoEqualizerCondition {P Q : DcpoObject.{u}} (f g : P ⟶ Q) :
    dcpoEqualizerInclusion f g ≫ f = dcpoEqualizerInclusion f g ≫ g := by
  apply Subtype.ext
  funext x
  exact x.property

def dcpoEqualizerFork {P Q : DcpoObject.{u}} (f g : P ⟶ Q) : Fork f g :=
  Fork.ofι (dcpoEqualizerInclusion f g) (dcpoEqualizerCondition f g)

def dcpoEqualizerForkIsLimit {P Q : DcpoObject.{u}} (f g : P ⟶ Q) :
    IsLimit (dcpoEqualizerFork f g) := by
  apply Fork.IsLimit.mk'
  intro s
  have he : ∀ x, f.val (s.ι.val x) = g.val (s.ι.val x) :=
    congrFun (congrArg Subtype.val s.condition)
  refine ⟨ScottHom.ofScott (fun x => ⟨s.ι.val x, he x⟩) (scott_corestrict s.ι.isScott he), rfl, ?_⟩
  intro m hm
  apply Subtype.ext
  funext x
  exact Subtype.ext (congrFun (congrArg Subtype.val hm) x)

instance : HasEqualizers DcpoObject.{u} := by
  letI {P Q : DcpoObject.{u}} (f g : P ⟶ Q) : HasLimit (parallelPair f g) :=
    HasLimit.mk ⟨_,dcpoEqualizerForkIsLimit f g⟩
  exact hasEqualizers_of_hasLimit_parallelPair DcpoObject.{u}

theorem dcpo_hasFiniteLimits : HasFiniteLimits DcpoObject.{u} := by
  letI := hasFiniteProducts_of_has_binary_and_terminal (C := DcpoObject.{u})
  exact hasFiniteLimits_of_hasEqualizers_and_finite_products

variable {C : SpaceClass.{u}} (hScott : ContainsScott C)

private theorem sigma_preserves_terminal :
    PreservesLimit (Functor.empty.{0} DcpoObject.{u}) (sigmaFunctor hScott) := by
  apply preservesLimit_of_preserves_limit_cone dcpoTerminalIsTerminal
  refine (isLimitMapConeEmptyConeEquiv (sigmaFunctor hScott) dcpoTerminal).symm ?_
  refine IsTerminal.ofUniqueHom (fun X => ?_) ?_
  · exact ⟨fun _ => PUnit.unit, @continuous_const X.val.Carrier PUnit.{u+1}
      X.val.topology (scott PUnit.{u+1}) PUnit.unit⟩
  · intro X f
    apply Subtype.ext
    funext x
    exact @Subsingleton.elim PUnit.{u+1} inferInstance _ _

private theorem sigma_preserves_pair (H : ScottFiniteLimitPresentation C) (P Q : DcpoObject.{u}) :
    PreservesLimit (pair P Q) (sigmaFunctor hScott) := by
  obtain ⟨_, ⟨p, hp⟩⟩ := H.products P.Carrier Q.Carrier
  apply preservesLimit_of_preserves_limit_cone (dcpoBinaryFanIsLimit P Q)
  refine (isLimitMapConeBinaryFanEquiv (sigmaFunctor hScott) (dcpoProductFst P Q) (dcpoProductSnd P Q)).symm ?_
  let lift {Z : FullSpace C} (f : Z ⟶ (sigmaFunctor hScott).obj P)
      (g : Z ⟶ (sigmaFunctor hScott).obj Q) : Z ⟶ (sigmaFunctor hScott).obj (dcpoProduct P Q) :=
    ⟨fun z => (f.val z,g.val z), by
      change @Continuous _ _ Z.val.topology (scott (P.Carrier × Q.Carrier)) _
      rw [← hp]
      exact p.pair_continuous Z.val Z.property f g⟩
  refine BinaryFan.IsLimit.mk _ lift (fun _ _ => rfl) (fun _ _ => rfl) ?_
  intro Z f g m hf hg
  apply Subtype.ext
  funext z
  exact Prod.ext (congrFun (congrArg Subtype.val hf) z) (congrFun (congrArg Subtype.val hg) z)

private theorem sigma_preserves_parallelPair (H : PreservesScottEqualizers C)
    {P Q : DcpoObject.{u}} (f g : P ⟶ Q) : PreservesLimit (parallelPair f g) (sigmaFunctor hScott) := by
  apply preservesLimit_of_preserves_limit_cone (dcpoEqualizerForkIsLimit f g)
  refine (isLimitMapConeForkEquiv (sigmaFunctor hScott) (dcpoEqualizerCondition f g)).symm ?_
  apply Fork.IsLimit.mk'
  intro s
  have he : ∀ x, f.val (s.ι.val x) = g.val (s.ι.val x) :=
    congrFun (congrArg Subtype.val s.condition)
  have hex := ((H P.Carrier Q.Carrier f g).2 s.pt.val s.pt.property s.ι he).exists
  let l := hex.choose
  have hl := hex.choose_spec
  refine ⟨l, Subtype.ext (funext hl), ?_⟩
  intro m hm
  apply Subtype.ext
  funext x
  exact Subtype.ext ((congrFun (congrArg Subtype.val hm) x).trans (hl x).symm)

theorem sigma_preserves_equalizers (H : PreservesScottEqualizers C) :
    PreservesLimitsOfShape WalkingParallelPair (sigmaFunctor hScott) := by
  refine ⟨fun {F} => ?_⟩
  letI := sigma_preserves_parallelPair hScott H (F.map WalkingParallelPairHom.left)
    (F.map WalkingParallelPairHom.right)
  exact preservesLimit_of_iso_diagram (sigmaFunctor hScott) (diagramIsoParallelPair F).symm

/-- The exact Scott equalizer presentation is equivalent to preservation of
all equalizers by the Scott-topology functor. -/
theorem preservesScottEqualizers_iff_categorical :
    PreservesScottEqualizers C ↔ PreservesLimitsOfShape WalkingParallelPair (sigmaFunctor hScott) := by
  refine ⟨sigma_preserves_equalizers hScott, ?_⟩
  intro H P Q _ _ _ _ a b
  let F := sigmaFunctor hScott
  let P' := dcpoObject P
  let Q' := dcpoObject Q
  let f : P' ⟶ Q' := a
  let g : P' ⟶ Q' := b
  letI : PreservesLimitsOfShape WalkingParallelPair F := H
  let I := isLimitForkMapOfIsLimit F (dcpoEqualizerCondition f g) (dcpoEqualizerForkIsLimit f g)
  letI : IsDCPO (scottEqualizerSet a b) := scottEqualizer_dcpo a b
  refine ⟨hScott _, ?_⟩
  intro X hX l hl
  let W : FullSpace C := ⟨X,hX⟩
  let l' : W ⟶ F.obj P' := l
  have w : l' ≫ F.map f = l' ≫ F.map g := Subtype.ext (funext hl)
  let s := Fork.ofι l' w
  let k := I.lift s
  have hk : ∀ x, (k.val x).val = l.val x :=
    congrFun (congrArg Subtype.val (Fork.IsLimit.lift_ι I (t := s)))
  refine ⟨k, hk, ?_⟩
  intro m hm
  apply Subtype.ext
  funext x
  exact Subtype.ext ((hm x).trans (hk x).symm)

/-- Preservation of arbitrary finite diagrams from the exact terminal,
product and equalizer constructions. -/
theorem sigma_preserves_finite_limits_of_generators (H : ScottFiniteLimitPresentation C) :
    PreservesFiniteLimits (sigmaFunctor hScott) := by
  letI := hasFiniteProducts_of_has_binary_and_terminal (C := DcpoObject.{u})
  letI : PreservesLimit (Functor.empty.{0} DcpoObject.{u}) (sigmaFunctor hScott) :=
    sigma_preserves_terminal hScott
  letI : PreservesLimitsOfShape (Discrete.{0} PEmpty) (sigmaFunctor hScott) :=
    preservesLimitsOfShape_pempty_of_preservesTerminal (sigmaFunctor hScott)
  letI : PreservesLimitsOfShape (Discrete WalkingPair) (sigmaFunctor hScott) :=
    ⟨fun {F} => by
      letI := sigma_preserves_pair hScott H (F.obj ⟨WalkingPair.left⟩) (F.obj ⟨WalkingPair.right⟩)
      exact preservesLimit_of_iso_diagram (sigmaFunctor hScott) (diagramIsoPair F).symm⟩
  letI : PreservesLimitsOfShape WalkingParallelPair (sigmaFunctor hScott) :=
    sigma_preserves_equalizers hScott H.equalizers
  letI : PreservesFiniteProducts (sigmaFunctor hScott) := .of_preserves_binary_and_terminal _
  exact preservesFiniteLimits_of_preservesEqualizers_and_finiteProducts _

/-- The finite-limit conclusion of the compatibility theorem. -/
theorem sigma_preserves_finite_limits (hSDC : ∀ X, C X → SDCSpace X) :
    PreservesFiniteLimits (sigmaFunctor hScott) :=
  sigma_preserves_finite_limits_of_generators hScott (scott_finite_limit_generators hScott hSDC)

end ScottDCompletable
