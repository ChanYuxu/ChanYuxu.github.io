import ScottDCompletable.Completion
import Mathlib.Topology.ContinuousMap.Basic
import Mathlib.Topology.Maps.Basic

noncomputable section
open Set Topology
open scoped Topology
universe u v

namespace ScottDCompletable

variable {X Y Z W : Type u} [TopologicalSpace X] [TopologicalSpace Y]
  [TopologicalSpace Z] [TopologicalSpace W]

instance scottCompletion_carrier_topology (C : ScottCompletion X) : TopologicalSpace C.Carrier :=
  scott C.Carrier

def ScottCompletion.extend {D : Type v} [PartialOrder D] [IsDCPO D]
    (C : ScottCompletion X) (f : X → D)
    (hf : @Continuous X D _ (scott D) f) : ScottHom C.Carrier D :=
  let g := (C.existsUnique_extension f hf).exists
  ScottHom.ofScott (Classical.choose g) (Classical.choose_spec g).1

theorem ScottCompletion.extend_unit {D : Type v} [PartialOrder D] [IsDCPO D]
    (C : ScottCompletion X) (f : X → D) (hf : @Continuous X D _ (scott D) f) (x : X) :
    (C.extend f hf).val (C.unit x) = f x :=
  (Classical.choose_spec (C.existsUnique_extension f hf).exists).2 x

theorem ScottCompletion.extension_unique {D : Type v} [PartialOrder D] [IsDCPO D]
    (C : ScottCompletion X) (f : X → D) (hf : @Continuous X D _ (scott D) f)
    (g : ScottHom C.Carrier D) (hg : ∀ x, g.val (C.unit x) = f x) :
    g = C.extend f hf := by
  apply Subtype.ext
  exact (C.existsUnique_extension f hf).unique ⟨g.isScott, hg⟩
    ⟨(C.extend f hf).isScott, C.extend_unit f hf⟩

def extension (CX : ScottCompletion X) (CY : ScottCompletion Y) (f : C(X, Y)) :
    ScottHom CX.Carrier CY.Carrier :=
  CX.extend (CY.unit ∘ f) (CY.embedding.continuous.comp f.continuous)

@[simp] theorem extension_unit (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f : C(X, Y)) (x : X) : (extension CX CY f).val (CX.unit x) = CY.unit (f x) :=
  CX.extend_unit _ _ x

theorem extension_id (CX : ScottCompletion X) :
    extension CX CX (ContinuousMap.id X) = ScottHom.ofScott id ScottContinuous.id := by
  unfold extension
  symm
  apply CX.extension_unique
  intro x
  rfl

theorem extension_comp (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (CZ : ScottCompletion Z) (f : C(X,Y)) (g : C(Y,Z)) :
    extension CX CZ (g.comp f) =
      ScottHom.ofScott _ ((extension CX CY f).isScott.comp (extension CY CZ g).isScott) := by
  symm
  apply CX.extension_unique
  intro x
  change (extension CY CZ g).val ((extension CX CY f).val (CX.unit x)) = CZ.unit (g (f x))
  rw [extension_unit, extension_unit]

/-- The manuscript's product uses the Scott topology of the order product. -/
@[implicit_reducible] def productTopology (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    TopologicalSpace (X × Y) :=
  TopologicalSpace.induced (fun z : X × Y => (CX.unit z.1, CY.unit z.2))
    (scott (CX.Carrier × CY.Carrier))

def productCompletion (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    @ScottCompletion (X × Y) (productTopology CX CY) := by
  letI : TopologicalSpace (X × Y) := productTopology CX CY
  letI : TopologicalSpace (CX.Carrier × CY.Carrier) := scott _
  refine {
  Carrier := CX.Carrier × CY.Carrier
  order := inferInstance
  dcpo := inferInstance
  unit := fun z => (CX.unit z.1, CY.unit z.2)
  embedding := ⟨⟨rfl⟩, fun x y h => Prod.ext (CX.embedding.injective (congrArg Prod.fst h))
    (CY.embedding.injective (congrArg Prod.snd h))⟩
  dense := by
    have hr : Set.range (fun z : X × Y => (CX.unit z.1, CY.unit z.2)) =
        Set.range CX.unit ×ˢ Set.range CY.unit := by
      ext z
      constructor
      · rintro ⟨⟨x,y⟩, rfl⟩
        exact ⟨⟨x,rfl⟩,⟨y,rfl⟩⟩
      · rintro ⟨⟨x,hx⟩,⟨y,hy⟩⟩
        exact ⟨(x,y), Prod.ext hx hy⟩
    rw [hr, generated_prod, CX.dense, CY.dense]
    exact Set.univ_prod_univ }

theorem product_fst (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    @Continuous (X × Y) X (productTopology CX CY) _ Prod.fst := by
  letI : TopologicalSpace (X × Y) := productTopology CX CY
  letI : TopologicalSpace (CX.Carrier × CY.Carrier) := scott _
  apply CX.embedding.isInducing.continuous_iff.mpr
  exact (scott_iff_continuous.mp ScottContinuous.fst).comp (productCompletion CX CY).embedding.continuous

theorem product_snd (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    @Continuous (X × Y) Y (productTopology CX CY) _ Prod.snd := by
  letI : TopologicalSpace (X × Y) := productTopology CX CY
  letI : TopologicalSpace (CX.Carrier × CY.Carrier) := scott _
  apply CY.embedding.isInducing.continuous_iff.mpr
  exact (scott_iff_continuous.mp ScottContinuous.snd).comp (productCompletion CX CY).embedding.continuous

theorem product_pair (CZ : ScottCompletion Z) (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f : C(Z,X)) (g : C(Z,Y)) :
    @Continuous Z (X × Y) _ (productTopology CX CY) (fun z => (f z,g z)) := by
  letI : TopologicalSpace (CX.Carrier × CY.Carrier) := scott _
  apply continuous_induced_rng.mpr
  have hh := (scott_iff_continuous.mp
    ((extension CZ CX f).isScott.prodMk (extension CZ CY g).isScott)).comp CZ.embedding.continuous
  convert hh using 1
  funext z
  exact Prod.ext (extension_unit CZ CX f z).symm (extension_unit CZ CY g z).symm

theorem product_universal (CZ : ScottCompletion Z) (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f : C(Z,X)) (g : C(Z,Y)) :
    ∃! h : Z → X × Y, @Continuous Z (X × Y) _ (productTopology CX CY) h ∧
      (∀ z, (h z).1 = f z) ∧ (∀ z, (h z).2 = g z) := by
  refine ⟨fun z => (f z,g z), ⟨product_pair CZ CX CY f g, fun _ => rfl, fun _ => rfl⟩, ?_⟩
  intro h hh
  funext z
  exact Prod.ext (hh.2.1 z) (hh.2.2 z)

/-- The comparison to the ordinary product is induced by the two projections. -/
theorem product_comparison (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    @Continuous (X × Y) (X × Y) (productTopology CX CY) (@instTopologicalSpaceProd X Y _ _) id := by
  letI : TopologicalSpace (X × Y) := productTopology CX CY
  exact (product_fst CX CY).prodMk (product_snd CX CY)

abbrev extensionImage (CX : ScottCompletion X) (CY : ScottCompletion Y) :=
  Set.range (extension CX CY)

abbrev exponentialHull (CX : ScottCompletion X) (CY : ScottCompletion Y) :=
  generated (extensionImage CX CY)

instance hull_dcpo (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    IsDCPO (exponentialHull CX CY) := subDcpo_dcpo (generated_closed _)

def exponentialUnit (CX : ScottCompletion X) (CY : ScottCompletion Y) (f : C(X,Y)) :
    exponentialHull CX CY := ⟨extension CX CY f, subset_generated _ ⟨f,rfl⟩⟩

@[implicit_reducible] def exponentialTopology (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    TopologicalSpace C(X,Y) :=
  TopologicalSpace.induced (exponentialUnit CX CY) (scott (exponentialHull CX CY))

def exponentialCompletion (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    @ScottCompletion C(X,Y) (exponentialTopology CX CY) := by
  letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
  letI : TopologicalSpace (exponentialHull CX CY) := scott _
  refine {
  Carrier := exponentialHull CX CY
  order := inferInstance
  dcpo := inferInstance
  unit := exponentialUnit CX CY
  embedding := ⟨⟨rfl⟩, by
    intro f g h
    ext x
    apply CY.embedding.injective
    have he := congrArg (fun k : exponentialHull CX CY => k.val.val (CX.unit x)) h
    simpa only [exponentialUnit, extension_unit] using he⟩
  dense := generated_subtype _ _ (by ext p; simp [exponentialUnit]) }

@[implicit_reducible] def evaluationTopology (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    TopologicalSpace (C(X,Y) × X) := by
  letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
  exact productTopology (exponentialCompletion CX CY) CX

theorem exponential_evaluation (CX : ScottCompletion X) (CY : ScottCompletion Y) :
    @Continuous (C(X,Y) × X) Y (evaluationTopology CX CY) _
      (fun p => p.1 p.2) := by
  letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
  letI : TopologicalSpace (C(X,Y) × X) := productTopology (exponentialCompletion CX CY) CX
  letI : TopologicalSpace (exponentialHull CX CY × CX.Carrier) := scott _
  apply CY.embedding.isInducing.continuous_iff.mpr
  have he : ScottContinuous (fun p : exponentialHull CX CY × CX.Carrier => p.1.val.val p.2) :=
    ((subtype_scott (generated_closed (extensionImage CX CY))).prod ScottContinuous.id).comp scott_eval
  have hc := (scott_iff_continuous.mp he).comp
    (productCompletion (exponentialCompletion CX CY) CX).embedding.continuous
  convert hc using 1
  funext p
  exact (extension_unit CX CY p.1 p.2).symm

/-- The section is continuous by the product universal property. -/
def exponentialSection (CZ : ScottCompletion Z) (CX : ScottCompletion X) (z : Z) :
    @ContinuousMap X (Z × X) _ (productTopology CZ CX) := by
  letI : TopologicalSpace (Z × X) := productTopology CZ CX
  exact ⟨fun x => (z,x), product_pair CX CZ CX (ContinuousMap.const X z) (ContinuousMap.id X)⟩

def exponentialCurry (CZ : ScottCompletion Z) (CX : ScottCompletion X)
    (CY : ScottCompletion Y)
    (F : @ContinuousMap (Z × X) Y (productTopology CZ CX) _) :
    @ContinuousMap Z C(X,Y) _ (exponentialTopology CX CY) := by
  letI : TopologicalSpace (Z × X) := productTopology CZ CX
  letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
  refine ⟨fun z => F.comp (exponentialSection CZ CX z), ?_⟩
  apply continuous_induced_rng.mpr
  let Fd := extension (productCompletion CZ CX) CY F
  let Fhat := scottCurry Fd
  have hFhat : ScottContinuous Fhat := scott_curry Fd
  have hz (z : Z) : Fhat (CZ.unit z) = extension CX CY (F.comp (exponentialSection CZ CX z)) := by
    apply CX.extension_unique
    intro x
    exact extension_unit (productCompletion CZ CX) CY F (z,x)
  let M := Fhat ⁻¹' exponentialHull CX CY
  have hM : SubDcpo M := subDcpo_preimage hFhat (generated_closed _)
  have hU : Set.range CZ.unit ⊆ M := by
    rintro _ ⟨z,rfl⟩
    change Fhat (CZ.unit z) ∈ exponentialHull CX CY
    rw [hz]
    exact subset_generated _ ⟨_,rfl⟩
  have hAll : M = univ := generated_eq_of_superset CZ.dense hU hM
  have hmem (d : CZ.Carrier) : Fhat d ∈ exponentialHull CX CY := by
    change d ∈ M
    rw [hAll]
    exact Set.mem_univ _
  have hcore := scott_corestrict hFhat hmem
  letI : TopologicalSpace (exponentialHull CX CY) := scott _
  have hc := (scott_iff_continuous.mp hcore).comp CZ.embedding.continuous
  convert hc using 1
  funext z
  exact Subtype.ext (hz z).symm

def exponentialUncurry (CZ : ScottCompletion Z) (CX : ScottCompletion X)
    (CY : ScottCompletion Y) (g : @ContinuousMap Z C(X,Y) _ (exponentialTopology CX CY)) :
    @ContinuousMap (Z × X) Y (productTopology CZ CX) _ := by
  letI : TopologicalSpace (Z × X) := productTopology CZ CX
  letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
  letI : TopologicalSpace (C(X,Y) × X) := productTopology (exponentialCompletion CX CY) CX
  exact ⟨fun p => g p.1 p.2, (exponential_evaluation CX CY).comp
    (product_pair (productCompletion CZ CX) (exponentialCompletion CX CY) CX
      ⟨fun p => g p.1, g.continuous.comp (product_fst CZ CX)⟩ ⟨Prod.snd, product_snd CZ CX⟩)⟩

def exponential_bijection (CZ : ScottCompletion Z) (CX : ScottCompletion X)
    (CY : ScottCompletion Y) :
    @ContinuousMap (Z × X) Y (productTopology CZ CX) _ ≃
      @ContinuousMap Z C(X,Y) _ (exponentialTopology CX CY) := by
  letI : TopologicalSpace (Z × X) := productTopology CZ CX
  letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
  refine ⟨exponentialCurry CZ CX CY, exponentialUncurry CZ CX CY, ?_, ?_⟩
  · intro F; apply ContinuousMap.ext; rintro ⟨z,x⟩; rfl
  · intro g; apply ContinuousMap.ext; intro z; apply ContinuousMap.ext; intro x; rfl

theorem exponential_natural_pre (CW : ScottCompletion W) (CZ : ScottCompletion Z)
    (CX : ScottCompletion X) (CY : ScottCompletion Y) (f : C(W,Z))
    (F : @ContinuousMap (Z × X) Y (productTopology CZ CX) _) (w : W) (x : X) :
    letI : TopologicalSpace (W × X) := productTopology CW CX
    letI : TopologicalSpace (Z × X) := productTopology CZ CX
    letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
    exponentialCurry CW CX CY
      (F.comp ⟨fun p => (f p.1,p.2), product_pair (productCompletion CW CX) CZ CX
        ⟨fun p => f p.1,f.continuous.comp (product_fst CW CX)⟩ ⟨Prod.snd,product_snd CW CX⟩⟩) w x =
      exponentialCurry CZ CX CY F (f w) x := rfl

def exponentialPost (CX : ScottCompletion X) (CY : ScottCompletion Y) (CZ : ScottCompletion Z)
    (v : C(Y,Z)) : @ContinuousMap C(X,Y) C(X,Z) (exponentialTopology CX CY) (exponentialTopology CX CZ) := by
  letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
  letI : TopologicalSpace C(X,Z) := exponentialTopology CX CZ
  letI : TopologicalSpace (C(X,Y) × X) := productTopology (exponentialCompletion CX CY) CX
  exact exponentialCurry (exponentialCompletion CX CY) CX CZ
    ⟨fun p => v (p.1 p.2), v.continuous.comp (exponential_evaluation CX CY)⟩

theorem exponential_natural_post (CW : ScottCompletion W) (CX : ScottCompletion X)
    (CY : ScottCompletion Y) (CZ : ScottCompletion Z) (v : C(Y,Z))
    (F : @ContinuousMap (W × X) Y (productTopology CW CX) _) (w : W) (x : X) :
    letI : TopologicalSpace (W × X) := productTopology CW CX
    letI : TopologicalSpace C(X,Y) := exponentialTopology CX CY
    letI : TopologicalSpace C(X,Z) := exponentialTopology CX CZ
    exponentialCurry CW CX CZ (v.comp F) w x =
      exponentialPost CX CY CZ v (exponentialCurry CW CX CY F w) x := rfl

end ScottDCompletable
