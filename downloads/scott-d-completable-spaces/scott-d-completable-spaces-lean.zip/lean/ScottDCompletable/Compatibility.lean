import ScottDCompletable.Maximality
import ScottDCompletable.MixedExponential
import ScottDCompletable.EqualizerCompatibility

noncomputable section
open Set Topology
universe u
namespace ScottDCompletable

variable {C : SpaceClass.{u}}

/-- The terminal object, binary products and equalizers of Scott dcpos
retain their universal properties in the full class. -/
structure ScottFiniteLimitPresentation (C : SpaceClass.{u}) : Prop where
  terminal : C (scottSpace PUnit.{u+1}) ∧
    ∀ X, C X → ∃! _f : Cont X (scottSpace PUnit.{u+1}), True
  products : ∀ (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q],
    C (scottSpace (P × Q)) ∧
    (∃ p : ProductPresentation C (scottSpace P) (scottSpace Q),
      p.spaceTopology = scott (P × Q))
  equalizers : PreservesScottEqualizers C

theorem scott_finite_limit_generators (hScott : ContainsScott C)
    (hSDC : ∀ X, C X → SDCSpace X) : ScottFiniteLimitPresentation C := by
  constructor
  · refine ⟨hScott PUnit.{u+1}, ?_⟩
    intro X _
    letI : TopologicalSpace X.Carrier := X.topology
    letI : TopologicalSpace PUnit.{u+1} := scott _
    refine ⟨⟨fun _ => PUnit.unit, continuous_const⟩, trivial, ?_⟩
    intro f _
    apply Subtype.ext
    exact Subsingleton.elim _ _
  · intro P Q _ _ _ _
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    let CP := scottCompletion P
    let CQ := scottCompletion Q
    have hp := scott_product_topology P Q
    have hmem : C ⟨P × Q, productTopology CP CQ⟩ := by
      rw [hp]
      exact hScott (P × Q)
    refine ⟨hScott (P × Q), ⟨⟨productTopology CP CQ, hmem, product_fst CP CQ,
      product_snd CP CQ, ?_⟩, hp⟩⟩
    intro Z hZ f g
    letI : TopologicalSpace Z.Carrier := Z.topology
    exact product_pair (completionOf (hSDC Z hZ)) CP CQ f.toContinuousMap g.toContinuousMap
  · exact preservesScottEqualizers_of_subclass_sdc hScott (fun {X} => hSDC X)

/-- The mixed homeomorphism reduces to the identity for a Scott-space source. -/
theorem canonical_exponents_of_subclass_sdc (K : ClosedPresentation C) (hScott : ContainsScott C)
    (hSDC : ∀ X, C X → SDCSpace X) : CanonicalDcpoExponents K hScott := by
  intro P Q _ _ _ _
  letI : TopologicalSpace P := scott P
  obtain ⟨e, he⟩ := mixedExponential_homeomorph K hScott hSDC (hScott P) (scottCompletion P) Q
  let e' : ScottHom P Q ≃ ScottHom P Q :=
    @Homeomorph.toEquiv _ _ (K.exponents (hScott P) (hScott Q)).spaceTopology (scott _) e
  have hId : e'.toFun = id := by
    funext f
    apply Subtype.ext
    funext p
    change (e' f).val p = f.val p
    rw [show e' f = (scottCompletion P).extend f.val f.property from he f]
    exact (scottCompletion P).extend_unit f.val f.property p
  letI : TopologicalSpace (ScottHom P Q) := scott _
  unfold CanonicalDcpoExponent
  have hi : (K.exponents (hScott P) (hScott Q)).spaceTopology =
      TopologicalSpace.induced e'.toFun (scott (ScottHom P Q)) :=
    @IsInducing.eq_induced _ _ (K.exponents (hScott P) (hScott Q)).spaceTopology
      (scott (ScottHom P Q)) e'.toFun
      (@Homeomorph.isInducing _ _ (K.exponents (hScott P) (hScott Q)).spaceTopology
        (scott (ScottHom P Q)) e)
  rw [hId, induced_id] at hi
  exact hi

/-- The four equivalent conditions and their terminal/product/equalizer preservation consequence. -/
theorem compatibility_equivalence (K : ClosedPresentation C) (hScott : ContainsScott C) :
    ((∀ X, C X → SDCSpace X) ↔ CanonicalDcpoExponents K hScott) ∧
    (CanonicalDcpoExponents K hScott ↔ CanonicalSixExponents K hScott) ∧
    (CanonicalSixExponents K hScott ↔ PreservesScottEqualizers C) ∧
    ((∀ X, C X → SDCSpace X) → ScottFiniteLimitPresentation C) := by
  let h₁ := canonical_exponents_of_subclass_sdc K hScott
  let h₂ : CanonicalDcpoExponents K hScott → CanonicalSixExponents K hScott :=
    fun h R _ _ _ _ => h SixSource.{u} R
  let h₃ := exponent_maximality K hScott
  have h₄ : PreservesScottEqualizers C → ∀ X, C X → SDCSpace X := by
    intro h X hX
    exact subclass_sdc_of_preservesScottEqualizers h (fun {_} => K.t0) hX
  exact ⟨⟨h₁, fun h => h₃ (h₂ h)⟩, ⟨h₂, fun h => h₁ (h₃ h)⟩,
    ⟨fun h => (scott_finite_limit_generators hScott (h₃ h)).equalizers, fun h => h₂ (h₁ (h₄ h))⟩,
    scott_finite_limit_generators hScott⟩

/-- SDC itself meets the hypotheses, and contains every full class
with the canonical dcpo exponential property. -/
theorem largest_sdc :
    CanonicalDcpoExponents sdcClosedPresentation.{u} sdcContainsScott ∧
    ∀ (C : SpaceClass.{u}) (K : ClosedPresentation C) (hScott : ContainsScott C),
      CanonicalDcpoExponents K hScott → ∀ X, C X → SDCSpace X :=
  ⟨canonical_exponents_of_subclass_sdc _ _ (fun _ hX => hX),
    fun _ K hScott => maximality_of_canonical_exponents K hScott⟩

end ScottDCompletable
