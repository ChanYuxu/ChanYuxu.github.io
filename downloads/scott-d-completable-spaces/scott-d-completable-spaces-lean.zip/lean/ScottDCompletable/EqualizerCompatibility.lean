import ScottDCompletable.FiniteSource
import ScottDCompletable.CategoryPresentation
import ScottDCompletable.UpperEqualizer

/-! Intrinsic Scott equalizers and the two equalizer-compatibility implications. -/

noncomputable section

open Set
open scoped Topology
universe u v

namespace ScottDCompletable

variable {P Q : Type u} [PartialOrder P] [PartialOrder Q]

/-- The literal equalizer subset of the source dcpo. -/
def scottEqualizerSet (a b : ScottHom P Q) : Set P :=
  {p | a.val p = b.val p}

theorem scottEqualizer_subDcpo (a b : ScottHom P Q) :
    SubDcpo (scottEqualizerSet a b) := by
  intro D hD hne hdir p hp
  have heq : a.val '' D = b.val '' D := by
    ext y
    constructor
    · rintro ⟨x, hx, rfl⟩
      exact ⟨x, hx, (hD hx).symm⟩
    · rintro ⟨x, hx, rfl⟩
      exact ⟨x, hx, hD hx⟩
  have ha := a.isScott hne hdir hp
  rw [heq] at ha
  exact ha.unique (b.isScott hne hdir hp)

theorem scottEqualizer_dcpo [IsDCPO P] (a b : ScottHom P Q) :
    IsDCPO (scottEqualizerSet a b) := subDcpo_dcpo (scottEqualizer_subDcpo a b)

theorem scottEqualizer_inclusion [IsDCPO P] (a b : ScottHom P Q) :
    ScottContinuous (Subtype.val : scottEqualizerSet a b → P) :=
  subtype_scott (scottEqualizer_subDcpo a b)

/-- The dcpo equalizer universal property for the exact inclusion. -/
theorem scottEqualizer_universal (a b : ScottHom P Q)
    {D : Type v} [PartialOrder D] [IsDCPO D]
    (f : D → P) (hf : ScottContinuous f)
    (he : ∀ x, a.val (f x) = b.val (f x)) :
    ∃! k : D → scottEqualizerSet a b, ScottContinuous k ∧ ∀ x, (k x).val = f x := by
  let hm (x : D) : f x ∈ scottEqualizerSet a b := he x
  refine ⟨fun x => ⟨f x, hm x⟩, ⟨scott_corestrict hf hm, fun _ => rfl⟩, ?_⟩
  intro k hk
  funext x
  exact Subtype.ext (hk.2 x)

/-- The Scott-topology embedding preserves equalizers when the intrinsic
Scott equalizer is an object and its literal inclusion has the universal
property among all objects of the full class. -/
def PreservesScottEqualizers (C : SpaceClass.{u}) : Prop :=
  ∀ (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q]
    (a b : ScottHom P Q),
    C (scottSpace (scottEqualizerSet a b)) ∧
      ∀ (X : Space.{u}), C X → ∀ (f : Cont X (scottSpace P)),
        (∀ x, a.val (f.val x) = b.val (f.val x)) →
        ∃! k : Cont X (scottSpace (scottEqualizerSet a b)),
          ∀ x, (k.val x).val = f.val x

/-- Compatibility condition (iv) gives the upper-corestriction property
through the explicitly constructed pair of Boolean-valued coordinate maps. -/
theorem upperCorestrictions_of_preservesScottEqualizers {C : SpaceClass.{u}}
    (hC : PreservesScottEqualizers C) {X : Space.{u}} (hX : C X) :
    @UpperCorestrictions X.Carrier X.topology := by
  letI : TopologicalSpace X.Carrier := X.topology
  intro P _ _ A hA f hf hm
  let a := ScottHom.ofScott (upperEqualizerA A) (upperEqualizerA_scott A)
  let b := ScottHom.ofScott (upperEqualizerB A) (upperEqualizerB_scott A)
  let f' : Cont X (scottSpace P) := ⟨f,hf⟩
  have he (x : X.Carrier) : a.val (f'.val x) = b.val (f'.val x) :=
    (upperEqualizer_eq_iff hA (f x)).mpr (hm x)
  obtain ⟨k,hk⟩ := ((hC P (UpperEqualizerTarget A) a b).2 X hX f' he).exists
  exact upperCorestrict_of_equalizer_factor hA hm ⟨k.val,k.property,hk⟩

/-- The implication (iv) to (i) of the compatibility theorem. -/
theorem subclass_sdc_of_preservesScottEqualizers {C : SpaceClass.{u}}
    (hC : PreservesScottEqualizers C)
    (hT0 : ∀ {X : Space.{u}}, C X → @T0Space X.Carrier X.topology) :
    ∀ {X : Space.{u}}, C X → SDCSpace X := by
  intro X hX
  letI : TopologicalSpace X.Carrier := X.topology
  letI : T0Space X.Carrier := hT0 hX
  exact sdc_of_upperCorestrictions (upperCorestrictions_of_preservesScottEqualizers hC hX)

/-- Restrict the universal Scott equalizer to the full class of SDC objects. -/
theorem preservesScottEqualizers_of_subclass_sdc {C : SpaceClass.{u}}
    (hScott : ContainsScott C) (hSDC : ∀ {X : Space.{u}}, C X → SDCSpace X) :
    PreservesScottEqualizers C := by
  intro P Q _ _ _ _ a b
  let L := scottEqualizerSet a b
  letI : IsDCPO L := scottEqualizer_dcpo a b
  refine ⟨hScott L, ?_⟩
  intro X hX f he
  letI : TopologicalSpace X.Carrier := X.topology
  let hm (x : X.Carrier) : f.val x ∈ L := he x
  have hc : @Continuous X.Carrier L X.topology (scott L) (fun x => ⟨f.val x,hm x⟩) :=
    allCorestrictions_of_sdc (hSDC hX) P L (scottEqualizer_subDcpo a b) f.val f.property hm
  refine ⟨⟨fun x => ⟨f.val x,hm x⟩,hc⟩,fun _ => rfl,?_⟩
  intro k hk
  apply Subtype.ext
  funext x
  exact Subtype.ext (hk x)

end ScottDCompletable
