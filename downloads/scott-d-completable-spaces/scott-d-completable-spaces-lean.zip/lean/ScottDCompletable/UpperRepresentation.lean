import ScottDCompletable.Order
import Mathlib.Topology.Sets.Opens

/-! An upper Scott representation for the cited premise in Section 4,
lines 354–360. The construction realizes the opens by finite collections
of open neighborhoods. Its directed suprema have the union of their
neighborhood coordinates, even when the underlying point changes. -/

noncomputable section
open Set Topology TopologicalSpace
open scoped Topology

namespace ScottDCompletable

universe u

namespace UpperRepresentation
variable {M : Type u} [TopologicalSpace M]

def neighborhoodOpens (x : M) : Set (Opens M) := {U | x ∈ U}

structure Host (M : Type u) [TopologicalSpace M] where
  opens : Set (Opens M)
  point : M
  contained : opens ⊆ neighborhoodOpens point

theorem Host.ext {a b : Host M} (h₁ : a.opens = b.opens) (h₂ : a.point = b.point) :
    a = b := by
  cases a
  cases b
  cases h₁
  cases h₂
  rfl

def diagonal (x : M) : Host M := ⟨neighborhoodOpens x, x, Set.Subset.rfl⟩

def Host.IsDiagonal (p : Host M) : Prop := p.opens = neighborhoodOpens p.point

theorem eq_diagonal {p : Host M} (h : p.IsDiagonal) : p = diagonal p.point :=
  Host.ext h rfl

class IsSpecializationOrder (M : Type u) [TopologicalSpace M] [PartialOrder M] : Prop where
  specializes_iff_le : ∀ a b : M, Specializes b a ↔ a ≤ b

variable [PartialOrder M] [IsSpecializationOrder M]

theorem neighborhoodOpens_subset_iff (a b : M) :
    neighborhoodOpens a ⊆ neighborhoodOpens b ↔ a ≤ b := by
  rw [← IsSpecializationOrder.specializes_iff_le, specializes_iff_forall_open]
  constructor
  · intro h U hU ha
    exact h (show ⟨U, hU⟩ ∈ neighborhoodOpens a from ha)
  · intro h U hU
    exact h U U.isOpen hU

instance : PartialOrder (Host M) where
  le a b := a.opens ⊆ b.opens ∧ (a.point = b.point ∨ b.IsDiagonal)
  le_refl a := ⟨Set.Subset.rfl, Or.inl rfl⟩
  le_trans a b c hab hbc := by
    refine ⟨hab.1.trans hbc.1, ?_⟩
    rcases hbc.2 with hpoint | hdiag
    · rcases hab.2 with hpoint' | hdiag'
      · exact Or.inl (hpoint'.trans hpoint)
      · right
        refine Subset.antisymm c.contained ?_
        rw [← hpoint, ← hdiag']
        exact hbc.1
    · exact Or.inr hdiag
  le_antisymm a b hab hba := by
    refine Host.ext (Subset.antisymm hab.1 hba.1) ?_
    by_contra hne
    have ha : a.IsDiagonal := hba.2.resolve_left (Ne.symm hne)
    have hb : b.IsDiagonal := hab.2.resolve_left hne
    apply hne
    apply le_antisymm
    · apply (neighborhoodOpens_subset_iff _ _).mp
      rw [← ha, ← hb]
      exact hab.1
    · apply (neighborhoodOpens_subset_iff _ _).mp
      rw [← ha, ← hb]
      exact hba.1

theorem diagonal_le_diagonal (a b : M) : diagonal a ≤ diagonal b ↔ a ≤ b := by
  rw [← neighborhoodOpens_subset_iff a b]
  exact ⟨fun h => h.1, fun h => ⟨h, Or.inr rfl⟩⟩

theorem above_diagonal {a : M} {p : Host M} (h : diagonal a ≤ p) : p.IsDiagonal := by
  rcases h.2 with heq | hdiag
  · refine Subset.antisymm p.contained ?_
    change a = p.point at heq
    rw [← heq]
    exact h.1
  · exact hdiag

theorem diagonal_image_upper : IsUpperSet (Set.range (diagonal : M → Host M)) := by
  rintro _ p h ⟨a, rfl⟩
  exact ⟨p.point, (eq_diagonal (above_diagonal h)).symm⟩

/-- The diagonal reflects the specialization order and preserves all
existing nonempty directed suprema. -/
theorem diagonal_scottContinuous : ScottContinuous (diagonal : M → Host M) := by
  intro S hne _ s hs
  constructor
  · rintro _ ⟨a, ha, rfl⟩
    exact (diagonal_le_diagonal a s).mpr (hs.1 ha)
  · intro p hp
    obtain ⟨a, ha⟩ := hne
    have hpEq := eq_diagonal (above_diagonal (hp ⟨a, ha, rfl⟩))
    have hsp : s ≤ p.point := by
      apply hs.2
      intro x hx
      apply (diagonal_le_diagonal x p.point).mp
      rw [← hpEq]
      exact hp ⟨x, hx, rfl⟩
    calc
      diagonal s ≤ diagonal p.point := (diagonal_le_diagonal _ _).mpr hsp
      _ = p := hpEq.symm

def opensUnion (S : Set (Host M)) : Set (Opens M) :=
  {U | ∃ p ∈ S, U ∈ p.opens}

/-- Cofinal diagonal points reduce one supremum case to the specialization
dcpo of M. In the other case all points lie in the same fiber. -/
theorem directed_has_lub [IsDCPO M] (hopen : scott M ≤ ‹TopologicalSpace M›)
    (S : Set (Host M)) (hne : S.Nonempty) (hd : DirectedOn (· ≤ ·) S) :
    ∃ p, IsLUB S p ∧ p.opens = opensUnion S := by
  classical
  by_cases hdiag : ∃ x : M, diagonal x ∈ S
  · have cofinal : ∀ p ∈ S, ∃ x : M, diagonal x ∈ S ∧ p ≤ diagonal x := by
      intro p hp
      obtain ⟨a, ha⟩ := hdiag
      obtain ⟨q, hq, hpq, haq⟩ := hd p hp (diagonal a) ha
      have hqeq := eq_diagonal (above_diagonal haq)
      refine ⟨q.point, ?_, ?_⟩
      · rw [← hqeq]
        exact hq
      · rw [← hqeq]
        exact hpq
    let T : Set M := {x | diagonal x ∈ S}
    have hT : T.Nonempty := hdiag
    have hdT : DirectedOn (· ≤ ·) T := by
      intro x hx y hy
      obtain ⟨q, hq, hxq, hyq⟩ := hd (diagonal x) hx (diagonal y) hy
      obtain ⟨z, hz, hqz⟩ := cofinal q hq
      exact ⟨z, hz, (diagonal_le_diagonal x z).mp (hxq.trans hqz),
        (diagonal_le_diagonal y z).mp (hyq.trans hqz)⟩
    obtain ⟨s, hs⟩ := IsDCPO.lub T hT hdT
    refine ⟨diagonal s, ⟨?_, ?_⟩, ?_⟩
    · intro p hp
      obtain ⟨a, ha, hpa⟩ := cofinal p hp
      exact hpa.trans ((diagonal_le_diagonal a s).mpr (hs.1 ha))
    · intro p hp
      obtain ⟨x, hx⟩ := hdiag
      have hpEq := eq_diagonal (above_diagonal (hp hx))
      have hsle : s ≤ p.point := by
        apply hs.2
        intro a ha
        apply (diagonal_le_diagonal a p.point).mp
        rw [← hpEq]
        exact hp ha
      calc
        diagonal s ≤ diagonal p.point := (diagonal_le_diagonal _ _).mpr hsle
        _ = p := hpEq.symm
    · ext U
      constructor
      · intro hU
        have hUscott : IsOpen[scott M] (U : Set M) := hopen _ U.isOpen
        obtain ⟨a, ha, haU⟩ :=
          ((scott_isOpen_iff (U : Set M)).mp hUscott).2 hT hdT hs hU
        exact ⟨diagonal a, ha, haU⟩
      · rintro ⟨p, hp, hpU⟩
        obtain ⟨a, ha, hpa⟩ := cofinal p hp
        exact ((diagonal_le_diagonal a s).mpr (hs.1 ha)).1 (hpa.1 hpU)
  · obtain ⟨a, ha⟩ := hne
    have samePoint : ∀ p ∈ S, p.point = a.point := by
      intro p hp
      obtain ⟨q, hq, hpq, haq⟩ := hd p hp a ha
      have hn : ¬ q.IsDiagonal := by
        intro h
        exact hdiag ⟨q.point, (eq_diagonal h) ▸ hq⟩
      exact (hpq.2.resolve_right hn).trans (haq.2.resolve_right hn).symm
    let q : Host M := ⟨opensUnion S, a.point, by
      rintro U ⟨p, hp, hpU⟩
      rw [← samePoint p hp]
      exact p.contained hpU⟩
    refine ⟨q, ⟨?_, ?_⟩, rfl⟩
    · intro p hp
      exact ⟨fun _ hpU => ⟨p, hp, hpU⟩, Or.inl (samePoint p hp)⟩
    · intro p hp
      refine ⟨?_, (hp ha).2⟩
      rintro U ⟨b, hb, hbU⟩
      exact (hp hb).1 hbU

@[implicit_reducible] def host_isDCPO [IsDCPO M] (hopen : scott M ≤ ‹TopologicalSpace M›) : IsDCPO (Host M) where
  lub S hne hd := by
    obtain ⟨p, hp, _⟩ := directed_has_lub hopen S hne hd
    exact ⟨p, hp⟩

def coordinate (U : Opens M) : Set (Host M) := {p | U ∈ p.opens}

theorem coordinate_scottOpen [IsDCPO M] (hopen : scott M ≤ ‹TopologicalSpace M›)
    (U : Opens M) : IsOpen[scott (Host M)] (coordinate U) := by
  refine (scott_isOpen_iff (coordinate U)).mpr ⟨fun _ _ hpq hp => hpq.1 hp, ?_⟩
  intro S hne hd q hq hqU
  obtain ⟨p, hp, heq⟩ := directed_has_lub hopen S hne hd
  have heqp := hq.unique hp
  subst q
  change U ∈ p.opens at hqU
  rw [heq] at hqU
  obtain ⟨q, hq, hqU⟩ := hqU
  exact ⟨q, hq, hqU⟩

def finiteApproximants (x : M) : Set (Host M) :=
  {p | p.point = x ∧ p.opens.Finite}

def emptyAt (x : M) : Host M := ⟨∅, x, Set.empty_subset _⟩

omit [PartialOrder M] [IsSpecializationOrder M] in
theorem emptyAt_mem (x : M) : emptyAt x ∈ finiteApproximants x :=
  ⟨rfl, Set.finite_empty⟩

theorem finiteApproximants_directed (x : M) :
    DirectedOn (· ≤ ·) (finiteApproximants x) := by
  intro p hp q hq
  change p.point = x ∧ p.opens.Finite at hp
  change q.point = x ∧ q.opens.Finite at hq
  let r : Host M := ⟨p.opens ∪ q.opens, x, by
    apply Set.union_subset
    · rw [← hp.1]; exact p.contained
    · rw [← hq.1]; exact q.contained⟩
  exact ⟨r, ⟨rfl, hp.2.union hq.2⟩,
    ⟨Set.subset_union_left, Or.inl hp.1⟩, ⟨Set.subset_union_right, Or.inl hq.1⟩⟩

theorem finiteApproximants_lub (x : M) : IsLUB (finiteApproximants x) (diagonal x) := by
  constructor
  · intro p hp
    refine ⟨?_, Or.inr rfl⟩
    change p.opens ⊆ neighborhoodOpens x
    rw [← hp.1]
    exact p.contained
  · intro p hp
    refine ⟨?_, (hp (emptyAt_mem x)).2⟩
    intro U hU
    let q : Host M := ⟨{U}, x, Set.singleton_subset_iff.mpr hU⟩
    have hq : q ∈ finiteApproximants x := ⟨rfl, Set.finite_singleton U⟩
    exact (hp hq).1 (Set.mem_singleton U)

theorem diagonal_continuous : @Continuous M (Host M) _ (scott (Host M)) diagonal := by
  apply continuous_def.2
  intro U hU
  rw [isOpen_iff_mem_nhds]
  intro x hx
  obtain ⟨p, hp, hpU⟩ := ((scott_isOpen_iff U).mp hU).2
    ⟨emptyAt x, emptyAt_mem x⟩ (finiteApproximants_directed x)
    (finiteApproximants_lub x) hx
  let V : Set M := ⋂ O ∈ p.opens, (O : Set M)
  have hV : IsOpen V := hp.2.isOpen_biInter fun O _ => O.isOpen
  refine mem_nhds_iff.mpr ⟨V, ?_, hV, ?_⟩
  · intro y hy
    apply ((scott_isOpen_iff U).mp hU).1 _ hpU
    exact ⟨fun O hO => Set.mem_iInter.mp (Set.mem_iInter.mp hy O) hO, Or.inr rfl⟩
  · exact Set.mem_iInter.mpr fun O => Set.mem_iInter.mpr fun hO =>
      hp.1 ▸ p.contained hO

theorem diagonal_embedding [IsDCPO M] (hopen : scott M ≤ ‹TopologicalSpace M›) :
    @IsEmbedding M (Host M) _ (scott (Host M)) diagonal := by
  letI : TopologicalSpace (Host M) := scott (Host M)
  refine ⟨⟨le_antisymm ?_ ?_⟩, fun _ _ h => congrArg Host.point h⟩
  · rintro U ⟨V, hV, rfl⟩
    exact continuous_def.mp diagonal_continuous _ hV
  · intro U hU
    exact ⟨coordinate ⟨U, hU⟩, coordinate_scottOpen hopen ⟨U, hU⟩, rfl⟩

end UpperRepresentation

/-- An upper Scott representation of a space with its specialization dcpo
and a topology contained in the intrinsic Scott topology. -/
theorem exists_upper_scott_embedding {M : Type u} [TopologicalSpace M]
    [PartialOrder M] [IsDCPO M]
    (horder : ∀ a b : M, Specializes b a ↔ a ≤ b)
    (hopen : scott M ≤ ‹TopologicalSpace M›) :
    ∃ (Q : Type u) (o : PartialOrder Q) (_ : @IsDCPO Q o) (f : M → Q),
      @IsEmbedding M Q _ (@scott Q o.toPreorder) f ∧
        @IsUpperSet Q o.toLE (Set.range f) := by
  letI : UpperRepresentation.IsSpecializationOrder M := ⟨horder⟩
  exact ⟨UpperRepresentation.Host M, inferInstance,
    UpperRepresentation.host_isDCPO hopen, UpperRepresentation.diagonal,
    UpperRepresentation.diagonal_embedding hopen, UpperRepresentation.diagonal_image_upper⟩

end ScottDCompletable
