import ScottDCompletable.Constructions

noncomputable section
open Set Topology
open scoped Topology
universe u

namespace ScottDCompletable

variable {X Y Z : Type u} [TopologicalSpace X] [TopologicalSpace Y] [TopologicalSpace Z]

def equalizerPoints (f g : C(X,Y)) : Set X := {x | f x = g x}

def equalizerAmbient (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) : Set CX.Carrier :=
  {d | (extension CX CY f).val d = (extension CX CY g).val d}

theorem equalizerAmbient_closed (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) : SubDcpo (equalizerAmbient CX CY f g) := by
  intro A hA hne hdir s hs
  have h₁ := (extension CX CY f).isScott hne hdir hs
  have h₂ := (extension CX CY g).isScott hne hdir hs
  have he : (extension CX CY f).val '' A = (extension CX CY g).val '' A :=
    Set.image_congr (fun _ hx => hA hx)
  rw [he] at h₁
  exact h₁.unique h₂

instance equalizerAmbient_dcpo (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) : IsDCPO (equalizerAmbient CX CY f g) :=
  subDcpo_dcpo (equalizerAmbient_closed CX CY f g)

def equalizerIntoAmbient (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) (x : equalizerPoints f g) : equalizerAmbient CX CY f g :=
  ⟨CX.unit x.val, by
    change (extension CX CY f).val (CX.unit x.val) = (extension CX CY g).val (CX.unit x.val)
    rw [extension_unit, extension_unit]
    exact congrArg CY.unit x.property⟩

abbrev equalizerHull (CX : ScottCompletion X) (CY : ScottCompletion Y) (f g : C(X,Y)) :=
  generated (Set.range (equalizerIntoAmbient CX CY f g))

instance equalizerHull_dcpo (CX : ScottCompletion X) (CY : ScottCompletion Y) (f g : C(X,Y)) :
    IsDCPO (equalizerHull CX CY f g) := subDcpo_dcpo (generated_closed _)

def equalizerUnit (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) (x : equalizerPoints f g) : equalizerHull CX CY f g :=
  ⟨equalizerIntoAmbient CX CY f g x, subset_generated _ ⟨x,rfl⟩⟩

@[implicit_reducible] def equalizerTopology (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) : TopologicalSpace (equalizerPoints f g) :=
  TopologicalSpace.induced (equalizerUnit CX CY f g) (scott (equalizerHull CX CY f g))

def equalizerCompletion (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) : @ScottCompletion (equalizerPoints f g) (equalizerTopology CX CY f g) := by
  letI : TopologicalSpace (equalizerPoints f g) := equalizerTopology CX CY f g
  letI : TopologicalSpace (equalizerHull CX CY f g) := scott _
  refine {
  Carrier := equalizerHull CX CY f g
  order := inferInstance
  dcpo := inferInstance
  unit := equalizerUnit CX CY f g
  embedding := ⟨⟨rfl⟩, by
    intro x y h
    apply Subtype.ext
    exact CX.embedding.injective (congrArg (fun k : equalizerHull CX CY f g => k.val.val) h)⟩
  dense := generated_subtype _ _ (by
    ext p
    constructor
    · rintro ⟨_, ⟨x,rfl⟩,rfl⟩
      exact ⟨x,rfl⟩
    · rintro ⟨x,rfl⟩
      exact ⟨equalizerUnit CX CY f g x,⟨x,rfl⟩,rfl⟩) }

theorem equalizer_inclusion (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) : @Continuous (equalizerPoints f g) X (equalizerTopology CX CY f g) _ Subtype.val := by
  letI : TopologicalSpace (equalizerPoints f g) := equalizerTopology CX CY f g
  letI : TopologicalSpace (equalizerHull CX CY f g) := scott _
  apply CX.embedding.isInducing.continuous_iff.mpr
  have hs : ScottContinuous (fun k : equalizerHull CX CY f g => k.val.val) :=
    (subtype_scott (generated_closed _)).comp (subtype_scott (equalizerAmbient_closed CX CY f g))
  exact (scott_iff_continuous.mp hs).comp (equalizerCompletion CX CY f g).embedding.continuous

theorem equalizer_factor (CZ : ScottCompletion Z) (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) (h : C(Z,X)) (hh : ∀ z, f (h z) = g (h z)) :
    @Continuous Z (equalizerPoints f g) _ (equalizerTopology CX CY f g)
      (fun z => ⟨h z, hh z⟩) := by
  letI : TopologicalSpace (equalizerPoints f g) := equalizerTopology CX CY f g
  letI : TopologicalSpace (equalizerHull CX CY f g) := scott _
  let Hd := extension CZ CX h
  have hExt : extension CZ CY (f.comp h) = extension CZ CY (g.comp h) := by
    congr 1
    ext z
    exact hh z
  rw [extension_comp, extension_comp] at hExt
  have hMem (z : CZ.Carrier) : Hd.val z ∈ equalizerAmbient CX CY f g :=
    congrArg (fun k : ScottHom CZ.Carrier CY.Carrier => k.val z) hExt
  let hL := fun z => (⟨Hd.val z, hMem z⟩ : equalizerAmbient CX CY f g)
  have hLScott : ScottContinuous hL := scott_corestrict Hd.isScott hMem
  have hUnit (z : Z) : hL (CZ.unit z) = equalizerIntoAmbient CX CY f g ⟨h z,hh z⟩ :=
    Subtype.ext (extension_unit CZ CX h z)
  have hDense : hL ⁻¹' equalizerHull CX CY f g = univ := by
    apply generated_eq_of_superset CZ.dense _ (subDcpo_preimage hLScott (generated_closed _))
    rintro _ ⟨z,rfl⟩
    change hL (CZ.unit z) ∈ equalizerHull CX CY f g
    rw [hUnit]
    exact subset_generated _ ⟨_,rfl⟩
  have hCore (z : CZ.Carrier) : hL z ∈ equalizerHull CX CY f g := by
    change z ∈ hL ⁻¹' equalizerHull CX CY f g
    rw [hDense]
    exact Set.mem_univ _
  have hc := (scott_iff_continuous.mp (scott_corestrict hLScott hCore)).comp CZ.embedding.continuous
  apply continuous_induced_rng.mpr
  convert hc using 1
  funext z
  exact Subtype.ext (hUnit z).symm

theorem equalizer_universal (CZ : ScottCompletion Z) (CX : ScottCompletion X) (CY : ScottCompletion Y)
    (f g : C(X,Y)) (h : C(Z,X)) (hh : ∀ z, f (h z) = g (h z)) :
    ∃! k : Z → equalizerPoints f g,
      @Continuous Z (equalizerPoints f g) _ (equalizerTopology CX CY f g) k ∧
        ∀ z, (k z).val = h z := by
  refine ⟨fun z => ⟨h z,hh z⟩, ⟨equalizer_factor CZ CX CY f g h hh,fun _ => rfl⟩,?_⟩
  intro k hk
  funext z
  exact Subtype.ext (hk.2 z)

/-- Identity is a D-completion of a Scott dcpo. -/
def scottCompletion (P : Type u) [PartialOrder P] [IsDCPO P] : @ScottCompletion P (scott P) := by
  letI : TopologicalSpace P := scott P
  exact {
    Carrier := P
    order := inferInstance
    dcpo := inferInstance
    unit := id
    embedding := ⟨⟨induced_id.symm⟩, Function.injective_id⟩
    dense := Set.eq_univ_of_forall fun p => subset_generated _ ⟨p,rfl⟩ }

theorem scott_isSDC (P : Type u) [PartialOrder P] [IsDCPO P] : @IsSDC P (scott P) :=
  ⟨scottCompletion P⟩

theorem scott_product_topology (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q] :
    @productTopology P Q (scott P) (scott Q) (scottCompletion P) (scottCompletion Q) = scott (P × Q) := by
  change TopologicalSpace.induced (fun p : P × Q => (p.1,p.2)) (scott (P × Q)) = _
  exact @induced_id (P × Q) (scott (P × Q))

end ScottDCompletable
