import ScottDCompletable.FiniteSource
import ScottDCompletable.CategoryClosure

noncomputable section
open Set Topology
open scoped Topology
universe u
namespace ScottDCompletable

variable {C : SpaceClass.{u}}

def CanonicalDcpoExponent (K : ClosedPresentation C) (hS : ContainsScott C)
    (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q] : Prop :=
  (K.exponents (hS P) (hS Q)).spaceTopology = scott (ScottHom P Q)

def CanonicalDcpoExponents (K : ClosedPresentation C) (hS : ContainsScott C) : Prop :=
  ∀ (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q],
    CanonicalDcpoExponent K hS P Q

def CanonicalSixExponents (K : ClosedPresentation C) (hS : ContainsScott C) : Prop :=
  ∀ (R : Type u) [PartialOrder R] [IsDCPO R] [OrderBot R] [OrderTop R],
    CanonicalDcpoExponent K hS SixSource.{u} R

theorem canonicalExponent_identity_homeomorph (K : ClosedPresentation C) (hS : ContainsScott C)
    (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q]
    (h : CanonicalDcpoExponent K hS P Q) :
    ∃ e : @Homeomorph (Cont (scottSpace P) (scottSpace Q)) (ScottHom P Q)
      (K.exponents (hS P) (hS Q)).spaceTopology (scott (ScottHom P Q)),
      ∀ f, (@Homeomorph.toEquiv _ _
        (K.exponents (hS P) (hS Q)).spaceTopology (scott (ScottHom P Q)) e) f = f := by
  unfold CanonicalDcpoExponent at h
  rw [h]
  exact ⟨@Homeomorph.refl (ScottHom P Q) (scott _),fun _ => rfl⟩

/-- The weak, fixed-source assumption in the manuscript's maximality theorem. -/
theorem exponent_maximality (K : ClosedPresentation C) (hS : ContainsScott C)
    (hE : CanonicalSixExponents K hS) : ∀ X, C X → SDCSpace X := by
  intro X hX
  letI : TopologicalSpace X.Carrier := X.topology
  letI : T0Space X.Carrier := K.t0 hX
  apply finite_source_test.mpr
  intro R _ _ _ _ H hH
  let T := scottSpace SixSource.{u}
  let Y := scottSpace R
  let P := K.products hX (hS SixSource.{u})
  letI : TopologicalSpace P.space.Carrier := P.space.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  let F : Cont P.space Y := ⟨H,
    @Continuous.comp _ _ _ P.spaceTopology (ordinarySixTopology X.Carrier) (scott R) _ _
      hH P.comparison⟩
  have h := (K.exponents (hS SixSource.{u}) (hS R)).transpose_continuous hX F
  have he : (K.exponents (hS SixSource.{u}) (hS R)).spaceTopology = scott (ScottHom SixSource.{u} R) := hE R
  rw [he] at h
  exact h

theorem maximality_of_canonical_exponents (K : ClosedPresentation C) (hS : ContainsScott C)
    (hE : CanonicalDcpoExponents K hS) : ∀ X, C X → SDCSpace X :=
  exponent_maximality K hS (fun R _ _ _ _ => hE SixSource.{u} R)

end ScottDCompletable
