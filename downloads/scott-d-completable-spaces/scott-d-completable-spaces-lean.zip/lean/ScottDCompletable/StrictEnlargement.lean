import ScottDCompletable.CategoryClosure
import ScottDCompletable.MonotoneSpaces

/-! Proposition `prop:DTop-SDC` and Corollary `cor:strict` of the supplied manuscript. -/

noncomputable section
open Topology
universe u

namespace ScottDCompletable

/-- The full class of monotone determined objects of `Top₀`. -/
def MDSpace (X : Space.{u}) : Prop :=
  @T0Space X.Carrier X.topology ∧ @MonotoneDetermined X.Carrier X.topology

theorem sdc_is_replete {X Y : Space.{u}}
    (e : @Homeomorph X.Carrier Y.Carrier X.topology Y.topology) :
    SDCSpace X ↔ SDCSpace Y :=
  @isSDC_homeomorph X.Carrier Y.Carrier X.topology Y.topology e

theorem sdc_contains_monotoneSpaces (X : Space.{u}) (hX : MDSpace X) : SDCSpace X :=
  @isSDC_of_monotoneDetermined X.Carrier X.topology hX.1 hX.2

theorem sdc_contains_all_cSpaces (X : Space.{u}) (h₀ : @T0Space X.Carrier X.topology)
    (hX : @IsCSpace X.Carrier X.topology) : SDCSpace X :=
  @isSDC_of_cSpace X.Carrier X.topology h₀ hX

theorem sdc_contains_all_scott_posets (P : Type u) [PartialOrder P] :
    SDCSpace (scottSpace P) := isSDC_scott P

theorem sdc_strictly_contains_monotoneSpaces :
    (∀ X : Space.{u}, MDSpace X → SDCSpace X) ∧
    ∃ X : Space.{u}, SDCSpace X ∧ ¬ MDSpace X := by
  let X : Space.{u} := ⟨StrictExample.X, inferInstance⟩
  refine ⟨sdc_contains_monotoneSpaces, X, StrictExample.isSDC, ?_⟩
  · intro hX
    exact StrictExample.strict_witness.2 hX.2

/-- Corollary `cor:strict`: the class of monotone determined spaces cannot
contain every replete full Cartesian closed class containing the required objects. -/
theorem monotoneSpaces_not_largest_closed :
    ¬ (∀ (C : SpaceClass.{u}), ClosedPresentation C →
      (∀ {X Y : Space.{u}}, @Homeomorph X.Carrier Y.Carrier X.topology Y.topology → (C X ↔ C Y)) →
      (∀ X : Space.{u}, @T0Space X.Carrier X.topology → @IsCSpace X.Carrier X.topology → C X) →
      (∀ (P : Type u) [PartialOrder P], C (scottSpace P)) →
      ∀ X : Space.{u}, C X → MDSpace X) := by
  intro largest
  obtain ⟨X, hX, hnX⟩ := sdc_strictly_contains_monotoneSpaces.2
  exact hnX (largest SDCSpace sdcClosedPresentation sdc_is_replete
    sdc_contains_all_cSpaces sdc_contains_all_scott_posets X hX)

end ScottDCompletable
