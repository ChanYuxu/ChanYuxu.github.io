import ScottDCompletable.Limits
import Mathlib.Order.Bounds.OrderIso

noncomputable section
open Set Topology
open scoped Topology
universe u v

namespace ScottDCompletable

section MixedExponentials

variable {X : Type u} [TopologicalSpace X] (CX : ScottCompletion X)
variable {Q : Type u} [PartialOrder Q] [IsDCPO Q]

/-- Restriction of a Scott-continuous map along the actual completion unit. -/
def restrictCompletion (g : ScottHom CX.Carrier Q) :
    @ContinuousMap X Q _ (scott Q) := by
  letI : TopologicalSpace CX.Carrier := scott CX.Carrier
  letI : TopologicalSpace Q := scott Q
  exact ⟨g.val ∘ CX.unit, g.property.comp CX.embedding.continuous⟩

theorem extension_restrictCompletion (g : ScottHom CX.Carrier Q) :
    letI : TopologicalSpace Q := scott Q
    extension CX (scottCompletion Q) (restrictCompletion CX g) = g := by
  letI : TopologicalSpace Q := scott Q
  symm
  apply CX.extension_unique
  intro x
  rfl

theorem mixedExponentialImage_univ :
    letI : TopologicalSpace Q := scott Q
    extensionImage CX (scottCompletion Q) = univ := by
  letI : TopologicalSpace Q := scott Q
  apply Set.eq_univ_of_forall
  intro g
  exact ⟨restrictCompletion CX g, extension_restrictCompletion CX g⟩

theorem mixedExponentialHull_univ :
    letI : TopologicalSpace Q := scott Q
    exponentialHull CX (scottCompletion Q) = univ := by
  letI : TopologicalSpace Q := scott Q
  apply Set.eq_univ_of_forall
  intro g
  exact subset_generated _ ⟨restrictCompletion CX g, extension_restrictCompletion CX g⟩

/-- The canonical map f ↦ f^d is a homeomorphism for a Scott-space target. -/
def mixedExponentialHomeomorph :
    letI : TopologicalSpace Q := scott Q
    @Homeomorph (@ContinuousMap X Q _ (scott Q)) (ScottHom CX.Carrier Q)
      (exponentialTopology CX (scottCompletion Q)) (scott (ScottHom CX.Carrier Q)) := by
  letI : TopologicalSpace Q := scott Q
  letI : TopologicalSpace (@ContinuousMap X Q _ (scott Q)) :=
    exponentialTopology CX (scottCompletion Q)
  letI : TopologicalSpace (ScottHom CX.Carrier Q) := scott (ScottHom CX.Carrier Q)
  letI : TopologicalSpace (exponentialHull CX (scottCompletion Q)) :=
    scott (exponentialHull CX (scottCompletion Q))
  refine {
    toEquiv :=
      { toFun := extension CX (scottCompletion Q)
        invFun := restrictCompletion CX
        left_inv := by
          intro f
          ext x
          exact extension_unit CX (scottCompletion Q) f x
        right_inv := extension_restrictCompletion CX }
    continuous_toFun := ?_
    continuous_invFun := ?_ }
  · have hval : ScottContinuous
        (Subtype.val : exponentialHull CX (scottCompletion Q) → ScottHom CX.Carrier Q) :=
      subtype_scott (generated_closed (extensionImage CX (scottCompletion Q)))
    exact @Continuous.comp _ _ _
      (exponentialTopology CX (scottCompletion Q))
      (scott (exponentialHull CX (scottCompletion Q)))
      (scott (ScottHom CX.Carrier Q)) _ _ (scott_iff_continuous.mp hval)
        (exponentialCompletion CX (scottCompletion Q)).embedding.continuous
  · apply continuous_induced_rng.mpr
    have hfull (g : ScottHom CX.Carrier Q) : g ∈ exponentialHull CX (scottCompletion Q) := by
      rw [mixedExponentialHull_univ CX]
      exact Set.mem_univ _
    have he : (exponentialUnit CX (scottCompletion Q) ∘ restrictCompletion CX) =
        (fun g => (⟨g, hfull g⟩ : exponentialHull CX (scottCompletion Q))) := by
      funext g
      apply Subtype.ext
      exact extension_restrictCompletion CX g
    rw [he]
    exact scott_iff_continuous.mp (scott_corestrict ScottContinuous.id hfull)

@[simp] theorem mixedExponentialHomeomorph_apply
    (f : @ContinuousMap X Q _ (scott Q)) :
    letI : TopologicalSpace Q := scott Q
    (mixedExponentialHomeomorph CX) f = extension CX (scottCompletion Q) f := rfl

end MixedExponentials

section IdentityCompletions

variable {P Q : Type u} [PartialOrder P] [IsDCPO P] [PartialOrder Q] [IsDCPO Q]

@[simp] theorem extension_scottCompletion_apply
    (f : @ContinuousMap P Q (scott P) (scott Q)) (p : P) :
    (@extension P Q (scott P) (scott Q) (scottCompletion P) (scottCompletion Q) f).val p = f p :=
  @extension_unit P Q (scott P) (scott Q) (scottCompletion P) (scottCompletion Q) f p

/-- The canonical identification of the SDC exponential of two Scott dcpos. -/
def scottExponentialHomeomorph :
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    @Homeomorph (@ContinuousMap P Q (scott P) (scott Q)) (ScottHom P Q)
      (exponentialTopology (scottCompletion P) (scottCompletion Q))
      (scott (ScottHom P Q)) :=
  @mixedExponentialHomeomorph P (scott P) (scottCompletion P) Q _ _

@[simp] theorem scottExponentialHomeomorph_apply
    (f : @ContinuousMap P Q (scott P) (scott Q)) (p : P) :
    ((scottExponentialHomeomorph (P := P) (Q := Q)) f).val p = f p :=
  extension_scottCompletion_apply f p

/-- The same Scott-continuous function on the product topology in SDC. -/
def scottProductContinuousMap {R : Type u} [PartialOrder R] [IsDCPO R]
    (F : ScottHom (R × P) Q) :
    @ContinuousMap (R × P) Q
      (@productTopology R P (scott R) (scott P) (scottCompletion R) (scottCompletion P))
      (scott Q) := by
  letI : TopologicalSpace R := scott R
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  letI : TopologicalSpace (R × P) := productTopology (scottCompletion R) (scottCompletion P)
  refine ⟨F.val, ?_⟩
  change @Continuous (R × P) Q (productTopology (scottCompletion R) (scottCompletion P))
    (scott Q) F.val
  rw [scott_product_topology]
  exact F.property

theorem scott_exponential_curry {R : Type u} [PartialOrder R] [IsDCPO R]
    (F : ScottHom (R × P) Q) (r : R) :
    letI : TopologicalSpace R := scott R
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    ((scottExponentialHomeomorph (P := P) (Q := Q))
      ((exponentialCurry (scottCompletion R) (scottCompletion P) (scottCompletion Q)
        (scottProductContinuousMap F)) r)) = scottCurry F r := by
  letI : TopologicalSpace R := scott R
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  apply Subtype.ext
  funext p
  rw [scottExponentialHomeomorph_apply]
  rfl

theorem equalizerAmbient_scott_eq (f g : @ContinuousMap P Q (scott P) (scott Q)) :
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    equalizerAmbient (scottCompletion P) (scottCompletion Q) f g = equalizerPoints f g := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  ext p
  change (extension (scottCompletion P) (scottCompletion Q) f).val p =
    (extension (scottCompletion P) (scottCompletion Q) g).val p ↔ f p = g p
  rw [extension_scottCompletion_apply, extension_scottCompletion_apply]
  rfl

theorem scott_equalizer_subDcpo (f g : @ContinuousMap P Q (scott P) (scott Q)) :
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    SubDcpo (equalizerPoints f g) := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  rw [← equalizerAmbient_scott_eq f g]
  exact equalizerAmbient_closed (scottCompletion P) (scottCompletion Q) f g

/-- The completion unit is an order isomorphism in the Scott equalizer case. -/
def scottEqualizerOrderIso (f g : @ContinuousMap P Q (scott P) (scott Q)) :
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    equalizerPoints f g ≃o equalizerHull (scottCompletion P) (scottCompletion Q) f g := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  exact {
  toFun := equalizerUnit (scottCompletion P) (scottCompletion Q) f g
  invFun p := ⟨p.val.val, by
    rw [← equalizerAmbient_scott_eq f g]
    exact p.val.property⟩
  left_inv p := Subtype.ext rfl
  right_inv p := by
    apply Subtype.ext
    apply Subtype.ext
    rfl
  map_rel_iff' := by
    intro p q
    rfl }

theorem scott_equalizer_topology (f g : @ContinuousMap P Q (scott P) (scott Q)) :
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    equalizerTopology (scottCompletion P) (scottCompletion Q) f g =
      scott (equalizerPoints f g) := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  let E := equalizerPoints f g
  let L := equalizerHull (scottCompletion P) (scottCompletion Q) f g
  let e : E ≃o L := scottEqualizerOrderIso f g
  letI : TopologicalSpace E := scott E
  letI : TopologicalSpace L := scott L
  have hE : ScottContinuous e := fun _ _ _ _ h => (OrderIso.isLUB_image' e).mpr h
  have hL : ScottContinuous e.symm := fun _ _ _ _ h => (OrderIso.isLUB_image' e.symm).mpr h
  let eh : E ≃ₜ L :=
    { toEquiv := e.toEquiv
      continuous_toFun := scott_iff_continuous.mp hE
      continuous_invFun := scott_iff_continuous.mp hL }
  exact eh.isEmbedding.isInducing.eq_induced.symm

end IdentityCompletions

/-- The one-point Scott dcpo is terminal among SDC spaces. -/
theorem scott_terminal (X : Type u) [TopologicalSpace X] :
    ∃! f : X → PUnit.{u + 1}, @Continuous X PUnit.{u + 1} _ (scott PUnit.{u + 1}) f := by
  letI : TopologicalSpace PUnit.{u + 1} := scott PUnit.{u + 1}
  exact ⟨fun _ => PUnit.unit, continuous_const, fun _ _ => Subsingleton.elim _ _⟩

/-- The manuscript's canonical identifications, with the identity completions. -/
theorem sigma_preserves_constructions
    (P Q : Type u) [PartialOrder P] [IsDCPO P] [PartialOrder Q] [IsDCPO Q] :
    letI : TopologicalSpace P := scott P
    letI : TopologicalSpace Q := scott Q
    @IsSDC PUnit.{u + 1} (scott PUnit.{u + 1}) ∧
    (∀ (X : Type u) (tX : TopologicalSpace X),
      ∃! f : X → PUnit.{u + 1}, @Continuous X PUnit.{u + 1} tX (scott PUnit.{u + 1}) f) ∧
    productTopology (scottCompletion P) (scottCompletion Q) = scott (P × Q) ∧
    @Continuous (P × Q) P (productTopology (scottCompletion P) (scottCompletion Q))
      (scott P) Prod.fst ∧
    @Continuous (P × Q) Q (productTopology (scottCompletion P) (scottCompletion Q))
      (scott Q) Prod.snd ∧
    (∀ f g : @ContinuousMap P Q (scott P) (scott Q),
      SubDcpo (equalizerPoints f g) ∧
      equalizerTopology (scottCompletion P) (scottCompletion Q) f g =
        scott (equalizerPoints f g)) ∧
    ∃ e : @Homeomorph (@ContinuousMap P Q (scott P) (scott Q)) (ScottHom P Q)
        (exponentialTopology (scottCompletion P) (scottCompletion Q)) (scott (ScottHom P Q)),
      (∀ f p, (e f).val p = f p) ∧
      (∀ (R : Type u) [PartialOrder R] [IsDCPO R]
        (F : ScottHom (R × P) Q) (r : R),
        letI : TopologicalSpace R := scott R
        e ((exponentialCurry (scottCompletion R) (scottCompletion P) (scottCompletion Q)
          (scottProductContinuousMap F)) r) = scottCurry F r) := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  refine ⟨scott_isSDC _, fun X tX => @scott_terminal X tX, scott_product_topology P Q,
    product_fst _ _, product_snd _ _, fun f g => ⟨scott_equalizer_subDcpo f g,
      scott_equalizer_topology f g⟩, scottExponentialHomeomorph,
      scottExponentialHomeomorph_apply, ?_⟩
  intro R oR hR F r
  exact @scott_exponential_curry P Q _ _ _ _ R oR hR F r

end ScottDCompletable
