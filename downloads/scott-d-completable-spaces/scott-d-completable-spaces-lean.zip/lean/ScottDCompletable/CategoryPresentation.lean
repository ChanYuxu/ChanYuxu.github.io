import ScottDCompletable.Completion
import Mathlib.Topology.Constructions.SumProd

noncomputable section
open Set Topology
universe u
namespace ScottDCompletable

/-- A bundled space, used with the full hom-set of continuous functions. -/
structure Space where
  Carrier : Type u
  topology : TopologicalSpace Carrier

abbrev SpaceClass := Space.{u} → Prop

abbrev Cont (X Y : Space.{u}) :=
  {f : X.Carrier → Y.Carrier // @Continuous _ _ X.topology Y.topology f}

abbrev scottSpace (P : Type u) [Preorder P] : Space.{u} := ⟨P, scott P⟩

abbrev ordinaryProductSpace (X Y : Space.{u}) : Space.{u} :=
  ⟨X.Carrier × Y.Carrier, @instTopologicalSpaceProd X.Carrier Y.Carrier X.topology Y.topology⟩

/-- The product universal property in a full class of spaces on the canonical set product. -/
structure ProductPresentation (C : SpaceClass.{u}) (X Y : Space.{u}) where
  spaceTopology : TopologicalSpace (X.Carrier × Y.Carrier)
  belongs : C ⟨X.Carrier × Y.Carrier, spaceTopology⟩
  fst_continuous : @Continuous _ _ spaceTopology X.topology Prod.fst
  snd_continuous : @Continuous _ _ spaceTopology Y.topology Prod.snd
  pair_continuous : ∀ (Z : Space.{u}), C Z → ∀ (f : Cont Z X) (g : Cont Z Y),
    @Continuous _ _ Z.topology spaceTopology (fun z => (f.val z,g.val z))

abbrev ProductPresentation.space {C : SpaceClass.{u}} {X Y : Space.{u}}
    (P : ProductPresentation C X Y) : Space.{u} := ⟨_,P.spaceTopology⟩

theorem ProductPresentation.comparison {C : SpaceClass.{u}} {X Y : Space.{u}}
    (P : ProductPresentation C X Y) :
    @Continuous _ _ P.spaceTopology (ordinaryProductSpace X Y).topology id := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  letI : TopologicalSpace (X.Carrier × Y.Carrier) := P.spaceTopology
  exact P.fst_continuous.prodMk P.snd_continuous

theorem ProductPresentation.universal {C : SpaceClass.{u}} {X Y : Space.{u}}
    (P : ProductPresentation C X Y) (Z : Space.{u}) (hZ : C Z)
    (f : Cont Z X) (g : Cont Z Y) :
    ∃! h : Cont Z P.space, ∀ z, (h.val z).1 = f.val z ∧ (h.val z).2 = g.val z := by
  refine ⟨⟨fun z => (f.val z,g.val z),P.pair_continuous Z hZ f g⟩,fun _ => ⟨rfl,rfl⟩,?_⟩
  intro h hh
  apply Subtype.ext
  funext z
  exact Prod.ext (hh z).1 (hh z).2

abbrev ProductChoices (C : SpaceClass.{u}) :=
  ∀ {X Y : Space.{u}}, C X → C Y → ProductPresentation C X Y

def ProductPresentation.section {C : SpaceClass.{u}} {X Z : Space.{u}}
    (P : ProductPresentation C Z X) (hX : C X) (z : Z.Carrier) : Cont X P.space := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Z.Carrier := Z.topology
  exact ⟨fun x => (z,x), P.pair_continuous X hX ⟨fun _ => z,continuous_const⟩ ⟨id,continuous_id⟩⟩

def transpose {C : SpaceClass.{u}} {X Y Z : Space.{u}} (P : ProductPresentation C Z X)
    (hX : C X) (f : Cont P.space Y) (z : Z.Carrier) : Cont X Y := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  letI : TopologicalSpace (Z.Carrier × X.Carrier) := P.spaceTopology
  exact ⟨fun x => f.val (z,x), f.property.comp (P.section hX z).property⟩

/-- Exponential universal property on the canonically identified hom-set. -/
structure ExponentialPresentation (C : SpaceClass.{u}) (products : ProductChoices C)
    {X Y : Space.{u}} (hX : C X) (hY : C Y) where
  spaceTopology : TopologicalSpace (Cont X Y)
  belongs : C ⟨Cont X Y,spaceTopology⟩
  evaluation_continuous : @Continuous (Cont X Y × X.Carrier) Y.Carrier
    (products belongs hX).spaceTopology Y.topology (fun p => p.1.val p.2)
  transpose_continuous : ∀ {Z : Space.{u}} (hZ : C Z) (f : Cont (products hZ hX).space Y),
    @Continuous _ _ Z.topology spaceTopology (transpose (products hZ hX) hX f)

abbrev ExponentialPresentation.space {C : SpaceClass.{u}} {prod : ProductChoices C}
    {X Y : Space.{u}} {hX : C X} {hY : C Y} (E : ExponentialPresentation C prod hX hY) : Space.{u} :=
  ⟨_,E.spaceTopology⟩

structure ClosedPresentation (C : SpaceClass.{u}) where
  t0 : ∀ {X : Space.{u}}, C X → @T0Space X.Carrier X.topology
  products : ProductChoices C
  exponents : ∀ {X Y : Space.{u}} (hX : C X) (hY : C Y), ExponentialPresentation C products hX hY

def ContainsScott (C : SpaceClass.{u}) : Prop :=
  ∀ (P : Type u) [PartialOrder P] [IsDCPO P], C (scottSpace P)

def SDCSpace (X : Space.{u}) : Prop := @IsSDC X.Carrier X.topology

end ScottDCompletable
