import ScottDCompletable.Limits
import ScottDCompletable.UpperEncoding
import ScottDCompletable.UpperRepresentation

noncomputable section
open Set Topology
open scoped Topology
universe u v

namespace ScottDCompletable

variable {X : Type u} [TopologicalSpace X]

/-- Corestriction to the intrinsic Scott topology of any sub-dcpo. -/
def AllCorestrictions (X : Type u) [TopologicalSpace X] : Prop :=
  ∀ (P : Type u) [PartialOrder P] [IsDCPO P] (A : Set P), SubDcpo A →
    ∀ (f : X → P), @Continuous X P _ (scott P) f →
      ∀ h : ∀ x, f x ∈ A, @Continuous X A _ (scott A) (fun x => ⟨f x,h x⟩)

def UpperCorestrictions (X : Type u) [TopologicalSpace X] : Prop :=
  ∀ (P : Type u) [PartialOrder P] [IsDCPO P] (A : Set P), IsUpperSet A →
    ∀ (f : X → P), @Continuous X P _ (scott P) f →
      ∀ h : ∀ x, f x ∈ A, @Continuous X A _ (scott A) (fun x => ⟨f x,h x⟩)

theorem allCorestrictions_of_sdc (hX : IsSDC X) : AllCorestrictions X := by
  obtain ⟨C⟩ := hX
  intro P _ _ A hA f hf hm
  let F := C.extend f hf
  have hEq : F.val ⁻¹' A = univ := by
    apply generated_eq_of_superset C.dense _ (subDcpo_preimage F.isScott hA)
    rintro _ ⟨x,rfl⟩
    change F.val (C.unit x) ∈ A
    rw [C.extend_unit]
    exact hm x
  have hF (x : C.Carrier) : F.val x ∈ A := by
    change x ∈ F.val ⁻¹' A
    rw [hEq]
    exact mem_univ x
  letI : TopologicalSpace A := scott A
  have h := (scott_iff_continuous.mp (scott_corestrict F.isScott hF)).comp C.embedding.continuous
  convert h using 1
  funext x
  exact Subtype.ext (C.extend_unit f hf x).symm

theorem upperCorestrictions_of_all (hX : AllCorestrictions X) : UpperCorestrictions X :=
  fun P _ _ A hA f hf hm => hX P A (upper_subDcpo hA) f hf hm

theorem orderIso_scott {P Q : Type*} [PartialOrder P] [PartialOrder Q] (e : P ≃o Q) :
    ScottContinuous (e : P → Q) := by
  intro A _ _ a ha
  constructor
  · rintro _ ⟨x,hx,rfl⟩
    exact e.monotone (ha.1 hx)
  · intro b hb
    have h : e.symm b ∈ upperBounds A := fun x hx => by
      apply e.le_symm_apply.mpr
      exact hb ⟨x,hx,rfl⟩
    exact e.le_symm_apply.mp (ha.2 h)

theorem specializes_scott_iff {P : Type*} [PartialOrder P] (a b : P) :
    @Specializes P (scott P) b a ↔ a ≤ b := by
  letI : TopologicalSpace P := scott P
  letI : T0Space P := scott_t0 P
  change (specializationOrder P).le a b ↔ a ≤ b
  rw [specializationOrder_scott]

theorem sdc_of_upperCorestrictions [T0Space X] (hX : UpperCorestrictions X) : IsSDC X := by
  let D := standardCompletion X
  letI : TopologicalSpace D.Carrier := D.topology
  letI : PartialOrder D.Carrier := D.order
  letI : IsDCPO D.Carrier := D.dcpo
  obtain ⟨P, oP, dP, ρ, hρ, hupper⟩ :=
    exists_upper_scott_embedding (M := D.Carrier) (fun _ _ => Iff.rfl) D.topology_le_scott
  letI : PartialOrder P := oP
  letI : IsDCPO P := dP
  letI : TopologicalSpace P := scott P
  let A := Set.range ρ
  have hf := hρ.continuous.comp D.embedding.continuous
  let f := ρ ∘ D.unit
  have hm (x : X) : f x ∈ A := ⟨D.unit x,rfl⟩
  have hcore := hX P A hupper f hf hm
  let e : D.Carrier ≃o A :=
    { toEquiv := Equiv.ofInjective ρ hρ.injective
      map_rel_iff' := by
        intro a b
        change ρ a ≤ ρ b ↔ a ≤ b
        rw [← specializes_scott_iff, hρ.isInducing.specializes_iff]
        rfl }
  have hu : @Continuous X D.Carrier _ (scott D.Carrier) D.unit := by
    letI : TopologicalSpace A := scott A
    letI : TopologicalSpace D.Carrier := scott D.Carrier
    have h := (scott_iff_continuous.mp (orderIso_scott e.symm)).comp hcore
    convert h using 1
    funext x
    exact (e.symm_apply_apply (D.unit x)).symm
  exact ⟨D.toScottCompletion (D.topology_eq_scott_of_continuous_unit hu)⟩

theorem corestriction_test [T0Space X] :
    (IsSDC X ↔ AllCorestrictions X) ∧ (AllCorestrictions X ↔ UpperCorestrictions X) :=
  ⟨⟨allCorestrictions_of_sdc, fun h => sdc_of_upperCorestrictions (upperCorestrictions_of_all h)⟩,
    ⟨upperCorestrictions_of_all, fun h => allCorestrictions_of_sdc (sdc_of_upperCorestrictions h)⟩⟩

abbrev ordinarySixTopology (X : Type u) [TopologicalSpace X] :
    TopologicalSpace (X × SixSource.{u}) :=
  @instTopologicalSpaceProd X SixSource _ (scott SixSource)

def ordinaryTranspose {R : Type u} [PartialOrder R] (H : X × SixSource.{u} → R)
    (hH : @Continuous (X × SixSource.{u}) R (ordinarySixTopology X) (scott R) H)
    (x : X) : ScottHom SixSource.{u} R := by
  letI : TopologicalSpace SixSource.{u} := scott SixSource
  letI : TopologicalSpace R := scott R
  exact ⟨fun t => H (x,t), hH.comp (continuous_const.prodMk continuous_id)⟩

def FiniteSourceTest (X : Type u) [TopologicalSpace X] : Prop :=
  ∀ (R : Type u) [PartialOrder R] [IsDCPO R] [OrderBot R] [OrderTop R]
    (H : X × SixSource.{u} → R)
    (hH : @Continuous (X × SixSource.{u}) R (ordinarySixTopology X) (scott R) H),
    @Continuous X (ScottHom SixSource.{u} R) _ (scott (ScottHom SixSource.{u} R))
      (ordinaryTranspose H hH)

theorem finiteSourceTest_of_sdc (hX : IsSDC X) : FiniteSourceTest X := by
  obtain ⟨C⟩ := hX
  intro R _ _ _ _ H hH
  letI : TopologicalSpace SixSource.{u} := scott SixSource
  letI : TopologicalSpace R := scott R
  let T := scottCompletion SixSource.{u}
  letI : TopologicalSpace (X × SixSource.{u}) := productTopology C T
  let Cprod := productCompletion C T
  have hcomp : @Continuous (X × SixSource.{u}) (X × SixSource.{u})
      (productTopology C T) (ordinarySixTopology X) id := product_comparison C T
  have hh : @Continuous _ _ (productTopology C T) (scott R) H :=
    @Continuous.comp _ _ _ (productTopology C T) (ordinarySixTopology X) (scott R) _ _ hH hcomp
  let Hext : ScottHom (C.Carrier × SixSource.{u}) R := Cprod.extend H hh
  letI : TopologicalSpace (ScottHom SixSource.{u} R) := scott _
  have hc := (scott_iff_continuous.mp (scott_curry Hext)).comp C.embedding.continuous
  convert hc using 1
  funext x
  apply Subtype.ext
  funext t
  exact (Cprod.extend_unit H hh (x,t)).symm

theorem upperCorestrictions_of_finiteSourceTest (hX : FiniteSourceTest X) : UpperCorestrictions X := by
  intro P _ _ A hA f hf hm
  let R := Encoding.Target A hA
  let j := Encoding.j (A := A) (hA := hA)
  let H := fun p : X × SixSource.{u} => (j ⟨f p.1, hm p.1⟩).val p.2
  have hH : @Continuous (X × SixSource.{u}) R (ordinarySixTopology X) (scott R) H :=
    Encoding.continuous_H (A := A) (hA := hA) hf hm
  letI : TopologicalSpace A := scott A
  letI : TopologicalSpace (ScottHom SixSource.{u} R) := scott _
  apply (Encoding.j_isEmbedding (A := A) (hA := hA)).isInducing.continuous_iff.mpr
  convert hX R H hH using 1

theorem finite_source_test [T0Space X] : IsSDC X ↔ FiniteSourceTest X :=
  ⟨finiteSourceTest_of_sdc, fun h => sdc_of_upperCorestrictions (upperCorestrictions_of_finiteSourceTest h)⟩

end ScottDCompletable
