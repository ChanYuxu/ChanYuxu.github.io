import ScottDCompletable.CategoryClosure
import ScottDCompletable.Limits
import Mathlib.CategoryTheory.Limits.Constructions.FiniteProductsOfBinaryProducts
import Mathlib.CategoryTheory.Limits.Constructions.LimitsOfProductsAndEqualizers
import Mathlib.CategoryTheory.Limits.Preserves.Shapes.BinaryProducts
import Mathlib.CategoryTheory.Limits.Preserves.Shapes.Equalizers
import Mathlib.CategoryTheory.Limits.Preserves.Shapes.Terminal

noncomputable section
open CategoryTheory CategoryTheory.Limits
universe u
namespace ScottDCompletable

abbrev FullSpace (C : SpaceClass.{u}) := {X : Space.{u} // C X}

instance (C : SpaceClass.{u}) : Category.{u} (FullSpace C) where
  Hom X Y := Cont X.val Y.val
  id X := ⟨id, @continuous_id _ X.val.topology⟩
  comp {X Y Z} f g := ⟨g.val ∘ f.val,
    @Continuous.comp _ _ _ X.val.topology Y.val.topology Z.val.topology
      _ _ g.property f.property⟩
  id_comp _ := rfl
  comp_id _ := rfl
  assoc _ _ _ := rfl

def sdcTerminal : FullSpace (SDCSpace : SpaceClass.{u}) :=
  ⟨scottSpace PUnit.{u+1}, sdcContainsScott _⟩

def isTerminalSdc : IsTerminal (sdcTerminal.{u}) := by
  refine IsTerminal.ofUniqueHom
    (fun X => ⟨fun _ => PUnit.unit,
      @continuous_const X.val.Carrier PUnit.{u+1} X.val.topology (scott PUnit.{u+1}) PUnit.unit⟩) ?_
  intro X f
  apply Subtype.ext
  funext x
  exact @Subsingleton.elim PUnit.{u+1} inferInstance _ _

instance : HasTerminal (FullSpace (SDCSpace : SpaceClass.{u})) := isTerminalSdc.hasTerminal

def sdcBinaryFan (X Y : FullSpace (SDCSpace : SpaceClass.{u})) : BinaryFan X Y :=
  let P := sdcProducts X.property Y.property
  BinaryFan.mk (P := ⟨P.space,P.belongs⟩)
    ⟨Prod.fst,P.fst_continuous⟩ ⟨Prod.snd,P.snd_continuous⟩

def sdcBinaryFanIsLimit (X Y : FullSpace (SDCSpace : SpaceClass.{u})) :
    IsLimit (sdcBinaryFan X Y) := by
  let P := sdcProducts X.property Y.property
  refine BinaryFan.IsLimit.mk _ (fun {Z} f g => ⟨fun z => (f.val z,g.val z),
    P.pair_continuous Z.val Z.property f g⟩) (fun _ _ => rfl) (fun _ _ => rfl) ?_
  intro Z f g m hf hg
  apply Subtype.ext
  funext z
  exact Prod.ext (congrFun (congrArg Subtype.val hf) z) (congrFun (congrArg Subtype.val hg) z)

instance : HasBinaryProducts (FullSpace (SDCSpace : SpaceClass.{u})) := by
  letI {X Y : FullSpace (SDCSpace : SpaceClass.{u})} : HasLimit (pair X Y) :=
    HasLimit.mk ⟨_,sdcBinaryFanIsLimit X Y⟩
  exact hasBinaryProducts_of_hasLimit_pair (FullSpace (SDCSpace : SpaceClass.{u}))

def sdcEqualizerSpace {X Y : FullSpace (SDCSpace : SpaceClass.{u})} (f g : X ⟶ Y) :
    FullSpace (SDCSpace : SpaceClass.{u}) := by
  letI : TopologicalSpace X.val.Carrier := X.val.topology
  letI : TopologicalSpace Y.val.Carrier := Y.val.topology
  let CX := completionOf X.property
  let CY := completionOf Y.property
  exact ⟨⟨equalizerPoints f.toContinuousMap g.toContinuousMap,
    equalizerTopology CX CY f.toContinuousMap g.toContinuousMap⟩,
    ⟨equalizerCompletion CX CY f.toContinuousMap g.toContinuousMap⟩⟩

def sdcEqualizerArrow {X Y : FullSpace (SDCSpace : SpaceClass.{u})} (f g : X ⟶ Y) :
    sdcEqualizerSpace f g ⟶ X := by
  letI : TopologicalSpace X.val.Carrier := X.val.topology
  letI : TopologicalSpace Y.val.Carrier := Y.val.topology
  exact ⟨Subtype.val, equalizer_inclusion (completionOf X.property) (completionOf Y.property)
    f.toContinuousMap g.toContinuousMap⟩

def sdcFork {X Y : FullSpace (SDCSpace : SpaceClass.{u})} (f g : X ⟶ Y) : Fork f g :=
  Fork.ofι (sdcEqualizerArrow f g) (by
    apply Subtype.ext
    funext x
    exact x.property)

def sdcForkIsLimit {X Y : FullSpace (SDCSpace : SpaceClass.{u})} (f g : X ⟶ Y) :
    IsLimit (sdcFork f g) := by
  apply Fork.IsLimit.mk'
  intro s
  letI : TopologicalSpace X.val.Carrier := X.val.topology
  letI : TopologicalSpace Y.val.Carrier := Y.val.topology
  letI : TopologicalSpace s.pt.val.Carrier := s.pt.val.topology
  have hh : ∀ z, f.val (s.ι.val z) = g.val (s.ι.val z) :=
    congrFun (congrArg Subtype.val s.condition)
  refine ⟨⟨fun z => ⟨s.ι.val z,hh z⟩,
    equalizer_factor (completionOf s.pt.property) (completionOf X.property)
      (completionOf Y.property) f.toContinuousMap g.toContinuousMap s.ι.toContinuousMap hh⟩,
    rfl, ?_⟩
  intro m hm
  apply Subtype.ext
  funext z
  exact Subtype.ext (congrFun (congrArg Subtype.val hm) z)

instance : HasEqualizers (FullSpace (SDCSpace : SpaceClass.{u})) := by
  letI {X Y : FullSpace (SDCSpace : SpaceClass.{u})} {f g : X ⟶ Y} :
      HasLimit (parallelPair f g) := HasLimit.mk ⟨_,sdcForkIsLimit f g⟩
  exact hasEqualizers_of_hasLimit_parallelPair (FullSpace (SDCSpace : SpaceClass.{u}))

theorem sdc_hasFiniteLimits : HasFiniteLimits (FullSpace (SDCSpace : SpaceClass.{u})) := by
  letI := hasFiniteProducts_of_has_binary_and_terminal (C := FullSpace (SDCSpace : SpaceClass.{u}))
  exact hasFiniteLimits_of_hasEqualizers_and_finite_products

end ScottDCompletable
