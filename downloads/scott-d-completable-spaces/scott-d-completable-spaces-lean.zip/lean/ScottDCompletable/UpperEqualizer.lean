import ScottDCompletable.Order
import Mathlib.Data.Fintype.Order
import Mathlib.Order.Bounds.OrderIso

/-! The upper-set equalizers used in the reverse implication of the
compatibility theorem. The target has the Scott topology of the
pointwise ordered function dcpo. -/

noncomputable section

open Set
open scoped Topology
universe u v

namespace ScottDCompletable

variable {P : Type u} [PartialOrder P]

/-- The characteristic function of the complement of a principal downset. -/
def principalComplementChar (p t : P) : Bool := by
  classical
  exact if p ≤ t then false else true

theorem principalComplement_scottOpen (t : P) :
    IsOpen[scott P] (Iic t)ᶜ := by
  have h : IsClosed[scott P] (Iic t) :=
    (scott_isClosed_iff _).mpr ⟨isLowerSet_Iic t, dirSupClosed_Iic t⟩
  exact h.isOpen_compl

theorem principalComplementChar_scott (t : P) :
    ScottContinuous (fun p : P => principalComplementChar p t) := by
  classical
  intro D _ _ p hp
  constructor
  · rintro _ ⟨d, hd, rfl⟩
    by_cases ht : p ≤ t
    · have hdt : d ≤ t := (hp.1 hd).trans ht
      simp [principalComplementChar, hdt, ht]
    · simp [principalComplementChar, ht]
  · intro b hb
    cases b with
    | true => exact Bool.le_true _
    | false =>
      have ht : p ≤ t := hp.2 (by
        intro d hd
        have hc := hb ⟨d, hd, rfl⟩
        by_contra hdt
        simp [principalComplementChar, hdt] at hc
        exact (by decide : ¬ ((true : Bool) ≤ false)) hc)
      simp [principalComplementChar, ht]

/-- The index set (I=P\setminus A). -/
abbrev UpperEqualizerIndex (A : Set P) := ↥(Aᶜ)

/-- The pointwise ordered dcpo (S^I), with (S={0<1}). -/
abbrev UpperEqualizerTarget (A : Set P) := UpperEqualizerIndex A → Bool

def upperEqualizerA (A : Set P) (p : P) : UpperEqualizerTarget A :=
  fun t => principalComplementChar p t.val

def upperEqualizerB (A : Set P) (_ : P) : UpperEqualizerTarget A :=
  fun _ => true

theorem upperEqualizerA_scott (A : Set P) : ScottContinuous (upperEqualizerA A) := by
  intro D hne hdir p hp
  apply isLUB_pi.mpr
  intro t
  rw [Set.image_image]
  exact principalComplementChar_scott t.val hne hdir hp

theorem upperEqualizerB_scott (A : Set P) : ScottContinuous (upperEqualizerB A) :=
  ScottContinuous.const _

theorem upperEqualizer_eq_iff_avoid (A : Set P) (p : P) :
    upperEqualizerA A p = upperEqualizerB A p ↔
      ∀ t ∈ Aᶜ, ¬ p ≤ t := by
  classical
  constructor
  · intro h t ht hpt
    have hv := congrFun h (⟨t, ht⟩ : UpperEqualizerIndex A)
    simp [upperEqualizerA, upperEqualizerB, principalComplementChar, hpt] at hv
  · intro h
    funext t
    simp [upperEqualizerA, upperEqualizerB, principalComplementChar, h t.val t.property]

theorem upperEqualizer_eq_iff {A : Set P} (hA : IsUpperSet A) (p : P) :
    upperEqualizerA A p = upperEqualizerB A p ↔ p ∈ A := by
  rw [upperEqualizer_eq_iff_avoid]
  constructor
  · intro h
    by_contra hp
    exact h p hp le_rfl
  · intro hp t ht hpt
    exact ht (hA hpt hp)

theorem upperEqualizer_inclusion [IsDCPO P] {A : Set P} (hA : IsUpperSet A) :
    ScottContinuous (Subtype.val : A → P) :=
  subtype_scott (upper_subDcpo hA)

theorem upperEqualizer_commutes {A : Set P} (hA : IsUpperSet A) :
    (fun p : A => upperEqualizerA A p.val) =
      (fun p : A => upperEqualizerB A p.val) := by
  funext p
  exact (upperEqualizer_eq_iff hA p.val).mpr p.property

/-- The intrinsic Scott-space inclusion is the equalizer of the displayed
parallel Scott-continuous maps in dcpos. -/
theorem upperEqualizer_universal_dcpo {A : Set P} (hA : IsUpperSet A)
    {D : Type v} [PartialOrder D] [IsDCPO D]
    (f : D → P) (hf : ScottContinuous f)
    (he : ∀ x, upperEqualizerA A (f x) = upperEqualizerB A (f x)) :
    ∃! k : D → A, ScottContinuous k ∧ ∀ x, (k x).val = f x := by
  let hm (x : D) : f x ∈ A := (upperEqualizer_eq_iff hA (f x)).mp (he x)
  refine ⟨fun x => ⟨f x, hm x⟩, ⟨scott_corestrict hf hm, fun _ => rfl⟩, ?_⟩
  intro k hk
  funext x
  exact Subtype.ext (hk.2 x)

abbrev UpperEqualizerCarrier (A : Set P) :=
  {p : P // upperEqualizerA A p = upperEqualizerB A p}

/-- The order identification of the exact equalizer carrier with the upper
subset. Its underlying map is the identity on points of (P). -/
def upperEqualizerOrderIso {A : Set P} (hA : IsUpperSet A) :
    UpperEqualizerCarrier A ≃o A where
  toFun p := ⟨p.val, (upperEqualizer_eq_iff hA p.val).mp p.property⟩
  invFun p := ⟨p.val, (upperEqualizer_eq_iff hA p.val).mpr p.property⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

/-- Transport a categorical equalizer factor through the literal upper-set
identification. Both subtype codomains have intrinsic Scott topologies. -/
theorem upperCorestrict_of_equalizer_factor {A : Set P} (hA : IsUpperSet A)
    {X : Type v} [TopologicalSpace X] {f : X → P} (hm : ∀ x, f x ∈ A)
    (factor : ∃ k : X → UpperEqualizerCarrier A,
      @Continuous X (UpperEqualizerCarrier A) _ (scott (UpperEqualizerCarrier A)) k ∧
        ∀ x, (k x).val = f x) :
    @Continuous X A _ (scott A) (fun x => ⟨f x, hm x⟩) := by
  obtain ⟨k, hk, hval⟩ := factor
  let e := upperEqualizerOrderIso hA
  have he : @Continuous (UpperEqualizerCarrier A) A
      (scott (UpperEqualizerCarrier A)) (scott A) e :=
    scott_iff_continuous.mp (fun _ _ _ _ hp => e.isLUB_image'.mpr hp)
  convert he.comp hk using 1
  funext x
  exact Subtype.ext (hval x).symm

end ScottDCompletable
