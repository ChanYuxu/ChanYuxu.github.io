import ScottDCompletable.CategoricalLimits
import Mathlib.CategoryTheory.Monoidal.Closed.Cartesian

/-! The Cartesian closed structure of the full category of Scott
D-completable spaces, on the products and exponentials of `thm:CCC`. -/

noncomputable section
open CategoryTheory CategoryTheory.Limits CategoryTheory.MonoidalCategory
universe u

namespace ScottDCompletable

abbrev SdcCategory := FullSpace (SDCSpace : SpaceClass.{u})

/-- Choose the actual completion-induced products and the one-point space. -/
abbrev sdcCartesianMonoidal : CartesianMonoidalCategory SdcCategory.{u} :=
  .ofChosenFiniteProducts ⟨asEmptyCone sdcTerminal, isTerminalSdc⟩
    (fun X Y => ⟨sdcBinaryFan X Y, sdcBinaryFanIsLimit X Y⟩)

attribute [local instance] sdcCartesianMonoidal

/-- The fixed-source exponential, acting on maps by postcomposition. -/
def sdcExponentFunctor (X : SdcCategory.{u}) : SdcCategory.{u} ⥤ SdcCategory.{u} where
  obj Y := ⟨(sdcExponents X.property Y.property).space,
    (sdcExponents X.property Y.property).belongs⟩
  map {Y Y'} g := by
    let E := sdcExponents X.property Y.property
    let E' := sdcExponents X.property Y'.property
    let P := sdcProducts E.belongs X.property
    let f : Cont P.space Y'.val := ⟨fun p => g.val (p.1.val p.2),
      @Continuous.comp _ _ _ P.spaceTopology Y.val.topology Y'.val.topology
        _ _ g.property E.evaluation_continuous⟩
    exact ⟨transpose P X.property f, E'.transpose_continuous E.belongs f⟩
  map_id _ := rfl
  map_comp _ _ := rfl

private def tensorCurry (X Z Y : SdcCategory.{u}) (f : (tensorLeft X).obj Z ⟶ Y) :
    Z ⟶ (sdcExponentFunctor X).obj Y := by
  let P := sdcProducts X.property Z.property
  let P' := sdcProducts Z.property X.property
  have hs : @Continuous _ _ P'.spaceTopology P.spaceTopology Prod.swap :=
    P.pair_continuous P'.space P'.belongs ⟨Prod.snd, P'.snd_continuous⟩
      ⟨Prod.fst, P'.fst_continuous⟩
  let G : Cont P'.space Y.val := ⟨f.val ∘ Prod.swap,
    @Continuous.comp _ _ _ P'.spaceTopology P.spaceTopology Y.val.topology _ _ f.property hs⟩
  exact ⟨transpose P' X.property G,
    (sdcExponents X.property Y.property).transpose_continuous Z.property G⟩

private def tensorUncurry (X Z Y : SdcCategory.{u}) (g : Z ⟶ (sdcExponentFunctor X).obj Y) :
    (tensorLeft X).obj Z ⟶ Y := by
  let P := sdcProducts X.property Z.property
  let E := sdcExponents X.property Y.property
  let P' := sdcProducts E.belongs X.property
  have hg : @Continuous _ _ P.spaceTopology E.spaceTopology (fun p => g.val p.2) :=
    @Continuous.comp _ _ _ P.spaceTopology Z.val.topology E.spaceTopology
      _ _ g.property P.snd_continuous
  have hp : @Continuous _ _ P.spaceTopology P'.spaceTopology (fun p => (g.val p.2, p.1)) :=
    P'.pair_continuous P.space P.belongs ⟨_,hg⟩ ⟨Prod.fst, P.fst_continuous⟩
  exact ⟨fun p => (g.val p.2).val p.1,
    @Continuous.comp _ _ _ P.spaceTopology P'.spaceTopology Y.val.topology
      _ _ E.evaluation_continuous hp⟩

/-- Currying and uncurrying give the categorical hom-set equivalence. -/
def sdcTensorHomEquiv (X Z Y : SdcCategory.{u}) :
    ((tensorLeft X).obj Z ⟶ Y) ≃ (Z ⟶ (sdcExponentFunctor X).obj Y) where
  toFun := tensorCurry X Z Y
  invFun := tensorUncurry X Z Y
  left_inv _ := rfl
  right_inv _ := rfl

/-- The exponential is right adjoint to the chosen product with the source. -/
def sdcTensorAdjunction (X : SdcCategory.{u}) : tensorLeft X ⊣ sdcExponentFunctor X :=
  Adjunction.mkOfHomEquiv {
    homEquiv := sdcTensorHomEquiv X
    homEquiv_naturality_left_symm := fun _ _ => rfl
    homEquiv_naturality_right := fun _ _ => rfl }

/-- Categorical form of `thm:CCC` in Mathlib's Cartesian monoidal API. -/
@[implicit_reducible]
def sdcMonoidalClosed : MonoidalClosed SdcCategory.{u} where
  closed X := ⟨sdcExponentFunctor X, sdcTensorAdjunction X⟩

end ScottDCompletable
