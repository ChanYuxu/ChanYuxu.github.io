import Mathlib.CategoryTheory.Limits.Shapes.IsTerminal
import Mathlib.CategoryTheory.Monoidal.Cartesian.Basic
import Mathlib.Order.Category.PartOrd
import Mathlib.CategoryTheory.Adjunction.Reflective
import Mathlib.CategoryTheory.Monoidal.Closed.Basic
import Mathlib.CategoryTheory.ObjectProperty.FullSubcategory
import Mathlib.Order.ScottContinuity.Prod
import Mathlib.Tactic.Choose
import Mathlib.Tactic.Push
import Mathlib.Topology.Category.TopCat.Basic
import Mathlib.Topology.Order.ScottTopology
import Mathlib.Topology.Sets.Closeds

/-!
Proof bodies reused from the earlier Scott D-completable spaces formalization.
Each source module is scoped separately and its original imports are ordered
through the dependency graph. See audit/legacy-provenance.json for source hashes.
-/

set_option linter.unusedVariables false

/- Source module PMRVerifier.Statements.N043 -/
section
universe u

namespace PMRVerifier

noncomputable def node_N043 : (
(∀ (X : Type u) (t : TopologicalSpace X) (hT0 : @T0Space X t),
  {o : PartialOrder X //
    (∀ (x y : X), o.le x y ↔ x ∈ @closure X t ({y} : Set X)) ∧
    (∀ (U : Set X), @IsOpen X t U →
      ∀ (x y : X), o.le x y → x ∈ U → y ∈ U)}) ×
(∀ (P : Type u) (o : PartialOrder P), Set P → Prop)
) := (
⟨(fun X t hT0 =>
  letI : TopologicalSpace X := t
  letI : T0Space X := hT0
  ⟨specializationOrder X,
    ⟨(fun x y => specializes_iff_mem_closure),
     (fun U hU x y hxy hx => Specializes.mem_open hxy hU hx)⟩⟩),
 (fun P o A => A.Nonempty ∧ DirectedOn o.le A)⟩
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N043 -/
section

end

/- Source module PMRVerifier.Statements.N001 -/
section
universe u

namespace PMRVerifier

noncomputable def node_N001 : (
(∀ (X : Type u) (t : TopologicalSpace X) (hT0 : @T0Space X t),
  (Set X → Prop) × Prop) ×
(Σ (C : Type (u + 1)), CategoryTheory.Category.{u} C)
) := (
let predicates : ∀ (X : Type u) (t : TopologicalSpace X)
    (hT0 : @T0Space X t), (Set X → Prop) × Prop :=
  fun X t hT0 =>
    let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
    let directedOpen : Set X → Prop := fun U =>
      ∀ (A : Set X), PMRVerifier.node_N043.2 X o A →
        ∀ (x : X), x ∈ U →
          (∀ (V : Set X), @IsOpen X t V → x ∈ V →
            ∃ (a : X), a ∈ A ∧
              ∀ (b : X), b ∈ A → o.le a b → b ∈ V) →
          (A ∩ U).Nonempty
    ⟨directedOpen,
      ∀ (U : Set X), directedOpen U → @IsOpen X t U⟩
let t0Property : CategoryTheory.ObjectProperty TopCat.{u} :=
  fun X => @T0Space X X.str
let Top0 := CategoryTheory.ObjectProperty.FullSubcategory t0Property
let mdProperty : CategoryTheory.ObjectProperty Top0 :=
  fun X => (predicates X.obj X.obj.str X.property).2
let Topmd := CategoryTheory.ObjectProperty.FullSubcategory mdProperty
⟨predicates, ⟨Topmd, inferInstance⟩⟩
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N001 -/
section

end

/- Source module PMRVerifier.Statements.N002 -/
section
universe u

namespace PMRVerifier

noncomputable def node_N002 : (
∀ (P : Type u) (o : PartialOrder P),
  letI : PartialOrder P := o
  (Set P → Prop) × TopologicalSpace P × (Set P → Set P) ×
    (∀ (hDcpo : ∀ (E : Set P),
      (PMRVerifier.node_N043).2 P o E → ∃ (s : P), IsLUB E s),
      (Set P → Prop) × (Set P → Set P))
) := (
fun P o =>
  letI : PartialOrder P := o
  let dClosed : Set P → Prop := fun A =>
    ∀ (E : Set P), E ⊆ A → (PMRVerifier.node_N043).2 P o E →
      ∀ (s : P), IsLUB E s → s ∈ A
  let dTopology : TopologicalSpace P := TopologicalSpace.ofClosed
    {A : Set P | dClosed A}
    (by
      intro E hE hdir s hs
      change E.Nonempty ∧ DirectedOn o.le E at hdir
      obtain ⟨x, hx⟩ := hdir.1
      exact False.elim (hE hx))
    (by
      intro F hF E hEF hdir s hs
      apply Set.mem_sInter.mpr
      intro A hA
      exact hF hA E (fun x hx => Set.mem_sInter.mp (hEF hx) A hA) hdir s hs)
    (by
      classical
      intro A hA B hB E hE hdir s hs
      change E.Nonempty ∧ DirectedOn o.le E at hdir
      have hCof : ∀ (C : Set P), C ⊆ E →
          (∀ x ∈ E, ∃ y ∈ C, x ≤ y) →
          (PMRVerifier.node_N043).2 P o C ∧ IsLUB C s := by
        intro C hCE hcof
        constructor
        · change C.Nonempty ∧ DirectedOn o.le C
          constructor
          · obtain ⟨x, hx⟩ := hdir.1
            obtain ⟨y, hy, hxy⟩ := hcof x hx
            exact ⟨y, hy⟩
          · intro x hx y hy
            obtain ⟨z, hz, hxz, hyz⟩ := hdir.2 x (hCE hx) y (hCE hy)
            obtain ⟨w, hw, hzw⟩ := hcof z hz
            exact ⟨w, hw, le_trans hxz hzw, le_trans hyz hzw⟩
        · constructor
          · intro x hx
            exact hs.1 (hCE hx)
          · intro z hz
            apply hs.2
            intro x hx
            obtain ⟨y, hy, hxy⟩ := hcof x hx
            exact le_trans hxy (hz hy)
      by_cases hcof : ∀ x ∈ E, ∃ y ∈ E ∩ A, x ≤ y
      · obtain ⟨hdirA, hsupA⟩ := hCof (E ∩ A) (fun x hx => hx.1) hcof
        exact Or.inl (hA (E ∩ A) (fun x hx => hx.2) hdirA s hsupA)
      · push_neg at hcof
        obtain ⟨x, hx, hxA⟩ := hcof
        have hcofB : ∀ y ∈ E, ∃ z ∈ E ∩ B, y ≤ z := by
          intro y hy
          obtain ⟨z, hz, hxz, hyz⟩ := hdir.2 x hx y hy
          have hzNotA : z ∉ A := fun hzA => hxA z ⟨hz, hzA⟩ hxz
          exact ⟨z, ⟨hz, (hE hz).resolve_left hzNotA⟩, hyz⟩
        obtain ⟨hdirB, hsupB⟩ := hCof (E ∩ B) (fun y hy => hy.1) hcofB
        exact Or.inr (hB (E ∩ B) (fun y hy => hy.2) hdirB s hsupB))
  ⟨dClosed, dTopology, @closure P dTopology,
    fun hDcpo =>
      let subDcpo : Set P → Prop := fun K =>
        ∀ (E : Set P), E ⊆ K → (PMRVerifier.node_N043).2 P o E →
          ∃ (s : P), IsLUB E s ∧ s ∈ K
      ⟨subDcpo, fun A => ⋂₀ {K : Set P | subDcpo K ∧ A ⊆ K}⟩⟩
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N002 -/
section

end

/- Source module PMRVerifier.Statements.N044 -/
section
universe u

namespace PMRVerifier

noncomputable def node_N044 : (
∀ (P : Type u) (o : PartialOrder P), TopologicalSpace P × TopCat.{u}
) := (
fun (P : Type u) (o : PartialOrder P) =>
  let σ : TopologicalSpace P := @Topology.scott P (Set.univ : Set (Set P)) o.toPreorder
  (⟨σ, @TopCat.of P σ⟩ : TopologicalSpace P × TopCat.{u})
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N044 -/
section

end

/- Source module PMRVerifier.Statements.N003 -/
section
universe u v

namespace PMRVerifier

noncomputable def node_N003 : (
(∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM), Prop) ×
(∀ (X : Type u) (tX : TopologicalSpace X) (hX : @T0Space X tX)
  (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
  (η : X → M), Prop)
) := (
let monotoneConvergence :
    ∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM), Prop :=
  fun M tM hM =>
    let o : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
    letI : PartialOrder M := o
    (∀ (E : Set M), (PMRVerifier.node_N043).2 M o E →
      ∃ (s : M), IsLUB E s) ∧
    (∀ (U : Set M), @IsOpen M tM U →
      @IsOpen M (PMRVerifier.node_N044 M o).1 U)
⟨monotoneConvergence,
  fun X tX hX M tM hM η =>
    let o : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
    Function.Injective η ∧
    tX = TopologicalSpace.induced η tM ∧
    monotoneConvergence M tM hM ∧
    (PMRVerifier.node_N002 M o).2.2.1 (Set.range η) = (Set.univ : Set M)⟩
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N003 -/
section

end

/- Source module PMRVerifier.Statements.N040 -/
section
universe u

namespace PMRVerifier

def spec_N040 : Prop := (
∀ (X : Type u) (tX : TopologicalSpace X) (hX : @T0Space X tX),
  letI : TopologicalSpace X := tX
  let S := TopologicalSpace.IrreducibleCloseds X
  let oS : PartialOrder S := inferInstance
  letI : PartialOrder S := oS
  let tS : TopologicalSpace S := TopologicalSpace.generateFrom
    {V : Set S | ∃ (U : Set X), @IsOpen X tX U ∧
      V = {F : S | ((F : Set X) ∩ U).Nonempty}}
  let ε : X → S := fun x =>
    ⟨@closure X tX ({x} : Set X),
      (isIrreducible_singleton (x := x)).closure,
      @isClosed_closure X tX ({x} : Set X)⟩
  let C : Set S := Set.sInter
    {K : Set S | Set.range ε ⊆ K ∧
      ∀ (E : Set S), E ⊆ K →
        (PMRVerifier.node_N043).2 S oS E →
        ∀ (s : S), IsLUB E s → s ∈ K}
  let D := {F : S // F ∈ C}
  let tD : TopologicalSpace D :=
    TopologicalSpace.induced (fun F : D => (F : S)) tS
  let η : X → D := fun x =>
    ⟨ε x, Set.mem_sInter.mpr
      (fun K hK => hK.1 ⟨x, rfl⟩)⟩
  ∃ (hD : @T0Space D tD),
    (PMRVerifier.node_N003).2 X tX hX D tD hD η ∧
    (∀ (U : Set D), @IsOpen D tD U →
      @IsOpen D
        (PMRVerifier.node_N044 D
          ((PMRVerifier.node_N043).1 D tD hD).1).1 U)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N040 -/
section
universe u

namespace PMRVerifier

theorem node_N040 : (
∀ (X : Type u) (tX : TopologicalSpace X) (hX : @T0Space X tX),
  letI : TopologicalSpace X := tX
  let S := TopologicalSpace.IrreducibleCloseds X
  let oS : PartialOrder S := inferInstance
  letI : PartialOrder S := oS
  let tS : TopologicalSpace S := TopologicalSpace.generateFrom
    {V : Set S | ∃ (U : Set X), @IsOpen X tX U ∧
      V = {F : S | ((F : Set X) ∩ U).Nonempty}}
  let ε : X → S := fun x =>
    ⟨@closure X tX ({x} : Set X),
      (isIrreducible_singleton (x := x)).closure,
      @isClosed_closure X tX ({x} : Set X)⟩
  let C : Set S := Set.sInter
    {K : Set S | Set.range ε ⊆ K ∧
      ∀ (E : Set S), E ⊆ K →
        (PMRVerifier.node_N043).2 S oS E →
        ∀ (s : S), IsLUB E s → s ∈ K}
  let D := {F : S // F ∈ C}
  let tD : TopologicalSpace D :=
    TopologicalSpace.induced (fun F : D => (F : S)) tS
  let η : X → D := fun x =>
    ⟨ε x, Set.mem_sInter.mpr
      (fun K hK => hK.1 ⟨x, rfl⟩)⟩
  ∃ (hD : @T0Space D tD),
    (PMRVerifier.node_N003).2 X tX hX D tD hD η ∧
    (∀ (U : Set D), @IsOpen D tD U →
      @IsOpen D
        (PMRVerifier.node_N044 D
          ((PMRVerifier.node_N043).1 D tD hD).1).1 U)
) := (
by
  classical
  intro X tX hX
  letI : TopologicalSpace X := tX
  letI : T0Space X := hX
  let S := TopologicalSpace.IrreducibleCloseds X
  let oS : PartialOrder S := inferInstance
  let tS : TopologicalSpace S := TopologicalSpace.generateFrom
    {V : Set S | ∃ U : Set X, IsOpen U ∧
      V = {F : S | ((F : Set X) ∩ U).Nonempty}}
  let ε : X → S := fun x =>
    ⟨closure ({x} : Set X), (isIrreducible_singleton (x := x)).closure,
      isClosed_closure⟩
  let C : Set S := Set.sInter
    {K : Set S | Set.range ε ⊆ K ∧
      ∀ E : Set S, E ⊆ K →
        (PMRVerifier.node_N043).2 S oS E → ∀ s : S, IsLUB E s → s ∈ K}
  let D := {F : S // F ∈ C}
  let tD : TopologicalSpace D := TopologicalSpace.induced (fun F : D => (F : S)) tS
  let η : X → D := fun x =>
    ⟨ε x, Set.mem_sInter.mpr (fun K hK => hK.1 ⟨x, rfl⟩)⟩
  change ∃ hD : @T0Space D tD,
    (PMRVerifier.node_N003.{u, u}).2 X tX hX D tD hD η ∧
      ∀ U : Set D, @IsOpen D tD U →
        @IsOpen D (PMRVerifier.node_N044 D
          ((PMRVerifier.node_N043).1 D tD hD).1).1 U
  have hSupS : ∀ E : Set S, E.Nonempty → DirectedOn (· ≤ ·) E →
      ∃ s : S, IsLUB E s ∧
        (s : Set X) = closure {x | ∃ F ∈ E, x ∈ (F : Set X)} := by
    intro E hne hdir
    let A : Set X := {x | ∃ F ∈ E, x ∈ (F : Set X)}
    have hA : IsIrreducible A := by
      constructor
      · obtain ⟨F, hF⟩ := hne
        obtain ⟨x, hx⟩ := F.isIrreducible.nonempty
        exact ⟨x, F, hF, hx⟩
      · intro U V hU hV hx hy
        obtain ⟨x, ⟨F, hF, hxF⟩, hxU⟩ := hx
        obtain ⟨y, ⟨G, hG, hyG⟩, hyV⟩ := hy
        obtain ⟨H, hH, hFH, hGH⟩ := hdir F hF G hG
        obtain ⟨z, hzH, hzUV⟩ := H.isIrreducible.isPreirreducible U V hU hV
          ⟨x, hFH hxF, hxU⟩ ⟨y, hGH hyG, hyV⟩
        exact ⟨z, ⟨H, hH, hzH⟩, hzUV⟩
    let s : S := ⟨closure A, hA.closure, isClosed_closure⟩
    refine ⟨s, ⟨?_, ?_⟩, rfl⟩
    · intro F hF x hx
      exact subset_closure ⟨F, hF, hx⟩
    · intro G hG
      exact closure_minimal (by rintro x ⟨F, hF, hx⟩; exact hG hF hx) G.isClosed
  have hInaccS : ∀ (E : Set S), E.Nonempty → DirectedOn (· ≤ ·) E →
      ∀ (s : S), IsLUB E s → ∀ U : Set X, IsOpen U →
      ((s : Set X) ∩ U).Nonempty →
      ∃ F ∈ E, ((F : Set X) ∩ U).Nonempty := by
    intro E hne hdir s hs U hU hsU
    obtain ⟨s', hs', heq⟩ := hSupS E hne hdir
    have he : s = s' := hs.unique hs'
    rw [he, heq] at hsU
    obtain ⟨x, ⟨F, hF, hxF⟩, hxU⟩ := (closure_inter_open_nonempty_iff hU).mp hsU
    exact ⟨F, hF, x, hxF, hxU⟩
  have hScottS : Topology.scott S (Set.univ : Set (Set S)) ≤ tS := by
    letI : TopologicalSpace S := Topology.scott S Set.univ
    letI : Topology.IsScott S Set.univ := ⟨rfl⟩
    apply TopologicalSpace.le_generateFrom_iff_subset_isOpen.mpr
    rintro V ⟨U, hU, rfl⟩
    change IsOpen {F : S | ((F : Set X) ∩ U).Nonempty}
    apply (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn (D := Set.univ)).mpr
    constructor
    · intro F G hFG hF
      obtain ⟨x, hxF, hxU⟩ := hF
      exact ⟨x, hFG hxF, hxU⟩
    · intro E _ hne hdir s hs hsU
      exact hInaccS E hne hdir s hs U hU hsU
  letI : TopologicalSpace S := tS
  letI : TopologicalSpace D := tD
  have hOpenS : ∀ V : Set S, IsOpen V →
      IsUpperSet V ∧ DirSupInaccOn (Set.univ : Set (Set S)) V := by
    intro V hV
    letI : TopologicalSpace S := Topology.scott S Set.univ
    letI : Topology.IsScott S Set.univ := ⟨rfl⟩
    exact (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn (D := Set.univ)).mp
      (hScottS V hV)
  have hBasic : ∀ U : Set X, IsOpen U →
      IsOpen ({F : S | ((F : Set X) ∩ U).Nonempty} : Set S) := by
    intro U hU
    exact TopologicalSpace.isOpen_generateFrom_of_mem ⟨U, hU, rfl⟩
  have hSpecS : ∀ F G : S, F ∈ closure ({G} : Set S) ↔ F ≤ G := by
    intro F G
    constructor
    · intro h x hx
      by_contra hn
      have hg := (specializes_iff_mem_closure.mpr h).mem_open
        (hBasic (G : Set X)ᶜ G.isClosed.isOpen_compl) ⟨x, hx, hn⟩
      obtain ⟨y, hy, hny⟩ := hg
      exact hny hy
    · intro h
      apply specializes_iff_mem_closure.mp
      apply specializes_iff_forall_open.mpr
      intro V hV hF
      exact (hOpenS V hV).1 h hF
  have hT0S : T0Space S := by
    constructor
    intro F G h
    exact le_antisymm ((hSpecS F G).mp h.symm.specializes.mem_closure)
      ((hSpecS G F).mp h.specializes.mem_closure)
  letI : T0Space S := hT0S
  have hD : T0Space D := inferInstance
  have hOrderD : ((PMRVerifier.node_N043).1 D tD hD).1 =
      (inferInstance : PartialOrder D) := by
    apply PartialOrder.ext
    intro F G
    change @Specializes D tD G F ↔ F.val ≤ G.val
    rw [subtype_specializes_iff]
    exact specializes_iff_mem_closure.trans (hSpecS F.val G.val)
  have hCC : ∀ E : Set S, E ⊆ C → E.Nonempty → DirectedOn (· ≤ ·) E →
      ∀ s : S, IsLUB E s → s ∈ C := by
    intro E hEC hne hdir s hs
    apply Set.mem_sInter.mpr
    intro K hK
    exact hK.2 E (fun F hF => Set.mem_sInter.mp (hEC hF) K hK)
      ⟨hne, hdir⟩ s hs
  have hImgDir : ∀ E : Set D, E.Nonempty → DirectedOn (· ≤ ·) E →
      ((Subtype.val : D → S) '' E).Nonempty ∧
      DirectedOn (· ≤ ·) ((Subtype.val : D → S) '' E) := by
    intro E hne hdir
    constructor
    · exact hne.image _
    · rintro F ⟨f, hf, rfl⟩ G ⟨g, hg, rfl⟩
      obtain ⟨k, hk, hfk, hgk⟩ := hdir f hf g hg
      exact ⟨k.val, ⟨k, hk, rfl⟩, hfk, hgk⟩
  have hSupD : ∀ E : Set D, E.Nonempty → DirectedOn (· ≤ ·) E →
      ∃ s : D, IsLUB E s ∧ IsLUB ((Subtype.val : D → S) '' E) s.val := by
    intro E hne hdir
    have hi := hImgDir E hne hdir
    obtain ⟨s, hs, _⟩ := hSupS _ hi.1 hi.2
    have hsC : s ∈ C := hCC _ (by rintro F ⟨f, hf, rfl⟩; exact f.property)
      hi.1 hi.2 s hs
    refine ⟨⟨s, hsC⟩, ⟨?_, ?_⟩, hs⟩
    · intro f hf
      exact hs.1 ⟨f, hf, rfl⟩
    · intro f hf
      exact hs.2 (by rintro G ⟨g, hg, rfl⟩; exact hf hg)
  have hLift : ∀ E : Set D, E.Nonempty → DirectedOn (· ≤ ·) E →
      ∀ s : D, IsLUB E s → IsLUB ((Subtype.val : D → S) '' E) s.val := by
    intro E hne hdir s hs
    obtain ⟨s', hs', hi⟩ := hSupD E hne hdir
    have he : s = s' := hs.unique hs'
    simpa only [he] using hi
  have hScottD : ∀ U : Set D, IsOpen U →
      @IsOpen D (PMRVerifier.node_N044 D (inferInstance : PartialOrder D)).1 U := by
    intro U hU
    obtain ⟨V, hV, rfl⟩ := isOpen_induced_iff.mp hU
    letI : TopologicalSpace D := Topology.scott D Set.univ
    letI : Topology.IsScott D Set.univ := ⟨rfl⟩
    change IsOpen ((Subtype.val : D → S) ⁻¹' V)
    apply (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn (D := Set.univ)).mpr
    constructor
    · intro f g hfg hf
      exact (hOpenS V hV).1 hfg hf
    · intro E _ hne hdir s hs hsU
      have hi := hImgDir E hne hdir
      obtain ⟨F, ⟨f, hf, rfl⟩, hF⟩ :=
        (hOpenS V hV).2 (Set.mem_univ _) hi.1 hi.2 (hLift E hne hdir s hs) hsU
      exact ⟨f, hf, hF⟩
  have hPre : ∀ U : Set X, IsOpen U →
      ε ⁻¹' {F : S | ((F : Set X) ∩ U).Nonempty} = U := by
    intro U hU
    ext x
    change (closure ({x} : Set X) ∩ U).Nonempty ↔ x ∈ U
    rw [closure_inter_open_nonempty_iff hU]
    simp only [Set.singleton_inter_nonempty]
  have hεcont : @Continuous X S tX tS ε := by
    apply continuous_generateFrom_iff.mpr
    rintro V ⟨U, hU, rfl⟩
    rw [hPre U hU]
    exact hU
  have hεtop : tX = TopologicalSpace.induced ε tS := by
    apply le_antisymm (continuous_iff_le_induced.mp hεcont)
    intro U hU
    exact isOpen_induced_iff.mpr ⟨_, hBasic U hU, hPre U hU⟩
  have hηtop : tX = TopologicalSpace.induced η tD := by
    change tX = TopologicalSpace.induced η
      (TopologicalSpace.induced (Subtype.val : D → S) tS)
    rw [induced_compose]
    exact hεtop
  have hηinj : Function.Injective η := by
    intro x y he
    have hc := congrArg (fun d : D => (d.val : Set X)) he
    change closure ({x} : Set X) = closure ({y} : Set X) at hc
    exact (inseparable_iff_closure_eq.mpr hc).eq
  have hDense : (PMRVerifier.node_N002 D (inferInstance : PartialOrder D)).2.2.1
      (Set.range η) = (Set.univ : Set D) := by
    change @closure D (PMRVerifier.node_N002 D (inferInstance : PartialOrder D)).2.1
      (Set.range η) = (Set.univ : Set D)
    apply Set.eq_univ_of_forall
    intro d
    apply Set.mem_sInter.mpr
    intro A hA
    have hAc := hA.1.isOpen_compl
    change (∀ E : Set D, E ⊆ Aᶜᶜ →
      (PMRVerifier.node_N043).2 D (inferInstance : PartialOrder D) E →
      ∀ s : D, IsLUB E s → s ∈ Aᶜᶜ) at hAc
    simp only [compl_compl] at hAc
    let K : Set S := (Subtype.val : D → S) '' A
    have hKR : Set.range ε ⊆ K := by
      rintro F ⟨x, rfl⟩
      exact ⟨η x, hA.2 ⟨x, rfl⟩, rfl⟩
    have hKC : ∀ E : Set S, E ⊆ K →
        (PMRVerifier.node_N043).2 S oS E →
        ∀ s : S, IsLUB E s → s ∈ K := by
      intro E hEK hdir s hs
      change E.Nonempty ∧ DirectedOn (· ≤ ·) E at hdir
      have hEC : E ⊆ C := by
        intro F hF
        obtain ⟨f, hf, rfl⟩ := hEK hF
        exact f.property
      have hsC : s ∈ C := hCC E hEC hdir.1 hdir.2 s hs
      let B : Set D := (Subtype.val : D → S) ⁻¹' E
      have hBne : B.Nonempty := by
        obtain ⟨F, hF⟩ := hdir.1
        exact ⟨⟨F, hEC hF⟩, hF⟩
      have hBdir : DirectedOn (· ≤ ·) B := by
        intro f hf g hg
        obtain ⟨H, hH, hfH, hgH⟩ := hdir.2 f.val hf g.val hg
        exact ⟨⟨H, hEC hH⟩, hH, hfH, hgH⟩
      have hBA : B ⊆ A := by
        intro f hf
        obtain ⟨g, hg, hgf⟩ := hEK hf
        have he : g = f := Subtype.ext hgf
        exact he ▸ hg
      have hsB : IsLUB B (⟨s, hsC⟩ : D) := by
        constructor
        · intro f hf
          exact hs.1 hf
        · intro f hf
          exact hs.2 (fun F hF => hf (show (⟨F, hEC hF⟩ : D) ∈ B from hF))
      exact ⟨⟨s, hsC⟩, hAc B hBA ⟨hBne, hBdir⟩ _ hsB, rfl⟩
    have hdK : d.val ∈ K := Set.mem_sInter.mp d.property K ⟨hKR, hKC⟩
    obtain ⟨a, ha, had⟩ := hdK
    exact (Subtype.ext had : a = d) ▸ ha
  have hM : (PMRVerifier.node_N003.{u, u}).1 D tD hD := by
    change (∀ E : Set D,
      (PMRVerifier.node_N043).2 D ((PMRVerifier.node_N043).1 D tD hD).1 E →
      ∃ s : D, @IsLUB D ((PMRVerifier.node_N043).1 D tD hD).1.toLE E s) ∧ _
    rw [hOrderD]
    constructor
    · intro E hE
      obtain ⟨s, hs, _⟩ := hSupD E hE.1 hE.2
      exact ⟨s, hs⟩
    · exact hScottD
  refine ⟨hD, ?_, ?_⟩
  · change Function.Injective η ∧ tX = TopologicalSpace.induced η tD ∧
      (PMRVerifier.node_N003.{u, u}).1 D tD hD ∧
      (PMRVerifier.node_N002 D ((PMRVerifier.node_N043).1 D tD hD).1).2.2.1
        (Set.range η) = (Set.univ : Set D)
    refine ⟨hηinj, hηtop, hM, ?_⟩
    rw [hOrderD]
    exact hDense
  · rw [hOrderD]
    exact hScottD

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N047 -/
section
universe u

namespace PMRVerifier

def spec_N047 : Prop := (
∀ (P : Type u) (o : PartialOrder P),
  letI : PartialOrder P := o
  ∀ (hDcpo : ∀ (E : Set P),
      (PMRVerifier.node_N043).2 P o E → ∃ (s : P), IsLUB E s)
    (A : Set P),
    (PMRVerifier.node_N002 P o).1 A ↔
      ((PMRVerifier.node_N002 P o).2.2.2 hDcpo).1 A
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N047 -/
section
universe u

namespace PMRVerifier

theorem node_N047 : (
∀ (P : Type u) (o : PartialOrder P),
  letI : PartialOrder P := o
  ∀ (hDcpo : ∀ (E : Set P),
      (PMRVerifier.node_N043).2 P o E → ∃ (s : P), IsLUB E s)
    (A : Set P),
    (PMRVerifier.node_N002 P o).1 A ↔
      ((PMRVerifier.node_N002 P o).2.2.2 hDcpo).1 A
) := (
by
  intro P o
  letI : PartialOrder P := o
  intro hDcpo A
  change
    (∀ (E : Set P), E ⊆ A → (PMRVerifier.node_N043).2 P o E →
      ∀ (s : P), IsLUB E s → s ∈ A) ↔
    (∀ (E : Set P), E ⊆ A → (PMRVerifier.node_N043).2 P o E →
      ∃ (s : P), IsLUB E s ∧ s ∈ A)
  constructor
  · intro hClosed E hEA hDir
    obtain ⟨s, hs⟩ := hDcpo E hDir
    exact ⟨s, hs, hClosed E hEA hDir s hs⟩
  · intro hSub E hEA hDir s hs
    obtain ⟨t, ht, htA⟩ := hSub E hEA hDir
    have hst : s = t := le_antisymm (hs.2 ht.1) (ht.2 hs.1)
    exact hst.symm ▸ htA
)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N004 -/
section
universe u v w

namespace PMRVerifier

def spec_N004 : Prop := (
∀ (X : Type u) (tX : TopologicalSpace X) (hX : @T0Space X tX),
  letI : TopologicalSpace X := tX
  let S := TopologicalSpace.IrreducibleCloseds X
  let oS : PartialOrder S := inferInstance
  letI : PartialOrder S := oS
  let tS : TopologicalSpace S := TopologicalSpace.generateFrom
    {V : Set S | ∃ (U : Set X), @IsOpen X tX U ∧
      V = {F : S | ((F : Set X) ∩ U).Nonempty}}
  let ε : X → S := fun x =>
    ⟨@closure X tX ({x} : Set X),
      (isIrreducible_singleton (x := x)).closure,
      @isClosed_closure X tX ({x} : Set X)⟩
  let C : Set S := Set.sInter
    {K : Set S | Set.range ε ⊆ K ∧
      ∀ (E : Set S), E ⊆ K →
        (PMRVerifier.node_N043).2 S oS E →
        ∀ (s : S), IsLUB E s → s ∈ K}
  let D := {F : S // F ∈ C}
  let tD : TopologicalSpace D :=
    TopologicalSpace.induced (fun F : D => (F : S)) tS
  let η : X → D := fun x =>
    ⟨ε x, Set.mem_sInter.mpr
      (fun K hK => hK.1 ⟨x, rfl⟩)⟩
  ((∃ (hD : @T0Space D tD),
      (PMRVerifier.node_N003.{u, u}).2 X tX hX D tD hD η ∧
      (∀ (N : Type v) (tN : TopologicalSpace N) (hN : @T0Space N tN),
        (PMRVerifier.node_N003.{u, v}).1 N tN hN →
        ∀ (f : X → N), @Continuous X N tX tN f →
          ∃! (g : D → N),
            @Continuous D N tD tN g ∧
            (∀ (x : X), g (η x) = f x))) ∧
    (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
      (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN)
      (ι : X → M) (κ : X → N),
      (PMRVerifier.node_N003.{u, v}).2 X tX hX M tM hM ι →
      (PMRVerifier.node_N003.{u, w}).2 X tX hX N tN hN κ →
        ∃! (e : @Homeomorph M N tM tN),
          ∀ (x : X), e (ι x) = κ x)) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (ι : X → M),
    (PMRVerifier.node_N003.{u, v}).2 X tX hX M tM hM ι →
    ∀ (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN),
      (PMRVerifier.node_N003.{u, w}).1 N tN hN →
      ∀ (f : X → N), @Continuous X N tX tN f →
        ∃! (g : M → N),
          @Continuous M N tM tN g ∧
          (∀ (x : X), g (ι x) = f x)) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN),
    (PMRVerifier.node_N003.{u, v}).1 M tM hM →
    (PMRVerifier.node_N003.{u, w}).1 N tN hN →
    ∀ (f : M → N), @Continuous M N tM tN f →
      let oM : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
      let oN : PartialOrder N := ((PMRVerifier.node_N043).1 N tN hN).1
      letI : PartialOrder M := oM
      letI : PartialOrder N := oN
      (∀ (a b : M), oM.le a b → oN.le (f a) (f b)) ∧
      (∀ (E : Set M), (PMRVerifier.node_N043).2 M oM E →
        ∀ (s : M), IsLUB E s → IsLUB (f '' E) (f s))) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (hMC : (PMRVerifier.node_N003.{u, v}).1 M tM hM),
      let oM : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
      letI : PartialOrder M := oM
      let hDcpo : ∀ (E : Set M), (PMRVerifier.node_N043).2 M oM E →
          ∃ (s : M), IsLUB E s := hMC.1
      ∀ (K : Set M),
        ((PMRVerifier.node_N002 M oM).2.2.2 hDcpo).1 K ↔
          (PMRVerifier.node_N002 M oM).1 K) ∧
  (∀ (P : Type v) (oP : PartialOrder P)
    (Q : Type w) (oQ : PartialOrder Q),
      letI : PartialOrder P := oP
      letI : PartialOrder Q := oQ
      let oPQ : PartialOrder (P × Q) := inferInstance
      ∀ (A : Set P) (B : Set Q),
        (PMRVerifier.node_N002 (P × Q) oPQ).2.2.1 (A ×ˢ B) =
          ((PMRVerifier.node_N002 P oP).2.2.1 A) ×ˢ
            ((PMRVerifier.node_N002 Q oQ).2.2.1 B)) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (ι : X → M),
    (PMRVerifier.node_N003.{u, v}).2 X tX hX M tM hM ι →
      let oM : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
      @Continuous X M tX (PMRVerifier.node_N044 M oM).1 ι →
        tM = (PMRVerifier.node_N044 M oM).1)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N004 -/
section
universe u v w

namespace PMRVerifier

theorem node_N004 : (
∀ (X : Type u) (tX : TopologicalSpace X) (hX : @T0Space X tX),
  letI : TopologicalSpace X := tX
  let S := TopologicalSpace.IrreducibleCloseds X
  let oS : PartialOrder S := inferInstance
  letI : PartialOrder S := oS
  let tS : TopologicalSpace S := TopologicalSpace.generateFrom
    {V : Set S | ∃ (U : Set X), @IsOpen X tX U ∧
      V = {F : S | ((F : Set X) ∩ U).Nonempty}}
  let ε : X → S := fun x =>
    ⟨@closure X tX ({x} : Set X),
      (isIrreducible_singleton (x := x)).closure,
      @isClosed_closure X tX ({x} : Set X)⟩
  let C : Set S := Set.sInter
    {K : Set S | Set.range ε ⊆ K ∧
      ∀ (E : Set S), E ⊆ K →
        (PMRVerifier.node_N043).2 S oS E →
        ∀ (s : S), IsLUB E s → s ∈ K}
  let D := {F : S // F ∈ C}
  let tD : TopologicalSpace D :=
    TopologicalSpace.induced (fun F : D => (F : S)) tS
  let η : X → D := fun x =>
    ⟨ε x, Set.mem_sInter.mpr
      (fun K hK => hK.1 ⟨x, rfl⟩)⟩
  ((∃ (hD : @T0Space D tD),
      (PMRVerifier.node_N003.{u, u}).2 X tX hX D tD hD η ∧
      (∀ (N : Type v) (tN : TopologicalSpace N) (hN : @T0Space N tN),
        (PMRVerifier.node_N003.{u, v}).1 N tN hN →
        ∀ (f : X → N), @Continuous X N tX tN f →
          ∃! (g : D → N),
            @Continuous D N tD tN g ∧
            (∀ (x : X), g (η x) = f x))) ∧
    (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
      (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN)
      (ι : X → M) (κ : X → N),
      (PMRVerifier.node_N003.{u, v}).2 X tX hX M tM hM ι →
      (PMRVerifier.node_N003.{u, w}).2 X tX hX N tN hN κ →
        ∃! (e : @Homeomorph M N tM tN),
          ∀ (x : X), e (ι x) = κ x)) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (ι : X → M),
    (PMRVerifier.node_N003.{u, v}).2 X tX hX M tM hM ι →
    ∀ (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN),
      (PMRVerifier.node_N003.{u, w}).1 N tN hN →
      ∀ (f : X → N), @Continuous X N tX tN f →
        ∃! (g : M → N),
          @Continuous M N tM tN g ∧
          (∀ (x : X), g (ι x) = f x)) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN),
    (PMRVerifier.node_N003.{u, v}).1 M tM hM →
    (PMRVerifier.node_N003.{u, w}).1 N tN hN →
    ∀ (f : M → N), @Continuous M N tM tN f →
      let oM : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
      let oN : PartialOrder N := ((PMRVerifier.node_N043).1 N tN hN).1
      letI : PartialOrder M := oM
      letI : PartialOrder N := oN
      (∀ (a b : M), oM.le a b → oN.le (f a) (f b)) ∧
      (∀ (E : Set M), (PMRVerifier.node_N043).2 M oM E →
        ∀ (s : M), IsLUB E s → IsLUB (f '' E) (f s))) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (hMC : (PMRVerifier.node_N003.{u, v}).1 M tM hM),
      let oM : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
      letI : PartialOrder M := oM
      let hDcpo : ∀ (E : Set M), (PMRVerifier.node_N043).2 M oM E →
          ∃ (s : M), IsLUB E s := hMC.1
      ∀ (K : Set M),
        ((PMRVerifier.node_N002 M oM).2.2.2 hDcpo).1 K ↔
          (PMRVerifier.node_N002 M oM).1 K) ∧
  (∀ (P : Type v) (oP : PartialOrder P)
    (Q : Type w) (oQ : PartialOrder Q),
      letI : PartialOrder P := oP
      letI : PartialOrder Q := oQ
      let oPQ : PartialOrder (P × Q) := inferInstance
      ∀ (A : Set P) (B : Set Q),
        (PMRVerifier.node_N002 (P × Q) oPQ).2.2.1 (A ×ˢ B) =
          ((PMRVerifier.node_N002 P oP).2.2.1 A) ×ˢ
            ((PMRVerifier.node_N002 Q oQ).2.2.1 B)) ∧
  (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
    (ι : X → M),
    (PMRVerifier.node_N003.{u, v}).2 X tX hX M tM hM ι →
      let oM : PartialOrder M := ((PMRVerifier.node_N043).1 M tM hM).1
      @Continuous X M tX (PMRVerifier.node_N044 M oM).1 ι →
        tM = (PMRVerifier.node_N044 M oM).1)
) := (
by
  classical
  intro X tX hX
  letI : TopologicalSpace X := tX
  letI : T0Space X := hX
  have hExts :
    (∀ (M : Type u) (tM : TopologicalSpace M) (hM : @T0Space M tM)
      (ι : X → M), (node_N003.{u, u}).2 X tX hX M tM hM ι →
      ∀ (N : Type v) (tN : TopologicalSpace N) (hN : @T0Space N tN),
      (node_N003.{u, v}).1 N tN hN →
      ∀ (f : X → N), @Continuous X N tX tN f →
      ∃! g : M → N, @Continuous M N tM tN g ∧ ∀ x, g (ι x) = f x) ∧
    (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
      (ι : X → M), (node_N003.{u, v}).2 X tX hX M tM hM ι →
      ∀ (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN),
      (node_N003.{u, w}).1 N tN hN →
      ∀ (f : X → N), @Continuous X N tX tN f →
      ∃! g : M → N, @Continuous M N tM tN g ∧ ∀ x, g (ι x) = f x) ∧
    (∀ (M : Type w) (tM : TopologicalSpace M) (hM : @T0Space M tM)
      (ι : X → M), (node_N003.{u, w}).2 X tX hX M tM hM ι →
      ∀ (N : Type v) (tN : TopologicalSpace N) (hN : @T0Space N tN),
      (node_N003.{u, v}).1 N tN hN →
      ∀ (f : X → N), @Continuous X N tX tN f →
      ∃! g : M → N, @Continuous M N tM tN g ∧ ∀ x, g (ι x) = f x) ∧
    (∀ (M : Type v) (tM : TopologicalSpace M) (hM : @T0Space M tM)
      (ι : X → M), (node_N003.{u, v}).2 X tX hX M tM hM ι →
      ∀ (N : Type v) (tN : TopologicalSpace N) (hN : @T0Space N tN),
      (node_N003.{u, v}).1 N tN hN →
      ∀ (f : X → N), @Continuous X N tX tN f →
      ∃! g : M → N, @Continuous M N tM tN g ∧ ∀ x, g (ι x) = f x) ∧
    (∀ (M : Type w) (tM : TopologicalSpace M) (hM : @T0Space M tM)
      (ι : X → M), (node_N003.{u, w}).2 X tX hX M tM hM ι →
      ∀ (N : Type w) (tN : TopologicalSpace N) (hN : @T0Space N tN),
      (node_N003.{u, w}).1 N tN hN →
      ∀ (f : X → N), @Continuous X N tX tN f →
      ∃! g : M → N, @Continuous M N tM tN g ∧ ∀ x, g (ι x) = f x) := by
    refine ⟨?_, ?_, ?_, ?_, ?_⟩
    all_goals
      intro M tM hM ι hc N tN hN hn f hf
      letI : TopologicalSpace M := tM
      letI : T0Space M := hM
      letI : TopologicalSpace N := tN
      letI : T0Space N := hN
      let oM := ((node_N043).1 M tM hM).1
      let oN := ((node_N043).1 N tN hN).1
      letI : PartialOrder M := oM
      letI : PartialOrder N := oN
      have hOpenM : ∀ U : Set M, IsOpen U →
          IsUpperSet U ∧ DirSupInaccOn (Set.univ : Set (Set M)) U := by
        intro U hU
        letI : TopologicalSpace M := (node_N044 M oM).1
        letI : Topology.IsScott M Set.univ := ⟨rfl⟩
        exact (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn
          (D := Set.univ)).mp (hc.2.2.1.2 U hU)
      have hOpenN : ∀ U : Set N, IsOpen U →
          IsUpperSet U ∧ DirSupInaccOn (Set.univ : Set (Set N)) U := by
        intro U hU
        letI : TopologicalSpace N := (node_N044 N oN).1
        letI : Topology.IsScott N Set.univ := ⟨rfl⟩
        exact (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn
          (D := Set.univ)).mp (hn.2 U hU)
      have hPres : ∀ (g : M → N), Continuous g →
          ∀ E : Set M, E.Nonempty → DirectedOn (· ≤ ·) E →
          ∀ s : M, IsLUB E s → IsLUB (g '' E) (g s) := by
        intro g hg E hne hdir s hs
        constructor
        · rintro _ ⟨e, he, rfl⟩
          exact (hs.1 he).map hg
        · intro y hy
          change @Specializes N tN y (g s)
          apply specializes_iff_forall_open.mpr
          intro U hU hgs
          obtain ⟨e, he, hge⟩ := (hOpenM _ (hU.preimage hg)).2
            (Set.mem_univ E) hne hdir hs hgs
          exact (hOpenN U hU).1 (hy ⟨e, he, rfl⟩) hge
      have hDense : ∀ K : Set M, (node_N002 M oM).1 K →
          Set.range ι ⊆ K → ∀ m : M, m ∈ K := by
        intro K hK hIK m
        have hClosed : @IsClosed M (node_N002 M oM).2.1 K := by
          refine @IsClosed.mk M (node_N002 M oM).2.1 K ?_
          change (node_N002 M oM).1 Kᶜᶜ
          simpa only [compl_compl] using hK
        have hs := @closure_minimal M (node_N002 M oM).2.1
          (Set.range ι) K hIK hClosed
        change (node_N002 M oM).2.2.1 (Set.range ι) ⊆ K at hs
        rw [hc.2.2.2] at hs
        exact hs (Set.mem_univ m)
      let I := {U : Set N // IsOpen U}
      have hLift : ∀ U : I, ∃ V : Set M, IsOpen V ∧ ι ⁻¹' V = f ⁻¹' U.val := by
        intro U
        have hp := U.property.preimage hf
        rw [hc.2.1] at hp
        obtain ⟨V, hV, he⟩ := isOpen_induced_iff.mp hp
        exact ⟨V, hV, he⟩
      choose V hVo hVe using hLift
      let R : M → N → Prop := fun m n => ∀ U : I, m ∈ V U ↔ n ∈ U.val
      let K : Set M := {m | ∃ n : N, R m n}
      have hRmono : ∀ {a b : M} {n p : N}, R a n → R b p → a ≤ b → n ≤ p := by
        intro a b n p ha hb hab
        change @Specializes N tN p n
        apply specializes_iff_forall_open.mpr
        intro U hU hnU
        exact (hb ⟨U, hU⟩).mp ((hOpenM _ (hVo ⟨U, hU⟩)).1 hab
          ((ha ⟨U, hU⟩).mpr hnU))
      have hKC : (node_N002 M oM).1 K := by
        intro E hEK hdir s hs
        change E.Nonempty ∧ DirectedOn (· ≤ ·) E at hdir
        choose n hnR using (fun e : E => hEK e.property)
        have hTdir : DirectedOn (· ≤ ·) (Set.range n) := by
          rintro a ⟨e, rfl⟩ b ⟨d, rfl⟩
          obtain ⟨c, hcE, hec, hdc⟩ := hdir.2 e.val e.property d.val d.property
          exact ⟨n ⟨c, hcE⟩, ⟨⟨c, hcE⟩, rfl⟩,
            hRmono (hnR e) (hnR ⟨c, hcE⟩) hec,
            hRmono (hnR d) (hnR ⟨c, hcE⟩) hdc⟩
        have hTne : (Set.range n).Nonempty := by
          obtain ⟨e, he⟩ := hdir.1
          exact ⟨n ⟨e, he⟩, ⟨e, he⟩, rfl⟩
        obtain ⟨p, hp⟩ := hn.1 (Set.range n) ⟨hTne, hTdir⟩
        refine ⟨p, ?_⟩
        intro U
        constructor
        · intro hsU
          obtain ⟨e, he, heV⟩ := (hOpenM _ (hVo U)).2
            (Set.mem_univ E) hdir.1 hdir.2 hs hsU
          exact (hOpenN _ U.property).1 (hp.1 ⟨⟨e, he⟩, rfl⟩)
            ((hnR ⟨e, he⟩ U).mp heV)
        · intro hpU
          obtain ⟨q, ⟨e, rfl⟩, heU⟩ := (hOpenN _ U.property).2
            (Set.mem_univ _) hTne hTdir hp hpU
          exact (hOpenM _ (hVo U)).1 (hs.1 e.property) ((hnR e U).mpr heU)
      have hIK : Set.range ι ⊆ K := by
        rintro m ⟨x, rfl⟩
        refine ⟨f x, ?_⟩
        intro U
        exact Set.ext_iff.mp (hVe U) x
      have hTotal : ∀ m : M, ∃ n : N, R m n := hDense K hKC hIK
      choose g hgR using hTotal
      have hgcont : Continuous g := by
        apply continuous_def.mpr
        intro U hU
        have he : g ⁻¹' U = V ⟨U, hU⟩ := by
          ext m
          exact (hgR m ⟨U, hU⟩).symm
        rw [he]
        exact hVo ⟨U, hU⟩
      have hRuniq : ∀ m n p, R m n → R m p → n = p := by
        intro m n p hnR hpR
        exact le_antisymm (hRmono hnR hpR le_rfl) (hRmono hpR hnR le_rfl)
      have hgext : ∀ x, g (ι x) = f x := by
        intro x
        apply hRuniq (ι x) _ _ (hgR (ι x))
        intro U
        exact Set.ext_iff.mp (hVe U) x
      refine ⟨g, ⟨hgcont, hgext⟩, ?_⟩
      rintro h ⟨hhcont, hhext⟩
      apply funext
      intro m
      apply hDense {m | h m = g m} ?_ ?_ m
      · intro E hE hdir s hs
        have he : h '' E = g '' E := by
          apply Set.image_congr
          exact fun e he => hE he
        have hh := hPres h hhcont E hdir.1 hdir.2 s hs
        have hg := hPres g hgcont E hdir.1 hdir.2 s hs
        rw [he] at hh
        exact hh.unique hg
      · rintro y ⟨x, rfl⟩
        exact (hhext x).trans (hgext x).symm

  refine ⟨⟨?_, ?_⟩, ?_, ?_, ?_, ?_, ?_⟩
  · obtain ⟨hD, hc, hσ⟩ := node_N040 X tX hX
    refine ⟨hD, hc, ?_⟩
    intro N tN hN hn f hf
    exact hExts.1 _ _ hD _ hc N tN hN hn f hf
  · intro M tM hM N tN hN ι κ hc hd
    letI : TopologicalSpace M := tM
    letI : TopologicalSpace N := tN
    have hι : Continuous ι := continuous_iff_le_induced.mpr hc.2.1.le
    have hκ : Continuous κ := continuous_iff_le_induced.mpr hd.2.1.le
    obtain ⟨g, ⟨hg, hge⟩, hgu⟩ :=
      hExts.2.1 M tM hM ι hc N tN hN hd.2.2.1 κ hκ
    obtain ⟨h, ⟨hh, hhe⟩, hhu⟩ :=
      hExts.2.2.1 N tN hN κ hd M tM hM hc.2.2.1 ι hι
    obtain ⟨r, hr, hru⟩ :=
      hExts.2.2.2.1 M tM hM ι hc M tM hM hc.2.2.1 ι hι
    obtain ⟨s, hs, hsu⟩ :=
      hExts.2.2.2.2 N tN hN κ hd N tN hN hd.2.2.1 κ hκ
    have hleft : h ∘ g = id := by
      apply (hru _ ⟨hh.comp hg, ?_⟩).trans (hru _ ⟨continuous_id, fun _ => rfl⟩).symm
      intro x
      change h (g (ι x)) = ι x
      rw [hge, hhe]
    have hright : g ∘ h = id := by
      apply (hsu _ ⟨hg.comp hh, ?_⟩).trans (hsu _ ⟨continuous_id, fun _ => rfl⟩).symm
      intro x
      change g (h (κ x)) = κ x
      rw [hhe, hge]
    let e : @Homeomorph M N tM tN :=
      { toEquiv :=
          { toFun := g
            invFun := h
            left_inv := fun m => congrFun hleft m
            right_inv := fun n => congrFun hright n }
        continuous_toFun := hg
        continuous_invFun := hh }
    refine ⟨e, hge, ?_⟩
    intro e' he'
    apply Homeomorph.ext
    intro m
    exact congrFun (hgu (e' : M → N) ⟨e'.continuous, he'⟩) m
  · exact hExts.2.1
  · intro M tM hM N tN hN hm hn f hf
    letI : TopologicalSpace M := tM
    letI : T0Space M := hM
    letI : TopologicalSpace N := tN
    letI : T0Space N := hN
    let oM := ((node_N043).1 M tM hM).1
    let oN := ((node_N043).1 N tN hN).1
    letI : PartialOrder M := oM
    letI : PartialOrder N := oN
    have hOpenM : ∀ U : Set M, IsOpen U →
        IsUpperSet U ∧ DirSupInaccOn (Set.univ : Set (Set M)) U := by
      intro U hU
      letI : TopologicalSpace M := (node_N044 M oM).1
      letI : Topology.IsScott M Set.univ := ⟨rfl⟩
      exact (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn
        (D := Set.univ)).mp (hm.2 U hU)
    constructor
    · intro a b hab
      exact hab.map hf
    · intro E hdir s hs
      constructor
      · rintro _ ⟨e, he, rfl⟩
        exact (hs.1 he).map hf
      · intro y hy
        change @Specializes N tN y (f s)
        apply specializes_iff_forall_open.mpr
        intro U hU hfs
        obtain ⟨e, he, hfe⟩ := (hOpenM _ (hU.preimage hf)).2
          (Set.mem_univ E) hdir.1 hdir.2 hs hfs
        exact (((node_N043).1 N tN hN).2.2 U hU (f e) y
          (hy ⟨e, he, rfl⟩) hfe)
  · intro M tM hM hm
    dsimp only
    intro K
    exact (node_N047 M _ hm.1 K).symm
  · intro P oP Q oQ
    letI : PartialOrder P := oP
    letI : PartialOrder Q := oQ
    let oPQ : PartialOrder (P × Q) := inferInstance
    have hCls :
      (∀ (R : Type v) (o : PartialOrder R) (A : Set R),
        A ⊆ (node_N002 R o).2.2.1 A ∧
        (node_N002 R o).1 ((node_N002 R o).2.2.1 A) ∧
        ∀ K : Set R, (node_N002 R o).1 K → A ⊆ K →
          (node_N002 R o).2.2.1 A ⊆ K) ∧
      (∀ (R : Type w) (o : PartialOrder R) (A : Set R),
        A ⊆ (node_N002 R o).2.2.1 A ∧
        (node_N002 R o).1 ((node_N002 R o).2.2.1 A) ∧
        ∀ K : Set R, (node_N002 R o).1 K → A ⊆ K →
          (node_N002 R o).2.2.1 A ⊆ K) ∧
      (∀ (R : Type (max v w)) (o : PartialOrder R) (A : Set R),
        A ⊆ (node_N002 R o).2.2.1 A ∧
        (node_N002 R o).1 ((node_N002 R o).2.2.1 A) ∧
        ∀ K : Set R, (node_N002 R o).1 K → A ⊆ K →
          (node_N002 R o).2.2.1 A ⊆ K) := by
      refine ⟨?_, ?_, ?_⟩
      all_goals
        intro R o A
        letI : PartialOrder R := o
        letI : TopologicalSpace R := (node_N002 R o).2.1
        refine ⟨subset_closure, ?_, ?_⟩
        · have h := (@isClosed_closure R (node_N002 R o).2.1 A).isOpen_compl
          change (node_N002 R o).1 ((node_N002 R o).2.2.1 A)ᶜᶜ at h
          simpa only [compl_compl] using h
        · intro K hK hAK
          apply closure_minimal hAK
          refine @IsClosed.mk R (node_N002 R o).2.1 K ?_
          change (node_N002 R o).1 Kᶜᶜ
          simpa only [compl_compl] using hK
    dsimp only
    intro A B
    let cP := (node_N002 P oP).2.2.1
    let cQ := (node_N002 Q oQ).2.2.1
    let cPQ := (node_N002 (P × Q) oPQ).2.2.1
    have hp := hCls.1 P oP A
    have hq := hCls.2.1 Q oQ B
    have hr := hCls.2.2 (P × Q) oPQ (A ×ˢ B)
    apply Set.Subset.antisymm
    · apply hr.2.2
      · intro E hE hdir s hs
        have hsP := (isLUB_prod.mp hs).1
        have hsQ := (isLUB_prod.mp hs).2
        exact ⟨hp.2.1 (Prod.fst '' E)
          (by rintro p ⟨e, he, rfl⟩; exact (hE he).1)
          ⟨hdir.1.image Prod.fst, hdir.2.fst⟩ s.1 hsP,
          hq.2.1 (Prod.snd '' E)
          (by rintro q ⟨e, he, rfl⟩; exact (hE he).2)
          ⟨hdir.1.image Prod.snd, hdir.2.snd⟩ s.2 hsQ⟩
      · intro p hpAB
        exact ⟨hp.1 hpAB.1, hq.1 hpAB.2⟩
    · have hsectionP : ∀ b ∈ B, cP A ⊆ {p | (p, b) ∈ cPQ (A ×ˢ B)} := by
        intro b hb
        apply hp.2.2
        · intro E hE hdir s hs
          let T : Set (P × Q) := (fun p : P => (p,b)) '' E
          have hT : (node_N043).2 (P × Q) oPQ T := by
            refine ⟨hdir.1.image _, ?_⟩
            exact DirectedOn.mono_comp (fun _ _ h => ⟨h, le_rfl⟩) hdir.2
          have hTs : IsLUB T (s,b) := by
            constructor
            · rintro p ⟨e, he, rfl⟩
              exact ⟨hs.1 he, le_rfl⟩
            · intro p hpT
              constructor
              · exact hs.2 (fun e he => (hpT ⟨e, he, rfl⟩).1)
              · obtain ⟨e, he⟩ := hdir.1
                exact (hpT ⟨e, he, rfl⟩).2
          exact hr.2.1 T
            (by rintro p ⟨e, he, rfl⟩; exact hE he) hT (s,b) hTs
        · intro a ha
          exact hr.1 ⟨ha,hb⟩
      intro p hpAB
      have hsectionQ : cQ B ⊆ {q | (p.1,q) ∈ cPQ (A ×ˢ B)} := by
        apply hq.2.2
        · intro E hE hdir s hs
          let T : Set (P × Q) := (fun q : Q => (p.1,q)) '' E
          have hT : (node_N043).2 (P × Q) oPQ T := by
            refine ⟨hdir.1.image _, ?_⟩
            exact DirectedOn.mono_comp (fun _ _ h => ⟨le_rfl, h⟩) hdir.2
          have hTs : IsLUB T (p.1,s) := by
            constructor
            · rintro q ⟨e, he, rfl⟩
              exact ⟨le_rfl, hs.1 he⟩
            · intro q hqT
              constructor
              · obtain ⟨e, he⟩ := hdir.1
                exact (hqT ⟨e, he, rfl⟩).1
              · exact hs.2 (fun e he => (hqT ⟨e, he, rfl⟩).2)
          exact hr.2.1 T
            (by rintro q ⟨e, he, rfl⟩; exact hE he) hT (p.1,s) hTs
        · intro b hb
          exact hsectionP b hb hpAB.1
      exact hsectionQ hpAB.2
  · intro M tM hM ι hc
    dsimp only
    intro hιScott
    let oM := ((node_N043).1 M tM hM).1
    let σ := (node_N044 M oM).1
    letI : PartialOrder M := oM
    have hSpec : @T0Space M σ := by
      letI : TopologicalSpace M := σ
      letI : Topology.IsScott M Set.univ := ⟨rfl⟩
      infer_instance
    have hOrder : ((node_N043).1 M σ hSpec).1 = oM := by
      apply PartialOrder.ext
      intro a b
      letI : TopologicalSpace M := σ
      letI : Topology.IsScott M Set.univ := ⟨rfl⟩
      change @Specializes M σ b a ↔ a ≤ b
      rw [specializes_iff_mem_closure, Topology.IsScott.closure_singleton]
      rfl
    have hScottMC : (node_N003.{u,v}).1 M σ hSpec := by
      change (∀ E : Set M, (node_N043).2 M
        ((node_N043).1 M σ hSpec).1 E →
        ∃ s, @IsLUB M ((node_N043).1 M σ hSpec).1.toLE E s) ∧ _
      rw [hOrder]
      exact ⟨hc.2.2.1.1, fun U hU => hU⟩
    obtain ⟨g, ⟨hg, hge⟩, hgu⟩ := hExts.2.2.2.1
      M tM hM ι hc M σ hSpec hScottMC ι hιScott
    have hj : @Continuous M M σ tM id :=
      continuous_def.mpr (fun U hU => hc.2.2.1.2 U hU)
    have hι : @Continuous X M tX tM ι :=
      continuous_iff_le_induced.mpr hc.2.1.le
    obtain ⟨r, hr, hru⟩ := hExts.2.2.2.1
      M tM hM ι hc M tM hM hc.2.2.1 ι hι
    have he : g = id := by
      exact (hru g ⟨@Continuous.comp M M M tM σ tM g id hj hg, hge⟩).trans
        (hru id ⟨@continuous_id M tM, fun _ => rfl⟩).symm
    have hid : @Continuous M M tM σ id := he ▸ hg
    apply le_antisymm
    · simpa only [induced_id] using continuous_iff_le_induced.mp hid
    · simpa only [induced_id] using continuous_iff_le_induced.mp hj

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N066 -/
section
universe u v

namespace PMRVerifier

noncomputable def node_N066 : (
∀ (P : Type u) (Q : Type v) [instP : PartialOrder P] [instQ : PartialOrder Q] (f : P → Q), Prop
) := (
fun (P : Type u) (Q : Type v) [instP : PartialOrder P] [instQ : PartialOrder Q] (f : P → Q) => (∀ (x y : P), x ≤ y → f x ≤ f y) ∧ (∀ (x y : P), f x ≤ f y → x ≤ y)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N066 -/
section

end

/- Source module PMRVerifier.Statements.N005 -/
section
universe u v w z

namespace PMRVerifier

def spec_N005 : Prop := (
∀ (D : Type u) (E : Type v) (P : Type w) (Q : Type z)
  (oD : PartialOrder D) (oE : PartialOrder E)
  (oP : PartialOrder P) (oQ : PartialOrder Q),
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  letI : PartialOrder P := oP
  letI : PartialOrder Q := oQ
  ∀ (hD : ∀ (B : Set D), B.Nonempty ∧ DirectedOn oD.le B →
      ∃ (s : D), IsLUB B s)
    (hE : ∀ (B : Set E), B.Nonempty ∧ DirectedOn oE.le B →
      ∃ (s : E), IsLUB B s)
    (hP : ∀ (B : Set P), B.Nonempty ∧ DirectedOn oP.le B →
      ∃ (s : P), IsLUB B s)
    (hQ : ∀ (B : Set Q), B.Nonempty ∧ DirectedOn oQ.le B →
      ∃ (s : Q), IsLUB B s),
    let subD : Set D → Prop :=
      ((PMRVerifier.node_N002 D oD).2.2.2 hD).1
    let genD : Set D → Set D :=
      ((PMRVerifier.node_N002 D oD).2.2.2 hD).2
    let subE : Set E → Prop :=
      ((PMRVerifier.node_N002 E oE).2.2.2 hE).1
    let subQ : Set Q → Prop :=
      ((PMRVerifier.node_N002 Q oQ).2.2.2 hQ).1
    let σD : TopologicalSpace D := (PMRVerifier.node_N044 D oD).1
    let σE : TopologicalSpace E := (PMRVerifier.node_N044 E oE).1
    let σP : TopologicalSpace P := (PMRVerifier.node_N044 P oP).1
    let σQ : TopologicalSpace Q := (PMRVerifier.node_N044 Q oQ).1
    (∀ (A K : Set D), genD A = Set.univ → subD K →
      A ⊆ K → K = Set.univ) ∧
    (∀ (h : D → E), @Continuous D E σD σE h →
      ∀ (K : Set E), subE K → subD (h ⁻¹' K)) ∧
    (∀ (m : P → Q), @Continuous P Q σP σQ m →
      @PMRVerifier.node_N066 P Q oP oQ m →
      subQ (Set.range m)) ∧
    (∀ (m : P → Q), @Continuous P Q σP σQ m →
      @PMRVerifier.node_N066 P Q oP oQ m →
      ∀ (h : D → Q), @Continuous D Q σD σQ h →
        Set.range h ⊆ Set.range m →
        ∃ (hbar : D → P),
          Function.comp m hbar = h ∧
          @Continuous D P σD σP hbar ∧
          ∀ (g : D → P), Function.comp m g = h → g = hbar)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N005 -/
section
universe u v w z

namespace PMRVerifier

theorem node_N005 : (
∀ (D : Type u) (E : Type v) (P : Type w) (Q : Type z)
  (oD : PartialOrder D) (oE : PartialOrder E)
  (oP : PartialOrder P) (oQ : PartialOrder Q),
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  letI : PartialOrder P := oP
  letI : PartialOrder Q := oQ
  ∀ (hD : ∀ (B : Set D), B.Nonempty ∧ DirectedOn oD.le B →
      ∃ (s : D), IsLUB B s)
    (hE : ∀ (B : Set E), B.Nonempty ∧ DirectedOn oE.le B →
      ∃ (s : E), IsLUB B s)
    (hP : ∀ (B : Set P), B.Nonempty ∧ DirectedOn oP.le B →
      ∃ (s : P), IsLUB B s)
    (hQ : ∀ (B : Set Q), B.Nonempty ∧ DirectedOn oQ.le B →
      ∃ (s : Q), IsLUB B s),
    let subD : Set D → Prop :=
      ((PMRVerifier.node_N002 D oD).2.2.2 hD).1
    let genD : Set D → Set D :=
      ((PMRVerifier.node_N002 D oD).2.2.2 hD).2
    let subE : Set E → Prop :=
      ((PMRVerifier.node_N002 E oE).2.2.2 hE).1
    let subQ : Set Q → Prop :=
      ((PMRVerifier.node_N002 Q oQ).2.2.2 hQ).1
    let σD : TopologicalSpace D := (PMRVerifier.node_N044 D oD).1
    let σE : TopologicalSpace E := (PMRVerifier.node_N044 E oE).1
    let σP : TopologicalSpace P := (PMRVerifier.node_N044 P oP).1
    let σQ : TopologicalSpace Q := (PMRVerifier.node_N044 Q oQ).1
    (∀ (A K : Set D), genD A = Set.univ → subD K →
      A ⊆ K → K = Set.univ) ∧
    (∀ (h : D → E), @Continuous D E σD σE h →
      ∀ (K : Set E), subE K → subD (h ⁻¹' K)) ∧
    (∀ (m : P → Q), @Continuous P Q σP σQ m →
      @PMRVerifier.node_N066 P Q oP oQ m →
      subQ (Set.range m)) ∧
    (∀ (m : P → Q), @Continuous P Q σP σQ m →
      @PMRVerifier.node_N066 P Q oP oQ m →
      ∀ (h : D → Q), @Continuous D Q σD σQ h →
        Set.range h ⊆ Set.range m →
        ∃ (hbar : D → P),
          Function.comp m hbar = h ∧
          @Continuous D P σD σP hbar ∧
          ∀ (g : D → P), Function.comp m g = h → g = hbar)
) := (
by
  classical
  intro D E P Q oD oE oP oQ
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  letI : PartialOrder P := oP
  letI : PartialOrder Q := oQ
  dsimp only
  intro hD hE hP hQ
  letI : TopologicalSpace D := (PMRVerifier.node_N044 D oD).1
  letI : TopologicalSpace E := (PMRVerifier.node_N044 E oE).1
  letI : TopologicalSpace P := (PMRVerifier.node_N044 P oP).1
  letI : TopologicalSpace Q := (PMRVerifier.node_N044 Q oQ).1
  letI : Topology.IsScott D (Set.univ : Set (Set D)) := ⟨rfl⟩
  letI : Topology.IsScott E (Set.univ : Set (Set E)) := ⟨rfl⟩
  letI : Topology.IsScott P (Set.univ : Set (Set P)) := ⟨rfl⟩
  letI : Topology.IsScott Q (Set.univ : Set (Set Q)) := ⟨rfl⟩
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro A K hgen hK hAK
    apply Set.Subset.antisymm (Set.subset_univ K)
    rw [← hgen]
    exact Set.sInter_subset_of_mem ⟨hK, hAK⟩
  · intro h hc K hK
    have hsc : ScottContinuous h := by
      rw [← scottContinuousOn_univ]
      exact (Topology.IsScott.scottContinuousOn_iff_continuous
        (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mpr hc
    change ∀ (B : Set D), B ⊆ h ⁻¹' K →
      B.Nonempty ∧ DirectedOn (· ≤ ·) B →
      ∃ s : D, IsLUB B s ∧ s ∈ h ⁻¹' K
    intro B hBK hB
    obtain ⟨s, hs⟩ := hD B hB
    have hImageDir : DirectedOn (· ≤ ·) (h '' B) := by
      rintro _ ⟨x, hx, rfl⟩ _ ⟨y, hy, rfl⟩
      obtain ⟨z, hz, hxz, hyz⟩ := hB.2 x hx y hy
      exact ⟨h z, ⟨z, hz, rfl⟩, hsc.monotone hxz, hsc.monotone hyz⟩
    have hImageK : h '' B ⊆ K := by
      rintro _ ⟨x, hx, rfl⟩
      exact hBK hx
    obtain ⟨t, ht, htK⟩ := hK (h '' B) hImageK ⟨hB.1.image h, hImageDir⟩
    have heq : h s = t := (hsc hB.1 hB.2 hs).unique ht
    refine ⟨s, hs, ?_⟩
    change h s ∈ K
    rw [heq]
    exact htK
  · intro m mc hm
    have msc : ScottContinuous m := by
      rw [← scottContinuousOn_univ]
      exact (Topology.IsScott.scottContinuousOn_iff_continuous
        (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mpr mc
    change (∀ x y : P, x ≤ y → m x ≤ m y) ∧
      (∀ x y : P, m x ≤ m y → x ≤ y) at hm
    change ∀ (C : Set Q), C ⊆ Set.range m →
      C.Nonempty ∧ DirectedOn (· ≤ ·) C →
      ∃ s : Q, IsLUB C s ∧ s ∈ Set.range m
    intro C hC hdir
    have hB : (m ⁻¹' C).Nonempty ∧ DirectedOn (· ≤ ·) (m ⁻¹' C) := by
      constructor
      · obtain ⟨q, hq⟩ := hdir.1
        obtain ⟨p, rfl⟩ := hC hq
        exact ⟨p, hq⟩
      · intro x hx y hy
        obtain ⟨q, hq, hxq, hyq⟩ := hdir.2 (m x) hx (m y) hy
        obtain ⟨p, rfl⟩ := hC hq
        exact ⟨p, hq, hm.2 x p hxq, hm.2 y p hyq⟩
    have hImage : m '' (m ⁻¹' C) = C := by
      apply Set.Subset.antisymm
      · rintro _ ⟨p, hp, rfl⟩
        exact hp
      · intro q hq
        obtain ⟨p, rfl⟩ := hC hq
        exact ⟨p, hq, rfl⟩
    obtain ⟨s, hs⟩ := hP (m ⁻¹' C) hB
    refine ⟨m s, ?_, ⟨s, rfl⟩⟩
    rw [← hImage]
    exact msc hB.1 hB.2 hs
  · intro m mc hm h hc hRange
    have msc : ScottContinuous m := by
      rw [← scottContinuousOn_univ]
      exact (Topology.IsScott.scottContinuousOn_iff_continuous
        (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mpr mc
    have hsc : ScottContinuous h := by
      rw [← scottContinuousOn_univ]
      exact (Topology.IsScott.scottContinuousOn_iff_continuous
        (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mpr hc
    change (∀ x y : P, x ≤ y → m x ≤ m y) ∧
      (∀ x y : P, m x ≤ m y → x ≤ y) at hm
    have minj : Function.Injective m := by
      intro x y hxy
      exact le_antisymm (hm.2 x y (le_of_eq hxy))
        (hm.2 y x (le_of_eq hxy.symm))
    have hex : ∀ d : D, ∃ p : P, m p = h d := by
      intro d
      exact hRange ⟨d, rfl⟩
    choose hbar hhbar using hex
    have hbmon : Monotone hbar := by
      intro d d' hdd'
      apply hm.2
      rw [hhbar, hhbar]
      exact hsc.monotone hdd'
    have hbsc : ScottContinuous hbar := by
      intro B hBn hBdir s hs
      have hImageDir : DirectedOn (· ≤ ·) (hbar '' B) := by
        rintro _ ⟨x, hx, rfl⟩ _ ⟨y, hy, rfl⟩
        obtain ⟨z, hz, hxz, hyz⟩ := hBdir x hx y hy
        exact ⟨hbar z, ⟨z, hz, rfl⟩, hbmon hxz, hbmon hyz⟩
      obtain ⟨p, hp⟩ := hP (hbar '' B) ⟨hBn.image hbar, hImageDir⟩
      have hImage : m '' (hbar '' B) = h '' B := by
        rw [Set.image_image]
        have heq : (fun d => m (hbar d)) = h := funext hhbar
        rw [heq]
      have hmp : IsLUB (h '' B) (m p) := by
        rw [← hImage]
        exact msc (hBn.image hbar) hImageDir hp
      have heq : m (hbar s) = m p := by
        rw [hhbar]
        exact (hsc hBn hBdir hs).unique hmp
      exact (minj heq).symm ▸ hp
    refine ⟨hbar, funext hhbar, ?_, ?_⟩
    · exact (Topology.IsScott.scottContinuousOn_iff_continuous
        (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mp hbsc.scottContinuousOn
    · intro g hg
      funext d
      apply minj
      exact (congrFun hg d).trans (hhbar d).symm

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N028 -/
section
universe u

namespace PMRVerifier

def spec_N028 : Prop := (
∀ (C : TopCat.{u} → Prop)
  (hC_T0 : ∀ (W : TopCat.{u}), C W → T0Space W)
  (One : TopCat.{u}) (hOne : C One)
  (hOnePoint : ∃ (o : One), ∀ (w : One), w = o)
  (X Y Z : TopCat.{u}) (hX : C X) (hY : C Y) (hZ : C Z)
  (p : ContinuousMap Z X) (q : ContinuousMap Z Y)
  (hProduct : ∀ (W : TopCat.{u}) (hW : C W)
    (f : ContinuousMap W X) (g : ContinuousMap W Y),
    ∃! (h : ContinuousMap W Z), p.comp h = f ∧ q.comp h = g),
  Function.Bijective (fun (z : Z) => (p z, q z))
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N028 -/
section
universe u

namespace PMRVerifier

theorem node_N028 : (
∀ (C : TopCat.{u} → Prop)
  (hC_T0 : ∀ (W : TopCat.{u}), C W → T0Space W)
  (One : TopCat.{u}) (hOne : C One)
  (hOnePoint : ∃ (o : One), ∀ (w : One), w = o)
  (X Y Z : TopCat.{u}) (hX : C X) (hY : C Y) (hZ : C Z)
  (p : ContinuousMap Z X) (q : ContinuousMap Z Y)
  (hProduct : ∀ (W : TopCat.{u}) (hW : C W)
    (f : ContinuousMap W X) (g : ContinuousMap W Y),
    ∃! (h : ContinuousMap W Z), p.comp h = f ∧ q.comp h = g),
  Function.Bijective (fun (z : Z) => (p z, q z))
) := (
by
  intro C hC_T0 One hOne hOnePoint X Y Z hX hY hZ p q hProduct
  obtain ⟨o, ho⟩ := hOnePoint
  constructor
  · intro z z' hzz
    obtain ⟨k, hk, huniq⟩ := hProduct One hOne
      (ContinuousMap.const One (p z)) (ContinuousMap.const One (q z))
    have hz : (ContinuousMap.const One z : ContinuousMap One Z) = k := by
      apply huniq
      constructor
      · ext w
        rfl
      · ext w
        rfl
    have hz' : (ContinuousMap.const One z' : ContinuousMap One Z) = k := by
      apply huniq
      constructor
      · ext w
        exact (congrArg Prod.fst hzz).symm
      · ext w
        exact (congrArg Prod.snd hzz).symm
    exact congrArg (fun f : ContinuousMap One Z => f o) (hz.trans hz'.symm)
  · rintro ⟨x, y⟩
    obtain ⟨f, hf, huniq⟩ := hProduct One hOne
      (ContinuousMap.const One x) (ContinuousMap.const One y)
    refine ⟨f o, ?_⟩
    apply Prod.ext
    · exact congrArg (fun a : ContinuousMap One X => a o) hf.1
    · exact congrArg (fun a : ContinuousMap One Y => a o) hf.2
)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N034 -/
section
universe u

namespace PMRVerifier

def spec_N034 : Prop := (
let IsDcpo : PartOrd.{u} → Prop :=
  fun P => ∀ (A : Set P),
    PMRVerifier.node_N043.2 P (inferInstance : PartialOrder P) A →
      ∃ a : P, IsLUB A a
let DCPO := {P : PartOrd.{u} // IsDcpo P}
let Hom : DCPO → DCPO → Type u :=
  fun D E => {f : D.1 → E.1 // ScottContinuous f}
letI : CategoryTheory.Category.{u} DCPO :=
  { Hom := Hom
    id := fun D => ⟨id, ScottContinuous.id⟩
    comp := fun {D E G} f g => ⟨g.1 ∘ f.1, f.2.comp g.2⟩
    id_comp := by intros; apply Subtype.ext; rfl
    comp_id := by intros; apply Subtype.ext; rfl
    assoc := by intros; apply Subtype.ext; rfl }
let ScottObj : DCPO → TopCat.{u} :=
  fun D => (PMRVerifier.node_N044 D.1 (inferInstance : PartialOrder D.1)).2
let Top0 : CategoryTheory.ObjectProperty TopCat.{u} :=
  fun X => T0Space X
∃ (hT0 : ∀ (D : DCPO), T0Space (ScottObj D))
  (hcont : ∀ (D E : DCPO) (f : Hom D E),
    @Continuous D.1 E.1 (ScottObj D).str (ScottObj E).str f.1),
  let F : CategoryTheory.Functor DCPO Top0.FullSubcategory :=
    { obj := fun D => ⟨ScottObj D, hT0 D⟩
      map := fun {D E} f =>
        CategoryTheory.ObjectProperty.homMk
          (@TopCat.ofHom D.1 E.1 (ScottObj D).str (ScottObj E).str
            (@ContinuousMap.mk D.1 E.1 (ScottObj D).str (ScottObj E).str
              f.1 (hcont D E f)))
      map_id := by
        intro D
        apply CategoryTheory.ObjectProperty.hom_ext
        apply TopCat.ext
        intro x
        rfl
      map_comp := by
        intro D E G f g
        apply CategoryTheory.ObjectProperty.hom_ext
        apply TopCat.ext
        intro x
        rfl }
  F.Full ∧ F.Faithful ∧ Function.Injective F.obj
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N034 -/
section
universe u

namespace PMRVerifier

theorem node_N034 : (
let IsDcpo : PartOrd.{u} → Prop :=
  fun P => ∀ (A : Set P),
    PMRVerifier.node_N043.2 P (inferInstance : PartialOrder P) A →
      ∃ a : P, IsLUB A a
let DCPO := {P : PartOrd.{u} // IsDcpo P}
let Hom : DCPO → DCPO → Type u :=
  fun D E => {f : D.1 → E.1 // ScottContinuous f}
letI : CategoryTheory.Category.{u} DCPO :=
  { Hom := Hom
    id := fun D => ⟨id, ScottContinuous.id⟩
    comp := fun {D E G} f g => ⟨g.1 ∘ f.1, f.2.comp g.2⟩
    id_comp := by intros; apply Subtype.ext; rfl
    comp_id := by intros; apply Subtype.ext; rfl
    assoc := by intros; apply Subtype.ext; rfl }
let ScottObj : DCPO → TopCat.{u} :=
  fun D => (PMRVerifier.node_N044 D.1 (inferInstance : PartialOrder D.1)).2
let Top0 : CategoryTheory.ObjectProperty TopCat.{u} :=
  fun X => T0Space X
∃ (hT0 : ∀ (D : DCPO), T0Space (ScottObj D))
  (hcont : ∀ (D E : DCPO) (f : Hom D E),
    @Continuous D.1 E.1 (ScottObj D).str (ScottObj E).str f.1),
  let F : CategoryTheory.Functor DCPO Top0.FullSubcategory :=
    { obj := fun D => ⟨ScottObj D, hT0 D⟩
      map := fun {D E} f =>
        CategoryTheory.ObjectProperty.homMk
          (@TopCat.ofHom D.1 E.1 (ScottObj D).str (ScottObj E).str
            (@ContinuousMap.mk D.1 E.1 (ScottObj D).str (ScottObj E).str
              f.1 (hcont D E f)))
      map_id := by
        intro D
        apply CategoryTheory.ObjectProperty.hom_ext
        apply TopCat.ext
        intro x
        rfl
      map_comp := by
        intro D E G f g
        apply CategoryTheory.ObjectProperty.hom_ext
        apply TopCat.ext
        intro x
        rfl }
  F.Full ∧ F.Faithful ∧ Function.Injective F.obj
) := (
by
  classical
  intro IsDcpo DCPO Hom ScottObj Top0
  letI : CategoryTheory.Category.{u} DCPO :=
    { Hom := Hom
      id := fun D => ⟨id, ScottContinuous.id⟩
      comp := fun {D E G} f g => ⟨g.1 ∘ f.1, f.2.comp g.2⟩
      id_comp := by intros; apply Subtype.ext; rfl
      comp_id := by intros; apply Subtype.ext; rfl
      assoc := by intros; apply Subtype.ext; rfl }
  have hScott (P : PartOrd.{u}) :
      @Topology.IsScott P (Set.univ : Set (Set P))
        (inferInstance : PartialOrder P).toPreorder
        (PMRVerifier.node_N044 P (inferInstance : PartialOrder P)).2.str :=
    by
      letI : TopologicalSpace P :=
        (PMRVerifier.node_N044 P (inferInstance : PartialOrder P)).2.str
      exact ⟨rfl⟩
  have hT0 : ∀ D : DCPO, T0Space (ScottObj D) := by
    intro D
    letI : TopologicalSpace D.1 := (ScottObj D).str
    letI : Topology.IsScott D.1 (Set.univ : Set (Set D.1)) := hScott D.1
    change @T0Space D.1 (ScottObj D).str
    infer_instance
  have hiff (D E : DCPO) (f : D.1 → E.1) :
      ScottContinuous f ↔
        @Continuous D.1 E.1 (ScottObj D).str (ScottObj E).str f := by
    letI : TopologicalSpace D.1 := (ScottObj D).str
    letI : TopologicalSpace E.1 := (ScottObj E).str
    letI : Topology.IsScott D.1 (Set.univ : Set (Set D.1)) := hScott D.1
    letI : Topology.IsScott E.1 (Set.univ : Set (Set E.1)) := hScott E.1
    rw [← scottContinuousOn_univ]
    exact Topology.IsScott.scottContinuousOn_iff_continuous (fun _ _ _ => Set.mem_univ _)
  have hcont : ∀ (D E : DCPO) (f : Hom D E),
      @Continuous D.1 E.1 (ScottObj D).str (ScottObj E).str f.1 :=
    fun D E f => (hiff D E f.1).mp f.2
  refine ⟨hT0, hcont, ?_⟩
  intro F
  refine ⟨?_, ?_, ?_⟩
  · refine ⟨?_⟩
    intro D E g
    refine ⟨⟨g.hom.hom, (hiff D E g.hom.hom).mpr g.hom.hom.continuous⟩, ?_⟩
    apply CategoryTheory.ObjectProperty.hom_ext
    apply TopCat.ext
    intro x
    rfl
  · refine ⟨?_⟩
    intro D E f g h
    apply Subtype.ext
    funext x
    exact congrArg (fun k => k.hom.hom x) h
  · have recover (X : Type u) (p : PartialOrder X) (x y : X) :
        p.le x y ↔ x ∈ @closure X
          (@Topology.scott X (Set.univ : Set (Set X)) p.toPreorder) ({y} : Set X) := by
      letI : PartialOrder X := p
      letI : TopologicalSpace X := Topology.scott X (Set.univ : Set (Set X))
      letI : Topology.IsScott X (Set.univ : Set (Set X)) := ⟨rfl⟩
      rw [Topology.IsScott.closure_singleton]
      rfl
    have obj_inj : Function.Injective
        (fun P : PartOrd.{u} => (PMRVerifier.node_N044 P (inferInstance : PartialOrder P)).2) := by
      intro P Q h
      rcases P with @⟨X, p⟩
      rcases Q with @⟨Y, q⟩
      have hc : X = Y := congrArg TopCat.carrier h
      cases hc
      have ht : @Topology.scott X (Set.univ : Set (Set X)) p.toPreorder =
          @Topology.scott X (Set.univ : Set (Set X)) q.toPreorder :=
        eq_of_heq (TopCat.of.inj h).2
      have hpq : p = q := by
        apply PartialOrder.ext
        intro x y
        change p.le x y ↔ q.le x y
        rw [recover X p x y, recover X q x y, ht]
      cases hpq
      rfl
    intro D E h
    apply Subtype.ext
    apply obj_inj
    exact congrArg CategoryTheory.ObjectProperty.FullSubcategory.obj h
)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N036 -/
section
universe u v

namespace PMRVerifier

def spec_N036 : Prop := (
∀ (X : Type u) (t : TopologicalSpace X) (hT0 : @T0Space X t),
  let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
  let increasingNetOpen : Set X → Prop := fun U =>
    ∀ (I : Type (max u v)) (r : Preorder I)
      (_hNonempty : Nonempty I)
      (_hDirected : ∀ (i j : I), ∃ (k : I), r.le i k ∧ r.le j k)
      (f : I → X)
      (_hIncreasing : ∀ (i j : I), r.le i j → o.le (f i) (f j))
      (x : X) (_hx : x ∈ U)
      (_hConverges : ∀ (V : Set X), @IsOpen X t V → x ∈ V →
        ∃ (i : I), ∀ (j : I), r.le i j → f j ∈ V),
      ∃ (i : I), ∀ (j : I), r.le i j → f j ∈ U
  (PMRVerifier.node_N001.1 X t hT0).2 ↔
    ∀ (U : Set X), @IsOpen X t U ↔ increasingNetOpen U
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N036 -/
section
universe u v

namespace PMRVerifier

theorem node_N036 : (
∀ (X : Type u) (t : TopologicalSpace X) (hT0 : @T0Space X t),
  let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
  let increasingNetOpen : Set X → Prop := fun U =>
    ∀ (I : Type (max u v)) (r : Preorder I)
      (_hNonempty : Nonempty I)
      (_hDirected : ∀ (i j : I), ∃ (k : I), r.le i k ∧ r.le j k)
      (f : I → X)
      (_hIncreasing : ∀ (i j : I), r.le i j → o.le (f i) (f j))
      (x : X) (_hx : x ∈ U)
      (_hConverges : ∀ (V : Set X), @IsOpen X t V → x ∈ V →
        ∃ (i : I), ∀ (j : I), r.le i j → f j ∈ V),
      ∃ (i : I), ∀ (j : I), r.le i j → f j ∈ U
  (PMRVerifier.node_N001.1 X t hT0).2 ↔
    ∀ (U : Set X), @IsOpen X t U ↔ increasingNetOpen U
) := (
by
  intro X t hT0
  let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
  have hupper : ∀ (V : Set X), @IsOpen X t V →
      ∀ (a b : X), o.le a b → a ∈ V → b ∈ V :=
    (PMRVerifier.node_N043.1 X t hT0).property.2
  dsimp only
  constructor
  · intro hMD U
    constructor
    · intro hU I r hI hdir f hinc x hx hconv
      exact hconv U hU hx
    · intro hU
      apply hMD U
      intro A hA x hx hconv
      change A.Nonempty ∧ DirectedOn o.le A at hA
      let J : Type (max u v) := ULift.{v} {a : X // a ∈ A}
      let R : Preorder J :=
        { le := fun i j => o.le i.down.val j.down.val
          le_refl := fun i => o.le_refl i.down.val
          le_trans := fun i j k hij hjk => o.le_trans i.down.val j.down.val k.down.val hij hjk }
      have hJ : Nonempty J := by
        obtain ⟨a, ha⟩ := hA.1
        exact ⟨ULift.up ⟨a, ha⟩⟩
      have hdirJ : ∀ (i j : J), ∃ (k : J), R.le i k ∧ R.le j k := by
        intro i j
        obtain ⟨a, ha, hia, hja⟩ := hA.2 i.down.val i.down.property j.down.val j.down.property
        exact ⟨ULift.up ⟨a, ha⟩, hia, hja⟩
      have hconvJ : ∀ (V : Set X), @IsOpen X t V → x ∈ V →
          ∃ (i : J), ∀ (j : J), R.le i j → j.down.val ∈ V := by
        intro V hV hxV
        obtain ⟨a, ha, htail⟩ := hconv V hV hxV
        refine ⟨ULift.up ⟨a, ha⟩, ?_⟩
        intro j hij
        exact htail j.down.val j.down.property hij
      obtain ⟨i, hi⟩ := hU J R hJ hdirJ (fun j => j.down.val)
        (fun i j hij => hij) x hx hconvJ
      exact ⟨i.down.val, i.down.property, hi i (o.le_refl i.down.val)⟩
  · intro htop U hU
    apply (htop U).2
    have hUupper : ∀ (a b : X), o.le a b → a ∈ U → b ∈ U := by
      intro a b hab ha
      have hs : PMRVerifier.node_N043.2 X o ({b} : Set X) := by
        change ({b} : Set X).Nonempty ∧ DirectedOn o.le ({b} : Set X)
        constructor
        · exact ⟨b, rfl⟩
        · intro c hc d hd
          have hc' : c = b := Set.mem_singleton_iff.mp hc
          have hd' : d = b := Set.mem_singleton_iff.mp hd
          subst c
          subst d
          exact ⟨b, rfl, o.le_refl b, o.le_refl b⟩
      have hsc : ∀ (V : Set X), @IsOpen X t V → a ∈ V →
          ∃ (c : X), c ∈ ({b} : Set X) ∧
            ∀ (d : X), d ∈ ({b} : Set X) → o.le c d → d ∈ V := by
        intro V hV haV
        refine ⟨b, rfl, ?_⟩
        intro d hd hbd
        have hd' : d = b := Set.mem_singleton_iff.mp hd
        subst d
        exact hupper V hV a b hab haV
      obtain ⟨c, hc, hcU⟩ := hU ({b} : Set X) hs a ha hsc
      have hc' : c = b := Set.mem_singleton_iff.mp hc
      exact hc' ▸ hcU
    intro I r hI hdir f hinc x hx hconv
    let A : Set X := Set.range f
    have hA : PMRVerifier.node_N043.2 X o A := by
      change A.Nonempty ∧ DirectedOn o.le A
      constructor
      · obtain ⟨i⟩ := hI
        exact ⟨f i, ⟨i, rfl⟩⟩
      · intro a ha b hb
        obtain ⟨i, rfl⟩ := ha
        obtain ⟨j, rfl⟩ := hb
        obtain ⟨k, hik, hjk⟩ := hdir i j
        exact ⟨f k, ⟨k, rfl⟩, hinc i k hik, hinc j k hjk⟩
    have hconvA : ∀ (V : Set X), @IsOpen X t V → x ∈ V →
        ∃ (a : X), a ∈ A ∧
          ∀ (b : X), b ∈ A → o.le a b → b ∈ V := by
      intro V hV hxV
      obtain ⟨i, hi⟩ := hconv V hV hxV
      refine ⟨f i, ⟨i, rfl⟩, ?_⟩
      intro b hb hib
      exact hupper V hV (f i) b hib (hi i (r.le_refl i))
    obtain ⟨a, ⟨i, rfl⟩, hiU⟩ := hU A hA x hx hconvA
    exact ⟨i, fun j hij => hUupper (f i) (f j) (hinc i j hij) hiU⟩
)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N037 -/
section
universe u

namespace PMRVerifier

def spec_N037 : Prop := (
let t0Property : CategoryTheory.ObjectProperty TopCat.{u} :=
  fun X => @T0Space X X.str
let Top0 := CategoryTheory.ObjectProperty.FullSubcategory t0Property
let mdProperty : CategoryTheory.ObjectProperty Top0 :=
  fun X => (PMRVerifier.node_N001.1 X.obj X.obj.str X.property).2
let Topmd := CategoryTheory.ObjectProperty.FullSubcategory mdProperty
Nonempty (CategoryTheory.Coreflective
  (CategoryTheory.ObjectProperty.ι mdProperty)) ∧
  ∃ (cartesian : CategoryTheory.CartesianMonoidalCategory Topmd),
    letI : CategoryTheory.CartesianMonoidalCategory Topmd := cartesian
    Nonempty (CategoryTheory.MonoidalClosed Topmd)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N037 -/
section
universe u

namespace PMRVerifier

theorem node_N037 : (
let t0Property : CategoryTheory.ObjectProperty TopCat.{u} :=
  fun X => @T0Space X X.str
let Top0 := CategoryTheory.ObjectProperty.FullSubcategory t0Property
let mdProperty : CategoryTheory.ObjectProperty Top0 :=
  fun X => (PMRVerifier.node_N001.1 X.obj X.obj.str X.property).2
let Topmd := CategoryTheory.ObjectProperty.FullSubcategory mdProperty
Nonempty (CategoryTheory.Coreflective
  (CategoryTheory.ObjectProperty.ι mdProperty)) ∧
  ∃ (cartesian : CategoryTheory.CartesianMonoidalCategory Topmd),
    letI : CategoryTheory.CartesianMonoidalCategory Topmd := cartesian
    Nonempty (CategoryTheory.MonoidalClosed Topmd)
) := (
by
  classical
  let t0Property : CategoryTheory.ObjectProperty TopCat.{u} :=
    fun X => @T0Space X X.str
  let Top0 := CategoryTheory.ObjectProperty.FullSubcategory t0Property
  let mdProperty : CategoryTheory.ObjectProperty Top0 :=
    fun X => (PMRVerifier.node_N001.1 X.obj X.obj.str X.property).2
  let Topmd := CategoryTheory.ObjectProperty.FullSubcategory mdProperty
  let Orders (X : Top0) : PartialOrder X.obj × Unit :=
    ⟨(PMRVerifier.node_N043.1 X.obj X.obj.str X.property).val, ()⟩
  let D (X : Top0) : Set X.obj → Prop :=
    (PMRVerifier.node_N001.1 X.obj X.obj.str X.property).1
  have ole (X : Top0) (a b : X.obj) :
      (Orders X).1.le a b ↔ ∀ U : Set X.obj, IsOpen U → a ∈ U → b ∈ U := by
    change @Specializes _ X.obj.str b a ↔ _
    exact specializes_iff_forall_open
  have openD (X : Top0) (U : Set X.obj) (hU : IsOpen U) : D X U := by
    intro A hA x hx hc
    obtain ⟨a, ha, ht⟩ := hc U hU hx
    exact ⟨a, ha, ht a ha ((Orders X).1.le_refl a)⟩
  have upperD (X : Top0) (U : Set X.obj) (hU : D X U)
      (a b : X.obj) (hab : (Orders X).1.le a b) (ha : a ∈ U) : b ∈ U := by
    have hs : PMRVerifier.node_N043.2 X.obj (Orders X).1 ({b} : Set X.obj) := by
      change ({b} : Set X.obj).Nonempty ∧ DirectedOn (Orders X).1.le ({b} : Set X.obj)
      refine ⟨⟨b, rfl⟩, ?_⟩
      intro c hc e he
      have hc' : c = b := Set.mem_singleton_iff.mp hc
      have he' : e = b := Set.mem_singleton_iff.mp he
      subst c
      subst e
      exact ⟨b, rfl, (Orders X).1.le_refl b, (Orders X).1.le_refl b⟩
    obtain ⟨c, hc, hcU⟩ := hU {b} hs a ha (by
      intro V hV haV
      refine ⟨b, rfl, ?_⟩
      intro e he hbe
      have he' : e = b := Set.mem_singleton_iff.mp he
      subst e
      exact (ole X a b).mp hab V hV haV)
    exact (Set.mem_singleton_iff.mp hc) ▸ hcU
  let DT (X : Top0) : TopologicalSpace X.obj × Unit :=
    ⟨{
      IsOpen := D X
      isOpen_univ := by
        intro A hA x hx hc
        obtain ⟨a, ha⟩ := hA.1
        exact ⟨a, ha, Set.mem_univ a⟩
      isOpen_inter := by
        intro U V hU hV A hA x hx hc
        obtain ⟨a, ha, haU⟩ := hU A hA x hx.1 hc
        obtain ⟨b, hb, hbV⟩ := hV A hA x hx.2 hc
        obtain ⟨c, hc, hac, hbc⟩ := hA.2 a ha b hb
        exact ⟨c, hc, upperD X U hU a c hac haU, upperD X V hV b c hbc hbV⟩
      isOpen_sUnion := by
        intro S hS A hA x hx hc
        obtain ⟨U, hUS, hxU⟩ := hx
        obtain ⟨a, ha, haU⟩ := hS U hUS A hA x hxU hc
        exact ⟨a, ha, U, hUS, haU⟩ }, ()⟩
  have did (X : Top0) : @Continuous X.obj X.obj (DT X).1 X.obj.str id := by
    apply continuous_def.mpr
    intro U hU
    exact openD X U hU
  have dt0 (X : Top0) : True ∧ @T0Space X.obj (DT X).1 := by
    refine ⟨True.intro, ?_⟩
    exact @t0Space_of_injective_of_continuous X.obj X.obj (DT X).1 X.obj.str id
      Function.injective_id (did X) X.property
  let RX (X : Top0) : Top0 := ⟨@TopCat.of X.obj (DT X).1, (dt0 X).2⟩
  have rord (X : Top0) (a b : X.obj) :
      (Orders (RX X)).1.le a b ↔ (Orders X).1.le a b := by
    constructor
    · intro hab
      apply (ole X a b).mpr
      intro U hU ha
      exact (ole (RX X) a b).mp hab U (openD X U hU) ha
    · intro hab
      apply (ole (RX X) a b).mpr
      intro U hU ha
      exact upperD X U hU a b hab ha
  have rconv (X : Top0) (A : Set X.obj)
      (hA : PMRVerifier.node_N043.2 X.obj (Orders X).1 A) (x : X.obj)
      (hc : ∀ V : Set X.obj, IsOpen V → x ∈ V →
        ∃ a, a ∈ A ∧ ∀ b, b ∈ A → (Orders X).1.le a b → b ∈ V) :
      ∀ V : Set X.obj, @IsOpen _ (DT X).1 V → x ∈ V →
        ∃ a, a ∈ A ∧ ∀ b, b ∈ A → (Orders (RX X)).1.le a b → b ∈ V := by
    intro V hV hxV
    obtain ⟨a, ha, haV⟩ := hV A hA x hxV hc
    exact ⟨a, ha, fun b hb hab => upperD X V hV a b ((rord X a b).mp hab) haV⟩
  have rmd (X : Top0) : mdProperty (RX X) := by
    intro U hU
    change D X U
    intro A hA x hx hc
    have hA' : PMRVerifier.node_N043.2 (RX X).obj (Orders (RX X)).1 A := by
      refine ⟨hA.1, ?_⟩
      intro a ha b hb
      obtain ⟨c, hc, hac, hbc⟩ := hA.2 a ha b hb
      exact ⟨c, hc, (rord X a c).mpr hac, (rord X b c).mpr hbc⟩
    exact hU A hA' x hx (rconv X A hA x hc)
  have monoC (X Y : Top0) (f : X.obj → Y.obj) (hf : Continuous f)
      (a b : X.obj) (hab : (Orders X).1.le a b) : (Orders Y).1.le (f a) (f b) := by
    apply (ole Y (f a) (f b)).mpr
    intro U hU ha
    exact (ole X a b).mp hab (f ⁻¹' U) (hf.isOpen_preimage U hU) ha
  have preD (X Y : Top0) (f : X.obj → Y.obj) (hf : Continuous f)
      (U : Set Y.obj) (hU : D Y U) : D X (f ⁻¹' U) := by
    intro A hA x hx hc
    have him : PMRVerifier.node_N043.2 Y.obj (Orders Y).1 (f '' A) := by
      refine ⟨hA.1.image f, ?_⟩
      rintro _ ⟨a, ha, rfl⟩ _ ⟨b, hb, rfl⟩
      obtain ⟨c, hc, hac, hbc⟩ := hA.2 a ha b hb
      exact ⟨f c, ⟨c, hc, rfl⟩, monoC X Y f hf a c hac, monoC X Y f hf b c hbc⟩
    have hconv : ∀ V : Set Y.obj, IsOpen V → f x ∈ V →
        ∃ a, a ∈ f '' A ∧ ∀ b, b ∈ f '' A → (Orders Y).1.le a b → b ∈ V := by
      intro V hV hxV
      obtain ⟨a, ha, ht⟩ := hc (f ⁻¹' V) (hf.isOpen_preimage V hV) hxV
      refine ⟨f a, ⟨a, ha, rfl⟩, ?_⟩
      intro b hb hab
      exact (ole Y (f a) b).mp hab V hV (ht a ha ((Orders X).1.le_refl a))
    obtain ⟨b, ⟨a, ha, hab⟩, hbU⟩ := hU (f '' A) him (f x) hx hconv
    exact ⟨a, ha, by change f a ∈ U; rw [hab]; exact hbU⟩
  have liftC (A : Topmd) (X : Top0) (f : A.obj.obj → X.obj)
      (hf : Continuous f) : @Continuous _ _ A.obj.obj.str (DT X).1 f := by
    apply continuous_def.mpr
    intro U hU
    exact A.property (f ⁻¹' U) (preD A.obj X f hf U hU)
  have mapC (X Y : Top0) (f : X.obj → Y.obj) (hf : Continuous f) :
      @Continuous _ _ (DT X).1 (DT Y).1 f := by
    apply continuous_def.mpr
    intro U hU
    exact preD X Y f hf U hU
  have compC {A B C : Type u} {sA : TopologicalSpace A} {sB : TopologicalSpace B}
      {sC : TopologicalSpace C} (f : A → B) (g : B → C)
      (hg : @Continuous B C sB sC g) (hf : @Continuous A B sA sB f) :
      @Continuous A C sA sC (fun a => g (f a)) := by
    exact ⟨fun U hU => hf.isOpen_preimage (g ⁻¹' U) (hg.isOpen_preimage U hU)⟩
  have pullOpen {A B : Type u} {sA : TopologicalSpace A} {sB : TopologicalSpace B}
      {f : A → B} (hf : @Continuous A B sA sB f) (U : Set B) (hU : @IsOpen B sB U) :
      @IsOpen A sA (f ⁻¹' U) := hf.1 U hU
  have morphC {X Y : Topmd} (f : X ⟶ Y) :
      @Continuous _ _ X.obj.obj.str Y.obj.obj.str (fun x => f.hom.hom x) :=
    f.hom.hom.hom'.2
  let mk0 {X Y : Top0} (f : X.obj → Y.obj) (hf : @Continuous _ _ X.obj.str Y.obj.str f) : X ⟶ Y :=
    CategoryTheory.ObjectProperty.homMk (TopCat.ofHom ⟨f, hf⟩)
  let mk {X Y : Topmd} (f : X.obj.obj → Y.obj.obj) (hf : @Continuous _ _ X.obj.obj.str Y.obj.obj.str f) : X ⟶ Y :=
    CategoryTheory.ObjectProperty.homMk (CategoryTheory.ObjectProperty.homMk (TopCat.ofHom ⟨f, hf⟩))
  have hext0 {X Y : Top0} {f g : X ⟶ Y}
      (h : ∀ x, f.hom x = g.hom x) : f = g :=
    CategoryTheory.ObjectProperty.hom_ext t0Property (TopCat.ext h)
  have hext {X Y : Topmd} {f g : X ⟶ Y}
      (h : ∀ x, f.hom.hom x = g.hom.hom x) : f = g :=
    CategoryTheory.ObjectProperty.hom_ext mdProperty
      (CategoryTheory.ObjectProperty.hom_ext t0Property (TopCat.ext h))
  let rObj (X : Top0) : Topmd := ⟨RX X, rmd X⟩
  let R : CategoryTheory.Functor Top0 Topmd :=
    { obj := rObj
      map := fun {X Y} f => mk (X := rObj X) (Y := rObj Y) (fun x => f.hom x)
        (mapC X Y (fun x => f.hom x) f.hom.hom'.2)
      map_id := by intro X; rfl
      map_comp := by intro X Y Z f g; rfl }
  let hequiv (A : Topmd) (X : Top0) :
      (A.obj ⟶ X) ≃ (A ⟶ R.obj X) :=
    { toFun := fun f => mk (X := A) (Y := R.obj X) (fun x => f.hom x)
        (liftC A X (fun x => f.hom x) f.hom.hom'.2)
      invFun := fun g => mk0 (X := A.obj) (Y := X) (fun a => g.hom.hom a)
        (compC (fun a => g.hom.hom a) id (did X) g.hom.hom.hom'.2)
      left_inv := by intro f; rfl
      right_inv := by intro g; rfl }
  have corefl : CategoryTheory.Coreflective (CategoryTheory.ObjectProperty.ι mdProperty) :=
    { R := R
      adj := CategoryTheory.Adjunction.mkOfHomEquiv
        { homEquiv := hequiv
          homEquiv_naturality_left_symm := by intro A B X f g; rfl
          homEquiv_naturality_right := by intro A X Y f g; rfl } }
  let P0 (X Y : Topmd) : Top0 :=
    ⟨TopCat.of (X.obj.obj × Y.obj.obj),
      @Prod.instT0Space X.obj.obj Y.obj.obj X.obj.obj.str Y.obj.obj.str X.obj.property Y.obj.property⟩
  let P (X Y : Topmd) : Topmd := R.obj (P0 X Y)
  let fstP (X Y : Topmd) : P X Y ⟶ X :=
    mk (X := P X Y) (Y := X) Prod.fst (compC id Prod.fst
      (@continuous_fst X.obj.obj Y.obj.obj X.obj.obj.str Y.obj.obj.str) (did (P0 X Y)))
  let sndP (X Y : Topmd) : P X Y ⟶ Y :=
    mk (X := P X Y) (Y := Y) Prod.snd (compC id Prod.snd
      (@continuous_snd X.obj.obj Y.obj.obj X.obj.obj.str Y.obj.obj.str) (did (P0 X Y)))
  let pairP {Z X Y : Topmd} (f : Z ⟶ X) (g : Z ⟶ Y) : Z ⟶ P X Y :=
    mk (X := Z) (Y := P X Y) (fun z => (f.hom.hom z, g.hom.hom z))
      (liftC Z (P0 X Y) _ (f.hom.hom.hom'.2.prodMk g.hom.hom.hom'.2))
  let term0 : Top0 := ⟨TopCat.of PUnit.{u+1}, inferInstance⟩
  let term : Topmd := R.obj term0
  let terminalCone : CategoryTheory.Limits.LimitCone (CategoryTheory.Functor.empty Topmd) :=
    ⟨CategoryTheory.Limits.asEmptyCone term,
      CategoryTheory.Limits.IsTerminal.ofUniqueHom
        (fun X => mk (X := X) (Y := term) (fun _ => PUnit.unit)
          (@continuous_const X.obj.obj term.obj.obj X.obj.obj.str term.obj.obj.str PUnit.unit))
        (by intro X f; apply hext; intro x; exact Subsingleton.elim _ _)⟩
  let productCone (X Y : Topmd) : CategoryTheory.Limits.LimitCone (CategoryTheory.Limits.pair X Y) :=
    ⟨CategoryTheory.Limits.BinaryFan.mk (fstP X Y) (sndP X Y),
      CategoryTheory.Limits.BinaryFan.isLimitMk
        (fun s => pairP s.fst s.snd)
        (by intro s; rfl)
        (by intro s; rfl)
        (by
          intro s m hm hn
          apply hext
          intro z
          apply Prod.ext
          · exact congrArg (fun k => k.hom.hom z) hm
          · exact congrArg (fun k => k.hom.hom z) hn)⟩
  let cartesian : CategoryTheory.CartesianMonoidalCategory Topmd :=
    CategoryTheory.CartesianMonoidalCategory.ofChosenFiniteProducts terminalCone productCone
  letI : CategoryTheory.CartesianMonoidalCategory Topmd := cartesian
  let F0 (X Y : Topmd) : Top0 := by
    let tF : TopologicalSpace C(X.obj.obj, Y.obj.obj) × Unit :=
      ⟨TopologicalSpace.induced (fun f : C(X.obj.obj, Y.obj.obj) =>
        (f : X.obj.obj → Y.obj.obj)) inferInstance, ()⟩
    refine ⟨@TopCat.of C(X.obj.obj, Y.obj.obj) tF.1, ?_⟩
    exact @t0Space_of_injective_of_continuous
      C(X.obj.obj, Y.obj.obj) (X.obj.obj → Y.obj.obj) tF.1 inferInstance
      (fun f => (f : X.obj.obj → Y.obj.obj))
      (by intro f g h; exact DFunLike.coe_injective h)
      continuous_induced_dom
      (@Pi.instT0Space X.obj.obj (fun _ => Y.obj.obj)
        (fun _ => Y.obj.obj.str) (fun _ => Y.obj.property))
  let E (X Y : Topmd) : Topmd := R.obj (F0 X Y)
  have evalAt (X Y : Topmd) (x : X.obj.obj) :
      @Continuous _ _ (E X Y).obj.obj.str Y.obj.obj.str (fun f : (E X Y).obj.obj => f x) := by
    have h : @Continuous _ _ (F0 X Y).obj.str Y.obj.obj.str
        (fun f : C(X.obj.obj, Y.obj.obj) => f x) := by
      exact compC (fun f : C(X.obj.obj, Y.obj.obj) => (f : X.obj.obj → Y.obj.obj))
        (fun f => f x) (continuous_apply x) continuous_induced_dom
    exact compC id (fun f => f x) h (did (F0 X Y))
  have evalC (X Y : Topmd) :
      @Continuous _ _ (P X (E X Y)).obj.obj.str Y.obj.obj.str (fun p : (P X (E X Y)).obj.obj => p.2 p.1) := by
    apply continuous_def.mpr
    intro U hU
    change D (P0 X (E X Y)) ((fun p => p.2 p.1) ⁻¹' U)
    intro A hA p hp hc
    have h1 : @Continuous _ _ (P0 X (E X Y)).obj.str Y.obj.obj.str (fun q : (P0 X (E X Y)).obj => q.2 p.1) :=
      compC (sA := (P0 X (E X Y)).obj.str) (sB := (E X Y).obj.obj.str)
        (sC := Y.obj.obj.str) Prod.snd (fun f : (E X Y).obj.obj => f p.1) (evalAt X Y p.1)
        (@continuous_snd X.obj.obj (E X Y).obj.obj X.obj.obj.str (E X Y).obj.obj.str)
    obtain ⟨a, ha, hta⟩ := hc _ (pullOpen h1 U hU) hp
    have haU : a.2 p.1 ∈ U := hta a ha ((Orders (P0 X (E X Y))).1.le_refl a)
    have h2 : @Continuous _ _ (P0 X (E X Y)).obj.str Y.obj.obj.str (fun q : (P0 X (E X Y)).obj => a.2 q.1) :=
      compC (sA := (P0 X (E X Y)).obj.str) (sB := X.obj.obj.str)
        (sC := Y.obj.obj.str) Prod.fst (fun x : X.obj.obj => a.2 x) a.2.2
        (@continuous_fst X.obj.obj (E X Y).obj.obj X.obj.obj.str (E X Y).obj.obj.str)
    obtain ⟨b, hb, htb⟩ := hc _ (pullOpen h2 U hU) haU
    have hbU : a.2 b.1 ∈ U := htb b hb ((Orders (P0 X (E X Y))).1.le_refl b)
    obtain ⟨c, hcA, hac, hbc⟩ := hA.2 a ha b hb
    have hacU : a.2 c.1 ∈ U :=
      (ole (P0 X (E X Y)) b c).mp hbc _ (pullOpen h2 U hU) hbU
    have h3 : @Continuous _ _ (P0 X (E X Y)).obj.str Y.obj.obj.str (fun q : (P0 X (E X Y)).obj => q.2 c.1) :=
      compC (sA := (P0 X (E X Y)).obj.str) (sB := (E X Y).obj.obj.str)
        (sC := Y.obj.obj.str) Prod.snd (fun f : (E X Y).obj.obj => f c.1) (evalAt X Y c.1)
        (@continuous_snd X.obj.obj (E X Y).obj.obj X.obj.obj.str (E X Y).obj.obj.str)
    exact ⟨c, hcA,
      (ole (P0 X (E X Y)) a c).mp hac
        ((fun q : (P0 X (E X Y)).obj => q.2 c.1) ⁻¹' U) (pullOpen h3 U hU) hacU⟩
  let ev (X Y : Topmd) : P X (E X Y) ⟶ Y := mk (X := P X (E X Y)) (Y := Y) (fun p => p.2 p.1) (evalC X Y)
  have section1 (X Z : Topmd) (z : Z.obj.obj) :
      @Continuous _ _ X.obj.obj.str (P X Z).obj.obj.str (fun x : X.obj.obj => ((x, z) : (P X Z).obj.obj)) :=
    liftC X (P0 X Z) _ (continuous_id.prodMk continuous_const)
  have section2 (X Z : Topmd) (x : X.obj.obj) :
      @Continuous _ _ Z.obj.obj.str (P X Z).obj.obj.str (fun z : Z.obj.obj => ((x, z) : (P X Z).obj.obj)) :=
    liftC Z (P0 X Z) _ (continuous_const.prodMk continuous_id)
  let cf (X Z Y : Topmd) (f : P X Z ⟶ Y) :
      Z.obj.obj → C(X.obj.obj, Y.obj.obj) :=
    fun z => ⟨fun x => f.hom.hom.hom' (x, z),
      compC (sA := X.obj.obj.str) (sB := (P X Z).obj.obj.str) (sC := Y.obj.obj.str)
        (fun x : X.obj.obj => ((x, z) : (P X Z).obj.obj))
        (fun p : (P X Z).obj.obj => f.hom.hom.hom' p)
        (morphC f) (section1 X Z z)⟩
  have curryC (X Z Y : Topmd) (f : P X Z ⟶ Y) :
      @Continuous _ _ Z.obj.obj.str (E X Y).obj.obj.str (cf X Z Y f : Z.obj.obj → (E X Y).obj.obj) := by
    apply liftC Z (F0 X Y)
    apply continuous_induced_rng.mpr
    apply continuous_pi
    intro x
    exact compC (sA := Z.obj.obj.str) (sB := (P X Z).obj.obj.str) (sC := Y.obj.obj.str)
      (fun z : Z.obj.obj => ((x, z) : (P X Z).obj.obj))
      (fun p : (P X Z).obj.obj => f.hom.hom.hom' p)
      (morphC f) (section2 X Z x)
  let curry (X Z Y : Topmd) (f : P X Z ⟶ Y) : Z ⟶ E X Y :=
    mk (X := Z) (Y := E X Y) (cf X Z Y f) (curryC X Z Y f)
  let uncurry (X Z Y : Topmd) (g : Z ⟶ E X Y) : P X Z ⟶ Y :=
    CategoryTheory.CategoryStruct.comp
      (pairP (fstP X Z) (CategoryTheory.CategoryStruct.comp (sndP X Z) g)) (ev X Y)
  let expEquiv (X Z Y : Topmd) : (P X Z ⟶ Y) ≃ (Z ⟶ E X Y) :=
    { toFun := curry X Z Y
      invFun := uncurry X Z Y
      left_inv := by intro f; apply hext; intro p; rfl
      right_inv := by intro g; apply hext; intro z; apply ContinuousMap.ext; intro x; rfl }
  have expNat (X : Topmd) : ∀ (Z' Z Y : Topmd) (f : Z' ⟶ Z) (g : P X Z ⟶ Y),
      expEquiv X Z' Y (CategoryTheory.CategoryStruct.comp
        ((CategoryTheory.MonoidalCategory.tensorLeft X).map f) g) =
        CategoryTheory.CategoryStruct.comp f (expEquiv X Z Y g) := by
    intro Z' Z Y f g
    apply hext
    intro z
    apply ContinuousMap.ext
    intro x
    rfl
  have closed (X : Topmd) : CategoryTheory.Closed X :=
    { rightAdj := CategoryTheory.Adjunction.rightAdjointOfEquiv (F := CategoryTheory.MonoidalCategory.tensorLeft X) (expEquiv X) (expNat X)
      adj := CategoryTheory.Adjunction.adjunctionOfEquivRight (F := CategoryTheory.MonoidalCategory.tensorLeft X) (expEquiv X) (expNat X) }
  exact ⟨⟨corefl⟩, cartesian, ⟨{ closed := closed }⟩⟩

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N038 -/
section
universe u

namespace PMRVerifier

def spec_N038 : Prop := (
let t0Property : CategoryTheory.ObjectProperty TopCat.{u} :=
  fun X => @T0Space X X.str
let Top0 := CategoryTheory.ObjectProperty.FullSubcategory t0Property
let mdProperty : CategoryTheory.ObjectProperty Top0 :=
  fun X => (PMRVerifier.node_N001.1 X.obj X.obj.str X.property).2
let Topmd := CategoryTheory.ObjectProperty.FullSubcategory mdProperty
(∀ (X : Type u) (t : TopologicalSpace X) (hT0 : @T0Space X t),
  let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
  (∀ (x : X) (U : Set X), @IsOpen X t U → x ∈ U →
    ∃ (y : X), y ∈ U ∧
      x ∈ @interior X t {z : X | o.le y z} ∧
      @interior X t {z : X | o.le y z} ⊆ U) →
    mdProperty ⟨@TopCat.of X t, hT0⟩) ∧
(∀ (P : Type u) (o : PartialOrder P),
  let t : TopologicalSpace P := (PMRVerifier.node_N044 P o).1
  ∃ (hT0 : @T0Space P t), mdProperty ⟨@TopCat.of P t, hT0⟩)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N038 -/
section
universe u

namespace PMRVerifier

theorem node_N038 : (
let t0Property : CategoryTheory.ObjectProperty TopCat.{u} :=
  fun X => @T0Space X X.str
let Top0 := CategoryTheory.ObjectProperty.FullSubcategory t0Property
let mdProperty : CategoryTheory.ObjectProperty Top0 :=
  fun X => (PMRVerifier.node_N001.1 X.obj X.obj.str X.property).2
let Topmd := CategoryTheory.ObjectProperty.FullSubcategory mdProperty
(∀ (X : Type u) (t : TopologicalSpace X) (hT0 : @T0Space X t),
  let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
  (∀ (x : X) (U : Set X), @IsOpen X t U → x ∈ U →
    ∃ (y : X), y ∈ U ∧
      x ∈ @interior X t {z : X | o.le y z} ∧
      @interior X t {z : X | o.le y z} ⊆ U) →
    mdProperty ⟨@TopCat.of X t, hT0⟩) ∧
(∀ (P : Type u) (o : PartialOrder P),
  let t : TopologicalSpace P := (PMRVerifier.node_N044 P o).1
  ∃ (hT0 : @T0Space P t), mdProperty ⟨@TopCat.of P t, hT0⟩)
) := (
by
  classical
  have upper_of_directedOpen :
      ∀ (X : Type u) (t : TopologicalSpace X) (hT0 : @T0Space X t),
      let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
      ∀ (U : Set X), (PMRVerifier.node_N001.1 X t hT0).1 U →
        ∀ (a b : X), o.le a b → a ∈ U → b ∈ U := by
    intro X t hT0
    dsimp only
    let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
    intro U hU a b hab ha
    have hs : PMRVerifier.node_N043.2 X o ({b} : Set X) := by
      change ({b} : Set X).Nonempty ∧ DirectedOn o.le ({b} : Set X)
      constructor
      · exact ⟨b, rfl⟩
      · intro c hc d hd
        have hc' : c = b := Set.mem_singleton_iff.mp hc
        have hd' : d = b := Set.mem_singleton_iff.mp hd
        subst c
        subst d
        exact ⟨b, rfl, o.le_refl b, o.le_refl b⟩
    have hconv : ∀ (V : Set X), @IsOpen X t V → a ∈ V →
        ∃ (c : X), c ∈ ({b} : Set X) ∧
          ∀ (d : X), d ∈ ({b} : Set X) → o.le c d → d ∈ V := by
      intro V hV haV
      refine ⟨b, rfl, ?_⟩
      intro d hd hbd
      have hd' : d = b := Set.mem_singleton_iff.mp hd
      subst d
      exact (PMRVerifier.node_N043.1 X t hT0).property.2 V hV a b hab haV
    obtain ⟨c, hc, hcU⟩ := hU ({b} : Set X) hs a ha hconv
    have hc' : c = b := Set.mem_singleton_iff.mp hc
    exact hc' ▸ hcU
  constructor
  · intro X t hT0
    dsimp only
    letI : TopologicalSpace X := t
    let o : PartialOrder X := (PMRVerifier.node_N043.1 X t hT0).val
    intro hC
    change (PMRVerifier.node_N001.1 X t hT0).2
    intro U hU
    -- In particular, this handles every subset of the empty carrier.
    by_cases hEmpty : U = ∅
    · rw [hEmpty]
      exact isOpen_empty
    have hupper : ∀ (a b : X), o.le a b → a ∈ U → b ∈ U :=
      upper_of_directedOpen X t hT0 U hU
    apply isOpen_iff_forall_mem_open.mpr
    intro x hx
    let A : Set X := {y : X | x ∈ interior {z : X | o.le y z}}
    have hA : PMRVerifier.node_N043.2 X o A := by
      change A.Nonempty ∧ DirectedOn o.le A
      constructor
      · obtain ⟨a, ha, hxa, hsub⟩ := hC x Set.univ isOpen_univ (Set.mem_univ x)
        exact ⟨a, hxa⟩
      · intro a ha b hb
        let V : Set X := interior {z : X | o.le a z} ∩
          interior {z : X | o.le b z}
        have hV : IsOpen V := isOpen_interior.inter isOpen_interior
        obtain ⟨c, hc, hxc, hsub⟩ := hC x V hV ⟨ha, hb⟩
        exact ⟨c, hxc, (interior_subset (s := {z : X | o.le a z}) hc.1), (interior_subset (s := {z : X | o.le b z}) hc.2)⟩
    have hconv : ∀ (V : Set X), IsOpen V → x ∈ V →
        ∃ (a : X), a ∈ A ∧
          ∀ (b : X), b ∈ A → o.le a b → b ∈ V := by
      intro V hV hxV
      obtain ⟨a, haV, hxa, hsub⟩ := hC x V hV hxV
      refine ⟨a, hxa, ?_⟩
      intro b hb hab
      exact (PMRVerifier.node_N043.1 X t hT0).property.2 V hV a b hab haV
    obtain ⟨a, haA, haU⟩ := hU A hA x hx hconv
    refine ⟨interior {z : X | o.le a z}, ?_, isOpen_interior, haA⟩
    intro b hb
    exact hupper a b (interior_subset (s := {z : X | o.le a z}) hb) haU
  · intro P o
    letI : PartialOrder P := o
    let t : TopologicalSpace P := (PMRVerifier.node_N044 P o).1
    letI : TopologicalSpace P := t
    letI : Topology.IsScott P (Set.univ : Set (Set P)) := ⟨rfl⟩
    have hT0 : T0Space P := inferInstance
    refine ⟨hT0, ?_⟩
    change (PMRVerifier.node_N001.1 P t hT0).2
    let sp : PartialOrder P := (PMRVerifier.node_N043.1 P t hT0).val
    letI : PartialOrder P := o
    have hsp : ∀ (a b : P), sp.le a b ↔ o.le a b := by
      intro a b
      rw [(PMRVerifier.node_N043.1 P t hT0).property.1 a b]
      change a ∈ closure ({b} : Set P) ↔ a ≤ b
      rw [Topology.IsScott.closure_singleton]
      rfl
    intro U hU
    -- The empty Scott space has only the open subset ∅.
    by_cases hEmpty : U = ∅
    · rw [hEmpty]
      exact isOpen_empty
    have hupper : IsUpperSet U := by
      intro a b hab ha
      exact upper_of_directedOpen P t hT0 U hU a b ((hsp a b).mpr hab) ha
    apply (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn
      (D := (Set.univ : Set (Set P)))).mpr
    refine ⟨hupper, ?_⟩
    intro A hAU hAN hAD x hL hx
    have hA : PMRVerifier.node_N043.2 P sp A := by
      change A.Nonempty ∧ DirectedOn sp.le A
      refine ⟨hAN, ?_⟩
      intro a ha b hb
      obtain ⟨c, hc, hac, hbc⟩ := hAD a ha b hb
      exact ⟨c, hc, (hsp a c).mpr hac, (hsp b c).mpr hbc⟩
    have hconv : ∀ (V : Set P), IsOpen V → x ∈ V →
        ∃ (a : P), a ∈ A ∧
          ∀ (b : P), b ∈ A → sp.le a b → b ∈ V := by
      intro V hV hxV
      have hVH : @IsOpen P (Topology.scottHausdorff P
          (Set.univ : Set (Set P))) V :=
        (Topology.IsScott.isOpen_iff_isUpperSet_and_scottHausdorff_open.mp hV).2
      obtain ⟨a, ha, htail⟩ := hVH (Set.mem_univ A) hAN hAD hL hxV
      refine ⟨a, ha, ?_⟩
      intro b hb hab
      exact htail ⟨(hsp a b).mp hab, hb⟩
    exact hU A hA x hx hconv

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N045 -/
section
universe u v

namespace PMRVerifier

noncomputable def node_N045 : (
∀ (D : Type u) (E : Type v) (oD : PartialOrder D) (oE : PartialOrder E),
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  ∀ (dcpoD : ∀ (S : Set D) (hne : S.Nonempty)
      (hdir : DirectedOn (fun x y : D => x ≤ y) S), ∃ d : D, IsLUB S d)
    (dcpoE : ∀ (S : Set E) (hne : S.Nonempty)
      (hdir : DirectedOn (fun x y : E => x ≤ y) S), ∃ e : E, IsLUB S e),
  Σ (F : Type (max u v)), {oF : PartialOrder F //
    letI : PartialOrder F := oF
    ∀ (S : Set F) (hne : S.Nonempty)
      (hdir : DirectedOn (fun f g : F => f ≤ g) S), ∃ f : F, IsLUB S f}
) := (
fun (D : Type u) (E : Type v) (oD : PartialOrder D) (oE : PartialOrder E) =>
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  fun _dcpoD dcpoE =>
    letI : TopologicalSpace D := (PMRVerifier.node_N044 D oD).1
    letI : TopologicalSpace E := (PMRVerifier.node_N044 E oE).1
    letI : Topology.IsScott D (Set.univ : Set (Set D)) := ⟨rfl⟩
    letI : Topology.IsScott E (Set.univ : Set (Set E)) := ⟨rfl⟩
    let F : Type (max u v) := {f : D → E // Continuous f}
    let oF : PartialOrder F := inferInstance
    ⟨F, ⟨oF, by
      intro S hne hdir
      have scott_iff (f : D → E) : ScottContinuous f ↔ Continuous f := by
        rw [← scottContinuousOn_univ]
        exact Topology.IsScott.scottContinuousOn_iff_continuous
          (fun _ _ _ => Set.mem_univ _)
      have eval_lub (x : D) :
          ∃ e : E, IsLUB ((fun f : F => f.1 x) '' S) e := by
        apply dcpoE
        · exact hne.image (fun f : F => f.1 x)
        · rintro a ⟨f, hf, rfl⟩ b ⟨g, hg, rfl⟩
          obtain ⟨k, hk, hfk, hgk⟩ := hdir f hf g hg
          exact ⟨k.1 x, ⟨k, hk, rfl⟩, hfk x, hgk x⟩
      let g : D → E := fun x => Classical.choose (eval_lub x)
      have hg (x : D) : IsLUB ((fun f : F => f.1 x) '' S) (g x) :=
        Classical.choose_spec (eval_lub x)
      have hgc : ScottContinuous g := by
        intro A hAne hAdir a ha
        constructor
        · rintro y ⟨x, hx, rfl⟩
          apply (hg x).2
          rintro y ⟨f, hf, rfl⟩
          exact le_trans (((scott_iff f.1).2 f.2).monotone (ha.1 hx))
            ((hg a).1 ⟨f, hf, rfl⟩)
        · intro y hy
          apply (hg a).2
          rintro z ⟨f, hf, rfl⟩
          apply (((scott_iff f.1).2 f.2) hAne hAdir ha).2
          rintro z ⟨x, hx, rfl⟩
          exact le_trans ((hg x).1 ⟨f, hf, rfl⟩) (hy ⟨x, hx, rfl⟩)
      refine ⟨⟨g, (scott_iff g).1 hgc⟩, ?_⟩
      constructor
      · intro f hf x
        exact (hg x).1 ⟨f, hf, rfl⟩
      · intro f hf x
        apply (hg x).2
        rintro y ⟨k, hk, rfl⟩
        exact hf hk x
    ⟩⟩
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N045 -/
section

end

/- Source module PMRVerifier.Statements.N046 -/
section
universe u v

namespace PMRVerifier

def spec_N046 : Prop := (
∀ (D : Type u) (E : Type v) (oD : PartialOrder D) (oE : PartialOrder E),
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  ∀ (dcpoD : ∀ (S : Set D) (hne : S.Nonempty)
      (hdir : DirectedOn (fun x y : D => x ≤ y) S), ∃ d : D, IsLUB S d)
    (dcpoE : ∀ (S : Set E) (hne : S.Nonempty)
      (hdir : DirectedOn (fun x y : E => x ≤ y) S), ∃ e : E, IsLUB S e),
  letI : TopologicalSpace D := (PMRVerifier.node_N044 D oD).1
  letI : TopologicalSpace E := (PMRVerifier.node_N044 E oE).1
  letI : Topology.IsScott D (Set.univ : Set (Set D)) := ⟨rfl⟩
  letI : Topology.IsScott E (Set.univ : Set (Set E)) := ⟨rfl⟩
  let F : Type (max u v) := {f : D → E // Continuous f}
  let oF : PartialOrder F := inferInstance
  letI : PartialOrder F := oF
  (∀ (S : Set F) (hne : S.Nonempty)
      (hdir : DirectedOn (fun f g : F => f ≤ g) S),
    ∃ f : F, IsLUB S f ∧
      ∀ d : D, IsLUB ((fun g : F => g.1 d) '' S) (f.1 d)) ∧
  ScottContinuous (fun p : F × D => p.1.1 p.2)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N046 -/
section
universe u v

namespace PMRVerifier

theorem node_N046 : (
∀ (D : Type u) (E : Type v) (oD : PartialOrder D) (oE : PartialOrder E),
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  ∀ (dcpoD : ∀ (S : Set D) (hne : S.Nonempty)
      (hdir : DirectedOn (fun x y : D => x ≤ y) S), ∃ d : D, IsLUB S d)
    (dcpoE : ∀ (S : Set E) (hne : S.Nonempty)
      (hdir : DirectedOn (fun x y : E => x ≤ y) S), ∃ e : E, IsLUB S e),
  letI : TopologicalSpace D := (PMRVerifier.node_N044 D oD).1
  letI : TopologicalSpace E := (PMRVerifier.node_N044 E oE).1
  letI : Topology.IsScott D (Set.univ : Set (Set D)) := ⟨rfl⟩
  letI : Topology.IsScott E (Set.univ : Set (Set E)) := ⟨rfl⟩
  let F : Type (max u v) := {f : D → E // Continuous f}
  let oF : PartialOrder F := inferInstance
  letI : PartialOrder F := oF
  (∀ (S : Set F) (hne : S.Nonempty)
      (hdir : DirectedOn (fun f g : F => f ≤ g) S),
    ∃ f : F, IsLUB S f ∧
      ∀ d : D, IsLUB ((fun g : F => g.1 d) '' S) (f.1 d)) ∧
  ScottContinuous (fun p : F × D => p.1.1 p.2)
) := (
by
  intro D E oD oE
  letI : PartialOrder D := oD
  letI : PartialOrder E := oE
  intro dcpoD dcpoE
  letI : TopologicalSpace D := (PMRVerifier.node_N044 D oD).1
  letI : TopologicalSpace E := (PMRVerifier.node_N044 E oE).1
  letI : Topology.IsScott D (Set.univ : Set (Set D)) := ⟨rfl⟩
  letI : Topology.IsScott E (Set.univ : Set (Set E)) := ⟨rfl⟩
  let F : Type (max u v) := {f : D → E // Continuous f}
  change (∀ (S : Set F) (hne : S.Nonempty)
    (hdir : DirectedOn (fun f g : F => f ≤ g) S),
    ∃ f : F, IsLUB S f ∧
      ∀ d : D, IsLUB ((fun g : F => g.1 d) '' S) (f.1 d)) ∧
    ScottContinuous (fun p : F × D => p.1.1 p.2)
  have scott_iff (f : D → E) : ScottContinuous f ↔ Continuous f := by
    rw [← scottContinuousOn_univ]
    exact Topology.IsScott.scottContinuousOn_iff_continuous
      (fun _ _ _ => Set.mem_univ _)
  have pointwise (S : Set F) (hne : S.Nonempty)
      (hdir : DirectedOn (fun f g : F => f ≤ g) S) :
      ∃ f : F, IsLUB S f ∧
        ∀ d : D, IsLUB ((fun g : F => g.1 d) '' S) (f.1 d) := by
    have eval_lub (x : D) :
        ∃ e : E, IsLUB ((fun f : F => f.1 x) '' S) e := by
      apply dcpoE
      · exact hne.image (fun f : F => f.1 x)
      · rintro a ⟨f, hf, rfl⟩ b ⟨g, hg, rfl⟩
        obtain ⟨k, hk, hfk, hgk⟩ := hdir f hf g hg
        exact ⟨k.1 x, ⟨k, hk, rfl⟩, hfk x, hgk x⟩
    let g : D → E := fun x => Classical.choose (eval_lub x)
    have hg (x : D) : IsLUB ((fun f : F => f.1 x) '' S) (g x) :=
      Classical.choose_spec (eval_lub x)
    have hgc : ScottContinuous g := by
      intro A hAne hAdir a ha
      constructor
      · rintro y ⟨x, hx, rfl⟩
        apply (hg x).2
        rintro y ⟨f, hf, rfl⟩
        exact le_trans (((scott_iff f.1).2 f.2).monotone (ha.1 hx))
          ((hg a).1 ⟨f, hf, rfl⟩)
      · intro y hy
        apply (hg a).2
        rintro z ⟨f, hf, rfl⟩
        apply (((scott_iff f.1).2 f.2) hAne hAdir ha).2
        rintro z ⟨x, hx, rfl⟩
        exact le_trans ((hg x).1 ⟨f, hf, rfl⟩) (hy ⟨x, hx, rfl⟩)
    refine ⟨⟨g, (scott_iff g).1 hgc⟩, ?_, hg⟩
    constructor
    · intro f hf x
      exact (hg x).1 ⟨f, hf, rfl⟩
    · intro f hf x
      apply (hg x).2
      rintro y ⟨k, hk, rfl⟩
      exact hf hk x
  refine ⟨pointwise, ?_⟩
  intro S hne hdir p hp
  have hS1ne : (Prod.fst '' S).Nonempty := hne.image Prod.fst
  have hS1dir : DirectedOn (fun f g : F => f ≤ g) (Prod.fst '' S) := by
    rintro f ⟨s, hs, rfl⟩ g ⟨t, ht, rfl⟩
    obtain ⟨q, hq, hsq, htq⟩ := hdir s hs t ht
    exact ⟨q.1, ⟨q, hq, rfl⟩, hsq.1, htq.1⟩
  have hS2ne : (Prod.snd '' S).Nonempty := hne.image Prod.snd
  have hS2dir : DirectedOn (fun x y : D => x ≤ y) (Prod.snd '' S) := by
    rintro x ⟨s, hs, rfl⟩ y ⟨t, ht, rfl⟩
    obtain ⟨q, hq, hsq, htq⟩ := hdir s hs t ht
    exact ⟨q.2, ⟨q, hq, rfl⟩, hsq.2, htq.2⟩
  have hp1 : IsLUB (Prod.fst '' S) p.1 := by
    constructor
    · rintro f ⟨q, hq, rfl⟩
      exact (hp.1 hq).1
    · intro g hg
      have hub : (g, p.2) ∈ upperBounds S := by
        intro q hq
        exact ⟨hg ⟨q, hq, rfl⟩, (hp.1 hq).2⟩
      exact (hp.2 hub).1
  have hp2 : IsLUB (Prod.snd '' S) p.2 := by
    constructor
    · rintro d ⟨q, hq, rfl⟩
      exact (hp.1 hq).2
    · intro d hd
      have hub : (p.1, d) ∈ upperBounds S := by
        intro q hq
        exact ⟨(hp.1 hq).1, hd ⟨q, hq, rfl⟩⟩
      exact (hp.2 hub).2
  obtain ⟨g, hg, hgpw⟩ := pointwise (Prod.fst '' S) hS1ne hS1dir
  have hgeq : g = p.1 := le_antisymm (hg.2 hp1.1) (hp1.2 hg.1)
  rw [hgeq] at hgpw
  constructor
  · rintro z ⟨q, hq, rfl⟩
    exact le_trans ((hp.1 hq).1 q.2)
      (((scott_iff p.1.1).2 p.1.2).monotone (hp.1 hq).2)
  · intro y hy
    apply (hgpw p.2).2
    rintro z ⟨f, ⟨s, hs, rfl⟩, rfl⟩
    apply (((scott_iff s.1.1).2 s.1.2) hS2ne hS2dir hp2).2
    rintro z ⟨d, ⟨t, ht, rfl⟩, rfl⟩
    obtain ⟨q, hq, hsq, htq⟩ := hdir s hs t ht
    exact le_trans (hsq.1 t.2)
      (le_trans (((scott_iff q.1.1).2 q.1.2).monotone htq.2)
        (hy ⟨q, hq, rfl⟩))

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N048 -/
section
universe u

namespace PMRVerifier

def spec_N048 : Prop := (
∀ (P : Type u) (o : PartialOrder P),
  letI : PartialOrder P := o
  ∀ (hDcpo : ∀ (E : Set P),
      (PMRVerifier.node_N043).2 P o E → ∃ (s : P), IsLUB E s)
    (A : Set P),
    ((PMRVerifier.node_N002 P o).2.2.2 hDcpo).2 A =
      (PMRVerifier.node_N002 P o).2.2.1 A
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N048 -/
section
universe u

namespace PMRVerifier

theorem node_N048 : (
∀ (P : Type u) (o : PartialOrder P),
  letI : PartialOrder P := o
  ∀ (hDcpo : ∀ (E : Set P),
      (PMRVerifier.node_N043).2 P o E → ∃ (s : P), IsLUB E s)
    (A : Set P),
    ((PMRVerifier.node_N002 P o).2.2.2 hDcpo).2 A =
      (PMRVerifier.node_N002 P o).2.2.1 A
) := (
by
  intro P o
  letI : PartialOrder P := o
  intro hDcpo A
  letI : TopologicalSpace P := (PMRVerifier.node_N002 P o).2.1
  have hClosed : ∀ K : Set P,
      IsClosed K ↔ (PMRVerifier.node_N002 P o).1 K := by
    intro K
    rw [← isOpen_compl_iff]
    change (PMRVerifier.node_N002 P o).1 (Kᶜ)ᶜ ↔
      (PMRVerifier.node_N002 P o).1 K
    rw [compl_compl]
  change
    ⋂₀ {K : Set P |
      ((PMRVerifier.node_N002 P o).2.2.2 hDcpo).1 K ∧ A ⊆ K} =
    ⋂₀ {K : Set P | IsClosed K ∧ A ⊆ K}
  apply congrArg Set.sInter
  apply Set.ext
  intro K
  change
    (((PMRVerifier.node_N002 P o).2.2.2 hDcpo).1 K ∧ A ⊆ K) ↔
      (IsClosed K ∧ A ⊆ K)
  exact and_congr
    ((PMRVerifier.node_N047 P o hDcpo K).symm.trans (hClosed K).symm)
    Iff.rfl
)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N080 -/
section
universe u v

namespace PMRVerifier

def spec_N080 : Prop := (
let Sier : Type u := ULift.{u} Bool
let oSier : PartialOrder Sier := inferInstance
letI : PartialOrder Sier := oSier
let one : Sier := ULift.up true
let sigmaSier : TopologicalSpace Sier := (PMRVerifier.node_N044 Sier oSier).1
(∀ (A : Set Sier), PMRVerifier.node_N043.2 Sier oSier A →
  ∃ (a : Sier), IsLUB A a) ∧
(∀ (U : Set Sier), @IsOpen Sier sigmaSier U ↔
  U = ∅ ∨ U = ({one} : Set Sier) ∨ U = Set.univ) ∧
(sigmaSier = TopologicalSpace.generateFrom {({one} : Set Sier)}) ∧
(∀ (P : Type v) (oP : PartialOrder P),
  letI : PartialOrder P := oP
  ∀ (f : Sier → P), Monotone f →
    ∀ (A : Set Sier) (a : Sier),
      PMRVerifier.node_N043.2 Sier oSier A →
      IsLUB A a → IsLUB (f '' A) (f a))
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N080 -/
section
universe u v

namespace PMRVerifier

theorem node_N080 : (
let Sier : Type u := ULift.{u} Bool
let oSier : PartialOrder Sier := inferInstance
letI : PartialOrder Sier := oSier
let one : Sier := ULift.up true
let sigmaSier : TopologicalSpace Sier := (PMRVerifier.node_N044 Sier oSier).1
(∀ (A : Set Sier), PMRVerifier.node_N043.2 Sier oSier A →
  ∃ (a : Sier), IsLUB A a) ∧
(∀ (U : Set Sier), @IsOpen Sier sigmaSier U ↔
  U = ∅ ∨ U = ({one} : Set Sier) ∨ U = Set.univ) ∧
(sigmaSier = TopologicalSpace.generateFrom {({one} : Set Sier)}) ∧
(∀ (P : Type v) (oP : PartialOrder P),
  letI : PartialOrder P := oP
  ∀ (f : Sier → P), Monotone f →
    ∀ (A : Set Sier) (a : Sier),
      PMRVerifier.node_N043.2 Sier oSier A →
      IsLUB A a → IsLUB (f '' A) (f a))
) := (
by
  classical
  dsimp only
  let Sier : Type u := ULift.{u} Bool
  let zero : Sier := ULift.up false
  let one : Sier := ULift.up true
  let sigmaSier : TopologicalSpace Sier := (PMRVerifier.node_N044 Sier inferInstance).1
  letI : TopologicalSpace Sier := sigmaSier
  letI : Topology.IsScott Sier (Set.univ : Set (Set Sier)) := ⟨rfl⟩
  have hcases (x : Sier) : x = zero ∨ x = one := by
    rcases x with ⟨b⟩
    cases b
    · exact Or.inl rfl
    · exact Or.inr rfl
  have hbot (x : Sier) : zero ≤ x := by
    rcases x with ⟨b⟩
    cases b <;> decide
  have htop (x : Sier) : x ≤ one := by
    rcases x with ⟨b⟩
    cases b <;> decide
  have hgreatest (A : Set Sier) (hA : A.Nonempty) :
      ∃ a, a ∈ A ∧ ∀ x ∈ A, x ≤ a := by
    by_cases h1 : one ∈ A
    · exact ⟨one, h1, fun x _ => htop x⟩
    · obtain ⟨a, ha⟩ := hA
      refine ⟨a, ha, ?_⟩
      intro x hx
      rcases hcases x with h0 | h1x
      · rw [h0]
        exact hbot a
      · exact False.elim (h1 (h1x ▸ hx))
  have hgreatest_lub (A : Set Sier) (a : Sier) (ha : a ∈ A)
      (hmax : ∀ x ∈ A, x ≤ a) : IsLUB A a := by
    exact ⟨fun x hx => hmax x hx, fun y hy => hy ha⟩
  have hlub_mem (A : Set Sier) (hA : A.Nonempty) (a : Sier)
      (ha : IsLUB A a) : a ∈ A := by
    obtain ⟨b, hb, hmax⟩ := hgreatest A hA
    rw [ha.unique (hgreatest_lub A b hb hmax)]
    exact hb
  have hopen (U : Set Sier) : IsOpen U ↔ IsUpperSet U := by
    rw [Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn
      (D := (Set.univ : Set (Set Sier)))]
    constructor
    · exact And.left
    · intro hU
      refine ⟨hU, ?_⟩
      intro A _ hA _ a ha haU
      exact ⟨a, hlub_mem A hA a ha, haU⟩
  have hupper_one : IsUpperSet ({one} : Set Sier) := by
    intro a b hab ha
    have haone : a = one := ha
    have hbone : b = one := le_antisymm (htop b) (haone ▸ hab)
    exact hbone
  have hclass (U : Set Sier) :
      IsUpperSet U ↔ U = ∅ ∨ U = ({one} : Set Sier) ∨ U = Set.univ := by
    constructor
    · intro hU
      by_cases h0 : zero ∈ U
      · right
        right
        apply Set.eq_univ_of_forall
        intro x
        exact hU (hbot x) h0
      · by_cases h1 : one ∈ U
        · right
          left
          apply Set.ext
          intro x
          constructor
          · intro hx
            rcases hcases x with hx0 | hx1
            · exact False.elim (h0 (hx0 ▸ hx))
            · exact hx1
          · intro hx
            have hx1 : x = one := hx
            rw [hx1]
            exact h1
        · left
          apply Set.ext
          intro x
          constructor
          · intro hx
            rcases hcases x with rfl | rfl
            · exact False.elim (h0 hx)
            · exact False.elim (h1 hx)
          · intro hx
            exact False.elim hx
    · rintro (rfl | rfl | rfl)
      · exact isUpperSet_empty
      · exact hupper_one
      · exact isUpperSet_univ
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro A hA
    obtain ⟨a, ha, hmax⟩ := hgreatest A hA.1
    exact ⟨a, hgreatest_lub A a ha hmax⟩
  · intro U
    exact (hopen U).trans (hclass U)
  · change sigmaSier = TopologicalSpace.generateFrom {({one} : Set Sier)}
    apply le_antisymm
    · apply le_generateFrom
      intro U hU
      have heq : U = ({one} : Set Sier) := Set.mem_singleton_iff.mp hU
      rw [heq]
      exact (hopen _).2 hupper_one
    · intro U hU
      rcases ((hopen U).trans (hclass U)).mp hU with rfl | rfl | rfl
      · exact @isOpen_empty Sier (TopologicalSpace.generateFrom {({one} : Set Sier)})
      · exact TopologicalSpace.isOpen_generateFrom_of_mem (by simp)
      · exact @isOpen_univ Sier (TopologicalSpace.generateFrom {({one} : Set Sier)})
  · intro P oP
    letI : PartialOrder P := oP
    intro f hf A a hA ha
    have haA : a ∈ A := hlub_mem A hA.1 a ha
    refine ⟨?_, ?_⟩
    · rintro y ⟨x, hx, rfl⟩
      exact hf (ha.1 hx)
    · intro y hy
      exact hy ⟨a, haA, rfl⟩

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N073 -/
section
universe u

namespace PMRVerifier

def spec_N073 : Prop := (
∀ (Z : Type u) (tZ : TopologicalSpace Z) (hZ : @T0Space Z tZ) (U : Set Z),
  let Sier : Type u := ULift.{u} Bool
  let oSier : PartialOrder Sier := inferInstance
  letI : PartialOrder Sier := oSier
  let one : Sier := ULift.up true
  let sigmaSier : TopologicalSpace Sier := (PMRVerifier.node_N044 Sier oSier).1
  let zero : Sier := ULift.up false
  let chiU : Z → Sier := fun z =>
    @ite Sier (z ∈ U) (Classical.propDecidable (z ∈ U)) one zero
  @IsOpen Z tZ U ↔ @Continuous Z Sier tZ sigmaSier chiU
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N073 -/
section
universe u

namespace PMRVerifier

theorem node_N073 : (
∀ (Z : Type u) (tZ : TopologicalSpace Z) (hZ : @T0Space Z tZ) (U : Set Z),
  let Sier : Type u := ULift.{u} Bool
  let oSier : PartialOrder Sier := inferInstance
  letI : PartialOrder Sier := oSier
  let one : Sier := ULift.up true
  let sigmaSier : TopologicalSpace Sier := (PMRVerifier.node_N044 Sier oSier).1
  let zero : Sier := ULift.up false
  let chiU : Z → Sier := fun z =>
    @ite Sier (z ∈ U) (Classical.propDecidable (z ∈ U)) one zero
  @IsOpen Z tZ U ↔ @Continuous Z Sier tZ sigmaSier chiU
) := (
by
  classical
  intro Z tZ hZ U
  let Sier : Type u := ULift.{u} Bool
  let one : Sier := ULift.up true
  let zero : Sier := ULift.up false
  let sigmaSier : TopologicalSpace Sier :=
    (PMRVerifier.node_N044 Sier inferInstance).1
  let chiU : Z → Sier := fun z => if z ∈ U then one else zero
  letI : TopologicalSpace Z := tZ
  letI : TopologicalSpace Sier := sigmaSier
  change IsOpen U ↔ Continuous chiU
  have hzero_one : zero ≠ one := by
    intro h
    have h' : (false : Bool) = true := congrArg ULift.down h
    cases h'
  have hpre : chiU ⁻¹' ({one} : Set Sier) = U := by
    ext z
    by_cases hz : z ∈ U <;> simp [chiU, hz, hzero_one]
  have hopen (V : Set Sier) :
      IsOpen V ↔ V = ∅ ∨ V = ({one} : Set Sier) ∨ V = Set.univ := by
    exact (PMRVerifier.node_N080.{u, u}).2.1 V
  constructor
  · intro hU
    apply continuous_def.mpr
    intro V hV
    rcases (hopen V).mp hV with rfl | rfl | rfl
    · simp
    · simpa only [hpre] using hU
    · simp
  · intro hc
    have ho : IsOpen ({one} : Set Sier) :=
      (hopen {one}).mpr (Or.inr (Or.inl rfl))
    simpa only [hpre] using ho.preimage hc

)

end PMRVerifier

end

/- Source module PMRVerifier.Statements.N076 -/
section
universe u v w

namespace PMRVerifier

def spec_N076 : Prop := (
∀ (P : Type u) (Q : Type v)
  (oP : PartialOrder P) (oQ : PartialOrder Q),
  letI : PartialOrder P := oP
  letI : PartialOrder Q := oQ
  ∀ (hP : ∀ (A : Set P),
      (PMRVerifier.node_N043).2 P oP A → ∃ (s : P), IsLUB A s)
    (hQ : ∀ (A : Set Q),
      (PMRVerifier.node_N043).2 Q oQ A → ∃ (s : Q), IsLUB A s),
    let σP : TopologicalSpace P := (PMRVerifier.node_N044 P oP).1
    let σQ : TopologicalSpace Q := (PMRVerifier.node_N044 Q oQ).1
    ∀ (f g : P → Q)
      (hf : @Continuous P Q σP σQ f)
      (hg : @Continuous P Q σP σQ g),
      let L : Set P := {p : P | f p = g p}
      let oL : PartialOrder ↥L := inferInstance
      letI : PartialOrder ↥L := oL
      let σL : TopologicalSpace ↥L := (PMRVerifier.node_N044 ↥L oL).1
      let ι : ↥L → P := fun p => p.val
      ((PMRVerifier.node_N002 P oP).2.2.2 hP).1 L ∧
      (∀ (A : Set ↥L),
        (PMRVerifier.node_N043).2 ↥L oL A →
        ∃ (s : ↥L), IsLUB A s) ∧
      @Continuous ↥L P σL σP ι ∧
      Function.comp f ι = Function.comp g ι ∧
      (∀ (R : Type w) (oR : PartialOrder R),
        letI : PartialOrder R := oR
        ∀ (hR : ∀ (A : Set R),
            (PMRVerifier.node_N043).2 R oR A →
            ∃ (s : R), IsLUB A s),
          let σR : TopologicalSpace R := (PMRVerifier.node_N044 R oR).1
          ∀ (h : R → P)
            (hh : @Continuous R P σR σP h)
            (heq : Function.comp f h = Function.comp g h),
            ∃! (hbar : R → ↥L),
              @Continuous R ↥L σR σL hbar ∧
              Function.comp ι hbar = h)
)

end PMRVerifier

end

/- Source module PMRVerifier.Nodes.N076 -/
section
universe u v w

namespace PMRVerifier

theorem node_N076 : (
∀ (P : Type u) (Q : Type v)
  (oP : PartialOrder P) (oQ : PartialOrder Q),
  letI : PartialOrder P := oP
  letI : PartialOrder Q := oQ
  ∀ (hP : ∀ (A : Set P),
      (PMRVerifier.node_N043).2 P oP A → ∃ (s : P), IsLUB A s)
    (hQ : ∀ (A : Set Q),
      (PMRVerifier.node_N043).2 Q oQ A → ∃ (s : Q), IsLUB A s),
    let σP : TopologicalSpace P := (PMRVerifier.node_N044 P oP).1
    let σQ : TopologicalSpace Q := (PMRVerifier.node_N044 Q oQ).1
    ∀ (f g : P → Q)
      (hf : @Continuous P Q σP σQ f)
      (hg : @Continuous P Q σP σQ g),
      let L : Set P := {p : P | f p = g p}
      let oL : PartialOrder ↥L := inferInstance
      letI : PartialOrder ↥L := oL
      let σL : TopologicalSpace ↥L := (PMRVerifier.node_N044 ↥L oL).1
      let ι : ↥L → P := fun p => p.val
      ((PMRVerifier.node_N002 P oP).2.2.2 hP).1 L ∧
      (∀ (A : Set ↥L),
        (PMRVerifier.node_N043).2 ↥L oL A →
        ∃ (s : ↥L), IsLUB A s) ∧
      @Continuous ↥L P σL σP ι ∧
      Function.comp f ι = Function.comp g ι ∧
      (∀ (R : Type w) (oR : PartialOrder R),
        letI : PartialOrder R := oR
        ∀ (hR : ∀ (A : Set R),
            (PMRVerifier.node_N043).2 R oR A →
            ∃ (s : R), IsLUB A s),
          let σR : TopologicalSpace R := (PMRVerifier.node_N044 R oR).1
          ∀ (h : R → P)
            (hh : @Continuous R P σR σP h)
            (heq : Function.comp f h = Function.comp g h),
            ∃! (hbar : R → ↥L),
              @Continuous R ↥L σR σL hbar ∧
              Function.comp ι hbar = h)
) := (
by
  classical
  intro P Q oP oQ
  letI : PartialOrder P := oP
  letI : PartialOrder Q := oQ
  dsimp only
  intro hP hQ
  letI : TopologicalSpace P := (PMRVerifier.node_N044 P oP).1
  letI : TopologicalSpace Q := (PMRVerifier.node_N044 Q oQ).1
  letI : Topology.IsScott P (Set.univ : Set (Set P)) := ⟨rfl⟩
  letI : Topology.IsScott Q (Set.univ : Set (Set Q)) := ⟨rfl⟩
  intro f g hf hg
  let L : Set P := {p | f p = g p}
  let oL : PartialOrder ↥L := inferInstance
  letI : PartialOrder ↥L := oL
  letI : TopologicalSpace ↥L := (PMRVerifier.node_N044 ↥L oL).1
  letI : Topology.IsScott ↥L (Set.univ : Set (Set ↥L)) := ⟨rfl⟩
  let ι : ↥L → P := fun p => p.val
  have fsc : ScottContinuous f := by
    rw [← scottContinuousOn_univ]
    exact (Topology.IsScott.scottContinuousOn_iff_continuous
      (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mpr hf
  have gsc : ScottContinuous g := by
    rw [← scottContinuousOn_univ]
    exact (Topology.IsScott.scottContinuousOn_iff_continuous
      (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mpr hg
  have hsub : ((PMRVerifier.node_N002 P oP).2.2.2 hP).1 L := by
    change ∀ (A : Set P), A ⊆ L → A.Nonempty ∧ DirectedOn (· ≤ ·) A →
      ∃ (s : P), IsLUB A s ∧ s ∈ L
    intro A hAL hA
    obtain ⟨s, hs⟩ := hP A hA
    have himage : f '' A = g '' A := by
      apply Set.Subset.antisymm
      · rintro _ ⟨a, ha, rfl⟩
        exact ⟨a, ha, (hAL ha).symm⟩
      · rintro _ ⟨a, ha, rfl⟩
        exact ⟨a, ha, hAL ha⟩
    have hfs : IsLUB (f '' A) (f s) := fsc hA.1 hA.2 hs
    have hgs : IsLUB (f '' A) (g s) := by
      rw [himage]
      exact gsc hA.1 hA.2 hs
    exact ⟨s, hs, hfs.unique hgs⟩
  have hdir_image : ∀ (A : Set ↥L),
      A.Nonempty ∧ DirectedOn (· ≤ ·) A →
      (ι '' A).Nonempty ∧ DirectedOn (· ≤ ·) (ι '' A) := by
    intro A hA
    refine ⟨hA.1.image ι, ?_⟩
    rintro _ ⟨a, ha, rfl⟩ _ ⟨b, hb, rfl⟩
    obtain ⟨c, hc, hac, hbc⟩ := hA.2 a ha b hb
    exact ⟨ι c, ⟨c, hc, rfl⟩, hac, hbc⟩
  have hlift : ∀ (A : Set ↥L) (s : P) (hsL : s ∈ L),
      IsLUB (ι '' A) s → IsLUB A (⟨s, hsL⟩ : ↥L) := by
    intro A s hsL hs
    constructor
    · intro a ha
      exact hs.1 ⟨a, ha, rfl⟩
    · intro b hb
      apply hs.2
      rintro _ ⟨a, ha, rfl⟩
      exact hb ha
  have hLc : ∀ (A : Set ↥L),
      (PMRVerifier.node_N043).2 ↥L oL A →
      ∃ (s : ↥L), IsLUB A s := by
    intro A hA
    obtain ⟨s, hs, hsL⟩ := hsub (ι '' A)
      (by rintro _ ⟨a, ha, rfl⟩; exact a.property) (hdir_image A hA)
    exact ⟨⟨s, hsL⟩, hlift A s hsL hs⟩
  have isc : ScottContinuous ι := by
    intro A hAn hAdir s hs
    obtain ⟨t, ht, htL⟩ := hsub (ι '' A)
      (by rintro _ ⟨a, ha, rfl⟩; exact a.property)
      (hdir_image A ⟨hAn, hAdir⟩)
    have heq : (⟨t, htL⟩ : ↥L) = s := (hlift A t htL ht).unique hs
    have hval : t = ι s := congrArg Subtype.val heq
    exact hval ▸ ht
  have ic : Continuous ι :=
    (Topology.IsScott.scottContinuousOn_iff_continuous
      (D := Set.univ) (fun _ _ _ => Set.mem_univ _)).mp isc.scottContinuousOn
  refine ⟨hsub, hLc, ic, ?_, ?_⟩
  · funext p
    exact p.property
  · intro R oR
    letI : PartialOrder R := oR
    intro hR
    letI : TopologicalSpace R := (PMRVerifier.node_N044 R oR).1
    intro h hh heq
    obtain ⟨hbar, hcomp, hcont, huniq⟩ :=
      (PMRVerifier.node_N005 R P ↥L P oR oP oL oP hR hP hLc hP).2.2.2
        ι ic (by
          constructor
          · intro a b hab; exact hab
          · intro a b hab; exact hab)
        h hh (by
          rintro _ ⟨r, rfl⟩
          exact ⟨⟨h r, congrFun heq r⟩, rfl⟩)
    exact ⟨hbar, ⟨hcont, hcomp⟩, fun k hk => huniq k hk.2⟩
)

end PMRVerifier

end
