import ScottDCompletable.CanonicalCarriers
import ScottDCompletable.UpperEncoding

/-! Arbitrary carriers for full Cartesian closed subcategories of Top₀.
The canonical function and pair identifications are obtained by the universal
properties on the one-point space, without imposing closure under homeomorphism. -/

noncomputable section
open ScottDCompletable Topology
universe u

namespace ScottDCompletableMaximalityFirst

/-- A full Cartesian closed class presented by its actual categorical objects. -/
structure RawClosedPresentation (C : SpaceClass.{u}) where
  t0 : ∀ {X : Space.{u}}, C X → @T0Space X.Carrier X.topology
  products : RawProductChoices C
  exponents : ∀ {X Y : Space.{u}} (hX : C X) (hY : C Y),
    AbstractExponentialPresentation C products hX hY

variable {C : SpaceClass.{u}} {X Y Z W : Space.{u}}

def rawProductPair (P : RawProductPresentation C X Y) (hZ : C Z)
    (f : Cont Z X) (g : Cont Z Y) : Cont Z P.space :=
  (P.universal Z hZ f g).exists.choose

theorem rawProductPair_fst (P : RawProductPresentation C X Y) (hZ : C Z)
    (f : Cont Z X) (g : Cont Z Y) (z : Z.Carrier) :
    P.fst.val ((rawProductPair P hZ f g).val z) = f.val z :=
  ((P.universal Z hZ f g).exists.choose_spec z).1

theorem rawProductPair_snd (P : RawProductPresentation C X Y) (hZ : C Z)
    (f : Cont Z X) (g : Cont Z Y) (z : Z.Carrier) :
    P.snd.val ((rawProductPair P hZ f g).val z) = g.val z :=
  ((P.universal Z hZ f g).exists.choose_spec z).2

/-- The canonical continuous comparison to the ordinary topological product. -/
def rawProductComparison (P : RawProductPresentation C X Y) :
    Cont P.space (ordinaryProductSpace X Y) := by
  letI : TopologicalSpace P.space.Carrier := P.space.topology
  letI : TopologicalSpace X.Carrier := X.topology
  letI : TopologicalSpace Y.Carrier := Y.topology
  exact ⟨fun p => (P.fst.val p, P.snd.val p), P.fst.property.prodMk P.snd.property⟩

/-- The unique point of the categorical product with the given coordinates. -/
def rawProductPoint (P : RawProductPresentation C X Y) (hPoint : C canonicalPointSpace)
    (x : X.Carrier) (y : Y.Carrier) : P.space.Carrier :=
  (P.carrierEquiv hPoint).symm (x, y)

theorem rawProductPoint_fst (P : RawProductPresentation C X Y) (hPoint : C canonicalPointSpace)
    (x : X.Carrier) (y : Y.Carrier) : P.fst.val (rawProductPoint P hPoint x y) = x :=
  congrArg Prod.fst ((P.carrierEquiv hPoint).apply_symm_apply (x, y))

theorem rawProductPoint_snd (P : RawProductPresentation C X Y) (hPoint : C canonicalPointSpace)
    (x : X.Carrier) (y : Y.Carrier) : P.snd.val (rawProductPoint P hPoint x y) = y :=
  congrArg Prod.snd ((P.carrierEquiv hPoint).apply_symm_apply (x, y))

private def contConst (A B : Space.{u}) (b : B.Carrier) : Cont A B :=
  ⟨fun _ => b, @continuous_const _ _ A.topology B.topology b⟩

private def contId (A : Space.{u}) : Cont A A := ⟨id, @continuous_id _ A.topology⟩

variable {K : RawClosedPresentation C} {hX : C X} {hY : C Y}
variable (E : AbstractExponentialPresentation C K.products hX hY)

/-- The continuous map represented by a point of the actual exponential. -/
def rawEvaluationSection (e : E.space.Carrier) : Cont X Y := by
  let P := K.products E.belongs hX
  let p := rawProductPair P hX (contConst X E.space e) (contId X)
  exact ⟨E.evaluation.val ∘ p.val,
    @Continuous.comp _ _ _ X.topology P.space.topology Y.topology
      _ _ E.evaluation.property p.property⟩

/-- Evaluate at a fixed point using the categorical product pairing. -/
def rawEvaluationAt (x : X.Carrier) : Cont E.space Y := by
  let P := K.products E.belongs hX
  let p := rawProductPair P E.belongs (contId E.space) (contConst E.space X x)
  exact ⟨E.evaluation.val ∘ p.val,
    @Continuous.comp _ _ _ E.space.topology P.space.topology Y.topology
      _ _ E.evaluation.property p.property⟩

theorem rawEvaluationSection_apply (hPoint : C canonicalPointSpace)
    (e : E.space.Carrier) (x : X.Carrier) :
    (rawEvaluationSection E e).val x =
      E.evaluation.val (rawProductPoint (K.products E.belongs hX) hPoint e x) := by
  let P := K.products E.belongs hX
  let p := rawProductPair P hX (contConst X E.space e) (contId X)
  change E.evaluation.val (p.val x) = E.evaluation.val (rawProductPoint P hPoint e x)
  apply congrArg E.evaluation.val
  apply (P.carrierEquiv hPoint).injective
  exact Prod.ext ((rawProductPair_fst P hX _ _ x).trans (rawProductPoint_fst P hPoint e x).symm)
    ((rawProductPair_snd P hX _ _ x).trans (rawProductPoint_snd P hPoint e x).symm)

theorem rawEvaluationAt_apply (hPoint : C canonicalPointSpace)
    (e : E.space.Carrier) (x : X.Carrier) :
    (rawEvaluationAt E x).val e = (rawEvaluationSection E e).val x := by
  let P := K.products E.belongs hX
  let p := rawProductPair P E.belongs (contId E.space) (contConst E.space X x)
  rw [rawEvaluationSection_apply E hPoint]
  change E.evaluation.val (p.val e) = E.evaluation.val (rawProductPoint P hPoint e x)
  apply congrArg E.evaluation.val
  apply (P.carrierEquiv hPoint).injective
  exact Prod.ext
    ((rawProductPair_fst P E.belongs _ _ e).trans (rawProductPoint_fst P hPoint e x).symm)
    ((rawProductPair_snd P E.belongs _ _ e).trans (rawProductPoint_snd P hPoint e x).symm)

private theorem rawEvaluationCondition_iff (hPoint : C canonicalPointSpace)
    (hZ : C Z) (f : Cont (K.products hZ hX).space Y) (k : Cont Z E.space) :
    (∀ (p : (K.products hZ hX).space.Carrier)
      (q : (K.products E.belongs hX).space.Carrier),
        (K.products E.belongs hX).fst.val q = k.val ((K.products hZ hX).fst.val p) →
        (K.products E.belongs hX).snd.val q = (K.products hZ hX).snd.val p →
        E.evaluation.val q = f.val p) ↔
    ∀ z x, (rawEvaluationSection E (k.val z)).val x =
      f.val (rawProductPoint (K.products hZ hX) hPoint z x) := by
  let P := K.products hZ hX
  let Q := K.products E.belongs hX
  constructor
  · intro h z x
    rw [rawEvaluationSection_apply E hPoint]
    refine h _ _ ?_ ?_
    · rw [rawProductPoint_fst, rawProductPoint_fst]
    · rw [rawProductPoint_snd, rawProductPoint_snd]
  · intro h p q h₁ h₂
    let z := P.fst.val p
    let x := P.snd.val p
    have hp : rawProductPoint P hPoint z x = p :=
      (P.carrierEquiv hPoint).symm_apply_apply p
    have hq : rawProductPoint Q hPoint (k.val z) x = q := by
      apply (Q.carrierEquiv hPoint).injective
      exact Prod.ext ((rawProductPoint_fst Q hPoint (k.val z) x).trans h₁.symm)
        ((rawProductPoint_snd Q hPoint (k.val z) x).trans h₂.symm)
    have h' := h z x
    rw [rawEvaluationSection_apply E hPoint, hp, hq] at h'
    exact h'

/-- The universal transposition equation in canonical set coordinates. -/
theorem rawExponentialUniversal (hPoint : C canonicalPointSpace)
    (hZ : C Z) (f : Cont (K.products hZ hX).space Y) :
    ∃! k : Cont Z E.space, ∀ z x, (rawEvaluationSection E (k.val z)).val x =
      f.val (rawProductPoint (K.products hZ hX) hPoint z x) := by
  obtain ⟨k, hk, hu⟩ := E.universal Z hZ f
  exact ⟨k, (rawEvaluationCondition_iff E hPoint hZ f k).mp hk,
    fun l hl => hu l ((rawEvaluationCondition_iff E hPoint hZ f l).mpr hl)⟩

/-- Transpose a map from the actual categorical product. -/
def rawTranspose (hPoint : C canonicalPointSpace) (hZ : C Z)
    (f : Cont (K.products hZ hX).space Y) : Cont Z E.space :=
  (rawExponentialUniversal E hPoint hZ f).exists.choose

theorem rawTranspose_apply (hPoint : C canonicalPointSpace) (hZ : C Z)
    (f : Cont (K.products hZ hX).space Y) (z : Z.Carrier) (x : X.Carrier) :
    (rawEvaluationSection E ((rawTranspose E hPoint hZ f).val z)).val x =
      f.val (rawProductPoint (K.products hZ hX) hPoint z x) :=
  (rawExponentialUniversal E hPoint hZ f).exists.choose_spec z x

theorem rawEvaluationSection_bijective (hPoint : C canonicalPointSpace) :
    Function.Bijective (rawEvaluationSection E) := by
  let P := K.products hPoint hX
  let evalFrom (f : Cont X Y) : Cont P.space Y :=
    ⟨f.val ∘ P.snd.val,
      @Continuous.comp _ _ _ P.space.topology X.topology Y.topology
        _ _ f.property P.snd.property⟩
  have evalFrom_apply (f : Cont X Y) (x : X.Carrier) :
      (evalFrom f).val (rawProductPoint P hPoint PUnit.unit x) = f.val x :=
    congrArg f.val (rawProductPoint_snd P hPoint PUnit.unit x)
  constructor
  · intro a b h
    obtain ⟨k, _, hu⟩ := rawExponentialUniversal E hPoint hPoint (evalFrom (rawEvaluationSection E a))
    have ha := hu (contConst canonicalPointSpace E.space a) (by
      rintro ⟨⟩ x
      exact (evalFrom_apply _ x).symm)
    have hb := hu (contConst canonicalPointSpace E.space b) (by
      rintro ⟨⟩ x
      rw [evalFrom_apply, h]
      rfl)
    exact congrArg (fun l : Cont canonicalPointSpace E.space => l.val PUnit.unit) (ha.trans hb.symm)
  · intro f
    let k := rawTranspose E hPoint hPoint (evalFrom f)
    exact ⟨k.val PUnit.unit, Subtype.ext (funext fun x =>
      (rawTranspose_apply E hPoint hPoint (evalFrom f) PUnit.unit x).trans (evalFrom_apply f x))⟩

/-- The set identification of the exponential by its evaluation sections. -/
def rawExponentialEquiv (hPoint : C canonicalPointSpace) : E.space.Carrier ≃ Cont X Y :=
  Equiv.ofBijective _ (rawEvaluationSection_bijective E hPoint)

/-- Canonical compatibility refers to the evaluation-section map itself. -/
def CanonicalDcpoExponentRaw (K : RawClosedPresentation C) (hScott : ContainsScott C)
    (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q] : Prop :=
  let E := K.exponents (hScott P) (hScott Q)
  ∃ e : @Homeomorph E.space.Carrier (ScottHom P Q) E.space.topology (scott _),
    ∀ f, e f = rawEvaluationSection E f

def CanonicalDcpoExponentsRaw (K : RawClosedPresentation C) (hScott : ContainsScott C) : Prop :=
  ∀ (P Q : Type u) [PartialOrder P] [PartialOrder Q] [IsDCPO P] [IsDCPO Q],
    CanonicalDcpoExponentRaw K hScott P Q

def CanonicalSixExponentsRaw (K : RawClosedPresentation C) (hScott : ContainsScott C) : Prop :=
  ∀ (R : Type u) [PartialOrder R] [IsDCPO R] [OrderBot R] [OrderTop R],
    CanonicalDcpoExponentRaw K hScott SixSource.{u} R

end ScottDCompletableMaximalityFirst
