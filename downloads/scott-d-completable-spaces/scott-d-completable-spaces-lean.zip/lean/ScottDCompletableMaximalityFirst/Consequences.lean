import ScottDCompletableMaximalityFirst.CategoricalEquivalence
import ScottDCompletable.StrictEnlargement

open ScottDCompletable

universe u

namespace ScottDCompletableMaximalityFirst

/-- The strict extension of monotone determined spaces also satisfies canonical
compatibility on Scott dcpos. The witness class is the actual SDC class. -/
theorem canonical_strict_enlargement :
    ∃ (C : SpaceClass.{u}) (K : RawClosedPresentation C) (hScott : ContainsScott C),
      (∀ X, MDSpace X → C X) ∧
      (∃ X, C X ∧ ¬ MDSpace X) ∧
      (∀ X : Space.{u}, @T0Space X.Carrier X.topology →
        @IsCSpace X.Carrier X.topology → C X) ∧
      (∀ (P : Type u) [PartialOrder P], C (scottSpace P)) ∧
      CanonicalDcpoExponentsRaw K hScott :=
  ⟨SDCSpace, sdcRawClosedPresentation, sdcContainsScott,
    sdc_strictly_contains_monotoneSpaces.1, sdc_strictly_contains_monotoneSpaces.2,
    sdc_contains_all_cSpaces, sdc_contains_all_scott_posets, largest_sdc_raw.1⟩

end ScottDCompletableMaximalityFirst
