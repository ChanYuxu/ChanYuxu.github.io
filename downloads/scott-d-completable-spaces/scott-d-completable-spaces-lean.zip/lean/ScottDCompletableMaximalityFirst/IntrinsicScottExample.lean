import ScottDCompletable.SigmaFiniteLimits
import ScottDCompletable.UpperEqualizer
import Mathlib.Data.Nat.Lattice

/-! A dcpo equalizer whose intrinsic Scott topology is strictly finer than
the topology induced by its inclusion in the source dcpo. -/

noncomputable section

open Set CategoryTheory CategoryTheory.Limits ScottDCompletable
open scoped Topology
universe u

namespace ScottDCompletableMaximalityFirst
namespace IntrinsicScottExample

/-- An increasing spine with a limit and a distinct maximal leaf above
each finite initial segment. -/
inductive Fan : Type u where
  | spine (n : ℕ)
  | leaf (n : ℕ)
  | limit

def Fan.below : Fan → Fan → Prop
  | .spine n, .spine m => n ≤ m
  | .spine n, .leaf m => n ≤ m
  | .spine _, .limit => True
  | .leaf n, .leaf m => n = m
  | .limit, .limit => True
  | _, _ => False

instance : PartialOrder Fan where
  le := Fan.below
  le_refl x := by cases x <;> simp [Fan.below]
  le_trans x y z hxy hyz := by
    cases x <;> cases y <;> cases z <;> simp_all only [Fan.below]
    all_goals omega
  le_antisymm x y hxy hyx := by
    cases x <;> cases y <;> simp_all only [Fan.below, Fan.spine.injEq]
    all_goals omega

private theorem maximal_of_not_spine {x : Fan}
    (h : x ∉ Set.range Fan.spine) {y : Fan} (hxy : x ≤ y) : x = y := by
  cases x with
  | spine n => exact False.elim (h (Set.mem_range_self n))
  | leaf n => cases y <;> simpa [Fan.below] using hxy
  | limit =>
    cases y with
    | spine _ => exact False.elim hxy
    | leaf _ => exact False.elim hxy
    | limit => rfl

private theorem bounded_spine_finite (D : Set Fan) (hD : D ⊆ Set.range Fan.spine)
    {n : ℕ} (hn : Fan.spine n ∈ upperBounds D) : D.Finite := by
  apply ((finite_Iic n).image Fan.spine).subset
  intro x hx
  obtain ⟨k, rfl⟩ := hD hx
  exact ⟨k, hn hx, rfl⟩

instance : IsDCPO Fan where
  lub D hne hd := by
    by_cases hD : D ⊆ Set.range Fan.spine
    · by_cases hbound : ∃ n, Fan.spine n ∈ upperBounds D
      · obtain ⟨n, hn⟩ := hbound
        obtain ⟨x, hx⟩ := (bounded_spine_finite D hD hn).exists_maximal hne
        exact ⟨x, (hd.maximal_iff_isGreatest.mp hx).isLUB⟩
      · refine ⟨.limit, ⟨?_, ?_⟩⟩
        · intro x hx
          obtain ⟨n, rfl⟩ := hD hx
          trivial
        · intro y hy
          cases y with
          | limit => exact le_rfl
          | spine n => exact False.elim (hbound ⟨n, hy⟩)
          | leaf n =>
            apply False.elim
            refine hbound ⟨n, ?_⟩
            intro x hx
            obtain ⟨k, rfl⟩ := hD hx
            exact hy hx
    · obtain ⟨x, hx, hmax⟩ := Set.not_subset.mp hD
      refine ⟨x, ⟨?_, fun _ hy => hy hx⟩⟩
      intro y hy
      obtain ⟨z, _, hxz, hyz⟩ := hd x hx y hy
      exact (maximal_of_not_spine hmax hxz).symm ▸ hyz

private theorem spine_directed : DirectedOn (· ≤ ·) (Set.range Fan.spine) := by
  rintro _ ⟨n,rfl⟩ _ ⟨m,rfl⟩
  refine ⟨.spine (max n m), Set.mem_range_self _, ?_, ?_⟩
  · exact (show n ≤ max n m from le_max_left n m)
  · exact (show m ≤ max n m from le_max_right n m)

private theorem spine_lub : IsLUB (Set.range Fan.spine) Fan.limit := by
  constructor
  · rintro _ ⟨n,rfl⟩
    trivial
  · intro x hx
    cases x with
    | limit => exact le_rfl
    | spine n =>
      have h : n + 1 ≤ n := hx (Set.mem_range_self (n+1))
      omega
    | leaf n =>
      have h : n + 1 ≤ n := hx (Set.mem_range_self (n+1))
      omega

/-- The maximal points form an upper antichain. -/
def heads : Set Fan := (Set.range Fan.spine)ᶜ

theorem heads_upper : IsUpperSet heads := by
  intro x y hxy hx
  exact maximal_of_not_spine hx hxy ▸ hx

abbrev sourceDcpo := dcpoObject Fan
abbrev targetDcpo := dcpoObject (UpperEqualizerTarget heads)

def first : sourceDcpo ⟶ targetDcpo :=
  ScottHom.ofScott (upperEqualizerA heads) (upperEqualizerA_scott heads)

def second : sourceDcpo ⟶ targetDcpo :=
  ScottHom.ofScott (upperEqualizerB heads) (upperEqualizerB_scott heads)

abbrev EqualizerCarrier := ↥(scottEqualizerSet first second)

private theorem in_equalizer (x : Fan) :
    x ∈ scottEqualizerSet first second ↔ x ∈ heads :=
  upperEqualizer_eq_iff heads_upper x

def limitPoint : EqualizerCarrier :=
  ⟨.limit, (in_equalizer _).mpr (by rintro ⟨n, hn⟩; cases hn)⟩

private def leafPoint (n : ℕ) : EqualizerCarrier :=
  ⟨.leaf n, (in_equalizer _).mpr (by rintro ⟨k, hk⟩; cases hk)⟩

private theorem equalizer_points_eq {x y : EqualizerCarrier} (h : x ≤ y) : x = y :=
  Subtype.ext (maximal_of_not_spine ((in_equalizer _).mp x.property) h)

theorem limit_open_intrinsic :
    IsOpen[scott EqualizerCarrier] ({limitPoint} : Set EqualizerCarrier) := by
  refine (scott_isOpen_iff _).2 ⟨?_, ?_⟩
  · intro x y hxy hx
    exact equalizer_points_eq hxy ▸ hx
  · intro D hne _ x hx hopen
    obtain ⟨d, hd⟩ := hne
    exact ⟨d, hd, (equalizer_points_eq (hx.1 hd)).symm ▸ hopen⟩

theorem limit_not_open_induced :
    ¬ IsOpen[TopologicalSpace.induced (Subtype.val : EqualizerCarrier → Fan) (scott Fan)]
      ({limitPoint} : Set EqualizerCarrier) := by
  rintro ⟨U, hU, hpre⟩
  have hlim : Fan.limit ∈ U := by
    change limitPoint ∈ Subtype.val ⁻¹' U
    rw [hpre]
    exact Set.mem_singleton _
  have hScott := (scott_isOpen_iff _).1 hU
  obtain ⟨_, ⟨n, rfl⟩, hn⟩ :=
    hScott.2 ⟨Fan.spine 0, Set.mem_range_self _⟩
      spine_directed spine_lub hlim
  have hleaf : leafPoint n ∈ Subtype.val ⁻¹' U :=
    hScott.1 (show Fan.spine n ≤ Fan.leaf n from Nat.le_refl n) hn
  rw [hpre] at hleaf
  have hfalse : Fan.leaf n = Fan.limit := congrArg Subtype.val hleaf
  cases hfalse

theorem explicit_topology_difference :
    scott EqualizerCarrier ≠
      TopologicalSpace.induced (Subtype.val : EqualizerCarrier → Fan) (scott Fan) := by
  intro h
  exact limit_not_open_induced (h ▸ limit_open_intrinsic)

end IntrinsicScottExample

/-- There are parallel dcpo arrows whose actual equalizer fork has intrinsic
Scott topology different from the topology induced by its ambient inclusion. -/
theorem intrinsic_equalizer_topology_ne_subspace :
    ∃ (P Q : DcpoObject.{u}) (a b : P ⟶ Q),
      Nonempty (IsLimit (dcpoEqualizerFork a b)) ∧
      scott (↥(scottEqualizerSet a b)) ≠
        TopologicalSpace.induced Subtype.val (scott P.Carrier) :=
  ⟨IntrinsicScottExample.sourceDcpo, IntrinsicScottExample.targetDcpo,
   IntrinsicScottExample.first, IntrinsicScottExample.second,
   ⟨dcpoEqualizerForkIsLimit _ _⟩,
   IntrinsicScottExample.explicit_topology_difference⟩

end ScottDCompletableMaximalityFirst
