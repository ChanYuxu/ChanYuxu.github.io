import ScottDCompletable.SigmaFiniteLimits

open CategoryTheory CategoryTheory.Limits Set
open ScottDCompletable

universe u v w z

namespace ScottDCompletableMaximalityFirst

/-- Compactness of a dcpo element, in the manuscript's Scott-open form. -/
def IsScottCompactElement {P : Type u} [PartialOrder P] (k : P) : Prop :=
  @IsOpen P (scott P) (Set.Ici k)

/-- Definition 2.1: the commuting equation and unique factorization. -/
def IsEqualizerOf {C : Type u} [Category.{v} C] {E Q R : C}
    (a b : Q ⟶ R) (i : E ⟶ Q) : Prop :=
  i ≫ a = i ≫ b ∧ ∀ (Z : C) (h : Z ⟶ Q), h ≫ a = h ≫ b →
    ∃! g : Z ⟶ E, g ≫ i = h

theorem isEqualizerOf_iff_fork {C : Type u} [Category.{v} C] {E Q R : C}
    (a b : Q ⟶ R) (i : E ⟶ Q) :
    IsEqualizerOf a b i ↔ ∃ eq : i ≫ a = i ≫ b, Nonempty (IsLimit (Fork.ofι i eq)) := by
  constructor
  · rintro ⟨eq, h⟩
    classical
    refine ⟨eq, ⟨Fork.IsLimit.mk' _ ?_⟩⟩
    intro s
    let existsFactor := h s.pt s.ι s.condition
    exact ⟨Classical.choose existsFactor, (Classical.choose_spec existsFactor).1,
      fun {g} hg => (Classical.choose_spec existsFactor).2 g hg⟩
  · rintro ⟨eq, ⟨L⟩⟩
    refine ⟨eq, fun Z h hh => ?_⟩
    let s := Fork.ofι h hh
    refine ⟨L.lift s, Fork.IsLimit.lift_ι L, ?_⟩
    intro g hg
    apply Fork.IsLimit.hom_ext L
    exact hg.trans (Fork.IsLimit.lift_ι L (t := s)).symm

theorem dcpo_equalizerOf {P Q : DcpoObject.{u}} (a b : P ⟶ Q) :
    IsEqualizerOf a b (dcpoEqualizerInclusion a b) :=
  (isEqualizerOf_iff_fork a b _).mpr
    ⟨dcpoEqualizerCondition a b, ⟨dcpoEqualizerForkIsLimit a b⟩⟩

/-- The image of a Scott-continuous order embedding from a dcpo is a sub-dcpo. -/
theorem scottEmbedding_range_subDcpo {P : Type u} {Q : Type v}
    [PartialOrder P] [PartialOrder Q] [IsDCPO P]
    (m : P ↪o Q) (hm : ScottContinuous m) : SubDcpo (range m) := by
  intro B hB hne hdir q hq
  let A := m ⁻¹' B
  have hAne : A.Nonempty := by
    obtain ⟨y, hy⟩ := hne
    obtain ⟨x, rfl⟩ := hB hy
    exact ⟨x, hy⟩
  have hAdir : DirectedOn (· ≤ ·) A := by
    intro x hx y hy
    obtain ⟨b, hb, hxb, hyb⟩ := hdir (m x) hx (m y) hy
    obtain ⟨a, rfl⟩ := hB hb
    exact ⟨a, hb, m.le_iff_le.mp hxb, m.le_iff_le.mp hyb⟩
  have hImage : m '' A = B := by
    ext y
    constructor
    · rintro ⟨x, hx, rfl⟩
      exact hx
    · intro hy
      obtain ⟨x, rfl⟩ := hB hy
      exact ⟨x, hy, rfl⟩
  obtain ⟨p, hp⟩ := IsDCPO.lub A hAne hAdir
  have hl := hm hAne hAdir hp
  rw [hImage] at hl
  exact ⟨p, hl.unique hq⟩

/-- The actual factor through an order embedding preserves directed suprema. -/
theorem scottCorestriction_along_embedding {D : Type u} {P : Type v} {Q : Type w}
    [PartialOrder D] [PartialOrder P] [PartialOrder Q]
    (m : P ↪o Q) {h : D → Q} (hh : ScottContinuous h) (hr : range h ⊆ range m) :
    ∃! g : D → P, ScottContinuous g ∧ ∀ d, m (g d) = h d := by
  classical
  let g (d : D) : P := Classical.choose (hr (mem_range_self d))
  have hg (d : D) : m (g d) = h d := Classical.choose_spec (hr (mem_range_self d))
  refine ⟨g, ⟨?_, hg⟩, ?_⟩
  · intro B hne hdir d hd
    have hl : IsLUB (m '' (g '' B)) (m (g d)) := by
      rw [image_image, show (fun x => m (g x)) = h from funext hg, hg d]
      exact hh hne hdir hd
    refine ⟨?_, ?_⟩
    · intro p hp
      exact m.le_iff_le.mp (hl.1 ⟨p, hp, rfl⟩)
    · intro p hp
      apply m.le_iff_le.mp (hl.2 ?_)
      rintro _ ⟨a, ha, rfl⟩
      exact m.monotone (hp ha)
  · intro g' hg'
    funext d
    exact m.injective ((hg'.2 d).trans (hg d).symm)

/-- Lemma 2.7, with the factor map and all four clauses explicit. -/
theorem subdcpo_tools (D : Type u) (E : Type v) (P : Type w) (Q : Type z)
    [PartialOrder D] [IsDCPO D] [PartialOrder E] [IsDCPO E]
    [PartialOrder P] [IsDCPO P] [PartialOrder Q] [IsDCPO Q] :
    (∀ A K : Set D, generated A = univ → SubDcpo K → A ⊆ K → K = univ) ∧
    (∀ (h : D → E) (K : Set E), ScottContinuous h → SubDcpo K → SubDcpo (h ⁻¹' K)) ∧
    (∀ (m : P ↪o Q), ScottContinuous m → SubDcpo (range m)) ∧
    (∀ (m : P ↪o Q) (h : D → Q), ScottContinuous m → ScottContinuous h →
      range h ⊆ range m → ∃! g : D → P, ScottContinuous g ∧ ∀ d, m (g d) = h d) :=
  ⟨fun _ _ hgen hK hAK => generated_eq_of_superset hgen hAK hK,
    fun _ _ hh hK => subDcpo_preimage hh hK, scottEmbedding_range_subDcpo,
    fun m _ _ hh hr => scottCorestriction_along_embedding m hh hr⟩

end ScottDCompletableMaximalityFirst
