import ScottDCompletableMaximalityFirst.Maximality
import ScottDCompletable.SigmaFiniteLimits
import ScottDCompletable.ScottPreservation

/-! The categorical characterization for full subcategories with arbitrary
chosen product and exponential carriers. -/

noncomputable section
open ScottDCompletable CategoryTheory CategoryTheory.Limits
universe u

namespace ScottDCompletableMaximalityFirst

/-- The raw presentation for a class whose products and exponentials have
already been realized on the canonical set carriers. -/
def rawClosedPresentationOfCanonical {C : SpaceClass.{u}} (K : ClosedPresentation C) :
    RawClosedPresentation C := by
  let products : RawProductChoices C := fun hX hY =>
    let P := K.products hX hY
    ⟨P.space, P.belongs, ⟨Prod.fst,P.fst_continuous⟩, ⟨Prod.snd,P.snd_continuous⟩,
      P.universal⟩
  refine ⟨K.t0, products, ?_⟩
  intro X Y hX hY
  let E := K.exponents hX hY
  refine ⟨E.space, E.belongs, ⟨fun p => p.1.val p.2, E.evaluation_continuous⟩, ?_⟩
  intro Z hZ f
  let tr : Cont Z E.space :=
    ⟨transpose (K.products hZ hX) hX f, E.transpose_continuous hZ f⟩
  refine ⟨tr, ?_, ?_⟩
  · intro p q h₁ h₂
    change q.1.val q.2 = f.val p
    change q.1 = tr.val p.1 at h₁
    change q.2 = p.2 at h₂
    rw [h₁, h₂]
    rfl
  · intro g hg
    apply Subtype.ext
    funext z
    apply Subtype.ext
    funext x
    exact hg (z,x) (g.val z,x) rfl rfl

abbrev sdcRawClosedPresentation : RawClosedPresentation (SDCSpace : SpaceClass.{u}) :=
  rawClosedPresentationOfCanonical sdcClosedPresentation

variable {C : SpaceClass.{u}} (K : RawClosedPresentation C) (hScott : ContainsScott C)

private theorem dcpoOfOrderIso {P H : Type u} [PartialOrder P] [PartialOrder H]
    [IsDCPO H] (e : P ≃o H) : IsDCPO P where
  lub A hne hd := by
    obtain ⟨b, hb⟩ := IsDCPO.lub (e '' A) (hne.image e)
      (directedOn_image.mpr (hd.mono (fun _ _ h => e.monotone h)))
    exact ⟨e.symm b, e.isLUB_image.mp hb⟩

/-- The mixed exponential homeomorphism sends a point of the actual
exponential to the unique extension of its evaluation section. -/
theorem mixedExponentialRaw_homeomorph (hSDC : ∀ X, C X → SDCSpace X)
    {X : Space.{u}} (hX : C X)
    (CX : @ScottCompletion X.Carrier X.topology) (Q : Type u) [PartialOrder Q] [IsDCPO Q] :
    letI : TopologicalSpace X.Carrier := X.topology
    let E := K.exponents hX (hScott Q)
    ∃ e : @Homeomorph E.space.Carrier (ScottHom CX.Carrier Q) E.space.topology (scott _),
      ∀ f, e f = CX.extend (rawEvaluationSection E f).val (rawEvaluationSection E f).property := by
  let E := K.exponents hX (hScott Q)
  letI : TopologicalSpace X.Carrier := X.topology
  let H := ScottHom CX.Carrier Q
  let F : Space := scottSpace H
  have hF : C F := hScott H
  let P := K.products hF hX
  letI : TopologicalSpace P.space.Carrier := P.space.topology
  letI : TopologicalSpace E.space.Carrier := E.space.topology
  letI : TopologicalSpace H := scott H
  letI : TopologicalSpace Q := scott Q
  letI : T0Space E.space.Carrier := K.t0 E.belongs
  have hPoint : C canonicalPointSpace := hScott PUnit.{u + 1}
  obtain ⟨CP⟩ := hSDC P.space P.belongs
  let CF := scottCompletion H
  have hcomparison : @Continuous _ _ P.space.topology (productTopology CF CX)
      (fun p => (P.fst.val p, P.snd.val p)) :=
    product_pair CP CF CX P.fst.toContinuousMap P.snd.toContinuousMap
  have hevaluation : @Continuous _ _ (productTopology CF CX) (scott Q)
      (fun p : H × X.Carrier => p.1.val (CX.unit p.2)) := by
    letI : TopologicalSpace (H × X.Carrier) := productTopology CF CX
    letI : TopologicalSpace (H × CX.Carrier) := scott _
    letI : TopologicalSpace Q := scott _
    exact (scott_iff_continuous.mp scott_eval).comp (productCompletion CF CX).embedding.continuous
  let eval : Cont P.space (scottSpace Q) :=
    ⟨fun p => (P.fst.val p).val (CX.unit (P.snd.val p)),
      @Continuous.comp _ _ _ P.space.topology (productTopology CF CX) (scott Q)
        _ _ hevaluation hcomparison⟩
  let restriction := rawTranspose E hPoint hF eval
  let extend : Cont X (scottSpace Q) ≃o H := extensionOrderIso CX
  let extension : E.space.Carrier ≃ H := (rawExponentialEquiv E hPoint).trans extend.toEquiv
  have hSection (f : H) : rawEvaluationSection E (restriction.val f) = extend.symm f := by
    apply Subtype.ext
    funext x
    rw [rawTranspose_apply E hPoint hF eval f x]
    change (P.fst.val (rawProductPoint P hPoint f x)).val
      (CX.unit (P.snd.val (rawProductPoint P hPoint f x))) = f.val (CX.unit x)
    rw [rawProductPoint_fst, rawProductPoint_snd]
  have hRestriction : restriction.val = extension.symm := by
    funext f
    apply extension.injective
    rw [extension.apply_symm_apply]
    change extend (rawEvaluationSection E (restriction.val f)) = f
    rw [hSection, extend.apply_symm_apply]
  have hinv : Continuous (extension.symm : H → E.space.Carrier) :=
    hRestriction ▸ restriction.property
  have hSpec (f g : E.space.Carrier) : Specializes g f ↔ extension f ≤ extension g := by
    constructor
    · intro h
      apply (extend.map_rel_iff).mpr
      intro x
      have hp := h.map (rawEvaluationAt E x).property
      have hv := (specializes_scott_iff _ _).mp hp
      rwa [rawEvaluationAt_apply E hPoint, rawEvaluationAt_apply E hPoint] at hv
    · intro h
      have hp := ((specializes_scott_iff (extension f) (extension g)).mpr h).map hinv
      rwa [extension.symm_apply_apply, extension.symm_apply_apply] at hp
  letI : PartialOrder E.space.Carrier := specializationOrder E.space.Carrier
  let e : E.space.Carrier ≃o H := {
    extension with
    map_rel_iff' := fun {f g} => (hSpec f g).symm
  }
  have hDcpo : IsDCPO E.space.Carrier := dcpoOfOrderIso e
  have hId : @Continuous _ _ (scott E.space.Carrier) E.space.topology id := by
    have h := @Continuous.comp _ _ _ (scott E.space.Carrier) (scott H) E.space.topology
      e e.symm hinv (scott_iff_continuous.mp (orderIso_scott e))
    convert h using 1
    funext f
    exact (e.symm_apply_apply f).symm
  have hScottCoarser : scott E.space.Carrier ≤ E.space.topology :=
    fun U hU => continuous_def.mp hId U hU
  have hMC : IsMonotoneConvergence E.space.Carrier := ⟨hDcpo,hScottCoarser⟩
  have hTopology : E.space.topology = scott E.space.Carrier :=
    (identityDCompletion E.space.Carrier hMC).topology_eq_scott_of_sdc (hSDC E.space E.belongs)
  have hfwd : Continuous (extension : E.space.Carrier → H) := by
    change @Continuous E.space.Carrier H E.space.topology (scott H) extension
    rw [hTopology]
    exact scott_iff_continuous.mp (orderIso_scott e)
  exact ⟨{ extension with continuous_toFun := hfwd, continuous_invFun := hinv }, fun _ => rfl⟩

/-- Condition (i) implies canonical dcpo exponentials through the mixed
homeomorphism and the identity completion of a Scott dcpo. -/
theorem canonical_exponents_raw_of_subclass_sdc (hSDC : ∀ X, C X → SDCSpace X) :
    CanonicalDcpoExponentsRaw K hScott := by
  intro P Q _ _ _ _
  letI : TopologicalSpace P := scott P
  obtain ⟨e, he⟩ := mixedExponentialRaw_homeomorph K hScott hSDC (hScott P) (scottCompletion P) Q
  refine ⟨e, ?_⟩
  intro f
  refine (he f).trans ?_
  apply Subtype.ext
  funext x
  exact (scottCompletion P).extend_unit _ _ x

/-- The extension map in the displayed mixed exponential for each member of the full class. -/
def MixedExponentialsRaw : Prop :=
  ∀ (X : Space.{u}) (hX : C X) (CX : @ScottCompletion X.Carrier X.topology)
    (Q : Type u) [PartialOrder Q] [IsDCPO Q],
    letI : TopologicalSpace X.Carrier := X.topology
    let E := K.exponents hX (hScott Q)
    ∃ e : @Homeomorph E.space.Carrier (ScottHom CX.Carrier Q) E.space.topology (scott _),
      ∀ f, e f = CX.extend (rawEvaluationSection E f).val (rawEvaluationSection E f).property

/-- The standard D-completion, retaining its carrier, order and unit. -/
def standardScottCompletionFor {X : Space.{u}} (hT0 : @T0Space X.Carrier X.topology)
    (hSDC : SDCSpace X) : @ScottCompletion X.Carrier X.topology := by
  letI : TopologicalSpace X.Carrier := X.topology
  letI : T0Space X.Carrier := hT0
  let D := standardCompletion X.Carrier
  exact D.toScottCompletion (D.topology_eq_scott_of_sdc hSDC)

/-- The displayed mixed exponential for the actual standard completion. -/
theorem source_mixed_exponential (hSDC : ∀ X, C X → SDCSpace X)
    {X : Space.{u}} (hX : C X) (Q : Type u) [PartialOrder Q] [IsDCPO Q] :
    letI : TopologicalSpace X.Carrier := X.topology
    let E := K.exponents hX (hScott Q)
    let D := standardScottCompletionFor (K.t0 hX) (hSDC X hX)
    ∃ e : @Homeomorph E.space.Carrier (ScottHom D.Carrier Q) E.space.topology (scott _),
      ∀ f, e f = D.extend (rawEvaluationSection E f).val (rawEvaluationSection E f).property :=
  mixedExponentialRaw_homeomorph K hScott hSDC hX
    (standardScottCompletionFor (K.t0 hX) (hSDC X hX)) Q

/-- The four equivalent categorical conditions and their two conclusions. -/
theorem source_compatibility :
    ((∀ X, C X → SDCSpace X) ↔ CanonicalDcpoExponentsRaw K hScott) ∧
    (CanonicalDcpoExponentsRaw K hScott ↔ CanonicalSixExponentsRaw K hScott) ∧
    (CanonicalSixExponentsRaw K hScott ↔
      PreservesLimitsOfShape WalkingParallelPair (sigmaFunctor hScott)) ∧
    ((∀ X, C X → SDCSpace X) →
      PreservesFiniteLimits (sigmaFunctor hScott) ∧ MixedExponentialsRaw K hScott) := by
  have firstToSecond := canonical_exponents_raw_of_subclass_sdc K hScott
  have secondToThird : CanonicalDcpoExponentsRaw K hScott → CanonicalSixExponentsRaw K hScott :=
    fun h R _ _ _ _ => h SixSource.{u} R
  have thirdToFirst := source_exponent_maximality_direct K hScott
  have firstToFourth (h : ∀ X, C X → SDCSpace X) :
      PreservesLimitsOfShape WalkingParallelPair (sigmaFunctor hScott) :=
    sigma_preserves_equalizers hScott
      (preservesScottEqualizers_of_subclass_sdc hScott (fun {X} => h X))
  have fourthToFirst (h : PreservesLimitsOfShape WalkingParallelPair (sigmaFunctor hScott))
      (X : Space.{u}) (hX : C X) : SDCSpace X := by
    letI : TopologicalSpace X.Carrier := X.topology
    letI : T0Space X.Carrier := K.t0 hX
    exact source_sdc_of_upperCorestrictions (upperCorestrictions_of_preservesScottEqualizers
      ((preservesScottEqualizers_iff_categorical hScott).mpr h) hX)
  refine ⟨⟨firstToSecond, fun h => thirdToFirst (secondToThird h)⟩,
    ⟨secondToThird, fun h => firstToSecond (thirdToFirst h)⟩,
    ⟨fun h => firstToFourth (thirdToFirst h), fun h => secondToThird (firstToSecond (fourthToFirst h))⟩,
    fun h => ⟨sigma_preserves_finite_limits hScott h, ?_⟩⟩
  intro X hX DX Q _ _
  exact mixedExponentialRaw_homeomorph K hScott h hX DX Q

/-- The exponential topology on the continuous function set is independent
of the chosen Scott completions. The identity comparison is the transpose
of evaluation along the product comparison. -/
theorem exponentialTopology_eq_of_completions {X Y : Type u}
    [TopologicalSpace X] [TopologicalSpace Y]
    (CX DX : ScottCompletion X) (CY DY : ScottCompletion Y) :
    exponentialTopology CX CY = exponentialTopology DX DY := by
  have compare (A B : ScottCompletion X) (M N : ScottCompletion Y) :
      exponentialTopology A M ≤ exponentialTopology B N := by
    letI : TopologicalSpace (ContinuousMap X Y) := exponentialTopology A M
    let E := exponentialCompletion A M
    let S := ContinuousMap X Y × X
    letI : TopologicalSpace S := productTopology E B
    have pairContinuous : @Continuous S S (productTopology E B) (productTopology E A)
        (fun p => (p.1, p.2)) :=
      product_pair (productCompletion E B) E A
        ⟨Prod.fst, product_fst E B⟩ ⟨Prod.snd, product_snd E B⟩
    let eval : @ContinuousMap S Y (productTopology E B) _ :=
      ⟨fun p => p.1 p.2, @Continuous.comp S S Y
        (productTopology E B) (productTopology E A) _ _ _
        (exponential_evaluation A M) pairContinuous⟩
    let curry : @ContinuousMap (ContinuousMap X Y) (ContinuousMap X Y)
        (exponentialTopology A M) (exponentialTopology B N) := exponentialCurry E B N eval
    let curryFn : ContinuousMap X Y → ContinuousMap X Y :=
      @ContinuousMap.toFun _ _ (exponentialTopology A M) (exponentialTopology B N) curry
    have curryContinuous : @Continuous (ContinuousMap X Y) (ContinuousMap X Y)
        (exponentialTopology A M) (exponentialTopology B N) curryFn :=
      @ContinuousMap.continuous_toFun _ _ (exponentialTopology A M) (exponentialTopology B N) curry
    apply continuous_id_iff_le.mp
    have pointwise : curryFn = id := by
      funext f
      apply ContinuousMap.ext
      intro x
      rfl
    exact pointwise ▸ curryContinuous
  exact le_antisymm (compare CX DX CY DY) (compare DX CX DY CY)

/-- Theorem 3.9's identity-completion comparison, transported to the chosen
SDC presentation along the identity on continuous functions. -/
theorem sdc_canonical_dcpo_exponents :
    CanonicalDcpoExponentsRaw sdcRawClosedPresentation.{u} sdcContainsScott := by
  intro P Q _ _ _ _
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace Q := scott Q
  let t := exponentialTopology (scottCompletion P) (scottCompletion Q)
  let tE := sdcExponentialTopology (sdcContainsScott P) (sdcContainsScott Q)
  let toMap := Cont.toContinuousMap (X := scottSpace P) (Y := scottSpace Q)
  have ht : tE = TopologicalSpace.induced toMap t := by
    change TopologicalSpace.induced toMap
      (exponentialTopology (completionOf (sdcContainsScott P))
        (completionOf (sdcContainsScott Q))) = _
    rw [exponentialTopology_eq_of_completions _ (scottCompletion P) _ (scottCompletion Q)]
  let e : @Homeomorph (Cont (scottSpace P) (scottSpace Q)) (ContinuousMap P Q) tE t :=
    { toEquiv :=
        { toFun := toMap
          invFun := fun f => ⟨f, f.continuous⟩
          left_inv := fun _ => rfl
          right_inv := fun _ => rfl }
      continuous_toFun := by rw [ht]; exact continuous_induced_dom
      continuous_invFun := by
        rw [ht]
        exact continuous_induced_rng.mpr continuous_id }
  obtain ⟨comparison, hcomparison, _⟩ := (sigma_preserves_constructions P Q).2.2.2.2.2.2
  refine ⟨@Homeomorph.trans _ _ _ tE t (scott (ScottHom P Q)) e comparison,
    fun f => Subtype.ext (funext fun x => ?_)⟩
  change (comparison (toMap f)).val x =
    (rawEvaluationSection (sdcRawClosedPresentation.exponents
      (sdcContainsScott P) (sdcContainsScott Q)) f).val x
  rw [hcomparison, rawEvaluationSection_apply _ (sdcContainsScott PUnit.{u+1})]
  let E := sdcRawClosedPresentation.exponents (sdcContainsScott P) (sdcContainsScott Q)
  let product := sdcRawClosedPresentation.products E.belongs (sdcContainsScott P)
  let point := rawProductPoint product (sdcContainsScott PUnit.{u+1}) f x
  change f.val x = point.1.val point.2
  have hf : point.1 = f := rawProductPoint_fst product _ f x
  have hx : point.2 = x := rawProductPoint_snd product _ f x
  rw [hf, hx]

/-- The largest full Cartesian closed class satisfying the canonical exponential
condition is the class of Scott D-completable spaces. -/
theorem largest_sdc_raw :
    CanonicalDcpoExponentsRaw sdcRawClosedPresentation.{u} sdcContainsScott ∧
    ∀ (A : SpaceClass.{u}) (KA : RawClosedPresentation A) (hA : ContainsScott A),
      CanonicalDcpoExponentsRaw KA hA → ∀ X, A X → SDCSpace X :=
  ⟨sdc_canonical_dcpo_exponents,
    fun _ KA hA h => source_exponent_maximality_direct KA hA (fun R _ _ _ _ => h SixSource.{u} R)⟩

/-- The maximality theorem with its stated largestness consequence. -/
theorem source_exponent_maximality :
    (CanonicalSixExponentsRaw K hScott → ∀ X, C X → SDCSpace X) ∧
    CanonicalDcpoExponentsRaw sdcRawClosedPresentation.{u} sdcContainsScott ∧
    (∀ (A : SpaceClass.{u}) (KA : RawClosedPresentation A) (hA : ContainsScott A),
      CanonicalDcpoExponentsRaw KA hA → ∀ X, A X → SDCSpace X) :=
  ⟨source_exponent_maximality_direct K hScott, largest_sdc_raw⟩

end ScottDCompletableMaximalityFirst
