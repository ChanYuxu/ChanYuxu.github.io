import ScottDCompletable.Compatibility
import ScottDCompletableMaximalityFirst.RawCategory

/-! The Scott subspace equation and the fixed-source space characterizations. -/

noncomputable section
open Set ScottDCompletable
open Topology (IsEmbedding)
open scoped Topology

universe u

namespace ScottDCompletableMaximalityFirst

/-- On the fixed finite source, monotonicity already preserves directed suprema. -/
theorem sixSource_monotone_scott {R : Type u} [PartialOrder R] {f : SixSource.{u} → R}
    (hf : Monotone f) : ScottContinuous f := by
  intro A hne hdir a ha
  obtain ⟨b, hb⟩ := (Set.toFinite A).exists_maximal hne
  have hb' := hdir.maximal_iff_isGreatest.mp hb
  rw [ha.unique hb'.isLUB]
  exact (show IsGreatest (f '' A) (f b) from
    ⟨⟨b, hb'.1, rfl⟩, by rintro _ ⟨x, hx, rfl⟩; exact hf (hb'.2 hx)⟩).isLUB

/-- Equation `scott-subspace`: the intrinsic topology is the ordinary trace. -/
theorem scott_subspace_open_or_closed {P : Type u} [PartialOrder P] [IsDCPO P]
    (B : Set P) (_hSub : SubDcpo B) (hB : IsOpen[scott P] B ∨ IsClosed[scott P] B) :
    scott B = TopologicalSpace.induced (Subtype.val : B → P) (scott P) ∧
      {U : Set B | IsOpen[scott B] U} =
        (fun U : Set P => (Subtype.val : B → P) ⁻¹' U) '' {U | IsOpen[scott P] U} := by
  letI : TopologicalSpace P := scott P
  letI : TopologicalSpace B := scott B
  have h : IsEmbedding (Subtype.val : B → P) :=
    hB.elim scott_subspace_of_open scott_subspace_of_closed
  exact ⟨h.isInducing.eq_induced, h.isInducing.setOf_isOpen⟩

/-- The identity is a Scott completion of the empty space. -/
theorem empty_isSDC (X : Type u) [TopologicalSpace X] [T0Space X] [IsEmpty X] : IsSDC X := by
  letI : PartialOrder X := specializationOrder X
  let dcpo : IsDCPO X := ⟨fun _ hne _ => isEmptyElim hne.choose⟩
  refine ⟨⟨X, inferInstance, dcpo, id, ?_, Set.eq_univ_of_forall (fun x => isEmptyElim x)⟩⟩
  exact @IsEmbedding.of_subsingleton X X ‹TopologicalSpace X› (scott X) inferInstance id

/-- Transpose the encoded standard completion unit in the given full
category. This direct proof precedes the equivalent space conditions. -/
theorem source_exponent_maximality_direct {C : SpaceClass.{u}} (K : RawClosedPresentation C)
    (hScott : ContainsScott C) (hSix : CanonicalSixExponentsRaw K hScott) :
    ∀ X, C X → SDCSpace X := by
  intro X hX
  letI : TopologicalSpace X.Carrier := X.topology
  letI : T0Space X.Carrier := K.t0 hX
  rcases isEmpty_or_nonempty X.Carrier with hEmpty | hne
  · letI : IsEmpty X.Carrier := hEmpty
    exact empty_isSDC X.Carrier
  let D := standardCompletion X.Carrier
  letI : TopologicalSpace D.Carrier := D.topology
  letI : PartialOrder D.Carrier := D.order
  letI : IsDCPO D.Carrier := D.dcpo
  obtain ⟨P, oP, dP, ρ, hρ, hupper⟩ :=
    exists_upper_scott_embedding (M := D.Carrier) (fun _ _ => Iff.rfl) D.topology_le_scott
  letI : PartialOrder P := oP
  letI : IsDCPO P := dP
  letI : TopologicalSpace P := scott P
  let A := Set.range ρ
  let f := ρ ∘ D.unit
  have hf : Continuous f := hρ.continuous.comp D.embedding.continuous
  have hm (x : X.Carrier) : f x ∈ A := ⟨D.unit x, rfl⟩
  let x₀ := Classical.choice hne
  obtain ⟨R, oR, hR⟩ := upper_encoding.{u, u} A hupper ⟨f x₀, hm x₀⟩
  letI : PartialOrder R := oR
  obtain ⟨dR, ⟨bR⟩, ⟨tR⟩, _, j, _, _, hj, hcont⟩ := hR
  letI : IsDCPO R := dR
  letI : OrderBot R := bR
  letI : OrderTop R := tR
  let H := fun p : X.Carrier × SixSource.{u} => (j ⟨f p.1, hm p.1⟩).val p.2
  have hH : @Continuous (X.Carrier × SixSource.{u}) R
      (ordinarySixTopology X.Carrier) (scott R) H :=
    hcont X.Carrier f hf hm
  let hPoint : C canonicalPointSpace := hScott PUnit.{u + 1}
  let hT := hScott SixSource.{u}
  let hY := hScott R
  let prod := K.products hX hT
  let q := rawProductComparison prod
  let F : Cont prod.space (scottSpace R) := ⟨H ∘ q.val,
    @Continuous.comp _ _ _ prod.space.topology (ordinarySixTopology X.Carrier) (scott R) _ _
      hH q.property⟩
  let E := K.exponents hT hY
  let k₀ := rawTranspose (K := K) E hPoint hX F
  obtain ⟨e, he⟩ := hSix R
  letI : TopologicalSpace (K.exponents (hScott SixSource.{u}) (hScott R)).space.Carrier :=
    E.space.topology
  letI : TopologicalSpace (ScottHom SixSource.{u} R) := scott _
  let k := fun x : X.Carrier => e (k₀.val x)
  have hk : Continuous k := e.continuous_toFun.comp k₀.property
  let fA : X.Carrier → A := fun x => ⟨f x, hm x⟩
  have hEq : k = j ∘ fA := by
    funext x
    apply Subtype.ext
    funext t
    change (e (k₀.val x)).val t = H (x, t)
    rw [he]
    rw [show (rawEvaluationSection (K := K) E (k₀.val x)).val t =
        F.val (rawProductPoint prod hPoint x t) from rawTranspose_apply E hPoint hX F x t]
    change H (prod.fst.val (rawProductPoint prod hPoint x t),
      prod.snd.val (rawProductPoint prod hPoint x t)) = H (x, t)
    rw [rawProductPoint_fst, rawProductPoint_snd]
  letI : TopologicalSpace A := scott A
  have hfA : Continuous fA := hj.isInducing.continuous_iff.mpr (hEq ▸ hk)
  let ρA : D.Carrier ≃o A :=
    { toEquiv := Equiv.ofInjective ρ hρ.injective
      map_rel_iff' := by
        intro a b
        change ρ a ≤ ρ b ↔ a ≤ b
        rw [← specializes_scott_iff, hρ.isInducing.specializes_iff]
        rfl }
  have hu : @Continuous X.Carrier D.Carrier _ (scott D.Carrier) D.unit := by
    letI : TopologicalSpace D.Carrier := scott D.Carrier
    have hc := (scott_iff_continuous.mp (orderIso_scott ρA.symm)).comp hfA
    convert hc using 1
    funext x
    exact (ρA.symm_apply_apply (D.unit x)).symm
  exact ⟨D.toScottCompletion (D.topology_eq_scott_of_continuous_unit hu)⟩

/-- The source's implication (i) ⇒ (iv), using the actual SDC transpose after the product comparison. -/
theorem source_finiteSourceTest_of_sdc {X : Type u} [TopologicalSpace X]
    (hX : IsSDC X) : FiniteSourceTest X := by
  intro R _ _ _ _ H hH
  let X' : Space.{u} := ⟨X, inferInstance⟩
  have hX' : SDCSpace X' := hX
  let Y := scottSpace R
  let hT := sdcContainsScott SixSource.{u}
  let hY := sdcContainsScott R
  let P := sdcClosedPresentation.products hX' hT
  let F : Cont P.space Y := ⟨H,
    @Continuous.comp _ _ _ P.spaceTopology (ordinarySixTopology X) (scott R) _ _
      hH P.comparison⟩
  have hc := (sdcClosedPresentation.exponents hT hY).transpose_continuous hX' F
  have hE : (sdcClosedPresentation.exponents hT hY).spaceTopology =
      scott (ScottHom SixSource.{u} R) :=
    canonical_exponents_of_subclass_sdc sdcClosedPresentation sdcContainsScott
      (fun _ h => h) SixSource.{u} R
  rw [hE] at hc
  exact hc

/-- The source's implication (iv) ⇒ (iii), with the empty and encoded upper-set cases. -/
theorem source_upperCorestrictions_of_finiteSourceTest {X : Type u} [TopologicalSpace X]
    (hX : FiniteSourceTest X) : UpperCorestrictions X := by
  intro P _ _ A hA f hf hm
  classical
  by_cases hne : A.Nonempty
  · obtain ⟨R, oR, hR⟩ := upper_encoding.{u, u} A hA hne
    letI : PartialOrder R := oR
    obtain ⟨dR, ⟨bR⟩, ⟨tR⟩, _, j, _, _, hj, hcont⟩ := hR
    letI : IsDCPO R := dR
    letI : OrderBot R := bR
    letI : OrderTop R := tR
    let H := fun p : X × SixSource.{u} => (j ⟨f p.1, hm p.1⟩).val p.2
    have hH : @Continuous (X × SixSource.{u}) R (ordinarySixTopology X) (scott R) H :=
      hcont X f hf hm
    letI : TopologicalSpace A := scott A
    letI : TopologicalSpace (ScottHom SixSource.{u} R) := scott _
    apply hj.isInducing.continuous_iff.mpr
    convert hX R H hH using 1
  · letI : IsEmpty X := ⟨fun x => hne ⟨f x, hm x⟩⟩
    letI : TopologicalSpace A := scott A
    exact continuous_of_discreteTopology

/-- The source's implication (iii) ⇒ (i), with the empty space explicit. -/
theorem source_sdc_of_upperCorestrictions {X : Type u} [TopologicalSpace X] [T0Space X]
    (h : UpperCorestrictions X) : IsSDC X := by
  rcases isEmpty_or_nonempty X with hEmpty | _
  · letI : IsEmpty X := hEmpty
    exact empty_isSDC X
  · exact sdc_of_upperCorestrictions h

/-- The four equivalent space conditions, in their printed order. -/
theorem source_space_characterizations (X : Type u) [TopologicalSpace X] [T0Space X] :
    (IsSDC X ↔ AllCorestrictions X) ∧
    (AllCorestrictions X ↔ UpperCorestrictions X) ∧
    (UpperCorestrictions X ↔ FiniteSourceTest X) :=
  ⟨⟨allCorestrictions_of_sdc, fun h => source_sdc_of_upperCorestrictions (upperCorestrictions_of_all h)⟩,
    ⟨upperCorestrictions_of_all, fun h => allCorestrictions_of_sdc (source_sdc_of_upperCorestrictions h)⟩,
    ⟨fun h => source_finiteSourceTest_of_sdc (source_sdc_of_upperCorestrictions h),
      source_upperCorestrictions_of_finiteSourceTest⟩⟩

end ScottDCompletableMaximalityFirst
