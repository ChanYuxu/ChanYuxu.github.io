# Finite Separation on Subprobability Powerdomains

This archive contains the Lean 4 formalization accompanying the manuscript
*Finite separation on subprobability powerdomains*. It contains the complete
`FiniteSeparation` proof tree together with the reusable
`FiniteValuationApproximable` modules needed to build it as a standalone Lake
project.

The manuscript PDF and its TeX source are not included in this archive. The PDF
is distributed separately on the article page; no LaTeX source is published.

## Main theorem

The source-facing endpoint is `FiniteSeparation.thm_main`:

```lean
theorem thm_main (hD : IsFSDomain D) :
    IsFSDomain (VSub D) ∧ ∃ z : VSub D, IsLeast z
```

It states that the subprobability powerdomain of every FS-domain is a pointed
FS-domain. The source domain is not required to have a least element; the least
element of the target is the zero valuation.

## Build

The archive pins Lean to `v4.30.0-rc2` and Mathlib to commit
`5450b53e5ddc75d46418fabb605edbf36bd0beb6`.

```sh
lake update
lake build
```

The first command downloads the pinned dependencies. The second builds the
aggregate `FiniteSeparation` target.

## Scope and status

The formalization has 20 `FiniteSeparation` Lean files. It covers all 25
numbered source items and 14 operative unnumbered claim groups recorded by the
source-fidelity audit. Reusable order-theoretic and continuous-valuation
foundations are bundled under `FiniteValuationApproximable`; this is therefore
not a from-scratch redevelopment of those foundations.

The recorded status is `machine_accepted_human_pending`. The canonical audit
rebuilt all local modules, checked the critical source files with Lean's
trust-zero mode, found only `propext`, `Classical.choice`, and `Quot.sound` in
the transitive axiom audit, and completed an independent source-fidelity review.
Human expert review and publication approval remain pending. See
`FORMALIZATION_STATUS.md` for the precise boundary.
