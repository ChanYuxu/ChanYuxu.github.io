# Formalization status

- Recorded date: 2026-10-25 (Asia/Shanghai)
- Status: `machine_accepted_human_pending`
- Scope: the complete frozen manuscript, including operative unnumbered claims
- Numbered source items mapped: 25
- Operative unnumbered claim groups mapped: 14
- `FiniteSeparation` Lean files: 20
- Complete local build recorded: passed
- Trust-zero critical-source checks recorded: passed
- Fresh-project rebuild recorded: passed
- Source-fidelity review recorded: passed
- Human mathematical review: pending
- Human approval or publication acceptance: no

The source-facing main declaration is `FiniteSeparation.thm_main`. The
transitive axiom audit for the accepted proof tree reported only `propext`,
`Classical.choice`, and `Quot.sound`.

The formalization reuses proved modules from the finite-valuation approximable
development. Their source is included in this archive so that the download is
self-contained at the project level. Reuse does not transfer a separate
project's completion verdict, and the result should not be described as an
independent from-scratch formalization of all imported mathematics.

Machine acceptance and independent automated review do not establish novelty,
historical priority, journal acceptance, or human expert approval.
