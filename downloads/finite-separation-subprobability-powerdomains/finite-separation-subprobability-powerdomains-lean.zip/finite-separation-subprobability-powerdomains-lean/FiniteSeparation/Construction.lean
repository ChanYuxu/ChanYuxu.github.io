import FiniteSeparation.Grid
import FiniteSeparation.LocalMap
import FiniteSeparation.Height
import FiniteSeparation.Threshold
import FiniteSeparation.ValuationBasis
import FiniteSeparation.Approximation

set_option autoImplicit false

universe u

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open FiniteValuationApproximable (SubprobabilityVector upperMass)
open PointAssignment
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D]

structure SourceData (D : Type u) [PartialOrder D] where
  f : ScottContFun D D
  M : Finset D
  separates : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x

abbrev SourceData.poset (C : SourceData D) := SourcePoset C.f C.M

noncomputable def SourceData.witness (C : SourceData D) (x : D) : C.M :=
  ⟨Classical.choose (C.separates x), (Classical.choose_spec (C.separates x)).1⟩

theorem SourceData.witness_bounds (C : SourceData D) (x : D) :
    C.f x ≤ (C.witness x).1 ∧ (C.witness x).1 ≤ x :=
  (Classical.choose_spec (C.separates x)).2

theorem fibre_mass (p : Coeff D) {I : Type*} (c : D → I) (a : I) :
    mass p {x | c x = a} = integral p (fun x => if c x = a then 1 else 0) := by
  unfold mass
  apply congrArg (integral p)
  funext x
  by_cases hx : c x = a <;> simp [hx]

noncomputable def thetaVector (C : SourceData D) (p : SimpleCoeff D) : SubprobabilityVector C.M where
  coeff a := mass p.coeff {x | C.witness x = a}
  coeff_nonneg a := mass_nonneg p.nonneg _
  total_le_one := by
    simp_rw [fibre_mass]
    rw [← integral_sum_weight]
    convert p.total_le_one using 1
    unfold mass
    apply congrArg (integral p.coeff)
    funext x
    rw [Finset.sum_eq_single (C.witness x)]
    · simp
    · intro a ha hax
      simp [Ne.symm hax]
    · simp

theorem thetaVector_real (C : SourceData D) (p : SimpleCoeff D) (U : ScottOpen D) :
    (liftVector C.M (thetaVector C p) U).toReal =
      mass p.coeff {x | (C.witness x).1 ∈ U} := by
  rw [liftVector_real]
  unfold upperMass FiniteValuationApproximable.SubprobabilityVector.mass
  have hzero : integral p.coeff (fun _ => 0) = 0 := by simp [integral_eq_sum]
  calc
    _ = ∑ a : C.M, integral p.coeff
        (fun x => if a.1 ∈ U then if C.witness x = a then 1 else 0 else 0) := by
      apply Finset.sum_congr rfl
      intro a ha
      by_cases haU : a.1 ∈ U
      · have hat : a ∈ (traceUpper C.M U : Set C.M) := haU
        simp only [if_pos hat, if_pos haU]
        change mass p.coeff {x | C.witness x = a} = _
        rw [fibre_mass]
        apply congrArg (integral p.coeff)
        funext x
        by_cases hx : C.witness x = a <;> simp [hx]
      · have hat : a ∉ (traceUpper C.M U : Set C.M) := haU
        simp only [if_neg hat, if_neg haU, hzero]
    _ = integral p.coeff (fun x => ∑ a : C.M,
        if a.1 ∈ U then if C.witness x = a then 1 else 0 else 0) :=
      (integral_sum_weight _ _ _).symm
    _ = _ := by
      congr 1
      funext x
      rw [Finset.sum_eq_single (C.witness x)]
      · simp
      · intro a ha hax
        simp [Ne.symm hax]
      · simp

theorem thetaVector_below (C : SourceData D) (p : SimpleCoeff D) :
    liftVector C.M (thetaVector C p) ≤ p.toVSub := by
  intro U
  have hfin (v : VSub D) : v U ≠ ⊤ :=
    ne_of_lt ((v.value_le_one U).trans_lt ENNReal.one_lt_top)
  apply (ENNReal.toReal_le_toReal (hfin _) (hfin _)).mp
  rw [thetaVector_real, SimpleCoeff.toVSub_toReal]
  apply mass_mono_set p.nonneg
  intro x hx
  exact U.upper (C.witness_bounds x).2 hx

noncomputable def sourceRaw (C : SourceData D) (m : ℕ) (p : Coeff D) : Coeff D :=
  LocalMap.sourceH C.f.continuous.monotone C.separates chainHeight (m : ℝ) p

theorem sourceRaw_nonneg (C : SourceData D) {m : ℕ} (hm : 2 ≤ m)
    (p : SimpleCoeff D) : Nonneg (sourceRaw C m p.coeff) := by
  have hm0 : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
  exact LocalMap.rawH_nonneg _ _ _ _
    (fun u => (LocalMap.threshold_pos chainHeight hm0 u).le)
    (LocalMap.fixedScale_nonneg hm0) p.nonneg

theorem sourceRaw_total (C : SourceData D) {m : ℕ} (hm : 2 ≤ m)
    (p : SimpleCoeff D) : mass (sourceRaw C m p.coeff) Set.univ ≤ 1 := by
  have hmr : (2 : ℝ) ≤ m := by exact_mod_cast hm
  have hbound := (LocalMap.source_theta_margins C.f.continuous.monotone C.separates
    C.witness C.witness_bounds chainHeight chainHeight_strictMono (maxHeight C.poset)
    chainHeight_le_maxHeight hmr p ScottOpen.univ).1
  have hden : 0 < (m : ℝ) + (LocalMap.edgeCount (P := C.poset) : ℝ) + 1 := by positivity
  have hnn := mass_nonneg p.nonneg Set.univ
  have htot := p.total_le_one
  have hw : {x : D | (C.witness x).1 ∈ (ScottOpen.univ : ScottOpen D)} = Set.univ := by
    ext x
    simp
  rw [hw] at hbound
  change mass (sourceRaw C m p.coeff) Set.univ ≤ _ at hbound
  have heta : 0 < 1 / ((m : ℝ) + (LocalMap.edgeCount (P := C.poset) : ℝ) + 1) :=
    one_div_pos.mpr hden
  nlinarith

noncomputable def sourceSimple (C : SourceData D) (m : ℕ) (hm : 2 ≤ m)
    (p : SimpleCoeff D) : SimpleCoeff D :=
  ⟨sourceRaw C m p.coeff, sourceRaw_nonneg C hm p, sourceRaw_total C hm p⟩

theorem sourceSimple_mono (C : SourceData D) (m : ℕ) (hm : 2 ≤ m)
    (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub) :
    (sourceSimple C m hm p).toVSub ≤ (sourceSimple C m hm q).toVSub := by
  intro U
  apply ENNReal.ofReal_le_ofReal
  exact LocalMap.sourceH_mono C.f.continuous.monotone C.separates chainHeight
    (by exact_mod_cast hm) p q hpq U

theorem scaledAtomic_image_integral (p : SimpleCoeff D) (g : D → D) (rate : ℝ)
    (U : ScottOpen D) :
    integral p.coeff (fun x => if g x ∈ U then rate else 0) =
      rate * mass (LocalMap.atomicImage g p.coeff) U := by
  simp only [integral_eq_sum, LocalMap.atomicImage, mass_finset_sum,
    mass_single, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x hx
  change p.coeff x * (if g x ∈ U then rate else 0) =
    rate * (if g x ∈ U then p.coeff x else 0)
  by_cases hxU : g x ∈ U <;> simp [hxU, mul_comm]

theorem sourceSimple_lower (C : SourceData D) (m : ℕ) (hm : 2 ≤ m)
    (p : SimpleCoeff D) (rate : ℝ) (hr0 : 0 ≤ rate) (hr1 : rate ≤ 1)
    (hsmall : ∀ x ∈ p.coeff.support, (m : ℝ)⁻¹ < p.coeff x)
    (hrate : rate ≤ scaleFactor m (LocalMap.edgeCount (P := C.poset))) :
    (scaledAtomic p (fun x => C.f (C.f x)) rate hr0 hr1).toVSub ≤
      (sourceSimple C m hm p).toVSub := by
  intro U
  rw [scaledAtomic_apply, scaledAtomic_image_integral, SimpleCoeff.toVSub_apply]
  apply ENNReal.ofReal_le_ofReal
  exact LocalMap.sourceH_lower C.f.continuous.monotone C.separates chainHeight
    chainHeight_pos (by exact_mod_cast hm) p.nonneg hsmall hr0 hrate U

noncomputable def sourceGrid (C : SourceData D) (m : ℕ) : Set (VSub D) :=
  gridSet C.M
    (gridDenominator C.M.card m (LocalMap.edgeCount (P := C.poset)) (maxHeight C.poset))
    (gridDenominator_pos _ _ _ _)

theorem sourceGrid_finite (C : SourceData D) (m : ℕ) : (sourceGrid C m).Finite :=
  gridSet_finite _ _ _

theorem sourceSimple_separated (C : SourceData D) (m : ℕ) (hm : 2 ≤ m)
    (p : SimpleCoeff D) :
    ∃ γ ∈ sourceGrid C m, (sourceSimple C m hm p).toVSub ≤ γ ∧ γ ≤ p.toVSub := by
  have hm0 : 0 < m := by omega
  have hmr : (2 : ℝ) ≤ m := by exact_mod_cast hm
  have hmargin := LocalMap.source_theta_margins C.f.continuous.monotone C.separates
    C.witness C.witness_bounds chainHeight chainHeight_strictMono (maxHeight C.poset)
    chainHeight_le_maxHeight hmr p
  obtain ⟨γ, hγ, hlow, hupp⟩ := grid_separates C.M (thetaVector C p)
    (sourceSimple C m hm p).toVSub (separationEta m (LocalMap.edgeCount (P := C.poset)))
    (threshold m (maxHeight C.poset)) (separationEta_pos hm0 _) (by
      intro U
      rw [SimpleCoeff.toVSub_toReal, thetaVector_real]
      simpa only [separationEta, one_div] using (hmargin U).1) (by
      intro U hU
      rw [SimpleCoeff.toVSub_toReal] at hU
      rw [thetaVector_real]
      exact (hmargin U).2 hU) _ (gridDenominator_pos _ _ _ _)
        (gridDenominator_margin C.M.card hm0 _ _)
  exact ⟨γ, hγ, hlow, hupp.trans (thetaVector_below C p)⟩

noncomputable def basisRepresentative (α : simpleBasis D) : SimpleCoeff D :=
  Classical.choose α.2

theorem basisRepresentative_eq (α : simpleBasis D) : (basisRepresentative α).toVSub = α.1 :=
  Classical.choose_spec α.2

noncomputable def localBasisMap (C : SourceData D) (m : ℕ) (hm : 2 ≤ m)
    (α : simpleBasis D) : VSub D :=
  (sourceSimple C m hm (basisRepresentative α)).toVSub

theorem localBasisMap_mem_simpleBasis (C : SourceData D) (m : ℕ) (hm : 2 ≤ m)
    (α : simpleBasis D) : localBasisMap C m hm α ∈ simpleBasis D :=
  ⟨sourceSimple C m hm (basisRepresentative α), rfl⟩

theorem localBasisMap_monotone (C : SourceData D) (m : ℕ) (hm : 2 ≤ m) :
    Monotone (localBasisMap C m hm) := by
  intro α β hαβ
  apply sourceSimple_mono
  simpa only [basisRepresentative_eq] using hαβ

theorem localBasisMap_eq_sourceSimple (C : SourceData D) (m : ℕ) (hm : 2 ≤ m)
    (α : simpleBasis D) (p : SimpleCoeff D) (hp : p.toVSub = α.1) :
    localBasisMap C m hm α = (sourceSimple C m hm p).toVSub := by
  have hrep : (basisRepresentative α).toVSub = p.toVSub :=
    (basisRepresentative_eq α).trans hp.symm
  exact le_antisymm (sourceSimple_mono C m hm _ _ hrep.le)
    (sourceSimple_mono C m hm _ _ hrep.ge)

/-- `prop:simple-separation`, with the one fixed printed denominator grid. -/
theorem prop_simple_separation (C : SourceData D) (m : ℕ) (hm : 2 ≤ m) :
    Monotone (localBasisMap C m hm) ∧ (sourceGrid C m).Finite ∧
    ∀ α : simpleBasis D, ∃ γ ∈ sourceGrid C m,
      localBasisMap C m hm α ≤ γ ∧ γ ≤ α.1 := by
  refine ⟨localBasisMap_monotone C m hm, sourceGrid_finite C m, ?_⟩
  intro α
  obtain ⟨γ, hγ, hlow, hupp⟩ := sourceSimple_separated C m hm (basisRepresentative α)
  exact ⟨γ, hγ, hlow, by simpa only [basisRepresentative_eq] using hupp⟩

end FiniteSeparation
