import FiniteSeparation.Grid
import FiniteSeparation.LocalMap

set_option autoImplicit false

universe u

namespace FiniteSeparation

open Set
open FiniteValuationApproximable (SubprobabilityVector)
open FiniteValuationApproximable.Erosion
open scoped BigOperators Classical

variable {P : Type u} [PartialOrder P] [Fintype P]

/-- The source definition of M_N, with membership in the natural numbers
written as an explicit natural-number witness after coercion to R. -/
def SourceGridCoordinates (N : ℕ) (p : SubprobabilityVector P) : Prop :=
  ∀ x : P, ∃ n : ℕ, (N : ℝ) * p x = n

theorem grid_codes_iff (N : ℕ) (hN : 0 < N) (p : SubprobabilityVector P) :
    p ∈ Set.range (gridVector (P := P) N hN) ↔ SourceGridCoordinates N p := by
  have hN0 : (N : ℝ) ≠ 0 := ne_of_gt (Nat.cast_pos.mpr hN)
  constructor
  · rintro ⟨k, rfl⟩ x
    refine ⟨(k.1 x).1, ?_⟩
    change (N : ℝ) * ((k.1 x).1 / (N : ℝ)) = (k.1 x).1
    field_simp
  · intro h
    let n : P → ℕ := fun x => Classical.choose (h x)
    have hn (x : P) : (N : ℝ) * p x = n x := Classical.choose_spec (h x)
    have hnle (x : P) : n x ≤ N := by
      have hx1 : p x ≤ 1 := (Finset.single_le_sum
        (fun y _ => p.coeff_nonneg y) (Finset.mem_univ x)).trans p.total_le_one
      have hh : (n x : ℝ) ≤ N := by
        rw [← hn x]
        exact (mul_le_mul_of_nonneg_left hx1 (Nat.cast_nonneg N)).trans_eq (mul_one _)
      exact_mod_cast hh
    let code : P → Fin (N + 1) := fun x => ⟨n x, by have := hnle x; omega⟩
    have hsum : ∑ x, n x ≤ N := by
      have hh : (∑ x, (n x : ℝ)) ≤ N := by
        calc
          _ = ∑ x, (N : ℝ) * p x := Finset.sum_congr rfl (fun x _ => (hn x).symm)
          _ = (N : ℝ) * ∑ x, p x := (Finset.mul_sum _ _ _).symm
          _ ≤ (N : ℝ) * 1 :=
            mul_le_mul_of_nonneg_left p.total_le_one (Nat.cast_nonneg N)
          _ = (N : ℝ) := mul_one _
      exact_mod_cast hh
    let k : NatFloorGridCode (P := P) N := ⟨code, hsum⟩
    refine ⟨k, ?_⟩
    apply SubprobabilityVector.ext
    intro x
    change (n x : ℝ) / N = p x
    apply (div_eq_iff hN0).mpr
    exact (hn x).symm.trans (mul_comm _ _)

abbrev CoverPairs (P : Type u) [PartialOrder P] := {p : P × P // p.1 ⋖ p.2}

noncomputable instance coverPairsFintype : Fintype (CoverPairs P) := Fintype.ofFinite _

/-- The source's c_P is exactly the number of cover pairs; the sum of
out-degrees in LocalMap is only an alternative encoding of that cardinal. -/
theorem edgeCount_eq_card_coverPairs :
    LocalMap.edgeCount (P := P) = Fintype.card (CoverPairs P) := by
  let e : (Σ u : P, covers u) ≃ CoverPairs P :=
    { toFun := fun z => ⟨(z.1, z.2.1), (Finset.mem_filter.mp z.2.2).2⟩
      invFun := fun z => ⟨z.1.1, ⟨z.1.2,
        Finset.mem_filter.mpr ⟨Finset.mem_univ _, z.2⟩⟩⟩
      left_inv := by rintro ⟨u, v, hv⟩; rfl
      right_inv := by intro z; rfl }
  calc
    _ = ∑ u : P, Fintype.card (covers u) := by simp [LocalMap.edgeCount]
    _ = Fintype.card (Σ u : P, covers u) := (Fintype.card_sigma).symm
    _ = _ := Fintype.card_congr e

end FiniteSeparation
