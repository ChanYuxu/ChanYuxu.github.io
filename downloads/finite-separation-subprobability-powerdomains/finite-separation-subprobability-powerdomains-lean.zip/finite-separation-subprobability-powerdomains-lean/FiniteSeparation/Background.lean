import FiniteSeparation.FiniteTest
import FiniteSeparation.ValuationBasis
import FiniteValuationApproximable.ContinuousValuation.Finite

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical ENNReal

variable {D : Type u} [PartialOrder D]

theorem valuation_zero_isLeast : IsLeast (0 : VSub D).val := by
  intro μ U
  exact bot_le

theorem simpleBasis_zero : (0 : VSub D) ∈ simpleBasis D := by
  let p : SimpleCoeff D := ⟨0, fun _ => by simp, by simp⟩
  refine ⟨p, ?_⟩
  apply VSub.ext
  intro U
  simp [p, SimpleCoeff.toVSub_apply]

theorem valuation_union_le (μ : Valuation D) (U V : ScottOpen D) :
    μ (ScottOpen.union U V) ≤ μ U + μ V := by
  calc
    _ ≤ μ (ScottOpen.union U V) + μ (ScottOpen.inter U V) := le_self_add
    _ = _ := (μ.modular U V).symm

theorem valuation_finite_subadd {I : Type v} (μ : Valuation D)
    (O : I → ScottOpen D) (S : Finset I) : μ (finiteUnion O S) ≤ ∑ i ∈ S, μ (O i) := by
  induction S using Finset.induction_on with
  | empty => simp [μ.strict]
  | @insert i S hi ih =>
    rw [finiteUnion_insert, Finset.sum_insert hi]
    exact (valuation_union_le μ _ _).trans (add_le_add le_rfl ih)

noncomputable def addValuation (μ ν : Valuation D) : Valuation D where
  toFun U := μ U + ν U
  continuous := by
    constructor
    · intro U V hUV
      exact add_le_add (μ.monotone hUV) (ν.monotone hUV)
    · intro A S hA hS
      have hμ := μ.continuous.maps_isSup hA hS
      have hν := ν.continuous.maps_isSup hA hS
      constructor
      · rintro _ ⟨U, hU, rfl⟩
        exact add_le_add (hμ.1 ⟨U, hU, rfl⟩) (hν.1 ⟨U, hU, rfl⟩)
      · intro y hy
        change μ S + ν S ≤ y
        have heq : μ S + ν S = ⨆ U : A, μ U.1 + ν U.1 := by
          rw [isSup_image_eq_iSup_subtype μ (μ S) hμ,
            isSup_image_eq_iSup_subtype ν (ν S) hν]
          apply ENNReal.iSup_add_iSup
          intro U V
          obtain ⟨W, hW, hUW, hVW⟩ := hA.2 U.2 V.2
          exact ⟨⟨W, hW⟩, add_le_add (μ.monotone hUW) (ν.monotone hVW)⟩
        rw [heq]
        exact iSup_le fun U => hy ⟨U.1, U.2, rfl⟩
  strict := by simp [μ.strict, ν.strict]
  modular U V := by
    calc
      (μ U + ν U) + (μ V + ν V) = (μ U + μ V) + (ν U + ν V) := by ac_rfl
      _ = (μ (ScottOpen.union U V) + μ (ScottOpen.inter U V)) +
          (ν (ScottOpen.union U V) + ν (ScottOpen.inter U V)) := by rw [μ.modular, ν.modular]
      _ = _ := by ac_rfl

@[simp] theorem addValuation_apply (μ ν : Valuation D) (U : ScottOpen D) :
    addValuation μ ν U = μ U + ν U := rfl

noncomputable def sumValuations (l : List (Valuation D)) : Valuation D :=
  l.foldr addValuation (0 : VSub D).val

@[simp] theorem sumValuations_apply (l : List (Valuation D)) (U : ScottOpen D) :
    sumValuations l U = (l.map (fun μ => μ U)).sum := by
  induction l with
  | nil => rfl
  | cons μ l ih => simpa [sumValuations] using congrArg (fun x => μ U + x) ih

noncomputable def scaleValuation (μ : Valuation D) (c : ℝ) : Valuation D where
  toFun U := ENNReal.ofReal c * μ U
  continuous := by
    constructor
    · intro U V hUV
      exact mul_le_mul_left' (μ.monotone hUV) _
    · intro A S hA hS
      have hμ := μ.continuous.maps_isSup hA hS
      constructor
      · rintro _ ⟨U, hU, rfl⟩
        exact mul_le_mul_left' (hμ.1 ⟨U, hU, rfl⟩) _
      · intro y hy
        have heq : μ S = ⨆ U : A, μ U.1 := isSup_image_eq_iSup_subtype μ (μ S) hμ
        change ENNReal.ofReal c * μ S ≤ y
        rw [heq, ENNReal.mul_iSup]
        exact iSup_le fun U => hy ⟨U.1, U.2, rfl⟩
  strict := by simp [μ.strict]
  modular U V := by
    rw [← mul_add, μ.modular U V, mul_add]

@[simp] theorem scaleValuation_apply (μ : Valuation D) (c : ℝ) (U : ScottOpen D) :
    scaleValuation μ c U = ENNReal.ofReal c * μ U := rfl

theorem scaleValuation_cancel (μ : Valuation D) (C : ℝ) (hC : 0 < C) :
    scaleValuation (scaleValuation μ C⁻¹) C = μ := by
  apply FiniteValuationApproximable.ContinuousValuation.Valuation.ext
  intro U
  simp only [scaleValuation_apply, ← mul_assoc]
  rw [← ENNReal.ofReal_mul hC.le]
  simp [ne_of_gt hC]

noncomputable def totalBound (μ : Valuation D) : ℝ := max 1 (μ ScottOpen.univ).toReal

theorem totalBound_pos (μ : Valuation D) : 0 < totalBound μ :=
  zero_lt_one.trans_le (le_max_left _ _)

noncomputable def normalizeValuation (μ : Valuation D) (hμ : μ ScottOpen.univ ≠ ⊤) : VSub D :=
  ⟨scaleValuation μ (totalBound μ)⁻¹, by
    change ENNReal.ofReal (totalBound μ)⁻¹ * μ ScottOpen.univ ≤ 1
    rw [← ENNReal.ofReal_toReal hμ, ← ENNReal.ofReal_mul (inv_nonneg.mpr (totalBound_pos μ).le)]
    have hh : (totalBound μ)⁻¹ * (μ ScottOpen.univ).toReal ≤ 1 := by
      rw [mul_comm, ← div_eq_mul_inv]
      exact (div_le_one (totalBound_pos μ)).mpr (le_max_right _ _)
    exact (ENNReal.ofReal_le_ofReal hh).trans_eq (by simp)⟩

theorem normalize_recovery (μ : Valuation D) (hμ : μ ScottOpen.univ ≠ ⊤) (U : ScottOpen D) :
    μ U = ENNReal.ofReal (totalBound μ) * normalizeValuation μ hμ U := by
  have h := congrArg (fun ν : Valuation D => ν U)
    (scaleValuation_cancel μ (totalBound μ) (totalBound_pos μ))
  exact h.symm

theorem finiteMass_nonneg {P : Type v} [Fintype P] (p : P → ℝ) (hp : ∀ x, 0 ≤ p x) (U : Set P) :
    0 ≤ finiteMass p U := by
  apply Finset.sum_nonneg
  intro x hx
  split_ifs
  · exact hp x
  · exact le_rfl

/-- Generalized from the reused finite simplex coefficient identity: no
normalization or positivity is needed for this algebraic finite-sum fact. -/
theorem finiteMass_principal_sub {P : Type v} [Fintype P] [PartialOrder P]
    (p : P → ℝ) (x : P) :
    finiteMass p (principalScottOpen x : Set P) -
      finiteMass p (puncturedPrincipalScottOpen x : Set P) = p x := by
  unfold finiteMass
  rw [← Finset.sum_sub_distrib]
  calc
    _ = ∑ y : P, if y = x then p y else 0 := by
      apply Finset.sum_congr rfl
      intro y hy
      by_cases hyx : y = x
      · subst y
        have hmem : x ∈ principalScottOpen x := le_rfl
        have hnot : x ∉ puncturedPrincipalScottOpen x := fun h => h.2 rfl
        simp [hmem, hnot]
      · by_cases hxy : y ∈ principalScottOpen x
        · have hpunct : y ∈ puncturedPrincipalScottOpen x := ⟨hxy, hyx⟩
          simp [hyx, hxy, hpunct]
        · have hpunct : y ∉ puncturedPrincipalScottOpen x := fun h => hxy h.1
          simp [hyx, hxy, hpunct]
    _ = p x := by simp

/-- The unnumbered finite-poset representation statement in Section 2,
including arbitrary finite total mass, the printed coefficient formula,
and uniqueness. This is not restricted to subprobability valuations. -/
theorem finite_valuation_representation {P : Type v} [Fintype P] [PartialOrder P]
    (μ : Valuation P) (hμ : μ ScottOpen.univ ≠ ⊤) :
    ∃ p : P → ℝ, (∀ x, 0 ≤ p x) ∧
      (∀ U : ScottOpen P, μ U = ENNReal.ofReal (finiteMass p U)) ∧
      (∀ x, p x = (μ (principalScottOpen x)).toReal -
        (μ (puncturedPrincipalScottOpen x)).toReal) ∧
      (∀ q : P → ℝ, (∀ x, 0 ≤ q x) →
        (∀ U : ScottOpen P, μ U = ENNReal.ofReal (finiteMass q U)) → q = p) := by
  let ν := normalizeValuation μ hμ
  let r := valuationToVector ν
  let p : P → ℝ := fun x => totalBound μ * r x
  have hp (x : P) : 0 ≤ p x := mul_nonneg (totalBound_pos μ).le (r.coeff_nonneg x)
  have hrep (U : ScottOpen P) : μ U = ENNReal.ofReal (finiteMass p U) := by
    rw [normalize_recovery μ hμ U]
    change ENNReal.ofReal (totalBound μ) * ν U = _
    have hr : vectorToVSub r = ν := vectorToVSub_valuationToVector ν
    rw [← hr, vectorToVSub_apply, ← ENNReal.ofReal_mul (totalBound_pos μ).le]
    congr 1
    unfold FiniteValuationApproximable.SubprobabilityVector.mass finiteMass
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x hx
    by_cases hxU : x ∈ (U : Set P) <;> simp [hxU, p]
  have hreal (q : P → ℝ) (hq : ∀ x, 0 ≤ q x)
      (hr : ∀ U : ScottOpen P, μ U = ENNReal.ofReal (finiteMass q U)) (U : ScottOpen P) :
      (μ U).toReal = finiteMass q U := by
    rw [hr U, ENNReal.toReal_ofReal (finiteMass_nonneg q hq U)]
  have hcoeff (q : P → ℝ) (hq : ∀ x, 0 ≤ q x)
      (hr : ∀ U : ScottOpen P, μ U = ENNReal.ofReal (finiteMass q U)) (x : P) :
      q x = (μ (principalScottOpen x)).toReal - (μ (puncturedPrincipalScottOpen x)).toReal := by
    rw [hreal q hq hr, hreal q hq hr]
    exact (finiteMass_principal_sub q x).symm
  refine ⟨p, hp, hrep, hcoeff p hp hrep, ?_⟩
  intro q hq hqrep
  funext x
  exact (hcoeff q hq hqrep x).trans (hcoeff p hp hrep x).symm

end FiniteSeparation
