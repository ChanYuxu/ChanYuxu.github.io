import FiniteSeparation.Basis
import FiniteValuationApproximable.ContinuousValuation.JonesAtomic
import FiniteValuationApproximable.FiniteValuation.Basic
import Mathlib.LinearAlgebra.Finsupp.LinearCombination

set_option autoImplicit false

universe u

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D]

/-- Finite atomic coefficients, before imposing a mass bound. Coefficients
are real so that all rounding estimates have their literal source types. -/
abbrev Coeff (D : Type u) := D →₀ ℝ

noncomputable def integral (p : Coeff D) (w : D → ℝ) : ℝ :=
  Finsupp.linearCombination ℝ w p

noncomputable def mass (p : Coeff D) (U : Set D) : ℝ :=
  integral p (fun x => if x ∈ U then 1 else 0)

def Nonneg (p : Coeff D) : Prop := ∀ x, 0 ≤ p x

@[simp] theorem integral_zero (w : D → ℝ) : integral (0 : Coeff D) w = 0 := by
  exact map_zero _

@[simp] theorem integral_add (p q : Coeff D) (w : D → ℝ) :
    integral (p + q) w = integral p w + integral q w := by
  exact map_add _ _ _

@[simp] theorem integral_smul (c : ℝ) (p : Coeff D) (w : D → ℝ) :
    integral (c • p) w = c * integral p w := by
  exact (Finsupp.linearCombination ℝ w).map_smul c p

@[simp] theorem integral_single (x : D) (c : ℝ) (w : D → ℝ) :
    integral (Finsupp.single x c) w = c * w x := by
  exact Finsupp.linearCombination_single ℝ c x

theorem integral_eq_sum (p : Coeff D) (w : D → ℝ) :
    integral p w = ∑ x ∈ p.support, p x * w x := by
  rfl

theorem integral_on {S : Finset D} (p : Coeff D) (hp : p.support ⊆ S) (w : D → ℝ) :
    integral p w = ∑ x ∈ S, p x * w x := by
  rw [integral_eq_sum]
  exact Finset.sum_subset hp (by
    intro x hxS hxp
    simp [Finsupp.notMem_support_iff.mp hxp])

theorem integral_nonneg {p : Coeff D} (hp : Nonneg p) {w : D → ℝ}
    (hw : ∀ x, 0 ≤ w x) : 0 ≤ integral p w := by
  rw [integral_eq_sum]
  exact Finset.sum_nonneg fun x _ => mul_nonneg (hp x) (hw x)

theorem integral_mono_weight {p : Coeff D} (hp : Nonneg p) {w z : D → ℝ}
    (hwz : ∀ x, w x ≤ z x) : integral p w ≤ integral p z := by
  simp only [integral_eq_sum]
  exact Finset.sum_le_sum fun x _ => mul_le_mul_of_nonneg_left (hwz x) (hp x)

theorem integral_add_weight (p : Coeff D) (w z : D → ℝ) :
    integral p (fun x => w x + z x) = integral p w + integral p z := by
  simp [integral_eq_sum, mul_add, Finset.sum_add_distrib]

theorem integral_sum_weight {I : Type*} (S : Finset I) (p : Coeff D) (w : I → D → ℝ) :
    integral p (fun x => ∑ i ∈ S, w i x) = ∑ i ∈ S, integral p (w i) := by
  simp only [integral_eq_sum, Finset.mul_sum]
  exact Finset.sum_comm

theorem integral_finset_sum {I : Type*} (S : Finset I) (p : I → Coeff D) (w : D → ℝ) :
    integral (∑ i ∈ S, p i) w = ∑ i ∈ S, integral (p i) w :=
  map_sum (Finsupp.linearCombination ℝ w) p S

theorem mass_eq_sum (p : Coeff D) (U : Set D) :
    mass p U = ∑ x ∈ p.support, if x ∈ U then p x else 0 := by
  classical
  simp [mass, integral_eq_sum, mul_ite]

theorem mass_on {S : Finset D} (p : Coeff D) (hp : p.support ⊆ S) (U : Set D) :
    mass p U = ∑ x ∈ S, if x ∈ U then p x else 0 := by
  classical
  simp [mass, integral_on p hp, mul_ite]

theorem mass_nonneg {p : Coeff D} (hp : Nonneg p) (U : Set D) : 0 ≤ mass p U :=
  integral_nonneg hp (by intro x; split_ifs <;> norm_num)

@[simp] theorem mass_add (p q : Coeff D) (U : Set D) :
    mass (p + q) U = mass p U + mass q U := integral_add _ _ _

@[simp] theorem mass_smul (c : ℝ) (p : Coeff D) (U : Set D) :
    mass (c • p) U = c * mass p U := integral_smul _ _ _

@[simp] theorem mass_single (x : D) (c : ℝ) (U : Set D) :
    mass (Finsupp.single x c) U = if x ∈ U then c else 0 := by
  classical
  simp [mass, integral_single, mul_ite]

theorem mass_mono_set {p : Coeff D} (hp : Nonneg p) {U V : Set D} (hUV : U ⊆ V) :
    mass p U ≤ mass p V := by
  apply integral_mono_weight hp
  intro x
  by_cases hx : x ∈ U
  · simp [hx, hUV hx]
  · by_cases hxV : x ∈ V <;> norm_num [hx, hxV]

@[simp] theorem mass_zero (U : Set D) : mass (0 : Coeff D) U = 0 := integral_zero _

@[simp] theorem mass_empty (p : Coeff D) : mass p ∅ = 0 := by
  simp [mass, integral_eq_sum]

theorem mass_finset_sum {I : Type*} (S : Finset I) (p : I → Coeff D) (U : Set D) :
    mass (∑ i ∈ S, p i) U = ∑ i ∈ S, mass (p i) U := integral_finset_sum _ _ _

theorem mass_union_le {p : Coeff D} (hp : Nonneg p) (U V : Set D) :
    mass p (U ∪ V) ≤ mass p U + mass p V := by
  unfold mass
  rw [← integral_add_weight]
  apply integral_mono_weight hp
  intro x
  by_cases hxU : x ∈ U <;> by_cases hxV : x ∈ V <;> norm_num [hxU, hxV]

theorem mass_biUnion_le {I : Type*} (S : Finset I) {p : Coeff D}
    (hp : Nonneg p) (V : I → Set D) :
    mass p (⋃ i ∈ S, V i) ≤ ∑ i ∈ S, mass p (V i) := by
  classical
  induction S using Finset.induction_on with
  | empty => simp
  | @insert i S hi ih =>
    simp only [Finset.set_biUnion_insert, Finset.sum_insert hi]
    exact (mass_union_le hp _ _).trans (add_le_add le_rfl ih)

noncomputable def atomicValuation (p : Coeff D) (hp : Nonneg p) : Valuation D :=
  { toFun := fun U => ENNReal.ofReal (mass p U)
    continuous := by
      convert finiteAtomicValue_scottContinuous
        (fun x : p.support => x.1) (fun x => p x.1) (fun x => hp x.1) using 1
      funext U
      congr 1
      simp only [finiteAtomicRealMass, mass_eq_sum]
      exact (Finset.sum_coe_sort p.support (fun x => if x ∈ U then p x else 0)).symm
    strict := by simp [mass, integral_eq_sum]
    modular := by
      intro U V
      rw [← ENNReal.ofReal_add (mass_nonneg hp _) (mass_nonneg hp _),
        ← ENNReal.ofReal_add (mass_nonneg hp _) (mass_nonneg hp _)]
      congr 1
      simp only [mass_eq_sum, ← Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intro x hx
      by_cases hxU : x ∈ U <;> by_cases hxV : x ∈ V <;> simp [hxU, hxV] }

structure SimpleCoeff (D : Type u) [PartialOrder D] where
  coeff : Coeff D
  nonneg : Nonneg coeff
  total_le_one : mass coeff Set.univ ≤ 1

noncomputable def finiteCoeff {I : Type*} [Fintype I]
    (point : I → D) (weight : I → ℝ) : Coeff D :=
  ∑ i, Finsupp.single (point i) (weight i)

theorem finiteCoeff_nonneg {I : Type*} [Fintype I]
    (point : I → D) (weight : I → ℝ) (hw : ∀ i, 0 ≤ weight i) :
    Nonneg (finiteCoeff point weight) := by
  have h : (0 : Coeff D) ≤ finiteCoeff point weight := by
    exact Finset.sum_nonneg fun i _ => Finsupp.single_nonneg.mpr (hw i)
  exact fun x => h x

theorem mass_finiteCoeff {I : Type*} [Fintype I]
    (point : I → D) (weight : I → ℝ) (U : Set D) :
    mass (finiteCoeff point weight) U = ∑ i, if point i ∈ U then weight i else 0 := by
  simp only [finiteCoeff, mass_finset_sum, mass_single]

noncomputable def SimpleCoeff.ofFinite {I : Type*} [Fintype I]
    (point : I → D) (weight : I → ℝ) (hw : ∀ i, 0 ≤ weight i)
    (htotal : (∑ i, weight i) ≤ 1) : SimpleCoeff D where
  coeff := finiteCoeff point weight
  nonneg := finiteCoeff_nonneg point weight hw
  total_le_one := by simpa only [mass_finiteCoeff, Set.mem_univ, if_true] using htotal

noncomputable def SimpleCoeff.toVSub (p : SimpleCoeff D) : VSub D :=
  ⟨atomicValuation p.coeff p.nonneg, by
    change ENNReal.ofReal (mass p.coeff Set.univ) ≤ 1
    exact (ENNReal.ofReal_le_ofReal p.total_le_one).trans_eq (by simp)⟩

@[simp] theorem SimpleCoeff.toVSub_apply (p : SimpleCoeff D) (U : ScottOpen D) :
    p.toVSub U = ENNReal.ofReal (mass p.coeff U) := rfl

@[simp] theorem SimpleCoeff.toVSub_toReal (p : SimpleCoeff D) (U : ScottOpen D) :
    (p.toVSub U).toReal = mass p.coeff U :=
  ENNReal.toReal_ofReal (mass_nonneg p.nonneg U)

theorem SimpleCoeff.ofFinite_toVSub {I : Type*} [Fintype I]
    (point : I → D) (weight : I → ℝ) (hw : ∀ i, 0 ≤ weight i)
    (htotal : (∑ i, weight i) ≤ 1) :
    (SimpleCoeff.ofFinite point weight hw htotal).toVSub =
      finiteAtomicVSub point weight hw htotal := by
  apply VSub.ext
  intro U
  simp only [SimpleCoeff.toVSub_apply, SimpleCoeff.ofFinite,
    mass_finiteCoeff, finiteAtomicVSub_apply, finiteAtomicRealMass]
  rfl

def simpleBasis (D : Type u) [PartialOrder D] : Set (VSub D) :=
  {ν | ∃ p : SimpleCoeff D, p.toVSub = ν}

/-- An induced finite upper set is the trace of a genuine Scott open in D.
No continuity or bottom hypothesis on D is needed. -/
noncomputable def traceOpen (S : Finset D) (V : Set D)
    (hV : ∀ x ∈ S, ∀ y ∈ S, x ≤ y → x ∈ V → y ∈ V) : ScottOpen D :=
  { carrier := {x | ∀ y ∈ S, y ∉ V → ¬ x ≤ y}
    isScottOpen := by
      constructor
      · intro x y hxy hx z hz hzV hyz
        exact hx z hz hzV (hxy.trans hyz)
      · intro A s hA hs hsm
        by_contra hn
        have hcover : ∀ a ∈ A, ∃ y ∈ (S : Set D) \ V, a ≤ y := by
          intro a ha
          by_contra hbad
          apply hn
          refine ⟨a, ha, ?_⟩
          intro y hy hyV hay
          exact hbad ⟨y, ⟨hy, hyV⟩, hay⟩
        obtain ⟨y, hy, hsy⟩ := finite_cover_sup hA hs
          S.finite_toSet.diff hcover
        exact hsm y hy.1 hy.2 hsy }

theorem mem_traceOpen_iff (S : Finset D) (V : Set D)
    (hV : ∀ x ∈ S, ∀ y ∈ S, x ≤ y → x ∈ V → y ∈ V) (x : D) (hx : x ∈ S) :
    x ∈ traceOpen S V hV ↔ x ∈ V := by
  constructor
  · intro hm
    by_contra hn
    exact hm x hx hn le_rfl
  · intro hm y hy hyV hxy
    exact hyV (hV x hx y hy hxy hm)

noncomputable def SimpleCoeff.vectorOn (p : SimpleCoeff D) (S : Finset D)
    (hp : p.coeff.support ⊆ S) : FiniteValuationApproximable.SubprobabilityVector S where
  coeff x := p.coeff x.1
  coeff_nonneg x := p.nonneg x.1
  total_le_one := by
    have h := p.total_le_one
    rw [mass_on p.coeff hp] at h
    simpa only [Set.mem_univ, if_true, Finset.sum_coe_sort] using h

theorem vectorOn_integral (p : SimpleCoeff D) (S : Finset D)
    (hp : p.coeff.support ⊆ S) (w : D → ℝ) :
    FiniteValuationApproximable.weightedSum (p.vectorOn S hp) (fun x => w x.1) =
      integral p.coeff w := by
  rw [integral_on p.coeff hp]
  exact Finset.sum_coe_sort S (fun x => p.coeff x * w x)

theorem vectorOn_mass (p : SimpleCoeff D) (S : Finset D)
    (hp : p.coeff.support ⊆ S) (V : Set D) :
    (p.vectorOn S hp).mass {x | x.1 ∈ V} = mass p.coeff V := by
  classical
  rw [mass_on p.coeff hp]
  exact Finset.sum_coe_sort S (fun x => if x ∈ V then p.coeff x else 0)

theorem vectorOn_le_of_toVSub_le (p q : SimpleCoeff D) (S : Finset D)
    (hp : p.coeff.support ⊆ S) (hq : q.coeff.support ⊆ S)
    (hpq : p.toVSub ≤ q.toVSub) : p.vectorOn S hp ≤ q.vectorOn S hq := by
  classical
  intro U
  let V : Set D := {x | ∀ hx : x ∈ S, (⟨x, hx⟩ : S) ∈ U}
  have hV : ∀ x ∈ S, ∀ y ∈ S, x ≤ y → x ∈ V → y ∈ V := by
    intro x hx y hy hxy hxV hy'
    exact U.upper hxy (hxV hx)
  let O := traceOpen S V hV
  have hm (a : SimpleCoeff D) (ha : a.coeff.support ⊆ S) :
      FiniteValuationApproximable.upperMass (a.vectorOn S ha) U = mass a.coeff O := by
    rw [mass_on a.coeff ha]
    rw [← Finset.sum_coe_sort S]
    change (∑ x : S, if x ∈ U then a.coeff x.1 else 0) = _
    apply Finset.sum_congr rfl
    intro x _
    have hx : x.1 ∈ O ↔ x ∈ U := by
      rw [mem_traceOpen_iff S V hV x.1 x.2]
      change (∀ h : x.1 ∈ S, (⟨x.1, h⟩ : S) ∈ U) ↔ x ∈ U
      exact ⟨fun h => h x.2, fun h _ => h⟩
    change (if x ∈ U then a.coeff x.1 else 0) =
      (if x.1 ∈ O then a.coeff x.1 else 0)
    rw [hx]
  rw [hm p hp, hm q hq]
  have hh := hpq O
  exact (ENNReal.ofReal_le_ofReal_iff (mass_nonneg q.nonneg O)).mp hh

/-- Finite monotone tests are valid even if the test is not Scott continuous
on the ambient dcpo. Only its restriction to the common finite support is used. -/
theorem simple_integral_mono (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub)
    (w : D → ℝ) (hw : Monotone w) (hw0 : ∀ x, 0 ≤ w x) :
    integral p.coeff w ≤ integral q.coeff w := by
  let S := p.coeff.support ∪ q.coeff.support
  have hp : p.coeff.support ⊆ S := Finset.subset_union_left
  have hq : q.coeff.support ⊆ S := Finset.subset_union_right
  have h := (FiniteValuationApproximable.stochasticLE_iff_weightedSum_le.mp
    (vectorOn_le_of_toVSub_le p q S hp hq hpq))
    (fun x : S => w x.1) (fun _ _ hxy => hw hxy) (fun x => hw0 x.1)
  simpa only [vectorOn_integral] using h

end FiniteSeparation
