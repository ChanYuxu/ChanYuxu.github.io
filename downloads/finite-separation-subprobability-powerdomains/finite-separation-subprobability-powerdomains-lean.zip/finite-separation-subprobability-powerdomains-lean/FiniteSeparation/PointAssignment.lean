import FiniteValuationApproximable.OrderTheory
import FiniteValuationApproximable.ContinuousValuation.Basic

/-!
# Source points and cover-based point assignments

Source: `Finite_Separation_on_Subprobability_Powerdomains_FVA_aligned.tex`,
SHA256 `2d544eb99266f3a6c842718e51b8a8ecd304c47aa1da5dd2393193208ab329ff`.
This module covers the source-data lemma (lines 514-552) and the
point-assignment lemma (lines 582-647), not the whole paper.

The observation of xi on an upper set is real-valued and is proved equal
to the printed indicator formula. No valuation structure, least element,
countability, or monotonicity of the chosen source points is assumed.
-/

set_option autoImplicit false

universe u v

namespace FiniteSeparation.PointAssignment

open Set
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators

section SourceData

variable {D : Type u} [PartialOrder D]

/-- The source subset `{a in M | f x <= a}`. -/
noncomputable def sourceSlice (f : D → D) (M : Finset D) (x : D) : Finset D := by
  classical
  exact M.filter (fun a => f x ≤ a)

@[simp] theorem mem_sourceSlice {f : D → D} {M : Finset D} {x a : D} :
    a ∈ sourceSlice f M x ↔ a ∈ M ∧ f x ≤ a := by
  classical
  simp [sourceSlice]

/-- Exactly the range of the source subsets, ordered by reverse inclusion. -/
abbrev SourcePoset (f : D → D) (M : Finset D) :=
  OrderDual (Set.range (sourceSlice f M))

noncomputable def sourcePi (f : D → D) (M : Finset D) (x : D) : SourcePoset f M :=
  ⟨sourceSlice f M x, ⟨x, rfl⟩⟩

theorem source_le_iff {f : D → D} {M : Finset D} (s t : SourcePoset f M) :
    s ≤ t ↔ t.val ⊆ s.val := Iff.rfl

theorem sourceMembers_subset {f : D → D} {M : Finset D} (s : SourcePoset f M) :
    s.val ⊆ M := by
  obtain ⟨x, hx⟩ := s.property
  rw [← hx]
  intro a ha
  exact (mem_sourceSlice.mp ha).1

instance sourcePoset_finite (f : D → D) (M : Finset D) : Finite (SourcePoset f M) := by
  classical
  let e : SourcePoset f M → {s : Finset D // s ∈ M.powerset} :=
    fun s => ⟨s.val, Finset.mem_powerset.mpr (sourceMembers_subset s)⟩
  apply Finite.of_injective e
  intro s t h
  apply Subtype.ext
  exact congrArg (fun z : {s : Finset D // s ∈ M.powerset} => z.val) h

theorem sourcePi_surjective (f : D → D) (M : Finset D) :
    Function.Surjective (sourcePi f M) := by
  intro s
  obtain ⟨x, hx⟩ := s.property
  exact ⟨x, Subtype.ext hx⟩

theorem sourcePi_monotone {f : D → D} {M : Finset D} (hf : Monotone f) :
    Monotone (sourcePi f M) := by
  intro x y hxy
  change sourceSlice f M y ⊆ sourceSlice f M x
  intro a ha
  obtain ⟨haM, hya⟩ := mem_sourceSlice.mp ha
  exact mem_sourceSlice.mpr ⟨haM, (hf hxy).trans hya⟩

theorem sourceMembers_nonempty {f : D → D} {M : Finset D}
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) (s : SourcePoset f M) :
    s.val.Nonempty := by
  obtain ⟨x, hx⟩ := s.property
  obtain ⟨a, haM, hfa, _⟩ := hsep x
  exact ⟨a, hx ▸ mem_sourceSlice.mpr ⟨haM, hfa⟩⟩

/-- The source choice is in `f[s]` and below every member of `s`. -/
theorem sourceChoice_exists {f : D → D} {M : Finset D} (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) (s : SourcePoset f M) :
    ∃ a : D, a ∈ f '' (s.val : Set D) ∧ ∀ c ∈ s.val, a ≤ c := by
  obtain ⟨y, hy⟩ := s.property
  obtain ⟨b, hbM, hfyb, hby⟩ := hsep y
  have hbs : b ∈ s.val := hy ▸ mem_sourceSlice.mpr ⟨hbM, hfyb⟩
  refine ⟨f b, ⟨b, hbs, rfl⟩, ?_⟩
  intro c hcs
  have hcy : c ∈ sourceSlice f M y := hy.symm ▸ hcs
  exact (hf hby).trans (mem_sourceSlice.mp hcy).2

noncomputable def sourceChosen {f : D → D} {M : Finset D} (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) (s : SourcePoset f M) : D :=
  Classical.choose (sourceChoice_exists hf hsep s)

theorem sourceChosen_mem_image {f : D → D} {M : Finset D} (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) (s : SourcePoset f M) :
    sourceChosen hf hsep s ∈ f '' (s.val : Set D) :=
  (Classical.choose_spec (sourceChoice_exists hf hsep s)).1

theorem sourceChosen_le_member {f : D → D} {M : Finset D} (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) (s : SourcePoset f M)
    {c : D} (hc : c ∈ s.val) : sourceChosen hf hsep s ≤ c :=
  (Classical.choose_spec (sourceChoice_exists hf hsep s)).2 c hc

theorem sourceChosen_mem_fM {f : D → D} {M : Finset D} (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) (s : SourcePoset f M) :
    sourceChosen hf hsep s ∈ f '' (M : Set D) := by
  obtain ⟨b, hbs, hb⟩ := sourceChosen_mem_image hf hsep s
  exact ⟨b, sourceMembers_subset s hbs, hb⟩

/-- The first source bound, with the reverse-inclusion direction explicit. -/
theorem sourceSquare_le_chosen {f : D → D} {M : Finset D} (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) {x : D} {s : SourcePoset f M}
    (hxs : sourcePi f M x ≤ s) : f (f x) ≤ sourceChosen hf hsep s := by
  obtain ⟨b, hbs, hb⟩ := sourceChosen_mem_image hf hsep s
  have hbx : b ∈ sourceSlice f M x := hxs hbs
  have hfb : f x ≤ b := (mem_sourceSlice.mp hbx).2
  exact hb ▸ hf hfb

/-- Both printed source bounds; there is no monotonicity assumption on `a_s`. -/
theorem source_bounds {f : D → D} {M : Finset D} (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x) :
    (∀ (x : D) (s : SourcePoset f M), sourcePi f M x ≤ s →
      f (f x) ≤ sourceChosen hf hsep s) ∧
    (∀ (s : SourcePoset f M) (a : D), a ∈ s.val → sourceChosen hf hsep s ≤ a) := by
  exact ⟨fun _ _ h => sourceSquare_le_chosen hf hsep h,
    fun _ _ h => sourceChosen_le_member hf hsep _ h⟩

end SourceData

section FirstExit

variable {P : Type v} [PartialOrder P]

/-- The union of principal upper sets at covers of `u` outside `A`. -/
def exitUpper (A : Set P) (u : P) : Set P :=
  {v | ∃ z : P, u ⋖ z ∧ z ∉ A ∧ z ≤ v}

theorem exitUpper_upper (A : Set P) (u : P) : IsUpperSet (exitUpper A u) := by
  intro x y hxy hx
  obtain ⟨z, huz, hzA, hzx⟩ := hx
  exact ⟨z, huz, hzA, hzx.trans hxy⟩

theorem not_mem_exitUpper_of_le {A : Set P} {u w : P} (huw : u ≤ w) :
    u ∉ exitUpper A w := by
  rintro ⟨z, hwz, _, hzu⟩
  exact hwz.lt.not_ge (hzu.trans huw)

/-- A finite-poset first exit: no upper/lower closure of `A` is assumed. -/
theorem exists_first_exit [Finite P] {A : Set P} {u v : P}
    (huv : u ≤ v) (huA : u ∈ A) (hvA : v ∉ A) :
    ∃ w z : P, u ≤ w ∧ w ⋖ z ∧ z ≤ v ∧ w ∈ A ∧ z ∉ A := by
  obtain ⟨w, hw⟩ := (Set.toFinite {w : P | u ≤ w ∧ w ≤ v ∧ w ∈ A}).exists_maximal
    ⟨u, le_rfl, huv, huA⟩
  have hwv : w < v := lt_of_le_of_ne hw.1.2.1 (by
    intro h
    exact hvA (h ▸ hw.1.2.2))
  obtain ⟨z, hz⟩ := (Set.toFinite {z : P | w < z ∧ z ≤ v}).exists_minimal
    ⟨v, hwv, le_rfl⟩
  have hwz : w ⋖ z := by
    refine ⟨hz.1.1, ?_⟩
    intro c hwc hcz
    exact hcz.not_ge (hz.2 ⟨hwc, hcz.le.trans hz.1.2⟩ hcz.le)
  have hzA : z ∉ A := by
    intro hzA
    exact hwz.lt.not_ge (hw.2 ⟨hw.1.1.trans hwz.le, hz.1.2, hzA⟩ hwz.le)
  exact ⟨w, z, hw.1.1, hwz, hz.1.2, hw.1.2.2, hzA⟩

end FirstExit

section Observation

variable {D : Type u} [Preorder D] {P : Type v} [PartialOrder P] [Fintype P]

/-- A real 0/1 indicator of a proposition. -/
noncomputable def flag (p : Prop) : ℝ := by
  classical
  exact if p then 1 else 0

theorem flag_nonneg (p : Prop) : 0 ≤ flag p := by
  classical
  by_cases hp : p <;> simp [flag, hp]

theorem flag_mono {p q : Prop} (h : p → q) : flag p ≤ flag q := by
  classical
  by_cases hp : p
  · simp [flag, hp, h hp]
  · simpa [flag, hp] using flag_nonneg q

theorem flag_and (p q : Prop) : flag (p ∧ q) = flag p * flag q := by
  classical
  by_cases hp : p <;> by_cases hq : q <;> simp [flag, hp, hq]

noncomputable def correction (pi : D → P) (a : P → D) (A : Set P)
    (U : Set D) (x : D) (u : P) : ℝ :=
  flag (u ∈ A ∧ pi x ∈ exitUpper A u ∧ a u ∈ U)

/-- The real observation of xi_A(x) on U, with all multiplicities retained. -/
noncomputable def xiObservation (pi : D → P) (g : D → D) (a : P → D)
    (A : Set P) (U : Set D) (x : D) : ℝ :=
  flag (pi x ∈ A ∧ g x ∈ U) + ∑ u : P, correction pi a A U x u

omit [Preorder D] in
/-- Equality to the source's product-of-indicators formula. -/
theorem xiObservation_eq_printed (pi : D → P) (g : D → D) (a : P → D)
    (A : Set P) (U : Set D) (x : D) :
    xiObservation pi g a A U x =
      flag (pi x ∈ A) * flag (g x ∈ U) +
        ∑ u : P, flag (u ∈ A) * flag (pi x ∈ exitUpper A u) * flag (a u ∈ U) := by
  simp only [xiObservation, correction, flag_and, mul_assoc]

omit [Preorder D] in
theorem xiObservation_nonneg (pi : D → P) (g : D → D) (a : P → D)
    (A : Set P) (U : Set D) (x : D) : 0 ≤ xiObservation pi g a A U x :=
  add_nonneg (flag_nonneg _) (Finset.sum_nonneg (fun _ _ => flag_nonneg _))

omit [Fintype P] in
theorem correction_mono (pi : D → P) (a : P → D) (A : Set P) (U : Set D)
    (hpi : Monotone pi) {x y : D} (hxy : x ≤ y) (u : P) :
    correction pi a A U x u ≤ correction pi a A U y u := by
  apply flag_mono
  rintro ⟨huA, hx, hau⟩
  exact ⟨huA, exitUpper_upper A u (hpi hxy) hx, hau⟩

/-- The first-exit cover replaces a disappearing head summand.
`a` itself is not required to be monotone. -/
theorem xiObservation_mono (pi : D → P) (g : D → D) (a : P → D)
    (A : Set P) (U : Set D) (hU : IsUpperSet U)
    (hpi : Monotone pi) (hg : Monotone g)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u)
    {x y : D} (hxy : x ≤ y) :
    xiObservation pi g a A U x ≤ xiObservation pi g a A U y := by
  classical
  have hcorr (u : P) := correction_mono pi a A U hpi hxy u
  by_cases hxA : pi x ∈ A
  · by_cases hyA : pi y ∈ A
    · apply add_le_add
      · exact flag_mono (fun h => ⟨hyA, hU (hg hxy) h.2⟩)
      · exact Finset.sum_le_sum (fun u _ => hcorr u)
    · obtain ⟨w, z, hxw, hwz, hzy, hwA, hzA⟩ :=
        exists_first_exit (hpi hxy) hxA hyA
      have hxwU : pi x ∉ exitUpper A w := not_mem_exitUpper_of_le hxw
      have hywU : pi y ∈ exitUpper A w := ⟨z, hwz, hzA, hzy⟩
      have hxzero : correction pi a A U x w = 0 := by
        simp [correction, flag, hxwU]
      have hyone : correction pi a A U y w = flag (a w ∈ U) := by
        simp [correction, hwA, hywU]
      have hhead : flag (pi x ∈ A ∧ g x ∈ U) ≤ flag (a w ∈ U) :=
        flag_mono (fun h => hU (hchosen x w hxw) h.2)
      have hrest :
          (∑ u ∈ Finset.univ.erase w, correction pi a A U x u) ≤
            ∑ u ∈ Finset.univ.erase w, correction pi a A U y u :=
        Finset.sum_le_sum (fun u _ => hcorr u)
      have hsx := Finset.sum_erase_add (Finset.univ : Finset P)
        (fun u => correction pi a A U x u) (Finset.mem_univ w)
      have hsy := Finset.sum_erase_add (Finset.univ : Finset P)
        (fun u => correction pi a A U y u) (Finset.mem_univ w)
      dsimp only at hsx hsy
      change flag (pi x ∈ A ∧ g x ∈ U) + _ ≤ flag (pi y ∈ A ∧ g y ∈ U) + _
      have hyzero : flag (pi y ∈ A ∧ g y ∈ U) = 0 := by simp [flag, hyA]
      rw [← hsx, ← hsy, hxzero, hyone, hyzero]
      linarith
  · apply add_le_add
    · simpa [flag, hxA] using flag_nonneg (pi y ∈ A ∧ g y ∈ U)
    · exact Finset.sum_le_sum (fun u _ => hcorr u)

theorem xiObservation_monotone (pi : D → P) (g : D → D) (a : P → D)
    (A : Set P) (U : Set D) (hU : IsUpperSet U)
    (hpi : Monotone pi) (hg : Monotone g)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u) :
    Monotone (xiObservation pi g a A U) :=
  fun _ _ hxy => xiObservation_mono pi g a A U hU hpi hg hchosen hxy

theorem xiObservation_scottOpen_monotone (pi : D → P) (g : D → D) (a : P → D)
    (A : Set P) (U : ScottOpen D) (hpi : Monotone pi) (hg : Monotone g)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u) :
    Monotone (xiObservation pi g a A (U : Set D)) :=
  xiObservation_monotone pi g a A U U.upper hpi hg hchosen

end Observation

section ConcreteObservation

variable {D : Type u} [PartialOrder D] {f : D → D} {M : Finset D}

/-- The concrete source assignment, observed on an actual Scott open. -/
noncomputable def sourceObservation (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (A : Set (SourcePoset f M)) (U : ScottOpen D) (x : D) : ℝ := by
  letI : Fintype (SourcePoset f M) := Fintype.ofFinite _
  exact xiObservation (sourcePi f M) (fun y => f (f y)) (sourceChosen hf hsep) A U x

theorem sourceObservation_monotone (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (A : Set (SourcePoset f M)) (U : ScottOpen D) :
    Monotone (sourceObservation hf hsep A U) := by
  letI : Fintype (SourcePoset f M) := Fintype.ofFinite _
  exact xiObservation_scottOpen_monotone (sourcePi f M) (fun y => f (f y))
    (sourceChosen hf hsep) A U (sourcePi_monotone hf) (hf.comp hf)
    (fun _ _ h => sourceSquare_le_chosen hf hsep h)

end ConcreteObservation

end FiniteSeparation.PointAssignment

/-
NON-KERNEL STRESS-TEST RECORD

Preserved from the preceding source-only adversarial review. These finite
computations are not Lean proofs and do not certify the infinite theorem.
The command and stdout are included here to respect the one-file write boundary.
No source files are read or written by this command.

Exact shell command:

python3 -c 'import itertools

def orders(n):
    pairs=list(itertools.combinations(range(n),2))
    for mask in range(1<<len(pairs)):
        le=[[i==j for j in range(n)] for i in range(n)]
        for k,(i,j) in enumerate(pairs):
            if mask>>k&1: le[i][j]=True
        if all(not(le[i][j] and le[j][k]) or le[i][k] for i in range(n) for j in range(n) for k in range(n)):
            yield le
counts={"posets":0,"monotone_deflations":0,"separator_pairs":0,"all_choice_assignments":0,"point_monotonicity_instances":0,"subset_instances":0,"h_order_instances":0,"theta_and_grid_witnesses":0}
nonmonotone=None
for n in range(1,6):
  for le in orders(n):
    counts["posets"]+=1
    upper=[sum(1<<j for j in range(n) if le[i][j]) for i in range(n)]
    opens=[tuple(i for i in range(n) if S>>i&1) for S in range(1<<n) if all(not(S>>i&1) or upper[i]&S==upper[i] for i in range(n))]
    weights=[v for v in itertools.product(range(5),repeat=n) if sum(v)<=4] if n<=4 else []
    weight_values=[tuple(sum(v[i] for i in U) for U in opens) for v in weights]
    ordered=[(i,j) for i,a in enumerate(weight_values) for j,b in enumerate(weight_values) if all(x<=y for x,y in zip(a,b))]
    for f in itertools.product(*(tuple(j for j in range(n) if le[j][i]) for i in range(n))):
      if not all(not le[i][j] or le[f[i]][f[j]] for i in range(n) for j in range(n)): continue
      counts["monotone_deflations"]+=1
      for M in range(1,1<<n):
        source_choices=[tuple(a for a in range(n) if M>>a&1 and le[f[x]][a] and le[a][x]) for x in range(n)]
        if not all(source_choices): continue
        counts["separator_pairs"]+=1
        pi=[sum(1<<a for a in range(n) if M>>a&1 and le[f[x]][a]) for x in range(n)]
        P=sorted(set(pi)); d=len(P); pidx=[P.index(u) for u in pi]
        ple=[[P[j]&P[i]==P[j] for j in range(d)] for i in range(d)]
        covers=[[j for j in range(d) if i!=j and ple[i][j] and not any(k!=i and k!=j and ple[i][k] and ple[k][j] for k in range(d))] for i in range(d)]
        pu=[tuple(v for v in range(d) if ple[u][v]) for u in range(d)]
        heights=[0]*d
        for u in sorted(range(d),key=lambda k:-P[k].bit_count()):
          heights[u]=1+max((heights[v] for v in range(d) if v!=u and ple[v][u]),default=0)
        H=max(heights); cP=sum(map(len,covers))
        choices=[sorted(set(f[a] for a in range(n) if u>>a&1 and all(not(u>>b&1) or le[f[a]][b] for b in range(n)))) for u in P]
        assert all(choices)
        for chosen in itertools.product(*choices):
          counts["all_choice_assignments"]+=1
          assert all(not ple[pidx[x]][u] or le[f[f[x]]][chosen[u]] for x in range(n) for u in range(d))
          assert all(not(P[u]>>a&1) or le[chosen[u]][a] for u in range(d) for a in range(n))
          if nonmonotone is None and any(ple[u][v] and not le[chosen[u]][chosen[v]] for u in range(d) for v in range(d)):
            nonmonotone={"n":n,"strict_order":[(i,j) for i in range(n) for j in range(n) if i!=j and le[i][j]],"f":f,"M":[a for a in range(n) if M>>a&1],"P_as_bitsets":P,"chosen":chosen}
          xis=[]
          for A in range(1<<d):
            U=[sum(1<<z for z in range(d) if any(not(A>>v&1) and ple[v][z] for v in covers[u])) for u in range(d)]
            xi=[]
            for x in range(n):
              vec=[0]*n
              if A>>pidx[x]&1: vec[f[f[x]]]+=1
              for u in range(d):
                if A>>u&1 and U[u]>>pidx[x]&1: vec[chosen[u]]+=1
              xi.append(vec)
            xis.append(xi)
            values=[tuple(sum(vec[z] for z in U) for U in opens) for vec in xi]
            for x in range(n):
              for y in range(n):
                if le[x][y]:
                  counts["point_monotonicity_instances"]+=1
                  assert all(a<=b for a,b in zip(values[x],values[y])), ("point",n,le,f,M,P,chosen,A,x,y)
          if n>4: continue
          for m in (2,3):
            L=4*m**H
            thresholds=[4*m**(H-h) for h in heights]
            taus=[]
            for A in range(1<<d):
              tau=[0]*n
              for u in range(d):
                if A>>u&1: tau[chosen[u]]+=sum(thresholds[v] for v in covers[u] if A>>v&1)
              taus.append(tau)
            h_values=[]
            N=M.bit_count()*(m+cP+1)*m**H+1
            for wi,weight in enumerate(weights):
              coeff=[v*m**H for v in weight]
              p=[sum(coeff[x] for x in range(n) if pidx[x]==u) for u in range(d)]
              masses=[sum(p[v] for v in pu[u]) for u in range(d)]
              selected=sum(1<<u for u in range(d) if masses[u]>thresholds[u])
              Ts=[tuple(sum(coeff[x]*xis[A][x][z] for x in range(n))+taus[A][z] for z in range(n)) for A in range(1<<d)]
              Tvalues=[tuple(sum(T[z] for z in U) for U in opens) for T in Ts]
              for A in range(1<<d):
                for B in range(1<<d):
                  if A&B==A and all(not((B&~A)>>u&1) or masses[u]<=thresholds[u] for u in range(d)):
                    counts["subset_instances"]+=1
                    assert all(a<=b for a,b in zip(Tvalues[A],Tvalues[B])), ("subset",n,f,M,chosen,m,weight,A,B)
              h_values.append(Tvalues[selected])
              active=[x for x in range(n) if weight[x]]
              for cx in itertools.product(*(source_choices[x] for x in active)):
                theta=[0]*n
                for x,a in zip(active,cx): theta[a]+=weight[x]
                gamma=[N*a//4 for a in theta]
                for ui,U in enumerate(opens):
                  th=sum(theta[z] for z in U); ga=sum(gamma[z] for z in U); out=Tvalues[selected][ui]
                  assert m*out<=(m+cP)*th*m**H, ("theta",n,f,M,chosen,m,weight,cx,U)
                  if out: assert th*m**H>4, ("threshold",n,f,M,chosen,m,weight,cx,U)
                  assert m*out*N<=L*(m+cP+1)*ga, ("gridlower",n,f,M,chosen,m,weight,cx,U)
                  assert 4*ga<=N*weight_values[wi][ui], ("gridupper",n,f,M,chosen,m,weight,cx,U)
                counts["theta_and_grid_witnesses"]+=1
            for i,j in ordered:
              counts["h_order_instances"]+=1
              assert all(a<=b for a,b in zip(h_values[i],h_values[j])), ("horder",n,f,M,chosen,m,weights[i],weights[j])
print(counts)
print("first_nonmonotone_point_choice",nonmonotone)
print("All tests used exact integer arithmetic; coefficient grid denominator 4; m=2,3 for n<=4.")'

Exact stdout:

{'posets': 407, 'monotone_deflations': 2480, 'separator_pairs': 10344, 'all_choice_assignments': 12400, 'point_monotonicity_instances': 1092626, 'subset_instances': 840800, 'h_order_instances': 1247106, 'theta_and_grid_witnesses': 124760}
first_nonmonotone_point_choice {'n': 5, 'strict_order': [(0, 1), (0, 2), (0, 3), (0, 4), (1, 3), (1, 4), (2, 3)], 'f': (0, 0, 0, 2, 1), 'M': [0, 3, 4], 'P_as_bitsets': [8, 24, 25], 'chosen': (2, 1, 0)}
All tests used exact integer arithmetic; coefficient grid denominator 4; m=2,3 for n<=4.
-/
