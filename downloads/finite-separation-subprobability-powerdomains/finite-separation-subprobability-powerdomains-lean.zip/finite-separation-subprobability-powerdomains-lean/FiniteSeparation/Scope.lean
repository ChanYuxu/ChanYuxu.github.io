import FiniteSeparation.Main
import FiniteSeparation.GridBridge

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open PointAssignment
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D]

theorem lem_fs_facts :
    (∀ f : D → D, ScottContinuous f → FinitelySeparated f → ∀ x, f x ≪ x) ∧
    (IsFSDomain D → IsContinuousDomain D) := by
  refine ⟨fun f hf hs x => finitelySeparated_wayBelow hf hs x, ?_⟩
  rintro ⟨_, _, ⟨A⟩⟩
  exact fs_continuous A

theorem source_height_bounds [Nonempty D] (C : SourceData D) :
    1 ≤ maxHeight C.poset ∧ maxHeight C.poset ≤ min (Fintype.card C.poset) C.M.card := by
  letI : Nonempty C.poset := ⟨sourcePi C.f C.M (Classical.arbitrary D)⟩
  exact ⟨maxHeight_pos, le_min maxHeight_le_card (source_maxHeight_le_card C.separates)⟩

theorem grouping_mass_eq {P : Type v} (pi : D → P) (p : SimpleCoeff D) (A : Set P) :
    mass p.coeff (pi ⁻¹' A) = ∑ x ∈ p.coeff.support, if pi x ∈ A then p.coeff x else 0 := by
  rw [mass_eq_sum]
  apply Finset.sum_congr rfl
  intro x hx
  by_cases hA : pi x ∈ A <;> simp [hA]

theorem grouping_mono {P : Type v} [PartialOrder P] (pi : D → P) (hpi : Monotone pi)
    (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub) (A : UpperSet P) :
    mass p.coeff (pi ⁻¹' (A : Set P)) ≤ mass q.coeff (pi ⁻¹' (A : Set P)) := by
  apply LocalMap.simple_mass_mono_upper p q hpq
  intro x y hxy hx
  exact A.upper (hpi hxy) hx

noncomputable def xiCoeff (C : SourceData D) (A : Finset C.poset) (x : D) : Coeff D :=
  LocalMap.rawT (sourcePi C.f C.M) (fun y => C.f (C.f y))
    (sourceChosen C.f.continuous.monotone C.separates) (fun _ => 0) A
    (Finsupp.single x 1)

theorem xiCoeff_nonneg (C : SourceData D) (A : Finset C.poset) (x : D) :
    Nonneg (xiCoeff C A x) := by
  apply LocalMap.rawT_nonneg _ _ _ _ (fun _ => le_rfl) A
  have h : (0 : Coeff D) ≤ Finsupp.single x 1 := Finsupp.single_nonneg.mpr zero_le_one
  exact fun y => h y

theorem mass_xiCoeff (C : SourceData D) (A : Finset C.poset) (x : D) (U : ScottOpen D) :
    mass (xiCoeff C A x) U =
      sourceObservation C.f.continuous.monotone C.separates (A : Set C.poset) U x := by
  rw [xiCoeff, LocalMap.mass_rawT_eq_integral, integral_single, LocalMap.mass_tauCoeff]
  simp only [Finset.sum_const_zero, ite_self, add_zero, one_mul]
  rfl

noncomputable def xiValuation (C : SourceData D) (A : Finset C.poset) (x : D) : Valuation D :=
  atomicValuation (xiCoeff C A x) (xiCoeff_nonneg C A x)

/-- `lem:point-monotone`, as an inequality of actual continuous valuations,
not just observations of an unbundled formal expression. -/
theorem lem_point_monotone (C : SourceData D) (A : Finset C.poset) :
    Monotone (xiValuation C A) := by
  intro x y hxy U
  apply ENNReal.ofReal_le_ofReal
  rw [mass_xiCoeff, mass_xiCoeff]
  exact sourceObservation_monotone C.f.continuous.monotone C.separates A U hxy

theorem flag_le_one (p : Prop) : flag p ≤ 1 := by
  by_cases hp : p <;> simp [flag, hp]

theorem xiObservation_mass_bound {P : Type v} [PartialOrder P] [Fintype P]
    (pi : D → P) (g : D → D) (a : P → D) (A : Finset P) (U : Set D) (x : D) :
    xiObservation pi g a A U x ≤ 1 + (A.card : ℝ) := by
  have hsum : (∑ u : P, flag (u ∈ A)) = (A.card : ℝ) := by
    calc
      _ = ∑ u ∈ A, flag (u ∈ A) := (Finset.sum_subset (Finset.subset_univ A) (by
        intro u hu hnot
        simp [flag, hnot])).symm
      _ = ∑ _u ∈ A, (1 : ℝ) := Finset.sum_congr rfl (fun u hu => by simp [flag, hu])
      _ = _ := by simp
  calc
    _ ≤ 1 + ∑ u : P, flag (u ∈ A) := by
      apply add_le_add (flag_le_one _)
      apply Finset.sum_le_sum
      intro u hu
      exact flag_mono (fun h => h.1)
    _ = _ := by rw [hsum]

set_option maxHeartbeats 1000000 in
theorem xiValuation_mass_bound (C : SourceData D) (A : Finset C.poset) (x : D) :
    (xiValuation C A x ScottOpen.univ).toReal ≤ 1 + (A.card : ℝ) := by
  change (ENNReal.ofReal (mass (xiCoeff C A x) (Set.univ : Set D))).toReal ≤ _
  rw [ENNReal.toReal_ofReal (mass_nonneg (xiCoeff_nonneg C A x) Set.univ)]
  have hobs := mass_xiCoeff C A x (ScottOpen.univ (D := D))
  change mass (xiCoeff C A x) Set.univ = _ at hobs
  rw [hobs]
  simpa only [sourceObservation] using xiObservation_mass_bound
    (sourcePi C.f C.M) (fun y => C.f (C.f y))
    (sourceChosen C.f.continuous.monotone C.separates) A
    ((ScottOpen.univ (D := D)) : Set D) x

noncomputable def fixedAValuation (C : SourceData D) (t : C.poset → ℝ)
    (ht : ∀ u, 0 ≤ t u) (A : Finset C.poset) (p : SimpleCoeff D) : Valuation D :=
  atomicValuation
    (LocalMap.rawT (sourcePi C.f C.M) (fun x => C.f (C.f x))
      (sourceChosen C.f.continuous.monotone C.separates) t A p.coeff)
    (LocalMap.rawT_nonneg _ _ _ _ ht A p.nonneg)

/-- `lem:fixed-A`; the codomain permits total mass greater than one. -/
theorem lem_fixed_A (C : SourceData D) (t : C.poset → ℝ) (ht : ∀ u, 0 ≤ t u)
    (A : Finset C.poset) :
    Monotone (fun α : simpleBasis D => fixedAValuation C t ht A (basisRepresentative α)) := by
  intro α β hαβ U
  apply ENNReal.ofReal_le_ofReal
  apply LocalMap.rawT_fixedA_mono _ _ _ _ A
    (sourcePi_monotone C.f.continuous.monotone)
    (C.f.continuous.monotone.comp C.f.continuous.monotone)
    (fun _ _ h => sourceSquare_le_chosen C.f.continuous.monotone C.separates h)
  simpa only [basisRepresentative_eq] using hαβ

/-- `lem:subset-comparison`, retaining its exact threshold conditions. -/
theorem lem_subset_comparison (C : SourceData D) (t : C.poset → ℝ) (ht : ∀ u, 0 ≤ t u)
    (p : SimpleCoeff D) {A B : Finset C.poset} (hAB : A ⊆ B)
    (hnew : ∀ v, v ∈ B → v ∉ A → mass p.coeff (upperFiber (sourcePi C.f C.M) v) ≤ t v) :
    fixedAValuation C t ht A p ≤ fixedAValuation C t ht B p := by
  letI : DecidableEq C.poset := Classical.decEq _
  intro U
  apply ENNReal.ofReal_le_ofReal
  apply LocalMap.rawT_mono_subset _ _ _ _ ht p.nonneg hAB _ U
  intro v hv
  exact hnew v (Finset.mem_sdiff.mp hv).1 (Finset.mem_sdiff.mp hv).2

/-- The formula retained by `rem:extension-scope`: input atoms remain at
f^2(x); only the correction summands have fixed finite support. -/
theorem rem_extension_scope (C : SourceData D) (m : ℕ) (p : Coeff D) :
    sourceRaw C m p = LocalMap.fixedScale (P := C.poset) (m : ℝ) •
      (LocalMap.headCoeff (sourcePi C.f C.M) (fun x => C.f (C.f x))
        (selected (sourcePi C.f C.M) (LocalMap.threshold chainHeight (m : ℝ)) p) p +
        ∑ u ∈ selected (sourcePi C.f C.M) (LocalMap.threshold chainHeight (m : ℝ)) p,
          Finsupp.single (sourceChosen C.f.continuous.monotone C.separates u)
            (correctionCoeff (sourcePi C.f C.M) (LocalMap.threshold chainHeight (m : ℝ)) p
              (selected (sourcePi C.f C.M) (LocalMap.threshold chainHeight (m : ℝ)) p) u)) := rfl

def singletonIdentity {X : Type u} [PartialOrder X] [Subsingleton X] (z : X) : FSIdentity X := by
  let f : ScottContFun X X := ⟨fun x => x, scottContinuous_id⟩
  refine ⟨{f}, directed_singleton f, ?_, ?_⟩
  · intro g hg
    have hg' : g = f := Set.mem_singleton_iff.mp hg
    subst g
    refine ⟨{z}, Set.finite_singleton z, ?_⟩
    intro x
    exact ⟨z, Set.mem_singleton z, le_of_eq (Subsingleton.elim x z),
      le_of_eq (Subsingleton.elim z x)⟩
  · intro x
    simpa only [Set.image_singleton] using isSup_singleton x

/-- The empty-source case mentioned in `rem:scope` is proved independently
of the paper's standing nonempty-dcpo convention. -/
theorem rem_scope_empty [IsEmpty D] :
    IsFSDomain (VSub D) ∧ IsLeast (0 : VSub D) ∧ ∀ ν : VSub D, ν = 0 := by
  letI : Subsingleton (VSub D) := vSub_subsingleton_of_isEmpty
  exact ⟨⟨⟨0⟩, VSub.isDcpo, ⟨singletonIdentity 0⟩⟩, VSub.zero_le,
    fun ν => Subsingleton.elim ν 0⟩

theorem pointed_fs_closed (hD : IsFSDomain D) (_pointed : ∃ z : D, IsLeast z) :
    IsFSDomain (VSub D) ∧ ∃ z : VSub D, IsLeast z := thm_main hD

theorem SourceData.witness_eq_of_id (C : SourceData D) (hf : ∀ x, C.f x = x) (x : D) :
    (C.witness x).1 = x :=
  le_antisymm (C.witness_bounds x).2 (by simpa only [hf] using (C.witness_bounds x).1)

/-- In the finite identity case, the auxiliary witness is the original
input valuation, as stated before the full numerical example. -/
theorem thetaVector_of_id (C : SourceData D) (hf : ∀ x, C.f x = x) (p : SimpleCoeff D) :
    liftVector C.M (thetaVector C p) = p.toVSub := by
  apply VSub.ext
  intro U
  have hreal : (liftVector C.M (thetaVector C p) U).toReal = (p.toVSub U).toReal := by
    rw [thetaVector_real, SimpleCoeff.toVSub_toReal]
    congr 1
    ext x
    simp only [Set.mem_setOf_eq, C.witness_eq_of_id hf]
    rfl
  have hleft : liftVector C.M (thetaVector C p) U ≠ ⊤ :=
    ne_of_lt (((liftVector C.M (thetaVector C p)).value_le_one U).trans_lt ENNReal.one_lt_top)
  have hright : p.toVSub U ≠ ⊤ :=
    ne_of_lt ((p.toVSub.value_le_one U).trans_lt ENNReal.one_lt_top)
  exact le_antisymm ((ENNReal.toReal_le_toReal hleft hright).mp hreal.le)
    ((ENNReal.toReal_le_toReal hright hleft).mp hreal.ge)

end FiniteSeparation
