import FiniteSeparation.Atomic

set_option autoImplicit false

universe u

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D]

theorem squareEval_monotone (x : D) :
    Monotone (fun f : ScottContFun D D => f (f x)) := by
  intro f g hfg
  exact (f.continuous.monotone (hfg x)).trans (hfg (g x))

theorem source_squares_directed (A : FSIdentity D) (x : D) :
    DirectedSet ((fun f : ScottContFun D D => f (f x)) '' A.maps) :=
  DirectedSet.image (squareEval_monotone x) A.directed

/-- Equation `eq:source-square-sup`; the family is not assumed sequential. -/
theorem source_squares_isSup (A : FSIdentity D) (x : D) :
    IsSup ((fun f : ScottContFun D D => f (f x)) '' A.maps) x := by
  constructor
  · rintro _ ⟨f, hf, rfl⟩
    exact ((A.finitelySeparated f hf).below_id (f x)).trans
      ((A.finitelySeparated f hf).below_id x)
  · intro y hy
    apply (A.pointwise_sup x).2
    rintro _ ⟨f, hf, rfl⟩
    apply (f.continuous.maps_isSup (ScottContFun.eval_directed A.directed x)
      (A.pointwise_sup x)).2
    rintro _ ⟨_, ⟨g, hg, rfl⟩, rfl⟩
    obtain ⟨k, hk, hfk, hgk⟩ := A.directed.2 hf hg
    exact ((f.continuous.monotone (hgk x)).trans (hfk (k x))).trans
      (hy ⟨k, hk, rfl⟩)

theorem source_square_finite_open (A : FSIdentity D) (S : Finset D)
    (U : ScottOpen D) (hS : ∀ x ∈ S, x ∈ U) :
    ∃ f ∈ A.maps, ∀ x ∈ S, f (f x) ∈ U := by
  have hex : ∀ x : S, ∃ f ∈ A.maps, f (f x.1) ∈ U := by
    intro x
    obtain ⟨_, ⟨f, hf, rfl⟩, hfx⟩ := U.inaccessible
      (source_squares_directed A x.1) (source_squares_isSup A x.1) (hS x.1 x.2)
    exact ⟨f, hf, hfx⟩
  choose pick hpick hhit using hex
  obtain ⟨f, hf, hupper⟩ := A.directed.exists_upper_finite
    (Set.finite_range pick) (by rintro _ ⟨x, rfl⟩; exact hpick x)
  refine ⟨f, hf, ?_⟩
  intro x hx
  exact U.upper (squareEval_monotone x (hupper _ ⟨⟨x, hx⟩, rfl⟩)) (hhit ⟨x, hx⟩)

noncomputable def scaledAtomic (p : SimpleCoeff D) (g : D → D)
    (s : ℝ) (hs0 : 0 ≤ s) (hs1 : s ≤ 1) : SimpleCoeff D :=
  SimpleCoeff.ofFinite (fun x : p.coeff.support => g x.1)
    (fun x => s * p.coeff x.1) (fun x => mul_nonneg hs0 (p.nonneg x.1)) (by
      rw [← Finset.mul_sum, Finset.sum_coe_sort]
      have hsum : ∑ x ∈ p.coeff.support, p.coeff x = mass p.coeff Set.univ := by
        simp [mass_eq_sum]
      rw [hsum]
      exact (mul_le_mul_of_nonneg_right hs1 (mass_nonneg p.nonneg _)).trans
        (by simpa using p.total_le_one))

theorem scaledAtomic_apply (p : SimpleCoeff D) (g : D → D)
    (s : ℝ) (hs0 : 0 ≤ s) (hs1 : s ≤ 1) (U : ScottOpen D) :
    (scaledAtomic p g s hs0 hs1).toVSub U =
      ENNReal.ofReal (integral p.coeff (fun x => if g x ∈ U then s else 0)) := by
  rw [SimpleCoeff.toVSub_apply]
  congr 1
  simp only [scaledAtomic, SimpleCoeff.ofFinite, mass_finiteCoeff,
    integral_eq_sum]
  rw [Finset.sum_coe_sort p.coeff.support
    (fun x : D => if g x ∈ (U : Set D) then s * p.coeff x else 0)]
  apply Finset.sum_congr rfl
  intro x hx
  by_cases hg : g x ∈ U <;> simp [hg, mul_comm]

theorem scaledAtomic_mono (p : SimpleCoeff D) (g h : D → D)
    (s t : ℝ) (hs0 : 0 ≤ s) (hs1 : s ≤ 1) (ht0 : 0 ≤ t) (ht1 : t ≤ 1)
    (hgh : ∀ x, g x ≤ h x) (hst : s ≤ t) :
    (scaledAtomic p g s hs0 hs1).toVSub ≤ (scaledAtomic p h t ht0 ht1).toVSub := by
  intro U
  rw [scaledAtomic_apply, scaledAtomic_apply]
  apply ENNReal.ofReal_le_ofReal
  apply integral_mono_weight p.nonneg
  intro x
  by_cases hg : g x ∈ U
  · have hh : h x ∈ U := U.upper (hgh x) hg
    rw [if_pos hg, if_pos hh]
    exact hst
  · by_cases hh : h x ∈ U <;> simp [hg, hh, ht0]

theorem scaledAtomic_below (p : SimpleCoeff D) (g : D → D)
    (s : ℝ) (hs0 : 0 ≤ s) (hs1 : s ≤ 1) (hg : ∀ x, g x ≤ x) :
    (scaledAtomic p g s hs0 hs1).toVSub ≤ p.toVSub := by
  intro U
  rw [scaledAtomic_apply, SimpleCoeff.toVSub_apply]
  apply ENNReal.ofReal_le_ofReal
  apply integral_mono_weight p.nonneg
  intro x
  by_cases hgU : g x ∈ U
  · simp [hgU, U.upper (hg x) hgU, hs1]
  · by_cases hxU : x ∈ U <;> simp [hgU, hxU]

abbrev ApproxParam (A : FSIdentity D) :=
  {f : ScottContFun D D // f ∈ A.maps} × {s : ℝ // 0 < s ∧ s < 1}

theorem approxParam_directed (A : FSIdentity D) :
    DirectedSet (Set.univ : Set (ApproxParam A)) := by
  constructor
  · obtain ⟨f, hf⟩ := A.directed.1
    exact ⟨(⟨f, hf⟩, ⟨1 / 2, by norm_num⟩), Set.mem_univ _⟩
  · intro a _ b _
    obtain ⟨f, hf, haf, hbf⟩ := A.directed.2 a.1.2 b.1.2
    let s : {s : ℝ // 0 < s ∧ s < 1} :=
      ⟨max a.2.1 b.2.1, lt_of_lt_of_le a.2.2.1 (le_max_left _ _),
        max_lt a.2.2.2 b.2.2.2⟩
    exact ⟨(⟨f, hf⟩, s), Set.mem_univ _,
      ⟨haf, le_max_left _ _⟩, ⟨hbf, le_max_right _ _⟩⟩

noncomputable def beta (A : FSIdentity D) (p : SimpleCoeff D) (a : ApproxParam A) : VSub D :=
  (scaledAtomic p (fun x => a.1.1 (a.1.1 x)) a.2.1 a.2.2.1.le a.2.2.2.le).toVSub

theorem beta_monotone (A : FSIdentity D) (p : SimpleCoeff D) : Monotone (beta A p) := by
  intro a b hab
  apply scaledAtomic_mono p _ _ _ _ _ _ _ _ _ hab.2
  intro x
  exact squareEval_monotone x hab.1

theorem beta_directed (A : FSIdentity D) (p : SimpleCoeff D) :
    DirectedSet (Set.range (beta A p)) := by
  simpa only [Set.image_univ] using
    DirectedSet.image (beta_monotone A p) (approxParam_directed A)

theorem beta_below (A : FSIdentity D) (p : SimpleCoeff D) (a : ApproxParam A) :
    beta A p a ≤ p.toVSub := by
  apply scaledAtomic_below
  intro x
  exact ((A.finitelySeparated a.1.1 a.1.2).below_id (a.1.1 x)).trans
    ((A.finitelySeparated a.1.1 a.1.2).below_id x)

theorem beta_open_hit (A : FSIdentity D) (p : SimpleCoeff D) (U : ScottOpen D) :
    ∃ f : {f : ScottContFun D D // f ∈ A.maps}, ∀ s : {s : ℝ // 0 < s ∧ s < 1},
      beta A p (f, s) U = ENNReal.ofReal (s.1 * mass p.coeff U) := by
  obtain ⟨f, hf, hhit⟩ := source_square_finite_open A
    (p.coeff.support.filter (fun x => x ∈ U)) U (by
      intro x hx
      exact (Finset.mem_filter.mp hx).2)
  refine ⟨⟨f, hf⟩, ?_⟩
  intro s
  rw [beta, scaledAtomic_apply]
  congr 1
  rw [integral_eq_sum, mass_eq_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x hx
  have hbelow : f (f x) ≤ x :=
    ((A.finitelySeparated f hf).below_id (f x)).trans
      ((A.finitelySeparated f hf).below_id x)
  by_cases hxU : x ∈ U
  · have hfxU := hhit x (Finset.mem_filter.mpr ⟨hx, hxU⟩)
    simp [hxU, hfxU, mul_comm]
  · have hfxU : f (f x) ∉ U := fun h => hxU (U.upper hbelow h)
    simp [hxU, hfxU]

/-- Equation `eq:simple-directed-approx`, with a genuine directed family
inside the original continuous-valuation dcpo. -/
theorem beta_isSup (A : FSIdentity D) (p : SimpleCoeff D) :
    IsSup (Set.range (beta A p)) p.toVSub := by
  constructor
  · rintro _ ⟨a, rfl⟩
    exact beta_below A p a
  · intro ν hν U
    have hνfinite : ν U ≠ ⊤ := ne_of_lt ((ν.value_le_one U).trans_lt ENNReal.one_lt_top)
    have hpfinite : p.toVSub U ≠ ⊤ :=
      ne_of_lt ((p.toVSub.value_le_one U).trans_lt ENNReal.one_lt_top)
    apply (ENNReal.toReal_le_toReal hpfinite hνfinite).mp
    rw [SimpleCoeff.toVSub_toReal]
    by_contra hn
    have hlt : (ν U).toReal < mass p.coeff U := lt_of_not_ge hn
    have hpos : 0 < mass p.coeff U := ENNReal.toReal_nonneg.trans_lt hlt
    let r := (ν U).toReal / mass p.coeff U
    have hr0 : 0 ≤ r := div_nonneg ENNReal.toReal_nonneg hpos.le
    have hr1 : r < 1 := (div_lt_one hpos).mpr hlt
    let s : {s : ℝ // 0 < s ∧ s < 1} := ⟨(r + 1) / 2, by constructor <;> linarith⟩
    have hrs : r < s.1 := by dsimp [s]; linarith
    obtain ⟨f, hhit⟩ := beta_open_hit A p U
    have hle := hν (Set.mem_range_self (f, s)) U
    rw [hhit s] at hle
    have hreal := ENNReal.toReal_mono hνfinite hle
    rw [ENNReal.toReal_ofReal (mul_nonneg s.2.1.le (mass_nonneg p.nonneg U))] at hreal
    have hstrict : (ν U).toReal < s.1 * mass p.coeff U :=
      (div_lt_iff₀ hpos).mp hrs
    exact hstrict.not_ge hreal

theorem wayBelow_simple_beta (A : FSIdentity D) (p : SimpleCoeff D) {ν : VSub D}
    (hν : ν ≪ p.toVSub) : ∃ a : ApproxParam A, ν ≤ beta A p a := by
  obtain ⟨_, ⟨a, rfl⟩, hle⟩ := hν (beta_directed A p) (beta_isSup A p) le_rfl
  exact ⟨a, hle⟩

end FiniteSeparation
