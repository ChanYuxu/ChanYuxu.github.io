import FiniteSeparation.Height

set_option autoImplicit false

universe u

namespace FiniteSeparation

open scoped BigOperators

noncomputable def threshold (m ell : ℕ) : ℝ := ((m : ℝ) ^ ell)⁻¹
noncomputable def scaleFactor (m c : ℕ) : ℝ := (m : ℝ) / (m + c + 1)
noncomputable def separationEta (m c : ℕ) : ℝ := ((m : ℝ) + c + 1)⁻¹

theorem threshold_pos {m : ℕ} (hm : 0 < m) (ell : ℕ) : 0 < threshold m ell :=
  inv_pos.mpr (pow_pos (Nat.cast_pos.mpr hm) ell)

theorem threshold_antitone {m : ℕ} (hm : 1 ≤ m) : Antitone (threshold m) := by
  intro a b hab
  apply (inv_le_inv₀ (pow_pos (by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hm)) _)
    (pow_pos (by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hm)) _)).mpr
  exact pow_le_pow_right₀ (by exact_mod_cast hm) hab

theorem threshold_le_one_div {m ell : ℕ} (hm : 1 ≤ m) (hell : 0 < ell) :
    threshold m ell ≤ 1 / (m : ℝ) := by
  have h := threshold_antitone hm (show 1 ≤ ell by omega)
  simpa [threshold] using h

theorem threshold_cover_ratio {m a b : ℕ} (hm : 1 ≤ m) (hab : a < b) :
    threshold m b ≤ threshold m a / m := by
  have h := threshold_antitone hm (show a + 1 ≤ b by omega)
  simpa [threshold, pow_succ, div_eq_mul_inv, mul_comm] using h

theorem scale_den_pos {m : ℕ} (hm : 0 < m) (c : ℕ) :
    0 < (m : ℝ) + c + 1 := by positivity

theorem scaleFactor_pos {m : ℕ} (hm : 0 < m) (c : ℕ) : 0 < scaleFactor m c :=
  div_pos (Nat.cast_pos.mpr hm) (scale_den_pos hm c)

theorem scaleFactor_le_one {m : ℕ} (hm : 0 < m) (c : ℕ) : scaleFactor m c ≤ 1 := by
  apply (div_le_one (scale_den_pos hm c)).mpr
  have hc : 0 ≤ (c : ℝ) := Nat.cast_nonneg c
  linarith

theorem separationEta_pos {m : ℕ} (hm : 0 < m) (c : ℕ) : 0 < separationEta m c :=
  inv_pos.mpr (scale_den_pos hm c)

theorem scale_margin_identity {m : ℕ} (hm : 0 < m) (c : ℕ) :
    scaleFactor m c * (1 + (c : ℝ) / m) = 1 - separationEta m c := by
  have hm0 : (m : ℝ) ≠ 0 := ne_of_gt (Nat.cast_pos.mpr hm)
  have hd0 := ne_of_gt (scale_den_pos hm c)
  unfold scaleFactor separationEta
  field_simp
  <;> ring

def gridDenominator (n m c H : ℕ) : ℕ := n * (m + c + 1) * m ^ H + 1

theorem gridDenominator_pos (n m c H : ℕ) : 0 < gridDenominator n m c H := by
  unfold gridDenominator
  omega

theorem gridDenominator_margin (n : ℕ) {m : ℕ} (hm : 0 < m) (c H : ℕ) :
    (n : ℝ) / gridDenominator n m c H < separationEta m c * threshold m H := by
  have hN : 0 < (gridDenominator n m c H : ℝ) :=
    Nat.cast_pos.mpr (gridDenominator_pos _ _ _ _)
  have hd := scale_den_pos hm c
  have hp := pow_pos (Nat.cast_pos.mpr hm : (0 : ℝ) < (m : ℝ)) H
  have heq : separationEta m c * threshold m H =
      1 / (((m : ℝ) + c + 1) * (m : ℝ) ^ H) := by
    simp [separationEta, threshold, div_eq_mul_inv, mul_comm]
  rw [heq]
  apply (div_lt_div_iff₀ hN (mul_pos hd hp)).mpr
  simp only [gridDenominator, Nat.cast_add, Nat.cast_mul, Nat.cast_pow, Nat.cast_one]
  nlinarith

/-- One eventual integer bound for both retained positive atoms and the
scale factor in `lem:fixed-source`. -/
theorem sufficiently_large_parameters (rho c : ℝ) (hrho : 0 < rho)
    (hc0 : 0 < c) (hc1 : c < 1) (edges : ℕ) :
    ∃ m0 : ℕ, ∀ m : ℕ, m0 ≤ m →
      2 ≤ m ∧ 1 / (m : ℝ) < rho ∧ c < scaleFactor m edges := by
  obtain ⟨m0, hm0⟩ := exists_nat_gt
    (max 1 (max (1 / rho) (c * (edges + 1) / (1 - c))))
  refine ⟨m0, ?_⟩
  intro m hmm
  have hmreal : (m0 : ℝ) ≤ m := by exact_mod_cast hmm
  have hm1 : 1 < (m : ℝ) := (lt_of_le_of_lt (le_max_left _ _) hm0).trans_le hmreal
  have hmNat1 : 1 < m := by exact_mod_cast hm1
  have hm2 : 2 ≤ m := by omega
  have hmpos : 0 < (m : ℝ) := by linarith
  have hmNat : 0 < m := Nat.cast_pos.mp hmpos
  have hmRho : 1 / rho < (m : ℝ) :=
    ((le_max_left _ _).trans (le_max_right _ _)).trans_lt hm0 |>.trans_le hmreal
  have hmScale : c * (edges + 1) / (1 - c) < (m : ℝ) :=
    ((le_max_right _ _).trans (le_max_right _ _)).trans_lt hm0 |>.trans_le hmreal
  refine ⟨hm2, ?_, ?_⟩
  · apply (div_lt_iff₀ hmpos).mpr
    have hh := (div_lt_iff₀ hrho).mp hmRho
    nlinarith
  · apply (lt_div_iff₀ (scale_den_pos hmNat edges)).mpr
    have hh := (div_lt_iff₀ (sub_pos.mpr hc1)).mp hmScale
    nlinarith

end FiniteSeparation
