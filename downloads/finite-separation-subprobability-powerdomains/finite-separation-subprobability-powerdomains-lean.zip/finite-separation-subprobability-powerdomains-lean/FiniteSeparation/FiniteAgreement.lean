import FiniteSeparation.Main
import FiniteValuationApproximable.ContinuousValuation.Finite

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open PointAssignment
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D]

noncomputable def dilate (p : SimpleCoeff D) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) :
    SimpleCoeff D where
  coeff := c • p.coeff
  nonneg x := mul_nonneg hc0 (p.nonneg x)
  total_le_one := by
    rw [mass_smul]
    exact (mul_le_mul_of_nonneg_right hc1 (mass_nonneg p.nonneg _)).trans
      (by simpa using p.total_le_one)

theorem dilate_apply (p : SimpleCoeff D) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (U : ScottOpen D) :
    (dilate p c hc0 hc1).toVSub U = ENNReal.ofReal (c * mass p.coeff U) := by
  rw [SimpleCoeff.toVSub_apply]
  exact congrArg ENNReal.ofReal (mass_smul c p.coeff U)

theorem dilate_wayBelow [Finite D] (p : SimpleCoeff D) (c : ℝ)
    (hc0 : 0 < c) (hc1 : c < 1) : (dilate p c hc0.le hc1.le).toVSub ≪ p.toVSub := by
  letI : Fintype D := Fintype.ofFinite D
  letI : Fintype (ScottOpen D) := Fintype.ofFinite _
  intro A s hA hs hps
  have hex : ∀ U : ScottOpen D, ∃ ν ∈ A, (dilate p c hc0.le hc1.le).toVSub U ≤ ν U := by
    intro U
    by_cases hp0 : mass p.coeff U = 0
    · obtain ⟨ν, hν⟩ := hA.1
      refine ⟨ν, hν, ?_⟩
      rw [dilate_apply, hp0]
      simp
    · have hpos : 0 < mass p.coeff U :=
        lt_of_le_of_ne (mass_nonneg p.nonneg U) (Ne.symm hp0)
      have hstrict : (dilate p c hc0.le hc1.le).toVSub U < s U := by
        apply lt_of_lt_of_le _ (hps U)
        rw [dilate_apply, SimpleCoeff.toVSub_apply]
        apply (ENNReal.ofReal_lt_ofReal_iff hpos).mpr
        nlinarith
      by_contra hn
      have hub : IsUpperBound ((fun ν : VSub D => ν U) '' A)
          ((dilate p c hc0.le hc1.le).toVSub U) := by
        rintro _ ⟨ν, hν, rfl⟩
        by_contra hnot
        exact hn ⟨ν, hν, (lt_of_not_ge hnot).le⟩
      exact hstrict.not_ge ((VSub.eval_isSup hA hs U).2 _ hub)
  choose pick hpick hbound using hex
  obtain ⟨ν, hν, hupper⟩ := hA.exists_upper_finite (Set.finite_range pick)
    (by rintro _ ⟨U, rfl⟩; exact hpick U)
  refine ⟨ν, hν, ?_⟩
  intro U
  exact (hbound U).trans (hupper _ (Set.mem_range_self U) U)

theorem finite_simple [Finite D] (ν : VSub D) : ν ∈ simpleBasis D := by
  letI : Fintype D := Fintype.ofFinite D
  let p := valuationToVector ν
  refine ⟨SimpleCoeff.ofFinite (fun x : D => x) p p.coeff_nonneg p.total_le_one, ?_⟩
  rw [SimpleCoeff.ofFinite_toVSub]
  have heq : finiteAtomicVSub (fun x : D => x) p p.coeff_nonneg p.total_le_one =
      vectorToVSub p := by
    apply VSub.ext
    intro U
    rw [finiteAtomicVSub_apply, vectorToVSub_apply]
    congr 1
  exact heq.trans (vectorToVSub_valuationToVector ν)

theorem common_strict_factor {I : Type v} [Fintype I] (r : I → ℝ)
    (hr : ∀ i, r i < 1) : ∃ c : ℝ, 0 < c ∧ c < 1 ∧ ∀ i, r i < c := by
  let w : I ⊕ Unit → ℝ := Sum.elim (fun i => 1 - r i) (fun _ => 1)
  have hw (i : I ⊕ Unit) : 0 < w i := by
    cases i with
    | inl i => exact sub_pos.mpr (hr i)
    | inr i => exact zero_lt_one
  obtain ⟨rho, hrho, hbound⟩ := uniform_positive w hw
  have hρ1 : rho ≤ 1 := hbound (Sum.inr ())
  refine ⟨1 - rho / 2, by linarith, by linarith, ?_⟩
  intro i
  have hi : rho ≤ 1 - r i := hbound (Sum.inl i)
  linarith

theorem selected_smul_eq {P : Type v} [PartialOrder P] [Fintype P]
    (pi : D → P) (t : P → ℝ) {p : Coeff D} (hp : Nonneg p)
    (c : ℝ) (hc1 : c ≤ 1)
    (hkeep : ∀ u ∈ selected pi t p, t u < c * mass p (upperFiber pi u)) :
    selected pi t (c • p) = selected pi t p := by
  ext u
  simp only [mem_selected, mass_smul]
  constructor
  · intro h
    by_contra hn
    have hout : mass p (upperFiber pi u) ≤ t u := le_of_not_gt hn
    have hnn := mass_nonneg hp (upperFiber pi u)
    have hcm := mul_le_mul_of_nonneg_right hc1 hnn
    nlinarith
  · intro hu
    exact hkeep u ((mem_selected pi t p u).mpr hu)

theorem rawH_smul_lower {P : Type v} [PartialOrder P] [Fintype P]
    (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) (scale : ℝ) (hscale : 0 ≤ scale)
    (p : Coeff D) (c : ℝ) (hc1 : c ≤ 1)
    (hsel : selected pi t (c • p) = selected pi t p) (U : Set D) :
    c * mass (LocalMap.rawH pi g a t scale p) U ≤
      mass (LocalMap.rawH pi g a t scale (c • p)) U := by
  have htau : 0 ≤ mass (LocalMap.tauCoeff a t (selected pi t p)) U := by
    rw [LocalMap.mass_tauCoeff]
    exact Finset.sum_nonneg fun u hu => by
      split_ifs
      · exact Finset.sum_nonneg fun v hv => ht v
      · exact le_rfl
  simp only [LocalMap.rawH, mass_smul, LocalMap.rawSelectedT, hsel,
    LocalMap.mass_rawT_eq_integral, integral_smul]
  have hprod := mul_nonneg hscale (mul_nonneg (sub_nonneg.mpr hc1) htau)
  nlinarith

section Agreement

variable [Nonempty D] [Finite D]

theorem finite_agreement_coeff (hD : IsContinuousDomain D) (C : SourceData D)
    (m : ℕ) (hm : 2 ≤ m) (p : SimpleCoeff D) :
    valuationExtension hD C m hm p.toVSub = (sourceSimple C m hm p).toVSub := by
  let hB := lem_simple_basis hD
  apply le_antisymm
  · change basisExtension VSub.isDcpo hB.2 (localBasisMap C m hm)
      (localBasisMap_monotone C m hm) p.toVSub ≤ _
    apply (basisExtension_isSup VSub.isDcpo hB.2 _ _ p.toVSub).2
    rintro _ ⟨b, hb, rfl⟩
    apply sourceSimple_mono
    rw [basisRepresentative_eq]
    exact prop_2_2_2_1 hb
  · intro U
    let H := (sourceSimple C m hm p).toVSub
    let E := valuationExtension hD C m hm p.toVSub
    have hfinite (ν : VSub D) : ν U ≠ ⊤ :=
      ne_of_lt ((ν.value_le_one U).trans_lt ENNReal.one_lt_top)
    apply (ENNReal.toReal_le_toReal (hfinite H) (hfinite E)).mp
    rw [SimpleCoeff.toVSub_toReal]
    by_contra hn
    have hlt : (E U).toReal < mass (sourceRaw C m p.coeff) U := lt_of_not_ge hn
    have hpos : 0 < mass (sourceRaw C m p.coeff) U := ENNReal.toReal_nonneg.trans_lt hlt
    let pi := sourcePi C.f C.M
    let t := LocalMap.threshold (chainHeight (P := C.poset)) (m : ℝ)
    let A := selected pi t p.coeff
    let ratios : A ⊕ Unit → ℝ := Sum.elim
      (fun u => t u.1 / mass p.coeff (upperFiber pi u.1))
      (fun _ => (E U).toReal / mass (sourceRaw C m p.coeff) U)
    have hm0 : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
    have hr (i : A ⊕ Unit) : ratios i < 1 := by
      cases i with
      | inl u =>
        have hu := (mem_selected pi t p.coeff u.1).mp u.2
        have htpos : 0 < t u.1 := LocalMap.threshold_pos chainHeight hm0 u.1
        exact (div_lt_one (htpos.trans hu)).mpr hu
      | inr i => exact (div_lt_one hpos).mpr hlt
    obtain ⟨c, hc0, hc1, hratios⟩ := common_strict_factor ratios hr
    have hsel : selected pi t (c • p.coeff) = A := by
      apply selected_smul_eq pi t p.nonneg c hc1.le
      intro u hu
      have hup := (mem_selected pi t p.coeff u).mp hu
      have htpos : 0 < t u := LocalMap.threshold_pos chainHeight hm0 u
      exact (div_lt_iff₀ (htpos.trans hup)).mp (hratios (Sum.inl ⟨u, hu⟩))
    have hscaled := rawH_smul_lower pi (fun x => C.f (C.f x))
      (sourceChosen C.f.continuous.monotone C.separates) t
      (fun u => (LocalMap.threshold_pos chainHeight hm0 u).le)
      (LocalMap.fixedScale (P := C.poset) (m : ℝ)) (LocalMap.fixedScale_nonneg hm0)
      p.coeff c hc1.le hsel (U : Set D)
    change c * mass (sourceRaw C m p.coeff) U ≤
      mass (sourceRaw C m (c • p.coeff)) U at hscaled
    let pc := dilate p c hc0.le hc1.le
    let bc : simpleBasis D := ⟨pc.toVSub, pc, rfl⟩
    have hbc : pc.toVSub ≪ p.toVSub := dilate_wayBelow p c hc0 hc1
    have hle := le_basisExtension VSub.isDcpo hB.2 (localBasisMap C m hm)
      (localBasisMap_monotone C m hm) p.toVSub bc hbc
    change localBasisMap C m hm bc ≤ E at hle
    rw [localBasisMap_eq_sourceSimple C m hm bc pc rfl] at hle
    have hreal := ENNReal.toReal_mono (hfinite E) (hle U)
    rw [SimpleCoeff.toVSub_toReal] at hreal
    have hstrict : (E U).toReal < c * mass (sourceRaw C m p.coeff) U :=
      (div_lt_iff₀ hpos).mp (hratios (Sum.inr ()))
    exact hstrict.not_ge (hscaled.trans hreal)

noncomputable def finiteInput (ν : VSub D) : simpleBasis D := ⟨ν, finite_simple ν⟩

/-- `prop:finite-agreement`, for every valuation of the finite source D. -/
theorem prop_finite_agreement (hD : IsContinuousDomain D) (C : SourceData D)
    (m : ℕ) (hm : 2 ≤ m) (ν : VSub D) :
    valuationExtension hD C m hm ν = localBasisMap C m hm (finiteInput ν) := by
  let p := basisRepresentative (finiteInput ν)
  have hp : p.toVSub = ν := basisRepresentative_eq _
  have h := finite_agreement_coeff hD C m hm p
  rw [hp] at h
  exact h.trans (localBasisMap_eq_sourceSimple C m hm (finiteInput ν) p hp).symm

end Agreement

end FiniteSeparation
