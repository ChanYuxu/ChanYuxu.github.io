import FiniteSeparation.Atomic
import FiniteValuationApproximable.ContinuousValuation.JonesContinuity

set_option autoImplicit false

universe u

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators

variable {D : Type u} [PartialOrder D]

theorem certificate_simple (hD : IsContinuousDomain D) (ν : VSub D)
    (a : JonesCertificate hD ν) : a.toVSub hD ν ∈ simpleBasis D := by
  letI : Fintype a.index := a.fintypeIndex
  refine ⟨SimpleCoeff.ofFinite a.point a.weight a.weight_nonneg a.total_le_one, ?_⟩
  exact SimpleCoeff.ofFinite_toVSub a.point a.weight a.weight_nonneg a.total_le_one

/-- `lem:simple-basis`, for the actual continuous valuations on the source's
Scott opens, and the set of all finite atomic subprobability valuations. -/
theorem lem_simple_basis [Nonempty D] (hD : IsContinuousDomain D) :
    IsContinuousDomain (VSub D) ∧ IsBasis (simpleBasis D) := by
  constructor
  · exact JonesCertificate.vSub_isContinuousDomain hD
  · apply prop_2_2_4_1
    intro ν
    refine ⟨JonesCertificate.approximantSet hD ν, ?_,
      JonesCertificate.approximantSet_directed hD ν,
      JonesCertificate.approximantSet_isSup hD ν⟩
    intro μ hμ
    refine ⟨?_, JonesCertificate.approximantSet_wayBelow hD ν hμ⟩
    obtain ⟨a, rfl⟩ := hμ
    exact certificate_simple hD ν a

end FiniteSeparation
