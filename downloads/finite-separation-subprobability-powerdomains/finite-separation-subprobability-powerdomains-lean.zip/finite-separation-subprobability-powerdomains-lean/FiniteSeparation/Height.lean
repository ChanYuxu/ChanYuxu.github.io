import FiniteSeparation.PointAssignment

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set
open PointAssignment
open scoped BigOperators Classical

variable {P : Type v} [PartialOrder P] [Fintype P]

def ChainEnding (S : Finset P) (u : P) : Prop :=
  u ∈ S ∧ (∀ x ∈ S, x ≤ u) ∧ ∀ x ∈ S, ∀ y ∈ S, x ≤ y ∨ y ≤ x

noncomputable def chainFamily (u : P) : Finset (Finset P) :=
  Finset.univ.powerset.filter (fun S => ChainEnding S u)

@[simp] theorem mem_chainFamily (S : Finset P) (u : P) :
    S ∈ chainFamily u ↔ ChainEnding S u := by
  simp [chainFamily]

/-- The source's ell(u): largest number of elements in a chain ending at u,
not a convenient substitute rank. -/
noncomputable def chainHeight (u : P) : ℕ := (chainFamily u).sup Finset.card

theorem singleton_chain (u : P) : ChainEnding {u} u := by
  simp [ChainEnding]

theorem chainHeight_max {S : Finset P} {u : P} (hS : ChainEnding S u) :
    S.card ≤ chainHeight u := Finset.le_sup (f := Finset.card) (mem_chainFamily S u |>.mpr hS)

theorem chainHeight_attained (u : P) :
    ∃ S : Finset P, ChainEnding S u ∧ chainHeight u = S.card := by
  obtain ⟨S, hS, hcard⟩ := Finset.exists_mem_eq_sup (chainFamily u)
    ⟨{u}, (mem_chainFamily _ _).mpr (singleton_chain u)⟩ Finset.card
  exact ⟨S, (mem_chainFamily _ _).mp hS, hcard⟩

theorem chainHeight_pos (u : P) : 0 < chainHeight u := by
  have h := chainHeight_max (singleton_chain u)
  simp only [Finset.card_singleton] at h
  omega

theorem chainHeight_strictMono : StrictMono (chainHeight (P := P)) := by
  intro u v huv
  obtain ⟨S, hS, hcard⟩ := chainHeight_attained u
  have hvS : v ∉ S := fun hv => huv.not_ge (hS.2.1 v hv)
  have hnew : ChainEnding (insert v S) v := by
    refine ⟨by simp, ?_, ?_⟩
    · intro x hx
      rcases Finset.mem_insert.mp hx with rfl | hxS
      · exact le_rfl
      · exact (hS.2.1 x hxS).trans huv.le
    · intro x hx y hy
      rcases Finset.mem_insert.mp hx with rfl | hxS
      · rcases Finset.mem_insert.mp hy with rfl | hyS
        · exact Or.inl le_rfl
        · exact Or.inr ((hS.2.1 y hyS).trans huv.le)
      · rcases Finset.mem_insert.mp hy with rfl | hyS
        · exact Or.inl ((hS.2.1 x hxS).trans huv.le)
        · exact hS.2.2 x hxS y hyS
  have hbound := chainHeight_max hnew
  rw [Finset.card_insert_of_notMem hvS, ← hcard] at hbound
  omega

theorem chainHeight_le_card (u : P) : chainHeight u ≤ Fintype.card P := by
  obtain ⟨S, _, hcard⟩ := chainHeight_attained u
  rw [hcard]
  exact (Finset.card_le_card (Finset.subset_univ S)).trans_eq (Finset.card_univ)

noncomputable def maxHeight (P : Type v) [PartialOrder P] [Fintype P] : ℕ :=
  Finset.univ.sup (chainHeight (P := P))

theorem chainHeight_le_maxHeight (u : P) : chainHeight u ≤ maxHeight P :=
  Finset.le_sup (f := chainHeight) (Finset.mem_univ u)

theorem maxHeight_pos [Nonempty P] : 0 < maxHeight P :=
  (chainHeight_pos (Classical.arbitrary P)).trans_le (chainHeight_le_maxHeight _)

theorem maxHeight_le_card : maxHeight P ≤ Fintype.card P :=
  Finset.sup_le fun u _ => chainHeight_le_card u

section SourceHeight

variable {D : Type u} [PartialOrder D] {f : D → D} {M : Finset D}
variable (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)

noncomputable def sourceCardCode (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (s : SourcePoset f M) : Fin M.card :=
  ⟨M.card - s.val.card, by
    have hpos := Finset.card_pos.mpr (sourceMembers_nonempty hsep s)
    have hle := Finset.card_le_card (sourceMembers_subset s)
    omega⟩

include hsep in
theorem source_chain_card_le (S : Finset (SourcePoset f M))
    (hchain : ∀ x ∈ S, ∀ y ∈ S, x ≤ y ∨ y ≤ x) : S.card ≤ M.card := by
  have hinj : Set.InjOn (sourceCardCode hsep) (S : Set (SourcePoset f M)) := by
    intro x hx y hy hxy
    have hcodes := congrArg Fin.val hxy
    have hxle := Finset.card_le_card (sourceMembers_subset x)
    have hyle := Finset.card_le_card (sourceMembers_subset y)
    have hcards : x.val.card = y.val.card := by
      dsimp [sourceCardCode] at hcodes
      omega
    rcases hchain x hx y hy with hxy' | hyx'
    · apply Subtype.ext
      exact (Finset.eq_of_subset_of_card_le hxy' hcards.le).symm
    · apply Subtype.ext
      exact Finset.eq_of_subset_of_card_le hyx' hcards.ge
  have hc : (S.image (sourceCardCode hsep)).card = S.card := Finset.card_image_iff.mpr hinj
  calc
    S.card = (S.image (sourceCardCode hsep)).card := hc.symm
    _ ≤ (Finset.univ : Finset (Fin M.card)).card := Finset.card_le_card (Finset.subset_univ _)
    _ = M.card := by simp

include hsep in
theorem source_chainHeight_le_card [Fintype (SourcePoset f M)] (s : SourcePoset f M) :
    chainHeight s ≤ M.card := by
  obtain ⟨S, hS, hcard⟩ := chainHeight_attained s
  rw [hcard]
  exact source_chain_card_le hsep S hS.2.2

include hsep in
theorem source_maxHeight_le_card [Fintype (SourcePoset f M)] :
    maxHeight (SourcePoset f M) ≤ M.card :=
  Finset.sup_le fun s _ => source_chainHeight_le_card hsep s

end SourceHeight

end FiniteSeparation
