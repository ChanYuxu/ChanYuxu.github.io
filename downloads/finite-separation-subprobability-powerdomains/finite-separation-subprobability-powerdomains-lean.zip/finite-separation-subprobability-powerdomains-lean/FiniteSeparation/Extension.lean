import FiniteSeparation.Construction

set_option autoImplicit false

universe u

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation

variable {D : Type u} [PartialOrder D] [Nonempty D]

noncomputable def valuationExtension (hD : IsContinuousDomain D)
    (C : SourceData D) (m : ℕ) (hm : 2 ≤ m) : ScottContFun (VSub D) (VSub D) :=
  extendedMap VSub.isDcpo (lem_simple_basis hD).2 (lem_simple_basis hD).1
    (fun _ : Unit => localBasisMap C m hm) (fun _ => localBasisMap_monotone C m hm) ()

/-- `thm:extension`: the very same fixed grid separates the directed basis
extension, on the genuine continuous-valuation dcpo. -/
theorem thm_extension (hD : IsContinuousDomain D)
    (C : SourceData D) (m : ℕ) (hm : 2 ≤ m) :
    ScottContinuous (valuationExtension hD C m hm) ∧
    FiniteValuationApproximable.AbstractApproximation.IsFiniteSeparator (sourceGrid C m)
      (valuationExtension hD C m hm) := by
  refine ⟨(valuationExtension hD C m hm).continuous, ?_⟩
  exact basisExtension_separated VSub.isDcpo (lem_simple_basis hD).2
    (localBasisMap C m hm) (localBasisMap_monotone C m hm)
    (sourceGrid_finite C m) (prop_simple_separation C m hm).2.2

end FiniteSeparation
