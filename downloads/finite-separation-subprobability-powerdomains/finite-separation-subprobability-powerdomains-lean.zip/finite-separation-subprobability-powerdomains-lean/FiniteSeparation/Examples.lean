import FiniteSeparation.LocalMap
import FiniteSeparation.Height
import FiniteSeparation.Threshold
import FiniteSeparation.Grid
import FiniteSeparation.FiniteAgreement

/-!
# Finite computations for the numbered manuscript examples

Source SHA256: `2d544eb99266f3a6c842718e51b8a8ecd304c47aa1da5dd2393193208ab329ff`.
Only this file is owned by this sidecar. The underlying definitions are the
actual xi observations, expanded T coefficients, selected h coefficients, and
literal floor grid. This is computation/source-alignment evidence, not an
independent review of the imported implementation.
-/

set_option autoImplicit false
set_option maxRecDepth 2048

universe u v w

namespace FiniteSeparation.Examples

open Set AbramskyJung.Chapter2 PointAssignment LocalMap
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical

attribute [local simp] Fin.le_def Fin.lt_def Finsupp.single_apply

theorem fin3_ne02 : (0 : Fin 3) ≠ 2 := by decide
theorem fin3_ne20 : (2 : Fin 3) ≠ 0 := by decide
theorem fin3_ne12 : (1 : Fin 3) ≠ 2 := by decide
theorem fin3_ne21 : (2 : Fin 3) ≠ 1 := by decide
attribute [local simp] fin3_ne02 fin3_ne20 fin3_ne12 fin3_ne21

theorem fin_covBy_iff {n : ℕ} (u v : Fin n) : u ⋖ v ↔ u.val + 1 = v.val := by
  constructor
  · intro h
    have huv : u.val < v.val := h.lt
    by_contra hne
    have hgap : u.val + 1 < v.val := by omega
    let z : Fin n := ⟨u.val + 1, by omega⟩
    exact h.2 (show u < z by change u.val < u.val + 1; omega)
      (show z < v by exact hgap)
  · intro h
    refine ⟨by change u.val < v.val; omega, ?_⟩
    intro z huz hzv
    have h₁ : u.val < z.val := huz
    have h₂ : z.val < v.val := hzv
    omega

section IdentityCoordinates

variable {D : Type u} [PartialOrder D] [Fintype D]

theorem id_separates : ∀ x : D, ∃ a ∈ (Finset.univ : Finset D), id x ≤ a ∧ a ≤ x :=
  fun x => ⟨x, Finset.mem_univ x, le_rfl, le_rfl⟩

theorem id_sourcePi_le_iff (x y : D) :
    sourcePi id Finset.univ x ≤ sourcePi id Finset.univ y ↔ x ≤ y := by
  constructor
  · intro h
    exact (mem_sourceSlice.mp (h (mem_sourceSlice.mpr ⟨Finset.mem_univ y, le_rfl⟩))).2
  · intro h
    exact sourcePi_monotone (f := (id : D → D)) (M := Finset.univ) monotone_id h

/-- The printed identification x |-> upward x, not an arbitrary isomorphism. -/
noncomputable def idSourceIso : D ≃o SourcePoset id (Finset.univ : Finset D) where
  toEquiv := Equiv.ofBijective (sourcePi id Finset.univ)
    ⟨fun x y h => le_antisymm
      ((id_sourcePi_le_iff x y).mp h.le) ((id_sourcePi_le_iff y x).mp h.ge),
      sourcePi_surjective id Finset.univ⟩
  map_rel_iff' := by intro x y; exact id_sourcePi_le_iff x y

@[simp] theorem idSourceIso_apply (x : D) :
    idSourceIso x = sourcePi id Finset.univ x := rfl

theorem id_sourceSlice (x : D) :
    (sourcePi id Finset.univ x).val = Finset.univ.filter (fun y => x ≤ y) := rfl

@[simp] theorem id_chosen_agrees (x : D) :
    sourceChosen monotone_id (id_separates (D := D)) (idSourceIso x) = x := by
  apply le_antisymm
  · exact sourceChosen_le_member monotone_id id_separates _
      (mem_sourceSlice.mpr ⟨Finset.mem_univ x, le_rfl⟩)
  · exact sourceSquare_le_chosen monotone_id id_separates le_rfl

end IdentityCoordinates

section CoordinateTransport

variable {P : Type u} {Q : Type v} [PartialOrder P] [PartialOrder Q]
variable [Fintype P] [Fintype Q]

theorem map_covers (e : P ≃o Q) (u : P) :
    (covers u).map e.toEmbedding = covers (e u) := by
  ext q
  obtain ⟨v, rfl⟩ := e.surjective q
  simp [covers, apply_covBy_apply_iff]

omit [Fintype P] [Fintype Q] in
theorem map_exitUpper (e : P ≃o Q) (A : Finset P) (u v : P) :
    e v ∈ exitUpper (A.map e.toEmbedding : Set Q) (e u) ↔
      v ∈ exitUpper (A : Set P) u := by
  constructor
  · rintro ⟨q, huq, hqA, hqv⟩
    obtain ⟨z, rfl⟩ := e.surjective q
    exact ⟨z, (apply_covBy_apply_iff e).mp huq, by simpa using hqA,
      (e.le_iff_le).mp hqv⟩
  · rintro ⟨z, huz, hzA, hzv⟩
    exact ⟨e z, (apply_covBy_apply_iff e).mpr huz, by simpa using hzA,
      e.monotone hzv⟩

theorem chainHeight_orderIso (e : P ≃o Q) (u : P) : chainHeight (e u) = chainHeight u := by
  have hmap (S : Finset P) (hS : ChainEnding S u) :
      ChainEnding (S.map e.toEmbedding) (e u) := by
    refine ⟨by simpa using hS.1, ?_, ?_⟩
    · intro q hq
      obtain ⟨x, hx, rfl⟩ := Finset.mem_map.mp hq
      exact e.monotone (hS.2.1 x hx)
    · intro q hq r hr
      obtain ⟨x, hx, rfl⟩ := Finset.mem_map.mp hq
      obtain ⟨y, hy, rfl⟩ := Finset.mem_map.mp hr
      exact (hS.2.2 x hx y hy).imp (fun h => e.monotone h) (fun h => e.monotone h)
  have hle (S : Finset P) (hS : ChainEnding S u) : S.card ≤ chainHeight (e u) := by
    simpa using chainHeight_max (hmap S hS)
  apply le_antisymm
  · obtain ⟨S, hS, hcard⟩ := chainHeight_attained (e u)
    have hback : ChainEnding (S.map e.symm.toEmbedding) u := by
      refine ⟨by simpa using hS.1, ?_, ?_⟩
      · intro x hx
        obtain ⟨q, hq, rfl⟩ := Finset.mem_map.mp hx
        simpa using e.symm.monotone (hS.2.1 q hq)
      · intro x hx y hy
        obtain ⟨q, hq, rfl⟩ := Finset.mem_map.mp hx
        obtain ⟨r, hr, rfl⟩ := Finset.mem_map.mp hy
        exact (hS.2.2 q hq r hr).imp (fun h => e.symm.monotone h) (fun h => e.symm.monotone h)
    rw [hcard]
    simpa using chainHeight_max hback
  · obtain ⟨S, hS, hcard⟩ := chainHeight_attained u
    rw [hcard]
    exact hle S hS

/-- The finite source choices and cover unions transport to the printed coordinates. -/
theorem id_source_exit {D : Type w} [PartialOrder D] [Fintype D]
    (A : Finset D) (u x : D) :
    sourcePi id Finset.univ x ∈
      exitUpper (A.map (idSourceIso (D := D)).toEmbedding : Set _) (idSourceIso u) ↔
      x ∈ exitUpper (A : Set D) u :=
  map_exitUpper idSourceIso A u x

theorem maxHeight_orderIso (e : P ≃o Q) : maxHeight Q = maxHeight P := by
  apply le_antisymm
  · apply Finset.sup_le
    intro q hq
    obtain ⟨p, rfl⟩ := e.surjective q
    rw [chainHeight_orderIso]
    exact chainHeight_le_maxHeight p
  · apply Finset.sup_le
    intro p hp
    rw [← chainHeight_orderIso e p]
    exact chainHeight_le_maxHeight (e p)

theorem edgeCount_orderIso (e : P ≃o Q) : edgeCount (P := Q) = edgeCount (P := P) := by
  unfold edgeCount
  rw [← e.toEquiv.sum_comp (fun q => (covers q).card)]
  apply Finset.sum_congr rfl
  intro p hp
  change (covers (e p)).card = (covers p).card
  rw [← map_covers e p, Finset.card_map]

theorem map_covers_inter (e : P ≃o Q) (A : Finset P) (u : P) :
    (covers u ∩ A).map e.toEmbedding = covers (e u) ∩ A.map e.toEmbedding := by
  rw [Finset.map_inter, map_covers]

theorem correction_transport {D : Type w} [PartialOrder D] (e : P ≃o Q)
    (pi : D → P) (t : P → ℝ) (p : Coeff D) (A : Finset P) (u : P) :
    correctionCoeff (e ∘ pi) (t ∘ e.symm) p (A.map e.toEmbedding) (e u) =
      correctionCoeff pi t p A u := by
  have hb : boundary (e ∘ pi) (A.map e.toEmbedding) (e u) = boundary pi A u := by
    ext x
    exact map_exitUpper e A u (pi x)
  unfold correctionCoeff
  rw [hb, ← map_covers_inter, Finset.sum_map]
  simp

theorem selected_transport {D : Type w} [PartialOrder D] (e : P ≃o Q)
    (pi : D → P) (t : P → ℝ) (p : Coeff D) :
    selected (e ∘ pi) (t ∘ e.symm) p = (selected pi t p).map e.toEmbedding := by
  ext q
  obtain ⟨u, rfl⟩ := e.surjective q
  have hf : upperFiber (e ∘ pi) (e u) = upperFiber pi u := by
    ext x
    exact e.le_iff_le
  simp [mem_selected, hf]

theorem rawT_transport {D : Type w} [PartialOrder D] (e : P ≃o Q)
    (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ) (A : Finset P) (p : Coeff D) :
    rawT (e ∘ pi) g (a ∘ e.symm) (t ∘ e.symm) (A.map e.toEmbedding) p =
      rawT pi g a t A p := by
  have hh : headCoeff (e ∘ pi) g (A.map e.toEmbedding) p = headCoeff pi g A p := by
    unfold headCoeff
    apply Finset.sum_congr rfl
    intro x hx
    simp
  unfold rawT
  rw [hh, Finset.sum_map]
  congr 1
  apply Finset.sum_congr rfl
  intro u hu
  change Finsupp.single ((a ∘ e.symm) (e u))
    (correctionCoeff (e ∘ pi) (t ∘ e.symm) p (A.map e.toEmbedding) (e u)) = _
  rw [correction_transport]
  simp

theorem rawH_transport {D : Type w} [PartialOrder D] (e : P ≃o Q)
    (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ) (scale : ℝ) (p : Coeff D) :
    rawH (e ∘ pi) g (a ∘ e.symm) (t ∘ e.symm) scale p = rawH pi g a t scale p := by
  unfold rawH rawSelectedT
  rw [selected_transport, rawT_transport]

/-- Full raw-h bridge: finite coordinates compute the specified source map. -/
theorem id_sourceH_eq_coordinates {D : Type w} [PartialOrder D] [Fintype D]
    (m : ℝ) (p : Coeff D) :
    sourceH monotone_id (id_separates (D := D)) chainHeight m p =
      rawH id id id (LocalMap.threshold chainHeight m) (fixedScale (P := D) m) p := by
  let e : D ≃o SourcePoset id (Finset.univ : Finset D) := idSourceIso
  have hpi : sourcePi (id : D → D) Finset.univ = e ∘ id := rfl
  have ha : sourceChosen monotone_id (id_separates (D := D)) = id ∘ e.symm := by
    funext q
    obtain ⟨x, rfl⟩ := e.surjective q
    exact (id_chosen_agrees x).trans (by simp)
  have ht : LocalMap.threshold (chainHeight (P := SourcePoset id (Finset.univ : Finset D))) m =
      LocalMap.threshold (chainHeight (P := D)) m ∘ e.symm := by
    funext q
    obtain ⟨x, rfl⟩ := e.surjective q
    simp [LocalMap.threshold, chainHeight_orderIso]
  have hs : fixedScale (P := SourcePoset id (Finset.univ : Finset D)) m =
      fixedScale (P := D) m := by simp [fixedScale, edgeCount_orderIso e]
  unfold sourceH
  rw [hpi, ha, ht, hs]
  exact rawH_transport e id id id _ _ p

end CoordinateTransport

section LinearHeights

variable {P : Type u} [LinearOrder P] [Fintype P]

theorem chainHeight_linear (u : P) :
    chainHeight u = (Finset.univ.filter (fun x : P => x ≤ u)).card := by
  let S := Finset.univ.filter (fun x : P => x ≤ u)
  have hS : ChainEnding S u := by
    refine ⟨by simp [S], ?_, ?_⟩
    · intro x hx
      exact (Finset.mem_filter.mp hx).2
    · intro x hx y hy
      exact le_total x y
  apply le_antisymm
  · obtain ⟨T, hT, hcard⟩ := chainHeight_attained u
    rw [hcard]
    apply Finset.card_le_card
    intro x hx
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ x, hT.2.1 x hx⟩
  · exact chainHeight_max hS

end LinearHeights

/-! ## ex:two-chain (source lines 599-605) -/

theorem twoChain_exit : exitUpper ({0} : Set (Fin 2)) 0 = {1} := by
  ext x
  constructor
  · rintro ⟨z, hz, _, hzx⟩
    have hzv := (fin_covBy_iff 0 z).mp hz
    have hzxv : z.val ≤ x.val := hzx
    have hxv := x.isLt
    apply Fin.ext
    change x.val = 1
    change 0 + 1 = z.val at hzv
    omega
  · intro hx
    have hx1 : x = 1 := hx
    subst x
    exact ⟨1, (fin_covBy_iff 0 1).mpr rfl, by decide, le_rfl⟩

theorem twoChain_xi (U : Set (Fin 2)) (x : Fin 2) :
    xiObservation id id id ({0} : Set (Fin 2)) U x = flag ((0 : Fin 2) ∈ U) := by
  rw [xiObservation_eq_printed]
  simp only [id_eq]
  have hsum : (∑ u : Fin 2, flag (u ∈ ({0} : Set (Fin 2))) *
      flag (x ∈ exitUpper ({0} : Set (Fin 2)) u) * flag (u ∈ U)) =
      flag (x ∈ exitUpper ({0} : Set (Fin 2)) 0) * flag ((0 : Fin 2) ∈ U) := by
    rw [Finset.sum_eq_single 0]
    · simp [flag]
    · intro u hu hne
      simp [flag, hne]
    · simp
  rw [hsum, twoChain_exit]
  fin_cases x <;> by_cases h : (0 : Fin 2) ∈ U <;> simp [flag, h]

theorem twoChain_head_not_monotone :
    ¬ Monotone (fun x : Fin 2 => flag (x ∈ ({0} : Set (Fin 2)))) := by
  intro h
  have hh := h (show (0 : Fin 2) ≤ 1 by decide)
  norm_num [flag] at hh

/-! ## ex:diamond and ex:three-chain (source lines 649-658, 706-719) -/

abbrev Diamond := Fin 2 × Fin 2
def d0 : Diamond := (0, 0)
def da : Diamond := (0, 1)
def db : Diamond := (1, 0)
def d1 : Diamond := (1, 1)

theorem diamond_univ : (Finset.univ : Finset Diamond) = {d0, da, db, d1} := by
  ext x
  rcases x with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;> simp [d0, da, db, d1]

theorem diamond_covers (u : Diamond) : covers u =
    if u = d0 then {da, db} else if u = da ∨ u = db then {d1} else ∅ := by
  ext v
  rcases u with ⟨u, u'⟩
  rcases v with ⟨v, v'⟩
  fin_cases u <;> fin_cases u' <;> fin_cases v <;> fin_cases v' <;>
    norm_num [covers, Prod.covBy_iff, fin_covBy_iff, d0, da, db, d1]

theorem diamond_exit : exitUpper ({d0} : Set Diamond) d0 = {da, db, d1} := by
  ext x
  rcases x with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    norm_num [exitUpper, Prod.exists, Fin.exists_fin_succ, Prod.covBy_iff,
      fin_covBy_iff, d0, da, db, d1]

theorem diamond_exit_union : exitUpper ({d0} : Set Diamond) d0 =
    Set.Ici da ∪ Set.Ici db := by
  rw [diamond_exit]
  ext x
  rcases x with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;> simp [d0, da, db, d1]

theorem diamond_xi (U : Set Diamond) (x : Diamond) :
    xiObservation id id id ({d0} : Set Diamond) U x = flag (d0 ∈ U) := by
  rw [xiObservation_eq_printed]
  simp only [id_eq]
  have hsum : ∑ u : Diamond, flag (u ∈ ({d0} : Set Diamond)) *
      flag (x ∈ exitUpper ({d0} : Set Diamond) u) * flag (u ∈ U) =
        flag (x ∈ exitUpper ({d0} : Set Diamond) d0) * flag (d0 ∈ U) := by
    rw [Finset.sum_eq_single d0]
    · simp [flag]
    · intro u hu hne
      simp [flag, hne]
    · simp
  rw [hsum, diamond_exit]
  rcases x with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;> by_cases h : d0 ∈ U <;>
    simp [flag, h, d0, da, db, d1] at *

def diamondA : Finset Diamond := {d0, da, db}

theorem diamondA_xi_top (U : Set Diamond) :
    xiObservation id id id (diamondA : Set Diamond) U d1 = flag (da ∈ U) + flag (db ∈ U) := by
  rw [xiObservation_eq_printed]
  rw [show (Finset.univ : Finset Diamond) = {d0, da, db, d1} from diamond_univ]
  by_cases ha : da ∈ U <;> by_cases hb : db ∈ U <;>
    norm_num [diamondA, exitUpper, Prod.exists, Fin.exists_fin_succ, Prod.covBy_iff,
      fin_covBy_iff, flag, ha, hb, d0, da, db, d1] at * <;> rfl

theorem diamondB_xi_top (U : Set Diamond) :
    xiObservation id id id (Set.univ : Set Diamond) U d1 = flag (d1 ∈ U) := by
  simp [xiObservation, correction, exitUpper, flag]

theorem diamond_xi_not_subset_mono :
    ¬ xiObservation id id id (diamondA : Set Diamond) Set.univ d1 ≤
      xiObservation id id id (Set.univ : Set Diamond) Set.univ d1 := by
  rw [diamondA_xi_top, diamondB_xi_top]
  norm_num [flag]

theorem diamond_tau (t : Diamond → ℝ) :
    tauCoeff id t diamondA = Finsupp.single d0 (t da + t db) ∧
      tauCoeff id t Finset.univ = Finsupp.single d0 (t da + t db) +
        Finsupp.single da (t d1) + Finsupp.single db (t d1) := by
  classical
  letI : DecidableEq Diamond := Classical.decEq Diamond
  constructor <;> apply Finsupp.ext <;> intro x <;> rcases x with ⟨x, y⟩ <;>
    fin_cases x <;> fin_cases y <;>
      simp [tauCoeff, diamond_univ, diamond_covers, diamondA,
        d0, da, db, d1]
  all_goals
    rw [← Finset.filter_mem_eq_inter]
    simp [Finset.filter_insert, Finset.filter_singleton]

theorem diamond_threshold_comparison (t : Diamond → ℝ) (ht : ∀ x, 0 ≤ t x)
    (r : ℝ) (hr : 0 ≤ r) (hrt : r ≤ t d1) (U : Set Diamond) :
    mass (rawT id id id t diamondA (Finsupp.single d1 r)) U ≤
      mass (rawT id id id t Finset.univ (Finsupp.single d1 r)) U := by
  have hp : Nonneg (Finsupp.single d1 r) := by
    have h : (0 : Coeff Diamond) ≤ Finsupp.single d1 r := Finsupp.single_nonneg.mpr hr
    exact fun x => h x
  apply rawT_mono_subset id id id t ht hp (Finset.subset_univ _) _ U
  intro u hu
  have hu1 : u = d1 := by
    rcases u with ⟨x, y⟩
    fin_cases x <;> fin_cases y <;> simp_all [diamondA, d0, da, db, d1]
  subst u
  simpa [mass_single, upperFiber] using hrt

/-! ## ex:full-calculation (source lines 952-985) -/

abbrev Chain3 := Fin 3

theorem chain3_univ : (Finset.univ : Finset Chain3) = {0, 1, 2} := by decide

theorem chain3_covers (u : Chain3) :
    covers u = if u = 0 then {1} else if u = 1 then {2} else ∅ := by
  ext v
  simp only [covers, Finset.mem_filter, Finset.mem_univ, true_and, fin_covBy_iff]
  fin_cases u <;> fin_cases v <;> decide

theorem chain3_height (u : Chain3) : chainHeight u = u.val + 1 := by
  rw [chainHeight_linear, Finset.filter_ge_eq_Iic, Fin.card_Iic]

theorem chain3_maxHeight : maxHeight Chain3 = 3 := by
  simp [maxHeight, chain3_univ, chain3_height]

theorem chain3_edgeCount : edgeCount (P := Chain3) = 2 := by
  simp [edgeCount, chain3_univ, chain3_covers]

noncomputable def chain3_t (u : Chain3) : ℝ := LocalMap.threshold chainHeight 2 u

theorem chain3_thresholds : chain3_t 0 = 1 / 2 ∧ chain3_t 1 = 1 / 4 ∧ chain3_t 2 = 1 / 8 := by
  norm_num [chain3_t, LocalMap.threshold, chain3_height]

noncomputable def chain3_p : Coeff Chain3 :=
  Finsupp.single 0 (1 / 2) + Finsupp.single 1 (1 / 4) + Finsupp.single 2 (1 / 8)

theorem chain3_p_apply (x : Chain3) : chain3_p x =
    if x = 0 then 1 / 2 else if x = 1 then 1 / 4 else 1 / 8 := by
  fin_cases x <;> norm_num [chain3_p, Fin.ext_iff, -Fin.val_eq_zero_iff]

theorem chain3_mass (U : Set Chain3) : mass chain3_p U =
    (if (0 : Chain3) ∈ U then 1 / 2 else 0) +
      (if (1 : Chain3) ∈ U then 1 / 4 else 0) +
      (if (2 : Chain3) ∈ U then 1 / 8 else 0) := by
  simp [chain3_p, mass_add, mass_single]

theorem headCoeff_univ {D : Type u} [PartialOrder D] [Fintype D]
    {P : Type v} [PartialOrder P] (pi : D → P) (g : D → D) (A : Finset P) (p : Coeff D) :
    headCoeff pi g A p = ∑ x : D, Finsupp.single (g x) (if pi x ∈ A then p x else 0) := by
  apply Finset.sum_subset (Finset.subset_univ _)
  intro x hx hxp
  simp [Finsupp.notMem_support_iff.mp hxp]

theorem chain3_mass_upper :
    mass chain3_p (upperFiber id 0) = 7 / 8 ∧
      mass chain3_p (upperFiber id 1) = 3 / 8 ∧
      mass chain3_p (upperFiber id 2) = 1 / 8 := by
  norm_num [chain3_mass, upperFiber]

theorem chain3_selected : selected id chain3_t chain3_p = {0, 1} := by
  ext u
  fin_cases u <;> norm_num [mem_selected, chain3_mass, upperFiber,
    chain3_t, LocalMap.threshold, chain3_height]

theorem chain3_scale : fixedScale (P := Chain3) 2 = 2 / 5 := by
  norm_num [fixedScale, chain3_edgeCount]

theorem chain3_exit (u : Chain3) : exitUpper ({0, 1} : Set Chain3) u =
    if u = 1 then {2} else ∅ := by
  have he (x : Chain3) : x ∈ exitUpper ({0, 1} : Set Chain3) u ↔ u = 1 ∧ x = 2 := by
    constructor
    · rintro ⟨z, huz, hz, hzx⟩
      have hv := (fin_covBy_iff u z).mp huz
      have hz0 : z ≠ 0 := fun h => hz (Or.inl h)
      have hz1 : z ≠ 1 := fun h => hz (Or.inr h)
      have hz2 : z = 2 := by fin_cases z <;> simp_all
      subst z
      have huv : u.val + 1 = 2 := hv
      have hzxv : 2 ≤ x.val := hzx
      have hxv := x.isLt
      exact ⟨Fin.ext (by change u.val = 1; omega), Fin.ext (by change x.val = 2; omega)⟩
    · rintro ⟨rfl, rfl⟩
      exact ⟨2, (fin_covBy_iff 1 2).mpr rfl, by decide, le_rfl⟩
  ext x
  rw [he]
  by_cases hu : u = 1 <;> simp [hu]

theorem chain3_correction (u : Chain3) :
    correctionCoeff id chain3_t chain3_p {0, 1} u =
      if u = 0 then 1 / 4 else if u = 1 then 1 / 8 else 0 := by
  have hb : boundary id ({0, 1} : Finset Chain3) u =
      if u = 1 then {2} else ∅ := by
    simpa only [boundary, Set.preimage_id, Finset.coe_insert, Finset.coe_singleton]
      using chain3_exit u
  rw [correctionCoeff, hb, chain3_covers]
  fin_cases u <;>
    norm_num [chain3_mass, chain3_t, LocalMap.threshold, chain3_height,
      Fin.ext_iff, -Fin.val_eq_zero_iff, Finset.insert_inter_of_mem]

theorem chain3_T : rawSelectedT id id id chain3_t chain3_p =
    Finsupp.single 0 (3 / 4) + Finsupp.single 1 (3 / 8) := by
  rw [rawSelectedT, chain3_selected, rawT, headCoeff_univ]
  ext x
  fin_cases x <;>
    norm_num [chain3_univ, chain3_p_apply, chain3_correction,
      Fin.ext_iff, -Fin.val_eq_zero_iff]

theorem chain3_tau : tauCoeff id chain3_t {0, 1} = Finsupp.single 0 (1 / 4) := by
  ext x
  fin_cases x <;>
    norm_num [tauCoeff, chain3_covers, chain3_t, LocalMap.threshold, chain3_height,
      Fin.ext_iff, -Fin.val_eq_zero_iff, Finset.insert_inter_of_mem]

theorem chain3_point_contribution (U : Set Chain3) :
    integral chain3_p (xiObservation id id id ({0, 1} : Set Chain3) U) =
      mass (Finsupp.single 0 (1 / 2) + Finsupp.single 1 (3 / 8)) U := by
  have he := mass_rawT_eq_integral id id id chain3_t {0, 1} chain3_p U
  have hT : rawT id id id chain3_t {0, 1} chain3_p =
      Finsupp.single 0 (3 / 4) + Finsupp.single 1 (3 / 8) := by
    simpa only [rawSelectedT, chain3_selected] using chain3_T
  rw [hT, chain3_tau] at he
  simp only [mass_add, mass_single] at he ⊢
  by_cases h0 : (0 : Chain3) ∈ U <;> by_cases h1 : (1 : Chain3) ∈ U <;>
    simp [h0, h1] at he ⊢ <;> linarith

theorem chain3_h : rawH id id id chain3_t (fixedScale (P := Chain3) 2) chain3_p =
    Finsupp.single 0 (3 / 10) + Finsupp.single 1 (3 / 20) := by
  rw [rawH, chain3_T, chain3_scale]
  ext x
  fin_cases x <;> norm_num

theorem chain3_T_total : mass (rawSelectedT id id id chain3_t chain3_p) Set.univ = 9 / 8 := by
  rw [chain3_T]
  norm_num

theorem chain3_N : gridDenominator 3 2 (edgeCount (P := Chain3)) (maxHeight Chain3) = 121 := by
  norm_num [gridDenominator, chain3_edgeCount, chain3_maxHeight]

noncomputable def chain3_vector : FiniteValuationApproximable.SubprobabilityVector Chain3 where
  coeff x := chain3_p x
  coeff_nonneg x := by fin_cases x <;> norm_num [chain3_p_apply]
  total_le_one := by rw [chain3_univ]; norm_num [chain3_p_apply]

theorem chain3_roundDown (x : Chain3) :
    FiniteValuationApproximable.Erosion.roundDown 121 (by norm_num) chain3_vector x =
      if x = 0 then 60 / 121 else if x = 1 then 30 / 121 else 15 / 121 := by
  rw [FiniteValuationApproximable.Erosion.roundDown_apply]
  fin_cases x <;> norm_num [chain3_vector, chain3_p_apply]

theorem chain3_source_h :
    sourceH monotone_id (id_separates (D := Chain3)) chainHeight 2 chain3_p =
      Finsupp.single 0 (3 / 10) + Finsupp.single 1 (3 / 20) := by
  rw [id_sourceH_eq_coordinates]
  exact chain3_h

theorem chain3_source_N :
    gridDenominator (Finset.univ : Finset Chain3).card 2
      (edgeCount (P := SourcePoset id (Finset.univ : Finset Chain3)))
      (maxHeight (SourcePoset id (Finset.univ : Finset Chain3))) = 121 := by
  rw [edgeCount_orderIso (idSourceIso (D := Chain3)),
    maxHeight_orderIso (idSourceIso (D := Chain3))]
  simpa using chain3_N

noncomputable def chain3_rounded : Coeff Chain3 :=
  finiteCoeff id (FiniteValuationApproximable.Erosion.roundDown 121 (by norm_num) chain3_vector)

theorem chain3_rounded_coeff : chain3_rounded = Finsupp.single 0 (60 / 121) +
    Finsupp.single 1 (30 / 121) + Finsupp.single 2 (15 / 121) := by
  ext x
  fin_cases x <;> norm_num [chain3_rounded, finiteCoeff, chain3_univ, chain3_roundDown]

theorem chain3_separating_witness (U : Set Chain3) :
    mass (rawH id id id chain3_t (fixedScale (P := Chain3) 2) chain3_p) U ≤
      mass chain3_rounded U ∧ mass chain3_rounded U ≤ mass chain3_p U := by
  rw [chain3_h, chain3_rounded_coeff]
  by_cases h0 : (0 : Chain3) ∈ U <;> by_cases h1 : (1 : Chain3) ∈ U <;>
    by_cases h2 : (2 : Chain3) ∈ U <;>
      norm_num [mass_add, mass_single, chain3_mass, h0, h1, h2]

/-! ## rem:covers (source lines 987-994)
The strict-pair count counts each pair by its upper endpoint. No comparison
between the corresponding local maps is asserted.
-/

noncomputable def strictPairCount (P : Type u) [PartialOrder P] [Fintype P] : ℕ :=
  ∑ v : P, (Finset.univ.filter (fun u => u < v)).card

theorem fin_covers_card {n : ℕ} (u : Fin n) :
    (covers u).card = if u.val + 1 < n then 1 else 0 := by
  by_cases h : u.val + 1 < n
  · have hs : covers u = {⟨u.val + 1, h⟩} := by
      apply Finset.ext
      intro v
      simp only [covers, Finset.mem_filter, Finset.mem_univ, true_and,
        fin_covBy_iff, Finset.mem_singleton]
      exact ⟨fun hv => Fin.ext hv.symm, fun hv => (congrArg Fin.val hv).symm⟩
    simp [hs, h]
  · have hs : covers u = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro v hv
      have hv' := (fin_covBy_iff u v).mp ((Finset.mem_filter.mp hv).2)
      have hvn := v.isLt
      omega
    simp [hs, h]

theorem fin_edgeCount (n : ℕ) : edgeCount (P := Fin n) = n - 1 := by
  cases n with
  | zero => simp [edgeCount]
  | succ n =>
    rw [edgeCount, Fin.sum_univ_castSucc]
    simp only [fin_covers_card, Fin.val_castSucc, Fin.val_last, Nat.lt_irrefl,
      if_false, add_zero]
    have hsum : (∑ u : Fin n, if u.val + 1 < n + 1 then 1 else 0) = n := by
      calc
        _ = ∑ _u : Fin n, 1 := by
          apply Finset.sum_congr rfl
          intro u hu
          exact if_pos (by have h := u.isLt; omega)
        _ = n := by simp
    simpa using hsum

theorem fin_sum_val_twice (n : ℕ) : 2 * (∑ u : Fin n, u.val) = n * (n - 1) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Fin.sum_univ_castSucc]
    simp only [Fin.val_castSucc, Fin.val_last]
    cases n with
    | zero => simp
    | succ k =>
      simp only [Nat.add_sub_cancel] at ih ⊢
      nlinarith

theorem fin_strictPairCount (n : ℕ) : strictPairCount (Fin n) = n * (n - 1) / 2 := by
  unfold strictPairCount
  simp_rw [Finset.filter_gt_eq_Iio, Fin.card_Iio]
  have h := fin_sum_val_twice n
  omega

theorem fin_coverCount_le_strictPairCount (n : ℕ) :
    edgeCount (P := Fin n) ≤ strictPairCount (Fin n) := by
  rw [fin_edgeCount]
  have h : 2 * strictPairCount (Fin n) = n * (n - 1) := by
    unfold strictPairCount
    simp_rw [Finset.filter_gt_eq_Iio, Fin.card_Iio]
    exact fin_sum_val_twice n
  cases n with
  | zero => simp
  | succ n =>
    cases n with
    | zero => omega
    | succ k =>
      simp only [Nat.add_sub_cancel] at h ⊢
      nlinarith

theorem fin_chainHeight {n : ℕ} (u : Fin n) : chainHeight u = u.val + 1 := by
  rw [chainHeight_linear, Finset.filter_ge_eq_Iic, Fin.card_Iic]

theorem fin_cover_generates_order {n : ℕ} (u v : Fin n) :
    Relation.ReflTransGen (fun x y : Fin n => x ⋖ y) u v ↔ u ≤ v :=
  le_iff_reflTransGen_covBy.symm

theorem fin_threshold_height {n : ℕ} (u : Fin n) (m : ℝ) :
    LocalMap.threshold chainHeight m u = (m ^ (u.val + 1))⁻¹ := by
  rw [LocalMap.threshold, fin_chainHeight]

theorem covers_denominator_le (n m : ℕ) :
    m + edgeCount (P := Fin n) + 1 ≤ m + strictPairCount (Fin n) + 1 := by
  have h := fin_coverCount_le_strictPairCount n
  omega

theorem covers_gridDenominator_le (n size m H : ℕ) :
    gridDenominator size m (edgeCount (P := Fin n)) H ≤
      gridDenominator size m (strictPairCount (Fin n)) H := by
  unfold gridDenominator
  gcongr
  exact fin_coverCount_le_strictPairCount n

/-! ## ex:unpointed (source lines 1218-1233) -/

noncomputable def finite_idFS (D : Type u) [PartialOrder D] [Fintype D] : FSIdentity D where
  maps := {⟨id, scottContinuous_id⟩}
  directed := by
    refine ⟨⟨⟨id, scottContinuous_id⟩, rfl⟩, ?_⟩
    intro f hf g hg
    have hf' : f = ⟨id, scottContinuous_id⟩ := hf
    have hg' : g = ⟨id, scottContinuous_id⟩ := hg
    subst f
    subst g
    exact ⟨⟨id, scottContinuous_id⟩, rfl, le_rfl, le_rfl⟩
  finitelySeparated := by
    intro f hf
    have hf' : f = ⟨id, scottContinuous_id⟩ := hf
    subst f
    exact ⟨Set.univ, Set.toFinite _, fun x => ⟨x, Set.mem_univ x, le_rfl, le_rfl⟩⟩
  pointwise_sup := by
    intro x
    simpa using isSup_singleton x

inductive TwoPoint where
  | a | b
  deriving DecidableEq, Fintype

instance : Nonempty TwoPoint := ⟨TwoPoint.a⟩

instance : PartialOrder TwoPoint where
  le x y := x = y
  le_refl _ := rfl
  le_trans _ _ _ := Eq.trans
  le_antisymm _ _ h _ := h

@[simp] theorem twoPoint_le (x y : TwoPoint) : x ≤ y ↔ x = y := Iff.rfl

@[simp] theorem twoPoint_not_lt (x y : TwoPoint) : ¬ x < y := by
  intro h
  have heq : x = y := h.le
  subst y
  exact lt_irrefl x h

theorem twoPoint_univ : (Finset.univ : Finset TwoPoint) = {TwoPoint.a, TwoPoint.b} := by
  ext x
  cases x <;> simp

theorem twoPoint_no_least : ¬ ∃ x : TwoPoint, ∀ y, x ≤ y := by
  rintro ⟨x, hx⟩
  cases x with
  | a => have h := hx TwoPoint.b; cases h
  | b => have h := hx TwoPoint.a; cases h

theorem twoPoint_isFSDomain : IsFSDomain TwoPoint := by
  refine ⟨⟨TwoPoint.a⟩, ?_, ⟨finite_idFS TwoPoint⟩⟩
  intro A hA
  obtain ⟨s, _, hs⟩ := hA.exists_isSup_of_finite (Set.toFinite A)
  exact ⟨s, hs⟩

theorem twoPoint_continuousDomain : IsContinuousDomain TwoPoint :=
  (finite_idFS TwoPoint).continuousDomain

theorem twoPoint_sourceSlice (x : TwoPoint) : sourceSlice id Finset.univ x = {x} := by
  ext y
  simp [sourceSlice, eq_comm]

theorem twoPoint_source_antichain (u v : SourcePoset id (Finset.univ : Finset TwoPoint)) :
    u ≤ v ↔ u = v := by
  obtain ⟨x, rfl⟩ := sourcePi_surjective id Finset.univ u
  obtain ⟨y, rfl⟩ := sourcePi_surjective id Finset.univ v
  rw [id_sourcePi_le_iff]
  constructor
  · intro h
    have hxy : x = y := h
    subst y
    rfl
  · intro h
    exact (id_sourcePi_le_iff x y).mp h.le

theorem twoPoint_covers (x : TwoPoint) : covers x = ∅ := by
  ext y
  simp [covers, CovBy]

theorem twoPoint_height (x : TwoPoint) : chainHeight x = 1 := by
  apply le_antisymm
  · obtain ⟨S, hS, hcard⟩ := chainHeight_attained x
    rw [hcard]
    have hsub : S ⊆ {x} := by
      intro y hy
      exact Finset.mem_singleton.mpr ((twoPoint_le y x).mp (hS.2.1 y hy))
    simpa using Finset.card_le_card hsub
  · exact chainHeight_pos x

theorem twoPoint_parameters : maxHeight TwoPoint = 1 ∧ edgeCount (P := TwoPoint) = 0 := by
  simp [maxHeight, edgeCount, twoPoint_univ, twoPoint_height, twoPoint_covers]

theorem twoPoint_source_parameters (m : ℝ) :
    maxHeight (SourcePoset id (Finset.univ : Finset TwoPoint)) = 1 ∧
      edgeCount (P := SourcePoset id (Finset.univ : Finset TwoPoint)) = 0 ∧
      ∀ u : SourcePoset id (Finset.univ : Finset TwoPoint),
        LocalMap.threshold chainHeight m u = m⁻¹ := by
  rw [maxHeight_orderIso (idSourceIso (D := TwoPoint)),
    edgeCount_orderIso (idSourceIso (D := TwoPoint))]
  refine ⟨twoPoint_parameters.1, twoPoint_parameters.2, ?_⟩
  intro u
  obtain ⟨x, rfl⟩ := (idSourceIso (D := TwoPoint)).surjective u
  rw [LocalMap.threshold, chainHeight_orderIso, twoPoint_height, pow_one]

theorem twoPoint_mass_fiber (p : Coeff TwoPoint) (x : TwoPoint) :
    mass p (upperFiber id x) = p x := by
  rw [mass_on p (Finset.subset_univ _), twoPoint_univ]
  cases x <;> simp [upperFiber]

theorem twoPoint_exit_empty (A : Set TwoPoint) (x : TwoPoint) : exitUpper A x = ∅ := by
  ext y
  simp [exitUpper, CovBy]

theorem twoPoint_h (m : ℝ) (p : Coeff TwoPoint) :
    rawH id id id (LocalMap.threshold chainHeight m) (fixedScale (P := TwoPoint) m) p =
      (m / (m + 1)) • (Finsupp.single TwoPoint.a
        (if m⁻¹ < p TwoPoint.a then p TwoPoint.a else 0) +
          Finsupp.single TwoPoint.b (if m⁻¹ < p TwoPoint.b then p TwoPoint.b else 0)) := by
  unfold rawH rawSelectedT rawT
  rw [headCoeff_univ, twoPoint_univ]
  simp [correctionCoeff, boundary, twoPoint_exit_empty, twoPoint_covers,
    LocalMap.threshold, twoPoint_height, fixedScale, twoPoint_parameters.2,
    mem_selected, twoPoint_mass_fiber]

theorem twoPoint_source_h (m : ℝ) (u v : ℝ) :
    sourceH monotone_id (id_separates (D := TwoPoint)) chainHeight m
      (Finsupp.single TwoPoint.a u + Finsupp.single TwoPoint.b v) =
      (m / (m + 1)) •
        (Finsupp.single TwoPoint.a (u * flag (m⁻¹ < u)) +
          Finsupp.single TwoPoint.b (v * flag (m⁻¹ < v))) := by
  rw [id_sourceH_eq_coordinates, twoPoint_h]
  by_cases hu : m⁻¹ < u <;> by_cases hv : m⁻¹ < v <;> simp [flag, hu, hv]

noncomputable def twoPoint_source : SourceData TwoPoint :=
  ⟨⟨id, scottContinuous_id⟩, Finset.univ, id_separates⟩

noncomputable def twoPoint_simple (u v : ℝ) (hu : 0 ≤ u) (hv : 0 ≤ v) (ht : u + v ≤ 1) :
    SimpleCoeff TwoPoint where
  coeff := Finsupp.single TwoPoint.a u + Finsupp.single TwoPoint.b v
  nonneg x := by cases x <;> simp [hu, hv]
  total_le_one := by simpa only [mass_add, mass_single, Set.mem_univ, if_true] using ht

/-- The actual extended valuation, evaluated on every Scott open. -/
theorem twoPoint_hat (m : ℕ) (hm : 2 ≤ m) (u v : ℝ)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (ht : u + v ≤ 1) (U : ScottOpen TwoPoint) :
    valuationExtension twoPoint_continuousDomain twoPoint_source m hm
      (twoPoint_simple u v hu hv ht).toVSub U =
      ENNReal.ofReal (((m : ℝ) / (m + 1)) *
        ((if TwoPoint.a ∈ U then u * flag ((m : ℝ)⁻¹ < u) else 0) +
          (if TwoPoint.b ∈ U then v * flag ((m : ℝ)⁻¹ < v) else 0))) := by
  rw [finite_agreement_coeff, SimpleCoeff.toVSub_apply]
  change ENNReal.ofReal (mass
    (sourceH monotone_id (id_separates (D := TwoPoint)) chainHeight (m : ℝ)
      (Finsupp.single TwoPoint.a u + Finsupp.single TwoPoint.b v)) U) = _
  rw [twoPoint_source_h, mass_smul, mass_add, mass_single, mass_single]
  rfl

theorem valuation_zero_least (nu : VSub TwoPoint) : (0 : VSub TwoPoint) ≤ nu :=
  fun _ => bot_le

/-! ## rem:strict-test (source lines 1072-1079) -/

abbrev Singleton := Fin 1

theorem singleton_height (x : Singleton) : chainHeight x = 1 := by
  rw [chainHeight_linear]
  fin_cases x
  simp [Fin.univ_succ, Finset.filter_insert]

theorem singleton_covers (x : Singleton) : covers x = ∅ := by
  ext y
  fin_cases x <;> fin_cases y <;> simp [covers, CovBy]

theorem singleton_edgeCount : edgeCount (P := Singleton) = 0 := by
  simp [edgeCount, singleton_covers]

theorem singleton_h (m r : ℝ) :
    sourceH monotone_id (id_separates (D := Singleton)) chainHeight m (Finsupp.single 0 r) =
      Finsupp.single 0 (m / (m + 1) * r * flag (m⁻¹ < r)) := by
  rw [id_sourceH_eq_coordinates]
  unfold rawH rawSelectedT rawT
  rw [headCoeff_univ]
  have hexit (A : Set Singleton) (u : Singleton) : exitUpper A u = ∅ := by
    ext x
    fin_cases u <;> fin_cases x <;> simp [exitUpper, CovBy, Fin.exists_fin_succ]
  apply Finsupp.ext
  intro x
  fin_cases x
  by_cases h : m⁻¹ < r <;>
    simp [Fin.sum_univ_succ, correctionCoeff, boundary, hexit, singleton_covers,
      fixedScale, singleton_edgeCount, LocalMap.threshold, singleton_height,
      mem_selected, mass_single, upperFiber, flag, h]

theorem singleton_strict_threshold (m : ℝ) :
    sourceH monotone_id (id_separates (D := Singleton)) chainHeight m
      (Finsupp.single 0 m⁻¹) = 0 := by
  rw [singleton_h]
  simp [flag]

theorem singleton_below_threshold {m c : ℝ} (hm : 2 ≤ m) (hc : c < 1) :
    sourceH monotone_id (id_separates (D := Singleton)) chainHeight m
      (Finsupp.single 0 (c / m)) = 0 := by
  have hm0 : 0 < m := by linarith
  have hlt : c / m < m⁻¹ := by simpa [one_div] using div_lt_div_of_pos_right hc hm0
  rw [singleton_h]
  simp [flag, not_lt_of_ge hlt.le]

noncomputable def singletonClosed (m r : ℝ) : ℝ := m / (m + 1) * r * flag (m⁻¹ ≤ r)

theorem singleton_closed_jump {m : ℝ} (hm : 2 ≤ m) :
    0 < singletonClosed m m⁻¹ ∧ ∀ c : ℝ, c < 1 → singletonClosed m (c / m) = 0 := by
  constructor
  · simp only [singletonClosed, flag, le_refl, if_true, mul_one]
    positivity
  · intro c hc
    have hm0 : 0 < m := by linarith
    have hlt : c / m < m⁻¹ := by simpa [one_div] using div_lt_div_of_pos_right hc hm0
    simp [singletonClosed, flag, not_le_of_gt hlt]

noncomputable def singleton_simple (r : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    SimpleCoeff Singleton where
  coeff := Finsupp.single 0 r
  nonneg x := by fin_cases x; simpa using hr0
  total_le_one := by simpa only [mass_single, Set.mem_univ, if_true] using hr1

noncomputable def singletonThreshold (m : ℝ) (hm : 2 ≤ m) : SimpleCoeff Singleton :=
  singleton_simple m⁻¹ (by
    have hm0 : 0 < m := by linarith
    exact (inv_pos.mpr hm0).le) (by
    have hm0 : 0 < m := by linarith
    simpa only [one_div] using (div_le_one hm0).mpr (show 1 ≤ m by linarith))

noncomputable def singletonMass (ν : VSub Singleton) : ℝ :=
  (ν ScottOpen.univ).toReal

theorem singletonMass_le_one (ν : VSub Singleton) : singletonMass ν ≤ 1 := by
  simpa only [singletonMass, ENNReal.toReal_one] using
    ENNReal.toReal_mono ENNReal.one_ne_top (ν.value_le_one ScottOpen.univ)

theorem singletonMass_monotone : Monotone singletonMass := by
  intro ν ρ h
  exact ENNReal.toReal_mono
    (ne_of_lt ((ρ.value_le_one ScottOpen.univ).trans_lt ENNReal.one_lt_top))
    (h ScottOpen.univ)

@[simp] theorem singletonThreshold_mass (m : ℝ) (hm : 2 ≤ m) :
    singletonMass (singletonThreshold m hm).toVSub = m⁻¹ := by
  rw [singletonMass, SimpleCoeff.toVSub_toReal]
  simp [singletonThreshold, singleton_simple]

theorem singletonScale_nonneg {m : ℝ} (hm : 2 ≤ m) : 0 ≤ m / (m + 1) := by
  have hm0 : 0 ≤ m := by linarith
  positivity

theorem singletonScale_le_one {m : ℝ} (hm : 2 ≤ m) : m / (m + 1) ≤ 1 := by
  exact (div_le_one (by linarith)).mpr (by linarith)

noncomputable def singletonRepr (ν : VSub Singleton) : SimpleCoeff Singleton :=
  singleton_simple (singletonMass ν) ENNReal.toReal_nonneg (singletonMass_le_one ν)

/-- The non-strict modification is a concrete subprobability valuation map. -/
noncomputable def singletonClosedMap (m : ℝ) (hm : 2 ≤ m) (ν : VSub Singleton) :
    VSub Singleton :=
  if m⁻¹ ≤ singletonMass ν then
    (dilate (singletonRepr ν) (m / (m + 1)) (singletonScale_nonneg hm)
      (singletonScale_le_one hm)).toVSub
  else 0

theorem singletonClosedMap_apply (m : ℝ) (hm : 2 ≤ m) (ν : VSub Singleton)
    (U : ScottOpen Singleton) : singletonClosedMap m hm ν U =
      ENNReal.ofReal (if (0 : Singleton) ∈ U then singletonClosed m (singletonMass ν) else 0) := by
  by_cases h : m⁻¹ ≤ singletonMass ν
  · rw [singletonClosedMap, if_pos h, dilate_apply]
    by_cases hU : (0 : Singleton) ∈ U <;>
      simp [singletonRepr, singleton_simple, singletonClosed, flag, h, mass_single, hU]
  · simp [singletonClosedMap, singletonClosed, flag, h]

theorem singletonClosedMap_eq_zero {m : ℝ} (hm : 2 ≤ m) (ν : VSub Singleton)
    (hν : singletonMass ν < m⁻¹) : singletonClosedMap m hm ν = 0 := by
  simp [singletonClosedMap, not_le_of_gt hν]

theorem singleton_beta_mass {m : ℝ} (hm : 2 ≤ m)
    (a : ApproxParam (finite_idFS Singleton)) :
    singletonMass (beta (finite_idFS Singleton) (singletonThreshold m hm) a) =
      a.2.val * m⁻¹ := by
  rw [singletonMass, beta, scaledAtomic_apply]
  simp only [singletonThreshold, singleton_simple, integral_single, ScottOpen.mem_univ, if_true]
  have hm0 : 0 < m := by linarith
  rw [ENNReal.toReal_ofReal (mul_nonneg (inv_nonneg.mpr hm0.le) a.2.property.1.le)]
  ring

theorem singleton_beta_eq_dilate {m : ℝ} (hm : 2 ≤ m)
    (a : ApproxParam (finite_idFS Singleton)) :
    beta (finite_idFS Singleton) (singletonThreshold m hm) a =
      (dilate (singletonThreshold m hm) a.2.val a.2.property.1.le a.2.property.2.le).toVSub := by
  apply VSub.ext
  intro U
  rw [beta, scaledAtomic_apply, dilate_apply]
  have hx : a.1.val (a.1.val (0 : Singleton)) = 0 := Subsingleton.elim _ _
  simp only [singletonThreshold, singleton_simple, integral_single, mass_single, hx]
  by_cases hU : (0 : Singleton) ∈ U <;> simp [hU, mul_comm]

theorem singleton_beta_below_threshold {m : ℝ} (hm : 2 ≤ m)
    (a : ApproxParam (finite_idFS Singleton)) :
    singletonMass (beta (finite_idFS Singleton) (singletonThreshold m hm) a) < m⁻¹ := by
  rw [singleton_beta_mass hm]
  have hm0 : 0 < m := by linarith
  exact mul_lt_of_lt_one_left (inv_pos.mpr hm0) a.2.property.2

/-- A directed-supremum failure in the genuine continuous-valuation dcpo. -/
theorem singleton_closed_not_scottContinuous {m : ℝ} (hm : 2 ≤ m) :
    ¬ ScottContinuous (singletonClosedMap m hm) := by
  intro hF
  have hs := hF.2 (beta_directed (finite_idFS Singleton) (singletonThreshold m hm))
    (beta_isSup (finite_idFS Singleton) (singletonThreshold m hm))
  have hle : singletonClosedMap m hm (singletonThreshold m hm).toVSub ≤ 0 := by
    apply hs.2
    rintro _ ⟨ν, ⟨a, rfl⟩, rfl⟩
    exact le_of_eq (singletonClosedMap_eq_zero hm _ (singleton_beta_below_threshold hm a))
  have hmass := hle ScottOpen.univ
  rw [singletonClosedMap_apply, singletonThreshold_mass] at hmass
  have hpos : 0 < ENNReal.ofReal (singletonClosed m m⁻¹) :=
    ENNReal.ofReal_pos.mpr (singleton_closed_jump hm).1
  exact hpos.not_ge (by simpa using hmass)

theorem singleton_closed_basis_isSup {m : ℝ} (hm : 2 ≤ m) :
    IsSup ((singletonClosedMap m hm) ''
      {ν : VSub Singleton | ν ≪ (singletonThreshold m hm).toVSub}) 0 := by
  have hz : (0 : VSub Singleton) ≪ (singletonThreshold m hm).toVSub := by
    intro A s hA hs hle
    obtain ⟨ν, hν⟩ := hA.1
    exact ⟨ν, hν, fun U => bot_le⟩
  have hzero (ν : VSub Singleton) (hν : ν ≪ (singletonThreshold m hm).toVSub) :
      singletonClosedMap m hm ν = 0 := by
    obtain ⟨a, hle⟩ := wayBelow_simple_beta (finite_idFS Singleton) (singletonThreshold m hm) hν
    exact singletonClosedMap_eq_zero hm ν
      ((singletonMass_monotone hle).trans_lt (singleton_beta_below_threshold hm a))
  refine ⟨?_, ?_⟩
  · rintro _ ⟨ν, hν, rfl⟩
    exact le_of_eq (hzero ν hν)
  · intro ρ hρ
    have h := hρ (Set.mem_image_of_mem (singletonClosedMap m hm) hz)
    simpa only [hzero 0 hz] using h

theorem singletonClosed_monotone {m : ℝ} (hm : 2 ≤ m) : Monotone (singletonClosed m) := by
  intro r s hrs
  by_cases hr : m⁻¹ ≤ r
  · have hs : m⁻¹ ≤ s := hr.trans hrs
    simp only [singletonClosed, flag, if_pos hr, if_pos hs, mul_one]
    exact mul_le_mul_of_nonneg_left hrs (singletonScale_nonneg hm)
  · by_cases hs : m⁻¹ ≤ s
    · have hm0 : 0 < m := by linarith
      have hs0 : 0 ≤ s := (inv_pos.mpr hm0).le.trans hs
      simpa only [singletonClosed, flag, if_neg hr, if_pos hs, mul_zero, mul_one] using
        mul_nonneg (singletonScale_nonneg hm) hs0
    · simp [singletonClosed, flag, hr, hs]

theorem singletonClosedMap_monotone {m : ℝ} (hm : 2 ≤ m) :
    Monotone (singletonClosedMap m hm) := by
  intro ν ρ h U
  rw [singletonClosedMap_apply, singletonClosedMap_apply]
  apply ENNReal.ofReal_le_ofReal
  by_cases hU : (0 : Singleton) ∈ U
  · simp only [if_pos hU]
    exact singletonClosed_monotone hm (singletonMass_monotone h)
  · simp only [if_neg hU, le_refl]

noncomputable def singletonClosedBasisMap (m : ℝ) (hm : 2 ≤ m) :
    simpleBasis Singleton → VSub Singleton := fun b => singletonClosedMap m hm b.val

theorem singletonClosedBasisMap_monotone (m : ℝ) (hm : 2 ≤ m) :
    Monotone (singletonClosedBasisMap m hm) :=
  fun _ _ h => singletonClosedMap_monotone hm h

noncomputable def singletonClosedExtension (m : ℝ) (hm : 2 ≤ m) :
    VSub Singleton → VSub Singleton :=
  basisExtension VSub.isDcpo (lem_simple_basis (finite_idFS Singleton).continuousDomain).2
    (singletonClosedBasisMap m hm) (singletonClosedBasisMap_monotone m hm)

/-- The same closed-test modification has zero basis extension at the jump. -/
theorem singleton_closed_basisExtension_zero {m : ℝ} (hm : 2 ≤ m) :
    singletonClosedExtension m hm (singletonThreshold m hm).toVSub = 0 := by
  have hs := basisExtension_isSup VSub.isDcpo
    (lem_simple_basis (finite_idFS Singleton).continuousDomain).2
    (singletonClosedBasisMap m hm) (singletonClosedBasisMap_monotone m hm)
    (singletonThreshold m hm).toVSub
  have hvalues : basisValues (singletonClosedBasisMap m hm) (singletonThreshold m hm).toVSub =
      singletonClosedMap m hm '' {ν : VSub Singleton | ν ≪ (singletonThreshold m hm).toVSub} := by
    apply Set.ext
    intro ν
    constructor
    · rintro ⟨b, hb, rfl⟩
      exact ⟨b.val, hb, rfl⟩
    · rintro ⟨β, hβ, rfl⟩
      exact ⟨⟨β, finite_simple β⟩, hβ, rfl⟩
  rw [hvalues] at hs
  exact hs.unique (singleton_closed_basis_isSup hm)

/-! ## Public interfaces for the remaining three source items -/

theorem real_parameter {m : ℕ} (hm : 2 ≤ m) : (2 : ℝ) ≤ m := by
  exact_mod_cast hm

theorem fin_maxHeight (n : ℕ) : maxHeight (Fin n) = n := by
  apply le_antisymm
  · apply Finset.sup_le
    intro u hu
    rw [fin_chainHeight]
    exact Nat.succ_le_of_lt u.isLt
  · cases n with
    | zero => exact Nat.zero_le _
    | succ k =>
      simpa only [fin_chainHeight, Fin.val_last] using chainHeight_le_maxHeight (Fin.last k)

/-- `rem:covers`, lines 987-994: literal chain counts, unchanged height,
and the corresponding denominator bounds. No map comparison is claimed. -/
theorem rem_covers (n size m H : ℕ) :
    edgeCount (P := Fin n) = n - 1 ∧
      strictPairCount (Fin n) = n * (n - 1) / 2 ∧
      maxHeight (Fin n) = n ∧
      (∀ u v : Fin n, Relation.ReflTransGen (fun x y : Fin n => x ⋖ y) u v ↔ u ≤ v) ∧
      (∀ u : Fin n, LocalMap.threshold chainHeight (m : ℝ) u = ((m : ℝ) ^ (u.val + 1))⁻¹) ∧
      m + edgeCount (P := Fin n) + 1 ≤ m + strictPairCount (Fin n) + 1 ∧
      gridDenominator size m (edgeCount (P := Fin n)) H ≤
        gridDenominator size m (strictPairCount (Fin n)) H :=
  ⟨fin_edgeCount n, fin_strictPairCount n, fin_maxHeight n, fin_cover_generates_order,
    fun u => fin_threshold_height u m, covers_denominator_le n m,
    covers_gridDenominator_le n size m H⟩

noncomputable def twoPoint_printed (m : ℕ) (hm : 2 ≤ m) (u v : ℝ)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (ht : u + v ≤ 1) : SimpleCoeff TwoPoint :=
  dilate (twoPoint_simple (u * flag ((m : ℝ)⁻¹ < u)) (v * flag ((m : ℝ)⁻¹ < v))
    (mul_nonneg hu (flag_nonneg _)) (mul_nonneg hv (flag_nonneg _)) (by
      have huf : u * flag ((m : ℝ)⁻¹ < u) ≤ u := by
        by_cases h : (m : ℝ)⁻¹ < u <;> simp [flag, h, hu]
      have hvf : v * flag ((m : ℝ)⁻¹ < v) ≤ v := by
        by_cases h : (m : ℝ)⁻¹ < v <;> simp [flag, h, hv]
      exact (add_le_add huf hvf).trans ht))
    ((m : ℝ) / (m + 1)) (singletonScale_nonneg (real_parameter hm))
    (singletonScale_le_one (real_parameter hm))

theorem twoPoint_printed_coeff (m : ℕ) (hm : 2 ≤ m) (u v : ℝ)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (ht : u + v ≤ 1) :
    (twoPoint_printed m hm u v hu hv ht).coeff = ((m : ℝ) / (m + 1)) •
      (Finsupp.single TwoPoint.a (u * flag ((m : ℝ)⁻¹ < u)) +
        Finsupp.single TwoPoint.b (v * flag ((m : ℝ)⁻¹ < v))) := rfl

/-- The displayed hatted formula as equality of actual continuous valuations. -/
theorem twoPoint_hat_eq_printed (m : ℕ) (hm : 2 ≤ m) (u v : ℝ)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (ht : u + v ≤ 1) :
    valuationExtension twoPoint_continuousDomain twoPoint_source m hm
      (twoPoint_simple u v hu hv ht).toVSub = (twoPoint_printed m hm u v hu hv ht).toVSub := by
  apply VSub.ext
  intro U
  rw [twoPoint_hat, SimpleCoeff.toVSub_apply, twoPoint_printed_coeff,
    mass_smul, mass_add, mass_single, mass_single]
  rfl

/-- `ex:unpointed`, lines 1218-1233, including its actual basis extension. -/
theorem ex_unpointed (m : ℕ) (hm : 2 ≤ m) (u v : ℝ)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (ht : u + v ≤ 1) :
    IsFSDomain TwoPoint ∧ (¬ ∃ x : TwoPoint, ∀ y, x ≤ y) ∧
      (∀ x : TwoPoint, sourceSlice id Finset.univ x = {x}) ∧
      (∀ p q : SourcePoset id (Finset.univ : Finset TwoPoint), p ≤ q ↔ p = q) ∧
      maxHeight (SourcePoset id (Finset.univ : Finset TwoPoint)) = 1 ∧
      edgeCount (P := SourcePoset id (Finset.univ : Finset TwoPoint)) = 0 ∧
      (∀ p : SourcePoset id (Finset.univ : Finset TwoPoint),
        LocalMap.threshold chainHeight (m : ℝ) p = (m : ℝ)⁻¹) ∧
      valuationExtension twoPoint_continuousDomain twoPoint_source m hm
        (twoPoint_simple u v hu hv ht).toVSub = (twoPoint_printed m hm u v hu hv ht).toVSub ∧
      IsLeast (0 : VSub TwoPoint) :=
  ⟨twoPoint_isFSDomain, twoPoint_no_least, twoPoint_sourceSlice, twoPoint_source_antichain,
    (twoPoint_source_parameters m).1, (twoPoint_source_parameters m).2.1,
    (twoPoint_source_parameters m).2.2, twoPoint_hat_eq_printed m hm u v hu hv ht,
    valuation_zero_least⟩

noncomputable def singleton_source : SourceData Singleton :=
  ⟨⟨id, scottContinuous_id⟩, Finset.univ, id_separates⟩

theorem singleton_hat (m : ℕ) (hm : 2 ≤ m) (r : ℝ)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (U : ScottOpen Singleton) :
    valuationExtension (finite_idFS Singleton).continuousDomain singleton_source m hm
      (singleton_simple r hr0 hr1).toVSub U =
      ENNReal.ofReal (if (0 : Singleton) ∈ U then
        (m : ℝ) / (m + 1) * r * flag ((m : ℝ)⁻¹ < r) else 0) := by
  rw [finite_agreement_coeff, SimpleCoeff.toVSub_apply]
  change ENNReal.ofReal (mass
    (sourceH monotone_id (id_separates (D := Singleton)) chainHeight (m : ℝ)
      (Finsupp.single 0 r)) U) = _
  rw [singleton_h, mass_single]
  rfl

noncomputable def singletonPath (m : ℝ) (hm : 2 ≤ m)
    (c : {c : ℝ // 0 < c ∧ c < 1}) : VSub Singleton :=
  (dilate (singletonThreshold m hm) c.val c.property.1.le c.property.2.le).toVSub

theorem singletonPath_apply (m : ℝ) (hm : 2 ≤ m)
    (c : {c : ℝ // 0 < c ∧ c < 1}) (U : ScottOpen Singleton) :
    singletonPath m hm c U = ENNReal.ofReal (if (0 : Singleton) ∈ U then c.val / m else 0) := by
  rw [singletonPath, dilate_apply]
  simp only [singletonThreshold, singleton_simple, mass_single]
  by_cases h : (0 : Singleton) ∈ U <;> simp [h, div_eq_mul_inv]

def singletonParam (c : {c : ℝ // 0 < c ∧ c < 1}) : ApproxParam (finite_idFS Singleton) :=
  (⟨⟨id, scottContinuous_id⟩, rfl⟩, c)

theorem singletonPath_range (m : ℝ) (hm : 2 ≤ m) :
    Set.range (singletonPath m hm) = Set.range (beta (finite_idFS Singleton) (singletonThreshold m hm)) := by
  apply Set.Subset.antisymm
  · rintro _ ⟨c, rfl⟩
    exact ⟨singletonParam c, singleton_beta_eq_dilate hm (singletonParam c)⟩
  · rintro _ ⟨a, rfl⟩
    exact ⟨a.2, (singleton_beta_eq_dilate hm a).symm⟩

theorem singletonPath_directed (m : ℝ) (hm : 2 ≤ m) :
    DirectedSet (Set.range (singletonPath m hm)) := by
  rw [singletonPath_range]
  exact beta_directed (finite_idFS Singleton) (singletonThreshold m hm)

theorem singletonPath_isSup (m : ℝ) (hm : 2 ≤ m) :
    IsSup (Set.range (singletonPath m hm)) (singletonThreshold m hm).toVSub := by
  rw [singletonPath_range]
  exact beta_isSup (finite_idFS Singleton) (singletonThreshold m hm)

theorem singletonPath_monotone (m : ℝ) (hm : 2 ≤ m) : Monotone (singletonPath m hm) := by
  intro c d h U
  rw [singletonPath_apply, singletonPath_apply]
  apply ENNReal.ofReal_le_ofReal
  by_cases hU : (0 : Singleton) ∈ U
  · simp only [if_pos hU]
    exact div_le_div_of_nonneg_right h (by linarith)
  · simp only [if_neg hU, le_refl]

theorem singletonPath_closed_zero (m : ℝ) (hm : 2 ≤ m)
    (c : {c : ℝ // 0 < c ∧ c < 1}) :
    singletonClosedMap m hm (singletonPath m hm c) = 0 := by
  have he : singletonPath m hm c =
      beta (finite_idFS Singleton) (singletonThreshold m hm) (singletonParam c) :=
    (singleton_beta_eq_dilate hm (singletonParam c)).symm
  rw [he]
  exact singletonClosedMap_eq_zero hm _ (singleton_beta_below_threshold hm (singletonParam c))

theorem singleton_hat_threshold_zero (m : ℕ) (hm : 2 ≤ m) :
    valuationExtension (finite_idFS Singleton).continuousDomain singleton_source m hm
      (singletonThreshold m (real_parameter hm)).toVSub = 0 := by
  rw [finite_agreement_coeff]
  apply VSub.ext
  intro U
  rw [SimpleCoeff.toVSub_apply]
  change ENNReal.ofReal (mass
    (sourceH monotone_id (id_separates (D := Singleton)) chainHeight (m : ℝ)
      (Finsupp.single 0 (m : ℝ)⁻¹)) U) = _
  rw [singleton_strict_threshold]
  simp

theorem singletonPath_hat_zero (m : ℕ) (hm : 2 ≤ m)
    (c : {c : ℝ // 0 < c ∧ c < 1}) :
    valuationExtension (finite_idFS Singleton).continuousDomain singleton_source m hm
      (singletonPath m (real_parameter hm) c) = 0 := by
  apply le_antisymm
  · have hinput := (singletonPath_isSup m (real_parameter hm)).1 (Set.mem_range_self c)
    have h := (valuationExtension (finite_idFS Singleton).continuousDomain singleton_source m hm).continuous.monotone hinput
    simpa only [singleton_hat_threshold_zero m hm] using h
  · exact fun U => bot_le

theorem singletonClosedMap_threshold_pos (m : ℝ) (hm : 2 ≤ m) :
    0 < singletonClosedMap m hm (singletonThreshold m hm).toVSub ScottOpen.univ := by
  rw [singletonClosedMap_apply, singletonThreshold_mass]
  simpa only [ScottOpen.mem_univ, if_true] using
    ENNReal.ofReal_pos.mpr (singleton_closed_jump hm).1

/-- `rem:strict-test`, lines 1072-1079: a literal scalar-Dirac path in the
valuation dcpo, its zero strict-test images, and the closed-test failure. -/
theorem rem_strict_test (m : ℕ) (hm : 2 ≤ m) :
    (∀ r : ℝ, sourceH monotone_id (id_separates (D := Singleton)) chainHeight (m : ℝ)
      (Finsupp.single 0 r) = Finsupp.single 0
        ((m : ℝ) / (m + 1) * r * flag ((m : ℝ)⁻¹ < r))) ∧
      Monotone (singletonPath m (real_parameter hm)) ∧
      DirectedSet (Set.range (singletonPath m (real_parameter hm))) ∧
      IsSup (Set.range (singletonPath m (real_parameter hm)))
        (singletonThreshold m (real_parameter hm)).toVSub ∧
      (∀ c : {c : ℝ // 0 < c ∧ c < 1},
        valuationExtension (finite_idFS Singleton).continuousDomain singleton_source m hm
          (singletonPath m (real_parameter hm) c) = 0) ∧
      (∀ c : {c : ℝ // 0 < c ∧ c < 1},
        singletonClosedMap m (real_parameter hm) (singletonPath m (real_parameter hm) c) = 0) ∧
      valuationExtension (finite_idFS Singleton).continuousDomain singleton_source m hm
        (singletonThreshold m (real_parameter hm)).toVSub = 0 ∧
      0 < singletonClosedMap m (real_parameter hm)
        (singletonThreshold m (real_parameter hm)).toVSub ScottOpen.univ ∧
      (¬ ScottContinuous (singletonClosedMap m (real_parameter hm))) ∧
      singletonClosedExtension m (real_parameter hm)
        (singletonThreshold m (real_parameter hm)).toVSub = 0 :=
  ⟨singleton_h m, singletonPath_monotone m (real_parameter hm),
    singletonPath_directed m (real_parameter hm),
    singletonPath_isSup m (real_parameter hm), singletonPath_hat_zero m hm,
    singletonPath_closed_zero m (real_parameter hm),
    singleton_hat_threshold_zero m hm, singletonClosedMap_threshold_pos m (real_parameter hm),
    singleton_closed_not_scottContinuous (real_parameter hm),
    singleton_closed_basisExtension_zero (real_parameter hm)⟩

end FiniteSeparation.Examples
