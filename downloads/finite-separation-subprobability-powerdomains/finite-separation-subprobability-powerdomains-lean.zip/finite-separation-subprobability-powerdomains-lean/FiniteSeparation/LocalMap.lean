import FiniteSeparation.Atomic
import FiniteSeparation.Correction

/-!
# The printed local coefficients

Source SHA256: `2d544eb99266f3a6c842718e51b8a8ecd304c47aa1da5dd2393193208ab329ff`.
The coefficients below implement the expanded T_A formula (lines 667-674),
followed by threshold selection and a fixed scalar. They do not use an
erosion map, a finite-factorization substitute, or a separation certificate.
-/

set_option autoImplicit false

universe u v

namespace FiniteSeparation.LocalMap

open Set PointAssignment
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D] {P : Type v} [PartialOrder P] [Fintype P]

noncomputable def headCoeff (pi : D → P) (g : D → D) (A : Finset P)
    (p : Coeff D) : Coeff D :=
  ∑ x ∈ p.support, Finsupp.single (g x) (if pi x ∈ A then p x else 0)

noncomputable def tauCoeff (a : P → D) (t : P → ℝ) (A : Finset P) : Coeff D :=
  ∑ u ∈ A, Finsupp.single (a u) (∑ v ∈ covers u ∩ A, t v)

/-- The expanded printed T_A, with duplicate output points added, not removed. -/
noncomputable def rawT (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (A : Finset P) (p : Coeff D) : Coeff D :=
  headCoeff pi g A p + ∑ u ∈ A, Finsupp.single (a u) (correctionCoeff pi t p A u)

noncomputable def rawSelectedT (pi : D → P) (g : D → D) (a : P → D)
    (t : P → ℝ) (p : Coeff D) : Coeff D :=
  rawT pi g a t (selected pi t p) p

noncomputable def rawH (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (scale : ℝ) (p : Coeff D) : Coeff D :=
  scale • rawSelectedT pi g a t p

omit [PartialOrder D] [PartialOrder P] [Fintype P] in
theorem headCoeff_nonneg (pi : D → P) (g : D → D) (A : Finset P)
    {p : Coeff D} (hp : Nonneg p) : Nonneg (headCoeff pi g A p) := by
  have h : (0 : Coeff D) ≤ headCoeff pi g A p := by
    apply Finset.sum_nonneg
    intro x hx
    apply Finsupp.single_nonneg.mpr
    split_ifs <;> first | exact hp x | exact le_rfl
  exact fun x => h x

theorem rawT_nonneg (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) (A : Finset P) {p : Coeff D} (hp : Nonneg p) :
    Nonneg (rawT pi g a t A p) := by
  have h : (0 : Coeff D) ≤ ∑ u ∈ A,
      Finsupp.single (a u) (correctionCoeff pi t p A u) := by
    exact Finset.sum_nonneg fun u _ =>
      Finsupp.single_nonneg.mpr (correctionCoeff_nonneg pi t ht hp A u)
  exact fun x => add_nonneg (headCoeff_nonneg pi g A hp x) (h x)

theorem rawH_nonneg (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) {scale : ℝ} (hscale : 0 ≤ scale)
    {p : Coeff D} (hp : Nonneg p) : Nonneg (rawH pi g a t scale p) := by
  intro x
  exact mul_nonneg hscale (rawT_nonneg pi g a t ht _ hp x)

omit [PartialOrder P] [Fintype P] in
theorem mass_headCoeff (pi : D → P) (g : D → D) (A : Finset P)
    (p : Coeff D) (U : Set D) :
    mass (headCoeff pi g A p) U =
      integral p (fun x => flag (pi x ∈ A ∧ g x ∈ U)) := by
  rw [headCoeff, mass_finset_sum, integral_eq_sum]
  apply Finset.sum_congr rfl
  intro x hx
  by_cases hxA : pi x ∈ A <;> by_cases hxU : g x ∈ U <;>
    simp [mass_single, flag, hxA, hxU]

theorem mass_tauCoeff (a : P → D) (t : P → ℝ) (A : Finset P) (U : Set D) :
    mass (tauCoeff a t A) U =
      ∑ u ∈ A, if a u ∈ U then (∑ v ∈ covers u ∩ A, t v) else 0 := by
  simp only [tauCoeff, mass_finset_sum, mass_single]

theorem mass_rawT (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (A : Finset P) (p : Coeff D) (U : Set D) :
    mass (rawT pi g a t A p) U =
      integral p (fun x => flag (pi x ∈ A ∧ g x ∈ U)) +
        ∑ u ∈ A, if a u ∈ U then correctionCoeff pi t p A u else 0 := by
  simp only [rawT, mass_add, mass_headCoeff, mass_finset_sum, mass_single]

omit [Fintype P] in
theorem integral_correction (pi : D → P) (a : P → D) (A : Finset P)
    (p : Coeff D) (U : Set D) (u : P) :
    integral p (fun x => correction pi a A U x u) =
      if u ∈ A ∧ a u ∈ U then mass p (boundary pi A u) else 0 := by
  by_cases huA : u ∈ A <;> by_cases huU : a u ∈ U <;>
    simp [correction, flag, huA, huU, mass, integral_eq_sum, boundary]

theorem integral_xiObservation (pi : D → P) (g : D → D) (a : P → D)
    (A : Finset P) (p : Coeff D) (U : Set D) :
    integral p (xiObservation pi g a (A : Set P) U) =
      integral p (fun x => flag (pi x ∈ A ∧ g x ∈ U)) +
        ∑ u ∈ A, if a u ∈ U then mass p (boundary pi A u) else 0 := by
  unfold xiObservation
  rw [integral_add_weight, integral_sum_weight]
  congr 1
  simp_rw [integral_correction]
  simp only [ite_and]
  exact Finset.sum_ite_mem_eq A _

/-- The linear observation identity used for the fixed-A monotone test. -/
theorem mass_rawT_eq_integral (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (A : Finset P) (p : Coeff D) (U : Set D) :
    mass (rawT pi g a t A p) U =
      integral p (xiObservation pi g a (A : Set P) U) + mass (tauCoeff a t A) U := by
  rw [mass_rawT, integral_xiObservation, mass_tauCoeff]
  have h : (∑ u ∈ A, if a u ∈ U then correctionCoeff pi t p A u else 0) =
      (∑ u ∈ A, if a u ∈ U then mass p (boundary pi A u) else 0) +
        ∑ u ∈ A, if a u ∈ U then (∑ v ∈ covers u ∩ A, t v) else 0 := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro u hu
    by_cases huU : a u ∈ U <;> simp [correctionCoeff, huU]
  rw [h]
  ring

theorem rawT_fixedA_mono (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (A : Finset P) (hpi : Monotone pi) (hg : Monotone g)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u)
    (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub) (U : ScottOpen D) :
    mass (rawT pi g a t A p.coeff) U ≤ mass (rawT pi g a t A q.coeff) U := by
  rw [mass_rawT_eq_integral, mass_rawT_eq_integral]
  exact add_le_add (simple_integral_mono p q hpq _
    (xiObservation_scottOpen_monotone pi g a A U hpi hg hchosen)
    (xiObservation_nonneg pi g a A U)) le_rfl

theorem rawT_mono_subset (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) {p : Coeff D} (hp : Nonneg p)
    {A B : Finset P} (hAB : A ⊆ B)
    (hnew : ∀ v ∈ B \ A, mass p (upperFiber pi v) ≤ t v) (U : Set D) :
    mass (rawT pi g a t A p) U ≤ mass (rawT pi g a t B p) U := by
  rw [mass_rawT, mass_rawT]
  apply add_le_add
  · apply integral_mono_weight hp
    intro x
    exact flag_mono (fun h => ⟨hAB h.1, h.2⟩)
  · calc
      _ ≤ ∑ u ∈ A, if a u ∈ U then correctionCoeff pi t p B u else 0 := by
        apply Finset.sum_le_sum
        intro u hu
        split_ifs
        · exact correctionCoeff_mono_subset pi t hp hAB hnew u
        · exact le_rfl
      _ ≤ ∑ u ∈ B, if a u ∈ U then correctionCoeff pi t p B u else 0 := by
        apply Finset.sum_le_sum_of_subset_of_nonneg hAB
        intro u hu huA
        split_ifs
        · exact correctionCoeff_nonneg pi t ht hp B u
        · exact le_rfl

theorem simple_mass_mono_upper (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub)
    (V : Set D) (hV : IsUpperSet V) : mass p.coeff V ≤ mass q.coeff V := by
  apply simple_integral_mono p q hpq
  · intro x y hxy
    change flag (x ∈ V) ≤ flag (y ∈ V)
    exact flag_mono (hV hxy)
  · intro x
    change 0 ≤ flag (x ∈ V)
    exact flag_nonneg _

theorem selected_mono (pi : D → P) (t : P → ℝ) (hpi : Monotone pi)
    (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub) :
    selected pi t p.coeff ⊆ selected pi t q.coeff := by
  intro u hu
  apply (mem_selected pi t q.coeff u).mpr
  have hmass := simple_mass_mono_upper p q hpq (upperFiber pi u) (by
    intro x y hxy hx
    exact hx.trans (hpi hxy))
  exact ((mem_selected pi t p.coeff u).mp hu).trans_le hmass

theorem rawSelectedT_mono (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) (hpi : Monotone pi) (hg : Monotone g)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u)
    (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub) (U : ScottOpen D) :
    mass (rawSelectedT pi g a t p.coeff) U ≤
      mass (rawSelectedT pi g a t q.coeff) U := by
  exact (rawT_mono_subset pi g a t ht p.nonneg (selected_mono pi t hpi p q hpq)
    (fun v hv => not_selected_bound pi t p.coeff v (Finset.mem_sdiff.mp hv).2) U).trans
    (rawT_fixedA_mono pi g a t _ hpi hg hchosen p q hpq U)

theorem rawH_mono (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) (hpi : Monotone pi) (hg : Monotone g)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u)
    {scale : ℝ} (hscale : 0 ≤ scale)
    (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub) (U : ScottOpen D) :
    mass (rawH pi g a t scale p.coeff) U ≤ mass (rawH pi g a t scale q.coeff) U := by
  simp only [rawH, mass_smul]
  exact mul_le_mul_of_nonneg_left (rawSelectedT_mono pi g a t ht hpi hg hchosen p q hpq U)
    hscale

/-- Theta is the input mass moved by c, not a monotone choice of witnesses. -/
noncomputable def thetaMass (p : Coeff D) (c : D → D) (U : Set D) : ℝ :=
  mass p (c ⁻¹' U)

noncomputable def edgeCount : ℕ := ∑ u : P, (covers u).card

noncomputable def fixedScale (m : ℝ) : ℝ := m / (m + (edgeCount (P := P) : ℝ) + 1)

theorem thetaMass_nonneg {p : Coeff D} (hp : Nonneg p) (c : D → D) (U : Set D) :
    0 ≤ thetaMass p c U := mass_nonneg hp _

theorem thetaMass_le_input {p : Coeff D} (hp : Nonneg p) (c : D → D)
    (hc : ∀ x, c x ≤ x) (U : Set D) (hU : IsUpperSet U) :
    thetaMass p c U ≤ mass p U :=
  mass_mono_set hp (fun x hx => hU (hc x) hx)

omit [Fintype P] in
theorem principal_le_theta (pi : D → P) (a : P → D) (c : D → D)
    (hac : ∀ u x, u ≤ pi x → a u ≤ c x) {p : Coeff D} (hp : Nonneg p)
    (U : Set D) (hU : IsUpperSet U) {u : P} (huU : a u ∈ U) :
    mass p (upperFiber pi u) ≤ thetaMass p c U := by
  apply mass_mono_set hp
  intro x hx
  exact hU (hac u x hx) huU

theorem head_le_theta (pi : D → P) (g : D → D) (c : D → D)
    (hgc : ∀ x, g x ≤ c x) (A : Finset P) {p : Coeff D} (hp : Nonneg p)
    (U : Set D) (hU : IsUpperSet U) :
    mass (headCoeff pi g A p) U ≤ thetaMass p c U := by
  rw [mass_headCoeff]
  apply integral_mono_weight hp
  intro x
  change flag (pi x ∈ A ∧ g x ∈ U) ≤ flag (c x ∈ U)
  exact flag_mono (fun h => hU (hgc x) h.2)

theorem correction_total_le_theta (pi : D → P) (a : P → D) (c : D → D)
    (t : P → ℝ) {m : ℝ} (hm : 0 < m)
    (hcover : ∀ u v, u ⋖ v → t v ≤ t u / m)
    (hac : ∀ u x, u ≤ pi x → a u ≤ c x) {p : Coeff D} (hp : Nonneg p)
    (U : Set D) (hU : IsUpperSet U) :
    (∑ u ∈ selected pi t p,
      if a u ∈ U then correctionCoeff pi t p (selected pi t p) u else 0) ≤
        (edgeCount (P := P) : ℝ) / m * thetaMass p c U := by
  have htheta : 0 ≤ thetaMass p c U := thetaMass_nonneg hp c U
  have hterm (u : P) (hu : u ∈ selected pi t p) :
      (if a u ∈ U then correctionCoeff pi t p (selected pi t p) u else 0) ≤
        ((covers u).card : ℝ) * (thetaMass p c U / m) := by
    by_cases huU : a u ∈ U
    · rw [if_pos huU]
      have htu : t u ≤ thetaMass p c U :=
        ((mem_selected pi t p u).mp hu).le.trans (principal_le_theta pi a c hac hp U hU huU)
      calc
        _ ≤ ∑ v ∈ covers u, t v := correctionCoeff_bound pi t hp _
          (fun v hv => not_selected_bound pi t p v hv) u
        _ ≤ ∑ v ∈ covers u, thetaMass p c U / m := by
          apply Finset.sum_le_sum
          intro v hv
          exact (hcover u v (Finset.mem_filter.mp hv).2).trans
            (div_le_div_of_nonneg_right htu hm.le)
        _ = _ := by simp
    · rw [if_neg huU]
      positivity
  calc
    _ ≤ ∑ u ∈ selected pi t p, ((covers u).card : ℝ) * (thetaMass p c U / m) :=
      Finset.sum_le_sum (fun u hu => hterm u hu)
    _ ≤ ∑ u : P, ((covers u).card : ℝ) * (thetaMass p c U / m) := by
      apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      intro u hu huA
      positivity
    _ = _ := by
      rw [← Finset.sum_mul]
      simp only [edgeCount, Nat.cast_sum]
      ring

theorem rawSelectedT_le_theta (pi : D → P) (g : D → D) (a : P → D)
    (c : D → D) (t : P → ℝ) {m : ℝ} (hm : 0 < m)
    (hcover : ∀ u v, u ⋖ v → t v ≤ t u / m)
    (hgc : ∀ x, g x ≤ c x) (hac : ∀ u x, u ≤ pi x → a u ≤ c x)
    {p : Coeff D} (hp : Nonneg p) (U : Set D) (hU : IsUpperSet U) :
    mass (rawSelectedT pi g a t p) U ≤
      (1 + (edgeCount (P := P) : ℝ) / m) * thetaMass p c U := by
  rw [rawSelectedT, mass_rawT]
  have hhead := head_le_theta pi g c hgc (selected pi t p) hp U hU
  rw [mass_headCoeff] at hhead
  have hcorr := correction_total_le_theta pi a c t hm hcover hac hp U hU
  nlinarith

theorem fixedScale_nonneg {m : ℝ} (hm : 0 < m) : 0 ≤ fixedScale (P := P) m := by
  unfold fixedScale
  positivity

theorem rawH_theta_margin (pi : D → P) (g : D → D) (a : P → D)
    (c : D → D) (t : P → ℝ) {m : ℝ} (hm : 0 < m)
    (hcover : ∀ u v, u ⋖ v → t v ≤ t u / m)
    (hgc : ∀ x, g x ≤ c x) (hac : ∀ u x, u ≤ pi x → a u ≤ c x)
    {p : Coeff D} (hp : Nonneg p) (U : Set D) (hU : IsUpperSet U) :
    mass (rawH pi g a t (fixedScale (P := P) m) p) U ≤
      (1 - 1 / (m + (edgeCount (P := P) : ℝ) + 1)) * thetaMass p c U := by
  have hden : 0 < m + (edgeCount (P := P) : ℝ) + 1 := by positivity
  have halg : fixedScale (P := P) m * (1 + (edgeCount (P := P) : ℝ) / m) =
      1 - 1 / (m + (edgeCount (P := P) : ℝ) + 1) := by
    unfold fixedScale
    field_simp [ne_of_gt hm, ne_of_gt hden]
    ring
  simp only [rawH, mass_smul]
  calc
    _ ≤ fixedScale (P := P) m *
        ((1 + (edgeCount (P := P) : ℝ) / m) * thetaMass p c U) :=
      mul_le_mul_of_nonneg_left
        (rawSelectedT_le_theta pi g a c t hm hcover hgc hac hp U hU)
        (fixedScale_nonneg hm)
    _ = _ := by rw [← mul_assoc, halg]

theorem rawT_positive_index (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u) (A : Finset P) (p : Coeff D)
    (U : Set D) (hU : IsUpperSet U) (hpos : 0 < mass (rawT pi g a t A p) U) :
    ∃ u ∈ A, a u ∈ U := by
  by_contra hn
  have hout : ∀ u ∈ A, a u ∉ U := by simpa using hn
  have hhead : integral p (fun x => flag (pi x ∈ A ∧ g x ∈ U)) = 0 := by
    rw [integral_eq_sum]
    apply Finset.sum_eq_zero
    intro x hx
    have hxnot : ¬ (pi x ∈ A ∧ g x ∈ U) := by
      rintro ⟨hxA, hxU⟩
      exact hout (pi x) hxA (hU (hchosen x (pi x) le_rfl) hxU)
    simp [flag, hxnot]
  have hcorr : (∑ u ∈ A, if a u ∈ U then correctionCoeff pi t p A u else 0) = 0 :=
    Finset.sum_eq_zero (fun u hu => if_neg (hout u hu))
  rw [mass_rawT, hhead, hcorr] at hpos
  norm_num at hpos

theorem rawH_positive_theta (pi : D → P) (g : D → D) (a : P → D)
    (c : D → D) (t : P → ℝ) (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u)
    (hac : ∀ u x, u ≤ pi x → a u ≤ c x) {p : Coeff D} (hp : Nonneg p)
    {scale delta : ℝ} (hscale : 0 ≤ scale) (hlower : ∀ u, delta ≤ t u)
    (U : Set D) (hU : IsUpperSet U)
    (hpos : 0 < mass (rawH pi g a t scale p) U) : delta < thetaMass p c U := by
  have hT : 0 < mass (rawSelectedT pi g a t p) U := by
    have hmul : 0 < scale * mass (rawSelectedT pi g a t p) U := by
      simpa only [rawH, mass_smul] using hpos
    by_contra hn
    exact (not_lt_of_ge (mul_nonpos_of_nonneg_of_nonpos hscale (le_of_not_gt hn))) hmul
  obtain ⟨u, hu, huU⟩ := rawT_positive_index pi g a t hchosen (selected pi t p) p U hU hT
  exact (hlower u).trans_lt (((mem_selected pi t p u).mp hu).trans_le
    (principal_le_theta pi a c hac hp U hU huU))

/-- Numerical thresholds only. The actual finite-chain height is supplied externally. -/
noncomputable def threshold (ell : P → ℕ) (m : ℝ) (u : P) : ℝ := (m ^ ell u)⁻¹

omit [PartialOrder P] [Fintype P] in
theorem threshold_pos (ell : P → ℕ) {m : ℝ} (hm : 0 < m) (u : P) :
    0 < threshold ell m u := inv_pos.mpr (pow_pos hm _)

omit [Fintype P] in
theorem threshold_cover_ratio (ell : P → ℕ) (hell : StrictMono ell)
    {m : ℝ} (hm : 2 ≤ m) {u v : P} (huv : u ⋖ v) :
    threshold ell m v ≤ threshold ell m u / m := by
  have hm0 : 0 < m := by linarith
  have hp : m ^ (ell u + 1) ≤ m ^ ell v :=
    pow_le_pow_right₀ (by linarith) (Nat.succ_le_of_lt (hell huv.lt))
  calc
    _ ≤ (m ^ (ell u + 1))⁻¹ :=
      (inv_le_inv₀ (pow_pos hm0 _) (pow_pos hm0 _)).mpr hp
    _ = _ := by simp [threshold, pow_succ, mul_inv_rev, div_eq_mul_inv, mul_comm]

omit [PartialOrder P] [Fintype P] in
theorem threshold_lower (ell : P → ℕ) (H : ℕ) (hH : ∀ u, ell u ≤ H)
    {m : ℝ} (hm : 2 ≤ m) (u : P) : (m ^ H)⁻¹ ≤ threshold ell m u := by
  have hm0 : 0 < m := by linarith
  exact (inv_le_inv₀ (pow_pos hm0 _) (pow_pos hm0 _)).mpr
    (pow_le_pow_right₀ (by linarith) (hH u))

omit [PartialOrder P] [Fintype P] in
theorem threshold_le_inv (ell : P → ℕ) (hell : ∀ u, 0 < ell u)
    {m : ℝ} (hm : 2 ≤ m) (u : P) : threshold ell m u ≤ m⁻¹ := by
  have hm0 : 0 < m := by linarith
  apply (inv_le_inv₀ (pow_pos hm0 _) hm0).mpr
  simpa using (pow_le_pow_right₀ (by linarith : 1 ≤ m) (hell u) : m ^ 1 ≤ m ^ ell u)

theorem height_theta_margins (pi : D → P) (g : D → D) (a : P → D) (c : D → D)
    (hchosen : ∀ x u, pi x ≤ u → g x ≤ a u)
    (hgc : ∀ x, g x ≤ c x) (hac : ∀ u x, u ≤ pi x → a u ≤ c x)
    (ell : P → ℕ) (hell : StrictMono ell) (H : ℕ) (hH : ∀ u, ell u ≤ H)
    {m : ℝ} (hm : 2 ≤ m) {p : Coeff D} (hp : Nonneg p) (U : ScottOpen D) :
    mass (rawH pi g a (threshold ell m) (fixedScale (P := P) m) p) U ≤
        (1 - 1 / (m + (edgeCount (P := P) : ℝ) + 1)) * thetaMass p c U ∧
      (0 < mass (rawH pi g a (threshold ell m) (fixedScale (P := P) m) p) U →
        (m ^ H)⁻¹ < thetaMass p c U) := by
  have hm0 : 0 < m := by linarith
  exact ⟨rawH_theta_margin pi g a c (threshold ell m) hm0
      (fun _ _ h => threshold_cover_ratio ell hell hm h) hgc hac hp U U.upper,
    rawH_positive_theta pi g a c (threshold ell m) hchosen hac hp (fixedScale_nonneg hm0)
      (threshold_lower ell H hH hm) U U.upper⟩

noncomputable def atomicImage (g : D → D) (p : Coeff D) : Coeff D :=
  ∑ x ∈ p.support, Finsupp.single (g x) (p x)

omit [PartialOrder D] in
theorem atomicImage_nonneg (g : D → D) {p : Coeff D} (hp : Nonneg p) :
    Nonneg (atomicImage g p) := by
  have h : (0 : Coeff D) ≤ atomicImage g p :=
    Finset.sum_nonneg (fun x _ => Finsupp.single_nonneg.mpr (hp x))
  exact fun x => h x

omit [PartialOrder D] [PartialOrder P] [Fintype P] in
theorem headCoeff_eq_atomicImage (pi : D → P) (g : D → D) (A : Finset P)
    (p : Coeff D) (hsel : ∀ x ∈ p.support, pi x ∈ A) :
    headCoeff pi g A p = atomicImage g p := by
  apply Finset.sum_congr rfl
  intro x hx
  rw [if_pos (hsel x hx)]

omit [Fintype P] in
theorem atom_le_upperFiber (pi : D → P) {p : Coeff D} (hp : Nonneg p)
    (x : D) (hx : x ∈ p.support) : p x ≤ mass p (upperFiber pi (pi x)) := by
  rw [mass_eq_sum]
  have h := Finset.single_le_sum
    (fun y (_ : y ∈ p.support) => show 0 ≤ (if y ∈ upperFiber pi (pi x) then p y else 0) by
      split_ifs <;> first | exact hp y | exact le_rfl) hx
  simpa [upperFiber] using h

theorem support_selected_of_small_thresholds (pi : D → P) (t : P → ℝ)
    {p : Coeff D} (hp : Nonneg p) (hsmall : ∀ x ∈ p.support, t (pi x) < p x) :
    ∀ x ∈ p.support, pi x ∈ selected pi t p := by
  intro x hx
  exact (mem_selected pi t p (pi x)).mpr
    ((hsmall x hx).trans_le (atom_le_upperFiber pi hp x hx))

/-- Fixed-source lower approximation, before choosing a sufficiently large m. -/
theorem rawH_lower_of_selected (pi : D → P) (g : D → D) (a : P → D) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) {p : Coeff D} (hp : Nonneg p)
    (hsel : ∀ x ∈ p.support, pi x ∈ selected pi t p)
    {rate scale : ℝ} (hrate0 : 0 ≤ rate) (hrate : rate ≤ scale) (U : Set D) :
    rate * mass (atomicImage g p) U ≤ mass (rawH pi g a t scale p) U := by
  have hscale : 0 ≤ scale := hrate0.trans hrate
  have hsum : 0 ≤ ∑ u ∈ selected pi t p,
      if a u ∈ U then correctionCoeff pi t p (selected pi t p) u else 0 := by
    apply Finset.sum_nonneg
    intro u hu
    split_ifs
    · exact correctionCoeff_nonneg pi t ht hp _ u
    · exact le_rfl
  have hatom : 0 ≤ mass (atomicImage g p) U := mass_nonneg (atomicImage_nonneg g hp) U
  simp only [rawH, mass_smul, rawSelectedT, mass_rawT]
  rw [← mass_headCoeff, headCoeff_eq_atomicImage pi g _ p hsel]
  exact (mul_le_mul_of_nonneg_right hrate hatom).trans
    (mul_le_mul_of_nonneg_left (le_add_of_nonneg_right hsum) hscale)

theorem height_lower_bound (pi : D → P) (g : D → D) (a : P → D)
    (ell : P → ℕ) (hellpos : ∀ u, 0 < ell u) {m : ℝ} (hm : 2 ≤ m)
    {p : Coeff D} (hp : Nonneg p) (hsmall : ∀ x ∈ p.support, m⁻¹ < p x)
    {rate : ℝ} (hrate0 : 0 ≤ rate) (hrate : rate ≤ fixedScale (P := P) m) (U : Set D) :
    rate * mass (atomicImage g p) U ≤
      mass (rawH pi g a (threshold ell m) (fixedScale (P := P) m) p) U := by
  have hm0 : 0 < m := by linarith
  exact rawH_lower_of_selected pi g a (threshold ell m)
    (fun u => (threshold_pos ell hm0 u).le) hp
    (support_selected_of_small_thresholds pi (threshold ell m) hp
      (fun x hx => (threshold_le_inv ell hellpos hm (pi x)).trans_lt (hsmall x hx)))
    hrate0 hrate U

section SourceWrappers

variable {f : D → D} {M : Finset D}

noncomputable instance sourceFintype (f : D → D) (M : Finset D) :
    Fintype (SourcePoset f M) := Fintype.ofFinite _

/-- The actual source h is independent of the subsequently chosen c_x. -/
noncomputable def sourceH (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (ell : SourcePoset f M → ℕ) (m : ℝ) (p : Coeff D) : Coeff D :=
  rawH (sourcePi f M) (fun x => f (f x)) (sourceChosen hf hsep)
    (threshold ell m) (fixedScale (P := SourcePoset f M) m) p

theorem source_theta_margins (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (c : D → M) (hc : ∀ x, f x ≤ (c x).val ∧ (c x).val ≤ x)
    (ell : SourcePoset f M → ℕ) (hell : StrictMono ell)
    (H : ℕ) (hH : ∀ u, ell u ≤ H) {m : ℝ} (hm : 2 ≤ m)
    (p : SimpleCoeff D) (U : ScottOpen D) :
    mass (sourceH hf hsep ell m p.coeff) U ≤
        (1 - 1 / (m + (edgeCount (P := SourcePoset f M) : ℝ) + 1)) *
          mass p.coeff {x | (c x).val ∈ U} ∧
      (0 < mass (sourceH hf hsep ell m p.coeff) U →
        (m ^ H)⁻¹ < mass p.coeff {x | (c x).val ∈ U}) := by
  have hgc (x : D) : f (f x) ≤ (c x).val := by
    obtain ⟨b, _, hfb, hbx⟩ := hsep x
    exact (hf (hfb.trans hbx)).trans (hc x).1
  have hac (u : SourcePoset f M) (x : D) (hux : u ≤ sourcePi f M x) :
      sourceChosen hf hsep u ≤ (c x).val := by
    apply sourceChosen_le_member hf hsep u
    apply hux
    exact mem_sourceSlice.mpr ⟨(c x).property, (hc x).1⟩
  exact height_theta_margins (sourcePi f M) (fun x => f (f x)) (sourceChosen hf hsep)
    (fun x => (c x).val) (fun _ _ h => sourceSquare_le_chosen hf hsep h)
    hgc hac ell hell H hH hm p.nonneg U

theorem sourceH_mono (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (ell : SourcePoset f M → ℕ) {m : ℝ} (hm : 2 ≤ m)
    (p q : SimpleCoeff D) (hpq : p.toVSub ≤ q.toVSub) (U : ScottOpen D) :
    mass (sourceH hf hsep ell m p.coeff) U ≤ mass (sourceH hf hsep ell m q.coeff) U := by
  have hm0 : 0 < m := by linarith
  exact rawH_mono (sourcePi f M) (fun x => f (f x)) (sourceChosen hf hsep)
    (threshold ell m) (fun u => (threshold_pos ell hm0 u).le)
    (sourcePi_monotone hf) (hf.comp hf) (fun _ _ h => sourceSquare_le_chosen hf hsep h)
    (fixedScale_nonneg hm0) p q hpq U

theorem sourceH_nonneg (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (ell : SourcePoset f M → ℕ) {m : ℝ} (hm : 2 ≤ m)
    {p : Coeff D} (hp : Nonneg p) : Nonneg (sourceH hf hsep ell m p) := by
  have hm0 : 0 < m := by linarith
  exact rawH_nonneg (sourcePi f M) (fun x => f (f x)) (sourceChosen hf hsep)
    (threshold ell m) (fun u => (threshold_pos ell hm0 u).le) (fixedScale_nonneg hm0) hp

theorem sourceH_total_le_one (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (c : D → M) (hc : ∀ x, f x ≤ (c x).val ∧ (c x).val ≤ x)
    (ell : SourcePoset f M → ℕ) (hell : StrictMono ell)
    (H : ℕ) (hH : ∀ u, ell u ≤ H) {m : ℝ} (hm : 2 ≤ m) (p : SimpleCoeff D) :
    mass (sourceH hf hsep ell m p.coeff) Set.univ ≤ 1 := by
  have h := (source_theta_margins hf hsep c hc ell hell H hH hm p ScottOpen.univ).1
  change mass (sourceH hf hsep ell m p.coeff) Set.univ ≤
    (1 - 1 / (m + (edgeCount (P := SourcePoset f M) : ℝ) + 1)) *
      mass p.coeff Set.univ at h
  have heta : 0 ≤ 1 / (m + (edgeCount (P := SourcePoset f M) : ℝ) + 1) := by positivity
  have htotal := mass_nonneg p.nonneg Set.univ
  have hprod := mul_nonneg heta htotal
  nlinarith [p.total_le_one]

theorem sourceH_mass_gap (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (c : D → M) (hc : ∀ x, f x ≤ (c x).val ∧ (c x).val ≤ x)
    (ell : SourcePoset f M → ℕ) (hell : StrictMono ell)
    (H : ℕ) (hH : ∀ u, ell u ≤ H) {m : ℝ} (hm : 2 ≤ m)
    (p : SimpleCoeff D) (U : ScottOpen D)
    (hpos : 0 < mass (sourceH hf hsep ell m p.coeff) U) :
    mass (sourceH hf hsep ell m p.coeff) U < mass p.coeff {x | (c x).val ∈ U} -
      (m ^ H)⁻¹ / (m + (edgeCount (P := SourcePoset f M) : ℝ) + 1) := by
  obtain ⟨hmargin, hlower⟩ := source_theta_margins hf hsep c hc ell hell H hH hm p U
  have hden : 0 < m + (edgeCount (P := SourcePoset f M) : ℝ) + 1 := by positivity
  have hdiv := div_lt_div_of_pos_right (hlower hpos) hden
  have halg : (1 - 1 / (m + (edgeCount (P := SourcePoset f M) : ℝ) + 1)) *
      mass p.coeff {x | (c x).val ∈ U} = mass p.coeff {x | (c x).val ∈ U} -
        mass p.coeff {x | (c x).val ∈ U} / (m + (edgeCount (P := SourcePoset f M) : ℝ) + 1) := by
    ring
  rw [halg] at hmargin
  linarith

theorem sourceH_lower (hf : Monotone f)
    (hsep : ∀ x, ∃ a ∈ M, f x ≤ a ∧ a ≤ x)
    (ell : SourcePoset f M → ℕ) (hellpos : ∀ u, 0 < ell u)
    {m : ℝ} (hm : 2 ≤ m) {p : Coeff D} (hp : Nonneg p)
    (hsmall : ∀ x ∈ p.support, m⁻¹ < p x) {rate : ℝ}
    (hrate0 : 0 ≤ rate) (hrate : rate ≤ fixedScale (P := SourcePoset f M) m) (U : Set D) :
    rate * mass (atomicImage (fun x => f (f x)) p) U ≤
      mass (sourceH hf hsep ell m p) U :=
  height_lower_bound (sourcePi f M) (fun x => f (f x)) (sourceChosen hf hsep)
    ell hellpos hm hp hsmall hrate0 hrate U

end SourceWrappers

end FiniteSeparation.LocalMap
