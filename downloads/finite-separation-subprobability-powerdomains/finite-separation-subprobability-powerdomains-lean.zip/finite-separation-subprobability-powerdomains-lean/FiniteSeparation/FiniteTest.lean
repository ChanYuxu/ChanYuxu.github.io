import FiniteSeparation.Atomic

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical

section FiniteFunctions

variable {P : Type v} [Fintype P] [PartialOrder P]

noncomputable def finiteMass (p : P → ℝ) (U : Set P) : ℝ :=
  ∑ x, if x ∈ U then p x else 0

noncomputable def normalizedVector (p : P → ℝ) (hp : ∀ x, 0 ≤ p x)
    (C : ℝ) (hC : 0 < C) (htotal : ∑ x, p x ≤ C) :
    FiniteValuationApproximable.SubprobabilityVector P where
  coeff x := p x / C
  coeff_nonneg x := div_nonneg (hp x) hC.le
  total_le_one := by
    rw [← Finset.sum_div]
    exact (div_le_one hC).mpr htotal

theorem normalized_mass (p : P → ℝ) (hp : ∀ x, 0 ≤ p x)
    (C : ℝ) (hC : 0 < C) (htotal : ∑ x, p x ≤ C) (U : Set P) :
    (normalizedVector p hp C hC htotal).mass U = finiteMass p U / C := by
  simp only [FiniteValuationApproximable.SubprobabilityVector.mass,
    normalizedVector, finiteMass, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro x hx
  by_cases hxU : x ∈ U <;> simp [hxU]

theorem normalized_weighted (p : P → ℝ) (hp : ∀ x, 0 ≤ p x)
    (C : ℝ) (hC : 0 < C) (htotal : ∑ x, p x ≤ C) (w : P → ℝ) :
    FiniteValuationApproximable.weightedSum (normalizedVector p hp C hC htotal) w =
      (∑ x, p x * w x) / C := by
  simp only [FiniteValuationApproximable.weightedSum, normalizedVector, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro x hx
  ring

/-- The finite monotone-test implication for arbitrary finite nonnegative
mass, not just total mass at most one. The old simplex theorem is applied
only after a proved common normalization and the scaling is cancelled. -/
theorem finite_monotone_test (p q : P → ℝ)
    (hp : ∀ x, 0 ≤ p x) (hq : ∀ x, 0 ≤ q x)
    (horder : ∀ U : UpperSet P, finiteMass p U ≤ finiteMass q U)
    (w : P → ℝ) (hw : Monotone w) (hw0 : ∀ x, 0 ≤ w x) :
    (∑ x, p x * w x) ≤ ∑ x, q x * w x := by
  let C := max 1 (max (∑ x, p x) (∑ x, q x))
  have hC : 0 < C := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have hpC : ∑ x, p x ≤ C := (le_max_left _ _).trans (le_max_right _ _)
  have hqC : ∑ x, q x ≤ C := (le_max_right _ _).trans (le_max_right _ _)
  have hnormalized : normalizedVector p hp C hC hpC ≤ normalizedVector q hq C hC hqC := by
    intro U
    unfold FiniteValuationApproximable.upperMass
    rw [normalized_mass, normalized_mass]
    exact div_le_div_of_nonneg_right (horder U) hC.le
  have htest := (FiniteValuationApproximable.stochasticLE_iff_weightedSum_le.mp hnormalized)
    w hw hw0
  rw [normalized_weighted, normalized_weighted] at htest
  exact (div_le_div_iff_of_pos_right hC).mp htest

end FiniteFunctions

section SourceWrapper

variable {D : Type u} [PartialOrder D]

def AtomicLE (p q : Coeff D) : Prop := ∀ U : ScottOpen D, mass p U ≤ mass q U

theorem atomicValuation_le_iff {p q : Coeff D} (hp : Nonneg p) (hq : Nonneg q) :
    atomicValuation p hp ≤ atomicValuation q hq ↔ AtomicLE p q := by
  constructor
  · intro h U
    exact (ENNReal.ofReal_le_ofReal_iff (mass_nonneg hq U)).mp (h U)
  · intro h U
    exact ENNReal.ofReal_le_ofReal (h U)

def UpperOn (S : Finset D) (V : Set D) : Prop :=
  ∀ x ∈ S, ∀ y ∈ S, x ≤ y → x ∈ V → y ∈ V

theorem mass_congr_on {p : Coeff D} (S : Finset D) (hp : p.support ⊆ S)
    {U V : Set D} (hUV : ∀ x ∈ S, x ∈ U ↔ x ∈ V) : mass p U = mass p V := by
  rw [mass_on p hp, mass_on p hp]
  apply Finset.sum_congr rfl
  intro x hx
  rw [hUV x hx]

theorem finite_support_order_iff {p q : Coeff D} (S : Finset D)
    (hp : p.support ⊆ S) (hq : q.support ⊆ S) :
    AtomicLE p q ↔ ∀ V : Set D, UpperOn S V → mass p V ≤ mass q V := by
  constructor
  · intro h V hV
    have ht (a : Coeff D) (ha : a.support ⊆ S) :
        mass a (traceOpen S V hV) = mass a V :=
      mass_congr_on S ha (mem_traceOpen_iff S V hV)
    simpa only [ht p hp, ht q hq] using h (traceOpen S V hV)
  · intro h U
    exact h U (fun _ _ _ _ hxy hx => U.upper hxy hx)

theorem finite_support_integral {p q : Coeff D} (S : Finset D)
    (hpS : p.support ⊆ S) (hqS : q.support ⊆ S)
    (hp : Nonneg p) (hq : Nonneg q) (horder : AtomicLE p q)
    (w : S → ℝ) (hw : Monotone w) (hw0 : ∀ x, 0 ≤ w x) :
    (∑ x : S, p x.1 * w x) ≤ ∑ x : S, q x.1 * w x := by
  apply finite_monotone_test (fun x : S => p x.1) (fun x : S => q x.1)
    (fun x => hp x.1) (fun x => hq x.1) _ w hw hw0
  intro U
  let V : Set D := {x | ∀ hx : x ∈ S, (⟨x, hx⟩ : S) ∈ U}
  have hV : UpperOn S V := by
    intro x hx y hy hxy hxV hy'
    exact U.upper hxy (hxV hx)
  have h := (finite_support_order_iff S hpS hqS).mp horder V hV
  rw [mass_on p hpS, mass_on q hqS] at h
  have hmem (x : S) : x.1 ∈ V ↔ x ∈ (U : Set S) := by
    change (∀ hx : x.1 ∈ S, (⟨x.1, hx⟩ : S) ∈ U) ↔ x ∈ U
    exact ⟨fun h => h x.2, fun h _ => h⟩
  have hsum (a : Coeff D) :
      (∑ x : S, if x ∈ (U : Set S) then a x.1 else 0) = ∑ x ∈ S, if x ∈ V then a x else 0 := by
    calc
      _ = ∑ x : S, if x.1 ∈ V then a x.1 else 0 := by
        apply Finset.sum_congr rfl
        intro x hx
        by_cases hxU : x ∈ (U : Set S)
        · have hxV := (hmem x).mpr hxU
          simp only [if_pos hxU, if_pos hxV]
        · have hxV : x.1 ∉ V := fun hx => hxU ((hmem x).mp hx)
          simp only [if_neg hxU, if_neg hxV]
      _ = _ := Finset.sum_coe_sort S (fun x => if x ∈ V then a x else 0)
  simp only [finiteMass]
  rw [hsum p, hsum q]
  convert h using 1 <;> apply Finset.sum_congr rfl <;> intro x hx <;>
    by_cases hxV : x ∈ V <;> simp [hxV]

/-- Source-facing form of `lem:finite-test`, including its unrestricted
finite-mass hypothesis and the nonnegative monotone tests on the finite
induced poset, rather than on all of D. -/
theorem lem_finite_test {p q : Coeff D} (S : Finset D)
    (hpS : p.support ⊆ S) (hqS : q.support ⊆ S) (hp : Nonneg p) (hq : Nonneg q) :
    (atomicValuation p hp ≤ atomicValuation q hq ↔
      ∀ V : Set D, UpperOn S V → mass p V ≤ mass q V) ∧
    (atomicValuation p hp ≤ atomicValuation q hq →
      ∀ w : S → ℝ, Monotone w → (∀ x, 0 ≤ w x) →
        (∑ x : S, p x.1 * w x) ≤ ∑ x : S, q x.1 * w x) := by
  refine ⟨(atomicValuation_le_iff hp hq).trans (finite_support_order_iff S hpS hqS), ?_⟩
  intro h w hw hw0
  exact finite_support_integral S hpS hqS hp hq
    ((atomicValuation_le_iff hp hq).mp h) w hw hw0

end SourceWrapper

@[ext] theorem SimpleCoeff.ext {D : Type u} [PartialOrder D] {p q : SimpleCoeff D}
    (h : p.coeff = q.coeff) : p = q := by
  cases p
  cases q
  cases h
  rfl

/-- The finite atomic representation of a simple valuation is unique after
equal atoms have been combined. -/
theorem SimpleCoeff.toVSub_injective {D : Type u} [PartialOrder D] :
    Function.Injective (SimpleCoeff.toVSub (D := D)) := by
  intro p q hpq
  let S := p.coeff.support ∪ q.coeff.support
  have hpS : p.coeff.support ⊆ S := Finset.subset_union_left
  have hqS : q.coeff.support ⊆ S := Finset.subset_union_right
  have hvec : p.vectorOn S hpS = q.vectorOn S hqS :=
    le_antisymm (vectorOn_le_of_toVSub_le p q S hpS hqS hpq.le)
      (vectorOn_le_of_toVSub_le q p S hqS hpS hpq.ge)
  apply SimpleCoeff.ext
  ext x
  by_cases hx : x ∈ S
  · exact congrArg (fun r : FiniteValuationApproximable.SubprobabilityVector S => r ⟨x, hx⟩) hvec
  · have hxp : x ∉ p.coeff.support := fun h => hx (hpS h)
    have hxq : x ∉ q.coeff.support := fun h => hx (hqS h)
    simp [Finsupp.notMem_support_iff.mp hxp, Finsupp.notMem_support_iff.mp hxq]

end FiniteSeparation
