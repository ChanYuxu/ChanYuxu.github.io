import FiniteSeparation.Extension

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D]

theorem uniform_positive {I : Type v} [Fintype I] (w : I → ℝ) (hw : ∀ i, 0 < w i) :
    ∃ rho : ℝ, 0 < rho ∧ ∀ i, rho ≤ w i := by
  let S : Finset ℝ := insert 1 (Finset.univ.image w)
  have hS : S.Nonempty := ⟨1, Finset.mem_insert_self _ _⟩
  refine ⟨S.min' hS, ?_, ?_⟩
  · have hmem := Finset.min'_mem S hS
    rcases Finset.mem_insert.mp hmem with h | h
    · rw [h]
      exact zero_lt_one
    · obtain ⟨i, _, hi⟩ := Finset.mem_image.mp h
      exact hi ▸ hw i
  · intro i
    exact Finset.min'_le S (w i) (Finset.mem_insert_of_mem (Finset.mem_image.mpr
      ⟨i, Finset.mem_univ _, rfl⟩))

/-- Exact eventual finite-list form of `lem:fixed-source`. -/
theorem lem_fixed_source (C : SourceData D) (F : Set (SimpleCoeff D)) (hF : F.Finite)
    (rate : ℝ) (hr0 : 0 < rate) (hr1 : rate < 1) :
    ∃ m0 : ℕ, ∃ hm0 : 2 ≤ m0, ∀ m : ℕ, ∀ hm : m0 ≤ m, ∀ p ∈ F,
      (scaledAtomic p (fun x => C.f (C.f x)) rate hr0.le hr1.le).toVSub ≤
        (sourceSimple C m (hm0.trans hm) p).toVSub := by
  letI : Fintype F := hF.fintype
  let Atom := Σ p : F, p.1.coeff.support
  letI : Fintype Atom := inferInstance
  let weight : Atom → ℝ := fun z => z.1.1.coeff z.2.1
  have hweight (z : Atom) : 0 < weight z :=
    lt_of_le_of_ne (z.1.1.nonneg z.2.1) (Ne.symm (Finsupp.mem_support_iff.mp z.2.2))
  obtain ⟨rho, hrho, hsmallrho⟩ := uniform_positive weight hweight
  obtain ⟨m0, hparams⟩ := sufficiently_large_parameters rho rate hrho hr0 hr1
    (LocalMap.edgeCount (P := C.poset))
  have hm0 := (hparams m0 le_rfl).1
  refine ⟨m0, hm0, ?_⟩
  intro m hm p hp
  obtain ⟨_, hsmall, hscale⟩ := hparams m hm
  apply sourceSimple_lower C m (hm0.trans hm) p rate hr0.le hr1.le
  · intro x hx
    have hInv : (m : ℝ)⁻¹ < rho := by simpa only [one_div] using hsmall
    exact hInv.trans_le
      (hsmallrho (⟨⟨p, hp⟩, ⟨x, hx⟩⟩ : Atom))
  · exact hscale.le

abbrev SourceIndex (A : FSIdentity D) := {f : ScottContFun D D // f ∈ A.maps}
abbrev FamilyIndex (A : FSIdentity D) := SourceIndex A × {m : ℕ // 2 ≤ m}

theorem familyIndex_nonempty (A : FSIdentity D) : Nonempty (FamilyIndex A) := by
  obtain ⟨f, hf⟩ := A.directed.1
  exact ⟨(⟨f, hf⟩, ⟨2, le_rfl⟩)⟩

instance (A : FSIdentity D) : Nonempty (FamilyIndex A) := familyIndex_nonempty A

noncomputable def sourceDataFor (A : FSIdentity D) (i : SourceIndex A) : SourceData D := by
  let hsep := A.finitelySeparated i.1 i.2
  let M := Classical.choose hsep
  have hM := Classical.choose_spec hsep
  exact
    { f := i.1
      M := hM.1.toFinset
      separates := by
        intro x
        obtain ⟨a, ha, hfa, hax⟩ := hM.2 x
        exact ⟨a, hM.1.mem_toFinset.mpr ha, hfa, hax⟩ }

noncomputable def familyMap (A : FSIdentity D) (k : FamilyIndex A) :
    simpleBasis D → VSub D := localBasisMap (sourceDataFor A k.1) k.2.1 k.2.2

theorem familyMap_monotone (A : FSIdentity D) (k : FamilyIndex A) :
    Monotone (familyMap A k) := localBasisMap_monotone _ _ _

/-- `lem:finite-approx`. The common source index is obtained in the original
arbitrary directed family, followed by one eventual integer bound for all
positive atoms in the finite list. -/
theorem lem_finite_approx (A : FSIdentity D) : FiniteBasisApproximation (familyMap A) := by
  classical
  intro F hF hway
  letI : Fintype F := hF.fintype
  have hchoose : ∀ p : F, ∃ a : ApproxParam A,
      p.1.1 ≤ beta A (basisRepresentative p.1.2) a := by
    intro p
    apply wayBelow_simple_beta
    simpa only [basisRepresentative_eq] using hway p.1 p.2
  choose pick hpick using hchoose
  obtain ⟨a, _, hupper⟩ := (approxParam_directed A).exists_upper_finite
    (Set.finite_range pick) (Set.subset_univ _)
  have hbeta (p : F) : p.1.1 ≤ beta A (basisRepresentative p.1.2) a :=
    (hpick p).trans (beta_monotone A (basisRepresentative p.1.2)
      (hupper _ (Set.mem_range_self p)))
  let C := sourceDataFor A a.1
  let Atom := Σ p : F, (basisRepresentative p.1.2).coeff.support
  letI : Fintype Atom := inferInstance
  let weight : Atom → ℝ := fun z => (basisRepresentative z.1.1.2).coeff z.2.1
  have hweight (z : Atom) : 0 < weight z := by
    have hnn := (basisRepresentative z.1.1.2).nonneg z.2.1
    have hne := Finsupp.mem_support_iff.mp z.2.2
    exact lt_of_le_of_ne hnn (Ne.symm hne)
  obtain ⟨rho, hrho, hsmallrho⟩ := uniform_positive weight hweight
  obtain ⟨m, hm⟩ := sufficiently_large_parameters rho a.2.1 hrho a.2.2.1 a.2.2.2
    (LocalMap.edgeCount (P := C.poset))
  obtain ⟨hm2, hmRho, hmScale⟩ := hm m le_rfl
  refine ⟨(a.1, ⟨m, hm2⟩), ?_⟩
  intro p hp
  apply (hbeta ⟨p, hp⟩).trans
  apply sourceSimple_lower C m hm2 (basisRepresentative p.2) a.2.1 a.2.2.1.le a.2.2.2.le
  · intro x hx
    have hsmall := hsmallrho (⟨⟨p, hp⟩, ⟨x, hx⟩⟩ : Atom)
    have hInv : (m : ℝ)⁻¹ < rho := by simpa only [one_div] using hmRho
    exact hInv.trans_le hsmall
  · exact hmScale.le

section MainTheorem

variable [Nonempty D]

noncomputable def constructedIdentity (A : FSIdentity D) : FSIdentity (VSub D) := by
  letI : Nonempty (FamilyIndex A) := familyIndex_nonempty A
  have hB := lem_simple_basis (fs_continuous A)
  apply prop_basis_fs VSub.isDcpo hB.2 hB.1 (familyMap A) (familyMap_monotone A)
  · intro k
    exact ⟨sourceGrid (sourceDataFor A k.1) k.2.1,
      sourceGrid_finite _ _, (prop_simple_separation _ _ _).2.2⟩
  · exact lem_finite_approx A

end MainTheorem

/-- The exact unrestricted source-facing conclusion, `thm:main`:
no bottom, countable basis, sequential approximation, or factorization
through a fixed finite-poset valuation space is assumed on D. -/
theorem thm_main (hD : IsFSDomain D) :
    IsFSDomain (VSub D) ∧ ∃ z : VSub D, IsLeast z := by
  obtain ⟨hne, _hdcpo, ⟨A⟩⟩ := hD
  letI : Nonempty D := hne
  exact ⟨⟨⟨0⟩, VSub.isDcpo, ⟨constructedIdentity A⟩⟩, ⟨0, VSub.zero_le⟩⟩

end FiniteSeparation
