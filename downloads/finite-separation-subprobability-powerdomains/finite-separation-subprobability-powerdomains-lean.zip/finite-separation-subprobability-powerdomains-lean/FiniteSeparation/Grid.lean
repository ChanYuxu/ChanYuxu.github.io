import FiniteSeparation.Atomic
import FiniteValuationApproximable.FiniteValuation.ErosionFS

set_option autoImplicit false

universe u

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open FiniteValuationApproximable (SubprobabilityVector upperMass)
open FiniteValuationApproximable.Erosion
open FiniteValuationApproximable.ContinuousValuation
open scoped BigOperators Classical

variable {D : Type u} [PartialOrder D]

def traceUpper (M : Finset D) (U : ScottOpen D) : UpperSet M where
  carrier := {a | a.1 ∈ U}
  upper' := by intro a b hab ha; exact U.upper hab ha

noncomputable def liftVector (M : Finset D) (p : SubprobabilityVector M) : VSub D :=
  finiteAtomicVSub (fun a : M => a.1) p p.coeff_nonneg p.total_le_one

theorem liftVector_real (M : Finset D) (p : SubprobabilityVector M) (U : ScottOpen D) :
    (liftVector M p U).toReal = upperMass p (traceUpper M U) := by
  rw [liftVector, finiteAtomicVSub_apply_toReal]
  rfl

theorem liftVector_mono (M : Finset D) {p q : SubprobabilityVector M} (hpq : p ≤ q) :
    liftVector M p ≤ liftVector M q := by
  intro U
  change ENNReal.ofReal _ ≤ ENNReal.ofReal _
  exact ENNReal.ofReal_le_ofReal (hpq (traceUpper M U))

noncomputable def gridSet (M : Finset D) (N : ℕ) (hN : 0 < N) : Set (VSub D) :=
  Set.range (fun k : NatFloorGridCode (P := M) N =>
    liftVector M (gridVector N hN k))

theorem gridSet_finite (M : Finset D) (N : ℕ) (hN : 0 < N) :
    (gridSet M N hN).Finite := Set.finite_range _

/-- The literal deterministic floor-grid argument. Only the old library's
floor operation and uniform error bound are reused, not its erosion map. -/
theorem grid_separates (M : Finset D) (p : SubprobabilityVector M)
    (h : VSub D) (eta delta : ℝ) (heta : 0 < eta)
    (hscale : ∀ U : ScottOpen D, (h U).toReal ≤
      (1 - eta) * (liftVector M p U).toReal)
    (hpositive : ∀ U : ScottOpen D, 0 < (h U).toReal →
      delta < (liftVector M p U).toReal)
    (N : ℕ) (hN : 0 < N) (hgrid : (M.card : ℝ) / N < eta * delta) :
    ∃ γ ∈ gridSet M N hN, h ≤ γ ∧ γ ≤ liftVector M p := by
  let r := roundDown N hN p
  refine ⟨liftVector M r, ⟨natFloorCode N hN p, rfl⟩, ?_,
    liftVector_mono M (roundDown_le N hN p)⟩
  intro U
  have hhfin : h U ≠ ⊤ := ne_of_lt ((h.value_le_one U).trans_lt ENNReal.one_lt_top)
  have hrfin : liftVector M r U ≠ ⊤ :=
    ne_of_lt (((liftVector M r).value_le_one U).trans_lt ENNReal.one_lt_top)
  apply (ENNReal.toReal_le_toReal hhfin hrfin).mp
  by_cases hh : (h U).toReal = 0
  · rw [hh]
    exact ENNReal.toReal_nonneg
  · have hhpos : 0 < (h U).toReal := lt_of_le_of_ne ENNReal.toReal_nonneg (Ne.symm hh)
    have htheta := hpositive U hhpos
    have hmult := mul_lt_mul_of_pos_left htheta heta
    have hupper := hscale U
    have herr := upperMass_sub_roundDown_le N hN p (traceUpper M U)
    rw [← liftVector_real, ← liftVector_real] at herr
    have hcard : Fintype.card M = M.card := Fintype.card_coe M
    rw [hcard] at herr
    dsimp only [r]
    nlinarith

end FiniteSeparation
