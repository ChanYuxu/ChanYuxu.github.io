import FiniteSeparation.Atomic
import FiniteSeparation.PointAssignment

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set AbramskyJung.Chapter2
open scoped BigOperators Classical
open PointAssignment

variable {D : Type u} [PartialOrder D] {P : Type v} [PartialOrder P] [Fintype P]

noncomputable def covers (u : P) : Finset P := Finset.univ.filter (u ⋖ ·)

def upperFiber (pi : D → P) (u : P) : Set D := {x | u ≤ pi x}

def boundary (pi : D → P) (A : Finset P) (u : P) : Set D :=
  pi ⁻¹' exitUpper (A : Set P) u

theorem boundary_eq_union (pi : D → P) (A : Finset P) (u : P) :
    boundary pi A u = ⋃ v ∈ covers u \ A, upperFiber pi v := by
  ext x
  simp [boundary, exitUpper, covers, upperFiber, and_assoc, and_left_comm, and_comm]

noncomputable def correctionCoeff (pi : D → P) (t : P → ℝ)
    (p : Coeff D) (A : Finset P) (u : P) : ℝ :=
  mass p (boundary pi A u) + ∑ v ∈ covers u ∩ A, t v

theorem correctionCoeff_nonneg (pi : D → P) (t : P → ℝ)
    (ht : ∀ u, 0 ≤ t u) {p : Coeff D} (hp : Nonneg p) (A : Finset P) (u : P) :
    0 ≤ correctionCoeff pi t p A u :=
  add_nonneg (mass_nonneg hp _) (Finset.sum_nonneg fun v _ => ht v)

theorem correctionCoeff_bound (pi : D → P) (t : P → ℝ)
    {p : Coeff D} (hp : Nonneg p) (A : Finset P)
    (hout : ∀ v ∉ A, mass p (upperFiber pi v) ≤ t v) (u : P) :
    correctionCoeff pi t p A u ≤ ∑ v ∈ covers u, t v := by
  have hbound : mass p (boundary pi A u) ≤ ∑ v ∈ covers u \ A, t v := by
    rw [boundary_eq_union]
    exact (mass_biUnion_le _ hp _).trans (Finset.sum_le_sum fun v hv =>
      hout v (Finset.mem_sdiff.mp hv).2)
  unfold correctionCoeff
  calc
    _ ≤ (∑ v ∈ covers u \ A, t v) + ∑ v ∈ covers u ∩ A, t v :=
      add_le_add hbound le_rfl
    _ = ∑ v ∈ covers u, t v := by
      have heq : covers u \ (covers u ∩ A) = covers u \ A := by ext v; simp <;> tauto
      rw [← heq, Finset.sum_sdiff Finset.inter_subset_left]

theorem boundary_subset (pi : D → P) {A B : Finset P} (hAB : A ⊆ B) (u : P) :
    boundary pi A u ⊆ boundary pi B u ∪
      ⋃ v ∈ covers u ∩ (B \ A), upperFiber pi v := by
  intro x hx
  obtain ⟨v, huv, hvA, hvx⟩ := hx
  by_cases hvB : v ∈ B
  · right
    simp only [Set.mem_iUnion]
    exact ⟨v, Finset.mem_inter.mpr
      ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, huv⟩,
        Finset.mem_sdiff.mpr ⟨hvB, hvA⟩⟩, hvx⟩
  · exact Or.inl ⟨v, huv, hvB, hvx⟩

/-- The threshold compensation in `lem:subset-comparison`, separately at
each old index. This is stronger than the needed valuation inequality. -/
theorem correctionCoeff_mono_subset (pi : D → P) (t : P → ℝ)
    {p : Coeff D} (hp : Nonneg p) {A B : Finset P} (hAB : A ⊆ B)
    (hnew : ∀ v ∈ B \ A, mass p (upperFiber pi v) ≤ t v) (u : P) :
    correctionCoeff pi t p A u ≤ correctionCoeff pi t p B u := by
  have hmass : mass p (boundary pi A u) ≤ mass p (boundary pi B u) +
      ∑ v ∈ covers u ∩ (B \ A), t v := by
    have hnewsum : mass p (⋃ v ∈ covers u ∩ (B \ A), upperFiber pi v) ≤
        ∑ v ∈ covers u ∩ (B \ A), t v :=
      (mass_biUnion_le _ hp _).trans (Finset.sum_le_sum fun v hv =>
        hnew v (Finset.mem_inter.mp hv).2)
    exact (mass_mono_set hp (boundary_subset pi hAB u)).trans
      ((mass_union_le hp _ _).trans (add_le_add le_rfl hnewsum))
  have hsub : covers u ∩ A ⊆ covers u ∩ B := Finset.inter_subset_inter_left hAB
  have heq : (covers u ∩ B) \ (covers u ∩ A) = covers u ∩ (B \ A) := by
    ext v
    simp <;> tauto
  have hsum : (∑ v ∈ covers u ∩ (B \ A), t v) + ∑ v ∈ covers u ∩ A, t v =
      ∑ v ∈ covers u ∩ B, t v := by
    rw [← heq, Finset.sum_sdiff hsub]
  unfold correctionCoeff
  linarith

noncomputable def selected (pi : D → P) (t : P → ℝ) (p : Coeff D) : Finset P :=
  Finset.univ.filter (fun u => t u < mass p (upperFiber pi u))

@[simp] theorem mem_selected (pi : D → P) (t : P → ℝ) (p : Coeff D) (u : P) :
    u ∈ selected pi t p ↔ t u < mass p (upperFiber pi u) := by
  simp [selected]

theorem not_selected_bound (pi : D → P) (t : P → ℝ) (p : Coeff D)
    (u : P) (hu : u ∉ selected pi t p) : mass p (upperFiber pi u) ≤ t u := by
  exact le_of_not_gt (by simpa using hu)

end FiniteSeparation
