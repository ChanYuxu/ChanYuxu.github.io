import FiniteValuationApproximable.Abstract.Approximation

/-! Source-bound order theory for the finite-separation manuscript.
The dcpo predicate quantifies over nonempty directed sets; no bottom or
countability assumption is installed on the source or on the basis. -/

set_option autoImplicit false

universe u v

namespace FiniteSeparation

open Set AbramskyJung.Chapter2

abbrev ScottContinuous {X : Type u} {Y : Type v} [Preorder X] [Preorder Y]
    (f : X → Y) := AbramskyJung.Chapter2.ScottContinuous f

abbrev FinitelySeparated {X : Type u} [Preorder X] (f : X → X) :=
  FiniteValuationApproximable.AbstractApproximation.IsFinitelySeparated f

abbrev FSIdentity (X : Type u) [Preorder X] :=
  FiniteValuationApproximable.AbstractApproximation.DirectedFSApproximateIdentity X

def IsFSDomain (X : Type u) [Preorder X] : Prop :=
  Nonempty X ∧ IsDcpo X ∧ Nonempty (FSIdentity X)

theorem finitelySeparated_wayBelow {X : Type u} [Preorder X]
    {f : X → X} (hf : ScottContinuous f) (hsep : FinitelySeparated f) (x : X) :
    f x ≪ x :=
  FiniteValuationApproximable.AbstractApproximation.IsFinitelySeparated.wayBelow hf hsep x

theorem fs_continuous {X : Type u} [Preorder X] (A : FSIdentity X) :
    IsContinuousDomain X := by
  refine ⟨Set.univ, ?_⟩
  intro x
  refine ⟨(fun f : ScottContFun X X => f x) '' A.maps, ?_,
    ScottContFun.eval_directed A.directed x, A.pointwise_sup x⟩
  rintro y ⟨f, hf, rfl⟩
  exact ⟨Set.mem_univ _, finitelySeparated_wayBelow f.continuous (A.finitelySeparated f hf) x⟩

/-- A directed set cannot have its supremum covered only collectively by
finitely many principal lower sets. This is the finite Scott-closed-union
step in `lem:basis-extension`. -/
theorem finite_cover_sup {X : Type u} [Preorder X] {A M : Set X} {s : X}
    (hA : DirectedSet A) (hs : IsSup A s) (hM : M.Finite)
    (hcover : ∀ a ∈ A, ∃ m ∈ M, a ≤ m) : ∃ m ∈ M, s ≤ m := by
  classical
  by_contra hnot
  have hbad : ∀ m ∈ M, ∃ a ∈ A, ¬ a ≤ m := by
    intro m hm
    by_contra hn
    have hub : IsUpperBound A m := by
      intro a ha
      by_contra ham
      exact hn ⟨a, ha, ham⟩
    exact hnot ⟨m, hm, hs.2 m hub⟩
  let pick : M → X := fun m => Classical.choose (hbad m m.2)
  have hpick (m : M) : pick m ∈ A ∧ ¬ pick m ≤ m.1 :=
    Classical.choose_spec (hbad m m.2)
  letI : Fintype M := hM.fintype
  have hfin : (Set.range pick).Finite := Set.finite_range pick
  obtain ⟨a, ha, hupper⟩ := hA.exists_upper_finite hfin (by
    rintro _ ⟨m, rfl⟩
    exact (hpick m).1)
  obtain ⟨m, hm, ham⟩ := hcover a ha
  exact (hpick ⟨m, hm⟩).2 ((hupper _ ⟨⟨m, hm⟩, rfl⟩).trans ham)

section Extension

variable {X : Type u} [PartialOrder X] {B : Set X}
variable (hX : IsDcpo X) (hB : IsBasis B) (q : B → X) (hq : Monotone q)

def basisInputs (x : X) : Set B := {b | b.1 ≪ x}

include hB in
theorem basisInputs_directed (x : X) : DirectedSet (basisInputs (B := B) x) := by
  constructor
  · obtain ⟨b, hb⟩ := (hB x).1.1
    exact ⟨⟨b, hb.1⟩, hb.2⟩
  · intro b hb c hc
    obtain ⟨d, hd, hbd, hcd⟩ := (hB x).1.2 ⟨b.2, hb⟩ ⟨c.2, hc⟩
    exact ⟨⟨d, hd.1⟩, hd.2, hbd, hcd⟩

def basisValues (x : X) : Set X := q '' basisInputs x

include hB hq in
theorem basisValues_directed (x : X) : DirectedSet (basisValues q x) :=
  DirectedSet.image hq (basisInputs_directed hB x)

noncomputable def basisExtension (x : X) : X :=
  Classical.choose (hX _ (basisValues_directed hB q hq x))

theorem basisExtension_isSup (x : X) :
    IsSup (basisValues q x) (basisExtension hX hB q hq x) :=
  Classical.choose_spec (hX _ (basisValues_directed hB q hq x))

theorem le_basisExtension (x : X) (b : B) (hb : b.1 ≪ x) :
    q b ≤ basisExtension hX hB q hq x :=
  (basisExtension_isSup hX hB q hq x).1 ⟨b, hb, rfl⟩

theorem basisExtension_monotone : Monotone (basisExtension hX hB q hq) := by
  intro x y hxy
  apply (basisExtension_isSup hX hB q hq x).2
  rintro _ ⟨b, hb, rfl⟩
  exact le_basisExtension hX hB q hq y b (prop_2_2_2_2 le_rfl hb hxy)

theorem basisExtension_continuous (hcont : IsContinuousDomain X) :
    ScottContinuous (basisExtension hX hB q hq) := by
  refine ⟨basisExtension_monotone hX hB q hq, ?_⟩
  intro A s hA hs
  constructor
  · rintro _ ⟨a, ha, rfl⟩
    exact basisExtension_monotone hX hB q hq (hs.1 ha)
  · intro y hy
    apply (basisExtension_isSup hX hB q hq s).2
    rintro _ ⟨b, hb, rfl⟩
    obtain ⟨z, hbz, hzs⟩ := wayBelow_interpolation hcont hb
    obtain ⟨a, ha, hza⟩ := hzs hA hs le_rfl
    exact (le_basisExtension hX hB q hq a b
      (prop_2_2_2_2 le_rfl hbz hza)).trans (hy ⟨a, ha, rfl⟩)

theorem basisExtension_separated {M : Set X} (hM : M.Finite)
    (hsep : ∀ b : B, ∃ m ∈ M, q b ≤ m ∧ m ≤ b.1) :
    FiniteValuationApproximable.AbstractApproximation.IsFiniteSeparator M
      (basisExtension hX hB q hq) := by
  refine ⟨hM, ?_⟩
  intro x
  let N : Set X := {m | m ∈ M ∧ m ≤ x}
  have hN : N.Finite := hM.subset (fun _ h => h.1)
  obtain ⟨m, hm, hxm⟩ := finite_cover_sup
    (basisValues_directed hB q hq x) (basisExtension_isSup hX hB q hq x) hN (by
      rintro _ ⟨b, hb, rfl⟩
      obtain ⟨m, hm, hqm, hmb⟩ := hsep b
      exact ⟨m, ⟨hm, hmb.trans (prop_2_2_2_1 hb)⟩, hqm⟩)
  exact ⟨m, hm.1, hxm, hm.2⟩

/-- Exact public wrapper for `lem:basis-extension`. -/
theorem lem_basis_extension (hcont : IsContinuousDomain X) :
    ScottContinuous (basisExtension hX hB q hq) ∧
    (∀ x (b : B), b.1 ≪ x → q b ≤ basisExtension hX hB q hq x) ∧
    (∀ M : Set X, M.Finite →
      (∀ b : B, ∃ m ∈ M, q b ≤ m ∧ m ≤ b.1) →
      FiniteValuationApproximable.AbstractApproximation.IsFiniteSeparator M
        (basisExtension hX hB q hq)) :=
  ⟨basisExtension_continuous hX hB q hq hcont,
    le_basisExtension hX hB q hq, fun _ => basisExtension_separated hX hB q hq⟩

end Extension

section SquareCriterion

variable {X : Type u} [PartialOrder X] {K : Type v} [Nonempty K]
variable (e : K → ScottContFun X X)

def FiniteApproximation : Prop :=
  ∀ F : Set (X × X), F.Finite →
    (∀ p ∈ F, p.1 ≪ p.2) → ∃ k : K, ∀ p ∈ F, p.1 ≤ e k p.2

def squareMap (k : K) : ScottContFun X X := (e k).comp (e k)

theorem squares_directed (hcont : IsContinuousDomain X)
    (hsep : ∀ k, FinitelySeparated (e k)) (happ : FiniteApproximation e) :
    DirectedSet (Set.range (squareMap e)) := by
  classical
  constructor
  · exact ⟨squareMap e (Classical.arbitrary K), Set.mem_range_self _⟩
  · rintro _ ⟨i, rfl⟩ _ ⟨j, rfl⟩
    obtain ⟨S, hSfin, hS⟩ := hsep i
    obtain ⟨T, hTfin, hT⟩ := hsep j
    let L : Set (K × X) := ({i} : Set K) ×ˢ S ∪ ({j} : Set K) ×ˢ T
    have hL : L.Finite :=
      ((Set.finite_singleton i).prod hSfin).union ((Set.finite_singleton j).prod hTfin)
    letI : Fintype L := hL.fintype
    have hz : ∀ p : L, ∃ z : X, e p.1.1 p.1.2 ≪ z ∧ z ≪ p.1.2 := by
      intro p
      exact wayBelow_interpolation hcont
        (finitelySeparated_wayBelow (e p.1.1).continuous (hsep p.1.1) p.1.2)
    choose z hlow hhigh using hz
    let first : L → X × X := fun p => (e p.1.1 p.1.2, z p)
    let second : L → X × X := fun p => (z p, p.1.2)
    let F : Set (X × X) := Set.range first ∪ Set.range second
    have hF : F.Finite := (Set.finite_range first).union (Set.finite_range second)
    obtain ⟨k, hk⟩ := happ F hF (by
      rintro _ (⟨p, rfl⟩ | ⟨p, rfl⟩)
      · exact hlow p
      · exact hhigh p)
    have hdom (a : K) (x : X) (hax : (a, x) ∈ L) :
        e a x ≤ e k (z ⟨(a, x), hax⟩) ∧ z ⟨(a, x), hax⟩ ≤ e k x := by
      exact ⟨hk _ (Or.inl ⟨⟨(a, x), hax⟩, rfl⟩),
        hk _ (Or.inr ⟨⟨(a, x), hax⟩, rfl⟩)⟩
    refine ⟨squareMap e k, Set.mem_range_self _, ?_, ?_⟩
    · intro x
      obtain ⟨a, ha, hia, hax⟩ := hS x
      have haL : (i, a) ∈ L := Or.inl ⟨by simp, ha⟩
      exact ((e i).continuous.monotone hia).trans
        ((hdom i a haL).1.trans
          (((e k).continuous.monotone (hdom i a haL).2).trans
            ((squareMap e k).continuous.monotone hax)))
    · intro x
      obtain ⟨a, ha, hja, hax⟩ := hT x
      have haL : (j, a) ∈ L := Or.inr ⟨by simp, ha⟩
      exact ((e j).continuous.monotone hja).trans
        ((hdom j a haL).1.trans
          (((e k).continuous.monotone (hdom j a haL).2).trans
            ((squareMap e k).continuous.monotone hax)))

theorem squares_pointwise_sup (hcont : IsContinuousDomain X)
    (hsep : ∀ k, FinitelySeparated (e k)) (happ : FiniteApproximation e) (x : X) :
    IsSup (Set.range (fun k => squareMap e k x)) x := by
  classical
  constructor
  · rintro _ ⟨k, rfl⟩
    exact (hsep k).below_id (e k x) |>.trans ((hsep k).below_id x)
  · intro y hy
    apply (continuous_wayBelowLower_isSup hcont x).2
    intro u hu
    obtain ⟨z, huz, hzx⟩ := wayBelow_interpolation hcont hu
    obtain ⟨k, hk⟩ := happ ({(u, z), (z, x)} : Set (X × X))
      (by simp) (by
        intro p hp
        rcases Set.mem_insert_iff.mp hp with rfl | hp
        · exact huz
        · have hp' : p = (z, x) := Set.mem_singleton_iff.mp hp
          subst p
          exact hzx)
    exact (hk (u, z) (by simp)).trans
      (((e k).continuous.monotone (hk (z, x) (by simp))).trans
        (hy (Set.mem_range_self k)))

def squaresIdentity (hcont : IsContinuousDomain X)
    (hsep : ∀ k, FinitelySeparated (e k)) (happ : FiniteApproximation e) : FSIdentity X where
  maps := Set.range (squareMap e)
  directed := squares_directed e hcont hsep happ
  finitelySeparated := by
    rintro _ ⟨k, rfl⟩
    exact (hsep k).square
  pointwise_sup x := by
    have heq : (fun f : ScottContFun X X => f x) '' Set.range (squareMap e) =
        Set.range (fun k => squareMap e k x) := by
      ext y
      simp
    rw [heq]
    exact squares_pointwise_sup e hcont hsep happ x

end SquareCriterion

section BasisCriterion

variable {X : Type u} [PartialOrder X] {K : Type v} [Nonempty K] {B : Set X}
variable (hX : IsDcpo X) (hB : IsBasis B) (hcont : IsContinuousDomain X)
variable (q : K → B → X) (hq : ∀ k, Monotone (q k))

noncomputable def extendedMap (k : K) : ScottContFun X X where
  toFun := basisExtension hX hB (q k) (hq k)
  continuous := basisExtension_continuous hX hB (q k) (hq k) hcont

def FiniteBasisApproximation : Prop :=
  ∀ F : Set (X × B), F.Finite →
    (∀ p ∈ F, p.1 ≪ p.2.1) → ∃ k : K, ∀ p ∈ F, p.1 ≤ q k p.2

theorem finiteApproximation_extended (happ : FiniteBasisApproximation q) :
    FiniteApproximation (extendedMap hX hB hcont q hq) := by
  classical
  intro F hF hway
  letI : Fintype F := hF.fintype
  have hex : ∀ p : F, ∃ b : B, p.1.1 ≪ b.1 ∧ b.1 ≪ p.1.2 := by
    intro p
    obtain ⟨v, huv, hvx⟩ := wayBelow_interpolation hcont (hway p.1 p.2)
    obtain ⟨b, hb, hvb⟩ := hvx (hB p.1.2).1 (hB p.1.2).2 le_rfl
    exact ⟨⟨b, hb.1⟩, prop_2_2_2_2 le_rfl huv hvb, hb.2⟩
  choose pick hlow hhigh using hex
  let requirements : F → X × B := fun p => (p.1.1, pick p)
  obtain ⟨k, hk⟩ := happ (Set.range requirements) (Set.finite_range requirements) (by
    rintro _ ⟨p, rfl⟩
    exact hlow p)
  refine ⟨k, ?_⟩
  intro p hp
  exact (hk _ ⟨⟨p, hp⟩, rfl⟩).trans
    (le_basisExtension hX hB (q k) (hq k) p.2 (pick ⟨p, hp⟩) (hhigh ⟨p, hp⟩))

/-- `prop:basis-fs`: the actual maps are the composition squares of the
directed-basis extensions. No directedness of the original basis-map family
is assumed. -/
noncomputable def prop_basis_fs
    (hsep : ∀ k, ∃ M : Set X, M.Finite ∧
      ∀ b : B, ∃ m ∈ M, q k b ≤ m ∧ m ≤ b.1)
    (happ : FiniteBasisApproximation q) : FSIdentity X := by
  apply squaresIdentity (extendedMap hX hB hcont q hq) hcont
  · intro k
    obtain ⟨M, hM, hMk⟩ := hsep k
    exact ⟨M, basisExtension_separated hX hB (q k) (hq k) hM hMk⟩
  · exact finiteApproximation_extended hX hB hcont q hq happ

end BasisCriterion

end FiniteSeparation
