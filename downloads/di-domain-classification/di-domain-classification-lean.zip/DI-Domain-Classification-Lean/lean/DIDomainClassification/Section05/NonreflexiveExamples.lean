import DIDomainClassification.Support.ReflexiveExamples

/-! Example 5.7, with its complete-lattice and literal U/W clauses. -/
set_option autoImplicit false
universe u

namespace DIDomainClassification.Section05

theorem nonreflexiveCompleteLattice : NonreflexiveCompleteLatticeStatement.{u} :=
  ReflexiveExamples.complete_not_reflexive

theorem nonreflexiveExamples : NonreflexiveExamplesStatement.{u} :=
  ⟨nonreflexiveCompleteLattice, ReflexiveExamples.base_and_W⟩

end DIDomainClassification.Section05
