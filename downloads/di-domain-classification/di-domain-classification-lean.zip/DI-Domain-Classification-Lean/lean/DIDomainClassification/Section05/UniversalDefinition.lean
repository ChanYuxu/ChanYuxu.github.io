import DIDomainClassification.Section02.StableCategory
import DIDomainClassification.Section02.Retractions

/-!
# Stable universal objects

Exact definition at manuscript.tex:2123--2126, source SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
Full subcategories are specified by their actual ambient object predicates.
Membership of U is part of the definition. Stable split identities are exactly
the accepted non-strict relation, with no embedding-projection inequality.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Subcategories

/-- U is included and every included object is its actual stable retract. -/
def IsStableUniversal (P : CountablyBasedDIDomain.{u} → Prop)
    (U : CountablyBasedDIDomain.{u}) : Prop :=
  P U ∧ ∀ D : CountablyBasedDIDomain.{u}, P D →
    HasStableRetraction D.toDIDomainObject U.toDIDomainObject

end DIDomainClassification.Subcategories
