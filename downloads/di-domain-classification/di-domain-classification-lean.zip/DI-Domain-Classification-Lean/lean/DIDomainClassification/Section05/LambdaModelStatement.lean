import DIDomainClassification.Section04.AdditionalSourceModels
import Mathlib.Logic.Relation

/-! Genuine finite-context de Bruijn syntax, capture-avoiding substitution,
and unproved beta-model targets for a chosen stable reflexive pair.
No eta equation is included. Interpretations contain DATA, not assumed laws. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05.LambdaBetaModels
open Preliminaries Section04.AdditionalSourceModels Section03.StableFunctionModels

inductive Term : ℕ → Type
  | var {n : ℕ} : Fin n → Term n
  | app {n : ℕ} : Term n → Term n → Term n
  | lam {n : ℕ} : Term (n+1) → Term n

def liftRenaming {n m : ℕ} (r : Fin n → Fin m) : Fin (n+1) → Fin (m+1) :=
  Fin.cases 0 (fun i => (r i).succ)

/-- Primitive structural recursion on the actual indexed syntax. This uses
the kernel recursor directly; no well-founded or partial runtime helper. -/
def rename {n m : ℕ} (r : Fin n → Fin m) (t : Term n) : Term m :=
  Term.rec (motive := fun n _ => ∀ m : ℕ, (Fin n → Fin m) → Term m)
    (fun i _ r => Term.var (r i))
    (fun _ _ hf hx m r => Term.app (hf m r) (hx m r))
    (fun _ ht m r => Term.lam (ht (m+1) (liftRenaming r)))
    t m r

def liftSubstitution {n m : ℕ} (s : Fin n → Term m) : Fin (n+1) → Term (m+1) :=
  Fin.cases (.var 0) (fun i => rename Fin.succ (s i))

def subst {n m : ℕ} (s : Fin n → Term m) (t : Term n) : Term m :=
  Term.rec (motive := fun n _ => ∀ m : ℕ, (Fin n → Term m) → Term m)
    (fun i _ s => s i)
    (fun _ _ hf hx m s => Term.app (hf m s) (hx m s))
    (fun _ ht m s => Term.lam (ht (m+1) (liftSubstitution s)))
    t m s

def topSubstitution {n : ℕ} (x : Term n) : Fin (n+1) → Term n :=
  Fin.cases x Term.var

inductive BetaStep : {n : ℕ} → Term n → Term n → Prop
  | beta {n : ℕ} (t : Term (n+1)) (x : Term n) :
      BetaStep (.app (.lam t) x) (subst (topSubstitution x) t)
  | appLeft {n : ℕ} {f g : Term n} (x : Term n) :
      BetaStep f g → BetaStep (.app f x) (.app g x)
  | appRight {n : ℕ} (f : Term n) {x y : Term n} :
      BetaStep x y → BetaStep (.app f x) (.app f y)
  | lam {n : ℕ} {t s : Term (n+1)} :
      BetaStep t s → BetaStep (.lam t) (.lam s)

def BetaEquivalent {n : ℕ} (t s : Term n) : Prop :=
  Relation.EqvGen (fun x y : Term n => BetaStep x y) t s

structure Interpretation (E : CountablyBasedDIDomain.{u}) where
  eval : {n : ℕ} → Term n → (Fin n → Core E) → Core E

def extend {E : CountablyBasedDIDomain.{u}} {n : ℕ} (x : Core E)
    (env : Fin n → Core E) : Fin (n+1) → Core E := Fin.cases x env

def Equations {E : CountablyBasedDIDomain.{u}} (p : StableReflexivePair E)
    (I : Interpretation E) : Prop :=
  (∀ (n : ℕ) (env : Fin n → Core E) (i : Fin n), I.eval (.var i) env = env i) ∧
  (∀ (n : ℕ) (f x : Term n) (env : Fin n → Core E),
    I.eval (.app f x) env = p.application (I.eval f env) (I.eval x env)) ∧
  (∀ (n : ℕ) (t : Term (n+1)) (env : Fin n → Core E),
    ∃ f : StableSpace E E, (∀ x : Core E, f x = I.eval t (extend x env)) ∧
      I.eval (.lam t) env = p.sectionMap f)

def SubstitutionSound {E : CountablyBasedDIDomain.{u}} (I : Interpretation E) : Prop :=
  ∀ (n m : ℕ) (s : Fin n → Term m) (t : Term n) (env : Fin m → Core E),
    I.eval (subst s t) env = I.eval t (fun i => I.eval (s i) env)

def BetaSound {E : CountablyBasedDIDomain.{u}} (I : Interpretation E) : Prop :=
  ∀ (n : ℕ) (t s : Term n), BetaEquivalent t s →
    ∀ env : Fin n → Core E, I.eval t env = I.eval s env

def StableInterpretation {E : CountablyBasedDIDomain.{u}} (I : Interpretation E) : Prop :=
  ∀ n : ℕ, ∃ hEnv : IsCountablyBasedDIDomain (Fin n → Core E),
    ∀ t : Term n, IsStable (cbObject (Fin n → Core E) hEnv).toDIDomainObject (Core E)
      (fun env => I.eval t env)

end DIDomainClassification.Section05.LambdaBetaModels

namespace DIDomainClassification.Section05
open Preliminaries Section04.AdditionalSourceModels Section03.StableFunctionModels
open LambdaBetaModels

def LambdaModelStatement : Prop :=
  ∀ (E : CountablyBasedDIDomain.{u}) (p : StableReflexivePair E),
    ∃ I : Interpretation E,
      Equations p I ∧ SubstitutionSound I ∧ BetaSound I ∧ StableInterpretation I ∧
      ∃ hProduct : IsCountablyBasedDIDomain (Core E × Core E),
        IsStable (cbObject (Core E × Core E) hProduct).toDIDomainObject (Core E)
          (fun xy => p.application xy.1 xy.2)

end DIDomainClassification.Section05
