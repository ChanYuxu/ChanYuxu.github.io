import DIDomainClassification.Section05.UniversalSourceStatements
import DIDomainClassification.Support.ZhaoKouUniversality

/-!
Exact source Theorem4.18 (manuscript.tex1832--1835), frozen SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The same actual U certificate precedes the arbitrary D quantifier. W is the
source U's genuine native-stable-ordered self-map space, not a proxy object.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05

theorem zhaoKou : ZhaoKouStatement.{u} :=
  ⟨ZhaoKouCodes.baseCertificate, ZhaoKouUniversality.universality⟩

end DIDomainClassification.Section05
