import DIDomainClassification.Section05.UniversalSourceStatements
import DIDomainClassification.Section05.ZhaoKou
import DIDomainClassification.Section05.WDegree
import DIDomainClassification.Section03.FunctionDegree
import DIDomainClassification.Section04.ComparisonTheorem
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Support.FinitePowerMembership
import DIDomainClassification.Support.UniversalRetracts

/-! Exact Proposition successor-universal, manuscript.tex 2176--2246,
SHA256 11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The witness is literally [W → E], including beta = firstUncountableBound.
No universality, nontriviality or degree conclusion is an extra hypothesis.
-/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05
open Preliminaries Subcategories CoherenceDegree
open Section03.StableFunctionModels
open Section04 Section04.AdditionalSourceModels

theorem successorUniversal : SuccessorUniversalStatement.{u} := by
  intro β hβ _hBound E hE
  obtain ⟨hU, hZhao⟩ := zhaoKou.{u}
  obtain ⟨_hOther, _hBaseDegree, hWdegree, _hWcoherent⟩ := wDegreeModel.{u}
  let W := universalTwoObject hU
  let U := successorUniversalObject hU E
  have hW : objectDegree W = 2 := hWdegree
  have hWnon : Nontrivial (Core W) :=
    FinitePowerMembership.nontrivial_of_two_le_degree W hW.ge
  have hEnon : Nontrivial (Core E) :=
    FinitePowerMembership.nontrivial_of_two_le_degree E (by simpa only [hE] using hβ)
  have hdegree : objectDegree U = β := by
    have hFn := Section03.functionDegree.1 W E hWnon hEnon
    change objectDegree (exponential W E) = max 2 (objectDegree E) at hFn
    change objectDegree (exponential W E) = β
    exact hFn.trans (by rw [hE, max_eq_right hβ])
  have hForward : ∀ D : CountablyBasedDIDomain.{u}, objectDegree D ≤ β →
      HasStableRetraction (Core D) (Core U) := by
    intro D hD
    have hComparison : StableComparison D E :=
      (comparisonTheorem D E hEnon).mpr (by simpa only [hE, max_eq_right hβ] using hD)
    obtain ⟨H, hH, hDH⟩ := hComparison
    have hHW : HasStableRetraction (Core H) (Core W) := hZhao H hH
    have hExponential := UniversalRetracts.domainExponentialRetraction H W E hHW
    obtain ⟨s, r, hrs⟩ := hDH
    obtain ⟨t, q, hqt⟩ := hExponential
    refine ⟨StableHom.comp t s, StableHom.comp r q, ?_⟩
    intro x
    change r (q (t (s x))) = x
    rw [hqt (s x)]
    exact hrs x
  have hConverse : ∀ D : CountablyBasedDIDomain.{u},
      HasStableRetraction (Core D) (Core U) → objectDegree D ≤ β := by
    intro D hDU
    obtain ⟨s, r, hrs⟩ := hDU
    have hmono := Section02.bps.1 (Core D) (Core U)
      (Core D).isDIDomain.toIsScottDomain (Core U).isDIDomain.toIsScottDomain
      D.countableCompacts U.countableCompacts
      ⟨s, r, (StableHom.isStable s).1, (StableHom.isStable r).1, hrs⟩
    change objectDegree D ≤ objectDegree U at hmono
    simpa only [hdegree] using hmono
  have hCut : ∀ D : CountablyBasedDIDomain.{u},
      objectDegree D ≤ β ↔ DomainCut (β+1) D := by
    intro D
    change objectDegree D ≤ β ↔ objectDegree D < β+1
    simpa only [Order.succ_eq_add_one] using
      (Order.lt_succ_iff : objectDegree D < Order.succ β ↔ objectDegree D ≤ β).symm
  refine ⟨hU, hdegree, ?_, ?_⟩
  · intro D
    exact ⟨⟨hConverse D, hForward D⟩, hCut D⟩
  · constructor
    · exact (hCut U).mp hdegree.le
    · intro D hD
      exact hForward D ((hCut D).mpr hD)

end DIDomainClassification.Section05
