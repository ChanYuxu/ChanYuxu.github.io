import DIDomainClassification.Section05.StableReflexive
import DIDomainClassification.Section01.OrdinalCuts
import DIDomainClassification.Section05.UniversalDefinition
import DIDomainClassification.Support.OrdinalCutBounds
import Mathlib.Order.Antisymmetrization

/-! Private Step3 data/specification candidate for u:mutual-retraction,
thm:reflexive-class, cor:reflexive-order and p:reflexivity-universality.
The quotient uses the actual split-retraction preorder, NOT isomorphism.
The displayed order isomorphism is an unproved OUTPUT, not model data.
Frozen manuscript SHA256:
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05.ReflexiveModels
open Section03.StableFunctionModels Subcategories

/-- Reflexivity and transitivity of actual splits, needed only to form the
quotient model. These prove no classification or degree assertion. -/
theorem retract_refl (D : DIDomainObject.{u}) : HasStableRetraction D D := by
  exact ⟨StableHom.id D, StableHom.id D, fun _ => rfl⟩

theorem retract_trans {D E F : DIDomainObject.{u}}
    (hDE : HasStableRetraction D E) (hEF : HasStableRetraction E F) :
    HasStableRetraction D F := by
  obtain ⟨s, r, hrs⟩ := hDE
  obtain ⟨i, p, hpi⟩ := hEF
  refine ⟨StableHom.comp i s, StableHom.comp r p, ?_⟩
  intro x
  change r (p (i (s x))) = x
  rw [hpi]
  exact hrs x

def MutualStableRetraction (D E : CountablyBasedDIDomain.{u}) : Prop :=
  HasStableRetraction (Core D) (Core E) ∧ HasStableRetraction (Core E) (Core D)

def ReflexiveObject : Type (u+1) :=
  {D : CountablyBasedDIDomain.{u} // Nontrivial (Core D) ∧ IsStableReflexive D}

/-- The le relation is exactly stable split retraction, not pointwise order. -/
instance reflexivePreorder : Preorder ReflexiveObject.{u} where
  le D E := HasStableRetraction (Core D.val) (Core E.val)
  le_refl D := retract_refl (Core D.val)
  le_trans _ _ _ hDE hEF := retract_trans hDE hEF

/-- Actual quotient by the mutual form of this preorder, with the library's
proved quotient partial order. No equality of objects up to isomorphism. -/
abbrev ReflexiveClass : Type (u+1) :=
  Antisymmetrization ReflexiveObject.{u} (fun D E => D ≤ E)

def classOf (D : ReflexiveObject.{u}) : ReflexiveClass.{u} :=
  toAntisymmetrization (fun D E : ReflexiveObject.{u} => D ≤ E) D

abbrev DegreeInterval : Type (u+2) :=
  {β : Ordinal.{u+1} // 2 ≤ β ∧ β ≤ firstUncountableBound.{u}}

theorem mutualStableRetraction_iff (D E : CountablyBasedDIDomain.{u}) :
    MutualStableRetraction D E ↔
      HasStableRetraction (Core D) (Core E) ∧ HasStableRetraction (Core E) (Core D) :=
  Iff.rfl

theorem reflexivePreorder_le_iff (D E : ReflexiveObject.{u}) :
    D ≤ E ↔ HasStableRetraction (Core D.val) (Core E.val) := Iff.rfl

end DIDomainClassification.Section05.ReflexiveModels

namespace DIDomainClassification.Section05
open Subcategories Section03.StableFunctionModels ReflexiveModels

/-- Source2282--2291, including actual membership in the final universal class. -/
def ReflexiveClassStatement : Prop :=
  ∀ E : CountablyBasedDIDomain.{u}, Nontrivial (Core E) → IsStableReflexive E →
    (∀ D : CountablyBasedDIDomain.{u},
      HasStableRetraction (Core D) (Core E) ↔ objectDegree D ≤ objectDegree E) ∧
    IsStableUniversal (DomainCut (objectDegree E + 1)) E

/-- Source2313--2321: all degrees occur and the actual coherence degree
induces a genuine OrderIso on the specified quotient partial order. -/
def ReflexiveOrderStatement : Prop :=
  (∀ β : Ordinal.{u+1}, 2 ≤ β → β ≤ firstUncountableBound.{u} →
    ∃ D : ReflexiveObject.{u}, objectDegree D.val = β) ∧
  (∃ e : ReflexiveClass.{u} ≃o DegreeInterval.{u},
    ∀ D : ReflexiveObject.{u}, (e (classOf D)).val = objectDegree D.val)

/-- Source2334, with nontriviality retained and the lower-degree condition
explicit on the universal-object side. -/
def ReflexivityUniversalityStatement : Prop :=
  ∀ E : CountablyBasedDIDomain.{u}, Nontrivial (Core E) →
    (IsStableReflexive E ↔
      IsStableUniversal (DomainCut (objectDegree E + 1)) E ∧ 2 ≤ objectDegree E)

end DIDomainClassification.Section05
