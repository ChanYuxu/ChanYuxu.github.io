import DIDomainClassification.Support.ReflexiveQuotientOrder

/-! Corollary 5.6, manuscript.tex 2313--2327, frozen manuscript SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
Both printed clauses are outputs, including the representative formula for
the genuine order isomorphism of the mutual stable-retraction quotient. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05
open Subcategories ReflexiveModels

theorem reflexiveDegreeRealizability :
    ∀ β : Ordinal.{u+1}, 2 ≤ β → β ≤ firstUncountableBound.{u} →
      ∃ D : ReflexiveObject.{u}, objectDegree D.val = β :=
  ReflexiveQuotientOrder.realize

theorem reflexiveDegreeOrder :
    ∃ e : ReflexiveClass.{u} ≃o DegreeInterval.{u},
      ∀ D : ReflexiveObject.{u}, (e (classOf D)).val = objectDegree D.val :=
  ⟨ReflexiveQuotientOrder.degreeOrderIso, ReflexiveQuotientOrder.degreeOrderIso_classOf⟩

theorem reflexiveOrder : ReflexiveOrderStatement.{u} :=
  ⟨reflexiveDegreeRealizability, reflexiveDegreeOrder⟩

end DIDomainClassification.Section05
