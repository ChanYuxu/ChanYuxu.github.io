import DIDomainClassification.Section05.UniversalSourceStatements
import DIDomainClassification.Support.UniversalDegreeModels

/-! Source manuscript.tex1837--1840: the literal base and W both have degree2,
and the actual countably based stable exponential W is 2-coherent. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05

theorem wDegreeModel : WDegreeModelStatement.{u} :=
  ⟨ZhaoKouCodes.baseCertificate, UniversalDegreeModels.base_degree,
    UniversalDegreeModels.W_degree, UniversalDegreeModels.W_twoCoherent⟩

end DIDomainClassification.Section05
