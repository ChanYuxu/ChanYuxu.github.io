import DIDomainClassification.Support.LambdaSyntaxSoundness

/-! Source manuscript.tex:2276--2280, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The chosen actual stable reflexive split yields a stable finite-context
lambda-beta interpretation with proved substitution and beta equations.
No eta equation, strictness or EP inequality is assumed or concluded. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05

theorem lambdaModel : LambdaModelStatement.{u} := by
  intro E p
  exact ⟨LambdaInterpretation.interpretation p, LambdaInterpretation.equations p,
    LambdaSyntaxSoundness.substitutionSound p, LambdaSyntaxSoundness.betaSound p,
    LambdaInterpretation.stableInterpretation p, LambdaInterpretation.application_stable p⟩

end DIDomainClassification.Section05
