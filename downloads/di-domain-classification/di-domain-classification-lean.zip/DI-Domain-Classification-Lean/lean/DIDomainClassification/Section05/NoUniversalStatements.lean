import DIDomainClassification.Section01.OrdinalCuts
import DIDomainClassification.Section05.UniversalDefinition
import DIDomainClassification.Support.OrdinalCutBounds

/-! Unproved exact targets for prop:no-universal-finite (2128--2130)
and prop:no-universal-limit (2151--2153), frozen manuscript SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
No source proof, category classification or degree realization is assumed.
The printed upper bound on lambda IS present in prop:no-universal-limit;
the distinct unqualified Corollary4.23 sentence remains untouched. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05
open Subcategories

def NoUniversalFiniteStatement : Prop :=
  ∀ α : Ordinal.{u+1}, 3 ≤ α → α ≤ Ordinal.omega0 →
    ¬ ∃ U : CountablyBasedDIDomain.{u}, IsStableUniversal (FiniteDomainCut α) U

def NoUniversalLimitStatement : Prop :=
  ∀ lam : Ordinal.{u+1}, 3 ≤ lam → lam ≤ firstUncountableBound.{u} →
    Order.IsSuccLimit lam →
      ¬ ∃ U : CountablyBasedDIDomain.{u}, IsStableUniversal (DomainCut lam) U

end DIDomainClassification.Section05
