import DIDomainClassification.Support.NoUniversalObjects

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section05

theorem noUniversalLimit : NoUniversalLimitStatement.{u} := by
  intro lam h3 hbound hlim
  exact NoUniversalObjects.no_limit_universal lam h3 hbound hlim

end DIDomainClassification.Section05
