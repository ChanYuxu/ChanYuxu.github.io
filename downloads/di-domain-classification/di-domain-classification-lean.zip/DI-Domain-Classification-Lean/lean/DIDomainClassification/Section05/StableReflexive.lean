import DIDomainClassification.Section03.StableFunctionModels
import DIDomainClassification.Section02.Retractions

/-! Literal source stable-reflexive definition manuscript.tex2276--2280.
The existential domain property is separate from a CHOSEN defining split
pair. No EP inequality, strictness, classification or lambda-model theorem
is included as an assumption or proved here. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section05

open Section03.StableFunctionModels

def IsStableReflexive (E : CountablyBasedDIDomain.{u}) : Prop :=
  HasStableRetraction (Core (exponential E E)) (Core E)

theorem isStableReflexive_iff (E : CountablyBasedDIDomain.{u}) :
    IsStableReflexive E ↔
      ∃ (s : StableHom (Core (exponential E E)) (Core E))
        (r : StableHom (Core E) (Core (exponential E E))),
        Function.LeftInverse (r : Core E → Core (exponential E E))
          (s : Core (exponential E E) → Core E) := Iff.rfl

structure StableReflexivePair (E : CountablyBasedDIDomain.{u}) where
  sectionMap : StableHom (Core (exponential E E)) (Core E)
  retractionMap : StableHom (Core E) (Core (exponential E E))
  split : Function.LeftInverse
    (retractionMap : Core E → Core (exponential E E))
    (sectionMap : Core (exponential E E) → Core E)

/-- The printed raw application function associated to an actual split pair.
No stability or lambda-calculus beta theorem is proved here. -/
def StableReflexivePair.application {E : CountablyBasedDIDomain.{u}}
    (p : StableReflexivePair E) (x y : Core E) : Core E := p.retractionMap x y

theorem StableReflexivePair.application_apply {E : CountablyBasedDIDomain.{u}}
    (p : StableReflexivePair E) (x y : Core E) :
    p.application x y = p.retractionMap x y := rfl

end DIDomainClassification.Section05
