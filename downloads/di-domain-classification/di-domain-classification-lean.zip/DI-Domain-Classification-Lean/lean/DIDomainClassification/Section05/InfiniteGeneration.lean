import DIDomainClassification.Support.InfiniteCategoryGeneration

/-! Source manuscript.tex:1850--1906, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
An infinite object generates the literal flat natural domain, every natural
power of an included object, and all countably based 2-coherent domains. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05

theorem infiniteGeneration : InfiniteGenerationStatement.{u} := by
  intro P hP hInfinite
  have hFlat := InfiniteCategoryGeneration.flat_mem P hP hInfinite
  exact ⟨HomogeneousCliqueModels.flatCertificate, hFlat,
    InfiniteCategoryGeneration.all_twoCoherent_mem P hP hFlat⟩

theorem infiniteGenerationCountablePowers : InfiniteGenerationCountablePowersStatement.{u} := by
  intro P hP hInfinite X hX
  exact InfiniteCategoryGeneration.countable_powers_mem P hP hInfinite X hX

end DIDomainClassification.Section05
