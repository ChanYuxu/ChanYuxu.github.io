import DIDomainClassification.Section05.UniversalSourceStatements
import DIDomainClassification.Section01.Classification
import DIDomainClassification.Section02.DegreeRealizability
import DIDomainClassification.Section05.NoUniversalFinite
import DIDomainClassification.Section05.NoUniversalLimit
import DIDomainClassification.Section05.SuccessorUniversal

/-! Exact universal-object classification, manuscript.tex 2248--2267,
SHA256 11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The category-facing lemma uses the proved classification, not a classification
assumption. The source-facing wrapper retains the frozen alternatives and the
full range 2 <= beta <= firstUncountableBound. The positive witness is the
literal function-space object of successorUniversal.
-/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05
open Subcategories Section04.CutModels Section04.AdditionalSourceModels

/-- Among the nontrivial, replete, intrinsically cartesian closed,
stable-retract-closed full subcategories classified in Theorem 1.1. -/
theorem universalClassifiedCategory (P : ObjectClass.{u})
    (hP : CategoryHypotheses P) :
    (∃ U : CountablyBasedDIDomain.{u}, IsStableUniversal P U) ↔
      ∃ β : Ordinal.{u+1}, 2 ≤ β ∧ β ≤ firstUncountableBound.{u} ∧
        P = DomainCut (β+1) := by
  constructor
  · intro hUniversal
    rcases (Section01.classification.1 P).mp hP with hFinite | hDomain
    · obtain ⟨α, hα, rfl⟩ := hFinite
      exact False.elim (noUniversalFinite α hα.1 hα.2 hUniversal)
    · obtain ⟨α, hα, rfl⟩ := hDomain
      rcases Ordinal.zero_or_succ_or_isSuccLimit α with hZero | hSucc | hLimit
      · subst α
        exact False.elim ((not_lt_of_ge (zero_le (2 : Ordinal.{u+1})))
          (NoUniversalObjects.two_lt_of_three_le hα.1))
      · obtain ⟨β, rfl⟩ := hSucc
        refine ⟨β, ?_, ?_, ?_⟩
        · exact Order.lt_succ_iff.mp (NoUniversalObjects.two_lt_of_three_le hα.1)
        · apply Order.succ_le_succ_iff.mp
          simpa only [Order.succ_eq_add_one] using hα.2
        · rw [Order.succ_eq_add_one]
      · have hBound : α ≤ firstUncountableBound.{u} := by
          apply hLimit.le_succ_iff.mp
          simpa only [Order.succ_eq_add_one] using hα.2
        exact False.elim (noUniversalLimit α hα.1 hBound hLimit hUniversal)
  · rintro ⟨β, hTwo, hBound, rfl⟩
    obtain ⟨E, hDegree⟩ := Section02.degreeRealizability.1 β (Or.inr ⟨hTwo, hBound⟩)
    obtain ⟨hU, _hObjectDegree, _hRetractClass, hUniversal⟩ :=
      successorUniversal β hTwo hBound E hDegree
    exact ⟨successorUniversalObject hU E, hUniversal⟩

theorem universalCutClassification : UniversalCutClassificationStatement.{u} := by
  intro P hAlternative
  exact universalClassifiedCategory P ((Section01.classification.1 P).mpr hAlternative)

theorem universalTheorem : UniversalTheoremStatement.{u} :=
  ⟨universalCutClassification, successorUniversal⟩

end DIDomainClassification.Section05
