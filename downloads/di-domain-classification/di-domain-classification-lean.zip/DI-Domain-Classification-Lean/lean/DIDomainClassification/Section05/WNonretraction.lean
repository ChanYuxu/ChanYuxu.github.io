import DIDomainClassification.Section05.WDegree
import DIDomainClassification.Support.FiniteCoordinateRetraction

/-! Source manuscript.tex1847--1848: degree equality does not imply a stable
retraction W -> U. The local finite-coordinate proof uses the original thesis
star example and the already proved actual universality, without an FCI axiom. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05

open Section03.StableFunctionModels Section04.AdditionalSourceModels

theorem wDegreeNonretract : WDegreeNonretractStatement.{u} := by
  refine ⟨ZhaoKouCodes.baseCertificate, ?_⟩
  intro hWU
  have hStarW := ZhaoKouUniversality.universality StarCliqueObstruction.starObject.{u}
    StarCliqueObstruction.twoCoherent
  exact FiniteCoordinateRetraction.star_not_retract_base
    (ZhaoKouRetraction.trans hStarW hWU)

end DIDomainClassification.Section05
