import DIDomainClassification.Section04.AdditionalSourceModels
import DIDomainClassification.Section05.NoUniversalStatements

/-! UNPROVED source-facing targets for the literal universal construction,
infinite generation, generators, and nonreflexive examples. Certificates for
the fixed carriers are OUTPUTS; no universality or degree is an input field. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05
open Preliminaries Subcategories CoherenceDegree
open Section03.StableFunctionModels
open Section04 Section04.CutModels Section04.AdditionalSourceModels

def ZhaoKouStatement : Prop :=
  ∃ hU : IsCountablyBasedDIDomain UniversalBaseCarrier.{u},
    ∀ D : CountablyBasedDIDomain.{u},
      IsNCoherent (Core D).isDIDomain.toIsScottDomain 2 (by decide) →
      HasStableRetraction (Core D) (Core (universalTwoObject hU))

def WDegreeModelStatement : Prop :=
  ∃ hU : IsCountablyBasedDIDomain UniversalBaseCarrier.{u},
    objectDegree (universalBaseObject hU) = 2 ∧
    objectDegree (universalTwoObject hU) = 2 ∧
    IsNCoherent (Core (universalTwoObject hU)).isDIDomain.toIsScottDomain 2 (by decide)

def WDegreeNonretractStatement : Prop :=
  ∃ hU : IsCountablyBasedDIDomain UniversalBaseCarrier.{u},
    ¬ HasStableRetraction (Core (universalTwoObject hU)) (Core (universalBaseObject hU))

def InfiniteGenerationStatement : Prop :=
  ∀ P : ObjectClass.{u}, CategoryHypotheses P →
    (∃ D : CountablyBasedDIDomain.{u}, P D ∧ Infinite D) →
    ∃ hFlat : IsCountablyBasedDIDomain FlatCarrier.{u},
      P (flatObject hFlat) ∧ (∀ D : CountablyBasedDIDomain.{u}, DomainCut 3 D → P D)

def InfiniteGenerationCountablePowersStatement : Prop :=
  ∀ P : ObjectClass.{u}, CategoryHypotheses P →
    (∃ D : CountablyBasedDIDomain.{u}, P D ∧ Infinite D) →
    ∀ X : CountablyBasedDIDomain.{u}, P X →
    ∃ hPower : IsCountablyBasedDIDomain (ℕ → Core X),
      P (cbObject (ℕ → Core X) hPower)

def SuccessorUniversalStatement : Prop :=
  ∀ β : Ordinal.{u+1}, 2 ≤ β → β ≤ firstUncountableBound.{u} →
    ∀ E : CountablyBasedDIDomain.{u}, objectDegree E = β →
    ∃ hU : IsCountablyBasedDIDomain UniversalBaseCarrier.{u},
      objectDegree (successorUniversalObject hU E) = β ∧
      (∀ D : CountablyBasedDIDomain.{u},
        (HasStableRetraction (Core D) (Core (successorUniversalObject hU E)) ↔
          objectDegree D ≤ β) ∧
        (objectDegree D ≤ β ↔ DomainCut (β+1) D)) ∧
      IsStableUniversal (DomainCut (β+1)) (successorUniversalObject hU E)

def UniversalCutClassificationStatement : Prop :=
  ∀ P : ObjectClass.{u}, (FiniteAlternative P ∨ DomainAlternative P) →
    ((∃ U : CountablyBasedDIDomain.{u}, IsStableUniversal P U) ↔
      ∃ β : Ordinal.{u+1}, 2 ≤ β ∧ β ≤ firstUncountableBound.{u} ∧
        P = DomainCut (β+1))

def UniversalTheoremStatement : Prop :=
  UniversalCutClassificationStatement.{u} ∧ SuccessorUniversalStatement.{u}

def NonreflexiveCompleteLatticeStatement : Prop :=
  ∀ D : CountablyBasedDIDomain.{u}, Nontrivial (Core D) →
    Section02.BPS.IsCompleteLatticeOrder (Core D) → ¬ IsStableReflexive D

def NonreflexiveExamplesStatement : Prop :=
  NonreflexiveCompleteLatticeStatement.{u} ∧
    ∃ hU : IsCountablyBasedDIDomain UniversalBaseCarrier.{u},
      objectDegree (universalBaseObject hU) = 2 ∧
      objectDegree (universalTwoObject hU) = 2 ∧
      ¬ IsStableReflexive (universalBaseObject hU) ∧
      IsStableReflexive (universalTwoObject hU) ∧
      ¬ HasStableRetraction (Core (universalTwoObject hU)) (Core (universalBaseObject hU))

end DIDomainClassification.Section05

namespace DIDomainClassification.Section04
open Preliminaries Subcategories CoherenceDegree AdditionalSourceModels
open Section03.StableFunctionModels

def SingleGeneratorNontrivialStatement : Prop :=
  ∀ D : CountablyBasedDIDomain.{u}, Nontrivial (Core D) →
    (Finite D → GeneratedClass D = FiniteDomainCut (max 2 (objectDegree D) + 1)) ∧
    (Infinite D → GeneratedClass D = DomainCut (max 2 (objectDegree D) + 1))

def SingleGeneratorSingletonStatement : Prop :=
  ∀ D : CountablyBasedDIDomain.{u}, IsSingletonCarrier (Core D) →
    GeneratedClass D = SingletonClass

def FiniteOmegaNotSingleGeneratedStatement : Prop :=
  ¬ ∃ D : CountablyBasedDIDomain.{u}, IsGeneratedBy D (FiniteDomainCut Ordinal.omega0)

/-- Original unqualified limit clause retained EXACTLY. No upper range
restriction is inserted here. Its known range concern is recorded privately;
this defined proposition is NOT a proved theorem or a repaired statement. -/
def LimitNotSingleGeneratedOriginalStatement : Prop :=
  ∀ limitOrdinal : Ordinal.{u+1}, Order.IsSuccLimit limitOrdinal →
    ¬ ∃ D : CountablyBasedDIDomain.{u}, IsGeneratedBy D (DomainCut limitOrdinal)

def SingleGeneratorStatement : Prop :=
  SingleGeneratorNontrivialStatement.{u} ∧ SingleGeneratorSingletonStatement.{u} ∧
    FiniteOmegaNotSingleGeneratedStatement.{u} ∧ LimitNotSingleGeneratedOriginalStatement.{u}

def GeneratorExamplesStatement : Prop :=
  (GeneratedClass FiniteOrderDomains.twoObject.{u} = FiniteDomainCut 3) ∧
  (∀ (n : ℕ) (hn : 2 ≤ n),
    ∃ hCube : IsCountablyBasedDIDomain (FiniteCategoryModels.CubeCarrier.{u} n hn),
      GeneratedClass (FiniteCategoryModels.cubeObject n hn hCube) =
        FiniteDomainCut ((n : Ordinal.{u+1}) + 1)) ∧
  (∃ hFlat : IsCountablyBasedDIDomain FlatCarrier.{u},
    GeneratedClass (flatObject hFlat) = DomainCut 3) ∧
  (∃ hSequence : IsCountablyBasedDIDomain CubeSequenceCarrier.{u},
    objectDegree (cubeSequenceObject hSequence) = Ordinal.omega0 ∧
    GeneratedClass (cubeSequenceObject hSequence) = DomainCut (Ordinal.omega0+1) ∧
    ¬ DomainCut Ordinal.omega0 (cubeSequenceObject hSequence)) ∧
  (∀ (n : ℕ) (hn : 2 ≤ n),
    ∃ hCube : IsCountablyBasedDIDomain (FiniteCategoryModels.CubeCarrier.{u} n hn),
      DomainCut Ordinal.omega0 (FiniteCategoryModels.cubeObject n hn hCube))

def CrossFamilyIncomparabilityStatement : Prop :=
  (∃ hCube : IsCountablyBasedDIDomain (FiniteCategoryModels.CubeCarrier.{u} 3 (by decide)),
    FiniteDomainCut Ordinal.omega0 (FiniteCategoryModels.cubeObject 3 (by decide) hCube) ∧
    ¬ DomainCut 3 (FiniteCategoryModels.cubeObject 3 (by decide) hCube)) ∧
  (∃ hPower : IsCountablyBasedDIDomain NatPowersetCarrier.{u},
    DomainCut 3 (natPowersetObject hPower) ∧
    ¬ FiniteDomainCut Ordinal.omega0 (natPowersetObject hPower)) ∧
  ¬ (∀ D : CountablyBasedDIDomain.{u}, FiniteDomainCut Ordinal.omega0 D → DomainCut 3 D) ∧
  ¬ (∀ D : CountablyBasedDIDomain.{u}, DomainCut 3 D → FiniteDomainCut Ordinal.omega0 D)

end DIDomainClassification.Section04
