import DIDomainClassification.Support.ReflexiveDegreeCut

/-! Theorem 5.5, including membership in the asserted universal cut. -/
set_option autoImplicit false
universe u

namespace DIDomainClassification.Section05
open Section03.StableFunctionModels Subcategories

theorem reflexiveRetractIff (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) (D : CountablyBasedDIDomain.{u}) :
    HasStableRetraction (Core D) (Core E) ↔ objectDegree D ≤ objectDegree E :=
  ReflexiveDegreeCut.retract_iff E hNon hRef D

theorem reflexiveUniversal (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) : IsStableUniversal (DomainCut (objectDegree E+1)) E :=
  ReflexiveDegreeCut.universal E hNon hRef

theorem reflexiveClass : ReflexiveClassStatement.{u} := by
  intro E hNon hRef
  exact ⟨reflexiveRetractIff E hNon hRef, reflexiveUniversal E hNon hRef⟩

end DIDomainClassification.Section05
