import DIDomainClassification.Support.NoUniversalObjects

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section05

theorem noUniversalFinite : NoUniversalFiniteStatement.{u} := by
  intro α hα _hupper
  exact NoUniversalObjects.no_finite_universal α hα

end DIDomainClassification.Section05
