import DIDomainClassification.Section05.ReflexiveClassification
import DIDomainClassification.Section03.CandidateClosure
import DIDomainClassification.Support.GeneratedClassClosure

/-! The source's two implications, with actual universal membership and the
stated lower-degree condition retained. No universal-existence result is used. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section05
open Subcategories Section03.StableFunctionModels Section04.CutModels

theorem reflexivityImpliesUniversality (E : CountablyBasedDIDomain.{u})
    (hNon : Nontrivial (Core E)) (hRef : IsStableReflexive E) :
    IsStableUniversal (DomainCut (objectDegree E + 1)) E ∧ 2 ≤ objectDegree E :=
  ⟨(reflexiveClass E hNon hRef).2, ReflexiveRetractionClass.two_le_degree E hNon hRef⟩

theorem universalityImpliesReflexivity (E : CountablyBasedDIDomain.{u})
    (hU : IsStableUniversal (DomainCut (objectDegree E + 1)) E)
    (hTwo : 2 ≤ objectDegree E) : IsStableReflexive E := by
  let P : ObjectClass.{u} := DomainCut (objectDegree E + 1)
  have hThree : 3 ≤ objectDegree E + 1 := by
    simpa only [Order.succ_eq_add_one, OfNat.ofNat] using Order.succ_le_succ hTwo
  have hBound : objectDegree E + 1 ≤ firstUncountableBound.{u} + 1 := by
    simpa only [Order.succ_eq_add_one] using
      Order.succ_le_succ (objectDegree_le_firstUncountableBound E)
  have hP := Section03.candidateClosure.1 (objectDegree E + 1) ⟨hThree, hBound⟩
  have hAdmissible : IsAdmissibleGeneratedClass P := ⟨hP.2.1, hP.2.2.1, hP.2.2.2⟩
  have hUnit := GeneratedClassClosure.unitMem P hP.2.2.2 E hU.1
  have hExp := GeneratedClassClosure.nativeExponentialMem P hAdmissible hUnit E E hU.1 hU.1
  exact hU.2 (exponential E E) hExp

theorem reflexivityUniversality : ReflexivityUniversalityStatement.{u} := by
  intro E hNon
  exact ⟨reflexivityImpliesUniversality E hNon,
    fun h => universalityImpliesReflexivity E h.1 h.2⟩

end DIDomainClassification.Section05
