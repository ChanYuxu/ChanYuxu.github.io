import DIDomainClassification.Section04.CutRecovery
import DIDomainClassification.Section03.CandidateClosure
import DIDomainClassification.Section04.DistinctCuts

/-! Theorem 1.1, including its distinctness and whole-carrier assertions.
Only the proved cut recovery, candidate closure and separating witnesses enter. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section01
open Subcategories Section04.CutModels

theorem classificationCharacterization : ClassificationCharacterizationStatement.{u} := by
  intro P
  constructor
  · intro hP
    obtain ⟨hCases, _hFiniteIff⟩ := Section04.cutRecovery P hP
    rcases hCases with hFinite | hDomain
    · exact Or.inl hFinite.1
    · exact Or.inr hDomain.1
  · intro hCases
    rcases hCases with ⟨a, ha, hEq⟩ | ⟨a, ha, hEq⟩
    · rw [hEq]
      exact Section03.candidateClosure.2 a ha
    · rw [hEq]
      exact Section03.candidateClosure.1 a ha

theorem classificationDistinct : ClassificationDistinctStatement.{u} := by
  refine ⟨?_, ?_, ?_⟩
  · intro a b ha hb
    constructor
    · intro hEq
      apply le_antisymm
      · apply (Section04.distinctCuts.1 a b ha hb).mp
        intro D hD
        rw [← hEq]
        exact hD
      · apply (Section04.distinctCuts.1 b a hb ha).mp
        intro D hD
        rw [hEq]
        exact hD
    · intro hEq
      subst b
      rfl
  · intro a b ha hb
    constructor
    · intro hEq
      apply le_antisymm
      · apply (Section04.distinctCuts.2.1 a b ha hb).mp
        intro D hD
        rw [← hEq]
        exact hD
      · apply (Section04.distinctCuts.2.1 b a hb ha).mp
        intro D hD
        rw [hEq]
        exact hD
    · intro hEq
      subst b
      rfl
  · intro a b ha hb hEq
    apply Section04.distinctCuts.2.2.2 a b ha hb
    intro D hD
    rw [hEq]
    exact hD

theorem classificationCarrier : ClassificationCarrierStatement.{u} := by
  constructor
  · intro a _ha D hD
    exact hD.2
  · intro a ha
    refine ⟨OrdinalCutWitnesses.infinitePowerset.{u}, ?_, ?_⟩
    · change objectDegree OrdinalCutWitnesses.infinitePowerset.{u} < a
      rw [OrdinalCutWitnesses.infinitePowerset_degree]
      exact (by exact_mod_cast (show (0 : ℕ) < 3 by decide) :
        (0 : Ordinal.{u+1}) < 3).trans_le ha.1
    · rcases finite_or_infinite OrdinalCutWitnesses.infinitePowerset.{u} with hF | hI
      · exact False.elim (OrdinalCutWitnesses.infinitePowerset_not_finite hF)
      · exact hI

theorem classification : ClassificationStatement.{u} :=
  ⟨classificationCharacterization, classificationDistinct, classificationCarrier⟩

end DIDomainClassification.Section01
