import DIDomainClassification.Section02.StableCategory
import DIDomainClassification.Section02.RankDegree
import Mathlib.CategoryTheory.ObjectProperty.FullSubcategory

/-!
# The two source ordinal-cut families

Source: manuscript.tex:129--134, frozen source SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The finite family restricts the entire point carrier, not only compact or
maximal elements. These are the actual full subcategories; no cartesian
closedness, retraction closure or classification is assumed in their fields.
The explicit rank presentation lives one ordinal universe above the carrier.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Subcategories

open CategoryTheory

/-- The degree of the accepted underlying Scott domain. -/
noncomputable def objectDegree (D : CountablyBasedDIDomain.{u}) : Ordinal.{u+1} :=
  CoherenceDegree.coherenceDegree D.toDIDomainObject.isDIDomain.toIsScottDomain

/-- D_alpha: all actual ambient objects whose degree is strictly below alpha. -/
noncomputable def DomainCut (a : Ordinal.{u+1}) :
    ObjectProperty CountablyBasedDIDomain.{u} := fun D => objectDegree D < a

/-- F_alpha: the same cut, restricted to finite entire point carriers. -/
noncomputable def FiniteDomainCut (a : Ordinal.{u+1}) :
    ObjectProperty CountablyBasedDIDomain.{u} := fun D => DomainCut a D ∧ Finite D

noncomputable abbrev DomainCutCategory (a : Ordinal.{u+1}) :=
  (DomainCut a).FullSubcategory

noncomputable abbrev FiniteDomainCutCategory (a : Ordinal.{u+1}) :=
  (FiniteDomainCut a).FullSubcategory

end DIDomainClassification.Subcategories
