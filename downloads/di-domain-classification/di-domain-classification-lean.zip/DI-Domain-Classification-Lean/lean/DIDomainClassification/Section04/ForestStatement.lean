import DIDomainClassification.Section04.TreeRealisationStatements
import DIDomainClassification.Support.MinimalLowerConflicts
import Mathlib.Data.Finset.Sort

/-! Actual increasing-index forest DATA and its UNPROVED source proposition.
No caller supplies an enumeration, forest, label-occurrence bound or retraction.
The original event carrier need not be declared Countable; its basis is counted. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04.ForestModels
open Preliminaries EventStructures Trees FiniteCausalConflicts AdditionalSourceModels

variable {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A)

def sortedIndices (e : A → ℕ) (H : Set A) (hH : H ∈ causalConflictFamily E) : List ℕ :=
  ((conflict_member_finite E hH).toFinset.image e).sort (· ≤ ·)

def indexHead : List ℕ → Option ℕ
  | [] => none
  | x :: _ => some x

def indexLast (fallback : ℕ) (values : List ℕ) : ℕ :=
  values.foldl (fun _ x => x) fallback

def Roots (e : A → ℕ) : Type :=
  {i : ℕ // ∃ H ∈ causalConflictFamily E, ∃ a ∈ H, e a = i ∧ ∀ b ∈ H, i ≤ e b}

def nodeLists (e : A → ℕ) (i : Roots E e) : Set (List ℕ) :=
  {v | v ≠ [] ∧ ∃ (H : Set A) (hH : H ∈ causalConflictFamily E),
    indexHead (sortedIndices E e H hH) = some i.val ∧ v <+: sortedIndices E e H hH}

def IsInitialEnumeration (e : A → ℕ) : Prop :=
  Function.Injective e ∧
    (Set.range e = Set.univ ∨ ∃ N : ℕ, Set.range e = Set.Iio N)

/-- Pure source data only. The required exact node/root/last-label formulas and
all mathematical conclusions are outputs in the separate proposition below. -/
structure Data where
  enumerate : A → ℕ
  trees : Roots E enumerate → RootedPrefixTree ℕ
  label : ∀ i, (trees i).Node → A

abbrev ProductCarrier (F : Data E) : Type u :=
  Set A × ∀ i, TreeDomain (F.trees i)

def sectionCoordinate (F : Data E) (X : QualitativeCover E)
    (i : Roots E F.enumerate) : Set (F.trees i).Node :=
  {v | F.label i v ∈ X.val}

def retractionValues (F : Data E) (P : ProductCarrier E F) : Set A :=
  {a | a ∈ P.1 ∧ ∀ (i : Roots E F.enumerate) (v : (F.trees i).Node),
    F.label i v = a → v ∈ (P.2 i).val}

def occurrences (F : Data E) (a : A) : Set (Σ i, (F.trees i).Node) :=
  {x | F.label x.1 x.2 = a}

end DIDomainClassification.Section04.ForestModels

namespace DIDomainClassification.Section04
open Preliminaries EventStructures Trees CoherenceDegree AdditionalSourceModels
open ForestModels

def ForestStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)),
    ∃ (F : ForestModels.Data E),
      IsInitialEnumeration F.enumerate ∧
      (∀ i, (F.trees i).nodes = nodeLists E F.enumerate i ∧
        (F.trees i).rootList = [i.val]) ∧
      (∀ i (v : (F.trees i).Node),
        F.enumerate (F.label i v) = indexLast i.val v.val) ∧
      (∀ a : A, (occurrences E F a).Finite ∧
        (occurrences E F a).ncard ≤ 2 ^ F.enumerate a) ∧
      ∃ (hp : ∀ i, (F.trees i).IsProper)
        (hT : ∀ i, IsCountablyBasedDIDomain (TreeDomain (F.trees i)))
        (hH : ∀ i, IsCountablyBasedDIDomain (BranchCompletion (F.trees i) (hp i)))
        (C : QualitativeCoverClosure E)
        (hProduct : IsCountablyBasedDIDomain (ProductCarrier E F)),
        HasStableRetraction (causalConfigurationCore E) (qualitativeCoverCore E C) ∧
        (∃ (j : StableHom (qualitativeCoverCore E C)
            (cbObject (ProductCarrier E F) hProduct).toDIDomainObject)
          (R : StableHom (cbObject (ProductCarrier E F) hProduct).toDIDomainObject
            (qualitativeCoverCore E C)),
          (∀ X : QualitativeCover E, (j X).1 = X.val) ∧
          (∀ (X : QualitativeCover E) i, ((j X).2 i).val = sectionCoordinate E F X i) ∧
          (∀ P : ProductCarrier E F, (R P).val = retractionValues E F P) ∧
          Function.LeftInverse (R : ProductCarrier E F → QualitativeCover E)
            (j : QualitativeCover E → ProductCarrier E F)) ∧
        (∀ i, HasStableRetraction (treeCore (F.trees i) (hT i).1)
          (functionCore (completionCB (F.trees i) (hp i) (hH i)).toDIDomainObject
            (causalConfigurationCore E))) ∧
        coherenceDegree hE.1.toIsScottDomain = coherenceDegree C.domain.toIsScottDomain ∧
        coherenceDegree C.domain.toIsScottDomain =
          ⨆ i, Ordinal.lift.{u+1} (coherenceDegree (hT i).1.toIsScottDomain)

end DIDomainClassification.Section04
