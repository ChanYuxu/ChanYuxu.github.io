import DIDomainClassification.Section04.StableComparison
import DIDomainClassification.Section04.CutClassificationStatements
import DIDomainClassification.Section04.FiniteCategoryModels
import DIDomainClassification.Section04.BranchCompletionModels
import DIDomainClassification.Section04.CausalRetractionStatement
import DIDomainClassification.Section04.GeneratedCategory
import DIDomainClassification.Section02.BasicDomains
import DIDomainClassification.Section02.BPSStatement
import DIDomainClassification.Support.StableHomGeneralClosure
import DIDomainClassification.Support.FiniteOrderDomains
import DIDomainClassification.Section05.UniversalDefinition
import DIDomainClassification.Section05.StableReflexive
import Mathlib.Order.ULift

/-! Additional literal carriers and proof-certificate packaging only.
No new source conclusion is proved or supplied as an input model field.
All certificates in the source-facing propositions are existential outputs. -/
set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.Section04.AdditionalSourceModels
open Preliminaries EventStructures Trees
open Section03.StableFunctionModels FiniteCategoryModels

def cbObject (X : Type u) [PartialOrder X] (h : IsCountablyBasedDIDomain X) :
    CountablyBasedDIDomain.{u} := CountablyBasedDIDomain.ofType X h.1 h.2

def functionCore (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) :
    DIDomainObject.{max u v} :=
  DIDomainObject.ofType (StableHom D E) (StableExponentialClosure.stableHom_isDIDomain D E)

def functionValue (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (f : functionCore D E) : StableHom D E := f

def configurationCB {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)) : CountablyBasedDIDomain.{u} :=
  cbObject (Configuration E) hE

def treeCore {A : Type u} (T : RootedPrefixTree A) (h : IsDIDomain (TreeDomain T)) :
    DIDomainObject.{u} := DIDomainObject.ofType (TreeDomain T) h

def treeObject {A : Type u} (T : RootedPrefixTree A)
    (h : IsCountablyBasedDIDomain (TreeDomain T)) : CountablyBasedDIDomain.{u} :=
  cbObject (TreeDomain T) h

def completionCB {A : Type u} (T : RootedPrefixTree A) (hp : T.IsProper)
    (h : IsCountablyBasedDIDomain (BranchCompletion T hp)) : CountablyBasedDIDomain.{u} :=
  cbObject (BranchCompletion T hp) h

abbrev FlatCarrier : Type u := ULift.{u} BasicDomains.FlatNat
abbrev NatPowersetCarrier : Type u := ULift.{u} (Set ℕ)

def flatObject (h : IsCountablyBasedDIDomain FlatCarrier.{u}) : CountablyBasedDIDomain.{u} :=
  cbObject FlatCarrier h

def natPowersetObject (h : IsCountablyBasedDIDomain NatPowersetCarrier.{u}) :
    CountablyBasedDIDomain.{u} := cbObject NatPowersetCarrier h

abbrev UniversalBaseCarrier : Type u := ℕ → CubeCarrier.{u} 2 (by decide)

def universalBaseObject (h : IsCountablyBasedDIDomain UniversalBaseCarrier.{u}) :
    CountablyBasedDIDomain.{u} := cbObject UniversalBaseCarrier h

def universalTwoObject (h : IsCountablyBasedDIDomain UniversalBaseCarrier.{u}) :
    CountablyBasedDIDomain.{u} := exponential (universalBaseObject h) (universalBaseObject h)

def successorUniversalObject (h : IsCountablyBasedDIDomain UniversalBaseCarrier.{u})
    (E : CountablyBasedDIDomain.{u}) : CountablyBasedDIDomain.{u} :=
  exponential (universalTwoObject h) E

abbrev CubeIndex := {n : ℕ // 2 ≤ n}
abbrev CubeSequenceCarrier : Type u := ∀ n : CubeIndex, CubeCarrier.{u} n.val n.property

def cubeSequenceObject (h : IsCountablyBasedDIDomain CubeSequenceCarrier.{u}) :
    CountablyBasedDIDomain.{u} := cbObject CubeSequenceCarrier h

def SingletonClass : Subcategories.ObjectClass.{u} :=
  fun D => IsSingletonCarrier (Core D)

end DIDomainClassification.Section04.AdditionalSourceModels
