import DIDomainClassification.Section04.QualitativeCover

/-! The actual selected inherited order, exposed as data for the source
definition interface. No alternative order or domain closure is assumed. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.EventStructures.QualitativeCover

abbrev selectedOrder {A : Type u} [PartialOrder A]
    (E : FinitaryPrimeEventStructure A) : PartialOrder (QualitativeCover E) :=
  inferInstance

end DIDomainClassification.EventStructures.QualitativeCover
