import DIDomainClassification.Section04.SingleGenerators

/-!
Corollary 4.23 with the limit parameter restricted to the classification range.
The original unbounded statement and its counterexample remain in
`Section04.SingleGenerators`; they are not the statement proved here.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries Subcategories AdditionalSourceModels CutModels
open SingleGeneratorProof

/-- A limit cut in the nontrivial classification range is not singly generated. -/
def LimitNotSingleGeneratedBoundedStatement : Prop :=
  ∀ limitOrdinal : Ordinal.{u+1},
    3 ≤ limitOrdinal → limitOrdinal ≤ firstUncountableBound.{u} →
    Order.IsSuccLimit limitOrdinal →
    ¬ ∃ D : CountablyBasedDIDomain.{u}, IsGeneratedBy D (DomainCut limitOrdinal)

/-- The full revised corollary: the three positive clauses are unchanged. -/
def RevisedSingleGeneratorStatement : Prop :=
  SingleGeneratorNontrivialStatement.{u} ∧ SingleGeneratorSingletonStatement.{u} ∧
    FiniteOmegaNotSingleGeneratedStatement.{u} ∧
    LimitNotSingleGeneratedBoundedStatement.{u}

theorem limitNotSingleGeneratedBounded : LimitNotSingleGeneratedBoundedStatement.{u} := by
  intro limitOrdinal hThree hBound hLimit
  rintro ⟨D, hGenerated⟩
  have hParameters : DomainParameters limitOrdinal :=
    ⟨hThree, hBound.trans (Order.le_succ _)⟩
  have hDegree : objectDegree D < limitOrdinal := hGenerated.2.1
  have hMax : max 2 (objectDegree D) < limitOrdinal :=
    max_lt (CandidateCutClosure.two_lt_of_three_le hThree) hDegree
  have hParameterLt : parameter D < limitOrdinal := by
    simpa only [parameter, Order.succ_eq_add_one] using hLimit.succ_lt hMax
  have hCandidate := Section03.candidateClosure.1 (parameter D) (parameter_domain D)
  have hInclusion : ∀ E, DomainCut limitOrdinal E → DomainCut (parameter D) E :=
    hGenerated.2.2 (DomainCut (parameter D)) hCandidate.2 (degree_lt_parameter D)
  have hParameterLe : limitOrdinal ≤ parameter D :=
    (distinctCuts.2.1 limitOrdinal (parameter D) hParameters (parameter_domain D)).mp hInclusion
  exact (not_le_of_gt hParameterLt) hParameterLe

theorem singleGeneratorRevised : RevisedSingleGeneratorStatement.{u} :=
  ⟨singleGeneratorNontrivial, singleGeneratorSingleton,
    finiteOmegaNotSingleGenerated, limitNotSingleGeneratedBounded⟩

end DIDomainClassification.Section04
