import DIDomainClassification.Section04.BranchCompletionProperties
import DIDomainClassification.Section04.BranchExtensionStatement

/-! The specified extension from finite tree nodes to every entire infinite
branch, proved from actual directed suprema in the target dI-domain. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section04.BranchExtensionProof

open Preliminaries Trees OrderCore BranchCompletionModels PrefixCompletionDomain

variable {A : Type u} (T : RootedPrefixTree A) (E : DIDomainObject.{v})
  (a : T.Node → E) (ha : PrefixMonotone T E a)

include ha

theorem branchValues_directed (b : T.InfiniteBranch) :
    DirectedSet (a '' Set.range b.node) := by
  have hb : DirectedSet (Set.range b.node) := by
    refine ⟨⟨b.node 0, ⟨0, rfl⟩⟩, ?_⟩
    rintro x ⟨m, rfl⟩ y ⟨n, rfl⟩
    exact ⟨b.node (max m n), ⟨max m n, rfl⟩,
      b.monotone T (le_max_left _ _), b.monotone T (le_max_right _ _)⟩
  exact hb.image (fun _ _ h => ha _ _ h)

def branchValue (b : T.InfiniteBranch) : E :=
  Classical.choose (E.isDIDomain.toIsScottDomain.algebraic.1
    (a '' Set.range b.node) (branchValues_directed T E a ha b))

theorem branchValue_isLUB (b : T.InfiniteBranch) :
    IsLUB (a '' Set.range b.node) (branchValue T E a ha b) :=
  Classical.choose_spec (E.isDIDomain.toIsScottDomain.algebraic.1
    (a '' Set.range b.node) (branchValues_directed T E a ha b))

def extensionFun : H T → E
  | .inl w => a w
  | .inr b => branchValue T E a ha b

theorem extensionFun_finite (w : T.Node) :
    extensionFun T E a ha (PrefixCompletion.finite T w) = a w := rfl

theorem extensionFun_infinite (b : T.InfiniteBranch) :
    IsLUB (a '' Set.range b.node)
      (extensionFun T E a ha (PrefixCompletion.infinite T b)) :=
  branchValue_isLUB T E a ha b

theorem extensionFun_monotone : Monotone (extensionFun T E a ha) := by
  intro x y hxy
  rcases x with w | b <;> rcases y with z | c
  · exact ha _ _ hxy
  · exact (branchValue_isLUB T E a ha c).1 ⟨w, hxy, rfl⟩
  · exact False.elim hxy
  · change b = c at hxy
    subst c
    exact le_rfl

theorem finiteValues_isLUB (x : H T) :
    IsLUB (a '' {w : T.Node | PrefixCompletion.finite T w ≤ x})
      (extensionFun T E a ha x) := by
  rcases x with v | b
  · constructor
    · rintro z ⟨w, hw, rfl⟩
      exact ha _ _ hw
    · intro z hz
      refine hz ⟨v, ?_, rfl⟩
      change v ≤ v
      exact le_rfl
  · exact branchValue_isLUB T E a ha b

theorem extensionFun_scottContinuous
    (hfinite : ∀ w : T.Node, IsCompactElement (PrefixCompletion.finite T w)) :
    ScottContinuous (extensionFun T E a ha) := by
  intro S hSne hSdir x hx
  constructor
  · rintro z ⟨y, hy, rfl⟩
    exact extensionFun_monotone T E a ha (hx.1 hy)
  · intro z hz
    apply (finiteValues_isLUB T E a ha x).2
    rintro _ ⟨w, hwx, rfl⟩
    obtain ⟨y, hy, hwy⟩ := hfinite w ⟨hSne, hSdir⟩ hx hwx
    exact (extensionFun_monotone T E a ha hwy).trans (hz ⟨y, hy, rfl⟩)

end DIDomainClassification.Section04.BranchExtensionProof

namespace DIDomainClassification.Section04

open Preliminaries Trees BranchCompletionModels BranchExtensionProof

theorem branchExtension : BranchExtensionStatement.{u,v} := by
  intro A T hp
  obtain ⟨hH, _hcount, hfinite, _hbranches, _hcompacts, _hbelow, _hbounded,
    _hcomparable, _hpairwise, _hcoherent, hstable⟩ := branchCompletionProperties A T hp
  refine ⟨hH, ?_⟩
  intro E a ha
  let f : Completion T hp → E := extensionFun T E a ha
  have hf : ScottContinuous f := extensionFun_scottContinuous T E a ha hfinite
  refine ⟨StableHom.ofFunction f (hstable E f hf), ?_, ?_⟩
  · intro w
    rfl
  · intro b
    exact extensionFun_infinite T E a ha b

end DIDomainClassification.Section04
