import DIDomainClassification.Section04.AdditionalSourceModels
import DIDomainClassification.Support.LowerInterior

/-! Source917--926: the literal chain a<b with no inconsistent sets.
The chain and its consistency family are data; all domain, configuration,
map and counterexample claims are outputs in the UNPROVED proposition. -/
set_option autoImplicit false
noncomputable section

namespace DIDomainClassification.Section04.PointwiseNotStableModels
open EventStructures

def chainEvents : FinitaryPrimeEventStructure (Fin 2) where
  Con := Set.univ
  finite_principalIdeal _ := Set.toFinite _
  finite_of_mem_Con _ := Set.toFinite _
  empty_mem_Con := Set.mem_univ _
  singleton_mem_Con _ := Set.mem_univ _
  hereditary _ _ := Set.mem_univ _
  causal_closure _ _ _ := Set.mem_univ _

def compositeValues (Y : Set (Fin 2)) : Set (Fin 2) :=
  FiniteCausalConflicts.lowerInterior Y

end DIDomainClassification.Section04.PointwiseNotStableModels

namespace DIDomainClassification.Section04
open Preliminaries EventStructures AdditionalSourceModels PointwiseNotStableModels

def PointwiseNotStableStatement : Prop :=
  ∃ (C : QualitativeCoverClosure chainEvents)
    (hP : IsCountablyBasedDIDomain (Set (Fin 2)))
    (e : QualitativeCover chainEvents ≃o Set (Fin 2)),
    (∀ Y : QualitativeCover chainEvents, e Y = Y.val) ∧
    (∀ X : Set (Fin 2), IsConfiguration chainEvents X ↔
      X = ∅ ∨ X = {0} ∨ X = {0, 1}) ∧
    causalConflictFamily chainEvents = ∅ ∧
    let EC := causalConfigurationCore chainEvents
    let QC := qualitativeCoverCore chainEvents C
    let PC := (cbObject (Set (Fin 2)) hP).toDIDomainObject
    ∃ (s : StableHom EC QC) (r : StableHom QC EC) (q : StableHom PC PC),
      let qValues : Set (Fin 2) → Set (Fin 2) := q
      (∀ X : Configuration chainEvents, (s X).val = X.val) ∧
      (∀ Y : QualitativeCover chainEvents, (r Y).val = compositeValues Y.val) ∧
      Function.LeftInverse (r : QC → EC) (s : EC → QC) ∧
      (∀ Y : Set (Fin 2), qValues Y = compositeValues Y) ∧
      (∀ Y : QualitativeCover chainEvents, e (s (r Y)) = qValues (e Y)) ∧
      (∀ Y : Set (Fin 2), qValues Y ⊆ Y) ∧
      qValues ({1} : Set (Fin 2)) = ∅ ∧
      qValues ({0, 1} : Set (Fin 2)) = {0, 1} ∧
      qValues ({0, 1} : Set (Fin 2)) ∩ ({1} : Set (Fin 2)) = {1} ∧
      ¬ q ≤ StableHom.id PC

end DIDomainClassification.Section04
