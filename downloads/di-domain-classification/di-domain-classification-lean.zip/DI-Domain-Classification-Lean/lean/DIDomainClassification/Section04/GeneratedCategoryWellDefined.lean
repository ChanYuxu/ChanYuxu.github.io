import DIDomainClassification.Support.GeneratedClassClosure

/-!
Source2093 presupposes this least-category construction but supplies no proof.
These are exact public wrappers for a new proof of both registered implicit
claims, including singleton generators and using the literal raw intersection.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

open Subcategories GeneratedClassClosure

theorem generatedCategoryWellDefined : GeneratedCategoryWellDefinedStatement.{u} := by
  intro D
  exact ⟨generatedAdmissible D, generatedContainsGenerator D, generatedLeast D⟩

theorem generatedCategoryLeastExists : GeneratedCategoryLeastExistsStatement.{u} := by
  intro D
  exact ⟨GeneratedClass D, generatedCategoryWellDefined D⟩

end DIDomainClassification.Section04
