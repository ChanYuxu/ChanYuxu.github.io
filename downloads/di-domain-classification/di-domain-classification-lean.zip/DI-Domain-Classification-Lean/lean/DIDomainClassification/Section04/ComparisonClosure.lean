import DIDomainClassification.Support.ComparisonPowerset

/-! The six literal comparison-closure clauses, including empty products. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

theorem comparisonRetraction : ComparisonRetractionStatement.{u} :=
  ComparisonOperations.retraction_comparison

theorem comparisonTransitivity : ComparisonTransitivityStatement.{u} :=
  ComparisonCoherence.comparison_transitive

theorem comparisonCountableProduct : ComparisonCountableProductStatement.{u} :=
  ComparisonProducts.countable_product

theorem comparisonNatProduct : ComparisonNatProductStatement.{u} :=
  ComparisonProducts.nat_product

theorem comparisonFiniteProduct : ComparisonFiniteProductStatement.{u} :=
  ComparisonProducts.finite_product

theorem comparisonPowerset : ComparisonPowersetStatement.{u} :=
  ComparisonPowerset.powerset_comparison

theorem comparisonClosure : ComparisonClosureStatement.{u} :=
  ⟨comparisonRetraction,comparisonTransitivity,comparisonCountableProduct,
    comparisonNatProduct,comparisonFiniteProduct,comparisonPowerset⟩

end DIDomainClassification.Section04
