import DIDomainClassification.Section04.AdditionalSourceModels

/-! UNPROVED literal comparison-law, comparison-core and comparison-theorem
targets. No ordinary-retraction/degree equivalence is assumed. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04
open Preliminaries Subcategories AdditionalSourceModels
open Section03.StableFunctionModels

def ComparisonRetractionStatement : Prop :=
  ∀ D E : CountablyBasedDIDomain.{u},
    HasStableRetraction (Core D) (Core E) → StableComparison D E

def ComparisonTransitivityStatement : Prop :=
  ∀ D E F : CountablyBasedDIDomain.{u},
    StableComparison D E → StableComparison E F → StableComparison D F

def ComparisonCountableProductStatement : Prop :=
  ∀ (I : Type u) [Countable I] (D : I → CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{u}),
    (∀ i, StableComparison (D i) E) →
    ∃ h : IsCountablyBasedDIDomain (∀ i, Core (D i)),
      StableComparison (cbObject (∀ i, Core (D i)) h) E

/-- Literal natural-index products remain in the original carrier universe. -/
def ComparisonNatProductStatement : Prop :=
  ∀ (D : ℕ → CountablyBasedDIDomain.{u}) (E : CountablyBasedDIDomain.{u}),
    (∀ i, StableComparison (D i) E) →
    ∃ h : IsCountablyBasedDIDomain (∀ i, Core (D i)),
      StableComparison (cbObject (∀ i, Core (D i)) h) E

/-- Includes the empty finite product, as required by the source proof. -/
def ComparisonFiniteProductStatement : Prop :=
  ∀ (n : ℕ) (D : Fin n → CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{u}),
    (∀ i, StableComparison (D i) E) →
    ∃ h : IsCountablyBasedDIDomain (∀ i, Core (D i)),
      StableComparison (cbObject (∀ i, Core (D i)) h) E

def ComparisonPowersetStatement : Prop :=
  ∀ E : CountablyBasedDIDomain.{u}, Nontrivial (Core E) →
    ∃ h : IsCountablyBasedDIDomain NatPowersetCarrier.{u},
      StableComparison (natPowersetObject h) E

def ComparisonClosureStatement : Prop :=
  ComparisonRetractionStatement.{u} ∧ ComparisonTransitivityStatement.{u} ∧
    ComparisonCountableProductStatement.{u} ∧ ComparisonNatProductStatement.{u} ∧
    ComparisonFiniteProductStatement.{u} ∧ ComparisonPowersetStatement.{u}

def ComparisonCoreStatement : Prop :=
  ∀ D E : CountablyBasedDIDomain.{u}, Nontrivial (Core E) →
    objectDegree D ≤ objectDegree E → StableComparison D E

def ComparisonTheoremStatement : Prop :=
  ∀ D E : CountablyBasedDIDomain.{u}, Nontrivial (Core E) →
    (StableComparison D E ↔ objectDegree D ≤ max 2 (objectDegree E))

end DIDomainClassification.Section04
