import DIDomainClassification.Section04.PartitionRetractionModels
import DIDomainClassification.Section02.Retractions

/-! UNPROVED source lem:truncated-retractions994--1000 and its specified
partition/fixed-background constructions1002--1048. E is NOT assumed finite
or countably based; the event carrier A is arbitrary. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section04

open Preliminaries EventStructures FiniteCategoryModels PartitionRetractionModels

def TruncatedPartitionRetractionStatement : Prop :=
  ∀ (k m : ℕ) (hk : 2 ≤ k), k ≤ m →
    ∃ (hm : 2 ≤ m) (P : BlockPartition k m)
      (hK : IsCountablyBasedDIDomain (CubeCarrier.{u} k hk))
      (hM : IsCountablyBasedDIDomain (CubeCarrier.{u} m hm))
      (s : StableHom (cubeCore k hk hK.1) (cubeCore m hm hM.1))
      (r : StableHom (cubeCore m hm hM.1) (cubeCore k hk hK.1)),
      (∀ S, (s S).down.val = P.sectionValues S.down.val) ∧
      (∀ X, (r X).down.val = P.retractionValues X.down.val) ∧
      Function.LeftInverse (r : CubeCarrier m hm → CubeCarrier k hk)
        (s : CubeCarrier k hk → CubeCarrier m hm)

def TruncatedConflictRetractionStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (H : Set A), H ∈ causalConflictFamily E →
    ∃ (hm : 2 ≤ H.ncard) (U : Set A)
      (_hU : IsMinimallyInconsistentFiniteLowerSet E U) (e : Fin H.ncard ≃ H)
      (hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} H.ncard hm))
      (s : StableHom (cubeCore H.ncard hm hCube.1) (configurationCore E))
      (r : StableHom (configurationCore E) (cubeCore H.ncard hm hCube.1)),
      H = maximalEvents U ∧
      (∀ S, (s S).val = conflictSectionValues U H e S.down.val) ∧
      (∀ X, (r X).down.val = conflictRetractionValues e X.val) ∧
      Function.LeftInverse (r : Configuration E → CubeCarrier H.ncard hm)
        (s : CubeCarrier H.ncard hm → Configuration E)

def TruncatedRetractionsStatement : Prop :=
  TruncatedPartitionRetractionStatement.{u} ∧ TruncatedConflictRetractionStatement.{u}

end DIDomainClassification.Section04
