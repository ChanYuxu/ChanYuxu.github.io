import DIDomainClassification.Section04.CausalAntichainsStatement
import DIDomainClassification.Support.MinimalLowerConflicts

/-!
Source-facing proof of manuscript.tex839--855, frozen source SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The generic finite-lower-set proofs are reused without changing the original
event order, lower-subset minimality, finite cardinality, or empty-family cases.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Section04

open EventStructures FiniteCausalConflicts

/-- Exact accepted finite causal-conflict source statement. -/
theorem causalAntichains : CausalAntichainsStatement.{u} := by
  intro A _ E
  refine ⟨ConfigurationDomain.principal_mem_Con E, ?_, conflictFamily_isAntichain E⟩
  intro U hU
  exact ⟨maximalEvents_finite hU.1, maximalEvents_isAntichain U,
    finite_lower_eq_down_maximalEvents hU.1 hU.2.1,
    minimalLower_maximalEvents_card_ge_two E hU⟩

end DIDomainClassification.Section04

