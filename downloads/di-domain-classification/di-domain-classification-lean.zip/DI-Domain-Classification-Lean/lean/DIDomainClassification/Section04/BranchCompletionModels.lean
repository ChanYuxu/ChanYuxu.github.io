import DIDomainClassification.Section02.BranchCompletion
import DIDomainClassification.Section02.StableFunctionSpaces
import DIDomainClassification.Section02.MicCoherence

/-! Literal source Hτ and prefix-map models only. No completion-domain,
compactness, continuity, stability or extension theorem is proved here. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section04.BranchCompletionModels

open Preliminaries CoherenceDegree Trees

abbrev Completion {A : Type u} (T : RootedPrefixTree A) (hp : T.IsProper) :=
  BranchCompletion T hp

def completionObject {A : Type u} (T : RootedPrefixTree A) (hp : T.IsProper)
    (hH : IsDIDomain (Completion T hp)) : DIDomainObject.{u} :=
  DIDomainObject.ofType (Completion T hp) hH

theorem completionObject_order {A : Type u} (T : RootedPrefixTree A) (hp : T.IsProper)
    (hH : IsDIDomain (Completion T hp)) :
    (completionObject T hp hH).partialOrder = (inferInstance : PartialOrder (Completion T hp)) := rfl

def finiteNodes {A : Type u} (T : RootedPrefixTree A) (hp : T.IsProper) :
    Set (Completion T hp) := Set.range (BranchCompletion.finite T hp)

def branchPrefixes {A : Type u} (T : RootedPrefixTree A) (hp : T.IsProper)
    (b : T.InfiniteBranch) : Set (Completion T hp) :=
  BranchCompletion.finite T hp '' Set.range b.node

theorem branchPrefixes_mem_iff {A : Type u} (T : RootedPrefixTree A) (hp : T.IsProper)
    (b : T.InfiniteBranch) (x : Completion T hp) :
    x ∈ branchPrefixes T hp b ↔
      ∃ v ∈ Set.range b.node, BranchCompletion.finite T hp v = x := Iff.rfl

/-- Explicit accepted PREFIX relation, not an inherited order on lists. -/
def PrefixMonotone {A : Type u} (T : RootedPrefixTree A) (E : DIDomainObject.{v})
    (a : T.Node → E) : Prop :=
  ∀ v w : T.Node, v.val <+: w.val → a v ≤ a w

theorem prefixMonotone_iff {A : Type u} (T : RootedPrefixTree A) (E : DIDomainObject.{v})
    (a : T.Node → E) :
    PrefixMonotone T E a ↔
      @Monotone T.Node E (@RootedPrefixTree.instPartialOrderNode A T).toPreorder
        E.partialOrder.toPreorder a := Iff.rfl

end DIDomainClassification.Section04.BranchCompletionModels
