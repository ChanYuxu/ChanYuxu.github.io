import DIDomainClassification.Support.FiniteObstructionCubeDegree
import DIDomainClassification.Support.FiniteGeneratorCalculus
import DIDomainClassification.Support.OrdinalCutBounds
import DIDomainClassification.Section02.EventRepresentation
import DIDomainClassification.Section04.QualitativeCoherence

/-! Finite obstruction by stable retracts of the literal truncated cubes.
The causal conflicts are obtained from an actual event representation, not
assumed as input; the fixed predecessors are retained by the proved splits. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04
open Preliminaries EventStructures CoherenceDegree Subcategories
open Section03.StableFunctionModels FiniteCategoryModels
open FiniteGeneratorCalculus

theorem finiteObstruction : FiniteObstructionStatement.{u} := by
  classical
  intro D n hn
  have hTwo : 2 ≤ n + 1 := by omega
  let hCube := FiniteCubeRetractions.cubeCountablyBased.{u} (n+1) hTwo
  refine ⟨hCube, ?_⟩
  constructor
  · intro hDegree hSplit
    have hMono := objectDegree_mono_of_stable_retraction hSplit
    have hCubeDegree : objectDegree (cubeObject (n+1) hTwo hCube) =
        ((n+1 : ℕ) : Ordinal.{u+1}) :=
      FiniteObstructionCubeDegree.cube_degree (n+1) hTwo
    rw [hCubeDegree] at hMono
    have hBad := hMono.trans hDegree
    have hBadNat : n + 1 ≤ n := by exact_mod_cast hBad
    omega
  · intro hNoSplit
    by_contra hDegree
    obtain ⟨A, order, h⟩ := primeEventRepresentation (Core D)
      ⟨(Core D).isDIDomain, D.countableCompacts⟩
    letI : PartialOrder A := order
    obtain ⟨hCountable, E, ⟨e⟩⟩ := h
    letI : Countable A := hCountable
    let hE := configurationDomain A E
    have hNotBound : ¬ ∀ H ∈ causalConflictFamily E, H.ncard ≤ n := by
      intro hBound
      apply hDegree
      have hConf := (qualitativeCoherenceBound A E hE n hn).mpr hBound
      calc
        objectDegree D =
            coherenceDegree (configurationCore E).isDIDomain.toIsScottDomain :=
          FiniteGeneratorCalculus.degree_eq (Core D) (configurationCore E) e
        _ ≤ (n : Ordinal.{u+1}) := hConf
    push Not at hNotBound
    obtain ⟨H, hH, hLarge⟩ := hNotBound
    have hNM : n+1 ≤ H.ncard := by omega
    obtain ⟨hm, P, hK, hM, s₁, r₁, _hS₁, _hR₁, hLeft₁⟩ :=
      truncatedPartitionRetraction (n+1) H.ncard hTwo hNM
    obtain ⟨hCard, U, hU, eH, hC, s₂, r₂, _hMax, _hS₂, _hR₂, hLeft₂⟩ :=
      truncatedConflictRetraction A E H hH
    have hCubeConf : HasStableRetraction
        (cubeCore (n+1) hTwo hCube.1) (configurationCore E) :=
      FiniteGeneratorCalculus.trans ⟨s₁, r₁, hLeft₁⟩ ⟨s₂, r₂, hLeft₂⟩
    exact hNoSplit (FiniteGeneratorCalculus.trans hCubeConf
      (FiniteGeneratorCalculus.ofOrderIso (configurationCore E) (Core D) e.symm))

end DIDomainClassification.Section04
