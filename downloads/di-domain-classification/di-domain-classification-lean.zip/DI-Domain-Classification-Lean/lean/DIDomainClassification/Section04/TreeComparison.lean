import DIDomainClassification.Support.TreeComparisonProofs

/-! Exact source Proposition tree-comparison. Alphabets remain arbitrary in
the object universe; properness is not replaced by well-foundedness. The
second clause is proved by a documented direct infinite-spine argument. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries Trees AdditionalSourceModels
variable {A B : Type u}

theorem treeComparison_wellFounded (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (hp : T.IsProper) (hq : S.IsProper) (wfT : T.IsWellFounded) (wfS : S.IsWellFounded)
    (hRank : T.treeRank wfT ≤ S.treeRank wfS) :
    StableComparison
      (treeObject T (TreeRealisationConfigurations.treeCountablyBased T hp))
      (treeObject S (TreeRealisationConfigurations.treeCountablyBased S hq)) :=
  TreeComparisonProofs.wellFounded_comparison T S hp hq _ _ wfT wfS hRank

theorem treeComparison_infinite (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (hp : T.IsProper) (hq : S.IsProper) (hInf : S.HasInfiniteBranch) :
    StableComparison
      (treeObject T (TreeRealisationConfigurations.treeCountablyBased T hp))
      (treeObject S (TreeRealisationConfigurations.treeCountablyBased S hq)) :=
  TreeComparisonProofs.infinite_comparison T S hp hq _ _ hInf

theorem treeComparison : TreeComparisonStatement.{u} := by
  intro A B T S hp hq
  let hT := TreeRealisationConfigurations.treeCountablyBased T hp
  let hS := TreeRealisationConfigurations.treeCountablyBased S hq
  exact ⟨hT, hS, fun wfT wfS hRank =>
    TreeComparisonProofs.wellFounded_comparison T S hp hq hT hS wfT wfS hRank,
    TreeComparisonProofs.infinite_comparison T S hp hq hT hS⟩

end DIDomainClassification.Section04
