import DIDomainClassification.Support.FlatPowerRetraction

set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.Section04

theorem separatedSumGeneral : SeparatedSumGeneralStatement.{u,v,w} := by
  intro I _ _ H E
  refine ⟨SeparatedSumDomain.sum_countablyBased H,
    SeparatedSumHomOperations.family_countablyBased H E,
    SeparatedSumOrder.compact_sum_iff H,
    SeparatedSumDomain.sum_two_coherent H, ?_⟩
  refine ⟨SeparatedSumHomOperations.sectionMap H E,
    SeparatedSumHomOperations.restrictionMap H E, ?_, ?_,
    SeparatedSumHomOperations.maps_leftInverse H E⟩
  · intro f x
    rfl
  · intro g i x
    rfl

theorem countablePowersRetraction : CountablePowersRetractionStatement.{u} := by
  intro E
  refine ⟨FlatPowerRetraction.flat_countablyBased,
    FlatPowerRetraction.power_countablyBased E,
    FlatPowerRetraction.flat_two_coherent,
    FlatPowerRetraction.powerSection E, FlatPowerRetraction.retraction E,
    FlatPowerRetraction.section_apply E, FlatPowerRetraction.retraction_apply E,
    FlatPowerRetraction.leftInverse E⟩

theorem separatedSum : SeparatedSumStatement.{u,v,w} :=
  ⟨separatedSumGeneral, countablePowersRetraction⟩

end DIDomainClassification.Section04
