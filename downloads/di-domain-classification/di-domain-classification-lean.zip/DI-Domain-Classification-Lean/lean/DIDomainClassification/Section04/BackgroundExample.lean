import DIDomainClassification.Support.FiniteBackgroundExample

set_option autoImplicit false
noncomputable section

namespace DIDomainClassification.Section04

theorem backgroundExample : BackgroundExampleStatement := by
  open FiniteBackgroundExample in
    exact ⟨eventStructure, rfl, conflictFamily, closure_intersection, closure_empty,
      closure_intersection_ne_empty, cubeCountablyBased, closureMap, (fun _ => rfl),
      closure_not_stable, stableSection, stableRetraction, stableSection_values,
      stableRetraction_values, leftInverse⟩

end DIDomainClassification.Section04
