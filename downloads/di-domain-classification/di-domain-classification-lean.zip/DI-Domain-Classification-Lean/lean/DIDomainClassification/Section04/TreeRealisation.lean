import DIDomainClassification.Support.TreeRealisationOperators

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries EventStructures Trees
open TreeRealisationConfigurations TreeRealisationOperators

theorem treeRealisation : TreeRealisationStatement.{u,v} := by
  intro A _ E B T hp L hL
  refine ⟨treeCountablyBased T hp, completionCountablyBased T hp,
    stableSection E T L hL hp, stableRetraction E T L hL hp, ?_, ?_, ?_, leftInverse E T L hL hp⟩
  · intro X z
    exact section_finite E T L hL hp X z
  · intro X b
    exact section_infinite E T L hL hp X b
  · intro f
    rfl

end DIDomainClassification.Section04
