import DIDomainClassification.Section04.FiniteCategoryModels
import DIDomainClassification.Section04.CausalConflicts
import Mathlib.Data.Set.Card

/-! The ACTUAL nonempty-block partition and causal-background formulas.
No map well-definedness/stability/left-inverse claim is proved here. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section04.PartitionRetractionModels

open EventStructures

/-- A partition into k nonempty blocks, represented by its surjective owner.
Only defining DATA are stored, never a retraction conclusion. -/
structure BlockPartition (k m : ℕ) where
  owner : Fin m → Fin k
  onto : Function.Surjective owner

def BlockPartition.block {k m : ℕ} (P : BlockPartition k m) (i : Fin k) : Set (Fin m) :=
  P.owner ⁻¹' {i}

def BlockPartition.sectionValues {k m : ℕ} (P : BlockPartition k m)
    (S : Set (Fin k)) : Set (Fin m) := P.owner ⁻¹' S

def BlockPartition.retractionValues {k m : ℕ} (P : BlockPartition k m)
    (X : Set (Fin m)) : Set (Fin k) := {i | P.block i ⊆ X}

theorem BlockPartition.section_mem_iff {k m : ℕ} (P : BlockPartition k m)
    (S : Set (Fin k)) (j : Fin m) : j ∈ P.sectionValues S ↔ P.owner j ∈ S := Iff.rfl

theorem BlockPartition.retraction_mem_iff {k m : ℕ} (P : BlockPartition k m)
    (X : Set (Fin m)) (i : Fin k) : i ∈ P.retractionValues X ↔ P.block i ⊆ X := Iff.rfl

def conflictSectionValues {A : Type u} (U H : Set A) (e : Fin H.ncard ≃ H)
    (S : Set (Fin H.ncard)) : Set A :=
  (U \ H) ∪ (fun i => (e i).val) '' S

def conflictRetractionValues {A : Type u} {H : Set A} (e : Fin H.ncard ≃ H)
    (X : Set A) : Set (Fin H.ncard) := {i | (e i).val ∈ X}

end DIDomainClassification.Section04.PartitionRetractionModels
