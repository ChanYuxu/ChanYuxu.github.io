import DIDomainClassification.Section04.AdditionalSourceModels
import DIDomainClassification.Section02.BinaryForbiddenCliqueStatement

/-! Literal minimal-trigger graph and predicate formulas. The stable order,
not the pointwise order, is identified with inclusion of ALL cliques. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04.PredicateModels
open Preliminaries CoherenceDegree
open Section03.StableFunctionModels
open Section02.BinaryCliqueModels AdditionalSourceModels

def graph (D : CountablyBasedDIDomain.{u}) : SimpleGraph ↥(CompactElements (Core D)) where
  Adj k l := k ≠ l ∧ ¬ Compatible k.val l.val
  symm := by
    intro k l h
    refine ⟨h.1.symm, ?_⟩
    rintro ⟨b, hl, hk⟩
    exact h.2 ⟨b, hk, hl⟩
  loopless := ⟨fun _ h => h.1 rfl⟩

def minimalTriggers (D : CountablyBasedDIDomain.{u})
    (f : StableSpace D FiniteOrderDomains.twoObject.{u}) :
    Set ↥(CompactElements (Core D)) :=
  {k | f k.val = FiniteOrderDomains.one ∧
    ∀ l : Core D, l < k.val → f l = FiniteOrderDomains.zero}

def fromCliqueValues (D : CountablyBasedDIDomain.{u})
    (M : CliqueCarrier (graph D)) (x : Core D) : FiniteOrderDomains.TwoCarrier.{u} := by
  classical
  exact if ∃ k : ↥(CompactElements (Core D)), k ∈ M.val ∧ k.val ≤ x
    then FiniteOrderDomains.one else FiniteOrderDomains.zero

end DIDomainClassification.Section04.PredicateModels

namespace DIDomainClassification.Section04
open CategoryTheory Preliminaries CoherenceDegree AdditionalSourceModels PredicateModels
open Section03.StableFunctionModels Section02.BinaryCliqueModels

def PredicateReconstructionStatement : Prop :=
  ∀ (D : CountablyBasedDIDomain.{u}) (f : StableSpace D FiniteOrderDomains.twoObject.{u})
    (x : Core D), f x = FiniteOrderDomains.one ↔
      ∃ k ∈ minimalTriggers D f, k.val ≤ x

def PredicatesStatement : Prop :=
  ∀ D : CountablyBasedDIDomain.{u},
    ∃ hClique : IsCountablyBasedDIDomain (CliqueCarrier (graph D)),
      ∃ e : exponential D FiniteOrderDomains.twoObject.{u} ≅
          cbObject (CliqueCarrier (graph D)) hClique,
        (∀ f : StableSpace D FiniteOrderDomains.twoObject.{u},
          (CountablyBasedDIDomain.toStableHom e.hom f).val = minimalTriggers D f) ∧
        (∀ (M : CliqueCarrier (graph D)) (x : Core D),
          let f : StableSpace D FiniteOrderDomains.twoObject.{u} :=
            CountablyBasedDIDomain.toStableHom e.inv M
          f x = fromCliqueValues D M x) ∧
        (∀ f g : StableSpace D FiniteOrderDomains.twoObject.{u},
          f ≤ g ↔ minimalTriggers D f ⊆ minimalTriggers D g) ∧
        (∀ (f : StableSpace D FiniteOrderDomains.twoObject.{u}) (x : Core D),
          f x = FiniteOrderDomains.one ↔ ∃ k ∈ minimalTriggers D f, k.val ≤ x)

end DIDomainClassification.Section04
