import DIDomainClassification.Support.QualitativeCausalCoherence

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

theorem qualitativeCoherenceBound : QualitativeCoherenceBoundStatement.{u} := by
  intro A _ E hE n hn
  exact QualitativeCausalCoherence.degree_bound E hE n hn

theorem qualitativeEmptyFamily : QualitativeEmptyFamilyStatement.{u} := by
  intro A _ E hE hEmpty
  exact QualitativeCausalCoherence.empty_degree E hE hEmpty

theorem qualitativeFiniteMaximum : QualitativeFiniteMaximumStatement.{u} := by
  intro A _ E hE hNonempty hBound
  exact QualitativeCausalCoherence.attained_finite_maximum E hE hNonempty hBound

theorem qualitativeCoherence : QualitativeCoherenceStatement.{u} :=
  ⟨qualitativeCoherenceBound, qualitativeEmptyFamily, qualitativeFiniteMaximum⟩

end DIDomainClassification.Section04
