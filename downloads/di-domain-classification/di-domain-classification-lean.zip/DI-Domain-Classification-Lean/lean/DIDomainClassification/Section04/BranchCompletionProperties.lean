import DIDomainClassification.Support.PrefixCompletionDomain

/-! All assertions of the source paragraph introducing Hτ. The literal finite
nodes and full infinite branches are used throughout. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries Trees BranchCompletionModels PrefixCompletionDomain

theorem branchCompletionProperties : BranchCompletionPropertiesStatement.{u,v} := by
  intro A T hp
  refine ⟨PrefixCompletionDomain.isDIDomain T,
    compact_countable T, finite_compact T, ?_, compact_set_eq T,
    below_finite_finite T, ?_, ?_, ?_, two_coherent T, ?_⟩
  · intro b
    exact ⟨branch_prefixes_isLUB T b, infinite_not_compact T b⟩
  · intro S hS
    obtain ⟨z, hz⟩ := hS
    have hchain : IsChain (· ≤ ·) S := by
      intro x hx y hy _
      exact comparable_below T (hz hx) (hz hy)
    obtain ⟨c, hc, hSc⟩ := hchain.exists_maxChain
    exact ⟨c, hc, hSc, chain_has_lub T hchain⟩
  · intro x y hxy
    exact compatible_comparable T hxy
  · intro S hS
    exact ⟨pairwise_chain T hS, chain_has_lub T (pairwise_chain T hS)⟩
  · intro E f hf
    exact continuous_isStable T (PrefixCompletionDomain.isDIDomain T) E f hf

end DIDomainClassification.Section04
