import DIDomainClassification.Support.FiniteCausalConflictRetractions

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section04

theorem truncatedPartitionRetraction : TruncatedPartitionRetractionStatement.{u} :=
  FiniteCubeRetractions.partitionRetraction

theorem truncatedConflictRetraction : TruncatedConflictRetractionStatement.{u} :=
  FiniteCausalConflictRetractions.conflictRetraction

theorem truncatedRetractions : TruncatedRetractionsStatement.{u} :=
  ⟨truncatedPartitionRetraction, truncatedConflictRetraction⟩

end DIDomainClassification.Section04
