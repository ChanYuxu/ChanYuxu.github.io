import DIDomainClassification.Section03.StableFunctionModels
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section02.MicCoherence

/-! Literal Definition4.12, manuscript.tex1455--1468 ONLY. No finite/countable
product, finite-exponent or generated-category equivalence is part of this
definition or proved here. The exponential uses the SAME true closure. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section04

open CoherenceDegree Section03.StableFunctionModels

def StableComparison (D E : CountablyBasedDIDomain.{u}) : Prop :=
  ∃ H : CountablyBasedDIDomain.{u},
    IsNCoherent (Core H).isDIDomain.toIsScottDomain 2 (by decide) ∧
      HasStableRetraction (Core D) (Core (exponential H E))

theorem stableComparison_iff (D E : CountablyBasedDIDomain.{u}) :
    StableComparison D E ↔
      ∃ H : CountablyBasedDIDomain.{u},
        IsNCoherent (Core H).isDIDomain.toIsScottDomain 2 (by decide) ∧
          HasStableRetraction (Core D) (Core (exponential H E)) := Iff.rfl

end DIDomainClassification.Section04
