import DIDomainClassification.Section02.SubcategoryConventions
import DIDomainClassification.Section02.Retractions

/-! Literal least-category definition manuscript.tex2093. The raw intersection
is NOT asserted intrinsically CCC, admissible or inhabited as a least object.
Its well-definedness is a SEPARATE UNPROVED source-implicit obligation. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Subcategories

def IsStableRetractClosed (P : ObjectClass.{u}) : Prop :=
  ∀ D E : CountablyBasedDIDomain.{u}, P E →
    HasStableRetraction D.toDIDomainObject E.toDIDomainObject → P D

def IsAdmissibleGeneratedClass (P : ObjectClass.{u}) : Prop :=
  IsReplete P ∧ IsIntrinsicallyCartesianClosed P ∧ IsStableRetractClosed P

/-- Raw intersection membership only, over EVERY admissible object class.
Fullness is the existing native FullStableSubcategory, not a stored field. -/
def GeneratedClass (D : CountablyBasedDIDomain.{u}) : ObjectClass.{u} :=
  fun E => ∀ P : ObjectClass.{u}, IsAdmissibleGeneratedClass P → P D → P E

/-- The actual FULL stable subcategory on that raw intersection predicate.
This abbreviation supplies no cartesian-closedness or closure theorem. -/
abbrev GeneratedFullSubcategory (D : CountablyBasedDIDomain.{u}) :=
  FullStableSubcategory (GeneratedClass D)

/-- Exact least universal property, not an assumed existence package. -/
def IsGeneratedBy (D : CountablyBasedDIDomain.{u}) (P : ObjectClass.{u}) : Prop :=
  IsAdmissibleGeneratedClass P ∧ P D ∧
    ∀ Q : ObjectClass.{u}, IsAdmissibleGeneratedClass Q → Q D → ∀ E, P E → Q E

theorem generatedClass_mem_iff (D E : CountablyBasedDIDomain.{u}) :
    GeneratedClass D E ↔
      ∀ P : ObjectClass.{u}, IsAdmissibleGeneratedClass P → P D → P E := Iff.rfl

theorem isGeneratedBy_iff (D : CountablyBasedDIDomain.{u}) (P : ObjectClass.{u}) :
    IsGeneratedBy D P ↔
      IsAdmissibleGeneratedClass P ∧ P D ∧
        ∀ Q : ObjectClass.{u}, IsAdmissibleGeneratedClass Q → Q D → ∀ E, P E → Q E := Iff.rfl

end DIDomainClassification.Subcategories

namespace DIDomainClassification.Section04

open Subcategories

/-- Source2093's implicit well-definedness/least-existence claims. These have
NOT been proved by defining GeneratedClass. No Nontrivial D premise is added.
The coordinator must register the missing unnumbered obligation in a reviewed
graph amendment; this file does not mutate the graph or assert acceptance. -/
def GeneratedCategoryWellDefinedStatement : Prop :=
  ∀ D : CountablyBasedDIDomain.{u}, IsGeneratedBy D (GeneratedClass D)

def GeneratedCategoryLeastExistsStatement : Prop :=
  ∀ D : CountablyBasedDIDomain.{u}, ∃ P : ObjectClass.{u}, IsGeneratedBy D P

end DIDomainClassification.Section04
