import DIDomainClassification.Section04.CutClassificationStatements
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Section02.DegreeRealizability

/-! All six assertions of Corollary 4.22, with their exact source ranges. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries CoherenceDegree Subcategories

theorem domainCut_coherence (n : ℕ) (hn : 2 ≤ n) :
    DomainCut ((n : Ordinal.{u+1}) + 1) =
      (fun D : CountablyBasedDIDomain.{u} =>
        IsNCoherent D.toDIDomainObject.isDIDomain.toIsScottDomain n hn) := by
  funext D
  apply propext
  change coherenceDegree D.toDIDomainObject.isDIDomain.toIsScottDomain <
    (n : Ordinal.{u+1}) + 1 ↔ _
  rw [← Order.succ_eq_add_one, Order.lt_succ_iff]
  exact Section02.bps.2.2.2.2.2.2 D
    D.toDIDomainObject.isDIDomain.toIsScottDomain D.countableCompacts n hn

theorem finiteCut_coherence (n : ℕ) (hn : 2 ≤ n) :
    FiniteDomainCut ((n : Ordinal.{u+1}) + 1) =
      (fun D : CountablyBasedDIDomain.{u} =>
        Finite D ∧ IsNCoherent D.toDIDomainObject.isDIDomain.toIsScottDomain n hn) := by
  funext D
  apply propext
  change DomainCut ((n : Ordinal.{u+1}) + 1) D ∧ Finite D ↔ _
  rw [domainCut_coherence n hn]
  exact and_comm

theorem below_omega_iff (a : Ordinal.{u+1}) :
    a < Ordinal.omega0 ↔ ∃ n : ℕ, 2 ≤ n ∧ a < (n : Ordinal.{u+1}) + 1 := by
  constructor
  · intro ha
    obtain ⟨m, rfl⟩ := Ordinal.lt_omega0.mp ha
    refine ⟨max 2 m, le_max_left _ _, ?_⟩
    rw [← Order.succ_eq_add_one, Order.lt_succ_iff]
    exact_mod_cast le_max_right 2 m
  · rintro ⟨n, _hn, ha⟩
    have hn : (n : Ordinal.{u+1}) + 1 < Ordinal.omega0 := by
      simpa only [Nat.cast_add, Nat.cast_one] using Ordinal.natCast_lt_omega0 (n + 1)
    exact ha.trans hn

theorem domainCut_omega :
    DomainCut Ordinal.omega0 =
      (fun D : CountablyBasedDIDomain.{u} =>
        ∃ n : ℕ, 2 ≤ n ∧ DomainCut ((n : Ordinal.{u+1}) + 1) D) := by
  funext D
  exact propext (below_omega_iff (objectDegree D))

theorem finiteCut_omega :
    FiniteDomainCut Ordinal.omega0 =
      (fun D : CountablyBasedDIDomain.{u} =>
        ∃ n : ℕ, 2 ≤ n ∧ FiniteDomainCut ((n : Ordinal.{u+1}) + 1) D) := by
  funext D
  apply propext
  change (objectDegree D < Ordinal.omega0 ∧ Finite D) ↔
    ∃ n : ℕ, 2 ≤ n ∧ objectDegree D < (n : Ordinal.{u+1}) + 1 ∧ Finite D
  constructor
  · rintro ⟨hD, hfinite⟩
    obtain ⟨n, hn, hDn⟩ := (below_omega_iff (objectDegree D)).mp hD
    exact ⟨n, hn, hDn, hfinite⟩
  · rintro ⟨n, hn, hDn, hfinite⟩
    exact ⟨(below_omega_iff (objectDegree D)).mpr ⟨n, hn, hDn⟩, hfinite⟩

theorem omegaCut_subset_succ (D : CountablyBasedDIDomain.{u}) :
    DomainCut Ordinal.omega0 D → DomainCut (Ordinal.omega0 + 1) D := by
  intro hD
  exact hD.trans_le (by simpa only [Order.succ_eq_add_one] using Order.le_succ Ordinal.omega0)

theorem omegaCut_strictWitness :
    ∃ D : CountablyBasedDIDomain.{u},
      DomainCut (Ordinal.omega0 + 1) D ∧ ¬ DomainCut Ordinal.omega0 D := by
  have hcount : (Ordinal.omega0.{u+1}).card ≤ Cardinal.aleph0 := by simp
  have hωlt : Ordinal.omega0.{u+1} < Section02.DegreeRealizationModels.firstUncountable.{u} :=
    Cardinal.card_le_iff.mp hcount
  obtain ⟨D, hD⟩ := Section02.degreeRealizability.1 Ordinal.omega0
    (Or.inr ⟨(Ordinal.natCast_lt_omega0 2).le, hωlt.le⟩)
  refine ⟨D, ?_, ?_⟩
  · change objectDegree D < Ordinal.omega0 + 1
    rw [hD]
    simpa only [Order.succ_eq_add_one] using Order.lt_succ Ordinal.omega0
  · change ¬ objectDegree D < Ordinal.omega0
    rw [hD]
    exact lt_irrefl _

theorem finiteLayers : FiniteLayersStatement.{u} :=
  ⟨finiteCut_coherence, domainCut_coherence, finiteCut_omega,
    domainCut_omega, omegaCut_subset_succ, omegaCut_strictWitness⟩

end DIDomainClassification.Section04
