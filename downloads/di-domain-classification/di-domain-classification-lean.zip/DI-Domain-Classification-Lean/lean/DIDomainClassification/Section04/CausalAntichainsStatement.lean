import DIDomainClassification.Section04.CausalConflicts
import Mathlib.Order.Antichain
import Mathlib.Data.Set.Card

/-! Source specifications for the finite causal-conflict assertions.
manuscript.tex839--855, SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
No theorem in this module supplies a proof of these assertions. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section04

open EventStructures

def CausalAntichainsStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A),
    (∀ a : A, Set.Iic a ∈ E.Con) ∧
    (∀ U : Set A, IsMinimallyInconsistentFiniteLowerSet E U →
      (maximalEvents U).Finite ∧
      IsAntichain (· ≤ ·) (maximalEvents U) ∧
      U = {a : A | ∃ b ∈ maximalEvents U, a ≤ b} ∧
      2 ≤ (maximalEvents U).ncard) ∧
    IsAntichain (· ⊆ ·) (causalConflictFamily E)

end DIDomainClassification.Section04
