import DIDomainClassification.Section04.CausalConflicts

/-!
Step 3 candidate only: literal source qualitative-cover carrier.
Source manuscript.tex857--862, SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
No closure, well-definedness of a retraction, or source theorem is proved.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

variable {A : Type u} [PartialOrder A]

/-- All arbitrary event subsets avoiding every actual causal-conflict member.
No lowerness, finiteness, nonemptiness, countability, or interior-consistency
condition is imposed on an element of this carrier. -/
abbrev QualitativeCover (E : FinitaryPrimeEventStructure A) : Type u :=
  {Y : Set A // ∀ H ∈ causalConflictFamily E, ¬ H ⊆ Y}

namespace QualitativeCover

theorem avoids {E : FinitaryPrimeEventStructure A} (Y : QualitativeCover E) :
    ∀ H ∈ causalConflictFamily E, ¬ H ⊆ Y.val := Y.property

theorem le_iff_subset {E : FinitaryPrimeEventStructure A} (X Y : QualitativeCover E) :
    X ≤ Y ↔ X.val ⊆ Y.val := Iff.rfl

/-- Certify the actual selected partial order, not only the bare LE coercion. -/
theorem selectedPartialOrder_le_iff {E : FinitaryPrimeEventStructure A}
    (X Y : QualitativeCover E) :
    @LE.le (QualitativeCover E) (inferInstance : PartialOrder (QualitativeCover E)).toLE X Y ↔
      X.val ⊆ Y.val := Iff.rfl

theorem ext {E : FinitaryPrimeEventStructure A} {X Y : QualitativeCover E}
    (h : X.val = Y.val) : X = Y := Subtype.ext h

end QualitativeCover
end DIDomainClassification.EventStructures


