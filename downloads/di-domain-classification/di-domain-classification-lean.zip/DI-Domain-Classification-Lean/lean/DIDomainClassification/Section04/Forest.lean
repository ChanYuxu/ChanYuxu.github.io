import DIDomainClassification.Support.ForestDegree

/-! Proposition 4.10: the literal increasing-index forest, its stable
retractions and both coherence-degree equalities, including the empty family. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04
open Preliminaries EventStructures Trees CoherenceDegree
open AdditionalSourceModels ForestModels

theorem forest : ForestStatement.{u} := by
  intro A _ E hE
  letI : Countable A := ForestEnumeration.events_countable E hE
  obtain ⟨e, he, hrange⟩ := ForestEnumeration.exists_initial_enumeration (A := A)
  let F := ForestPrefixTrees.data E e
  let hp : ∀ i, (F.trees i).IsProper := ForestPrefixTrees.proper E e he
  let hT : ∀ i, IsCountablyBasedDIDomain (TreeDomain (F.trees i)) :=
    ForestProductMaps.treeCB E e he
  let hH : ∀ i, IsCountablyBasedDIDomain (BranchCompletion (F.trees i) (hp i)) :=
    fun i => TreeRealisationConfigurations.completionCountablyBased (F.trees i) (hp i)
  obtain ⟨C, s, r, _hsv, _hrv, hleft, _hbelow⟩ := causalRetraction A E
  have hCausal : HasStableRetraction (causalConfigurationCore E) (qualitativeCoverCore E C) :=
    ⟨s, r, hleft⟩
  let hProduct := ForestProductMaps.productCB E e he
  have hdegree := ForestDegree.degree_equalities E e he hE C hProduct hCausal
  refine ⟨F, ⟨he, hrange⟩, ?_, ?_, ?_, hp, hT, hH, C, hProduct, hCausal, ?_, ?_, ?_, ?_⟩
  · intro i
    exact ⟨rfl, rfl⟩
  · intro i v
    exact ForestPrefixTrees.enumerate_label E e i v
  · intro a
    exact ForestOccurrenceBounds.finite_and_bound E e a
  · exact ⟨ForestProductMaps.sectionHom E e he C hProduct,
      ForestProductMaps.retraction E e he C hProduct,
      ForestProductMaps.section_first_values E e he C hProduct,
      ForestProductMaps.section_coordinate_values E e he C hProduct,
      ForestProductMaps.retraction_values E e he C hProduct,
      ForestProductMaps.native_leftInverse E e he C hProduct⟩
  · intro i
    obtain ⟨_hTi, _hHi, hret⟩ := ForestPrefixTrees.realised_tree E e he i
    exact hret
  · exact hdegree.1
  · exact hdegree.2

end DIDomainClassification.Section04
