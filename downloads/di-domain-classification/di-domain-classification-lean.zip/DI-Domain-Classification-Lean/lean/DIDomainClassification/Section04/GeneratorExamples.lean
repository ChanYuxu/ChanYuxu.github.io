import DIDomainClassification.Support.GeneratorExamplesProofs

/-! The exact source-facing five-part statement of Example 4.24. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04
open Preliminaries Subcategories CoherenceDegree AdditionalSourceModels
open Section03.StableFunctionModels

theorem generatorExamples : GeneratorExamplesStatement.{u} := by
  refine ⟨GeneratorExamplesProof.two_generated, ?_, ?_, ?_, ?_⟩
  · intro n hn
    exact ⟨FiniteCubeRetractions.cubeCountablyBased n hn,
      GeneratorExamplesProof.cube_generated n hn⟩
  · exact ⟨FlatPowerRetraction.flat_countablyBased, GeneratorExamplesProof.flat_generated⟩
  · exact ⟨GeneratorExamplesProof.sequenceCertificate, GeneratorExamplesProof.sequence_degree,
      GeneratorExamplesProof.sequence_generated, GeneratorExamplesProof.sequence_not_below_omega⟩
  · intro n hn
    exact ⟨FiniteCubeRetractions.cubeCountablyBased n hn,
      GeneratorExamplesProof.cube_below_omega n hn⟩

end DIDomainClassification.Section04

