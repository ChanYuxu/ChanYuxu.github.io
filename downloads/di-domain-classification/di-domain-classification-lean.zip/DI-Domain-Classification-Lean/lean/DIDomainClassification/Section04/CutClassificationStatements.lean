import DIDomainClassification.Section01.OrdinalCuts
import DIDomainClassification.Section02.SubcategoryConventions
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section03.StableFunctionModels
import DIDomainClassification.Support.OrdinalCutBounds

/-!
Unproved interfaces for source labels cor:function-degree-upper,
cor:candidate-closure, prop:cut-recovery, prop:distinct-cuts,
thm:classification and cor:finite-layers. Source manuscript.tex SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The full subcategories retain their intrinsic categorical definition.
No closure, classification, ordinal realization or universal-object proof is
stored in a model field. This is a private Step3 candidate only.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04.CutModels
open Subcategories

def FiniteParameters (α : Ordinal.{u+1}) : Prop :=
  3 ≤ α ∧ α ≤ Ordinal.omega0

def DomainParameters (α : Ordinal.{u+1}) : Prop :=
  3 ≤ α ∧ α ≤ firstUncountableBound.{u} + 1

def RetractClosed (P : ObjectClass.{u}) : Prop :=
  ∀ D E : CountablyBasedDIDomain.{u}, P E →
    HasStableRetraction D.toDIDomainObject E.toDIDomainObject → P D

/-- Fullness is literal FullStableSubcategory; CCC remains intrinsic. -/
def CategoryHypotheses (P : ObjectClass.{u}) : Prop :=
  IsNontrivial P ∧ IsReplete P ∧ IsIntrinsicallyCartesianClosed P ∧ RetractClosed P

def FiniteAlternative (P : ObjectClass.{u}) : Prop :=
  ∃ α : Ordinal.{u+1}, FiniteParameters α ∧ P = FiniteDomainCut α

def DomainAlternative (P : ObjectClass.{u}) : Prop :=
  ∃ α : Ordinal.{u+1}, DomainParameters α ∧ P = DomainCut α

def AllFinite (P : ObjectClass.{u}) : Prop :=
  ∀ D : CountablyBasedDIDomain.{u}, P D → Finite D

def HasInfiniteObject (P : ObjectClass.{u}) : Prop :=
  ∃ D : CountablyBasedDIDomain.{u}, P D ∧ Infinite D

end DIDomainClassification.Section04.CutModels

namespace DIDomainClassification.Section03
open Subcategories StableFunctionModels Section04.CutModels

/-- Source797--806, no nontriviality restrictions. -/
def FunctionDegreeUpperStatement : Prop :=
  ∀ D E : CountablyBasedDIDomain.{u},
    objectDegree (exponential D E) ≤ max 2 (objectDegree E)

/-- Source807--826 and the global replete-subcategory convention. -/
def CandidateClosureStatement : Prop :=
  (∀ α : Ordinal.{u+1}, DomainParameters α → CategoryHypotheses (DomainCut α)) ∧
  (∀ α : Ordinal.{u+1}, FiniteParameters α → CategoryHypotheses (FiniteDomainCut α))

end DIDomainClassification.Section03

namespace DIDomainClassification.Section04
open Subcategories CutModels CoherenceDegree

/-- Source1909--1920: exactly one family and the stated finite-object iff.
The two alternatives are not assumed disjoint in the model. -/
def CutRecoveryStatement : Prop :=
  ∀ P : ObjectClass.{u}, CategoryHypotheses P →
    ((FiniteAlternative P ∧ ¬ DomainAlternative P) ∨
      (DomainAlternative P ∧ ¬ FiniteAlternative P)) ∧
    (FiniteAlternative P ↔ AllFinite P)

/-- Source1995--2017: all three inclusion equivalences and no reverse
domain-to-finite inclusion, with their different parameter ranges. -/
def DistinctCutsStatement : Prop :=
  (∀ α β : Ordinal.{u+1}, FiniteParameters α → FiniteParameters β →
    ((∀ D, FiniteDomainCut α D → FiniteDomainCut β D) ↔ α ≤ β)) ∧
  (∀ α β : Ordinal.{u+1}, DomainParameters α → DomainParameters β →
    ((∀ D, DomainCut α D → DomainCut β D) ↔ α ≤ β)) ∧
  (∀ α β : Ordinal.{u+1}, FiniteParameters α → DomainParameters β →
    ((∀ D, FiniteDomainCut α D → DomainCut β D) ↔ α ≤ β)) ∧
  (∀ α β : Ordinal.{u+1}, FiniteParameters α → DomainParameters β →
    ¬ (∀ D, DomainCut β D → FiniteDomainCut α D))

/-- Source2067--2091: literal class equalities, both unions and strict
inclusion at omega. The union ranges over ALL n>=2, not a finite cutoff. -/
def FiniteLayersStatement : Prop :=
  (∀ (n : ℕ) (hn : 2 ≤ n),
    FiniteDomainCut ((n : Ordinal.{u+1}) + 1) =
      (fun D : CountablyBasedDIDomain.{u} =>
        Finite D ∧ IsNCoherent D.toDIDomainObject.isDIDomain.toIsScottDomain n hn)) ∧
  (∀ (n : ℕ) (hn : 2 ≤ n),
    DomainCut ((n : Ordinal.{u+1}) + 1) =
      (fun D : CountablyBasedDIDomain.{u} =>
        IsNCoherent D.toDIDomainObject.isDIDomain.toIsScottDomain n hn)) ∧
  (FiniteDomainCut Ordinal.omega0 =
    (fun D : CountablyBasedDIDomain.{u} =>
      ∃ n : ℕ, 2 ≤ n ∧ FiniteDomainCut ((n : Ordinal.{u+1}) + 1) D)) ∧
  (DomainCut Ordinal.omega0 =
    (fun D : CountablyBasedDIDomain.{u} =>
      ∃ n : ℕ, 2 ≤ n ∧ DomainCut ((n : Ordinal.{u+1}) + 1) D)) ∧
  (∀ D : CountablyBasedDIDomain.{u},
    DomainCut Ordinal.omega0 D → DomainCut (Ordinal.omega0 + 1) D) ∧
  (∃ D : CountablyBasedDIDomain.{u},
    DomainCut (Ordinal.omega0 + 1) D ∧ ¬ DomainCut Ordinal.omega0 D)

end DIDomainClassification.Section04

namespace DIDomainClassification.Section01
open Subcategories Section04.CutModels

/-- The exact list assertion of source Theorem1.1; only definitions are
assumed. It does not use a classification theorem as a premise. -/
def ClassificationCharacterizationStatement : Prop :=
  ∀ P : ObjectClass.{u},
    CategoryHypotheses P ↔ FiniteAlternative P ∨ DomainAlternative P

/-- Pairwise distinct object classes in the three relevant cases. -/
def ClassificationDistinctStatement : Prop :=
  (∀ α β : Ordinal.{u+1}, FiniteParameters α → FiniteParameters β →
    (FiniteDomainCut α = FiniteDomainCut β ↔ α = β)) ∧
  (∀ α β : Ordinal.{u+1}, DomainParameters α → DomainParameters β →
    (DomainCut α = DomainCut β ↔ α = β)) ∧
  (∀ α β : Ordinal.{u+1}, FiniteParameters α → DomainParameters β →
    FiniteDomainCut α ≠ DomainCut β)

/-- Every object of F_alpha is finite; each D_alpha contains an infinite
object. Actual infinite whole carrier, not merely infinitely many compacts. -/
def ClassificationCarrierStatement : Prop :=
  (∀ α : Ordinal.{u+1}, FiniteParameters α → AllFinite (FiniteDomainCut α)) ∧
  (∀ α : Ordinal.{u+1}, DomainParameters α → HasInfiniteObject (DomainCut α))

def ClassificationStatement : Prop :=
  ClassificationCharacterizationStatement.{u} ∧
    ClassificationDistinctStatement.{u} ∧ ClassificationCarrierStatement.{u}

end DIDomainClassification.Section01
