import DIDomainClassification.Section04.FiniteCategoryModels
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section02.RankDegree
import DIDomainClassification.Section04.CausalRetractionStatement

/-! UNPROVED source lem:finite-generators1070--1076. D is an arbitrary dI
object with FINITE WHOLE carrier; no separate countably-based premise.
All cube/power certificates, finite exponents and stable splittings are outputs.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04.FiniteGeneratorModels

open EventStructures

abbrev ProperIn {A : Type u} (H : Set A) := {S : Set A // S ⊂ H}

abbrev ForbiddenProduct {A : Type u} [PartialOrder A]
    (E : FinitaryPrimeEventStructure A) :=
  Set A × ((H : causalConflictFamily E) → ProperIn H.val)

def sectionCoordinateValues {A : Type u} (X H : Set A) : Set A := X ∩ H

def retractionValues {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (p : ForbiddenProduct E) : Set A :=
  {a | a ∈ p.1 ∧ ∀ H : causalConflictFamily E, a ∈ H.val → a ∈ (p.2 H).val}

end DIDomainClassification.Section04.FiniteGeneratorModels

namespace DIDomainClassification.Section04

open Preliminaries CoherenceDegree EventStructures FiniteCategoryModels FiniteGeneratorModels

def FiniteGeneratorsStatement : Prop :=
  ∀ (n : ℕ) (hn : 2 ≤ n),
    (∀ D : DIDomainObject.{u}, Finite D → IsNCoherent D.isDIDomain.toIsScottDomain n hn →
      ∃ (m : ℕ) (_hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn))
        (hPower : IsCountablyBasedDIDomain (CubePower.{u} n hn m)),
        HasStableRetraction D (powerCore n hn m hPower.1)) ∧
    (∀ D : DIDomainObject.{u}, Finite D →
      coherenceDegree D.isDIDomain.toIsScottDomain = (n : Ordinal.{u+1}) →
      ∃ hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn),
        HasStableRetraction (cubeCore n hn hCube.1) D)

/-- Operative printed j/R construction1089--1117, separately UNPROVED.
No map/closure conclusion is supplied as a premise. -/
def FiniteForbiddenProductConstructionStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] [Finite A] (E : FinitaryPrimeEventStructure A),
    ∃ (C : QualitativeCoverClosure E) (hP : IsDIDomain (ForbiddenProduct E))
      (j : StableHom (qualitativeCoverCore E C) (DIDomainObject.ofType (ForbiddenProduct E) hP))
      (r : StableHom (DIDomainObject.ofType (ForbiddenProduct E) hP) (qualitativeCoverCore E C)),
      Finite (QualitativeCover E) ∧ Finite (ForbiddenProduct E) ∧
      (∀ X, (j X).1 = X.val ∧
        ∀ H : causalConflictFamily E, ((j X).2 H).val = sectionCoordinateValues X.val H.val) ∧
      (∀ p, (r p).val = retractionValues E p) ∧
      Function.LeftInverse (r : ForbiddenProduct E → QualitativeCover E)
        (j : QualitativeCover E → ForbiddenProduct E)

end DIDomainClassification.Section04
