import DIDomainClassification.Section04.AdditionalSourceModels
import DIDomainClassification.Section02.TreeDomain

/-! UNPROVED source tree/block realization and tree-comparison specifications.
Tree-domain points remain arbitrary forbidden-branch-avoiding node subsets,
not lower sets. The target event domain is RAW, not assumed countably based. -/
set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section04.TreeRealisationModels
open Preliminaries EventStructures Trees AdditionalSourceModels

variable {A : Type u} [PartialOrder A] {B : Type v}

def background (T : RootedPrefixTree B) (L : T.Node → Set A) (v : T.Node) : Set A :=
  {a | ∃ z : T.Node, z.val <+: v.val ∧ ∃ b ∈ L z, a ≤ b ∧ a ≠ b}

def nodeSection (T : RootedPrefixTree B) (L : T.Node → Set A)
    (X : Set T.Node) (v : T.Node) : Set A :=
  background T L v ∪ {a | ∃ z : T.Node, z.val <+: v.val ∧ z ∈ X ∧ a ∈ L z}

def branchSection (T : RootedPrefixTree B) (L : T.Node → Set A)
    (X : Set T.Node) (b : T.InfiniteBranch) : Set A :=
  {a | ∃ v ∈ Set.range b.node, a ∈ nodeSection T L X v}

def BlockCondition (T : RootedPrefixTree B) (E : FinitaryPrimeEventStructure A)
    (L : T.Node → Set A) : Prop :=
  (∀ v, (L v).Finite ∧ (L v).Nonempty) ∧
  ∀ c : Set T.Node, T.IsFiniteCompleteBranch c →
    c.Pairwise (fun x y => Disjoint (L x) (L y)) ∧
      (⋃ v ∈ c, L v) ∈ causalConflictFamily E

end DIDomainClassification.Section04.TreeRealisationModels

namespace DIDomainClassification.Section04
open Preliminaries EventStructures Trees CoherenceDegree AdditionalSourceModels
open TreeRealisationModels

def TreeRealisationStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (B : Type v) (T : RootedPrefixTree B) (hp : T.IsProper) (L : T.Node → Set A),
    BlockCondition T E L →
    ∃ (hT : IsCountablyBasedDIDomain (TreeDomain T))
      (hH : IsCountablyBasedDIDomain (BranchCompletion T hp)),
      let H := (completionCB T hp hH).toDIDomainObject
      let F := functionCore H (causalConfigurationCore E)
      ∃ (s : StableHom (treeCore T hT.1) F) (r : StableHom F (treeCore T hT.1)),
        (∀ (X : TreeDomain T) (v : T.Node),
          (functionValue H (causalConfigurationCore E) (s X)
            (BranchCompletion.finite T hp v)).val = nodeSection T L X.val v) ∧
        (∀ (X : TreeDomain T) (b : T.InfiniteBranch),
          (functionValue H (causalConfigurationCore E) (s X)
            (BranchCompletion.infinite T hp b)).val = branchSection T L X.val b) ∧
        (∀ f : F, (r f).val =
          {v : T.Node | L v ⊆ (functionValue H (causalConfigurationCore E) f
            (BranchCompletion.finite T hp v)).val}) ∧
        Function.LeftInverse (r : F → treeCore T hT.1) (s : treeCore T hT.1 → F)

def TreeBlocksStatement : Prop :=
  ∀ (A : Type u) (B : Type v) (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (hp : T.IsProper) (hq : S.IsProper) (L : T.Node → Set S.Node),
    (∀ v, (L v).Finite ∧ (L v).Nonempty) →
    (∀ c : Set T.Node, T.IsFiniteCompleteBranch c →
      c.Pairwise (fun x y => Disjoint (L x) (L y)) ∧
        S.IsFiniteCompleteBranch (⋃ v ∈ c, L v)) →
    ∃ (hT : IsCountablyBasedDIDomain (TreeDomain T))
      (hS : IsCountablyBasedDIDomain (TreeDomain S))
      (hH : IsCountablyBasedDIDomain (BranchCompletion T hp)),
      HasStableRetraction (treeCore T hT.1)
        (functionCore (completionCB T hp hH).toDIDomainObject (treeCore S hS.1))

/-- Both alphabets remain arbitrary in the ambient object universe; no Nat-only
tree, finite branching, root normalization, or map hypothesis is inserted. -/
def TreeComparisonStatement : Prop :=
  ∀ (A B : Type u) (T : RootedPrefixTree A) (S : RootedPrefixTree B),
    T.IsProper → S.IsProper →
    ∃ (hT : IsCountablyBasedDIDomain (TreeDomain T))
      (hS : IsCountablyBasedDIDomain (TreeDomain S)),
      ((∀ (wfT : T.IsWellFounded) (wfS : S.IsWellFounded),
        T.treeRank wfT ≤ S.treeRank wfS →
        StableComparison (treeObject T hT) (treeObject S hS)) ∧
       (S.HasInfiniteBranch → StableComparison (treeObject T hT) (treeObject S hS)))

end DIDomainClassification.Section04
