import DIDomainClassification.Support.ComparisonCharacterisation

/-! Theorem 4.16: exact parameterized comparison criterion. -/
set_option autoImplicit false
universe u

namespace DIDomainClassification.Section04
open Section03.StableFunctionModels Subcategories

theorem comparisonDegreeBound (D E : CountablyBasedDIDomain.{u})
    (h : StableComparison D E) : objectDegree D ≤ max 2 (objectDegree E) :=
  ComparisonCharacterisation.degree_bound D E h

theorem comparisonOfDegreeBound (D E : CountablyBasedDIDomain.{u})
    (hE : Nontrivial (Core E)) (h : objectDegree D ≤ max 2 (objectDegree E)) :
    StableComparison D E := ComparisonCharacterisation.of_degree_bound D E hE h

theorem comparisonTheorem : ComparisonTheoremStatement.{u} := by
  intro D E hE
  exact ⟨comparisonDegreeBound D E, comparisonOfDegreeBound D E hE⟩

end DIDomainClassification.Section04
