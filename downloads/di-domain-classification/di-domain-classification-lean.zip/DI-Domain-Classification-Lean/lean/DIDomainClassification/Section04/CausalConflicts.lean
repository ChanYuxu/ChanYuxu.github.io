import DIDomainClassification.Section02.Configurations

/-!
# Minimal inconsistent lower sets

Source: manuscript.tex:834--838, source SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
Minimality is among lower subsets, not among all subsets. This distinction is
essential when the event order is not equality. No antichain, size, domain,
retraction or representation theorem is assumed in these definitions.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

variable {A : Type u} [PartialOrder A]

/-- Maximal events in the induced order on the given subset. -/
def maximalEvents (U : Set A) : Set A :=
  {a | a ∈ U ∧ ∀ b ∈ U, a ≤ b → b = a}

/-- Finite inconsistent lower sets minimal only among lower subsets. -/
def IsMinimallyInconsistentFiniteLowerSet (E : FinitaryPrimeEventStructure A)
    (U : Set A) : Prop :=
  U.Finite ∧ IsLowerSet U ∧ U ∉ E.Con ∧
    ∀ V : Set A, V ⊂ U → IsLowerSet V → V ∈ E.Con

/-- The source family H_E, consisting of the actual maximal-event sets. -/
def causalConflictFamily (E : FinitaryPrimeEventStructure A) : Set (Set A) :=
  {H | ∃ U : Set A, IsMinimallyInconsistentFiniteLowerSet E U ∧ H = maximalEvents U}

end DIDomainClassification.EventStructures
