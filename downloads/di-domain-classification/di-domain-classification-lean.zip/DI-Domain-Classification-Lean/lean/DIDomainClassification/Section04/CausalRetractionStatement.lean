import DIDomainClassification.Section04.QualitativeCover
import DIDomainClassification.Section02.QualitativeDomains
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section02.StableCategory
import DIDomainClassification.Support.ConfigurationDomain

/-!
Step 3 unproved source-facing specification for Lemma4.1, causal retraction.
Source statement864--876; original proof877--915; preceding cover857--862.
Frozen manuscript SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

The exact literal Q carrier is used for ALL event carriers. Domain/presentation
proofs and conditional compact-countability are existential OUTPUTS, never public
premises. Only already-proved
configuration-domain structure is reused to type the original E core.
No maps, map well-definedness, closure witness or source proof is constructed.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.EventStructures

variable {A : Type u} [originalOrder : PartialOrder A]

/-- Concrete outputs needed to regard the literal cover as a qualitative,
dI-domain. The equality-order event presentation uses the SAME
event carrier and the EXACT given forbidden family, not an arbitrary order iso.
No chosen map or target retraction law is a field. -/
structure QualitativeCoverClosure (E : FinitaryPrimeEventStructure A) : Prop where
  qualitative :
    ∃ (qOrder : PartialOrder A) (qEvents : @FinitaryPrimeEventStructure A qOrder),
      @IsQualitativePresentation A qOrder qEvents ∧
      @IsForbiddenFamilyPresentation A qOrder qEvents
        (@causalConflictFamily A originalOrder E)
  domain : Preliminaries.IsDIDomain (QualitativeCover E)
  countableCompacts : Countable A →
    (Preliminaries.CompactElements (QualitativeCover E)).Countable

/-- Bundle the actual source configuration order using its already-proved
intrinsic dI theorem, not a new closure assumption. -/
@[reducible] def causalConfigurationCore (E : FinitaryPrimeEventStructure A) :
    DIDomainObject.{u} :=
  DIDomainObject.ofType (Configuration E) (ConfigurationDomain.dIDomain E)

/-- This packages an eventual OUTPUT closure proof on the literal Q carrier.
It does not supply or assume an inhabitant of QualitativeCoverClosure. -/
@[reducible] def qualitativeCoverCore (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) : DIDomainObject.{u} :=
  DIDomainObject.ofType (QualitativeCover E) C.domain

/-- The countably based categorical application is a separate packaging of
the conditional compact-countability OUTPUT. It does not restrict the raw
retraction construction to countable event carriers. -/
@[reducible] def qualitativeCoverCountablyBased (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) [Countable A] : CountablyBasedDIDomain.{u} where
  toDIDomainObject := qualitativeCoverCore E C
  countableCompacts := C.countableCompacts inferInstance

theorem causalConfigurationCore_carrier (E : FinitaryPrimeEventStructure A) :
    (causalConfigurationCore E).Carrier = Configuration E := rfl

theorem causalConfigurationCore_order (E : FinitaryPrimeEventStructure A) :
    (causalConfigurationCore E).partialOrder =
      (inferInstance : PartialOrder (Configuration E)) := rfl

theorem qualitativeCoverCore_carrier (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) :
    (qualitativeCoverCore E C).Carrier = QualitativeCover E := rfl

theorem qualitativeCoverCore_order (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) :
    (qualitativeCoverCore E C).partialOrder =
      (inferInstance : PartialOrder (QualitativeCover E)) := rfl

end DIDomainClassification.EventStructures

namespace DIDomainClassification.Section04

open EventStructures

/-- Exact unproved raw source target. The locally stated construction and
proof use only finiteness of principal event ideals, NOT Countable A. No full
carrier countability is imposed. All cover closure and actual stable maps must
be produced, with countability conditional in the separate closure field.

The r formula uses the ORIGINAL causal PartialOrder A. qOrder in the qualitative
output is never installed as the local order for this formula. The final
inequality is literal pointwise SET inclusion, not stable-order comparison of
the endomorphism s∘r with identity. -/
def CausalRetractionStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A),
    ∃ C : QualitativeCoverClosure E,
      ∃ (s : StableHom (causalConfigurationCore E) (qualitativeCoverCore E C))
        (r : StableHom (qualitativeCoverCore E C) (causalConfigurationCore E)),
        (∀ X : Configuration E, (s X).val = X.val) ∧
        (∀ Y : QualitativeCover E, (r Y).val = {a : A | Set.Iic a ⊆ Y.val}) ∧
        Function.LeftInverse (r : QualitativeCover E → Configuration E)
          (s : Configuration E → QualitativeCover E) ∧
        ∀ Y : QualitativeCover E, (s (r Y)).val ⊆ Y.val

end DIDomainClassification.Section04







