import DIDomainClassification.Section04.BranchCompletionModels

/-! UNPROVED source paragraph manuscript.tex1131--1137. All domain and
compactness facts are OUTPUTS. The target E of automatic stability is an
arbitrary dI-domain, not assumed countably based. -/

set_option autoImplicit false
universe u v

namespace DIDomainClassification.Section04

open Preliminaries CoherenceDegree Trees BranchCompletionModels

def BranchCompletionPropertiesStatement : Prop :=
  ∀ (A : Type u) (T : RootedPrefixTree A) (hp : T.IsProper),
    ∃ hH : IsDIDomain (Completion T hp),
      (CompactElements (Completion T hp)).Countable ∧
      (∀ v : T.Node, IsCompactElement (BranchCompletion.finite T hp v)) ∧
      (∀ b : T.InfiniteBranch,
        IsLUB (branchPrefixes T hp b) (BranchCompletion.infinite T hp b) ∧
          ¬ IsCompactElement (BranchCompletion.infinite T hp b)) ∧
      CompactElements (Completion T hp) = finiteNodes T hp ∧
      (∀ v : T.Node, (Set.Iic (BranchCompletion.finite T hp v)).Finite) ∧
      (∀ S : Set (Completion T hp), BddAbove S →
        ∃ c : Set (Completion T hp), IsMaxChain (· ≤ ·) c ∧ S ⊆ c ∧
          ∃ s : Completion T hp, IsLUB S s) ∧
      (∀ x y : Completion T hp, Compatible x y → x ≤ y ∨ y ≤ x) ∧
      (∀ S : Set (Completion T hp),
        (∀ x ∈ S, ∀ y ∈ S, Compatible x y) →
          IsChain (· ≤ ·) S ∧ ∃ s : Completion T hp, IsLUB S s) ∧
      IsNCoherent hH.toIsScottDomain 2 (by decide) ∧
      (∀ (E : DIDomainObject.{v}) (f : Completion T hp → E),
        ScottContinuous f → IsStable (completionObject T hp hH) E f)

end DIDomainClassification.Section04
