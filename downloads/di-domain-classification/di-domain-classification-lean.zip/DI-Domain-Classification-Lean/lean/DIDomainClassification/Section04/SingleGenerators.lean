import DIDomainClassification.Support.SingleGeneratorClassification

/-! Exact positive clauses of Corollary 4.23 and a checked refutation of
its original unqualified final clause. The source text is not repaired here. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04
open Subcategories AdditionalSourceModels SingleGeneratorProof

theorem singleGeneratorNontrivial : SingleGeneratorNontrivialStatement.{u} := by
  intro D hD
  exact ⟨finite_generated D hD, infinite_generated D hD⟩

theorem singleGeneratorSingleton : SingleGeneratorSingletonStatement.{u} :=
  singleton_generated

theorem finiteOmegaNotSingleGenerated : FiniteOmegaNotSingleGeneratedStatement.{u} :=
  finite_omega_not_single_generated

theorem notLimitNotSingleGeneratedOriginal :
    ¬ LimitNotSingleGeneratedOriginalStatement.{u} := by
  intro h
  exact h aboveBoundLimit aboveBoundLimit_isSuccLimit above_bound_limit_generated

theorem singleGeneratorOriginalRefuted : ¬ SingleGeneratorStatement.{u} := by
  intro h
  exact notLimitNotSingleGeneratedOriginal h.2.2.2

end DIDomainClassification.Section04
