import DIDomainClassification.Support.TreeBlocksCausalPresentation
import DIDomainClassification.Support.TreeBlocksNativeTransport

/-! The original blocks corollary, via the literal equality-order event
presentation and an actual native stable-Hom order isomorphism. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries EventStructures Trees
open TreeRealisationModels AdditionalSourceModels
open TreeBlocksCausalPresentation TreeBlocksNativeTransport

theorem treeBlocks : TreeBlocksStatement.{u,v} := by
  intro A B T S hp hq L hFinite hBranches
  letI : PartialOrder S.Node := ForbiddenFiniteDomains.equalityOrder S.Node
  let E := treeEvents S hq
  have hFamily : causalConflictFamily E = Section02.TreeDomainConstruction.forbiddenBranches S :=
    tree_conflictFamily S hq
  have hL : BlockCondition T E L := by
    refine ⟨hFinite, ?_⟩
    intro c hc
    refine ⟨(hBranches c hc).1, ?_⟩
    rw [hFamily]
    exact (hBranches c hc).2
  obtain ⟨hT, hH, s, r, _hFiniteValues, _hInfiniteValues, _hRValues, hleft⟩ :=
    treeRealisation.{v,u} S.Node E A T hp L hL
  let hS := TreeRealisationConfigurations.treeCountablyBased S hq
  let H := (completionCB T hp hH).toDIDomainObject
  let C := causalConfigurationCore E
  let Q := treeCore S hS.1
  let e : C ≃o Q := treeOrderIso S hq
  let eHom : functionCore H C ≃o functionCore H Q := postOrderIso H C Q e
  let t : StableHom (functionCore H C) (functionCore H Q) :=
    OrderIsoTransport.stableHom _ _ eHom
  let q : StableHom (functionCore H Q) (functionCore H C) :=
    OrderIsoTransport.stableHom _ _ eHom.symm
  refine ⟨hT, hS, hH, StableHom.comp t s, StableHom.comp r q, ?_⟩
  intro X
  change r (eHom.symm (eHom (s X))) = X
  rw [eHom.symm_apply_apply]
  exact hleft X

end DIDomainClassification.Section04
