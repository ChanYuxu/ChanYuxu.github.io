import DIDomainClassification.Section04.CutClassificationStatements
import DIDomainClassification.Support.OrdinalCutWitnesses

/-! The source Proposition distinct-cuts: exact parameter ranges, literal
finite witnesses for finite cut separation, degree realizability for the full
domain range, and the actual infinite powerset for every reverse inclusion. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries CoherenceDegree Subcategories CutModels OrdinalCutWitnesses

theorem finiteCut_separatingWitness (α β : Ordinal.{u+1})
    (hβ : 3 ≤ β) (hβα : β < α) (hα : α ≤ Ordinal.omega0) :
    ∃ D : CountablyBasedDIDomain.{u}, Finite D ∧ objectDegree D = β := by
  obtain ⟨n, rfl⟩ := Ordinal.lt_omega0.mp (hβα.trans_le hα)
  have hn : 2 ≤ n := by
    have hn3 : 3 ≤ n := by exact_mod_cast hβ
    omega
  exact ⟨finiteCube n hn, finiteCube_finite n hn, finiteCube_degree n hn⟩

theorem domainCut_separatingWitness (α β : Ordinal.{u+1})
    (hβ : 3 ≤ β) (hβα : β < α) (hα : α ≤ firstUncountableBound.{u} + 1) :
    ∃ D : CountablyBasedDIDomain.{u}, objectDegree D = β := by
  have hUpper : β ≤ firstUncountableBound.{u} := by
    apply Order.lt_succ_iff.mp
    simpa only [Order.succ_eq_add_one] using hβα.trans_le hα
  exact Section02.degreeRealizability.1 β (Or.inr ⟨
    (show (2 : Ordinal.{u+1}) ≤ 3 from by exact_mod_cast (by decide : (2 : ℕ) ≤ 3)).trans hβ,
    hUpper⟩)

theorem finiteCut_inclusion_iff (α β : Ordinal.{u+1})
    (hα : FiniteParameters α) (hβ : FiniteParameters β) :
    (∀ D, FiniteDomainCut α D → FiniteDomainCut β D) ↔ α ≤ β := by
  constructor
  · intro hInc
    by_contra hNot
    have hβα : β < α := lt_of_not_ge hNot
    obtain ⟨D, hFinite, hDegree⟩ := finiteCut_separatingWitness α β hβ.1 hβα hα.2
    have hD : FiniteDomainCut α D := ⟨by
      change objectDegree D < α
      simpa only [hDegree] using hβα, hFinite⟩
    have hBad := (hInc D hD).1
    change objectDegree D < β at hBad
    rw [hDegree] at hBad
    exact (lt_irrefl β) hBad
  · intro hαβ D hD
    exact ⟨hD.1.trans_le hαβ, hD.2⟩

theorem domainCut_inclusion_iff (α β : Ordinal.{u+1})
    (hα : DomainParameters α) (hβ : DomainParameters β) :
    (∀ D, DomainCut α D → DomainCut β D) ↔ α ≤ β := by
  constructor
  · intro hInc
    by_contra hNot
    have hβα : β < α := lt_of_not_ge hNot
    obtain ⟨D, hDegree⟩ := domainCut_separatingWitness α β hβ.1 hβα hα.2
    have hD : DomainCut α D := by
      change objectDegree D < α
      simpa only [hDegree] using hβα
    have hBad := hInc D hD
    change objectDegree D < β at hBad
    rw [hDegree] at hBad
    exact (lt_irrefl β) hBad
  · intro hαβ D hD
    exact hD.trans_le hαβ

theorem finiteToDomain_inclusion_iff (α β : Ordinal.{u+1})
    (hα : FiniteParameters α) (hβ : DomainParameters β) :
    (∀ D, FiniteDomainCut α D → DomainCut β D) ↔ α ≤ β := by
  constructor
  · intro hInc
    by_contra hNot
    have hβα : β < α := lt_of_not_ge hNot
    obtain ⟨D, hFinite, hDegree⟩ := finiteCut_separatingWitness α β hβ.1 hβα hα.2
    have hD : FiniteDomainCut α D := ⟨by
      change objectDegree D < α
      simpa only [hDegree] using hβα, hFinite⟩
    have hBad := hInc D hD
    change objectDegree D < β at hBad
    rw [hDegree] at hBad
    exact (lt_irrefl β) hBad
  · intro hαβ D hD
    exact hD.1.trans_le hαβ

theorem noDomainToFinite_inclusion (α β : Ordinal.{u+1})
    (_hα : FiniteParameters α) (hβ : DomainParameters β) :
    ¬ (∀ D, DomainCut β D → FiniteDomainCut α D) := by
  intro hInc
  have hD : DomainCut β infinitePowerset.{u} := by
    change objectDegree infinitePowerset < β
    rw [infinitePowerset_degree]
    exact (show (0 : Ordinal.{u+1}) < 3 from by
      exact_mod_cast (by decide : (0 : ℕ) < 3)).trans_le hβ.1
  exact infinitePowerset_not_finite (hInc _ hD).2

theorem distinctCuts : DistinctCutsStatement.{u} :=
  ⟨finiteCut_inclusion_iff, domainCut_inclusion_iff,
    finiteToDomain_inclusion_iff, noDomainToFinite_inclusion⟩

/-- The manuscript's concluding pairwise-distinctness clause, as literal
equality of full object classes rather than a claim about category equivalence. -/
theorem finiteCuts_eq_iff (α β : Ordinal.{u+1})
    (hα : FiniteParameters α) (hβ : FiniteParameters β) :
    FiniteDomainCut α = FiniteDomainCut β ↔ α = β := by
  constructor
  · intro hEq
    apply le_antisymm
    · exact (finiteCut_inclusion_iff α β hα hβ).mp (fun D hD => hEq ▸ hD)
    · exact (finiteCut_inclusion_iff β α hβ hα).mp (fun D hD => hEq.symm ▸ hD)
  · intro hEq
    rw [hEq]

theorem domainCuts_eq_iff (α β : Ordinal.{u+1})
    (hα : DomainParameters α) (hβ : DomainParameters β) :
    DomainCut α = DomainCut β ↔ α = β := by
  constructor
  · intro hEq
    apply le_antisymm
    · exact (domainCut_inclusion_iff α β hα hβ).mp (fun D hD => hEq ▸ hD)
    · exact (domainCut_inclusion_iff β α hβ hα).mp (fun D hD => hEq.symm ▸ hD)
  · intro hEq
    rw [hEq]

theorem finiteCut_ne_domainCut (α β : Ordinal.{u+1})
    (hα : FiniteParameters α) (hβ : DomainParameters β) :
    FiniteDomainCut α ≠ DomainCut β := by
  intro hEq
  exact noDomainToFinite_inclusion α β hα hβ (fun D hD => hEq.symm ▸ hD)

end DIDomainClassification.Section04
