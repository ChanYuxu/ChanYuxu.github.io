import DIDomainClassification.Support.InfiniteCutRecovery
import DIDomainClassification.Support.OrdinalCutWitnesses

/-! Proposition 4.20, with the two alternatives proved disjoint.
The ordinal parameter is constructed from the original category itself. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.CutRecoveryProof
open Subcategories Section04.CutModels

theorem finite_alternative_allFinite (P : ObjectClass.{u})
    (h : FiniteAlternative P) : AllFinite P := by
  obtain ⟨a, _ha, hEq⟩ := h
  intro D hD
  rw [hEq] at hD
  exact hD.2

theorem domain_alternative_not_allFinite (P : ObjectClass.{u})
    (h : DomainAlternative P) : ¬ AllFinite P := by
  obtain ⟨a, ha, hEq⟩ := h
  intro hFinite
  have hPower : P OrdinalCutWitnesses.infinitePowerset.{u} := by
    rw [hEq]
    change objectDegree OrdinalCutWitnesses.infinitePowerset.{u} < a
    rw [OrdinalCutWitnesses.infinitePowerset_degree]
    exact (by exact_mod_cast (show (0 : ℕ) < 3 by decide) :
      (0 : Ordinal.{u+1}) < 3).trans_le ha.1
  exact OrdinalCutWitnesses.infinitePowerset_not_finite
    (hFinite OrdinalCutWitnesses.infinitePowerset hPower)

theorem hasInfinite_of_not_allFinite (P : ObjectClass.{u})
    (h : ¬ AllFinite P) : HasInfiniteObject P := by
  classical
  by_contra hNo
  apply h
  intro D hD
  rcases finite_or_infinite D with hFinite | hInfinite
  · exact hFinite
  · exact False.elim (hNo ⟨D, hD, hInfinite⟩)

end DIDomainClassification.CutRecoveryProof

namespace DIDomainClassification.Section04
open Subcategories CutModels CutRecoveryProof

theorem cutRecovery : CutRecoveryStatement.{u} := by
  classical
  intro P hP
  by_cases hFinite : AllFinite P
  · have hAlt := finite_alternative P hP hFinite
    exact ⟨Or.inl ⟨hAlt, fun hDomain => domain_alternative_not_allFinite P hDomain hFinite⟩,
      ⟨fun _ => hFinite, fun _ => hAlt⟩⟩
  · have hAlt := domain_alternative P hP (hasInfinite_of_not_allFinite P hFinite)
    have hNoFinite : ¬ FiniteAlternative P :=
      fun hAltFinite => hFinite (finite_alternative_allFinite P hAltFinite)
    exact ⟨Or.inr ⟨hAlt, hNoFinite⟩,
      ⟨fun hAltFinite => False.elim (hNoFinite hAltFinite),
        fun hAllFinite => False.elim (hFinite hAllFinite)⟩⟩

end DIDomainClassification.Section04
