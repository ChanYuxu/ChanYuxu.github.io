import DIDomainClassification.Support.PointwiseChainInterior

/-! Source manuscript.tex:917--926, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The lower-interior composite is pointwise below identity but not below it in
the stable order. Its own stability is proved, not contradicted. -/

set_option autoImplicit false
noncomputable section

namespace DIDomainClassification.Section04

open PointwiseChainInterior PointwiseNotStableModels

theorem pointwiseNotStable : PointwiseNotStableStatement := by
  refine ⟨closure, powersetCB, orderIso, (fun _ => rfl), configurations,
    conflicts_empty, sectionMap, retractionMap, composite, (fun _ => rfl),
    (fun _ => rfl), CausalCoverSupport.leftInverse chainEvents,
    composite_apply, (fun _ => rfl), composite_subset, composite_singleton_one,
    composite_pair, ?_, composite_not_stableLE_identity⟩
  rw [composite_pair]
  simp

end DIDomainClassification.Section04
