import DIDomainClassification.Section04.BranchCompletionModels

/-! UNPROVED Lemma4.7, manuscript.tex1139--1147, proof1148--1160.
The needed completion dI certificate is produced, not assumed. The specified
native extension is constrained at EVERY finite node and EVERY whole branch.
-/

set_option autoImplicit false
universe u v

namespace DIDomainClassification.Section04

open Preliminaries Trees BranchCompletionModels

def BranchExtensionStatement : Prop :=
  ∀ (A : Type u) (T : RootedPrefixTree A) (hp : T.IsProper),
    ∃ hH : IsDIDomain (Completion T hp),
      ∀ (E : DIDomainObject.{v}) (a : T.Node → E), PrefixMonotone T E a →
        ∃ extension : StableHom (completionObject T hp hH) E,
          (∀ v : T.Node, extension (BranchCompletion.finite T hp v) = a v) ∧
          (∀ b : T.InfiniteBranch,
            IsLUB (a '' Set.range b.node) (extension (BranchCompletion.infinite T hp b)))

end DIDomainClassification.Section04
