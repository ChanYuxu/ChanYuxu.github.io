import DIDomainClassification.Section04.CausalRetractionStatement
import DIDomainClassification.Support.ForbiddenFiniteDomains
import DIDomainClassification.Support.MinimalLowerConflicts
import DIDomainClassification.Support.LowerInterior
import Mathlib.Order.GaloisConnection.Basic

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.CausalCoverSupport
open EventStructures FiniteCausalConflicts

variable {A : Type u} [PartialOrder A]

def admissible (E : FinitaryPrimeEventStructure A) :
    ForbiddenFiniteDomains.Admissible (causalConflictFamily E) where
  finite := fun _ h => conflict_member_finite E h
  nonempty := fun _ h => conflict_member_nonempty E h
  no_subset_singleton := by
    intro a H hH hsub
    obtain ⟨U, hU, rfl⟩ := hH
    obtain ⟨x, hx, y, hy, hxy⟩ := minimalLower_maximalEvents_nontrivial E hU
    exact hxy ((Set.mem_singleton_iff.mp (hsub hx)).trans
      (Set.mem_singleton_iff.mp (hsub hy)).symm)

def closure (E : FinitaryPrimeEventStructure A) : QualitativeCoverClosure E where
  qualitative := ⟨ForbiddenFiniteDomains.equalityOrder A,
    ForbiddenFiniteDomains.eventStructure (causalConflictFamily E) (admissible E),
    ForbiddenFiniteDomains.isQualitativePresentation _ _,
    ForbiddenFiniteDomains.isForbiddenFamilyPresentation _ _⟩
  domain := ForbiddenFiniteDomains.isDIDomain (causalConflictFamily E) (admissible E)
  countableCompacts := by
    intro h
    letI : Countable A := h
    exact ForbiddenFiniteDomains.compactElements_countable (causalConflictFamily E) (admissible E)

theorem configuration_avoids (E : FinitaryPrimeEventStructure A)
    (X : Configuration E) : ∀ H ∈ causalConflictFamily E, ¬ H ⊆ X.val := by
  rintro H ⟨U, hU, rfl⟩ hHX
  apply hU.2.2.1
  apply X.property.2 U hU.1
  intro a ha
  have haD : a ∈ downClosure (maximalEvents U) :=
    (finite_lower_eq_down_maximalEvents hU.1 hU.2.1) ▸ ha
  obtain ⟨b, hb, hab⟩ := haD
  exact X.property.1 hab (hHX hb)

def sectionMap (E : FinitaryPrimeEventStructure A)
    (X : Configuration E) : QualitativeCover E :=
  ⟨X.val, configuration_avoids E X⟩

theorem interior_isConfiguration (E : FinitaryPrimeEventStructure A)
    (Y : QualitativeCover E) : IsConfiguration E (lowerInterior Y.val) := by
  refine ⟨lowerInterior_isLower _, ?_⟩
  intro F hF hFsub
  by_contra hBad
  obtain ⟨U, hUF, hU⟩ := exists_minimalLower_in_downClosure E hF hBad
  apply Y.property (maximalEvents U) ⟨U, hU, rfl⟩
  intro a ha
  obtain ⟨b, hb, hab⟩ := hUF ha.1
  exact hFsub hb hab

def retractionMap (E : FinitaryPrimeEventStructure A)
    (Y : QualitativeCover E) : Configuration E :=
  ⟨lowerInterior Y.val, interior_isConfiguration E Y⟩

theorem section_monotone (E : FinitaryPrimeEventStructure A) :
    Monotone (sectionMap E) := fun _ _ h => h

theorem retraction_monotone (E : FinitaryPrimeEventStructure A) :
    Monotone (retractionMap E) := fun _ _ h => lowerInterior_mono h

theorem leftInverse (E : FinitaryPrimeEventStructure A) :
    Function.LeftInverse (retractionMap E) (sectionMap E) := by
  intro X
  apply Subtype.ext
  exact lowerInterior_eq_of_lower X.property.1

theorem composite_subset (E : FinitaryPrimeEventStructure A) (Y : QualitativeCover E) :
    (sectionMap E (retractionMap E Y)).val ⊆ Y.val := lowerInterior_subset Y.val

theorem galoisConnection (E : FinitaryPrimeEventStructure A) :
    GaloisConnection (sectionMap E) (retractionMap E) := by
  intro X Y
  exact (subset_lowerInterior_iff X.property.1).symm

theorem section_scottContinuous (E : FinitaryPrimeEventStructure A) :
    ScottContinuous (sectionMap E) := by
  intro C _hne _hdir X hs
  exact (galoisConnection E).isLUB_l_image hs

theorem retraction_scottContinuous (E : FinitaryPrimeEventStructure A) :
    ScottContinuous (retractionMap E) := by
  intro C hne hdir Y hs
  refine ⟨?_, ?_⟩
  · rintro _ ⟨Z, hZ, rfl⟩
    exact retraction_monotone E (hs.1 hZ)
  · intro X hX a ha
    let K : QualitativeCover E := ⟨Set.Iic a, by
      intro H hH hsub
      exact Y.property H hH (hsub.trans ha)⟩
    have hk : Preliminaries.IsCompactElement K :=
      (ForbiddenFiniteDomains.compact_iff_finite (causalConflictFamily E)
        (admissible E) K).mpr (E.finite_principalIdeal a)
    obtain ⟨Z, hZ, hKZ⟩ := hk ⟨hne, hdir⟩ hs ha
    exact hX ⟨Z, hZ, rfl⟩ hKZ

theorem configuration_inf_val (E : FinitaryPrimeEventStructure A)
    (X Y : causalConfigurationCore E) :
    (X ⊓ Y : causalConfigurationCore E).val = X.val ∩ Y.val := by
  exact congrArg Subtype.val ((DIDomainObject.inf_isGLB (causalConfigurationCore E) X Y).unique
    (ConfigurationDomain.intersection_isGLB E X Y))

theorem cover_inf_val (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) (Y Z : qualitativeCoverCore E C) :
    (Y ⊓ Z : qualitativeCoverCore E C).val = Y.val ∩ Z.val := by
  let I : QualitativeCover E := ⟨Y.val ∩ Z.val, by
    intro H hH hsub
    exact Y.property H hH (hsub.trans Set.inter_subset_left)⟩
  have hI : IsGLB ({Y, Z} : Set (qualitativeCoverCore E C)) I := by
    constructor
    · intro W hW
      rcases Set.mem_insert_iff.mp hW with rfl | hW
      · exact Set.inter_subset_left
      · have heq : W = Z := Set.mem_singleton_iff.mp hW
        subst W
        exact Set.inter_subset_right
    · intro W hW
      exact Set.subset_inter (hW (by simp)) (hW (by simp))
  exact congrArg Subtype.val
    ((DIDomainObject.inf_isGLB (qualitativeCoverCore E C) Y Z).unique hI)

theorem section_stable (E : FinitaryPrimeEventStructure A) (C : QualitativeCoverClosure E) :
    IsStable (causalConfigurationCore E) (qualitativeCoverCore E C) (sectionMap E) := by
  refine ⟨section_scottContinuous E, ?_⟩
  intro X Y _hcompat
  apply Subtype.ext
  change (X ⊓ Y : causalConfigurationCore E).val =
    (sectionMap E X ⊓ sectionMap E Y : qualitativeCoverCore E C).val
  rw [configuration_inf_val, cover_inf_val]
  rfl

theorem retraction_stable (E : FinitaryPrimeEventStructure A) (C : QualitativeCoverClosure E) :
    IsStable (qualitativeCoverCore E C) (causalConfigurationCore E) (retractionMap E) := by
  refine ⟨retraction_scottContinuous E, ?_⟩
  intro Y Z _hcompat
  apply Subtype.ext
  change lowerInterior (Y ⊓ Z : qualitativeCoverCore E C).val =
    (retractionMap E Y ⊓ retractionMap E Z : causalConfigurationCore E).val
  rw [cover_inf_val, configuration_inf_val, lowerInterior_inter]
  rfl

end DIDomainClassification.CausalCoverSupport

namespace DIDomainClassification.Section04
open EventStructures CausalCoverSupport

theorem causalRetraction : CausalRetractionStatement.{u} := by
  intro A _ E
  let C : QualitativeCoverClosure E := closure E
  let s : StableHom (causalConfigurationCore E) (qualitativeCoverCore E C) :=
    StableHom.ofFunction (sectionMap E) (section_stable E C)
  let r : StableHom (qualitativeCoverCore E C) (causalConfigurationCore E) :=
    StableHom.ofFunction (retractionMap E) (retraction_stable E C)
  refine ⟨C, s, r, ?_, ?_, ?_, ?_⟩
  · intro X
    rfl
  · intro Y
    rfl
  · exact leftInverse E
  · exact composite_subset E

end DIDomainClassification.Section04
