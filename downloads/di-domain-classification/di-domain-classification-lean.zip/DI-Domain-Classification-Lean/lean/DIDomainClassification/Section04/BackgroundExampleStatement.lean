import DIDomainClassification.Section04.FiniteCategoryModels
import DIDomainClassification.Section04.CausalConflicts
import Mathlib.Tactic.DeriveFintype

/-! ONLY the four-event source example928--958. The raw order, forbidden
triple and three printed set formulas are DATA. The event structure, failure
of stability, corrected stable maps and splitting are UNPROVED OUTPUTS. -/

set_option autoImplicit false
noncomputable section

namespace DIDomainClassification.Section04.BackgroundExampleModels

inductive Event where
  | c | a | b | d
  deriving DecidableEq, Fintype

def Rel (x y : Event) : Prop := x = Event.c ∨ x = y

instance : PartialOrder Event where
  le := Rel
  le_refl x := Or.inr rfl
  le_trans _ _ _ hxy hyz := by
    rcases hxy with hx | hxy
    · exact Or.inl hx
    · exact hxy ▸ hyz
  le_antisymm _ _ hxy hyx := by
    rcases hxy with hx | hxy
    · rcases hyx with hy | hyx
      · exact hx.trans hy.symm
      · exact hyx.symm
    · exact hxy

def forbiddenTriple : Set Event := {Event.a, Event.b, Event.d}

def consistency : Set (Set Event) := {F | F.Finite ∧ ¬ forbiddenTriple ⊆ F}

def leaf (i : Fin 3) : Event :=
  match i.val with
  | 0 => Event.a
  | 1 => Event.b
  | _ => Event.d

def closureValues (S : Set (Fin 3)) : Set Event :=
  {x | ∃ i ∈ S, x ≤ leaf i}

def sectionValues (S : Set (Fin 3)) : Set Event := {Event.c} ∪ leaf '' S

def retractionValues (X : Set Event) : Set (Fin 3) := leaf ⁻¹' X

abbrev Three := FiniteCategoryModels.CubeCarrier.{0} 3 (by decide)

theorem event_le_iff (x y : Event) : x ≤ y ↔ x = Event.c ∨ x = y := Iff.rfl

end DIDomainClassification.Section04.BackgroundExampleModels

namespace DIDomainClassification.Section04

open Preliminaries EventStructures FiniteCategoryModels BackgroundExampleModels

def BackgroundExampleStatement : Prop :=
  ∃ (E : FinitaryPrimeEventStructure Event),
    E.Con = consistency ∧ causalConflictFamily E = {forbiddenTriple} ∧
    closureValues ({0} : Set (Fin 3)) ∩ closureValues ({1} : Set (Fin 3)) = {Event.c} ∧
    closureValues (∅ : Set (Fin 3)) = ∅ ∧
    closureValues ({0} : Set (Fin 3)) ∩ closureValues ({1} : Set (Fin 3)) ≠
      closureValues (∅ : Set (Fin 3)) ∧
    ∃ (hCube : IsCountablyBasedDIDomain Three) (closure : Three → Configuration E),
      (∀ S, (closure S).val = closureValues S.down.val) ∧
      ¬ IsStable (cubeCore 3 (by decide) hCube.1) (configurationCore E) closure ∧
      ∃ (s : StableHom (cubeCore 3 (by decide) hCube.1) (configurationCore E))
        (r : StableHom (configurationCore E) (cubeCore 3 (by decide) hCube.1)),
        (∀ S, (s S).val = sectionValues S.down.val) ∧
        (∀ X, (r X).down.val = retractionValues X.val) ∧
        Function.LeftInverse (r : Configuration E → Three) (s : Three → Configuration E)

end DIDomainClassification.Section04
