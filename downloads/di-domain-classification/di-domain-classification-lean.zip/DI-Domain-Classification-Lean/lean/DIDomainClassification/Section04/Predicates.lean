import DIDomainClassification.Support.PredicateCliqueIso

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

theorem predicateReconstruction : PredicateReconstructionStatement.{u} :=
  PredicateTriggers.reconstruct

theorem predicates : PredicatesStatement.{u} := by
  intro D
  refine ⟨PredicateCliqueIso.cliqueCountablyBased D, PredicateCliqueIso.stableIso D,
    ?_, ?_, PredicateCliqueIso.order_iff D, PredicateTriggers.reconstruct D⟩
  · intro f
    rfl
  · intro M x
    rfl

end DIDomainClassification.Section04
