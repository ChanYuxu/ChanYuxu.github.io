import DIDomainClassification.Section02.BasicDomains
import DIDomainClassification.Section02.StableCategory
import DIDomainClassification.Support.ConfigurationDomain
import Mathlib.Order.ULift

/-! Literal finite-domain carriers and output-certificate wrappers only.
No truncated-cube domain/retraction theorem is proved or assumed globally. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04.FiniteCategoryModels

open Preliminaries EventStructures

abbrev CubeCarrier (n : ℕ) (hn : 2 ≤ n) : Type u :=
  ULift.{u} (BasicDomains.TruncatedCube n hn)

def cubeOrderIso (n : ℕ) (hn : 2 ≤ n) :
    CubeCarrier.{u} n hn ≃o BasicDomains.TruncatedCube n hn where
  toFun x := x.down
  invFun x := ⟨x⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

def cubeCore (n : ℕ) (hn : 2 ≤ n) (h : IsDIDomain (CubeCarrier.{u} n hn)) :
    DIDomainObject.{u} := DIDomainObject.ofType (CubeCarrier n hn) h

def cubeObject (n : ℕ) (hn : 2 ≤ n)
    (h : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn)) : CountablyBasedDIDomain.{u} :=
  CountablyBasedDIDomain.ofType (CubeCarrier n hn) h.1 h.2

abbrev CubePower (n : ℕ) (hn : 2 ≤ n) (m : ℕ) : Type u :=
  Fin m → CubeCarrier.{u} n hn

def powerCore (n : ℕ) (hn : 2 ≤ n) (m : ℕ)
    (h : IsDIDomain (CubePower.{u} n hn m)) : DIDomainObject.{u} :=
  DIDomainObject.ofType (CubePower n hn m) h

def configurationCore {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A) :
    DIDomainObject.{u} :=
  DIDomainObject.ofType (Configuration E) (ConfigurationDomain.dIDomain E)

theorem cubeCore_order (n : ℕ) (hn : 2 ≤ n)
    (h : IsDIDomain (CubeCarrier.{u} n hn)) :
    (cubeCore n hn h).partialOrder = (inferInstance : PartialOrder (CubeCarrier n hn)) := rfl

theorem cubePower_le_iff (n : ℕ) (hn : 2 ≤ n) (m : ℕ)
    (x y : CubePower.{u} n hn m) :
    x ≤ y ↔ ∀ i, (x i).down.val ⊆ (y i).down.val := Iff.rfl

end DIDomainClassification.Section04.FiniteCategoryModels
