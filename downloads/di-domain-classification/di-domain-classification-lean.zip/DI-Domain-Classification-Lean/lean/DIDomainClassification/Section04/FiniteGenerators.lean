import DIDomainClassification.Support.FiniteGeneratorProofs

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

theorem finiteForbiddenProductConstruction : FiniteForbiddenProductConstructionStatement.{u} :=
  FiniteForbiddenProduct.printedConstruction

theorem finiteGenerators : FiniteGeneratorsStatement.{u} := by
  intro n hn
  constructor
  · intro D hFinite hN
    letI : Finite D := hFinite
    exact FiniteGeneratorProofs.intoFinitePower n hn D hN
  · intro D hFinite hDegree
    letI : Finite D := hFinite
    exact FiniteGeneratorProofs.containsDegreeCube n hn D hDegree

end DIDomainClassification.Section04
