import DIDomainClassification.Section04.AdditionalSourceModels

/-! UNPROVED source964--975, arbitrary causal event carrier.
Only countability of the ACTUAL configuration compact set is assumed. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04
open Preliminaries EventStructures CoherenceDegree AdditionalSourceModels

def QualitativeCoherenceBoundStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)) (n : ℕ), 2 ≤ n →
      (coherenceDegree hE.1.toIsScottDomain ≤ (n : Ordinal.{u+1}) ↔
        ∀ H ∈ causalConflictFamily E, H.ncard ≤ n)

def QualitativeEmptyFamilyStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)),
    causalConflictFamily E = ∅ → coherenceDegree hE.1.toIsScottDomain = 0

/-- The actual attained maximum, not a caller-supplied maximum witness. -/
def QualitativeFiniteMaximumStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)),
    (causalConflictFamily E).Nonempty →
    (∃ n : ℕ, ∀ H ∈ causalConflictFamily E, H.ncard ≤ n) →
    ∃ (m : ℕ) (H : Set A), H ∈ causalConflictFamily E ∧ H.ncard = m ∧
      (∀ K ∈ causalConflictFamily E, K.ncard ≤ m) ∧
      coherenceDegree hE.1.toIsScottDomain = (m : Ordinal.{u+1})

def QualitativeCoherenceStatement : Prop :=
  QualitativeCoherenceBoundStatement.{u} ∧ QualitativeEmptyFamilyStatement.{u} ∧
    QualitativeFiniteMaximumStatement.{u}

def FiniteObstructionStatement : Prop :=
  ∀ (D : CountablyBasedDIDomain.{u}) (n : ℕ) (hn : 2 ≤ n),
    ∃ h : IsCountablyBasedDIDomain (FiniteCategoryModels.CubeCarrier.{u} (n+1) (by omega)),
      (Subcategories.objectDegree D ≤ (n : Ordinal.{u+1}) ↔
        ¬ HasStableRetraction
          (FiniteCategoryModels.cubeObject (n+1) (by omega) h).toDIDomainObject
          D.toDIDomainObject)

end DIDomainClassification.Section04
