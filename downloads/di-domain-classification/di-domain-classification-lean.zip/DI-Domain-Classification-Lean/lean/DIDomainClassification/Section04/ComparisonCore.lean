import DIDomainClassification.Support.ComparisonRepresentation

/-! Lemma comparison-core on all countably based native dI-domains. -/
set_option autoImplicit false
universe u

namespace DIDomainClassification.Section04

theorem comparisonCore : ComparisonCoreStatement.{u} :=
  ComparisonRepresentation.comparison

end DIDomainClassification.Section04
