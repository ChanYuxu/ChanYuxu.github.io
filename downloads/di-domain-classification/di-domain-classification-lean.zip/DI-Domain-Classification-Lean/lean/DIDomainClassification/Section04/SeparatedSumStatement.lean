import DIDomainClassification.Section04.AdditionalSourceModels
import Mathlib.Data.Sigma.Order
import Mathlib.Order.WithBot

/-! Literal separated sum (new bottom, disjoint components), not coalescing
component bottoms. All closure and map properties below remain UNPROVED. -/
set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.Section04.SeparatedSumModels
open Preliminaries AdditionalSourceModels Section03.StableFunctionModels

abbrev Carrier {I : Type v} (H : I → CountablyBasedDIDomain.{u}) :=
  WithBot (Σ i, Core (H i))

def bottom {I : Type v} (H : I → CountablyBasedDIDomain.{u}) : Carrier H := ⊥
def component {I : Type v} (H : I → CountablyBasedDIDomain.{u}) (i : I) (x : Core (H i)) :
    Carrier H := ((⟨i, x⟩ : Σ i, Core (H i)) : WithBot (Σ i, Core (H i)))

def sectionValues {I : Type v} (H : I → CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{w}) (f : ∀ i, StableHom (Core (H i)) (Core E)) :
    Carrier H → Core E
  | none => (Core E).isDIDomain.toIsScottDomain.bottom
  | some x => f x.1 x.2

def flatSectionValues (E : CountablyBasedDIDomain.{u}) (f : ℕ → Core E)
    (x : FlatCarrier.{u}) : Core E :=
  match x.down with
  | BasicDomains.FlatNat.bot => (Core E).isDIDomain.toIsScottDomain.bottom
  | BasicDomains.FlatNat.nat n => f n

end DIDomainClassification.Section04.SeparatedSumModels

namespace DIDomainClassification.Section04
open Preliminaries CoherenceDegree AdditionalSourceModels SeparatedSumModels
open Section03.StableFunctionModels

def SeparatedSumGeneralStatement : Prop :=
  ∀ (I : Type v) [Countable I] [Nonempty I]
    (H : I → CountablyBasedDIDomain.{u}) (E : CountablyBasedDIDomain.{w}),
    ∃ (hH : IsCountablyBasedDIDomain (Carrier H))
      (hP : IsCountablyBasedDIDomain (∀ i, StableHom (Core (H i)) (Core E))),
      let HC := (cbObject (Carrier H) hH).toDIDomainObject
      let PC := (cbObject (∀ i, StableHom (Core (H i)) (Core E)) hP).toDIDomainObject
      let FC := functionCore HC (Core E)
      (∀ x : Carrier H, IsCompactElement x ↔ x = bottom H ∨
        ∃ (i : I) (k : Core (H i)), IsCompactElement k ∧ x = component H i k) ∧
      ((∀ i, IsNCoherent (Core (H i)).isDIDomain.toIsScottDomain 2 (by decide)) →
        IsNCoherent hH.1.toIsScottDomain 2 (by decide)) ∧
      ∃ (S : StableHom PC FC) (R : StableHom FC PC),
        (∀ (f : ∀ i, StableHom (Core (H i)) (Core E)) (x : Carrier H),
          functionValue HC (Core E) (S f) x = sectionValues H E f x) ∧
        (∀ (g : FC) (i : I) (x : Core (H i)),
          let values : ∀ i, StableHom (Core (H i)) (Core E) := R g
          values i x = functionValue HC (Core E) g (component H i x)) ∧
        Function.LeftInverse (R : FC → PC) (S : PC → FC)

def CountablePowersRetractionStatement : Prop :=
  ∀ E : CountablyBasedDIDomain.{u},
    ∃ (hFlat : IsCountablyBasedDIDomain FlatCarrier.{u})
      (hP : IsCountablyBasedDIDomain (ℕ → Core E)),
      let NC := (flatObject hFlat).toDIDomainObject
      let PC := (cbObject (ℕ → Core E) hP).toDIDomainObject
      let FC := functionCore NC (Core E)
      IsNCoherent hFlat.1.toIsScottDomain 2 (by decide) ∧
      ∃ (S : StableHom PC FC) (R : StableHom FC PC),
        (∀ (f : ℕ → Core E) (x : FlatCarrier.{u}),
          functionValue NC (Core E) (S f) x = flatSectionValues E f x) ∧
        (∀ (g : FC) (n : ℕ),
          let values : ℕ → Core E := R g
          values n = functionValue NC (Core E) g (ULift.up (BasicDomains.FlatNat.nat n))) ∧
        Function.LeftInverse (R : FC → PC) (S : PC → FC)

def SeparatedSumStatement : Prop :=
  SeparatedSumGeneralStatement.{u,v,w} ∧ CountablePowersRetractionStatement.{u}

end DIDomainClassification.Section04
