import DIDomainClassification.Section05.UniversalSourceStatements
import DIDomainClassification.Support.OrdinalCutWitnesses

/-! The literal T3 and powerset-of-naturals witnesses printed after the cut
inclusion proposition. Both membership differences and both non-inclusions
are outputs, with no additional finiteness or degree premise. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section04

open Preliminaries CoherenceDegree Subcategories OrdinalCutWitnesses
open FiniteCategoryModels AdditionalSourceModels

theorem cubeThree_cutWitness :
    FiniteDomainCut Ordinal.omega0 (finiteCube.{u} 3 (by decide)) ∧
      ¬ DomainCut 3 (finiteCube.{u} 3 (by decide)) := by
  constructor
  · refine ⟨?_, finiteCube_finite 3 (by decide)⟩
    change objectDegree (finiteCube 3 _) < Ordinal.omega0
    rw [finiteCube_degree]
    exact Ordinal.natCast_lt_omega0 3
  · change ¬ objectDegree (finiteCube 3 _) < 3
    rw [finiteCube_degree]
    exact lt_irrefl _

theorem powerset_cutWitness :
    DomainCut 3 infinitePowerset.{u} ∧
      ¬ FiniteDomainCut Ordinal.omega0 infinitePowerset.{u} := by
  constructor
  · change objectDegree infinitePowerset < 3
    rw [infinitePowerset_degree]
    exact_mod_cast (by decide : (0 : ℕ) < 3)
  · intro h
    exact infinitePowerset_not_finite h.2

theorem crossFamilyIncomparability : CrossFamilyIncomparabilityStatement.{u} := by
  refine ⟨⟨FiniteCubeRetractions.cubeCountablyBased 3 (by decide), cubeThree_cutWitness⟩,
    ⟨powersetCB, powerset_cutWitness⟩, ?_, ?_⟩
  · intro hInc
    exact cubeThree_cutWitness.2 (hInc _ cubeThree_cutWitness.1)
  · intro hInc
    exact powerset_cutWitness.2 (hInc _ powerset_cutWitness.1)

end DIDomainClassification.Section04
