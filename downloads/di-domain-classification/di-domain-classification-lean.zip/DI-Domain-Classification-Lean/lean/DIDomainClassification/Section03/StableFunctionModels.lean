import DIDomainClassification.Support.StableClosureWitness
import DIDomainClassification.Support.PointwiseScottClosure

/-!
Literal models for the Section3 stable-function interfaces. The stable
exponential uses the existing PROVED closure witness, never an input record
containing any of the new theorem conclusions. The all-Scott carrier is a
different actual subtype with its native POINTWISE order. Only definitional
carrier/order/function bridges are proved in this staged interface module.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section03.StableFunctionModels

open Preliminaries

abbrev Core (D : CountablyBasedDIDomain.{u}) := D.toDIDomainObject

abbrev StableSpace (D : CountablyBasedDIDomain.{u}) (E : CountablyBasedDIDomain.{v}) :=
  StableHom (Core D) (Core E)

abbrev PointwiseSpace (D : CountablyBasedDIDomain.{u}) (E : CountablyBasedDIDomain.{v}) :=
  ScottHom (Core D) (Core E)

def forgetStable {D : CountablyBasedDIDomain.{u}} {E : CountablyBasedDIDomain.{v}}
    (f : StableSpace D E) : PointwiseSpace D E :=
  ⟨fun x => f x, (StableHom.isStable f).1⟩

theorem forgetStable_apply {D : CountablyBasedDIDomain.{u}}
    {E : CountablyBasedDIDomain.{v}} (f : StableSpace D E) (x : Core D) :
    (forgetStable f).val x = f x := rfl

theorem stableSpace_order_iff {D : CountablyBasedDIDomain.{u}}
    {E : CountablyBasedDIDomain.{v}} (f g : StableSpace D E) :
    f ≤ g ↔ ∀ x y : Core D, x ≤ y → f x = f y ⊓ g x := Iff.rfl

theorem pointwiseSpace_order_iff {D : CountablyBasedDIDomain.{u}}
    {E : CountablyBasedDIDomain.{v}} (f g : PointwiseSpace D E) :
    f ≤ g ↔ ∀ x : Core D, f.val x ≤ g.val x := Iff.rfl

theorem pointwiseSpace_eq_raw (D : CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{v}) :
    PointwiseSpace D E = {f : Core D → Core E // ScottContinuous f} := rfl

theorem forgetStable_le_iff {D : CountablyBasedDIDomain.{u}}
    {E : CountablyBasedDIDomain.{v}} (f : StableSpace D E) (g : PointwiseSpace D E) :
    forgetStable f ≤ g ↔ ∀ x : Core D, f x ≤ g.val x := Iff.rfl

abbrev trueClosure : Section02.StableBackground.DomainClosure.{u} :=
  StableClosureWitness.domainClosure.{u}

abbrev exponential (D E : CountablyBasedDIDomain.{u}) : CountablyBasedDIDomain.{u} :=
  Section02.StableBackground.exponentialObject trueClosure D E

theorem exponential_carrier (D E : CountablyBasedDIDomain.{u}) :
    (Core (exponential D E)).Carrier = StableSpace D E := rfl

theorem exponential_order (D E : CountablyBasedDIDomain.{u}) :
    (Core (exponential D E)).partialOrder =
      (@StableHom.instPartialOrder (Core D) (Core E)) := rfl

/-- Existing proved Scott structure on the literal STABLE-ordered carrier. -/
abbrev stableScottDomain (D E : CountablyBasedDIDomain.{u}) :
    IsScottDomain (StableSpace D E) :=
  (trueClosure.exponential D E).1.toIsScottDomain

/-- Existing proved Scott structure on the literal ALL-Scott pointwise carrier. -/
abbrev pointwiseScottDomain (D : CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{v}) : IsScottDomain (PointwiseSpace D E) :=
  PointwiseFunctionSupport.space_isScottDomain
    (Core D).isDIDomain.toIsScottDomain (Core E).isDIDomain.toIsScottDomain

/-- Actual cardinality one: a specified inhabitant and equality of EVERY point.
This is not mere subsingleton-ness of a potentially empty carrier. -/
def IsSingletonCarrier (X : Type u) : Prop := ∃ x : X, ∀ y : X, y = x

theorem isSingletonCarrier_iff (X : Type u) :
    IsSingletonCarrier X ↔ ∃ x : X, ∀ y : X, y = x := Iff.rfl

end DIDomainClassification.Section03.StableFunctionModels

