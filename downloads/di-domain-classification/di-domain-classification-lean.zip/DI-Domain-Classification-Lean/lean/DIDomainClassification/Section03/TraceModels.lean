import DIDomainClassification.Support.MinimalInputTraces
import DIDomainClassification.Section02.StableCategory

/-!
# Minimal-input traces and predecessor closure

Source manuscript.tex:498--532, frozen SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The source and represented target have countably many actual compact elements.
No countability of their point carriers, or of the supplied event carrier,
is imposed. Trace minimality tests every smaller point. The support C(k,a)
uses every event predecessor and its genuinely unique minimal input.

The final source-facing proposition is unproved here. Generic supporting
lemmas used to define the actual predecessor inputs were proved separately.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Section03.TraceModels

open Preliminaries EventStructures

abbrev Core (D : CountablyBasedDIDomain.{u}) := D.toDIDomainObject

abbrev Target {A : Type v} [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)) : DIDomainObject.{v} :=
  DIDomainObject.ofType (Configuration E) hE.1

variable (D : CountablyBasedDIDomain.{u}) {A : Type v} [PartialOrder A]
  (E : FinitaryPrimeEventStructure A) (hE : IsCountablyBasedDIDomain (Configuration E))
  (f : StableHom (Core D) (Target E hE))

/-- The source's literal set Tr(f), including all-point minimality. -/
def Trace : Set (Core D × A) := MinimalInputTraces.trace (fun x => f x)

theorem trace_eq : Trace D E hE f = MinimalInputTraces.trace (fun x => f x) := rfl

/-- A genuine bridge between the native map and chosen intrinsic meet conventions. -/
theorem preservesCompatibleMeets :
    MinimalInputTraces.PreservesCompatibleMeets
      (Core D).isDIDomain.toIsScottDomain (fun x => f x) := by
  intro x y hxy
  exact (StableHom.isStable f).2 x y hxy

/-- The actual unique minimal input for every point in the full event ideal. -/
def predecessorInput {k : Core D} {a : A} (hk : (k, a) ∈ Trace D E hE f)
    (b : Set.Iic a) : Core D :=
  MinimalInputTraces.predecessorInput (Core D).isDIDomain (StableHom.isStable f).1
    (preservesCompatibleMeets D E hE f) hk b

/-- Exactly C(k,a)={(k_b,b):b≤a}, with no chosen finite predecessor subfamily. -/
def C {k : Core D} {a : A} (hk : (k, a) ∈ Trace D E hE f) : Set (Core D × A) :=
  Set.range (fun b : Set.Iic a => (predecessorInput D E hE f hk b, b.val))

/-- All the source's finite-subset and predecessor-closure conditions. -/
def FinitePredecessorClosed (F : Set (Core D × A)) : Prop :=
  F.Finite ∧ F ⊆ Trace D E hE f ∧
    ∀ k a, (k, a) ∈ F → ∀ hk : (k, a) ∈ Trace D E hE f, C D E hE f hk ⊆ F

theorem C_eq_predecessorSupport {k : Core D} {a : A}
    (hk : (k, a) ∈ Trace D E hE f) :
    C D E hE f hk = MinimalInputTraces.predecessorSupport (fun x => f x) k a := by
  exact (MinimalInputTraces.predecessorSupport_eq_range (Core D).isDIDomain
    (StableHom.isStable f).1 (preservesCompatibleMeets D E hE f) hk).symm

theorem finitePredecessorClosed_iff (F : Set (Core D × A)) :
    FinitePredecessorClosed D E hE f F ↔
      F.Finite ∧ F ⊆ Trace D E hE f ∧
        MinimalInputTraces.IsPredecessorClosed (fun x => f x) F := by
  constructor
  · rintro ⟨hfinite, hsub, hclosed⟩
    refine ⟨hfinite, hsub, ?_⟩
    rintro ⟨k, a⟩ hp
    rw [← C_eq_predecessorSupport D E hE f (hsub hp)]
    exact hclosed k a hp (hsub hp)
  · rintro ⟨hfinite, hsub, hclosed⟩
    refine ⟨hfinite, hsub, ?_⟩
    intro k a hp hk
    rw [C_eq_predecessorSupport D E hE f hk]
    exact hclosed (k, a) hp

end DIDomainClassification.Section03.TraceModels

namespace DIDomainClassification.Section03

open Preliminaries EventStructures TraceModels

/-- Source507--514: a compact observation, followed by an actual minimal trigger. -/
def TraceInputExistenceStatement : Prop :=
  ∀ (D : CountablyBasedDIDomain.{u}) (A : Type v) [PartialOrder A]
    (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (f : StableHom (Core D) (Target E hE)) (x : Core D) (a : A),
    a ∈ (f x).val →
      (∃ c : Core D, IsCompactElement c ∧ c ≤ x ∧ a ∈ (f c).val) ∧
      ∃ k : Core D, k ≤ x ∧ (k, a) ∈ Trace D E hE f

/-- Source516--523: equality only below a common upper bound, and the meet identity. -/
def TraceInputUniquenessStatement : Prop :=
  ∀ (D : CountablyBasedDIDomain.{u}) (A : Type v) [PartialOrder A]
    (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (f : StableHom (Core D) (Target E hE)) (k l x : Core D) (a : A),
    (k, a) ∈ Trace D E hE f → (l, a) ∈ Trace D E hE f → k ≤ x → l ≤ x →
      k = l ∧ l = k ⊓ l

/-- Exact unproved source-facing minimal-input claim p:trace-inputs. -/
def TraceInputsStatement : Prop :=
  TraceInputExistenceStatement.{u,v} ∧ TraceInputUniquenessStatement.{u,v}

end DIDomainClassification.Section03
