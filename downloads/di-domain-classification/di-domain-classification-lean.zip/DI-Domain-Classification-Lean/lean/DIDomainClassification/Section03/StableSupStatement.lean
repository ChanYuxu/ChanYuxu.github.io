import DIDomainClassification.Section03.StableFunctionModels
/-!
Unproved source-facing Lemma3.3 specification, manuscript.tex:676--687;
written proof688--739, inherited countably-based dI context498.
No stable supremum/source proof is implemented here.
-/

set_option autoImplicit false
universe u v

namespace DIDomainClassification.Section03.StableFunctionModels

def FamilyValues (D : CountablyBasedDIDomain.{u}) (E : CountablyBasedDIDomain.{v})
    (A : Set (StableSpace D E)) (x : Core D) : Set (Core E) :=
  (fun f : StableSpace D E => f x) '' A

theorem familyValues_mem_iff (D : CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{v}) (A : Set (StableSpace D E))
    (x : Core D) (e : Core E) :
    e ∈ FamilyValues D E A x ↔ ∃ f ∈ A, f x = e := Iff.rfl

end DIDomainClassification.Section03.StableFunctionModels

namespace DIDomainClassification.Section03

open StableFunctionModels

/-- EXACT unproved Lemma3.3. A may be arbitrary/infinite. Nonemptiness,
pairwise common STABLE upper bounds, and pointwise boundedness are the only
family hypotheses. A common stable upper bound of the WHOLE family is an
OUTPUT consequence of the requested genuine stable IsLUB, never an input.
-/
def StableSupStatement : Prop :=
  ∀ (D E : CountablyBasedDIDomain.{u}) (A : Set (StableSpace D E)),
    A.Nonempty →
    (∀ f ∈ A, ∀ g ∈ A,
      ∃ k : StableSpace D E, f ≤ k ∧ g ≤ k) →
    (∀ x : Core D, BddAbove (FamilyValues D E A x)) →
    ∃ h : StableSpace D E,
      IsLUB A h ∧ ∀ x : Core D, IsLUB (FamilyValues D E A x) (h x)

end DIDomainClassification.Section03

