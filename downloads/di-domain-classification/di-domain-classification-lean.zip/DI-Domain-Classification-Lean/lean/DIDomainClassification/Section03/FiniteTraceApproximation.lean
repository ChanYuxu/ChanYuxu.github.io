import DIDomainClassification.Section03.FiniteTraceApproximationStatement

/-! Source-facing Lemma3.1 and its pointwise-union assertion. The family
ranges over EVERY admissible finite predecessor-closed trace subset. -/
set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section03.FiniteTraceProof
open Preliminaries EventStructures TraceModels FiniteTraceModels
open FiniteTraceApproximations StableExponentialClosure

variable (D : CountablyBasedDIDomain.{u}) {A : Type v} [PartialOrder A]
  (E : FinitaryPrimeEventStructure A)
  (hE : IsCountablyBasedDIDomain (Configuration E))
  (f : StableHom (Core D) (Target E hE))

def admissibleOfSupport (S : FiniteSupport (fun x : Core D => f x)) :
    AdmissibleSupports D E hE f :=
  ⟨S.carrier, (finitePredecessorClosed_iff D E hE f S.carrier).mpr
    ⟨S.finite, S.subtrace, S.closed⟩⟩

theorem support_admissibleOfSupport (S : FiniteSupport (fun x : Core D => f x)) :
    support D E hE f (admissibleOfSupport D E hE f S).val
      (admissibleOfSupport D E hE f S).property = S := by
  cases S
  rfl

theorem family_eq_approximants :
    family D E hE f = approximants (Core D).isDIDomain
      (StableHom.isStable f).1 (preservesCompatibleMeets D E hE f) := by
  ext g
  constructor
  · rintro ⟨F, rfl⟩
    exact ⟨support D E hE f F.val F.property, rfl⟩
  · rintro ⟨S, rfl⟩
    refine ⟨admissibleOfSupport D E hE f S, ?_⟩
    change approximationHom _ _ _ (support D E hE f
      (admissibleOfSupport D E hE f S).val
      (admissibleOfSupport D E hE f S).property) = _
    rw [support_admissibleOfSupport]

end DIDomainClassification.Section03.FiniteTraceProof

namespace DIDomainClassification.Section03
open Preliminaries EventStructures TraceModels FiniteTraceModels FiniteTraceProof
open FiniteTraceApproximations StableExponentialClosure

theorem finiteTraceApproximation : FiniteTraceApproximationStatement.{u,v} := by
  intro D A _ E hE f
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro F hF
    refine ⟨StableHom.isStable (reconstructionHom D E hE f F hF), ?_⟩
    have h := approximationHom_le_base (Core D).isDIDomain
      (StableHom.isStable f).1 (preservesCompatibleMeets D E hE f)
      (support D E hE f F hF)
    simpa only [baseHom_eq] using h
  · intro F G hF hG hFG
    exact approximationHom_mono (Core D).isDIDomain (StableHom.isStable f).1
      (preservesCompatibleMeets D E hE f)
      (support D E hE f F hF) (support D E hE f G hG) hFG
  · rw [family_eq_approximants]
    exact approximants_directed (Core D).isDIDomain (StableHom.isStable f).1
      (preservesCompatibleMeets D E hE f)
  · rw [family_eq_approximants]
    exact hom_approximation_isLUB (Core D).isDIDomain f

theorem finiteTracePointwiseUnion : FiniteTracePointwiseUnionStatement.{u,v} := by
  intro D A _ E hE f x
  ext a
  constructor
  · intro ha
    rw [pointwise_union (Core D).isDIDomain (StableHom.isStable f).1
      (preservesCompatibleMeets D E hE f) x] at ha
    obtain ⟨S, haS⟩ := Set.mem_iUnion.mp ha
    refine Set.mem_iUnion.mpr ⟨admissibleOfSupport D E hE f S, ?_⟩
    change a ∈ (approximationHom _ _ _ (support D E hE f
      (admissibleOfSupport D E hE f S).val
      (admissibleOfSupport D E hE f S).property) x).val
    rw [support_admissibleOfSupport]
    exact haS
  · intro ha
    obtain ⟨F, haF⟩ := Set.mem_iUnion.mp ha
    exact values_subset (StableHom.isStable f).1
      (support D E hE f F.val F.property).subtrace x haF

end DIDomainClassification.Section03
