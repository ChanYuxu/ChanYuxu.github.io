import DIDomainClassification.Section03.StableFunctionModels
import DIDomainClassification.Section02.RankDegree
import Mathlib.CategoryTheory.Iso

/-!
Unproved source-facing Theorem3.4 specification, manuscript.tex:741--747;
written proof748--795. The exponential is the actual stable-ordered carrier
with the SAME proved domain-closure witness. No degree equality, singleton
isomorphism or uniqueness proof is supplied in this design-stage module.
-/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section03

open CategoryTheory Preliminaries CoherenceDegree StableFunctionModels

/-- Main nontrivial clause: both objects have countably many ACTUAL compacts,
and their whole carriers are nontrivial, not assumed finite or countable. -/
def FunctionDegreeNontrivialStatement : Prop :=
  ∀ (D E : CountablyBasedDIDomain.{u}),
    Nontrivial (Core D) → Nontrivial (Core E) →
      coherenceDegree (stableScottDomain D E) =
        max (2 : Ordinal.{u+1}) (coherenceDegree (Core E).isDIDomain.toIsScottDomain)

/-- Genuine isomorphism in the ACTUAL category of stable maps: hom and inv
are native StableHom maps and satisfy both inverse laws. Not merely OrderIso.
-/
def FunctionDegreeSingletonInputStatement : Prop :=
  ∀ (D E : CountablyBasedDIDomain.{u}),
    IsSingletonCarrier (Core D) → Nonempty (exponential D E ≅ E)

/-- Actual singleton cardinality of the stable-function carrier, including
existence. This is not a vacuous Subsingleton assertion. -/
def FunctionDegreeSingletonOutputStatement : Prop :=
  ∀ (D E : CountablyBasedDIDomain.{u}),
    IsSingletonCarrier (Core E) → IsSingletonCarrier (StableSpace D E)

/-- All three clauses of the printed Theorem3.4, deliberately UNPROVED. -/
def FunctionDegreeStatement : Prop :=
  FunctionDegreeNontrivialStatement.{u} ∧
    FunctionDegreeSingletonInputStatement.{u} ∧ FunctionDegreeSingletonOutputStatement.{u}

end DIDomainClassification.Section03

