import DIDomainClassification.Section03.StableFunctionModels
/-!
Unproved source-facing Lemma3.2 specification, manuscript.tex:622--637;
written proof638--672. SourceSHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The source functions g are ALL Scott-continuous maps, not only stable ones.
No source result is proved in this design-stage module.
-/

set_option autoImplicit false
universe u v

namespace DIDomainClassification.Section03.StableFunctionModels

open Preliminaries

/-- The printed actual compact input/output tests, with m=0 permitted.
There is no bound or countability condition on the quantified g. -/
def FiniteTests (D : CountablyBasedDIDomain.{u}) (E : CountablyBasedDIDomain.{v})
    (p : StableSpace D E) (m : ℕ)
    (a : Fin m → ↥(CompactElements (Core D)))
    (b : Fin m → ↥(CompactElements (Core E))) : Prop :=
  ∀ g : PointwiseSpace D E,
    forgetStable p ≤ g ↔ ∀ i : Fin m, (b i).val ≤ g.val (a i).val

theorem finiteTests_iff (D : CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{v}) (p : StableSpace D E) (m : ℕ)
    (a : Fin m → ↥(CompactElements (Core D)))
    (b : Fin m → ↥(CompactElements (Core E))) :
    FiniteTests D E p m a b ↔
      ∀ g : PointwiseSpace D E,
        (∀ x : Core D, p x ≤ g.val x) ↔
          ∀ i : Fin m, (b i).val ≤ g.val (a i).val := Iff.rfl

end DIDomainClassification.Section03.StableFunctionModels

namespace DIDomainClassification.Section03

open Preliminaries StableFunctionModels

/-- EXACT unproved Lemma3.2, including its explicit empty-test case.
The premise is stable-order compactness; the first conclusion is compactness
in the DIFFERENT actual pointwise all-Scott carrier. The final clause permits
zero tests for a least stable p without prescribing a canonical enumeration.
-/
def CompactBridgeStatement : Prop :=
  ∀ (D E : CountablyBasedDIDomain.{u}) (p : StableSpace D E),
    IsCompactElement p →
      IsCompactElement (forgetStable p) ∧
      (∃ (m : ℕ) (a : Fin m → ↥(CompactElements (Core D)))
        (b : Fin m → ↥(CompactElements (Core E))), FiniteTests D E p m a b) ∧
      (IsLeast (Set.univ : Set (StableSpace D E)) p →
        ∃ (a : Fin 0 → ↥(CompactElements (Core D)))
          (b : Fin 0 → ↥(CompactElements (Core E))), FiniteTests D E p 0 a b)

end DIDomainClassification.Section03

