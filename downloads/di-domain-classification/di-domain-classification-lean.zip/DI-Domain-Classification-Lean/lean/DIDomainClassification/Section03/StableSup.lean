import DIDomainClassification.Section03.StableSupStatement
import DIDomainClassification.Support.PairwiseStableSup

/-! Source-facing Lemma3.3. The genuine pairwise-compatible union construction
requires no common stable bound of the whole family. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section03
open StableFunctionModels

theorem stableSup : StableSupStatement.{u} := by
  intro D E A _hne hPair hBound
  exact PairwiseStableSup.exists_native_supremum (Core D) (Core E) A hPair hBound

end DIDomainClassification.Section03
