import DIDomainClassification.Section03.CompactBridgeStatement
import DIDomainClassification.Support.StableHomGeneralClosure
import DIDomainClassification.Support.StableHomTraceOrder
import Mathlib.Data.Fintype.EquivFin

/-! Source-facing compact bridge. All test functions are Scott continuous,
not assumed stable. Finite input/output tests are actual compact elements. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section03.CompactBridgeProof

open Preliminaries EventStructures StableFunctionModels
open FiniteTraceApproximations StableExponentialClosure

theorem compact_of_tests (D E : CountablyBasedDIDomain.{u}) (p : StableSpace D E)
    (m : ℕ) (a : Fin m → ↥(CompactElements (Core D)))
    (b : Fin m → ↥(CompactElements (Core E))) (ht : FiniteTests D E p m a b) :
    IsCompactElement (forgetStable p) := by
  intro C s hC hs hps
  have hvalues := (PointwiseFunctionSupport.directed_isLUB_iff_values
    (Core E).isDIDomain.toIsScottDomain.algebraic.1 hC s).mp hs
  have htests := (ht s).mp hps
  have hEach : ∀ i : Fin m, ∃ g ∈ C, (b i).val ≤ g.val (a i).val := by
    intro i
    obtain ⟨z, hz, hbz⟩ := (b i).property
      (PointwiseFunctionSupport.values_directed hC (a i).val)
      (hvalues (a i).val) (htests i)
    obtain ⟨g, hg, rfl⟩ := hz
    exact ⟨g, hg, hbz⟩
  choose g hg hbg using hEach
  obtain ⟨k, hk, hGk⟩ := hC.exists_upper_finite
    (Set.finite_range g) (by rintro _ ⟨i, rfl⟩; exact hg i)
  refine ⟨k, hk, (ht k).mpr ?_⟩
  intro i
  exact (hbg i).trans (hGk (g i) ⟨i, rfl⟩ (a i).val)

theorem tests_of_compact (D E : CountablyBasedDIDomain.{u}) (p : StableSpace D E)
    (hp : IsCompactElement p) :
    ∃ (m : ℕ) (a : Fin m → ↥(CompactElements (Core D)))
      (b : Fin m → ↥(CompactElements (Core E))), FiniteTests D E p m a b := by
  let P := primeEventStructure (Core E)
  let e := primeEventOrderIso (Core E)
  let φ := codomainOrderIso (Core D) (Core E) (configurationObject P) e
  let q := φ p
  have hq : IsCompactElement q := (OrderIsoTransport.compact_iff φ p).mpr hp
  obtain ⟨S, hS⟩ := compact_eq_approximation (Core D).isDIDomain q hq
  letI : Fintype S.carrier := S.finite.fintype
  let m : ℕ := Fintype.card S.carrier
  let t : Fin m ≃ S.carrier := (Fintype.equivFin S.carrier).symm
  let a : Fin m → ↥(CompactElements (Core D)) :=
    fun i => ⟨(t i).val.1, (S.subtrace (t i).property).1⟩
  let b : Fin m → ↥(CompactElements (Core E)) :=
    fun i => ⟨((t i).val.2).val,
      FinitePrimeDecomposition.completePrime_isCompact ((t i).val.2).property⟩
  refine ⟨m, a, b, ?_⟩
  intro g
  constructor
  · intro hpg i
    have ha : (t i).val.2 ∈ (q (t i).val.1).val :=
      (S.subtrace (t i).property).2.1
    have hi : (t i).val.2 ∈ (e (g.val (t i).val.1)).val :=
      e.monotone (hpg (t i).val.1) ha
    exact hi
  · intro htests x
    apply e.le_iff_le.mp
    intro c hc
    change c ∈ (q x).val at hc
    have hsval := congrArg
      (fun h : StableHom (Core D) (configurationObject P) => (h x).val) hS
    have hc' : c ∈ (approximationHom (Core D).isDIDomain
        (StableHom.isStable q).1 (hom_preserves_meets (Core D).isDIDomain q) S x).val :=
      Eq.mpr (congrArg (fun X : Set (PrimeEventCarrier (Core E)) => c ∈ X) hsval) hc
    change ∃ k : Core D, (k, c) ∈ S.carrier ∧ k ≤ x at hc'
    obtain ⟨k, hkc, hkx⟩ := hc'
    let z : S.carrier := ⟨(k, c), hkc⟩
    let i : Fin m := t.symm z
    have hi : t i = z := t.apply_symm_apply z
    have htest : c.val ≤ g.val k := by
      have h := htests i
      change ((t i).val.2).val ≤ g.val (t i).val.1 at h
      simpa only [hi] using h
    exact htest.trans (g.property.monotone hkx)

def bottomStable (D E : CountablyBasedDIDomain.{u}) : StableSpace D E :=
  StableHom.ofFunction (fun _ => (Core E).isDIDomain.toIsScottDomain.bottom)
    ⟨ScottContinuous.const _, by intro x y _; exact (inf_idem _).symm⟩

theorem empty_tests_of_least (D E : CountablyBasedDIDomain.{u}) (p : StableSpace D E)
    (hp : IsLeast (Set.univ : Set (StableSpace D E)) p) :
    ∃ (a : Fin 0 → ↥(CompactElements (Core D)))
      (b : Fin 0 → ↥(CompactElements (Core E))), FiniteTests D E p 0 a b := by
  refine ⟨Fin.elim0, Fin.elim0, ?_⟩
  intro g
  constructor
  · intro _ i
    exact Fin.elim0 i
  · intro _ x
    have hpb : p ≤ bottomStable D E := hp.2 (Set.mem_univ _)
    have hpx : p x ≤ (Core E).isDIDomain.toIsScottDomain.bottom := by
      calc
        p x = p x ⊓ (Core E).isDIDomain.toIsScottDomain.bottom := hpb x x le_rfl
        _ ≤ (Core E).isDIDomain.toIsScottDomain.bottom := inf_le_right
    exact hpx.trans ((Core E).isDIDomain.toIsScottDomain.bottom_le (g.val x))

end DIDomainClassification.Section03.CompactBridgeProof

namespace DIDomainClassification.Section03
open StableFunctionModels CompactBridgeProof

theorem compactBridge : CompactBridgeStatement.{u} := by
  intro D E p hp
  obtain ⟨m, a, b, ht⟩ := tests_of_compact D E p hp
  exact ⟨compact_of_tests D E p m a b ht, ⟨m, a, b, ht⟩,
    empty_tests_of_least D E p⟩

end DIDomainClassification.Section03
