import DIDomainClassification.Section03.TraceModels
import DIDomainClassification.Support.StableHomTraceOrder

/-!
# Exact source-facing finite-trace approximation interface

Authoritative source: manuscript.tex, SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
Inherited context:498--532. Lemma3.1:534--546. Written proof:547--620.

This staged module DEFINES the source construction and unproved specifications.
Only literal carrier/operation adapters are proved here. It does not prove the
source lemma, request a proof take/claim, or transfer any independent verdict.

The support library has genuine proofs making the reconstruction configuration
valued and stable; using those proofs to construct a native map adds no input
assumption. The exact source-facing theorem remains a separately reviewed target.
Trace-exactness and compactness of each reconstruction are additional generic
support results, NOT assertions of the printed Lemma3.1 or its proof.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Section03.FiniteTraceModels

open Preliminaries EventStructures TraceModels

variable (D : CountablyBasedDIDomain.{u}) {A : Type v} [PartialOrder A]
  (E : FinitaryPrimeEventStructure A) (hE : IsCountablyBasedDIDomain (Configuration E))
  (f : StableHom (Core D) (Target E hE))

/-- Exact raw source supports, with all finiteness, subtrace and predecessor
closure conditions. The subtype merely indexes ALL admissible source sets F.
-/
abbrev AdmissibleSupports :=
  {F : Set (Core D × A) // FinitePredecessorClosed D E hE f F}

/-- Adapter from the accepted source predicate to the generic support record.
Its carrier remains literally F; no support or approximation conclusion is added.
-/
def support (F : Set (Core D × A))
    (hF : FinitePredecessorClosed D E hE f F) :
    FiniteTraceApproximations.FiniteSupport (fun x : Core D => f x) := by
  have h := (finitePredecessorClosed_iff D E hE f F).mp hF
  exact ⟨F, h.1, h.2.1, h.2.2⟩

theorem support_carrier (F : Set (Core D × A))
    (hF : FinitePredecessorClosed D E hE f F) :
    (support D E hE f F hF).carrier = F := rfl

/-- The generic source-object wrapper has literally the same carrier/order as
the native countably based source object's Core.
-/
theorem sourceObject_eq_Core :
    FiniteTraceApproximations.sourceObject (Core D).isDIDomain = Core D := rfl

/-- The generic configuration bundle and native target share the literal carrier
and order; their dI-domain proof fields are proof-irrelevant.
-/
theorem configurationObject_eq_Target :
    FiniteTraceApproximations.configurationObject E = Target E hE := rfl

/-- The source's f_F, represented as a native stable map between the EXACT source
objects. Its function is the printed set reconstruction, not an arbitrary witness.
Its stability certificate reuses the existing generic construction proof.
-/
def reconstructionHom (F : Set (Core D × A))
    (hF : FinitePredecessorClosed D E hE f F) :
    StableHom (Core D) (Target E hE) :=
  FiniteTraceApproximations.approximationHom (Core D).isDIDomain
    (StableHom.isStable f).1 (preservesCompatibleMeets D E hE f)
    (support D E hE f F hF)

/-- Literal configuration-valued source function in Equation(3.3), before any
order-theoretic conclusion about the family is asserted.
-/
abbrev reconstruction (F : Set (Core D × A))
    (hF : FinitePredecessorClosed D E hE f F) (x : Core D) : Configuration E :=
  reconstructionHom D E hE f F hF x

/-- The construction is EXACTLY {a | exists k, (k,a) in F and k <= x}.
This is definitional, not only a one-sided approximation or inclusion.
-/
theorem reconstruction_val (F : Set (Core D × A))
    (hF : FinitePredecessorClosed D E hE f F) (x : Core D) :
    (reconstruction D E hE f F hF x).val =
      {a : A | ∃ k : Core D, (k, a) ∈ F ∧ k ≤ x} := rfl

theorem reconstructionHom_apply (F : Set (Core D × A))
    (hF : FinitePredecessorClosed D E hE f F) (x : Core D) :
    reconstructionHom D E hE f F hF x = reconstruction D E hE f F hF x := rfl

/-- The whole family, over EVERY finite predecessor-closed subset of Tr(f),
in the native StableHom carrier with its actual STABLE partial order.
-/
def family : Set (StableHom (Core D) (Target E hE)) :=
  Set.range (fun F : AdmissibleSupports D E hE f =>
    reconstructionHom D E hE f F.val F.property)

end DIDomainClassification.Section03.FiniteTraceModels

namespace DIDomainClassification.Section03

open Preliminaries EventStructures TraceModels FiniteTraceModels

/-- EXACT claims of Lemma3.1, manuscript.tex:534--546:
the literal f_F is stable, below f in the stable order, inclusion-monotone in F,
and the entire family is nonempty directed with native stable-order supremum f.

No trace-exactness or compactness conclusion is attributed to the printed lemma.
No stable-exponential domain/closure theorem is an input.
-/
def FiniteTraceApproximationStatement : Prop :=
  ∀ (D : CountablyBasedDIDomain.{u}) (A : Type v) [PartialOrder A]
    (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (f : StableHom (Core D) (Target E hE)),
    (∀ (F : Set (Core D × A)) (hF : FinitePredecessorClosed D E hE f F),
      IsStable (Core D) (Target E hE) (reconstruction D E hE f F hF) ∧
      reconstructionHom D E hE f F hF ≤ f) ∧
    (∀ (F G : Set (Core D × A))
      (hF : FinitePredecessorClosed D E hE f F)
      (hG : FinitePredecessorClosed D E hE f G),
      F ⊆ G → reconstructionHom D E hE f F hF ≤ reconstructionHom D E hE f G hG) ∧
    OrderCore.DirectedSet (family D E hE f) ∧
    IsLUB (family D E hE f) f

/-- Operative proof assertion at manuscript.tex:610--618, especially612--613:
the pointwise union over ALL admissible finite supports is exactly the given f.
This is separate from the printed lemma's native stable-order LUB claim.
-/
def FiniteTracePointwiseUnionStatement : Prop :=
  ∀ (D : CountablyBasedDIDomain.{u}) (A : Type v) [PartialOrder A]
    (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (f : StableHom (Core D) (Target E hE)) (x : Core D),
    (f x).val = ⋃ F : AdmissibleSupports D E hE f,
      (reconstruction D E hE f F.val F.property x).val

end DIDomainClassification.Section03
