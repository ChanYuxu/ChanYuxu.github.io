import DIDomainClassification.Section04.CutClassificationStatements
import DIDomainClassification.Section03.FunctionDegree

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section03

/-- The upper estimate holds without nontriviality assumptions. -/
theorem functionDegreeUpper : FunctionDegreeUpperStatement.{u} := by
  intro D E
  exact FunctionDegreeHelpers.stable_degree_upper D E

end DIDomainClassification.Section03
