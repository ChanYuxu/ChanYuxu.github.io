import DIDomainClassification.Support.CandidateCutClosure

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section03

/-- Both printed ordinal-cut families, with intrinsic categorical closure. -/
theorem candidateClosure : CandidateClosureStatement.{u} := by
  constructor
  · intro α hα
    exact CandidateCutClosure.domain_hypotheses hα.1
  · intro α hα
    exact CandidateCutClosure.finite_hypotheses hα.1

end DIDomainClassification.Section03
