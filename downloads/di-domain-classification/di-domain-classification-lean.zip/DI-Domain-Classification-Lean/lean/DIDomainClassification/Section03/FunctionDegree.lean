import DIDomainClassification.Support.FunctionDegreeHelpers

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section03
open CategoryTheory Preliminaries CoherenceDegree StableFunctionModels FunctionDegreeHelpers

theorem functionDegreeNontrivial : FunctionDegreeNontrivialStatement.{u} := by
  intro D E hD hE
  exact le_antisymm (stable_degree_upper D E)
    (max_le (two_le_degree D E hD hE) (codomain_degree_le D E))

theorem functionDegreeSingletonInput : FunctionDegreeSingletonInputStatement.{u} := by
  intro D E hs
  obtain ⟨x0, hx0⟩ := hs
  refine ⟨{
    hom := evaluationAt D E x0
    inv := constantEmbedding D E
    hom_inv_id := ?_
    inv_hom_id := ?_
  }⟩
  · apply StableHom.ext
    intro f
    apply StableHom.ext
    intro x
    change f x0 = f x
    rw [hx0 x]
  · apply StableHom.ext
    intro e
    rfl

theorem functionDegreeSingletonOutput : FunctionDegreeSingletonOutputStatement.{u} := by
  intro D E hs
  obtain ⟨e0, he0⟩ := hs
  refine ⟨StableMapOperators.constant D E e0, ?_⟩
  intro f
  apply StableHom.ext
  intro x
  exact he0 (f x)

theorem functionDegree : FunctionDegreeStatement.{u} :=
  ⟨functionDegreeNontrivial, functionDegreeSingletonInput, functionDegreeSingletonOutput⟩

end DIDomainClassification.Section03
