import DIDomainClassification.Section03.TraceModels

/-!
# Minimal compact trace inputs

This proves the original existence and common-upper uniqueness argument at
manuscript.tex:507--523 using compact observation, the finite entire compact
ideal, and compatible binary meets. Minimality tests all smaller points.
The finite causal-support assertion at525--532 is also derived explicitly.
Source-facing proof review and whole-paper acceptance remain separate.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Section03

open Preliminaries EventStructures TraceModels

theorem traceInputs : TraceInputsStatement.{u,v} := by
  constructor
  · intro D A _ E hE f x a ha
    exact ⟨MinimalInputTraces.exists_compact_below_event
        (Core D).isDIDomain.toIsScottDomain.algebraic (StableHom.isStable f).1 ha,
      MinimalInputTraces.exists_trace_below
        (Core D).isDIDomain (StableHom.isStable f).1 ha⟩
  · intro D A _ E hE f k l x a hk hl hkx hlx
    have h := MinimalInputTraces.trace_unique_and_meet
      (Core D).isDIDomain.toIsScottDomain
      (preservesCompatibleMeets D E hE f) hk hl hkx hlx
    exact ⟨h.1, h.2.2.symm⟩

namespace TraceModels

theorem C_finite (D : CountablyBasedDIDomain.{u}) {A : Type v} [PartialOrder A]
    (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (f : StableHom (Core D) (Target E hE)) {k : Core D} {a : A}
    (hk : (k, a) ∈ Trace D E hE f) : (C D E hE f hk).Finite := by
  rw [C_eq_predecessorSupport]
  exact MinimalInputTraces.predecessorSupport_finite
    (Core D).isDIDomain.toIsScottDomain (preservesCompatibleMeets D E hE f) k a

end TraceModels

end DIDomainClassification.Section03
