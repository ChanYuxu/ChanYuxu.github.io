import DIDomainClassification.Section02.DegreeRealizabilityStatement
import DIDomainClassification.Section02.CountableTreeRanks
import DIDomainClassification.Section02.TreeDomainConstruction
import DIDomainClassification.Section02.CountableProducts
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Support.LiftedCombRealization

/-! Exact source degree realizability, including every printed construction. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02

open Preliminaries CoherenceDegree Trees Subcategories DegreeRealizationModels

theorem degreeZeroRealization : DegreeZeroRealizationStatement.{u} := by
  letI : CompleteDistribLattice FiniteOrderDomains.TwoCarrier.{u} :=
    Fintype.toCompleteDistribLattice _
  apply (bps.2.2.2.2.2.1
    FiniteOrderDomains.TwoCarrier FiniteOrderDomains.two_isCountablyBased.1.toIsScottDomain
    FiniteOrderDomains.two_isCountablyBased.2).mpr
  intro X
  exact ⟨⟨sSup X, isLUB_sSup X⟩, ⟨sInf X, isGLB_sInf X⟩⟩

theorem degreeSuccessorRealization : DegreeSuccessorRealizationStatement.{u} := by
  intro γ hγ hpos
  obtain ⟨A, T, hp, hT, hrank⟩ := countableTreeRanks γ hγ hpos
  have hD := treeDomainConstruction.2.1 A T hp
  obtain ⟨hScott, hdegree⟩ := bps.2.2.2.1.1 A T hp hT
  refine ⟨A, T, hp, hT, hD, hrank, ?_⟩
  simpa only [Ordinal.lift_add, Ordinal.lift_one, hrank] using hdegree

theorem degreeCombRealization : DegreeCombRealizationStatement.{u} :=
  ⟨LiftedCombRealization.domain, LiftedCombRealization.degree⟩

namespace DegreeRealizationProof

/-- Reindex by a literal ULift Nat to apply the already proved same-universe
product-degree theorem, then transfer back through the explicit order iso.
The final carrier is exactly the source's Nat-indexed dependent product. -/
theorem natProductDegree (D : ℕ → Type u) [∀ n, PartialOrder (D n)]
    (hD : ∀ n, IsScottDomain (D n)) (hProduct : IsScottDomain (∀ n, D n)) :
    coherenceDegree hProduct = ⨆ n : ℕ, coherenceDegree (hD n) := by
  let Q := ∀ i : ULift.{u} ℕ, D i.down
  let hQ : IsScottDomain Q := BPSProductDegree.productScottDomain (fun i : ULift.{u} ℕ => hD i.down)
  let e : (∀ n, D n) ≃o Q := {
    toFun := fun x i => x i.down
    invFun := fun y n => y ⟨n⟩
    left_inv := by intro x; rfl
    right_inv := by intro y; funext i; cases i; rfl
    map_rel_iff' := by
      intro x y
      constructor
      · intro h n; exact h ⟨n⟩
      · intro h i; exact h i.down }
  have he := OrderIsoTransport.scottContinuous e
  have hei := OrderIsoTransport.scottContinuous e.symm
  calc
    coherenceDegree hProduct = coherenceDegree hQ := le_antisymm
      (coherenceDegree_mono_of_scott_split hProduct hQ he hei (fun x => e.symm_apply_apply x))
      (coherenceDegree_mono_of_scott_split hQ hProduct hei he (fun y => e.apply_symm_apply y))
    _ = ⨆ i : ULift.{u} ℕ, coherenceDegree (hD i.down) :=
      BPSProductDegree.product_coherenceDegree_eq (fun i : ULift.{u} ℕ => hD i.down)
    _ = ⨆ n : ℕ, coherenceDegree (hD n) := iSup_ulift _

end DegreeRealizationProof

theorem degreeLimitRealization : DegreeLimitRealizationStatement.{u} := by
  intro limitOrdinal hpos hbound hlim
  have hcount : limitOrdinal.card ≤ Cardinal.aleph0 := Cardinal.card_le_iff.mpr hbound
  have hIio : (Set.Iio limitOrdinal).Countable :=
    (CountableTreeRankRealization.countable_Iio_of_card_le_aleph0 limitOrdinal hcount).to_set
  obtain ⟨δ, hδrange⟩ := hIio.exists_eq_range ⟨0, hpos⟩
  have hδlt : ∀ n, δ n < limitOrdinal := by
    intro n
    have h : δ n ∈ Set.Iio limitOrdinal := by rw [hδrange]; exact Set.mem_range_self n
    exact h
  have hone : (1 : Ordinal.{u+1}) < limitOrdinal := by
    simpa only [Order.succ_eq_add_one, zero_add] using hlim.succ_lt hpos
  let γ : ℕ → Ordinal.{u+1} := fun n => max 1 (δ n)
  let β : ℕ → Ordinal.{u+1} := fun n => γ n + 1
  have hγlt : ∀ n, γ n < limitOrdinal := fun n => max_lt hone (hδlt n)
  have hγcount : ∀ n, (γ n).card ≤ Cardinal.aleph0 :=
    fun n => Cardinal.card_le_iff.mpr ((hγlt n).trans hbound)
  have hγpos : ∀ n, 1 ≤ γ n := fun n => le_max_left _ _
  have hβlt : ∀ n, β n < limitOrdinal := by
    intro n
    simpa only [β, Order.succ_eq_add_one] using hlim.succ_lt (hγlt n)
  have hcofinal : ∀ ξ < limitOrdinal, ∃ n, ξ ≤ β n := by
    intro ξ hξ
    have hmem : ξ ∈ Set.range δ := by rw [← hδrange]; exact hξ
    obtain ⟨n, hn⟩ := hmem
    refine ⟨n, ?_⟩
    calc
      ξ = δ n := hn.symm
      _ ≤ γ n := le_max_right _ _
      _ ≤ β n := by simpa only [β, Order.succ_eq_add_one] using Order.le_succ (γ n)
  have hsup : (⨆ n, β n) = limitOrdinal := by
    apply le_antisymm (Ordinal.iSup_le fun n => (hβlt n).le)
    apply hlim.isLUB_Iio.2
    intro ξ hξ
    obtain ⟨n, hn⟩ := hcofinal ξ hξ
    exact hn.trans (Ordinal.le_iSup β n)
  choose A T hp hT hD hrank hdegree using
    fun n => degreeSuccessorRealization (γ n) (hγcount n) (hγpos n)
  refine ⟨β, A, T, hp, hT, ?_, hβlt, hcofinal, ?_, hsup⟩
  · intro n
    simp only [β, Ordinal.lift_add, Ordinal.lift_one, hrank n]
  · have hProduct := (countableProducts ℕ (fun n => TreeDomain (T n)) hD).1
    refine ⟨hD, hdegree, hProduct, ?_⟩
    have h := DegreeRealizationProof.natProductDegree (fun n => TreeDomain (T n))
      (fun n => (hD n).1.toIsScottDomain) hProduct.1.toIsScottDomain
    simpa only [hdegree] using h

theorem degreeAllValues : DegreeAllValuesStatement.{u} := by
  intro α hα
  rcases hα with rfl | hα
  · exact ⟨FiniteOrderDomains.twoObject, degreeZeroRealization⟩
  · by_cases htop : α = firstUncountable.{u}
    · subst α
      obtain ⟨hD, hdegree⟩ := degreeCombRealization.{u}
      exact ⟨⟨DIDomainObject.ofType CombCarrier hD.1, hD.2⟩, hdegree⟩
    · have hlt : α < firstUncountable.{u} := lt_of_le_of_ne hα.2 htop
      have hcount : α.card ≤ Cardinal.aleph0 := Cardinal.card_le_iff.mpr hlt
      have hpos : 0 < α := (by simp : (0 : Ordinal.{u+1}) < 2).trans_le hα.1
      rcases Order.isMin_or_mem_range_succ_or_isSuccLimit α with hmin | hsucc | hlim
      · have hz : α = 0 := isMin_iff_eq_bot.mp hmin
        exact False.elim ((ne_of_gt hpos) hz)
      · obtain ⟨γ, hγα⟩ := hsucc
        have hγle : γ ≤ α := by rw [← hγα]; exact Order.le_succ γ
        have hγcount : γ.card ≤ Cardinal.aleph0 :=
          (Ordinal.card_le_card hγle).trans hcount
        have hγpos : 1 ≤ γ := by
          by_contra hn
          have hγzero : γ = 0 := Order.lt_one_iff.mp (lt_of_not_ge hn)
          have hαone : α = 1 := by simpa only [hγzero, Order.succ_eq_add_one, zero_add] using hγα.symm
          have h21 : (2 : Ordinal.{u+1}) ≤ 1 := hαone ▸ hα.1
          exact (by simp : ¬(2 : Ordinal.{u+1}) ≤ 1) h21
        obtain ⟨A, T, hp, hT, hD, _hrank, hdegree⟩ :=
          degreeSuccessorRealization γ hγcount hγpos
        refine ⟨⟨DIDomainObject.ofType (TreeDomain T) hD.1, hD.2⟩, ?_⟩
        exact hdegree.trans (by simpa only [Order.succ_eq_add_one] using hγα)
      · obtain ⟨β, A, T, _hp, _hT, _hβ, _hβlt, _hcofinal, hFactors, hsup⟩ :=
          degreeLimitRealization α hpos hlt hlim
        obtain ⟨_hD, _hdegree, hProduct, hprod⟩ := hFactors
        exact ⟨⟨DIDomainObject.ofType (∀ n : ℕ, TreeDomain (T n)) hProduct.1,
          hProduct.2⟩, hprod.trans hsup⟩

theorem degreeRealizability : DegreeRealizabilityStatement.{u} :=
  ⟨degreeAllValues, degreeZeroRealization, degreeSuccessorRealization,
    degreeLimitRealization, degreeCombRealization⟩

end DIDomainClassification.Section02
