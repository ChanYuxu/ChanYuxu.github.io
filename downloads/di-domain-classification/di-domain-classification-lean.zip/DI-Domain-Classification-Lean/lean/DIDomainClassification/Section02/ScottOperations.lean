import DIDomainClassification.Section02.ScottDomains

/-!
# Chosen operations for the intrinsic Scott-domain presentation

These are representation bridges, not additional fields assumed of a source
domain. Infima are constructed from the bounded supremum of lower bounds.
The resulting semilattice has exactly the original order. The source's
bounded joins are chosen only when their compatibility premise is supplied.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Preliminaries

variable {D : Type u} [PartialOrder D]

theorem IsScottDomain.nonemptyInfimum (hD : IsScottDomain D)
    (S : Set D) (hS : S.Nonempty) : ∃ i : D, IsGLB S i := by
  obtain ⟨a, ha⟩ := hS
  obtain ⟨i, hi⟩ := hD.boundedSuprema (lowerBounds S)
    ⟨a, by intro b hb; exact hb ha⟩
  refine ⟨i, ?_, ?_⟩
  · intro b hb
    exact hi.2 (by intro c hc; exact hc hb)
  · intro b hb
    exact hi.1 hb

noncomputable def IsScottDomain.inf (hD : IsScottDomain D) (x y : D) : D :=
  Classical.choose (hD.nonemptyInfimum ({x, y} : Set D) ⟨x, by simp⟩)

theorem IsScottDomain.inf_isGLB (hD : IsScottDomain D) (x y : D) :
    IsGLB ({x, y} : Set D) (hD.inf x y) :=
  Classical.choose_spec (hD.nonemptyInfimum ({x, y} : Set D) ⟨x, by simp⟩)

theorem IsScottDomain.inf_le_left (hD : IsScottDomain D) (x y : D) :
    hD.inf x y ≤ x := (hD.inf_isGLB x y).1 (by simp)

theorem IsScottDomain.inf_le_right (hD : IsScottDomain D) (x y : D) :
    hD.inf x y ≤ y := (hD.inf_isGLB x y).1 (by simp)

theorem IsScottDomain.le_inf (hD : IsScottDomain D) {a x y : D}
    (hx : a ≤ x) (hy : a ≤ y) : a ≤ hD.inf x y := by
  apply (hD.inf_isGLB x y).2
  intro z hz
  rcases Set.mem_insert_iff.mp hz with rfl | hz
  · exact hx
  · have hzy : z = y := Set.mem_singleton_iff.mp hz
    simpa only [hzy] using hy

noncomputable def IsScottDomain.semilatticeInf (hD : IsScottDomain D) :
    SemilatticeInf D where
  toPartialOrder := inferInstance
  inf := hD.inf
  inf_le_left := hD.inf_le_left
  inf_le_right := hD.inf_le_right
  le_inf := fun _ _ _ hx hy => hD.le_inf hx hy

theorem IsScottDomain.semilatticeInf_order (hD : IsScottDomain D) :
    hD.semilatticeInf.toPartialOrder = (inferInstance : PartialOrder D) := rfl

noncomputable def IsScottDomain.bottom (hD : IsScottDomain D) : D :=
  Classical.choose hD.hasLeast

theorem IsScottDomain.bottom_le (hD : IsScottDomain D) (x : D) :
    hD.bottom ≤ x := Classical.choose_spec hD.hasLeast x

theorem compatible_iff_bddAbove_pair (x y : D) :
    DIDomainClassification.Compatible x y ↔ BddAbove ({x, y} : Set D) := by
  constructor
  · rintro ⟨u, hxu, hyu⟩
    refine ⟨u, ?_⟩
    intro z hz
    rcases Set.mem_insert_iff.mp hz with rfl | hz
    · exact hxu
    · simpa only [Set.mem_singleton_iff.mp hz] using hyu
  · rintro ⟨u, hu⟩
    exact ⟨u, hu (by simp), hu (by simp)⟩

noncomputable def IsScottDomain.join (hD : IsScottDomain D) (x y : D)
    (hxy : DIDomainClassification.Compatible x y) : D :=
  Classical.choose (hD.boundedSuprema ({x, y} : Set D)
    ((compatible_iff_bddAbove_pair x y).mp hxy))

theorem IsScottDomain.join_isLUB (hD : IsScottDomain D) (x y : D)
    (hxy : DIDomainClassification.Compatible x y) :
    IsLUB ({x, y} : Set D) (hD.join x y hxy) :=
  Classical.choose_spec (hD.boundedSuprema ({x, y} : Set D)
    ((compatible_iff_bddAbove_pair x y).mp hxy))

end DIDomainClassification.Preliminaries
