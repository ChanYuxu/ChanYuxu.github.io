import DIDomainClassification.Section02.RankDegree

/-! UNPROVED positive-rank existence used at manuscript.tex478.
Every countable ordinal in the DEGREE universe is quantified. The witness
alphabet is arbitrary Type u, not fixed to Nat. Properness excludes rank0;
the actual native rank is explicitly lifted across the one-universe gap. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section02

open Trees

def CountableTreeRanksStatement : Prop :=
  ∀ γ : Ordinal.{u+1}, γ.card ≤ Cardinal.aleph0 → 1 ≤ γ →
    ∃ (A : Type u) (T : RootedPrefixTree A), T.IsProper ∧
      ∃ hT : T.IsWellFounded, Ordinal.lift.{u+1} (T.treeRank hT) = γ

end DIDomainClassification.Section02
