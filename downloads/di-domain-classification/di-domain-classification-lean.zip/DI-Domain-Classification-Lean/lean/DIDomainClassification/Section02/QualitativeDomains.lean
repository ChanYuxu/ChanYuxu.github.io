import DIDomainClassification.Section02.Configurations
import Mathlib.Data.Set.Card

/-!
# Qualitative and coherence-space presentations

Source terminology: manuscript.tex:399 and403; frozen source SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The domain presented by E is its actual Configuration E with inclusion order.
No countability restriction is introduced. Forbidden families contain nonempty
finite subsets, but need not themselves be antichains or countable.
Forbidden-set existence and graph equivalence remain separate proof obligations.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

variable {A : Type u} [PartialOrder A]

/-- The equality-order event presentation of a qualitative domain. -/
def IsQualitativePresentation (_E : FinitaryPrimeEventStructure A) : Prop :=
  ∀ a b : A, a ≤ b ↔ a = b

/-- A family giving exactly the configuration sets by forbidden containment. -/
def IsForbiddenFamilyPresentation (E : FinitaryPrimeEventStructure A)
    (F : Set (Set A)) : Prop :=
  (∀ U ∈ F, U.Nonempty ∧ U.Finite) ∧
    ∀ X : Set A, IsConfiguration E X ↔ ∀ U ∈ F, ¬ U ⊆ X

/-- Every inclusion-minimal member of the forbidden family is binary. -/
def HasBinaryMinimalMembers (F : Set (Set A)) : Prop :=
  ∀ U ∈ F, (∀ V ∈ F, ¬ V ⊂ U) → U.ncard = 2

/-- The source coherence-space terminology for equality-order configurations. -/
def IsCoherenceSpacePresentation (E : FinitaryPrimeEventStructure A) : Prop :=
  IsQualitativePresentation E ∧ ∃ F : Set (Set A),
    IsForbiddenFamilyPresentation E F ∧ HasBinaryMinimalMembers F

end DIDomainClassification.EventStructures
