import DIDomainClassification.Section02.TreeWellFounded
import DIDomainClassification.Section02.MicTrees
import Mathlib.SetTheory.Ordinal.Rank

/-!
# Source tree ranks and the coherence-degree supremum

Source: `manuscript.tex`, lines 424–434; SHA-256
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

Node ranks use the actual reverse immediate-child relation. Its well-foundedness
is derived from the source's absence of infinite branches by the existing proved
bridge, not added as a new assumption. Roots may be arbitrary finite prefixes.

For D : Type u, the degree index contains every coding alphabet Index : Type u,
every actual mic tree over it, and only those with the source well-foundedness
property. This index lives in Type (u+1). Ranks are Ordinal.{u}; their successors
are explicitly lifted to Ordinal.{u+1} before taking the indexed supremum.
The family is small in that output universe, with an actual boundedness and
least-upper-bound proof below. No unbounded conditional-supremum fallback is used.

There is no restriction to natural-number labels, finite branching or countable
domain carriers. The definition never branches on existence of an infinite mic
tree, and no BPS bound, degree lower bound or classification theorem is asserted.
Universe-independent comparison of these lifted presentations is not claimed.

Status: provisional Step 3 source interface, pending independent review.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Trees.RootedPrefixTree

/-- The actual source node rank, using the proved reverse-child recursion relation. -/
def nodeRank {Index : Type v} (T : DIDomainClassification.Trees.RootedPrefixTree Index)
    (hT : T.IsWellFounded) (x : T.Node) : Ordinal.{v} :=
  ((T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).apply x).rank

/-- The exact printed child-successor recurrence, with no extra well-foundedness premise. -/
theorem nodeRank_eq {Index : Type v}
    (T : DIDomainClassification.Trees.RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) :
    T.nodeRank hT x = ⨆ y : {y : T.Node // T.IsChild x y}, T.nodeRank hT y.val + 1 := by
  simpa only [nodeRank, ReverseChildRelation, Order.succ_eq_add_one] using
    (Acc.rank_eq ((T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).apply x))

theorem nodeRank_children_bddAbove {Index : Type v}
    (T : DIDomainClassification.Trees.RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) :
    BddAbove (Set.range (fun y : {y : T.Node // T.IsChild x y} =>
      T.nodeRank hT y.val + 1)) := Ordinal.bddAbove_of_small

/-- Empty child supremum is zero, as required at leaves. -/
theorem nodeRank_leaf {Index : Type v}
    (T : DIDomainClassification.Trees.RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) (hx : T.IsLeaf x) : T.nodeRank hT x = 0 := by
  rw [nodeRank_eq]
  apply Ordinal.iSup_eq_zero_iff.mpr
  intro y
  exact ((T.isLeaf_iff_no_child x).mp hx ⟨y.val, y.property⟩).elim

/-- The source rank of a tree is the rank of its actual distinguished root. -/
def treeRank {Index : Type v} (T : DIDomainClassification.Trees.RootedPrefixTree Index)
    (hT : T.IsWellFounded) : Ordinal.{v} := T.nodeRank hT T.root

theorem treeRank_eq_root {Index : Type v}
    (T : DIDomainClassification.Trees.RootedPrefixTree Index) (hT : T.IsWellFounded) :
    T.treeRank hT = T.nodeRank hT T.root := rfl

end DIDomainClassification.Trees.RootedPrefixTree

namespace DIDomainClassification.CoherenceDegree

open DIDomainClassification.Preliminaries

/-- All well-founded mic trees with any coding alphabet in the ambient universe.
The rank is computed from these data and is not a field or an assumed bound.
-/
structure WellFoundedMicTree (D : Type u) [PartialOrder D] (hD : IsScottDomain D) :
    Type (u+1) where
  Index : Type u
  micTree : MicTree D hD Index
  wellFounded : micTree.tree.IsWellFounded

namespace WellFoundedMicTree

variable {D : Type u} [PartialOrder D] {hD : IsScottDomain D}

/-- Every source well-founded mic tree in the ambient universe occurs literally. -/
def ofMicTree {Index : Type u} (M : MicTree D hD Index)
    (hM : M.tree.IsWellFounded) : WellFoundedMicTree D hD := ⟨Index, M, hM⟩

/-- Lift the actual source root rank plus one into the supremum's output universe. -/
def rankContribution (M : WellFoundedMicTree D hD) : Ordinal.{u+1} :=
  Ordinal.lift.{u+1} (M.micTree.tree.treeRank M.wellFounded + 1)

theorem rankContribution_ofMicTree {Index : Type u} (M : MicTree D hD Index)
    (hM : M.tree.IsWellFounded) :
    (ofMicTree M hM).rankContribution = Ordinal.lift.{u+1} (M.tree.treeRank hM + 1) := rfl

end WellFoundedMicTree

/-- The source degree supremum, represented one ordinal universe higher.
Only well-founded mic trees are indexed, regardless of any other infinite branches.
-/
def coherenceDegree {D : Type u} [PartialOrder D] (hD : IsScottDomain D) :
    Ordinal.{u+1} :=
  ⨆ M : WellFoundedMicTree D hD, M.rankContribution

/-- The actual family is bounded: it is small in the explicit output universe. -/
theorem coherenceDegree_family_bddAbove {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) :
    BddAbove (Set.range (fun M : WellFoundedMicTree D hD => M.rankContribution)) :=
  Ordinal.bddAbove_of_small

/-- A genuine least upper bound, also valid if the family is empty. -/
theorem coherenceDegree_isLUB {D : Type u} [PartialOrder D] (hD : IsScottDomain D) :
    IsLUB (Set.range (fun M : WellFoundedMicTree D hD => M.rankContribution))
      (coherenceDegree hD) := by
  constructor
  · rintro a ⟨M, rfl⟩
    exact Ordinal.le_iSup.{u+1, u+1}
      (fun M : WellFoundedMicTree D hD => M.rankContribution) M
  · intro a ha
    exact Ordinal.iSup_le.{u+2, u+1}
      (f := fun M : WellFoundedMicTree D hD => M.rankContribution)
      (fun M => ha ⟨M, rfl⟩)

/-- Explicit coverage of every label type and every source well-founded mic tree. -/
theorem treeRank_add_one_le_coherenceDegree {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) {Index : Type u} (M : MicTree D hD Index)
    (hM : M.tree.IsWellFounded) :
    Ordinal.lift.{u+1} (M.tree.treeRank hM + 1) ≤ coherenceDegree hD :=
  Ordinal.le_iSup.{u+1, u+1}
    (fun N : WellFoundedMicTree D hD => N.rankContribution)
    (WellFoundedMicTree.ofMicTree M hM)

/-- The supremum's universal property in the printed tree-and-label binders. -/
theorem coherenceDegree_le_iff {D : Type u} [PartialOrder D] (hD : IsScottDomain D)
    (a : Ordinal.{u+1}) :
    coherenceDegree hD ≤ a ↔
      ∀ (Index : Type u) (M : MicTree D hD Index) (hM : M.tree.IsWellFounded),
        Ordinal.lift.{u+1} (M.tree.treeRank hM + 1) ≤ a := by
  constructor
  · intro h Index M hM
    exact (treeRank_add_one_le_coherenceDegree hD M hM).trans h
  · intro h
    exact Ordinal.iSup_le.{u+2, u+1}
      (f := fun M : WellFoundedMicTree D hD => M.rankContribution)
      (fun M => h M.Index M.micTree M.wellFounded)

/-- The explicitly printed empty-family convention; no nonempty family is assumed. -/
theorem coherenceDegree_eq_zero_of_no_trees {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (h : ¬ Nonempty (WellFoundedMicTree D hD)) :
    coherenceDegree hD = 0 := by
  apply Ordinal.iSup_eq_zero_iff.mpr
  intro M
  exact (h ⟨M⟩).elim

end DIDomainClassification.CoherenceDegree

end
