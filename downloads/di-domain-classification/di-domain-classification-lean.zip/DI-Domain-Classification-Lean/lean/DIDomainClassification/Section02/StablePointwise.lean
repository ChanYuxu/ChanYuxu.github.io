import DIDomainClassification.Section02.StablePointwiseStatement

/-! The source implication follows by taking the two stable-order inputs equal. -/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.Section02

theorem stablePointwise : StablePointwiseStatement.{u,v} := by
  intro D E f g h x
  calc
    f x = f x ⊓ g x := (StableHom.le_iff f g).mp h x x le_rfl
    _ ≤ g x := inf_le_right

end DIDomainClassification.Section02
