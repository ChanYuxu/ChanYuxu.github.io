import DIDomainClassification.Section02.StableCategory
import DIDomainClassification.Section02.RankDegree
import DIDomainClassification.Support.FiniteTraceApproximations

/-!
Unproved source-facing specifications for the unnumbered claims at
manuscript.tex:397, 403 and 485--490; frozen source SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The binary-meet claim retains the general dI-domain scope; the conditional
completeness equivalence is stated for raw Scott domains. Event carriers and
families in the configuration-map claim have no countability restriction.
No theorem inhabitant is supplied here.
-/

set_option autoImplicit false
universe u v

namespace DIDomainClassification.Section02

open Preliminaries EventStructures

/-- Binary meets preserve every bounded supremum, including the empty one. -/
def EventsDistributivityStatement : Prop :=
  ∀ (D : DIDomainObject.{u}) (x : D)
    (S : Set D), BddAbove S →
    ∀ s : D, IsLUB S s →
      IsLUB ((fun y : D => x ⊓ y) '' S) (x ⊓ s)

/-- Preservation of nonempty directed configuration unions and all binary
intersections implies the actual source stable-map predicate. Infima are the
intrinsic configuration infima, with their literal-intersection bridge already
proved in the imported configuration model. -/
def ConfigurationStabilityStatement : Prop :=
  ∀ (A : Type u) (B : Type v) [PartialOrder A] [PartialOrder B]
    (E : FinitaryPrimeEventStructure A) (F : FinitaryPrimeEventStructure B)
    (f : FiniteTraceApproximations.configurationObject E →
      FiniteTraceApproximations.configurationObject F),
    (∀ C : Set (Configuration E), OrderCore.DirectedSet C →
      ∀ Z : Configuration E, IsLUB C Z →
        (f Z).val = ⋃ Y ∈ C, (f Y).val) →
    (∀ X Y : FiniteTraceApproximations.configurationObject E,
      f (X ⊓ Y) = f X ⊓ f Y) →
    IsStable (FiniteTraceApproximations.configurationObject E)
      (FiniteTraceApproximations.configurationObject F) f

/-- Pairwise consistency is tested on arbitrary domain subsets, not merely
finite subsets; the requested supremum also covers the empty subset. -/
def ConditionalCompletenessStatement : Prop :=
  ∀ (D : Type u) [PartialOrder D] (hD : IsScottDomain D),
    (CoherenceDegree.coherenceDegree hD ≤ 2 ↔
      ∀ X : Set D, (∀ x ∈ X, ∀ y ∈ X, Compatible x y) →
        ∃ s : D, IsLUB X s)

end DIDomainClassification.Section02
