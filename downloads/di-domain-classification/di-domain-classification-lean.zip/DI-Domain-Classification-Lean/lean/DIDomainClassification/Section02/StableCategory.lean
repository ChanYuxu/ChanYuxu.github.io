import DIDomainClassification.Section02.StableFunctionSpaces
import Mathlib.CategoryTheory.Category.Basic

/-!
# The actual ambient category of countably based dI-domains

Source: `manuscript.tex`, line 121, the category and non-strictness sentences.
Frozen source SHA-256:
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

Objects wrap the accepted intrinsic `DIDomainObject` and require countability
of its actual compact-element set, not of the entire carrier. Morphisms are
exactly the accepted `StableHom` carrier. Identities and composition are actual
functions, with Scott continuity, compatible-meet preservation and category
laws proved below. The generic map operations allow independent universes.

There are no new carrier-order or semilattice instances for the countable
object wrapper: every ordered statement explicitly uses its accepted underlying
`DIDomainObject`, retaining the original order without an instance diamond.
No strictness, EP inequality, product/exponential closure or cartesian closedness
is assumed or concluded. The stable-retract setup later on the same source line
belongs to its separate interface.

Status: provisional Step 3 candidate; independent category-interface review
and acceptance are pending.
-/

set_option autoImplicit false

universe u v w z

namespace DIDomainClassification

noncomputable section

namespace StableHom

/-- Stable maps send compatible source pairs to compatible target pairs. -/
theorem map_compatible {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}
    (f : StableHom D E) {x y : D} (hxy : Compatible x y) :
    Compatible (f x) (f y) := by
  rcases hxy with ⟨a, hxa, hya⟩
  exact ⟨f a, (isStable f).1.monotone hxa, (isStable f).1.monotone hya⟩

/-- The actual identity function is stable, without a separate strictness condition. -/
def id (D : DIDomainObject.{u}) : StableHom D D :=
  ofFunction (fun x => x) ⟨ScottContinuous.id, fun _ _ _ => rfl⟩

theorem id_apply (D : DIDomainObject.{u}) (x : D) : id D x = x := rfl

/-- Actual function composition preserves Scott continuity and compatible meets. -/
def comp {D : DIDomainObject.{u}} {E : DIDomainObject.{v}} {F : DIDomainObject.{w}}
    (g : StableHom E F) (f : StableHom D E) : StableHom D F := by
  refine ofFunction (fun x => g (f x)) ⟨?_, ?_⟩
  · exact (isStable f).1.comp (isStable g).1
  · intro x y hxy
    change g (f (x ⊓ y)) = g (f x) ⊓ g (f y)
    rw [(isStable f).2 x y hxy]
    exact (isStable g).2 (f x) (f y) (map_compatible f hxy)

theorem comp_apply {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}
    {F : DIDomainObject.{w}} (g : StableHom E F) (f : StableHom D E) (x : D) :
    comp g f x = g (f x) := rfl

theorem id_comp {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}
    (f : StableHom D E) : comp (id E) f = f := by
  apply ext
  intro x
  rfl

theorem comp_id {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}
    (f : StableHom D E) : comp f (id D) = f := by
  apply ext
  intro x
  rfl

theorem comp_assoc {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}
    {F : DIDomainObject.{w}} {G : DIDomainObject.{z}}
    (h : StableHom F G) (g : StableHom E F) (f : StableHom D E) :
    comp h (comp g f) = comp (comp h g) f := by
  apply ext
  intro x
  rfl

end StableHom

/-- A source object: an actual dI-domain with countably many compact elements.
No countability restriction is placed on its entire carrier.
-/
structure CountablyBasedDIDomain where
  toDIDomainObject : DIDomainObject.{u}
  countableCompacts : (Preliminaries.CompactElements toDIDomainObject).Countable

/-- The wrapper has exactly the same underlying carrier as its accepted dI-domain. -/
instance : CoeSort CountablyBasedDIDomain.{u} (Type u) :=
  ⟨fun D => D.toDIDomainObject.Carrier⟩

namespace CountablyBasedDIDomain

/-- Every source countably based dI-domain is admitted, with its literal order. -/
def ofType (D : Type u) [PartialOrder D] (hD : Preliminaries.IsDIDomain D)
    (hK : (Preliminaries.CompactElements D).Countable) : CountablyBasedDIDomain.{u} :=
  ⟨DIDomainObject.ofType D hD, hK⟩

theorem ofType_carrier (D : Type u) [PartialOrder D] (hD : Preliminaries.IsDIDomain D)
    (hK : (Preliminaries.CompactElements D).Countable) :
    (ofType D hD hK).toDIDomainObject.Carrier = D := rfl

theorem ofType_order (D : Type u) [PartialOrder D] (hD : Preliminaries.IsDIDomain D)
    (hK : (Preliminaries.CompactElements D).Countable) :
    (ofType D hD hK).toDIDomainObject.partialOrder = (inferInstance : PartialOrder D) := rfl

/-- The wrapped object satisfies the accepted source countably-based predicate. -/
theorem isCountablyBased (D : CountablyBasedDIDomain.{u}) :
    Preliminaries.IsCountablyBasedDIDomain D.toDIDomainObject :=
  ⟨D.toDIDomainObject.isDIDomain, D.countableCompacts⟩

/-- The actual category. Its laws are consequences of actual stable functions. -/
instance instCategory : CategoryTheory.Category.{u} CountablyBasedDIDomain.{u} where
  Hom D E := StableHom D.toDIDomainObject E.toDIDomainObject
  id D := StableHom.id D.toDIDomainObject
  comp f g := StableHom.comp g f
  id_comp f := StableHom.comp_id f
  comp_id f := StableHom.id_comp f
  assoc f g h := StableHom.comp_assoc h g f

open CategoryTheory

/-- The category's Hom type is literally the accepted non-strict stable-map carrier. -/
theorem hom_model (D E : CountablyBasedDIDomain.{u}) :
    (D ⟶ E) = StableHom D.toDIDomainObject E.toDIDomainObject := rfl

/-- Typed identity view of a category morphism as its actual stable function.
This avoids registering duplicate function-coercion or order instances for Hom projections.
-/
abbrev toStableHom {D E : CountablyBasedDIDomain.{u}} (f : D ⟶ E) :
    StableHom D.toDIDomainObject E.toDIDomainObject := f

theorem hom_isStable {D E : CountablyBasedDIDomain.{u}} (f : D ⟶ E) :
    IsStable D.toDIDomainObject E.toDIDomainObject (toStableHom f) :=
  StableHom.isStable (toStableHom f)

theorem category_id_apply (D : CountablyBasedDIDomain.{u}) (x : D) :
    toStableHom (𝟙 D) x = x := rfl

theorem category_comp_apply {D E F : CountablyBasedDIDomain.{u}}
    (f : D ⟶ E) (g : E ⟶ F) (x : D) :
    toStableHom (f ≫ g) x = toStableHom g (toStableHom f x) := rfl

/-- No replacement of the accepted stable Hom order occurs in the category model. -/
theorem hom_order_iff {D E : CountablyBasedDIDomain.{u}} (f g : D ⟶ E) :
    toStableHom f ≤ toStableHom g ↔
      ∀ x y : D.toDIDomainObject, x ≤ y →
        toStableHom f x = toStableHom f y ⊓ toStableHom g x :=
  StableHom.le_iff (toStableHom f) (toStableHom g)

end CountablyBasedDIDomain

end

end DIDomainClassification
