import DIDomainClassification.Section02.ScottOperations

/-!
# Source statement for finite and countable products

This is only the statement from manuscript.tex, line 196. The index may be
empty, finite or countably infinite. The actual carrier is the dependent
function type with its pointwise order. Support is measured against the
least elements constructed from the Scott-domain property, not a new premise.
No product closure or compactness characterization is stored in input data.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.Section02

open DIDomainClassification.Preliminaries

noncomputable def CountableProductsStatement : Prop :=
  ∀ (I : Type v) [Countable I] (D : I → Type u)
    [∀ i, PartialOrder (D i)]
    (hD : ∀ i, IsCountablyBasedDIDomain (D i)),
    IsCountablyBasedDIDomain ((i : I) → D i) ∧
      ∀ x : ((i : I) → D i),
        Preliminaries.IsCompactElement x ↔
          (∀ i, Preliminaries.IsCompactElement (x i)) ∧
          {i : I | x i ≠ (hD i).1.toIsScottDomain.bottom}.Finite

end DIDomainClassification.Section02
