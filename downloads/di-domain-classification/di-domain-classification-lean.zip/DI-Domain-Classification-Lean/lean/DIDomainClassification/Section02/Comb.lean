import DIDomainClassification.Section02.Trees

/-!
# The literal proper comb and its root-relative prefix representation

Source: manuscript.tex:1559–1567, node `u:comb`, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

There are exactly the spine vertices j and the additional leaves j⁺. The
prefix representation may prepend any finite common root word; no extra
source vertices are created by that representation choice. Finite complete
branches and the infinite spine are represented explicitly. No coherence
degree, rank comparison, block map, or stable-retraction theorem is asserted.

Staged Step 3 authoring only, not an independently accepted source interface.
-/

set_option autoImplicit false

namespace DIDomainClassification.Comb

open DIDomainClassification.Trees

/-- The literal source vertices: j on the spine and its additional leaf j⁺. -/
inductive Vertex where
  | spine : ℕ → Vertex
  | leaf : ℕ → Vertex
  deriving DecidableEq

namespace Vertex

/-- The exact source ancestor order, directed away from spine 0. -/
def ancestor : Vertex → Vertex → Prop
  | spine i, spine j => i ≤ j
  | spine i, leaf j => i ≤ j
  | leaf _, spine _ => False
  | leaf i, leaf j => i = j

instance : PartialOrder Vertex where
  le := ancestor
  le_refl v := by cases v <;> simp [ancestor]
  le_trans a b c hab hbc := by
    cases a <;> cases b <;> cases c <;> simp_all [ancestor]
    all_goals exact hab.trans hbc
  le_antisymm a b hab hba := by
    cases a <;> cases b <;> simp_all [ancestor]
    exact Nat.le_antisymm hab hba

@[simp] theorem spine_le_spine (i j : ℕ) : spine i ≤ spine j ↔ i ≤ j := Iff.rfl
@[simp] theorem spine_le_leaf (i j : ℕ) : spine i ≤ leaf j ↔ i ≤ j := Iff.rfl
@[simp] theorem leaf_not_le_spine (i j : ℕ) : ¬leaf i ≤ spine j := fun h => h
@[simp] theorem leaf_le_leaf (i j : ℕ) : leaf i ≤ leaf j ↔ i = j := Iff.rfl

/-- The countable literal carrier is a disjoint union of two copies of ℕ. -/
def tags : Vertex → ℕ ⊕ ℕ
  | spine n => Sum.inl n
  | leaf n => Sum.inr n

theorem tags_injective : Function.Injective tags := by
  intro v w h
  cases v <;> cases w <;> simp_all [tags]

instance : Countable Vertex := tags_injective.countable

def depth : Vertex → ℕ
  | spine n => n
  | leaf n => n + 1

/-- Literal finite branch {0,...,j,j⁺}, with no omitted endpoint. -/
def finiteBranch (j : ℕ) : Set Vertex :=
  {v | (∃ i : ℕ, i ≤ j ∧ v = spine i) ∨ v = leaf j}

@[simp] theorem spine_mem_finiteBranch (i j : ℕ) :
    spine i ∈ finiteBranch j ↔ i ≤ j := by simp [finiteBranch]

@[simp] theorem leaf_mem_finiteBranch (i j : ℕ) :
    leaf i ∈ finiteBranch j ↔ i = j := by simp [finiteBranch]

theorem finiteBranch_eq_Iic (j : ℕ) : finiteBranch j = Set.Iic (leaf j) := by
  ext v
  cases v <;> simp

/-- The root is the empty code. A leaf uses a final true, the spine only false. -/
def code : Vertex → List Bool
  | spine n => List.replicate n false
  | leaf n => List.replicate n false ++ [true]

private theorem spine_prefix_leaf (i j : ℕ) :
    List.replicate i false <+: List.replicate j false ++ [true] ↔ i ≤ j := by
  induction i generalizing j with
  | zero => simp
  | succ i ih =>
      cases j with
      | zero => simp [List.replicate_succ]
      | succ j => simpa [List.replicate_succ] using ih j

private theorem leaf_not_prefix_spine (i j : ℕ) :
    ¬List.replicate i false ++ [true] <+: List.replicate j false := by
  intro h
  have heq := (List.prefix_replicate_iff.mp h).2
  have hm : true ∈ List.replicate i false ++ [true] := by simp
  rw [heq] at hm
  simp at hm

private theorem leaf_prefix_leaf (i j : ℕ) :
    List.replicate i false ++ [true] <+:
      List.replicate j false ++ [true] ↔ i = j := by
  induction i generalizing j with
  | zero =>
      cases j with
      | zero => simp
      | succ j => simp [List.replicate_succ]
  | succ i ih =>
      cases j with
      | zero => simp [List.replicate_succ]
      | succ j => simpa [List.replicate_succ] using ih j

theorem code_prefix_iff (v w : Vertex) : code v <+: code w ↔ v ≤ w := by
  cases v with
  | spine i =>
      cases w with
      | spine j => simp [code, List.prefix_replicate_iff]
      | leaf j => exact spine_prefix_leaf i j
  | leaf i =>
      cases w with
      | spine j => exact iff_of_false (leaf_not_prefix_spine i j) (by simp)
      | leaf j => exact leaf_prefix_leaf i j

theorem code_injective : Function.Injective code := by
  intro v w h
  apply le_antisymm
  · exact (code_prefix_iff v w).mp (h ▸ List.prefix_refl (code v))
  · exact (code_prefix_iff w v).mp (h ▸ List.prefix_refl (code v))

/-- Every prefix of a source vertex is again a source vertex. -/
theorem prefix_code {v : List Bool} {w : Vertex} (h : v <+: code w) :
    ∃ x : Vertex, code x = v := by
  cases w with
  | spine j =>
      exact ⟨spine v.length, (List.prefix_replicate_iff.mp h).2.symm⟩
  | leaf j =>
      by_cases hlen : v.length ≤ j
      · have hp : v <+: List.replicate j false :=
          (List.isPrefix_append_of_length (by simpa using hlen)).mp h
        exact ⟨spine v.length, (List.prefix_replicate_iff.mp hp).2.symm⟩
      · have hu := h.length_le
        have heq : v = code (leaf j) := h.eq_of_length (by
          simp only [code, List.length_append, List.length_replicate,
            List.length_singleton] at hu ⊢
          omega)
        exact ⟨leaf j, heq.symm⟩

end Vertex

/-- The code with an arbitrary common finite root prefix restored. -/
def representation (rootPrefix : List Bool) (v : Vertex) : List Bool :=
  rootPrefix ++ v.code

/-- The actual countable comb as the accepted root-relative prefix-tree model. -/
def tree (rootPrefix : List Bool := []) : RootedPrefixTree Bool where
  nodes := Set.range (representation rootPrefix)
  rootList := rootPrefix
  root_mem := ⟨Vertex.spine 0, by simp [representation, Vertex.code]⟩
  root_prefix := by
    rintro _ ⟨v, rfl⟩
    exact List.prefix_append _ _
  prefix_closed := by
    intro v w hroot hvw hw
    obtain ⟨x, rfl⟩ := hw
    have hp : v.drop rootPrefix.length <+: x.code := by
      apply (List.prefix_append_right_inj rootPrefix).mp
      simpa only [List.prefix_iff_eq_append.mp hroot] using hvw
    obtain ⟨y, hy⟩ := Vertex.prefix_code hp
    exact ⟨y, by
      change rootPrefix ++ y.code = v
      rw [hy]
      exact List.prefix_iff_eq_append.mp hroot⟩
  countable_nodes := Set.countable_range _

-- Select the accepted prefix order explicitly. The underlying List subtype
-- also admits inherited list orders, which are not the source tree order.
local instance prefixOrder (rootPrefix : List Bool) :
    PartialOrder (tree rootPrefix).Node :=
  RootedPrefixTree.instPartialOrderNode (tree rootPrefix)

local instance prefixPreorder (rootPrefix : List Bool) :
    Preorder (tree rootPrefix).Node := (prefixOrder rootPrefix).toPreorder

local instance prefixLE (rootPrefix : List Bool) :
    LE (tree rootPrefix).Node := (prefixOrder rootPrefix).toLE

/-- Explicit node embedding; its range is exactly all nodes, by construction. -/
def node (rootPrefix : List Bool) (v : Vertex) : (tree rootPrefix).Node :=
  ⟨representation rootPrefix v, ⟨v, rfl⟩⟩

@[simp] theorem node_val (rootPrefix : List Bool) (v : Vertex) :
    (node rootPrefix v).val = rootPrefix ++ v.code := rfl

theorem node_le_iff (rootPrefix : List Bool) (v w : Vertex) :
    node rootPrefix v ≤ node rootPrefix w ↔ v ≤ w := by
  change rootPrefix ++ v.code <+: rootPrefix ++ w.code ↔ v ≤ w
  rw [List.prefix_append_right_inj]
  exact Vertex.code_prefix_iff v w

theorem node_injective (rootPrefix : List Bool) : Function.Injective (node rootPrefix) := by
  intro v w h
  apply Vertex.code_injective
  exact List.append_cancel_left (congrArg Subtype.val h)

theorem node_surjective (rootPrefix : List Bool) : Function.Surjective (node rootPrefix) := by
  intro v
  obtain ⟨w, hw⟩ := v.property
  exact ⟨w, Subtype.ext hw⟩

/-- The literal order and every root-relative prefix representation are isomorphic. -/
noncomputable def vertexOrderIso (rootPrefix : List Bool) :
    Vertex ≃o (tree rootPrefix).Node where
  toFun := node rootPrefix
  invFun v := Classical.choose v.property
  left_inv v := node_injective rootPrefix (Subtype.ext
    (Classical.choose_spec (node rootPrefix v).property))
  right_inv v := Subtype.ext (Classical.choose_spec v.property)
  map_rel_iff' := by
    intro v w
    exact node_le_iff rootPrefix v w

@[simp] theorem node_spine_zero (rootPrefix : List Bool) :
    node rootPrefix (Vertex.spine 0) = (tree rootPrefix).root := by
  apply Subtype.ext
  simp [node, representation, Vertex.code, RootedPrefixTree.root, tree]

@[simp] theorem depth_node (rootPrefix : List Bool) (v : Vertex) :
    (tree rootPrefix).depth (node rootPrefix v) = v.depth := by
  cases v <;> simp [RootedPrefixTree.depth, tree, Vertex.code, Vertex.depth]

theorem node_leaf_isLeaf (rootPrefix : List Bool) (j : ℕ) :
    (tree rootPrefix).IsLeaf (node rootPrefix (Vertex.leaf j)) := by
  intro w hw
  obtain ⟨v, rfl⟩ := node_surjective rootPrefix w
  apply congrArg (node rootPrefix)
  have hv := (node_le_iff rootPrefix _ _).mp hw
  cases v with
  | spine i => exact False.elim hv
  | leaf i => exact congrArg Vertex.leaf hv.symm

theorem isLeaf_node_iff (rootPrefix : List Bool) (v : Vertex) :
    (tree rootPrefix).IsLeaf (node rootPrefix v) ↔
      ∃ j : ℕ, v = Vertex.leaf j := by
  cases v with
  | spine i =>
      constructor
      · intro h
        have heq := h (node rootPrefix (Vertex.leaf i))
          ((node_le_iff rootPrefix _ _).mpr (by simp))
        have hfalse := node_injective rootPrefix heq
        cases hfalse
      · rintro ⟨_, h⟩
        cases h
  | leaf i =>
      exact ⟨fun _ => ⟨i, rfl⟩, fun _ => node_leaf_isLeaf rootPrefix i⟩

/-- The extra leaf j⁺ is immediately above the spine vertex j. -/
theorem spine_leaf_isChild (rootPrefix : List Bool) (j : ℕ) :
    (tree rootPrefix).IsChild (node rootPrefix (Vertex.spine j))
      (node rootPrefix (Vertex.leaf j)) :=
  ⟨(node_le_iff rootPrefix _ _).mpr (by simp), by simp [Vertex.depth]⟩

/-- Successive natural-number spine vertices are also immediate neighbors. -/
theorem spine_succ_isChild (rootPrefix : List Bool) (j : ℕ) :
    (tree rootPrefix).IsChild (node rootPrefix (Vertex.spine j))
      (node rootPrefix (Vertex.spine (j + 1))) :=
  ⟨(node_le_iff rootPrefix _ _).mpr (by simp), by simp [Vertex.depth]⟩

/-- The image is exactly the full root-to-j⁺ path, not just a finite subchain. -/
theorem finiteBranch_image (rootPrefix : List Bool) (j : ℕ) :
    node rootPrefix '' Vertex.finiteBranch j =
      (tree rootPrefix).pathTo (node rootPrefix (Vertex.leaf j)) := by
  ext w
  constructor
  · rintro ⟨v, hv, rfl⟩
    exact (node_le_iff rootPrefix _ _).mpr (by
      simpa only [Vertex.finiteBranch_eq_Iic, Set.mem_Iic] using hv)
  · intro hw
    obtain ⟨v, rfl⟩ := node_surjective rootPrefix w
    exact ⟨v, by
      rw [Vertex.finiteBranch_eq_Iic]
      exact (node_le_iff rootPrefix _ _).mp hw, rfl⟩

/-- Precisely the source's finite complete branches {0,...,j,j⁺}. -/
theorem isFiniteCompleteBranch_iff (rootPrefix : List Bool)
    (c : Set (tree rootPrefix).Node) :
    (tree rootPrefix).IsFiniteCompleteBranch c ↔
      ∃ j : ℕ, c = node rootPrefix '' Vertex.finiteBranch j := by
  constructor
  · rintro ⟨v, hv, rfl⟩
    obtain ⟨w, rfl⟩ := node_surjective rootPrefix v
    obtain ⟨j, rfl⟩ := (isLeaf_node_iff rootPrefix w).mp hv
    exact ⟨j, (finiteBranch_image rootPrefix j).symm⟩
  · rintro ⟨j, rfl⟩
    exact ⟨node rootPrefix (Vertex.leaf j), node_leaf_isLeaf rootPrefix j,
      finiteBranch_image rootPrefix j⟩

theorem isProper (rootPrefix : List Bool) : (tree rootPrefix).IsProper := by
  apply (RootedPrefixTree.isProper_iff _).mpr
  constructor
  · exact ⟨node rootPrefix (Vertex.spine 0), node rootPrefix (Vertex.leaf 0),
      fun h => by cases node_injective rootPrefix h⟩
  · intro v
    obtain ⟨w, rfl⟩ := node_surjective rootPrefix v
    cases w with
    | spine j =>
        exact ⟨node rootPrefix (Vertex.leaf j), node_leaf_isLeaf rootPrefix j,
          (node_le_iff rootPrefix _ _).mpr (by simp)⟩
    | leaf j => exact ⟨node rootPrefix (Vertex.leaf j), node_leaf_isLeaf rootPrefix j, le_rfl⟩

/-- The actual infinite spine; all finite-depth vertices are present. -/
def infiniteSpine (rootPrefix : List Bool) : (tree rootPrefix).InfiniteBranch where
  node n := node rootPrefix (Vertex.spine n)
  root_eq := node_spine_zero rootPrefix
  child n := spine_succ_isChild rootPrefix n

/-- An infinite branch cannot enter a leaf, so it is precisely the spine. -/
theorem infiniteBranch_node_eq (rootPrefix : List Bool)
    (b : (tree rootPrefix).InfiniteBranch) (n : ℕ) :
    b.node n = node rootPrefix (Vertex.spine n) := by
  obtain ⟨v, hv⟩ := node_surjective rootPrefix (b.node n)
  cases v with
  | spine j =>
      have hd : j = n := by
        simpa only [← hv, depth_node, Vertex.depth] using b.depth_eq (tree rootPrefix) n
      simpa only [hd] using hv.symm
  | leaf j =>
      have hleaf : (tree rootPrefix).IsLeaf (b.node n) := by
        rw [← hv]
        exact node_leaf_isLeaf rootPrefix j
      have hno := ((tree rootPrefix).isLeaf_iff_no_child (b.node n)).mp hleaf
      exact False.elim (hno ⟨b.node (n + 1), b.child n⟩)

theorem infiniteBranch_eq_spine (rootPrefix : List Bool)
    (b : (tree rootPrefix).InfiniteBranch) : b = infiniteSpine rootPrefix := by
  apply RootedPrefixTree.InfiniteBranch.ext (tree rootPrefix)
  exact infiniteBranch_node_eq rootPrefix b

/-- Every maximal branch is one displayed finite branch or the infinite spine.
This is a proved representation fact, not a countability assumption on branches. -/
theorem isBranch_iff_leaf_or_spine (rootPrefix : List Bool)
    (c : Set (tree rootPrefix).Node) :
    (tree rootPrefix).IsBranch c ↔
      (∃ j : ℕ, c = node rootPrefix '' Vertex.finiteBranch j) ∨
        c = Set.range (fun n : ℕ => node rootPrefix (Vertex.spine n)) := by
  constructor
  · intro hc
    by_cases hleaf : ∃ j : ℕ, node rootPrefix (Vertex.leaf j) ∈ c
    · obtain ⟨j, hj⟩ := hleaf
      have hpath := (tree rootPrefix).pathTo_isBranch (node_leaf_isLeaf rootPrefix j)
      have hsub : (tree rootPrefix).pathTo (node rootPrefix (Vertex.leaf j)) ⊆ c :=
        fun _ hv => hc.mem_of_le (tree rootPrefix) hj hv
      have heq := hpath.2 hc.1 hsub
      exact Or.inl ⟨j, heq.symm.trans (finiteBranch_image rootPrefix j).symm⟩
    · right
      have hsub : c ⊆ Set.range (fun n : ℕ => node rootPrefix (Vertex.spine n)) := by
        intro v hv
        obtain ⟨w, rfl⟩ := node_surjective rootPrefix v
        cases w with
        | spine j => exact ⟨j, rfl⟩
        | leaf j => exact False.elim (hleaf ⟨j, hv⟩)
      exact hc.2 ((infiniteSpine rootPrefix).range_isBranch (tree rootPrefix)).1 hsub
  · rintro (⟨j, rfl⟩ | rfl)
    · rw [finiteBranch_image]
      exact (tree rootPrefix).pathTo_isBranch (node_leaf_isLeaf rootPrefix j)
    · exact (infiniteSpine rootPrefix).range_isBranch (tree rootPrefix)

theorem hasInfiniteBranch (rootPrefix : List Bool) : (tree rootPrefix).HasInfiniteBranch :=
  ⟨infiniteSpine rootPrefix⟩

theorem not_isWellFounded (rootPrefix : List Bool) : ¬(tree rootPrefix).IsWellFounded :=
  fun h => h (hasInfiniteBranch rootPrefix)

/-- The manuscript's comb C, with root 0 represented by the empty root word. -/
def combTree : RootedPrefixTree Bool := tree []

theorem combTree_isProper : combTree.IsProper := isProper []

theorem combTree_finite_complete_branches (c : Set combTree.Node) :
    combTree.IsFiniteCompleteBranch c ↔
      ∃ j : ℕ, c = node [] '' Vertex.finiteBranch j :=
  isFiniteCompleteBranch_iff [] c

theorem combTree_hasInfiniteBranch : combTree.HasInfiniteBranch := hasInfiniteBranch []

theorem combTree_not_isWellFounded : ¬combTree.IsWellFounded := not_isWellFounded []

end DIDomainClassification.Comb
