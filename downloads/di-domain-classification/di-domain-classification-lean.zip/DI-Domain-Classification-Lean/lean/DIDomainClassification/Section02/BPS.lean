import DIDomainClassification.Section02.BPSPreliminaries
import DIDomainClassification.Section02.BPSPointwiseFunction
import DIDomainClassification.Section02.BPSProduct
import DIDomainClassification.Section02.BPSFiniteDegree
import DIDomainClassification.Section02.BPSWellFoundedTree
import DIDomainClassification.Support.InfiniteTreeDegree

/-! Exact source-facing seven-clause coherence-degree theorem. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section02.BPSProof

theorem infiniteBranchTreeDegree : BPS.InfiniteBranchTreeDegreeStatement.{u} := by
  intro Index T hp hInf
  exact ⟨TreeDomainDegree.treeScottDomain T hp,
    TreeDomainDegree.infiniteBranch_treeDomain_degree_eq T hp hInf⟩

theorem properTreeDegree : BPS.ProperTreeDegreeStatement.{u} :=
  ⟨wellFoundedTreeDegree, infiniteBranchTreeDegree⟩

end DIDomainClassification.Section02.BPSProof

namespace DIDomainClassification.Section02

theorem bps : BPSStatement.{u} :=
  ⟨BPSProof.scottSplitMonotonicity, BPSProof.countableProductDegree,
    BPSProof.pointwiseFunctionDegree, BPSProof.properTreeDegree,
    BPSProof.allowedRange, BPSProof.degreeZeroIffCompleteLattice,
    BPSProof.finiteDegreeIffCoherent⟩

end DIDomainClassification.Section02
