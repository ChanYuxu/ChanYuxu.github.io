import DIDomainClassification.Section02.ScottDomains
import Mathlib.Data.Set.Card

/-!
# Minimally inconsistent sets and n-coherence

Source: manuscript.tex, line 407, node `u:mic-coherence`.
Source SHA-256: 11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

This staged Step 3 interface uses the accepted intrinsic Scott-domain model.
It contains the original mic-cardinality definition, not the following
arbitrary-subset characterization. That equivalence is a separate, unproved
node `p:mic-coherence-characterization` and is not asserted here.

No compactness restriction on M, countability of D, or nontriviality of D is
imposed. `Set.ncard` is used only under the finite-set clause of mic.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.CoherenceDegree

open DIDomainClassification.Preliminaries

/-- A mic set in a Scott domain is a finite inconsistent set all of whose
proper subsets are consistent. Consistency is boundedness of the whole set. -/
def IsMinimallyInconsistent {D : Type u} [PartialOrder D]
    (_hD : IsScottDomain D) (M : Set D) : Prop :=
  M.Finite ∧ ¬ Consistent M ∧
    ∀ N : Set D, N ⊂ M → Consistent N

/-- For an integer n at least two, n-coherence means that every mic set has
at most n elements. The hypotheses are the source's Scott-domain and n≥2
scope, not a compactness, finiteness, or countability assumption on D. -/
def IsNCoherent {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (n : ℕ) (_hn : 2 ≤ n) : Prop :=
  ∀ M : Set D, IsMinimallyInconsistent hD M → M.ncard ≤ n

end DIDomainClassification.CoherenceDegree
