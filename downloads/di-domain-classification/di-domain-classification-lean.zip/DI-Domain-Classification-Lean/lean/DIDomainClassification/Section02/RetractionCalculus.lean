import DIDomainClassification.Section02.RetractionCalculusStatement
import DIDomainClassification.Section02.ScottCountableRetracts
import DIDomainClassification.Section02.CountableProducts
import DIDomainClassification.Support.StableSplitClosure
import DIDomainClassification.Support.RawStableFunctionOperators

/-! Source238--264. All raw stable retraction clauses retain their actual
maps and orders. The algebraic Scott-basis clause is exposed separately. -/
set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section02
open Preliminaries RetractionCalculusModels

theorem retractionComposition : RetractionCompositionStatement.{u} := by
  intro D E F s r t q hD hE
  have hleft : Function.LeftInverse (StableHom.comp r q : F → D)
      (StableHom.comp t s : D → F) := by
    intro x
    change r (q (t (s x))) = x
    rw [hE (s x), hD x]
  exact ⟨hleft, ⟨StableHom.comp t s, StableHom.comp r q, hleft⟩⟩

theorem retractionBinaryProduct : RetractionBinaryProductStatement.{u} := by
  intro D E A B sD rD sE rE hD hE
  let hDE := RawStableFunctionOperators.productDomain D E
  let hAB := RawStableFunctionOperators.productDomain A B
  refine ⟨hDE, hAB,
    RawStableFunctionOperators.productMap_stable D E A B hDE hAB sD sE,
    RawStableFunctionOperators.productMap_stable A B D E hAB hDE rD rE, ?_⟩
  intro x
  apply Prod.ext
  · exact hD x.1
  · exact hE x.2

theorem retractionCountableProduct : RetractionCountableProductStatement.{u,v} := by
  intro I _ D A s r hleft
  let hD : IsCountablyBasedDIDomain (∀ i, (D i).toDIDomainObject) :=
    (countableProducts I (fun i => (D i).toDIDomainObject)
      (fun i => ⟨(D i).toDIDomainObject.isDIDomain, (D i).countableCompacts⟩)).1
  let hA : IsCountablyBasedDIDomain (∀ i, (A i).toDIDomainObject) :=
    (countableProducts I (fun i => (A i).toDIDomainObject)
      (fun i => ⟨(A i).toDIDomainObject.isDIDomain, (A i).countableCompacts⟩)).1
  refine ⟨hD, hA,
    RawStableFunctionOperators.piMap_stable (fun i => (D i).toDIDomainObject)
      (fun i => (A i).toDIDomainObject) hD.1 hA.1 s,
    RawStableFunctionOperators.piMap_stable (fun i => (A i).toDIDomainObject)
      (fun i => (D i).toDIDomainObject) hA.1 hD.1 r, ?_⟩
  intro x
  funext i
  exact hleft i (x i)

theorem retractionExponential : RetractionExponentialStatement.{u} := by
  intro D E A B sD rD sE rE hD hE
  let S : StableHom (exponentialCore D E) (exponentialCore A B) :=
    StableHom.comp (RawStableFunctionOperators.postcompose A E B sE)
      (RawStableFunctionOperators.precompose A D E rD)
  let R : StableHom (exponentialCore A B) (exponentialCore D E) :=
    StableHom.comp (RawStableFunctionOperators.postcompose D B E rE)
      (RawStableFunctionOperators.precompose D A B sD)
  refine ⟨StableHom.isStable S, StableHom.isStable R, ?_⟩
  intro f
  apply StableHom.ext
  intro x
  change rE (sE (f (rD (sD x)))) = f x
  rw [hD x, hE (f x)]

theorem stableSplitDIPreservation : StableSplitDIPreservationStatement.{u,v} := by
  intro D E _ _ hE s r hleft
  have hf : ScottContinuous (fun y : E => s (r y)) :=
    r.scottContinuous.comp s.scottContinuous
  have hid : StableIdempotentClosure.Idempotent (fun y : E => s (r y)) :=
    OrderIsoTransport.split_composite_idempotent s r hleft
  have hfixed := StableIdempotentClosure.fixed_isDIDomain hE hf hid
    (StableSplitClosure.stableComposite_preservesCompatibleInfima s r)
  exact (OrderIsoTransport.isDIDomain_iff
    (OrderIsoTransport.stableMapSplitFixedOrderIso s r hleft)).mpr hfixed

theorem retractionCalculus : RetractionCalculusStatement.{u,v} :=
  ⟨retractionComposition, retractionBinaryProduct, retractionCountableProduct,
    retractionExponential, stableSplitDIPreservation, scottCountableRetract⟩

end DIDomainClassification.Section02
