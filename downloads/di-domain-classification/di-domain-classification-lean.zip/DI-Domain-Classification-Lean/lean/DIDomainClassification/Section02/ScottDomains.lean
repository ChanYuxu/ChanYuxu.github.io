import DIDomainClassification.Section02.DomainDefinitions
import DIDomainClassification.Support.StableMaps
import Mathlib.Order.Bounds.Basic

/-!
# Intrinsic source definitions of Scott domains and dI-domains

This is a provisional, source-facing translation of the unnumbered definitions
in Section 2.1. Suprema and infima are specified by their order-theoretic
universal properties; no chosen operations or distributivity of arbitrary
incompatible joins are imposed. The bridge to a chosen-operation library
presentation is a separate proof obligation, not an assumed field.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Preliminaries

/-- A set is consistent exactly when it has an upper bound. -/
def Consistent {D : Type u} [Preorder D] (S : Set D) : Prop :=
  BddAbove S

/-- Pointed algebraicity and suprema of all bounded subsets, including empty. -/
structure IsScottDomain (D : Type u) [PartialOrder D] : Prop where
  algebraic : IsAlgebraicDcpo D
  hasLeast : ∃ bottom : D, ∀ x : D, bottom ≤ x
  boundedSuprema : ∀ S : Set D, BddAbove S → ∃ s : D, IsLUB S s

/-- The intrinsic form of `(x ∨ y) ∧ z = (x ∧ z) ∨ (y ∧ z)` for a compatible
pair `x,y` and an arbitrary third element `z`. Witnesses of the indicated
supremum and infima are quantified, not additional hypotheses on the domain. -/
def CompatibleJoinDistributive (D : Type u) [PartialOrder D] : Prop :=
  ∀ x y z joined meet left right : D,
    DIDomainClassification.Compatible x y →
    IsLUB ({x, y} : Set D) joined →
    IsGLB ({joined, z} : Set D) meet →
    IsGLB ({x, z} : Set D) left →
    IsGLB ({y, z} : Set D) right →
    IsLUB ({left, right} : Set D) meet

/-- A dI-domain has the source's compatible-join distributivity and finite
entire principal ideals below compact elements. Countability is separate. -/
structure IsDIDomain (D : Type u) [PartialOrder D] : Prop
    extends IsScottDomain D where
  distributive : CompatibleJoinDistributive D
  finitePrincipalIdeals : ∀ k : D, IsCompactElement k → (Set.Iic k).Finite

/-- The ambient objects of the manuscript: dI-domains with countably many
compact elements, not necessarily countably many points. -/
def IsCountablyBasedDIDomain (D : Type u) [PartialOrder D] : Prop :=
  IsDIDomain D ∧ (CompactElements D).Countable

end DIDomainClassification.Preliminaries
