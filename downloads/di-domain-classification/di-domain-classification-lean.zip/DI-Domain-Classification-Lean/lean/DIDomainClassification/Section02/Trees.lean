import Mathlib.SetTheory.Descriptive.Tree
import Mathlib.Data.List.Infix
import Mathlib.Data.Set.Countable
import Mathlib.Data.Set.Finite.Lemmas
import Mathlib.Order.Preorder.Chain

/-!
# Rooted prefix trees (Section 2, unnumbered definition)

Source: `manuscript.tex`, line 414, SHA-256
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

A root may itself be a nonempty list: the forest construction later uses roots
`[i]`. Closure under prefixes is therefore relative to that root, not a demand
to add all shorter prefixes as extra nodes. The order is the actual list-prefix
order, and depth is list length minus root length. Countability applies only to
the node set, not to the label type, levels, children, or the set of branches.

This is a Step 3 candidate, not an accepted source interface. There are no rank,
mic-labelling, tree-domain, or downstream theorem declarations in this file.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Trees

/-- A countable rooted prefix tree, with arbitrary finite root prefix. -/
structure RootedPrefixTree (Label : Type u) where
  nodes : Set (List Label)
  rootList : List Label
  root_mem : rootList ∈ nodes
  root_prefix : ∀ {v}, v ∈ nodes → rootList <+: v
  prefix_closed : ∀ {v w}, rootList <+: v → v <+: w → w ∈ nodes → v ∈ nodes
  countable_nodes : nodes.Countable

namespace RootedPrefixTree

variable {Label : Type u} (T : RootedPrefixTree Label)

/-- Only finite nodes of the tree; infinite branches are a separate type. -/
abbrev Node : Type u := T.nodes

instance : Countable T.Node := T.countable_nodes.to_subtype

/-- Ancestorship is precisely the prefix order, directed away from the root. -/
instance : PartialOrder T.Node where
  le v w := v.val <+: w.val
  le_refl v := List.prefix_refl v.val
  le_trans _ _ _ := List.IsPrefix.trans
  le_antisymm v w hvw hwv :=
    Subtype.ext (hvw.eq_of_length (Nat.le_antisymm hvw.length_le hwv.length_le))

@[simp] theorem le_iff_prefix (v w : T.Node) : v ≤ w ↔ v.val <+: w.val := Iff.rfl

/-- The distinguished source root, not an additional node. -/
def root : T.Node := ⟨T.rootList, T.root_mem⟩

@[simp] theorem root_val : T.root.val = T.rootList := rfl

theorem root_le (v : T.Node) : T.root ≤ v := T.root_prefix v.property

instance : OrderBot T.Node where
  bot := T.root
  bot_le := T.root_le

/-- Number of edges from the root; each node has finite depth. -/
def depth (v : T.Node) : ℕ := v.val.length - T.rootList.length

@[simp] theorem depth_root : T.depth T.root = 0 := Nat.sub_self _

theorem root_length_le (v : T.Node) : T.rootList.length ≤ v.val.length :=
  (T.root_prefix v.property).length_le

theorem depth_mono {v w : T.Node} (h : v ≤ w) : T.depth v ≤ T.depth w :=
  Nat.sub_le_sub_right h.length_le _

theorem eq_of_le_of_depth_eq {v w : T.Node} (h : v ≤ w)
    (hd : T.depth v = T.depth w) : v = w := by
  apply Subtype.ext
  apply h.eq_of_length
  have hv := T.root_length_le v
  have hw := T.root_length_le w
  dsimp [depth] at hd
  omega

@[simp] theorem depth_eq_zero_iff (v : T.Node) : T.depth v = 0 ↔ v = T.root := by
  constructor
  · intro h
    exact (T.eq_of_le_of_depth_eq (T.root_le v) (by simpa using h.symm)).symm
  · rintro rfl
    exact T.depth_root

/-- The ancestor at relative depth `n`, clamped at the given node. -/
def prefixAt (v : T.Node) (n : ℕ) : T.Node :=
  ⟨v.val.take (T.rootList.length + n), T.prefix_closed
    (by
      have h := (T.root_prefix v.property).take (T.rootList.length + n)
      simpa only [List.take_of_length_le (Nat.le_add_right _ _)] using h)
    (List.take_prefix _ _) v.property⟩

@[simp] theorem prefixAt_val (v : T.Node) (n : ℕ) :
    (T.prefixAt v n).val = v.val.take (T.rootList.length + n) := rfl

@[simp] theorem prefixAt_zero (v : T.Node) : T.prefixAt v 0 = T.root := by
  apply Subtype.ext
  simpa [prefixAt, root] using (List.prefix_iff_eq_take.mp (T.root_prefix v.property)).symm

theorem prefixAt_le (v : T.Node) (n : ℕ) : T.prefixAt v n ≤ v := List.take_prefix _ _

theorem prefixAt_mono (v : T.Node) {m n : ℕ} (h : m ≤ n) :
    T.prefixAt v m ≤ T.prefixAt v n := by
  change v.val.take _ <+: v.val.take _
  exact List.take_isPrefix_take.mpr (Or.inl (Nat.add_le_add_left h _))

theorem le_prefixAt {v w : T.Node} (h : v ≤ w) {n : ℕ} (hn : T.depth v ≤ n) :
    v ≤ T.prefixAt w n := by
  have hlen : v.val.length ≤ T.rootList.length + n := by
    have hv := T.root_length_le v
    dsimp [depth] at hn
    omega
  have hp := h.take (T.rootList.length + n)
  simpa only [List.take_of_length_le hlen] using hp

@[simp] theorem depth_prefixAt (v : T.Node) {n : ℕ} (h : n ≤ T.depth v) :
    T.depth (T.prefixAt v n) = n := by
  have hv := T.root_length_le v
  simp only [depth, prefixAt_val, List.length_take]
  dsimp [depth] at h
  omega

@[simp] theorem prefixAt_depth (v : T.Node) : T.prefixAt v (T.depth v) = v := by
  apply Subtype.ext
  change v.val.take (T.rootList.length + (v.val.length - T.rootList.length)) = v.val
  rw [Nat.add_sub_of_le (T.root_length_le v)]
  exact List.take_length

/-- An immediate child is one edge later in the prefix order. -/
def IsChild (v w : T.Node) : Prop := v ≤ w ∧ T.depth w = T.depth v + 1

/-- A leaf is a node with no strictly larger node. -/
def IsLeaf (v : T.Node) : Prop := ∀ w : T.Node, v ≤ w → w = v

theorem isChild_irrefl (v : T.Node) : ¬T.IsChild v v := by
  rintro ⟨_, h⟩
  omega

theorem isLeaf_iff_no_child (v : T.Node) :
    T.IsLeaf v ↔ ¬∃ w : T.Node, T.IsChild v w := by
  constructor
  · intro h ⟨w, hw⟩
    exact T.isChild_irrefl v ((h w hw.1) ▸ hw)
  · intro h w hvw
    by_contra hne
    have hd : T.depth v < T.depth w := by
      have hle := T.depth_mono hvw
      have he : T.depth v ≠ T.depth w := fun he => hne (T.eq_of_le_of_depth_eq hvw he).symm
      omega
    exact h ⟨T.prefixAt w (T.depth v + 1),
      T.le_prefixAt hvw (Nat.le_succ _), T.depth_prefixAt w hd⟩

/-- A branch is a maximal prefix chain. -/
def IsBranch (c : Set T.Node) : Prop := IsMaxChain (· ≤ ·) c

/-- The full root-to-node path, including both endpoints. -/
def pathTo (v : T.Node) : Set T.Node := Set.Iic v

@[simp] theorem mem_pathTo (v w : T.Node) : w ∈ T.pathTo v ↔ w ≤ v := Iff.rfl

theorem pathTo_finite (v : T.Node) : (T.pathTo v).Finite := by
  refine Set.Finite.of_injOn (t := {w | w ∈ v.val.inits})
    (f := fun w : T.Node => w.val) ?_ (Subtype.val_injective.injOn) v.val.inits.finite_toSet
  intro w hw
  exact (List.mem_inits _ _).mpr hw

theorem pathTo_isChain (v : T.Node) : IsChain (· ≤ ·) (T.pathTo v) := by
  intro x hx y hy _
  exact List.prefix_or_prefix_of_prefix hx hy

theorem pathTo_isBranch {v : T.Node} (hv : T.IsLeaf v) : T.IsBranch (T.pathTo v) := by
  refine ⟨T.pathTo_isChain v, ?_⟩
  intro c hc hsub
  apply Set.Subset.antisymm hsub
  intro w hw
  rcases hc.total hw (hsub (show v ∈ T.pathTo v from (show v ≤ v from le_rfl))) with h | h
  · exact h
  · exact le_of_eq (hv w h)

/-- A finite complete branch is exactly the full path ending at a leaf. -/
def IsFiniteCompleteBranch (c : Set T.Node) : Prop :=
  ∃ v : T.Node, T.IsLeaf v ∧ c = T.pathTo v

theorem IsFiniteCompleteBranch.finite {c : Set T.Node}
    (hc : T.IsFiniteCompleteBranch c) : c.Finite := by
  rcases hc with ⟨v, _, rfl⟩
  exact T.pathTo_finite v

theorem IsFiniteCompleteBranch.root_mem {c : Set T.Node}
    (hc : T.IsFiniteCompleteBranch c) : T.root ∈ c := by
  rcases hc with ⟨v, _, rfl⟩
  exact T.root_le v

theorem IsFiniteCompleteBranch.isBranch {c : Set T.Node}
    (hc : T.IsFiniteCompleteBranch c) : T.IsBranch c := by
  rcases hc with ⟨v, hv, rfl⟩
  exact T.pathTo_isBranch hv

/-- This endpoint encoding includes exactly the finite maximal branches. -/
theorem isFiniteCompleteBranch_iff {c : Set T.Node} :
    T.IsFiniteCompleteBranch c ↔ c.Finite ∧ T.IsBranch c := by
  constructor
  · intro hc
    exact ⟨hc.finite T, hc.isBranch T⟩
  · rintro ⟨hf, hc⟩
    obtain ⟨v, hv, hmax⟩ := Set.exists_max_image c T.depth hf ⟨T.root, hc.bot_mem⟩
    have hsub : c ⊆ T.pathTo v := by
      intro w hw
      rcases hc.1.total hw hv with h | h
      · exact h
      · exact le_of_eq (T.eq_of_le_of_depth_eq h (Nat.le_antisymm
          (T.depth_mono h) (hmax w hw))).symm
    refine ⟨v, ?_, hc.2 (T.pathTo_isChain v) hsub⟩
    intro w hvw
    have heq := hc.2 (T.pathTo_isChain w) (fun x hx =>
      (show x ≤ v from hsub hx).trans hvw)
    have hw : w ∈ c := by rw [heq]; exact (show w ≤ w from le_rfl)
    exact le_antisymm (hsub hw) hvw

/-- Properness does not impose well-foundedness or finite branching. -/
def IsProper : Prop :=
  Nontrivial T.Node ∧
    ∀ v : T.Node, ∃ c : Set T.Node, T.IsFiniteCompleteBranch c ∧ v ∈ c

theorem isProper_iff : T.IsProper ↔
    Nontrivial T.Node ∧ ∀ v : T.Node, ∃ w : T.Node, T.IsLeaf w ∧ v ≤ w := by
  constructor
  · rintro ⟨hnt, h⟩
    refine ⟨hnt, fun v => ?_⟩
    obtain ⟨c, ⟨w, hw, rfl⟩, hv⟩ := h v
    exact ⟨w, hw, hv⟩
  · rintro ⟨hnt, h⟩
    refine ⟨hnt, fun v => ?_⟩
    obtain ⟨w, hw, hv⟩ := h v
    exact ⟨T.pathTo w, ⟨w, hw, rfl⟩, hv⟩

/-- A complete infinite root-to-infinity path, one node at every finite depth. -/
structure InfiniteBranch where
  node : ℕ → T.Node
  root_eq : node 0 = T.root
  child : ∀ n : ℕ, T.IsChild (node n) (node (n + 1))

/-- Existence of an infinite branch, without a bound on how many branches exist. -/
def HasInfiniteBranch : Prop := Nonempty T.InfiniteBranch

/-- Source well-foundedness means exactly the absence of an infinite branch. -/
def IsWellFounded : Prop := ¬T.HasInfiniteBranch

theorem InfiniteBranch.depth_eq (b : T.InfiniteBranch) (n : ℕ) :
    T.depth (b.node n) = n := by
  induction n with
  | zero => rw [b.root_eq, T.depth_root]
  | succ n ih => simpa [ih] using (b.child n).2

theorem InfiniteBranch.injective (b : T.InfiniteBranch) : Function.Injective b.node := by
  intro m n h
  have := congrArg T.depth h
  simpa only [b.depth_eq] using this

theorem InfiniteBranch.monotone (b : T.InfiniteBranch) : Monotone b.node :=
  monotone_nat_of_le_succ (fun n => (b.child n).1)

theorem InfiniteBranch.range_isBranch (b : T.InfiniteBranch) :
    T.IsBranch (Set.range b.node) := by
  refine ⟨?_, ?_⟩
  · rintro _ ⟨m, rfl⟩ _ ⟨n, rfl⟩ _
    rcases le_total m n with h | h
    · exact Or.inl (b.monotone T h)
    · exact Or.inr (b.monotone T h)
  · intro c hc hsub
    apply Set.Subset.antisymm hsub
    intro v hv
    rcases hc.total hv (hsub ⟨T.depth v, rfl⟩) with h | h
    · exact ⟨T.depth v, (T.eq_of_le_of_depth_eq h (b.depth_eq T _).symm).symm⟩
    · exact ⟨T.depth v, T.eq_of_le_of_depth_eq h (b.depth_eq T _)⟩

theorem IsBranch.depth_injOn {c : Set T.Node} (hc : T.IsBranch c) :
    Set.InjOn T.depth c := by
  intro v hv w hw hdepth
  rcases hc.1.total hv hw with h | h
  · exact T.eq_of_le_of_depth_eq h hdepth
  · exact (T.eq_of_le_of_depth_eq h hdepth.symm).symm

theorem IsBranch.mem_of_le {c : Set T.Node} (hc : T.IsBranch c)
    {v w : T.Node} (hw : w ∈ c) (hvw : v ≤ w) : v ∈ c := by
  have hi : IsChain (· ≤ ·) (insert v c) := hc.1.insert (by
    intro x hx _
    rcases hc.1.total hx hw with h | h
    · exact List.prefix_or_prefix_of_prefix hvw h
    · exact Or.inl (hvw.trans h))
  have heq : c = insert v c := hc.2 hi (Set.subset_insert _ _)
  rw [heq]
  exact Set.mem_insert _ _

theorem IsBranch.exists_depth {c : Set T.Node} (hc : T.IsBranch c)
    (hinfinite : c.Infinite) (n : ℕ) : ∃ v ∈ c, T.depth v = n := by
  classical
  have hunbounded : ∃ w ∈ c, n ≤ T.depth w := by
    by_contra h
    push Not at h
    apply hinfinite
    apply Set.Finite.of_injOn (t := {m : ℕ | m ≤ n}) (f := T.depth) _
      (hc.depth_injOn T) (Set.finite_le_nat n)
    intro w hw
    change T.depth w ≤ n
    have := h w hw
    omega
  obtain ⟨w, hw, hn⟩ := hunbounded
  exact ⟨T.prefixAt w n, hc.mem_of_le T hw (T.prefixAt_le w n), T.depth_prefixAt w hn⟩

/-- The path encoding and the infinite-maximal-chain convention agree. -/
theorem hasInfiniteBranch_iff :
    T.HasInfiniteBranch ↔ ∃ c : Set T.Node, T.IsBranch c ∧ c.Infinite := by
  classical
  constructor
  · rintro ⟨b⟩
    exact ⟨Set.range b.node, b.range_isBranch T,
      Set.infinite_range_of_injective (b.injective T)⟩
  · rintro ⟨c, hc, hi⟩
    choose f hfmem hfdepth using hc.exists_depth T hi
    refine ⟨{ node := f, root_eq := (T.depth_eq_zero_iff _).mp (hfdepth 0), child := ?_ }⟩
    intro n
    refine ⟨?_, by rw [hfdepth, hfdepth]⟩
    rcases hc.1.total (hfmem n) (hfmem (n + 1)) with h | h
    · exact h
    · have hd := T.depth_mono h
      rw [hfdepth, hfdepth] at hd
      omega

theorem isWellFounded_iff :
    T.IsWellFounded ↔ ∀ c : Set T.Node, T.IsBranch c → c.Finite := by
  classical
  simp only [IsWellFounded, hasInfiniteBranch_iff, not_exists, not_and,
    Set.not_infinite]

/-- Remove the common root prefix to obtain the existing Mathlib tree model. -/
def suffixTree : Descriptive.tree Label where
  val := {v | T.rootList ++ v ∈ T.nodes}
  property := by
    intro v a h
    apply T.prefix_closed (List.prefix_append _ _)
      (List.prefix_append _ [a])
    simpa only [List.append_assoc] using h

@[simp] theorem mem_suffixTree (v : List Label) :
    v ∈ T.suffixTree ↔ T.rootList ++ v ∈ T.nodes := Iff.rfl

/-- Root-normalized representation; it has no extra source nodes. -/
def normalized : RootedPrefixTree Label where
  nodes := T.suffixTree
  rootList := []
  root_mem := by
    change T.rootList ++ [] ∈ T.nodes
    simpa using T.root_mem
  root_prefix := fun _ => List.nil_prefix
  prefix_closed := fun _ h hv => Descriptive.Tree.mem_of_prefix h hv
  countable_nodes := T.countable_nodes.preimage (fun _ _ h => List.append_cancel_left h)

/-- Explicit prefix-order equivalence: delete, or restore, exactly the root prefix. -/
def normalizeOrderIso : T.Node ≃o T.normalized.Node where
  toFun v := ⟨v.val.drop T.rootList.length, by
    change T.rootList ++ v.val.drop T.rootList.length ∈ T.nodes
    rw [List.prefix_iff_eq_append.mp (T.root_prefix v.property)]
    exact v.property⟩
  invFun v := ⟨T.rootList ++ v.val, v.property⟩
  left_inv v := by
    apply Subtype.ext
    exact List.prefix_iff_eq_append.mp (T.root_prefix v.property)
  right_inv v := by
    apply Subtype.ext
    simp
  map_rel_iff' := by
    intro v w
    change v.val.drop T.rootList.length <+: w.val.drop T.rootList.length ↔ v.val <+: w.val
    rw [← List.prefix_append_right_inj T.rootList]
    rw [List.prefix_iff_eq_append.mp (T.root_prefix v.property),
      List.prefix_iff_eq_append.mp (T.root_prefix w.property)]

@[simp] theorem normalizeOrderIso_root : T.normalizeOrderIso T.root = T.normalized.root := by
  apply Subtype.ext
  change T.rootList.drop T.rootList.length = []
  exact List.drop_length

@[simp] theorem normalizeOrderIso_depth (v : T.Node) :
    T.normalized.depth (T.normalizeOrderIso v) = T.depth v := by
  change (v.val.drop T.rootList.length).length - 0 = v.val.length - T.rootList.length
  simp

@[simp] theorem normalizeOrderIso_isChild (v w : T.Node) :
    T.normalized.IsChild (T.normalizeOrderIso v) (T.normalizeOrderIso w) ↔ T.IsChild v w := by
  simp [IsChild]

@[simp] theorem normalizeOrderIso_isLeaf (v : T.Node) :
    T.normalized.IsLeaf (T.normalizeOrderIso v) ↔ T.IsLeaf v := by
  constructor
  · intro h w hvw
    apply T.normalizeOrderIso.injective
    exact h _ (T.normalizeOrderIso.monotone hvw)
  · intro h w hvw
    obtain ⟨w, rfl⟩ := T.normalizeOrderIso.surjective w
    exact congrArg T.normalizeOrderIso (h w (T.normalizeOrderIso.le_iff_le.mp hvw))

theorem normalizeOrderIso_pathTo (v : T.Node) :
    T.normalizeOrderIso '' T.pathTo v = T.normalized.pathTo (T.normalizeOrderIso v) := by
  ext w
  constructor
  · rintro ⟨x, hx, rfl⟩
    exact T.normalizeOrderIso.monotone hx
  · intro hw
    refine ⟨T.normalizeOrderIso.symm w, ?_, T.normalizeOrderIso.apply_symm_apply w⟩
    apply T.normalizeOrderIso.le_iff_le.mp
    simpa only [OrderIso.apply_symm_apply] using hw

theorem normalizeOrderIso_isFiniteCompleteBranch (c : Set T.Node) :
    T.normalized.IsFiniteCompleteBranch (T.normalizeOrderIso '' c) ↔
      T.IsFiniteCompleteBranch c := by
  constructor
  · rintro ⟨v, hv, heq⟩
    obtain ⟨v, rfl⟩ := T.normalizeOrderIso.surjective v
    refine ⟨v, (T.normalizeOrderIso_isLeaf v).mp hv, ?_⟩
    ext w
    constructor
    · intro hw
      have hi : T.normalizeOrderIso w ∈ T.normalizeOrderIso '' c := ⟨w, hw, rfl⟩
      rw [heq] at hi
      exact T.normalizeOrderIso.le_iff_le.mp hi
    · intro hw
      have hi : T.normalizeOrderIso w ∈ T.normalizeOrderIso '' c := by
        rw [heq]
        exact T.normalizeOrderIso.monotone hw
      obtain ⟨x, hx, hxw⟩ := hi
      exact T.normalizeOrderIso.injective hxw ▸ hx
  · rintro ⟨v, hv, rfl⟩
    exact ⟨T.normalizeOrderIso v, (T.normalizeOrderIso_isLeaf v).mpr hv,
      T.normalizeOrderIso_pathTo v⟩

theorem normalized_isProper_iff : T.normalized.IsProper ↔ T.IsProper := by
  rw [isProper_iff, isProper_iff]
  constructor
  · rintro ⟨hnt, h⟩
    letI : Nontrivial T.normalized.Node := hnt
    refine ⟨T.normalizeOrderIso.toEquiv.nontrivial, fun v => ?_⟩
    obtain ⟨w, hw, hvw⟩ := h (T.normalizeOrderIso v)
    obtain ⟨w, rfl⟩ := T.normalizeOrderIso.surjective w
    exact ⟨w, (T.normalizeOrderIso_isLeaf w).mp hw, T.normalizeOrderIso.le_iff_le.mp hvw⟩
  · rintro ⟨hnt, h⟩
    letI : Nontrivial T.Node := hnt
    refine ⟨T.normalizeOrderIso.symm.toEquiv.nontrivial, fun v => ?_⟩
    obtain ⟨v, rfl⟩ := T.normalizeOrderIso.surjective v
    obtain ⟨w, hw, hvw⟩ := h v
    exact ⟨T.normalizeOrderIso w, (T.normalizeOrderIso_isLeaf w).mpr hw,
      T.normalizeOrderIso.monotone hvw⟩

@[ext] theorem InfiniteBranch.ext {b c : T.InfiniteBranch}
    (h : ∀ n : ℕ, b.node n = c.node n) : b = c := by
  cases b with
  | mk bn br bc =>
    cases c with
    | mk cn cr cc =>
      have heq : bn = cn := funext h
      cases heq
      rfl

/-- Root normalization preserves every infinite branch, not just its existence. -/
def normalizeInfiniteBranchEquiv : T.InfiniteBranch ≃ T.normalized.InfiniteBranch where
  toFun b := {
    node := fun n => T.normalizeOrderIso (b.node n)
    root_eq := by rw [b.root_eq, T.normalizeOrderIso_root]
    child := fun n => (T.normalizeOrderIso_isChild _ _).mpr (b.child n) }
  invFun b := {
    node := fun n => T.normalizeOrderIso.symm (b.node n)
    root_eq := by
      apply T.normalizeOrderIso.injective
      simp only [OrderIso.apply_symm_apply, b.root_eq, normalizeOrderIso_root]
    child := fun n => by
      apply (T.normalizeOrderIso_isChild _ _).mp
      simpa only [OrderIso.apply_symm_apply] using b.child n }
  left_inv b := by
    apply InfiniteBranch.ext T
    intro n
    exact T.normalizeOrderIso.symm_apply_apply (b.node n)
  right_inv b := by
    apply InfiniteBranch.ext T.normalized
    intro n
    exact T.normalizeOrderIso.apply_symm_apply (b.node n)

theorem normalized_hasInfiniteBranch_iff :
    T.normalized.HasInfiniteBranch ↔ T.HasInfiniteBranch :=
  T.normalizeInfiniteBranchEquiv.symm.nonempty_congr

theorem normalized_isWellFounded_iff :
    T.normalized.IsWellFounded ↔ T.IsWellFounded := by
  exact not_congr T.normalized_hasInfiniteBranch_iff

end RootedPrefixTree

end DIDomainClassification.Trees
