import DIDomainClassification.Support.StableClosureWitness

/-!
# The stable cartesian-closed background theorem

Theorem 2.2 for the literal countably based dI-domain category, including
domain closure, native products and stable exponentials, higher-order stable
operations, directed pointwise suprema and compatible pointwise infima.
Every component is supplied by proved constructions; no citation axiom is used.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02

theorem stableBackground : StableBackgroundStatement.{u} :=
  ⟨StableClosureWitness.domainClosure,
    StableClosureWitness.construction,
    StableClosureWitness.directedSupremaPointwise,
    StableClosureWitness.compatibleMeetsPointwise⟩

end DIDomainClassification.Section02
