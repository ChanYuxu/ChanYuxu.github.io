import DIDomainClassification.Section04.FiniteCategoryModels
import DIDomainClassification.Support.FiniteOrderDomains
import DIDomainClassification.Support.StableMapOperators
import Mathlib.CategoryTheory.Iso

/-! UNPROVED source296--300: actual three endomaps, native STABLE order,
pointwise comparison, no common STABLE upper bound, and genuine stable iso.
No general two-retract interface (stale or otherwise) is imported. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02.TwoExponentialModels

abbrev Two := FiniteOrderDomains.twoObject.{u}
abbrev Core := Two.{u}.toDIDomainObject
abbrev Endomaps := StableHom Core.{u} Core.{u}
abbrev Exponential := Section02.StableBackground.exponentialObject
  StableClosureWitness.domainClosure.{u} Two.{u} Two.{u}

def zeroMap : Endomaps.{u} := StableMapOperators.constant Two Two FiniteOrderDomains.zero
def identityMap : Endomaps.{u} := StableHom.id Core
def oneMap : Endomaps.{u} := StableMapOperators.constant Two Two FiniteOrderDomains.one

theorem zeroMap_apply (x : Core.{u}) : zeroMap x = FiniteOrderDomains.zero := rfl
theorem identityMap_apply (x : Core.{u}) : identityMap x = x := rfl
theorem oneMap_apply (x : Core.{u}) : oneMap x = FiniteOrderDomains.one := rfl

end DIDomainClassification.Section02.TwoExponentialModels

namespace DIDomainClassification.Section02

open CategoryTheory Preliminaries TwoExponentialModels Section04.FiniteCategoryModels

def TwoExponentialStatement : Prop :=
  ∃ hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} 2 (by decide)),
    (∀ f : Endomaps.{u}, f = zeroMap ∨ f = identityMap ∨ f = oneMap) ∧
    zeroMap.{u} ≠ identityMap ∧ zeroMap.{u} ≠ oneMap ∧ identityMap.{u} ≠ oneMap ∧
    (∀ f : Endomaps.{u}, zeroMap ≤ f) ∧
    (∀ x : Core.{u}, identityMap x ≤ oneMap x) ∧
    ¬ Compatible identityMap.{u} oneMap ∧
    Nonempty (Exponential.{u} ≅ cubeObject 2 (by decide) hCube)

end DIDomainClassification.Section02
