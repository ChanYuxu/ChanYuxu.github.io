import DIDomainClassification.Section02.QualitativeForbiddenRepresentationStatement

/-!
Source-facing proof of manuscript.tex399--402, frozen source SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
Choose ALL finite inconsistent subsets as the forbidden family. Its members
are nonempty by empty consistency, but the family itself may be empty.
The equivalence is proved for arbitrary, possibly infinite subsets of A.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Section02

open EventStructures

/-- Exact accepted qualitative forbidden-family representation statement. -/
theorem qualitativeForbiddenRepresentation : QualitativeForbiddenRepresentationStatement.{u} := by
  intro A _ E hQual
  let F : Set (Set A) := {U | U.Finite ∧ U ∉ E.Con}
  refine ⟨F, ?_, ?_⟩
  · intro U hU
    refine ⟨?_, hU.1⟩
    apply Set.nonempty_iff_ne_empty.mpr
    intro hEmpty
    apply hU.2
    simpa only [hEmpty] using E.empty_mem_Con
  · intro X
    constructor
    · intro hX U hU hUX
      exact hU.2 (hX.2 U hU.1 hUX)
    · intro hAvoid
      constructor
      · intro a b hab ha
        have hba : b = a := (hQual b a).mp hab
        simpa only [hba] using ha
      · intro U hU hUX
        by_contra hBad
        exact hAvoid U ⟨hU, hBad⟩ hUX

end DIDomainClassification.Section02

