import DIDomainClassification.Section02.TwoRetractStatement
import DIDomainClassification.Support.CompactPredicate

/-! Source manuscript.tex273--296, SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The literal two-point inclusion and compact threshold predicate are stable,
and their composite is the identity. The domain is arbitrary intrinsic dI;
neither countability nor an embedding--projection inequality is assumed.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02.TwoRetractionModels

open FiniteOrderDomains Preliminaries

theorem sectionMap_monotone (D : DIDomainObject.{u}) (a : Core D) :
    Monotone (sectionMap D a) := by
  intro x y hxy
  rcases eq_zero_or_one x with rfl | rfl
  · rw [section_zero]
    exact (Core D).isDIDomain.toIsScottDomain.bottom_le _
  · rcases eq_zero_or_one y with rfl | rfl
    · exact False.elim
        (zero_ne_one.{u} (le_antisymm (zero_le.{u} one.{u}) hxy))
    · exact le_rfl

theorem sectionMap_stable (D : DIDomainObject.{u}) (a : Core D) :
    IsStable TwoCore.{u} (Core D) (sectionMap D a) := by
  letI : Finite TwoCore.{u} := by
    change Finite TwoCarrier.{u}
    infer_instance
  apply stable_of_monotone_finite_total TwoCore (Core D)
  · intro x y
    rcases eq_zero_or_one x with rfl | rfl
    · exact Or.inl (zero_le y)
    · exact Or.inr (le_one y)
  · exact sectionMap_monotone D a

theorem predicate_stable (D : DIDomainObject.{u}) (a : Core D)
    (ha : IsCompactElement a) :
    IsStable (Core D) TwoCore.{u} (predicate D a) :=
  CompactPredicate.threshold_stable (Core D) ha

theorem predicate_section_leftInverse (D : DIDomainObject.{u}) (a : Core D)
    (ha : a ≠ (Core D).isDIDomain.toIsScottDomain.bottom) :
    Function.LeftInverse (predicate D a) (sectionMap D a) := by
  intro t
  rcases eq_zero_or_one t with rfl | rfl
  · rw [section_zero]
    apply predicate_of_not_le
    intro hab
    exact ha (le_antisymm hab ((Core D).isDIDomain.toIsScottDomain.bottom_le a))
  · rw [section_one]
    exact predicate_of_le D a a le_rfl

end DIDomainClassification.Section02.TwoRetractionModels

namespace DIDomainClassification.Section02

open Preliminaries TwoRetractionModels

theorem twoRetractionConstruction : TwoRetractionConstructionStatement := by
  intro D a ha hne
  exact ⟨sectionMap_stable D a, predicate_stable D a ha,
    predicate_section_leftInverse D a hne⟩

theorem twoRetract : TwoRetractStatement := by
  intro D hne
  obtain ⟨a, ha, hab⟩ := CompactPredicate.exists_compact_ne_least
    (Core D).isDIDomain.toIsScottDomain.algebraic
    (Core D).isDIDomain.toIsScottDomain.bottom
    (Core D).isDIDomain.toIsScottDomain.bottom_le hne
  refine ⟨⟨a, ha, hab⟩, ?_⟩
  obtain ⟨hs, hr, hleft⟩ := twoRetractionConstruction D a ha hab
  exact ⟨StableHom.ofFunction (sectionMap D a) hs,
    StableHom.ofFunction (predicate D a) hr, hleft⟩

end DIDomainClassification.Section02
