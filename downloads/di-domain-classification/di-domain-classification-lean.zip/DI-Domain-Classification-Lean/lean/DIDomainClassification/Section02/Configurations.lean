import DIDomainClassification.Section02.EventStructures
import Mathlib.Data.Set.Basic

/-!
# Configurations of a finitary prime event structure

Source: `manuscript.tex`, line 377, the definition of a configuration and the
notation `Conf(A)` for configurations ordered by inclusion. The frozen source
SHA-256 is
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

A configuration is an arbitrary subset of the event carrier: it is lower and
all its finite subsets are consistent. The configuration itself is not required
to be finite, nonempty or countable. Its carrier is the literal subtype of
`Set A` satisfying this predicate, with the inherited inclusion partial order.

No closure under directed unions or nonempty intersections, supremum/infimum
formula, compactness or representation theorem is assumed or proved here.
Status: provisional Step 3 translation; independent source-interface review
and acceptance are pending.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

/-- A configuration is a lower event subset whose every finite subset is
consistent. Finiteness is required only of the tested subset `F`, not of `X`.
-/
def IsConfiguration {A : Type u} [PartialOrder A]
    (E : FinitaryPrimeEventStructure A) (X : Set A) : Prop :=
  IsLowerSet X ∧ ∀ F : Set A, F.Finite → F ⊆ X → F ∈ E.Con

/-- The source carrier `Conf(A)`: exactly the subsets that are configurations.
Its partial order is inherited from `Set A`, namely subset inclusion.
-/
abbrev Configuration {A : Type u} [PartialOrder A]
    (E : FinitaryPrimeEventStructure A) : Type u :=
  {X : Set A // IsConfiguration E X}

namespace Configuration

/-- The underlying subset of a configuration satisfies the source predicate. -/
theorem isConfiguration {A : Type u} [PartialOrder A]
    {E : FinitaryPrimeEventStructure A} (X : Configuration E) :
    IsConfiguration E (X : Set A) := X.property

/-- The inherited order on configurations is exactly subset inclusion. -/
theorem le_iff_subset {A : Type u} [PartialOrder A]
    {E : FinitaryPrimeEventStructure A} (X Y : Configuration E) :
    X ≤ Y ↔ (X : Set A) ⊆ (Y : Set A) := Iff.rfl

end Configuration

end DIDomainClassification.EventStructures
