import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section02.CountableRetractStatement
import DIDomainClassification.Section03.StableFunctionModels
import DIDomainClassification.Support.StableHomGeneralClosure

/-! Literal raw all-dI maps and UNPROVED source238--264 calculus.
The target of dI preservation is NOT already assumed dI. No EP inequality,
strictness or whole-carrier countability condition is added. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.Section02.RetractionCalculusModels

open Preliminaries

def productCore (D E : DIDomainObject.{u}) (h : IsDIDomain (D × E)) : DIDomainObject.{u} :=
  DIDomainObject.ofType (D × E) h

def piCore {I : Type v} (D : I → DIDomainObject.{u})
    (h : IsDIDomain (∀ i, D i)) : DIDomainObject.{max u v} :=
  DIDomainObject.ofType (∀ i, D i) h

/-- Existing genuinely proved raw closure, not a new target-field premise. -/
def exponentialCore (D E : DIDomainObject.{u}) : DIDomainObject.{u} :=
  DIDomainObject.ofType (StableHom D E) (StableExponentialClosure.stableHom_isDIDomain D E)

theorem exponentialCore_order (D E : DIDomainObject.{u}) :
    (exponentialCore D E).partialOrder = (@StableHom.instPartialOrder D E) := rfl

theorem exponentialCore_countable_model (D E : CountablyBasedDIDomain.{u}) :
    exponentialCore D.toDIDomainObject E.toDIDomainObject =
      (Section03.StableFunctionModels.exponential D E).toDIDomainObject := rfl

def productMap {D E A B : DIDomainObject.{u}}
    (sD : StableHom D A) (sE : StableHom E B) (p : D × E) : A × B :=
  (sD p.1, sE p.2)

def piMap {I : Type v} {D A : I → DIDomainObject.{u}}
    (s : ∀ i, StableHom (D i) (A i)) (x : ∀ i, D i) : ∀ i, A i :=
  fun i => s i (x i)

def exponentialSection {D E A B : DIDomainObject.{u}}
    (rD : StableHom A D) (sE : StableHom E B) (f : StableHom D E) : StableHom A B :=
  StableHom.comp sE (StableHom.comp f rD)

def exponentialRetraction {D E A B : DIDomainObject.{u}}
    (sD : StableHom D A) (rE : StableHom B E) (g : StableHom A B) : StableHom D E :=
  StableHom.comp rE (StableHom.comp g sD)

theorem exponentialSection_apply {D E A B : DIDomainObject.{u}}
    (rD : StableHom A D) (sE : StableHom E B) (f : StableHom D E) (a : A) :
    exponentialSection rD sE f a = sE (f (rD a)) := rfl

theorem exponentialRetraction_apply {D E A B : DIDomainObject.{u}}
    (sD : StableHom D A) (rE : StableHom B E) (g : StableHom A B) (d : D) :
    exponentialRetraction sD rE g d = rE (g (sD d)) := rfl

end DIDomainClassification.Section02.RetractionCalculusModels

namespace DIDomainClassification.Section02

open Preliminaries RetractionCalculusModels

def RetractionCompositionStatement : Prop :=
  ∀ (D E F : DIDomainObject.{u}) (s : StableHom D E) (r : StableHom E D)
    (t : StableHom E F) (q : StableHom F E),
    Function.LeftInverse (r : E → D) (s : D → E) →
    Function.LeftInverse (q : F → E) (t : E → F) →
      Function.LeftInverse (StableHom.comp r q : F → D) (StableHom.comp t s : D → F) ∧
        HasStableRetraction D F

def RetractionBinaryProductStatement : Prop :=
  ∀ (D E A B : DIDomainObject.{u}) (sD : StableHom D A) (rD : StableHom A D)
    (sE : StableHom E B) (rE : StableHom B E),
    Function.LeftInverse (rD : A → D) (sD : D → A) →
    Function.LeftInverse (rE : B → E) (sE : E → B) →
    ∃ (hDE : IsDIDomain (D × E)) (hAB : IsDIDomain (A × B)),
      IsStable (productCore D E hDE) (productCore A B hAB) (productMap sD sE) ∧
      IsStable (productCore A B hAB) (productCore D E hDE) (productMap rD rE) ∧
      Function.LeftInverse (productMap rD rE) (productMap sD sE)

/-- Operative finite/countable ambient product preservation, with EXACT
coordinate maps and literal Pi orders. Both closure certificates are outputs. -/
def RetractionCountableProductStatement : Prop :=
  ∀ (I : Type v) [Countable I] (D A : I → CountablyBasedDIDomain.{u})
    (s : ∀ i, StableHom (D i).toDIDomainObject (A i).toDIDomainObject)
    (r : ∀ i, StableHom (A i).toDIDomainObject (D i).toDIDomainObject),
    (∀ i, Function.LeftInverse (r i : (A i).toDIDomainObject → (D i).toDIDomainObject)
      (s i : (D i).toDIDomainObject → (A i).toDIDomainObject)) →
    ∃ (hD : IsCountablyBasedDIDomain (∀ i, (D i).toDIDomainObject))
      (hA : IsCountablyBasedDIDomain (∀ i, (A i).toDIDomainObject)),
      IsStable (piCore (fun i => (D i).toDIDomainObject) hD.1)
        (piCore (fun i => (A i).toDIDomainObject) hA.1) (piMap s) ∧
      IsStable (piCore (fun i => (A i).toDIDomainObject) hA.1)
        (piCore (fun i => (D i).toDIDomainObject) hD.1) (piMap r) ∧
      Function.LeftInverse (piMap r) (piMap s)

def RetractionExponentialStatement : Prop :=
  ∀ (D E A B : DIDomainObject.{u}) (sD : StableHom D A) (rD : StableHom A D)
    (sE : StableHom E B) (rE : StableHom B E),
    Function.LeftInverse (rD : A → D) (sD : D → A) →
    Function.LeftInverse (rE : B → E) (sE : E → B) →
      IsStable (exponentialCore D E) (exponentialCore A B) (exponentialSection rD sE) ∧
      IsStable (exponentialCore A B) (exponentialCore D E) (exponentialRetraction sD rE) ∧
      Function.LeftInverse (exponentialRetraction sD rE) (exponentialSection rD sE)

/-- Raw minimal meet-data formulation; D has NO assumed algebraicity,
compact countability, bounded completeness or dI axiom. -/
def StableSplitDIPreservationStatement : Prop :=
  ∀ (D : Type u) (E : Type v) [SemilatticeInf D] [SemilatticeInf E],
    IsDIDomain E → ∀ (s : StableMap D E) (r : StableMap E D),
      Function.LeftInverse (r : E → D) (s : D → E) → IsDIDomain D

def RetractionCalculusStatement : Prop :=
  RetractionCompositionStatement.{u} ∧ RetractionBinaryProductStatement.{u} ∧
    RetractionCountableProductStatement.{u,v} ∧ RetractionExponentialStatement.{u} ∧
    StableSplitDIPreservationStatement.{u,v} ∧ ScottCountableRetractStatement.{u,v}

end DIDomainClassification.Section02
