import DIDomainClassification.Support.OrderCore

/-!
# Basic domain definitions used in Section 2

These are source-facing aliases of a narrow adaptation of the existing common
domain-theory definitions. No mathematical convention has changed; the former
umbrella import is deliberately excluded from this foundational layer.
They record the nonempty-directed convention of the manuscript, compactness,
algebraicity, and countability of the compact basis. They do not assert the
dI-domain axioms, cartesian closedness, or any classification theorem.

Status: provisional translation, pending current graph and independent
source-interface review. Compilation alone is not source acceptance.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Preliminaries

/-- Every nonempty directed subset has a supremum. -/
abbrev IsDcpo (D : Type u) [PartialOrder D] : Prop :=
  DIDomainClassification.OrderCore.IsDcpo D

/-- Compactness is tested against arbitrary nonempty directed suprema. -/
abbrev IsCompactElement {D : Type u} [PartialOrder D] (k : D) : Prop :=
  DIDomainClassification.OrderCore.Compact k

/-- The set `K(D)` of compact elements. -/
abbrev CompactElements (D : Type u) [PartialOrder D] : Set D :=
  DIDomainClassification.OrderCore.CompactSet D

/-- The compact elements below one point. -/
abbrev CompactBelow {D : Type u} [PartialOrder D] (x : D) : Set D :=
  DIDomainClassification.OrderCore.CompactBelow x

/-- Every point is the directed supremum of its compact approximants. -/
abbrev IsAlgebraicDcpo (D : Type u) [PartialOrder D] : Prop :=
  DIDomainClassification.OrderCore.IsAlgebraicDcpo D

/-- Algebraicity with countably many compact elements, not countably many points. -/
abbrev IsCountablyBasedAlgebraicDcpo (D : Type u) [PartialOrder D] : Prop :=
  DIDomainClassification.OrderCore.IsCountablyBasedAlgebraicDcpo D

end DIDomainClassification.Preliminaries
