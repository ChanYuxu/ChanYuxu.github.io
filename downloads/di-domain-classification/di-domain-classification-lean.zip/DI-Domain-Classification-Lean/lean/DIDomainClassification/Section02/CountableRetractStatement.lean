import DIDomainClassification.Section02.DomainDefinitions
import Mathlib.Order.ScottContinuity

/-!
# The general countable-basis retract statement

Source: the final clause of the unnumbered paragraph in Section 2.1 at line 264.
The target is not assumed or concluded algebraic. Its countable basis is a
domain-theoretic way-below basis, allowing the non-algebraic retract case.
This file contains definitions/specifications only, not a proof of the claim.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.Preliminaries

/-- A dcpo with an at-most-countable domain-theoretic approximation basis.
`IsBasis` uses nonempty directed sets of way-below approximants, not merely
a countable set of points or a sequence-specific approximation relation. -/
def IsCountablyBasedDcpo (D : Type u) [PartialOrder D] : Prop :=
  IsDcpo D ∧ ∃ B : Set D, B.Countable ∧ DIDomainClassification.OrderCore.IsBasis B

end DIDomainClassification.Preliminaries

namespace DIDomainClassification.Section02

open DIDomainClassification.Preliminaries

/-- A Scott-continuous split retract of a countably based algebraic dcpo has
a countable approximation basis. No EP inequality or least point is imposed. -/
def ScottCountableRetractStatement : Prop :=
  ∀ (D : Type u) (E : Type v) [PartialOrder D] [PartialOrder E],
    IsCountablyBasedAlgebraicDcpo D →
    ∀ (s : E → D) (r : D → E),
      _root_.ScottContinuous s → _root_.ScottContinuous r →
      Function.LeftInverse r s → IsCountablyBasedDcpo E

end DIDomainClassification.Section02
