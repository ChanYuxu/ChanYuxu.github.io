import DIDomainClassification.Section02.InheritedStatement
import DIDomainClassification.Section02.TwoRetract
import DIDomainClassification.Support.IntrinsicAmbientCore

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02
open CategoryTheory CategoryTheory.Limits Subcategories IntrinsicAmbient

theorem inherited : InheritedStatement.{u} := by
  intro P _hP hNontrivial hR _hCCC
  obtain ⟨D, hD, hxy⟩ := hNontrivial
  have hUnit : P unit := by
    apply hR unit D hD
    refine ⟨constant unit D D.toDIDomainObject.isDIDomain.toIsScottDomain.bottom,
      constant D unit PUnit.unit, ?_⟩
    intro x
    exact Subsingleton.elim _ _
  have hTwo : P two := hR two D hD (twoRetract D.toDIDomainObject hxy).2
  intro hProducts
  letI : HasFiniteProducts (FullStableSubcategory P) := hProducts
  intro X Y
  refine ⟨⟨productIso P hUnit hTwo X Y⟩, ?_⟩
  intro R A
  exact ⟨exponentialIso P hUnit hTwo X Y A⟩

end DIDomainClassification.Section02
