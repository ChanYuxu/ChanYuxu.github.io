import DIDomainClassification.Section02.QualitativeDomains
import Mathlib.Combinatorics.SimpleGraph.Clique

/-! Literal graph/clique DATA and UNPROVED source403 correspondence.
ALL cliques, including infinite subsets, are used. No Countable/Finite A
premise or antichain restriction on the forbidden family is added. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section02.BinaryCliqueModels

open EventStructures

abbrev CliqueCarrier {A : Type u} (G : SimpleGraph A) :=
  {X : Set A // G.IsClique X}

def compatibilityGraph {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A) :
    SimpleGraph A where
  Adj a b := a ≠ b ∧ ({a, b} : Set A) ∈ E.Con
  symm := by
    intro a b h
    exact ⟨h.1.symm, by simpa only [Set.pair_comm] using h.2⟩
  loopless := ⟨fun _ h => h.1 rfl⟩

abbrev equalityOrder (A : Type u) : PartialOrder A where
  le := Eq
  le_refl _ := rfl
  le_trans _ _ _ := Eq.trans
  le_antisymm _ _ h _ := h

def graphCon {A : Type u} (G : SimpleGraph A) : Set (Set A) :=
  {F | F.Finite ∧ G.IsClique F}

def graphForbidden {A : Type u} (G : SimpleGraph A) : Set (Set A) :=
  {U | ∃ a b : A, a ≠ b ∧ ¬ G.Adj a b ∧ U = {a, b}}

theorem cliqueCarrier_le_iff {A : Type u} (G : SimpleGraph A) (X Y : CliqueCarrier G) :
    X ≤ Y ↔ X.val ⊆ Y.val := Iff.rfl

end DIDomainClassification.Section02.BinaryCliqueModels

namespace DIDomainClassification.Section02

open EventStructures BinaryCliqueModels

def BinaryForbiddenCliqueForwardStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A) (F : Set (Set A)),
    IsQualitativePresentation E → IsForbiddenFamilyPresentation E F →
    HasBinaryMinimalMembers F →
      (∀ X : Set A, IsConfiguration E X ↔ (compatibilityGraph E).IsClique X) ∧
      ∃ e : Configuration E ≃o CliqueCarrier (compatibilityGraph E),
        ∀ X : Configuration E, (e X).val = X.val

def GraphCliqueConstructionStatement : Prop :=
  ∀ (A : Type u) (G : SimpleGraph A),
    letI : PartialOrder A := equalityOrder A
    ∃ E : FinitaryPrimeEventStructure A,
      IsQualitativePresentation E ∧ E.Con = graphCon G ∧
      IsForbiddenFamilyPresentation E (graphForbidden G) ∧
      HasBinaryMinimalMembers (graphForbidden G) ∧
      (∀ X : Set A, IsConfiguration E X ↔ G.IsClique X) ∧
      ∃ e : Configuration E ≃o CliqueCarrier G,
        ∀ X : Configuration E, (e X).val = X.val

def BinaryForbiddenCliqueCorrespondenceStatement : Prop :=
  BinaryForbiddenCliqueForwardStatement.{u} ∧ GraphCliqueConstructionStatement.{u}

end DIDomainClassification.Section02
