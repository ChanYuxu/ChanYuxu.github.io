import Mathlib.Order.Fin.Basic
import Mathlib.Data.Countable.Defs
import Mathlib.Order.Hom.Set

/-!
# The three basic source posets

Source: the unnumbered definitions at `manuscript.tex`, lines 266–273.
Frozen source SHA-256:
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

`Two` is the literal zero/one chain. `TruncatedCube n hn` is the inclusion
poset of proper subsets of `Fin n`, with the printed condition `2 ≤ n` retained
in its interface. The label shift from `0,...,n-1` to the source's `1,...,n`
is an explicit proved equivalence, and induces an order isomorphism of the
proper-powerset carriers. `FlatNat` has a separate bottom and incomparable
natural-number atoms; its order is not inherited from the usual natural order.

These definitions and order/label bridges assume no dI-domain property,
coherence degree, nontrivial-domain retraction, or exponential theorem.
Status: provisional Step 3 candidate, pending independent source review.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.BasicDomains

/-- The source two-element chain `{0 < 1}`, with the usual finite ordinal order. -/
abbrev Two := Fin 2

theorem two_eq_zero_or_one (x : Two) : x = 0 ∨ x = 1 := by
  rcases Nat.eq_zero_or_pos x.val with hx | hx
  · exact Or.inl (Fin.ext hx)
  · exact Or.inr (Fin.ext (Nat.le_antisymm (Nat.le_of_lt_succ x.isLt) hx))

theorem two_le_iff_val (x y : Two) : x ≤ y ↔ x.val ≤ y.val := Iff.rfl

theorem two_zero_lt_one : (0 : Two) < 1 := by decide

/-- Proper subsets of a carrier, with the actual inherited subset order. -/
abbrev ProperSubsets (A : Type u) : Type u := {S : Set A // S ≠ Set.univ}

/-- The actual source labels are natural numbers from `1` through `n`. -/
abbrev SourceLabel (n : ℕ) := {j : ℕ // j ∈ Set.Icc 1 n}

/-- Explicitly shift the finite ordinal labels by one; no label is lost. -/
def sourceLabelEquiv (n : ℕ) : Fin n ≃ SourceLabel n where
  toFun i := ⟨i.val + 1, Nat.succ_le_succ (Nat.zero_le i.val),
    Nat.succ_le_of_lt i.isLt⟩
  invFun j := ⟨j.val - 1,
    lt_of_lt_of_le (Nat.sub_lt j.property.1 (by decide)) j.property.2⟩
  left_inv i := by
    apply Fin.ext
    exact Nat.add_sub_cancel i.val 1
  right_inv j := by
    apply Subtype.ext
    exact Nat.sub_add_cancel j.property.1

theorem sourceLabelEquiv_apply_val (n : ℕ) (i : Fin n) :
    (sourceLabelEquiv n i).val = i.val + 1 := rfl

/-- The label shift also respects the ordinary order of the finite labels. -/
def sourceLabelOrderIso (n : ℕ) : Fin n ≃o SourceLabel n where
  toEquiv := sourceLabelEquiv n
  map_rel_iff' := by
    intro i j
    change i.val + 1 ≤ j.val + 1 ↔ i.val ≤ j.val
    exact Nat.succ_le_succ_iff

/-- Transport a proper subset by the image of an explicit label equivalence. -/
def properImage {A : Type u} {B : Type v} (e : A ≃ B)
    (S : ProperSubsets A) : ProperSubsets B :=
  ⟨e '' S.val, by
    intro htop
    apply S.property
    apply Set.eq_univ_of_forall
    intro a
    have ha : e a ∈ e '' S.val := by
      rw [htop]
      exact Set.mem_univ _
    rcases ha with ⟨b, hb, hba⟩
    exact (e.injective hba) ▸ hb⟩

/-- Relabelling gives the actual inclusion-order isomorphism after deleting top. -/
def properSubsetsOrderIso {A : Type u} {B : Type v} (e : A ≃ B) :
    ProperSubsets A ≃o ProperSubsets B where
  toFun := properImage e
  invFun := properImage e.symm
  left_inv S := by
    apply Subtype.ext
    exact e.symm_image_image S.val
  right_inv S := by
    apply Subtype.ext
    exact e.image_symm_image S.val
  map_rel_iff' := by
    intro S T
    exact e.image_subset S.val T.val

/-- The source `T_n`, encoded by the proper subsets of `Fin n`, only for `n ≥ 2`. -/
abbrev TruncatedCube (n : ℕ) (_hn : 2 ≤ n) : Type := ProperSubsets (Fin n)

/-- The same proper-powerset model with the literal source labels `1,...,n`. -/
abbrev SourceTruncatedCube (n : ℕ) (_hn : 2 ≤ n) : Type :=
  ProperSubsets (SourceLabel n)

theorem truncatedCube_le_iff (n : ℕ) (hn : 2 ≤ n) (S T : TruncatedCube n hn) :
    S ≤ T ↔ S.val ⊆ T.val := Iff.rfl

/-- The index shift is bridged on the entire source carrier, not just its atoms. -/
def truncatedCube_sourceOrderIso (n : ℕ) (hn : 2 ≤ n) :
    TruncatedCube n hn ≃o SourceTruncatedCube n hn :=
  properSubsetsOrderIso (sourceLabelEquiv n)

theorem truncatedCube_sourceOrderIso_apply (n : ℕ) (hn : 2 ≤ n)
    (S : TruncatedCube n hn) :
    (truncatedCube_sourceOrderIso n hn S).val = (sourceLabelEquiv n) '' S.val := rfl

/-- The literal carrier of the countable flat natural-number domain. -/
inductive FlatNat where
  | bot
  | nat (n : ℕ)
  deriving DecidableEq

namespace FlatNat

/-- Only bottom is below a distinct point; natural-number atoms are incomparable. -/
def Rel (x y : FlatNat) : Prop := x = bot ∨ x = y

instance instPartialOrder : PartialOrder FlatNat where
  le := Rel
  le_refl x := Or.inr rfl
  le_trans x y z hxy hyz := by
    rcases hxy with hx | hxy
    · exact Or.inl hx
    · rw [hxy]
      exact hyz
  le_antisymm x y hxy hyx := by
    rcases hxy with hx | hxy
    · rcases hyx with hy | hyx
      · exact hx.trans hy.symm
      · exact hyx.symm
    · exact hxy

instance instOrderBot : OrderBot FlatNat where
  bot := FlatNat.bot
  bot_le _x := Or.inl rfl

theorem le_iff (x y : FlatNat) : x ≤ y ↔ x = bot ∨ x = y := Iff.rfl

theorem nat_le_nat_iff (m n : ℕ) : nat m ≤ nat n ↔ m = n := by
  simp [le_iff]

theorem nat_not_le_bot (n : ℕ) : ¬ nat n ≤ bot := by
  simp [le_iff]

/-- This enumeration is only a carrier equivalence, never a transfer of order. -/
def encode : FlatNat → ℕ
  | bot => 0
  | nat n => n + 1

def decode : ℕ → FlatNat
  | 0 => bot
  | n + 1 => nat n

def equivNat : FlatNat ≃ ℕ where
  toFun := encode
  invFun := decode
  left_inv x := by cases x <;> rfl
  right_inv n := by cases n <;> rfl

/-- Countability follows from the explicit enumeration, not an assumed field. -/
instance instCountable : Countable FlatNat := equivNat.injective.countable

end FlatNat

end DIDomainClassification.BasicDomains
