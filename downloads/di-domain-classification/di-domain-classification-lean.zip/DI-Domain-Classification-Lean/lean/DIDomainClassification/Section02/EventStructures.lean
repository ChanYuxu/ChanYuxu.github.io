import Mathlib.Data.Finite.Defs
import Mathlib.Order.Interval.Set.Defs

/-!
# Finitary prime event structures

Source: `manuscript.tex`, lines 361–376, unnumbered definition in
Section 2, "Event representations". The frozen source SHA-256 is
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

The carrier and its partial order are explicit parameters. Consistency is a
family of sets, with finiteness required of every member. Thus the interface
uses the source's subsets directly, without a decidable-equality assumption or
a finite-set representation bridge. No countability or nonemptiness assumption
is imposed on the carrier.

This module defines only the event-structure interface. It does not define
configurations or assume any event-representation or domain-theoretic theorem.
Status: provisional Step 3 translation; independent source-interface review
and acceptance are pending.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

/-- A finitary prime event structure on an arbitrary partially ordered carrier.

The ambient `PartialOrder A` is the source order `≤_A`. The consistency family
`Con` contains only finite subsets and satisfies exactly the closure conditions
of the source definition. Countability, when needed later, is a separate
assumption on `A`, not part of this structure.
-/
structure FinitaryPrimeEventStructure (A : Type u) [PartialOrder A] where
  /-- The family `Con` of consistent subsets of the event carrier. -/
  Con : Set (Set A)
  /-- Every principal ideal `↓a = {b | b ≤ a}` is finite. -/
  finite_principalIdeal : ∀ a : A, (Set.Iic a).Finite
  /-- Every member of the consistency family is finite. -/
  finite_of_mem_Con : ∀ {F : Set A}, F ∈ Con → F.Finite
  /-- The empty event set is consistent. -/
  empty_mem_Con : (∅ : Set A) ∈ Con
  /-- Each singleton event set is consistent. -/
  singleton_mem_Con : ∀ a : A, {a} ∈ Con
  /-- Every subset of a consistent set is consistent. -/
  hereditary : ∀ {F G : Set A}, F ⊆ G → G ∈ Con → F ∈ Con
  /-- Adding a causal predecessor of a member preserves consistency. -/
  causal_closure : ∀ {F : Set A} {a b : A},
    F ∈ Con → a ≤ b → b ∈ F → F ∪ {a} ∈ Con

end DIDomainClassification.EventStructures
