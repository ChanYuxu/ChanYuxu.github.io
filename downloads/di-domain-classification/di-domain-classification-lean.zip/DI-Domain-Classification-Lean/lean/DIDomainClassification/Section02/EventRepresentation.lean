import DIDomainClassification.Section02.EventRepresentationStatements
import DIDomainClassification.Support.ConfigurationDomain
import DIDomainClassification.Support.PrimeEventDecomposition

/-!
# Theorem 2.5: source prime-event representation

Source: manuscript.tex:389--395, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

The manuscript cites Winskel2009 but gives no written proof. These are local,
book-free Lean proofs of the four accepted source targets. The converse uses
the proved complete-prime decomposition in finite principal ideals and the
actual Scott supremum of a configuration's event values. No representation,
countable whole-domain carrier, or classification conclusion is assumed.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

open DIDomainClassification.Preliminaries

/-- Countable events yield a countably based dI-domain of actual configurations. -/
theorem configurationDomain : ConfigurationDomainStatement.{u} := by
  intro A instA countA E
  exact ⟨ConfigurationDomain.dIDomain E, ConfigurationDomain.compactElements_countable E⟩

/-- Complete primes supply the actual event carrier and finite/bounded Con.
Only the compact basis is countable; the domain carrier remains arbitrary. -/
theorem primeEventRepresentation : PrimeEventRepresentationStatement.{u} := by
  intro D instD hD
  let P : D → Prop := FinitePrimeDecomposition.IsCompletePrime
  have hCompact : ∀ p : D, P p → OrderCore.Compact p :=
    fun _ hp => FinitePrimeDecomposition.completePrime_isCompact hp
  let E := PrimeEventPresentation.eventStructure hD.1 P hCompact
  have hCountable : Countable (PrimeEventPresentation.Carrier P) :=
    PrimeEventPresentation.carrier_countable P hCompact hD.2
  refine ⟨PrimeEventPresentation.Carrier P,
    (inferInstance : PartialOrder (PrimeEventPresentation.Carrier P)), ?_⟩
  refine ⟨hCountable, E, ?_⟩
  exact ⟨PrimeEventPresentation.representationOrderIso hD.1 P hCompact
    (fun p hp => (FinitePrimeDecomposition.isCompletePrime_iff_lub p).mp hp)
    (FinitePrimeDecomposition.point_isLUB_primes_below hD.1)⟩

/-- Compact configurations are exactly the finite underlying event sets. -/
theorem configurationCompactElements : ConfigurationCompactElementsStatement.{u} := by
  intro A instA countA E X
  exact ConfigurationDomain.compact_iff_finite E X

/-- The witness is literally the given event's principal downset. -/
theorem principalConfigurationCompact : PrincipalConfigurationCompactStatement.{u} := by
  intro A instA countA E a
  refine ⟨ConfigurationDomain.principal E a, rfl, ?_⟩
  exact ConfigurationDomain.compact_of_finite E _ (E.finite_principalIdeal a)

end DIDomainClassification.EventStructures
