import DIDomainClassification.Section02.Trees
import Mathlib.Order.WellFounded
import Mathlib.Order.Zorn

/-!
# No infinite source branch iff the descendant relation is well-founded

Staged generic Step 3 model bridge for source manuscript.tex:414, before
introducing ranks. No tree-rank, coherence-degree, or classification law is
asserted. Properness, finite branching and countability of completions are
not hypotheses. The distinguished root may be any finite prefix.

The recursion relation points FROM a strict descendant TO its ancestor:
`DescendantRelation descendant ancestor` means `ancestor < descendant` in
the accepted prefix order. Reversing this orientation would instead describe
the automatically well-founded finite-ancestor direction and would not encode
the source's absence of infinite branches.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Trees.RootedPrefixTree

variable {Label : Type u} (T : DIDomainClassification.Trees.RootedPrefixTree Label)

-- All four projections select the already accepted prefix order explicitly;
-- a concrete underlying List subtype may otherwise inherit a different order.
local instance sourcePartialOrder : PartialOrder T.Node := instPartialOrderNode T
local instance sourcePreorder : Preorder T.Node := (sourcePartialOrder T).toPreorder
local instance sourceLE : LE T.Node := (sourcePartialOrder T).toLE
local instance sourceLT : LT T.Node := (sourcePartialOrder T).toLT

/-- Strict descendants are smaller for downward tree recursion. -/
def DescendantRelation (descendant ancestor : T.Node) : Prop :=
  ancestor < descendant

/-- The exact proper-prefix meaning, including the direction and strictness. -/
theorem descendantRelation_iff (descendant ancestor : T.Node) :
    T.DescendantRelation descendant ancestor ↔
      ancestor.val <+: descendant.val ∧ ancestor.val ≠ descendant.val := by
  constructor
  · intro h
    exact ⟨h.le, fun heq => h.ne (Subtype.ext heq)⟩
  · rintro ⟨hprefix, hne⟩
    exact lt_of_le_of_ne hprefix (fun heq => hne (congrArg Subtype.val heq))

/-- An immediate child is, in particular, a strict descendant. -/
theorem isChild_descendantRelation {parent child : T.Node}
    (h : T.IsChild parent child) : T.DescendantRelation child parent := by
  apply lt_of_le_of_ne h.1
  intro heq
  have hd := h.2
  rw [heq] at hd
  omega

/-- A strictly increasing source-node stream lies in an infinite maximal branch.
There is no finite-branching assumption: use general chain extension. -/
theorem infiniteBranchSet_of_strictMono (f : ℕ → T.Node) (hf : StrictMono f) :
    ∃ c : Set T.Node, T.IsBranch c ∧ c.Infinite ∧ Set.range f ⊆ c := by
  obtain ⟨c, hc, hsub⟩ := hf.monotone.isChain_range.exists_maxChain
  exact ⟨c, hc, (Set.infinite_range_of_injective hf.injective).mono hsub, hsub⟩

/-- Prefix completion and the accepted branch bridge turn an arbitrary strict
node stream, even one starting below the root or skipping levels, into an
infinite root-started immediate-child branch. -/
theorem hasInfiniteBranch_of_strictMono (f : ℕ → T.Node) (hf : StrictMono f) :
    T.HasInfiniteBranch := by
  obtain ⟨c, hc, hinfinite, _hsub⟩ := T.infiniteBranchSet_of_strictMono f hf
  exact T.hasInfiniteBranch_iff.mpr ⟨c, hc, hinfinite⟩

/-- Exact source-to-Mathlib bridge for recursion through strict descendants. -/
theorem isWellFounded_iff_wellFounded_descendantRelation :
    T.IsWellFounded ↔ WellFounded T.DescendantRelation := by
  constructor
  · intro hsource
    apply wellFounded_iff_isEmpty_descending_chain.mpr
    refine ⟨?_⟩
    rintro ⟨f, hstep⟩
    have hmono : StrictMono f := strictMono_nat_of_lt_succ (fun n => hstep n)
    exact hsource (T.hasInfiniteBranch_of_strictMono f hmono)
  · intro hwf
    rintro ⟨b⟩
    have hempty := wellFounded_iff_isEmpty_descending_chain.mp hwf
    exact hempty.false ⟨b.node, fun n => T.isChild_descendantRelation (b.child n)⟩

/-- The immediate-child version of the same recursion orientation. -/
def ReverseChildRelation (child parent : T.Node) : Prop :=
  T.IsChild parent child

/-- Source well-foundedness also gives the actual child-recursion relation. -/
theorem isWellFounded_iff_wellFounded_reverseChildRelation :
    T.IsWellFounded ↔ WellFounded T.ReverseChildRelation := by
  constructor
  · intro hsource
    exact (T.isWellFounded_iff_wellFounded_descendantRelation.mp hsource).mono
      (fun _ _ h => T.isChild_descendantRelation h)
  · intro hwf
    rintro ⟨b⟩
    have hempty := wellFounded_iff_isEmpty_descending_chain.mp hwf
    exact hempty.false ⟨b.node, b.child⟩


end DIDomainClassification.Trees.RootedPrefixTree
