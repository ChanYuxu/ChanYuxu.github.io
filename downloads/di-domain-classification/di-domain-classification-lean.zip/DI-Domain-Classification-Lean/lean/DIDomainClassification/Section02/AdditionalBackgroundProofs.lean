import DIDomainClassification.Section02.AdditionalBackgroundStatements
import DIDomainClassification.Section02.CoherenceCharacterization
import DIDomainClassification.Support.CompactMicChains
import DIDomainClassification.Support.PrimeEventDecomposition
import DIDomainClassification.Support.OrderIsoTransport

/-!
# Three additional source background claims

Frozen source manuscript.tex:397, 403 and485--490, SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

The wrappers below retain the accepted general dI, raw Scott-domain and
arbitrary event-carrier scopes. The representation argument uses the genuinely
proved complete-prime construction underlying the event representation, with
no countable-basis premise. Conditional completeness uses the genuinely proved
raw finite-degree equivalence underlying BPS, not a countably-based special case.
No strictness, global upper bound or whole-carrier countability is assumed.
Original-source and independent proof review remain separate.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Section02

open Preliminaries EventStructures CoherenceDegree FiniteTraceApproximations

/-- Literal intersections distribute over every existing configuration LUB.
This includes the empty family; no nonempty-family premise is used. -/
theorem configuration_inf_isLUB_image {A : Type u} [PartialOrder A]
    (E : FinitaryPrimeEventStructure A) (X : configurationObject E)
    (C : Set (configurationObject E)) (Z : configurationObject E)
    (hZ : IsLUB C Z) :
    IsLUB ((fun Y : configurationObject E => X ⊓ Y) '' C) (X ⊓ Z) := by
  have hZval : Z.val = ⋃ Y ∈ C, Y.val :=
    congrArg (fun Y : Configuration E => Y.val)
      (hZ.unique (ConfigurationDomain.boundedUnion_isLUB E C Z
        (fun Y hY => hZ.1 hY)))
  constructor
  · rintro _ ⟨Y, hY, rfl⟩
    exact inf_le_inf_left X (hZ.1 hY)
  · intro W hW
    apply (Configuration.le_iff_subset _ _).mpr
    intro a ha
    rw [target_inf_val] at ha
    rw [hZval] at ha
    obtain ⟨Y, haY⟩ := Set.mem_iUnion.mp ha.2
    obtain ⟨hY, haY⟩ := Set.mem_iUnion.mp haY
    have haXY : a ∈ (X ⊓ Y).val := by
      rw [target_inf_val]
      exact ⟨ha.1, haY⟩
    exact (Configuration.le_iff_subset _ _).mp (hW ⟨Y, hY, rfl⟩) haXY

/-- Exact source397 claim, via the actual proved complete-prime presentation. -/
theorem eventsDistributivity : EventsDistributivityStatement.{u} := by
  intro D x S _hS s hs
  let P : D → Prop := FinitePrimeDecomposition.IsCompletePrime
  have hCompact : ∀ p : D, P p → OrderCore.Compact p :=
    fun _ hp => FinitePrimeDecomposition.completePrime_isCompact hp
  let E := PrimeEventPresentation.eventStructure D.isDIDomain P hCompact
  let F := configurationObject E
  let e : D ≃o F :=
    PrimeEventPresentation.representationOrderIso D.isDIDomain P hCompact
      (fun p hp => (FinitePrimeDecomposition.isCompletePrime_iff_lub p).mp hp)
      (FinitePrimeDecomposition.point_isLUB_primes_below D.isDIDomain)
  have hInf (a b : D) : e (a ⊓ b) = e a ⊓ e b :=
    OrderIsoTransport.map_intrinsic_inf e D.isDIDomain.toIsScottDomain
      F.isDIDomain.toIsScottDomain a b
  have hImage :
      e '' ((fun y : D => x ⊓ y) '' S) =
        (fun Y : F => e x ⊓ Y) '' (e '' S) := by
    ext Y
    constructor
    · rintro ⟨_, ⟨y, hy, rfl⟩, rfl⟩
      exact ⟨e y, ⟨y, hy, rfl⟩, (hInf x y).symm⟩
    · rintro ⟨_, ⟨y, hy, rfl⟩, rfl⟩
      exact ⟨x ⊓ y, ⟨y, hy, rfl⟩, hInf x y⟩
  have hLUB := configuration_inf_isLUB_image E (e x) (e '' S) (e s)
    (e.isLUB_image'.mpr hs)
  apply e.isLUB_image'.mp
  rw [hImage, hInf]
  exact hLUB

/-- A finite set of at most two pairwise compatible elements is bounded,
including the empty case supplied by the actual Scott bottom. -/
theorem consistent_of_pairwise_of_ncard_le_two {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (X : Set D) (hX : X.Finite) (hcard : X.ncard ≤ 2)
    (hpair : ∀ x ∈ X, ∀ y ∈ X, Compatible x y) : Consistent X := by
  by_cases hsmall : X.ncard ≤ 1
  · have hsub : X.Subsingleton := (Set.ncard_le_one hX).mp hsmall
    rcases X.eq_empty_or_nonempty with rfl | ⟨x, hx⟩
    · exact ⟨hD.bottom, by intro x hx; exact False.elim hx⟩
    · exact ⟨x, fun y hy => (hsub hy hx).le⟩
  · have heq : X.ncard = 2 := by omega
    obtain ⟨x, y, _hne, rfl⟩ := Set.ncard_eq_two.mp heq
    exact (compatible_iff_bddAbove_pair x y).mp (hpair x (by simp) y (by simp))

/-- The converse finite test uses the literal two-element subset, including
its possibly-singleton diagonal case, not a nonempty or distinctness premise. -/
theorem pair_ncard_le_two {D : Type u} (x y : D) : ({x, y} : Set D).ncard ≤ 2 := by
  by_cases h : x = y
  · subst y
    simp
  · rw [Set.ncard_pair h]

/-- Exact source485--490 equivalence for arbitrary raw Scott domains. -/
theorem conditionalCompleteness : ConditionalCompletenessStatement.{u} := by
  intro D _ hD
  have hDegree : coherenceDegree hD ≤ 2 ↔ IsNCoherent hD 2 (by decide) := by
    simpa using finite_degree_iff_nCoherent hD 2 (by decide)
  rw [hDegree]
  constructor
  · intro hTwo X hPair
    have hConsistent : Consistent X :=
      (coherenceCharacterization D hD 2 (by decide)).mp hTwo X (by
        intro F hFX hF hcard
        exact consistent_of_pairwise_of_ncard_le_two hD F hF hcard
          (fun x hx y hy => hPair x (hFX hx) y (hFX hy)))
    exact hD.boundedSuprema X hConsistent
  · intro hComplete
    apply (coherenceCharacterization D hD 2 (by decide)).mpr
    intro X hFiniteTests
    have hPair : ∀ x ∈ X, ∀ y ∈ X, Compatible x y := by
      intro x hx y hy
      apply (compatible_iff_bddAbove_pair x y).mpr
      apply hFiniteTests {x, y}
      · intro z hz
        rcases Set.mem_insert_iff.mp hz with rfl | hz
        · exact hx
        · simpa only [Set.mem_singleton_iff.mp hz] using hy
      · exact (Set.finite_singleton y).insert x
      · exact pair_ncard_le_two x y
    obtain ⟨s, hs⟩ := hComplete X hPair
    exact ⟨s, hs.1⟩

/-- Exact source403 map criterion, proved directly from the supplied ALL-LUB
directed-union formula and the native intrinsic binary-infimum formula. -/
theorem configurationStability : ConfigurationStabilityStatement.{u,v} := by
  intro A B _ _ E F f hUnion hInf
  constructor
  · intro C hne hdir Z hZ
    have hval := hUnion C ⟨hne, hdir⟩ Z hZ
    constructor
    · rintro _ ⟨Y, hY, rfl⟩
      apply (Configuration.le_iff_subset _ _).mpr
      intro b hb
      rw [hval]
      exact Set.mem_iUnion.mpr ⟨Y, Set.mem_iUnion.mpr ⟨hY, hb⟩⟩
    · intro W hW
      apply (Configuration.le_iff_subset _ _).mpr
      intro b hb
      rw [hval] at hb
      obtain ⟨Y, hbY⟩ := Set.mem_iUnion.mp hb
      obtain ⟨hY, hbY⟩ := Set.mem_iUnion.mp hbY
      exact (Configuration.le_iff_subset _ _).mp (hW ⟨Y, hY, rfl⟩) hbY
  · intro X Y _hCompatible
    exact hInf X Y

end DIDomainClassification.Section02

