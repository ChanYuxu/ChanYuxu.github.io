import DIDomainClassification.Section02.RankDegree
import DIDomainClassification.Section02.TreeDomain
import DIDomainClassification.Section02.QualitativeDomains
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Support.OrdinalCutBounds

/-!
# Staged source-facing BPS and tree-domain-construction interfaces

Frozen source manuscript.tex SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
Graph v5: thm:bps, lines445--476; p:tree-domain-construction, lines434--441.

These are unproved Step3 propositions, not accepted theorem declarations.
BPS ranges over arbitrary separable Scott domains, not only dI-domains.
Closure of each literal product/function/tree carrier is an existential OUTPUT
where needed to type its coherence degree, never a hypothesis supplied by the
caller. The pointwise function order is the original function-subtype order.
No countability of the whole domain, finite branching or strictness is assumed.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Section02.BPS

open DIDomainClassification.Preliminaries
open DIDomainClassification.CoherenceDegree
open DIDomainClassification.Trees

/-- Separable means countability of the actual compact set, not of all points. -/
def IsSeparableScottDomain (D : Type u) [PartialOrder D] : Prop :=
  IsScottDomain D ∧ (CompactElements D).Countable

/-- The Scott split on raw ordered carriers: no dI, strictness or EP inequality. -/
def HasScottSplit (D : Type u) (E : Type v) [PartialOrder D] [PartialOrder E] : Prop :=
  ∃ (s : D → E) (r : E → D),
    ScottContinuous s ∧ ScottContinuous r ∧ Function.LeftInverse r s

/-- On the older dI-bundled interface this is literally the same split relation. -/
theorem hasScottSplit_iff_hasScottRetraction
    (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) :
    HasScottSplit D E ↔ HasScottRetraction D E := Iff.rfl

/-- All Scott-continuous functions between raw carriers, not a stable subspace. -/
abbrev PointwiseScottSpace (D : Type u) (E : Type v)
    [PartialOrder D] [PartialOrder E] : Type (max u v) :=
  {f : D → E // ScottContinuous f}

/-- The function-subtype order is precisely pointwise order. -/
theorem pointwiseScottSpace_le_iff {D : Type u} {E : Type v}
    [PartialOrder D] [PartialOrder E] (f g : PointwiseScottSpace D E) :
    f ≤ g ↔ ∀ x : D, f.val x ≤ g.val x := Iff.rfl

/-- This carrier specializes definitionally to the accepted dI Scott carrier. -/
theorem pointwiseScottSpace_eq_scottHom
    (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) :
    PointwiseScottSpace D E = ScottHom D E := rfl

/-- The existing actual omega1 helper: successor cardinal of aleph0, then ord. -/
abbrev firstUncountable : Ordinal.{u+1} :=
  DIDomainClassification.Subcategories.firstUncountableBound.{u}

theorem firstUncountable_eq :
    firstUncountable.{u} = (Order.succ Cardinal.aleph0.{u+1}).ord := rfl

/-- The underlying given order is complete iff every subset has both extrema. -/
def IsCompleteLatticeOrder (D : Type u) [PartialOrder D] : Prop :=
  ∀ X : Set D, (∃ s : D, IsLUB X s) ∧ ∃ m : D, IsGLB X m

/-- The actual product degree family is small, hence its iSup is bounded. -/
theorem productDegreeFamily_bddAbove {I : Type u} (D : I → Type u)
    [∀ i : I, PartialOrder (D i)] (hD : ∀ i : I, IsScottDomain (D i)) :
    BddAbove (Set.range (fun i : I => coherenceDegree (hD i))) :=
  Ordinal.bddAbove_of_small

/-- Literal products carry exactly the coordinatewise order. -/
theorem product_le_iff {I : Type u} (D : I → Type u)
    [∀ i : I, PartialOrder (D i)] (x y : ∀ i : I, D i) :
    x ≤ y ↔ ∀ i : I, x i ≤ y i := Iff.rfl

/-- Scott-continuous retract monotonicity over all separable Scott domains. -/
def ScottSplitMonotonicityStatement : Prop :=
  ∀ (D E : Type u) [PartialOrder D] [PartialOrder E]
    (hD : IsScottDomain D) (hE : IsScottDomain E),
    (CompactElements D).Countable → (CompactElements E).Countable →
    HasScottSplit D E → coherenceDegree hD ≤ coherenceDegree hE

/-- Every nonempty finite/countable product, with its literal coordinate order.
Both domain closure and separability are output obligations, not caller inputs.
-/
def CountableProductDegreeStatement : Prop :=
  ∀ (I : Type u) [Countable I] [Nonempty I]
    (D : I → Type u) [∀ i : I, PartialOrder (D i)]
    (hD : ∀ i : I, IsScottDomain (D i)),
    (∀ i : I, (CompactElements (D i)).Countable) →
    ∃ hProduct : IsScottDomain (∀ i : I, D i),
      (CompactElements (∀ i : I, D i)).Countable ∧
      coherenceDegree hProduct = ⨆ i : I, coherenceDegree (hD i)

/-- Nonempty-source, pointwise Scott function-space degree.
The output must establish the literal function subtype is separable Scott.
-/
def PointwiseFunctionDegreeStatement : Prop :=
  ∀ (D E : Type u) [PartialOrder D] [PartialOrder E] [Nonempty D]
    (_hD : IsScottDomain D) (hE : IsScottDomain E),
    (CompactElements D).Countable → (CompactElements E).Countable →
    ∃ hFunctions : IsScottDomain (PointwiseScottSpace D E),
      (CompactElements (PointwiseScottSpace D E)).Countable ∧
      coherenceDegree hFunctions = coherenceDegree hE

/-- Proper source trees over every ambient-universe alphabet; no branching bound.
The degree is in Ordinal(u+1), so the actual source rank+1 is explicitly lifted.
-/
def WellFoundedTreeDegreeStatement : Prop :=
  ∀ (Index : Type u) (T : RootedPrefixTree Index), T.IsProper →
    ∀ hT : T.IsWellFounded,
      ∃ hDomain : IsScottDomain (TreeDomain T),
        coherenceDegree hDomain = Ordinal.lift.{u+1} (T.treeRank hT + 1)

/-- Only an actual infinite branch is assumed; no finite-branching surrogate. -/
def InfiniteBranchTreeDegreeStatement : Prop :=
  ∀ (Index : Type u) (T : RootedPrefixTree Index), T.IsProper →
    T.HasInfiniteBranch →
      ∃ hDomain : IsScottDomain (TreeDomain T),
        coherenceDegree hDomain = firstUncountable.{u}

def ProperTreeDegreeStatement : Prop :=
  WellFoundedTreeDegreeStatement.{u} ∧ InfiniteBranchTreeDegreeStatement.{u}

/-- Both endpoints of the nonzero interval are included; degree one is excluded. -/
def AllowedRangeStatement : Prop :=
  ∀ (D : Type u) [PartialOrder D] (hD : IsScottDomain D),
    (CompactElements D).Countable →
      coherenceDegree hD = 0 ∨
        (2 : Ordinal.{u+1}) ≤ coherenceDegree hD ∧
          coherenceDegree hD ≤ firstUncountable.{u}

/-- Completeness concerns the original order and all subsets, including empty. -/
def DegreeZeroIffCompleteLatticeStatement : Prop :=
  ∀ (D : Type u) [PartialOrder D] (hD : IsScottDomain D),
    (CompactElements D).Countable →
      (coherenceDegree hD = 0 ↔ IsCompleteLatticeOrder D)

/-- Actual natural-number ordinal casts and the source mic-cardinality definition. -/
def FiniteDegreeIffCoherentStatement : Prop :=
  ∀ (D : Type u) [PartialOrder D] (hD : IsScottDomain D),
    (CompactElements D).Countable →
    ∀ (n : ℕ) (hn : 2 ≤ n),
      (coherenceDegree hD ≤ (n : Ordinal.{u+1}) ↔ IsNCoherent hD n hn)

/-- Exactly the seven BPS clauses, with the two tree cases grouped as in item4. -/
def BPSStatement : Prop :=
  ScottSplitMonotonicityStatement.{u} ∧ CountableProductDegreeStatement.{u} ∧
    PointwiseFunctionDegreeStatement.{u} ∧ ProperTreeDegreeStatement.{u} ∧
    AllowedRangeStatement.{u} ∧ DegreeZeroIffCompleteLatticeStatement.{u} ∧
    FiniteDegreeIffCoherentStatement.{u}

/-- Equality causality on the same actual tree-node carrier, used only for events. -/
abbrev equalityOrder (A : Type u) : PartialOrder A where
  le := Eq
  le_refl _ := rfl
  le_trans _ _ _ := Eq.trans
  le_antisymm _ _ h _ := h

/-- Literal source predicate: arbitrary node subsets avoiding finite complete branches. -/
def AvoidsFiniteCompleteBranches {Index : Type u} (T : RootedPrefixTree Index)
    (X : Set T.Node) : Prop :=
  ∀ c : Set T.Node, T.IsFiniteCompleteBranch c → ¬ c ⊆ X

/-- A qualitative presentation of the actual carrier, not a replacement domain.
The event carrier is literally T.Node, causality is equality, Con consists
exactly of finite branch-free subsets, and the order isomorphism fixes sets.
-/
def TreeQualitativePresentationStatement : Prop :=
  ∀ (Index : Type u) (T : RootedPrefixTree Index), T.IsProper →
    letI : PartialOrder T.Node := equalityOrder T.Node
    ∃ E : DIDomainClassification.EventStructures.FinitaryPrimeEventStructure T.Node,
      DIDomainClassification.EventStructures.IsQualitativePresentation E ∧
      E.Con = {F : Set T.Node | F.Finite ∧ AvoidsFiniteCompleteBranches T F} ∧
      ∃ e : TreeDomain T ≃o DIDomainClassification.EventStructures.Configuration E,
        ∀ X : TreeDomain T, (e X).val = X.val

/-- Source prequel's actual countably based dI law, with no WF hypothesis. -/
def TreeCountablyBasedDIDomainStatement : Prop :=
  ∀ (Index : Type u) (T : RootedPrefixTree Index), T.IsProper →
    IsCountablyBasedDIDomain (TreeDomain T)

/-- Both directions of the compact=finite assertion for all actual domain points. -/
def TreeCompactIffFiniteStatement : Prop :=
  ∀ (Index : Type u) (T : RootedPrefixTree Index), T.IsProper →
    ∀ X : TreeDomain T, IsCompactElement X ↔ X.val.Finite

/-- Separate graph node p:tree-domain-construction, not a BPS input axiom. -/
def TreeDomainConstructionStatement : Prop :=
  TreeQualitativePresentationStatement.{u} ∧
    TreeCountablyBasedDIDomainStatement.{u} ∧ TreeCompactIffFiniteStatement.{u}

end DIDomainClassification.Section02.BPS

namespace DIDomainClassification.Section02

/-- Public candidate for source Theorem2.6 thm:bps; no proof supplied. -/
def BPSStatement : Prop := BPS.BPSStatement.{u}

/-- Public candidate for the exact unnumbered tree-domain construction node. -/
def TreeDomainConstructionStatement : Prop := BPS.TreeDomainConstructionStatement.{u}

end DIDomainClassification.Section02
