import DIDomainClassification.Section02.BPSStatement
import DIDomainClassification.Support.ProductDegree

/-! The exact nonempty countable-product clause of BPS. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section02.BPSProof

open Preliminaries CoherenceDegree BPSProductDegree

theorem countableProductDegree : BPS.CountableProductDegreeStatement.{u} := by
  intro I _ _ D _ hD hK
  exact ⟨productScottDomain hD, product_compactSet_countable hD hK,
    product_coherenceDegree_eq hD⟩

end DIDomainClassification.Section02.BPSProof
