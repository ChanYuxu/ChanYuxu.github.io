import DIDomainClassification.Section02.BPSStatement
import DIDomainClassification.Support.ForbiddenFiniteDomains
import DIDomainClassification.Support.TreeRankLowerBounds

/-!
# The branch-forbidden tree domain

The actual tree-node subsets, ordered by inclusion, form a countably based
dI-domain. Its qualitative event presentation uses equality causality on the
same node carrier and forbids exactly the finite complete branches. Compact
elements are precisely the finite subsets that avoid those branches.

This proves the manuscript's unnumbered construction at lines 434--441;
it does not assert the separate BPS coherence-degree formulas.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.Section02.TreeDomainConstruction

open DIDomainClassification.Trees
open DIDomainClassification.Preliminaries

variable {Index : Type u} (T : RootedPrefixTree Index)

/-- Exactly the finite complete branches of the given prefix tree. -/
def forbiddenBranches : Set (Set T.Node) := {c | T.IsFiniteCompleteBranch c}

/-- Properness excludes singleton complete branches; no branching bound is used. -/
theorem admissible (hp : T.IsProper) :
    ForbiddenFiniteDomains.Admissible (forbiddenBranches T) := by
  letI : PartialOrder T.Node := CoherenceDegree.prefixNodeOrder T
  refine ⟨fun c hc => hc.finite T, fun c hc => ⟨T.root, hc.root_mem T⟩, ?_⟩
  intro a c hc hsub
  have hroot : T.root = a := Set.mem_singleton_iff.mp (hsub (hc.root_mem T))
  rcases hc with ⟨v, hv, rfl⟩
  have hvself : v ∈ T.pathTo v := (T.mem_pathTo v v).mpr le_rfl
  have hva : v = a := Set.mem_singleton_iff.mp (hsub hvself)
  have hvr : v = T.root := hva.trans hroot.symm
  exact T.root_not_leaf_of_proper hp (hvr ▸ hv)

theorem qualitativePresentation (hp : T.IsProper) :
    letI : PartialOrder T.Node := BPS.equalityOrder T.Node
    ∃ E : EventStructures.FinitaryPrimeEventStructure T.Node,
      EventStructures.IsQualitativePresentation E ∧
      E.Con = {F : Set T.Node | F.Finite ∧ BPS.AvoidsFiniteCompleteBranches T F} ∧
      ∃ e : TreeDomain T ≃o EventStructures.Configuration E,
        ∀ X : TreeDomain T, (e X).val = X.val := by
  letI : PartialOrder T.Node := BPS.equalityOrder T.Node
  let H := forbiddenBranches T
  have hH : ForbiddenFiniteDomains.Admissible H := admissible T hp
  refine ⟨ForbiddenFiniteDomains.eventStructure H hH,
    ForbiddenFiniteDomains.isQualitativePresentation H hH, rfl,
    (ForbiddenFiniteDomains.configurationOrderIso H hH).symm, ?_⟩
  intro X
  rfl

theorem countablyBasedDIDomain (hp : T.IsProper) :
    IsCountablyBasedDIDomain (TreeDomain T) :=
  ForbiddenFiniteDomains.isCountablyBasedDIDomain
    (forbiddenBranches T) (admissible T hp)

theorem compact_iff_finite (hp : T.IsProper) (X : TreeDomain T) :
    IsCompactElement X ↔ X.val.Finite :=
  ForbiddenFiniteDomains.compact_iff_finite
    (forbiddenBranches T) (admissible T hp) X

end DIDomainClassification.Section02.TreeDomainConstruction

namespace DIDomainClassification.Section02

/-- The source construction, including the same-carrier qualitative presentation. -/
theorem treeDomainConstruction : TreeDomainConstructionStatement.{u} :=
  ⟨fun _ T hp => TreeDomainConstruction.qualitativePresentation T hp,
    fun _ T hp => TreeDomainConstruction.countablyBasedDIDomain T hp,
    fun _ T hp X => TreeDomainConstruction.compact_iff_finite T hp X⟩

end DIDomainClassification.Section02
