import DIDomainClassification.Support.PointwiseFunctionDegree

/-! The pointwise all-Scott clause of the exact BPS interface. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.Section02.BPSProof

open Preliminaries CoherenceDegree PointwiseFunctionSupport

theorem pointwiseFunctionDegree : BPS.PointwiseFunctionDegreeStatement.{u} := by
  intro D E _ _ _ hD hE hKD hKE
  exact ⟨space_isScottDomain hD hE,
    space_compactSet_countable hD hE hKD hKE,
    pointwise_coherenceDegree_eq hD hE⟩

end DIDomainClassification.Section02.BPSProof
