import DIDomainClassification.Section02.StableFunctionSpaces

/-! The source implication at manuscript.tex:214--218, as an unproved Prop. -/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.Section02

def StablePointwiseStatement : Prop :=
  ∀ (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (f g : StableHom D E), f ≤ g → ∀ x : D, f x ≤ g x

end DIDomainClassification.Section02
