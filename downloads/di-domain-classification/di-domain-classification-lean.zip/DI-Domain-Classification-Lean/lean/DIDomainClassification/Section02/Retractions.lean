import DIDomainClassification.Section02.StableFunctionSpaces

/-!
# Stable and Scott-continuous retractions

Definition 2.3, manuscript.tex lines 226--236. Both relations require a split
identity on the smaller domain. Neither relation adds a comparison between
the other composite and the identity, or preservation of the least point.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification

def HasStableRetraction (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) : Prop :=
  ∃ (s : StableHom D E) (r : StableHom E D),
    Function.LeftInverse (r : E → D) (s : D → E)

def HasScottRetraction (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) : Prop :=
  ∃ (s : D → E) (r : E → D),
    ScottContinuous s ∧ ScottContinuous r ∧ Function.LeftInverse r s

end DIDomainClassification
