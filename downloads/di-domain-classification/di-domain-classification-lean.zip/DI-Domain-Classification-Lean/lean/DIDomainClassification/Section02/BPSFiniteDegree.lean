import DIDomainClassification.Support.DegreeZeroCompleteness

/-! The two exact finite and zero degree clauses of the BPS interface. -/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Section02.BPSProof

open Preliminaries CoherenceDegree

theorem degreeZeroIffCompleteLattice : BPS.DegreeZeroIffCompleteLatticeStatement.{u} := by
  intro D _ hD _hK
  exact degree_zero_iff_complete_lattice_order hD

theorem finiteDegreeIffCoherent : BPS.FiniteDegreeIffCoherentStatement.{u} := by
  intro D _ hD _hK n hn
  exact finite_degree_iff_nCoherent hD n hn

end DIDomainClassification.Section02.BPSProof
