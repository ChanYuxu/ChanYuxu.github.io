import DIDomainClassification.Section02.BPSStatement
import DIDomainClassification.Support.CoherenceDegreeBounds
import DIDomainClassification.Support.TreeRankLowerBounds

/-! Proved clauses and directions of the actual BPS statement; not all seven. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.Section02.BPSProof

open Preliminaries CoherenceDegree

theorem scottSplitMonotonicity : BPS.ScottSplitMonotonicityStatement.{u} := by
  intro D E _ _ hD hE _hKD _hKE hspl
  obtain ⟨s, r, hs, hr, hleft⟩ := hspl
  exact coherenceDegree_mono_of_scott_split hD hE hs hr hleft

theorem allowedRange : BPS.AllowedRangeStatement.{u} := by
  intro D _ hD _hK
  rcases coherenceDegree_eq_zero_or_two_le hD with hz | htwo
  · exact Or.inl hz
  · exact Or.inr ⟨htwo, coherenceDegree_le_firstUncountable hD⟩

theorem degree_zero_of_complete {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (hComplete : BPS.IsCompleteLatticeOrder D) :
    coherenceDegree hD = 0 := by
  apply coherenceDegree_eq_zero_of_no_trees hD
  rintro ⟨M⟩
  obtain ⟨c, hc, _hroot⟩ := M.micTree.proper.2 M.micTree.tree.root
  have hmic := M.micTree.isMicTree.finiteBranch_mic hc
  obtain ⟨s, hs⟩ := (hComplete (labelImage M.micTree.tree M.micTree.label c)).1
  exact hmic.2.1 ⟨s, hs.1⟩

end DIDomainClassification.Section02.BPSProof
