import DIDomainClassification.Section01.OrdinalCuts
import DIDomainClassification.Section02.Comb
import DIDomainClassification.Section02.TreeDomain
import DIDomainClassification.Support.FiniteOrderDomains
import Mathlib.Order.ULift

/-! UNPROVED source degree realizability paragraph manuscript.tex478--484.
Both the full allowed range and ALL printed constructions are exposed. The
chosen trees, cofinal sequence, factors and product certificates are OUTPUTS.
No caller supplies a degree/rank realization or closure assumption. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02.DegreeRealizationModels

open Preliminaries CoherenceDegree Trees Subcategories

abbrev firstUncountable : Ordinal.{u+1} := (Order.succ Cardinal.aleph0.{u+1}).ord

def IsAllowedDegree (α : Ordinal.{u+1}) : Prop :=
  α = 0 ∨ (2 ≤ α ∧ α ≤ firstUncountable.{u})

/-- Only a universe lift of the LITERAL forbidden-subset domain of the source
comb. The actual order is inherited from that carrier, not replaced. -/
abbrev CombCarrier : Type u := ULift.{u} (TreeDomain (Comb.tree []))

def combOrderIso : CombCarrier.{u} ≃o TreeDomain (Comb.tree []) where
  toFun x := x.down
  invFun x := ⟨x⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

theorem combOrderIso_apply (x : CombCarrier.{u}) : combOrderIso x = x.down := rfl

end DIDomainClassification.Section02.DegreeRealizationModels

namespace DIDomainClassification.Section02

open Preliminaries CoherenceDegree Trees Subcategories DegreeRealizationModels

def DegreeAllValuesStatement : Prop :=
  ∀ α : Ordinal.{u+1}, IsAllowedDegree α →
    ∃ D : CountablyBasedDIDomain.{u}, objectDegree D = α

def DegreeZeroRealizationStatement : Prop :=
  objectDegree FiniteOrderDomains.twoObject.{u} = 0

def DegreeSuccessorRealizationStatement : Prop :=
  ∀ γ : Ordinal.{u+1}, γ.card ≤ Cardinal.aleph0 → 1 ≤ γ →
    ∃ (A : Type u) (T : RootedPrefixTree A), T.IsProper ∧
      ∃ (hT : T.IsWellFounded) (hD : IsCountablyBasedDIDomain (TreeDomain T)),
        Ordinal.lift.{u+1} (T.treeRank hT) = γ ∧
          coherenceDegree hD.1.toIsScottDomain = γ + 1

def DegreeLimitRealizationStatement : Prop :=
  ∀ limitOrdinal : Ordinal.{u+1}, 0 < limitOrdinal →
    limitOrdinal < firstUncountable.{u} → Order.IsSuccLimit limitOrdinal →
    ∃ (β : ℕ → Ordinal.{u+1}) (A : ℕ → Type u) (T : ∀ n, RootedPrefixTree (A n))
      (_hp : ∀ n, (T n).IsProper) (hT : ∀ n, (T n).IsWellFounded),
      (∀ n, β n = Ordinal.lift.{u+1} ((T n).treeRank (hT n) + 1)) ∧
      (∀ n, β n < limitOrdinal) ∧ (∀ δ < limitOrdinal, ∃ n, δ ≤ β n) ∧
      (∃ hD : ∀ n, IsCountablyBasedDIDomain (TreeDomain (T n)),
        (∀ n, coherenceDegree (hD n).1.toIsScottDomain = β n) ∧
        ∃ hProduct : IsCountablyBasedDIDomain (∀ n : ℕ, TreeDomain (T n)),
          coherenceDegree hProduct.1.toIsScottDomain = ⨆ n, β n) ∧
      (⨆ n, β n) = limitOrdinal

def DegreeCombRealizationStatement : Prop :=
  ∃ hD : IsCountablyBasedDIDomain CombCarrier.{u},
    coherenceDegree hD.1.toIsScottDomain = firstUncountable.{u}

def DegreeRealizabilityStatement : Prop :=
  DegreeAllValuesStatement.{u} ∧ DegreeZeroRealizationStatement.{u} ∧
    DegreeSuccessorRealizationStatement.{u} ∧ DegreeLimitRealizationStatement.{u} ∧
    DegreeCombRealizationStatement.{u}

end DIDomainClassification.Section02
