import DIDomainClassification.Section02.ScottOperations

/-!
# Stable maps and the two source function-space orders

Source: Definition 2.1 (`def:stable`), `manuscript.tex`, lines 198–212.
Frozen source SHA-256:
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

The source and target are arbitrary dI-domains, in independent universes.
Countability is not part of this definition. Their binary infima are derived
from the intrinsic Scott-domain axioms, retaining the original partial order;
no meet operation or function-space domain property is stored as an assumption.

The stable function space has the paper's stable order, not the pointwise
function order. The Scott-continuous function space separately inherits the
pointwise order. The order laws below only construct these ordered carriers.
They do not assert closure as dI-domains, cartesian closedness, preservation of
bottom, an embedding-projection inequality, or subsequent source theorems.

Status: provisional Step 3 source interface; independent review and acceptance
are pending.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification

noncomputable section

/-- An arbitrary intrinsic dI-domain, without a countability restriction.
The partial order and dI-domain property are the accepted source data.
-/
structure DIDomainObject where
  Carrier : Type u
  partialOrder : PartialOrder Carrier
  isDIDomain : @Preliminaries.IsDIDomain Carrier partialOrder

attribute [instance] DIDomainObject.partialOrder

instance : CoeSort DIDomainObject.{u} (Type u) := ⟨DIDomainObject.Carrier⟩

namespace DIDomainObject

/-- Bundle any source dI-domain without changing its carrier or order. -/
def ofType (D : Type u) [PartialOrder D] (hD : Preliminaries.IsDIDomain D) :
    DIDomainObject.{u} := ⟨D, inferInstance, hD⟩

/-- The binary meet is constructed from the intrinsic Scott-domain property. -/
instance instSemilatticeInf (D : DIDomainObject.{u}) : SemilatticeInf D :=
  D.isDIDomain.toIsScottDomain.semilatticeInf

/-- The derived meet structure retains the literal source partial order. -/
theorem semilatticeInf_order (D : DIDomainObject.{u}) :
    (instSemilatticeInf D).toPartialOrder = D.partialOrder := rfl

/-- The derived operation is the actual greatest lower bound of the source pair. -/
theorem inf_isGLB (D : DIDomainObject.{u}) (x y : D) :
    IsGLB ({x, y} : Set D) (x ⊓ y) :=
  D.isDIDomain.toIsScottDomain.inf_isGLB x y

end DIDomainObject

/-- Definition 2.1: Scott continuity and preservation of compatible binary meets.
No strictness or bottom-preservation condition is included.
-/
def IsStable (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) (f : D → E) : Prop :=
  ScottContinuous f ∧ ∀ x y : D, Compatible x y → f (x ⊓ y) = f x ⊓ f y

/-- The maps in the source stable function space, represented by the existing
generic stable-map structure specialized to the derived source infima.
-/
structure StableHom (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) where
  toStableMap : StableMap D E

instance {D : DIDomainObject.{u}} {E : DIDomainObject.{v}} :
    CoeFun (StableHom D E) (fun _ => D → E) :=
  ⟨fun f => f.toStableMap.toFun⟩

namespace StableHom

variable {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}

/-- Every represented stable map satisfies exactly the source predicate. -/
theorem isStable (f : StableHom D E) : IsStable D E f :=
  ⟨f.toStableMap.scottContinuous, f.toStableMap.map_inf_of_compatible⟩

/-- Every function satisfying the source predicate is represented. -/
def ofFunction (f : D → E) (hf : IsStable D E f) : StableHom D E :=
  ⟨⟨f, hf.1, hf.2⟩⟩

theorem ofFunction_apply (f : D → E) (hf : IsStable D E f) (x : D) :
    ofFunction f hf x = f x := rfl

/-- Equality of stable maps is equality of their actual underlying functions. -/
theorem ext {f g : StableHom D E} (h : ∀ x : D, f x = g x) : f = g := by
  rcases f with ⟨⟨f, hf, hfm⟩⟩
  rcases g with ⟨⟨g, hg, hgm⟩⟩
  have hfg : f = g := funext h
  cases hfg
  rfl

/-- The stable carrier represents all and only the source stable functions. -/
theorem representable_iff (f : D → E) :
    (∃ g : StableHom D E, (g : D → E) = f) ↔ IsStable D E f := by
  constructor
  · rintro ⟨g, rfl⟩
    exact isStable g
  · intro hf
    exact ⟨ofFunction f hf, rfl⟩

/-- The stable comparison from Definition 2.1, specialized without alteration. -/
def stableLE (f g : StableHom D E) : Prop :=
  StableLE f.toStableMap g.toStableMap

/-- The stable order is proved to be a partial order on the actual map carrier.
The diagonal substitutions below are used only for the order construction.
-/
instance instPartialOrder : PartialOrder (StableHom D E) where
  le := stableLE
  le_refl f := by
    intro x y hxy
    exact (inf_eq_right.mpr ((isStable f).1.monotone hxy)).symm
  le_trans f g h hfg hgh := by
    intro x y hxy
    have hfygy : f y ≤ g y := by
      calc
        f y = f y ⊓ g y := hfg y y le_rfl
        _ ≤ g y := inf_le_right
    calc
      f x = f y ⊓ g x := hfg x y hxy
      _ = f y ⊓ (g y ⊓ h x) := by rw [hgh x y hxy]
      _ = (f y ⊓ g y) ⊓ h x := (inf_assoc _ _ _).symm
      _ = f y ⊓ h x := by rw [inf_eq_left.mpr hfygy]
  le_antisymm f g hfg hgf := by
    apply ext
    intro x
    apply le_antisymm
    · calc
        f x = f x ⊓ g x := hfg x x le_rfl
        _ ≤ g x := inf_le_right
    · calc
        g x = g x ⊓ f x := hgf x x le_rfl
        _ ≤ f x := inf_le_right

/-- The actual order instance is the printed equation, not pointwise order. -/
theorem le_iff (f g : StableHom D E) :
    f ≤ g ↔ ∀ x y : D, x ≤ y → f x = f y ⊓ g x := Iff.rfl

end StableHom

/-- The source Scott-continuous function space, with its inherited pointwise order. -/
abbrev ScottHom (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) : Type (max u v) :=
  {f : D → E // ScottContinuous f}

namespace ScottHom

variable {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}

theorem scottContinuous (f : ScottHom D E) : ScottContinuous (f : D → E) :=
  f.property

/-- The actual Scott-function-space order is pointwise order. -/
theorem le_iff (f g : ScottHom D E) :
    f ≤ g ↔ ∀ x : D, f.val x ≤ g.val x := Iff.rfl

/-- The Scott carrier represents all and only Scott-continuous functions. -/
theorem representable_iff (f : D → E) :
    (∃ g : ScottHom D E, (g : D → E) = f) ↔ ScottContinuous f := by
  constructor
  · rintro ⟨g, rfl⟩
    exact g.property
  · intro hf
    exact ⟨⟨f, hf⟩, rfl⟩

end ScottHom

end

end DIDomainClassification
