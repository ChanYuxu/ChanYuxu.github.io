import DIDomainClassification.Support.BinaryForbiddenClique

/-!
Source manuscript.tex:403, first two sentences (frozen source SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56).
All configurations and graph cliques are arbitrary subsets of the same event
carrier. The actual order isomorphisms preserve the underlying event subsets.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02

open EventStructures BinaryCliqueModels BinaryCliqueSupport

theorem binaryForbiddenCliqueForward : BinaryForbiddenCliqueForwardStatement.{u} := by
  intro A _ E F hQual hF hBinary
  have h := configuration_iff_clique E F hQual hF hBinary
  exact ⟨h, configurationCliqueOrderIso E (compatibilityGraph E) h, fun _ => rfl⟩

theorem graphCliqueConstruction : GraphCliqueConstructionStatement.{u} := by
  intro A G
  letI : PartialOrder A := equalityOrder A
  refine ⟨graphEventStructure G, (fun _ _ => Iff.rfl), rfl,
    graph_forbidden_presentation G, graph_forbidden_binary G,
    graph_configuration_iff G, configurationCliqueOrderIso (graphEventStructure G) G
      (graph_configuration_iff G), fun _ => rfl⟩

theorem binaryForbiddenCliqueCorrespondence : BinaryForbiddenCliqueCorrespondenceStatement.{u} :=
  ⟨binaryForbiddenCliqueForward, graphCliqueConstruction⟩

end DIDomainClassification.Section02
