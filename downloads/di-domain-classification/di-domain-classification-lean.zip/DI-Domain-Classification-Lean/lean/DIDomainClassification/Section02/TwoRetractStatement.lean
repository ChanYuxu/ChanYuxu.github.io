import DIDomainClassification.Support.FiniteOrderDomains
import DIDomainClassification.Section02.Retractions

/-! Exact two-point retraction functions and unproved source specifications.
The lifted carrier is explicitly order-isomorphic to the literal Fin2 chain.
Source manuscript.tex273--296, SHA256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02.TwoRetractionModels

open FiniteOrderDomains

abbrev Core (D : DIDomainObject.{u}) := D
abbrev TwoCore := twoObject.{u}.toDIDomainObject

def sectionMap (D : DIDomainObject.{u}) (a : Core D)
    (t : TwoCarrier.{u}) : Core D :=
  if t = zero then (Core D).isDIDomain.toIsScottDomain.bottom else a

def predicate (D : DIDomainObject.{u}) (a x : Core D) : TwoCarrier.{u} := by
  classical
  exact if a ≤ x then one else zero

theorem section_zero (D : DIDomainObject.{u}) (a : Core D) :
    sectionMap D a zero = (Core D).isDIDomain.toIsScottDomain.bottom := if_pos rfl

theorem section_one (D : DIDomainObject.{u}) (a : Core D) :
    sectionMap D a one = a := if_neg (Ne.symm zero_ne_one)

theorem predicate_of_le (D : DIDomainObject.{u}) (a x : Core D) (h : a ≤ x) :
    predicate D a x = one := by
  classical
  exact if_pos h

theorem predicate_of_not_le (D : DIDomainObject.{u}) (a x : Core D) (h : ¬ a ≤ x) :
    predicate D a x = zero := by
  classical
  exact if_neg h

end DIDomainClassification.Section02.TwoRetractionModels

namespace DIDomainClassification.Section02

open Preliminaries TwoRetractionModels

/-- The printed functions for every permissible compact nonbottom choice. -/
def TwoRetractionConstructionStatement : Prop :=
  ∀ (D : DIDomainObject.{u}) (a : Core D),
    IsCompactElement a → a ≠ (Core D).isDIDomain.toIsScottDomain.bottom →
      IsStable TwoCore.{u} (Core D) (sectionMap D a) ∧
      IsStable (Core D) TwoCore.{u} (predicate D a) ∧
      Function.LeftInverse (predicate D a) (sectionMap D a)

/-- Existence of the printed compact choice and actual stable retraction. -/
def TwoRetractStatement : Prop :=
  ∀ (D : DIDomainObject.{u}), (∃ x y : Core D, x ≠ y) →
    (∃ a : Core D, IsCompactElement a ∧ a ≠ (Core D).isDIDomain.toIsScottDomain.bottom) ∧
      HasStableRetraction TwoCore.{u} (Core D)

end DIDomainClassification.Section02
