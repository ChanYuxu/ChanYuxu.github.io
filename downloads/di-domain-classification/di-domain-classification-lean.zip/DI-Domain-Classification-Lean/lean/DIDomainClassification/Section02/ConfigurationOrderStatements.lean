import DIDomainClassification.Section02.Configurations
import DIDomainClassification.Section02.DomainDefinitions
import Mathlib.Order.Bounds.Basic

/-!
# Source statements for configuration suprema and infima

The unnumbered claims at manuscript.tex:377--385 are kept at their full
scope: arbitrary finitary prime event structures, nonempty directed unions,
and all nonempty intersections. No countability or finiteness of the family
or its member configurations is assumed. These are unproved specifications.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

def ConfigurationDirectedUnionsStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (C : Set (Configuration E)),
    OrderCore.DirectedSet C →
      ∃ X : Configuration E,
        X.val = (⋃ Y ∈ C, Y.val) ∧ IsLUB C X

def ConfigurationNonemptyIntersectionsStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A)
    (C : Set (Configuration E)),
    C.Nonempty →
      ∃ X : Configuration E,
        X.val = (⋂ Y ∈ C, Y.val) ∧ IsGLB C X

end DIDomainClassification.EventStructures
