import DIDomainClassification.Section02.BasicFactStatements
import DIDomainClassification.Support.OrderCoreLemmas

/-!
# Compact predecessors in a dI-domain

Source: the unnumbered argument of Section 2.1 at manuscript line 196.
The compact-below set is contained in the finite entire ideal below k,
so its directed supremum belongs to that set and is compact.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Section02

theorem compactBelowCompact : CompactBelowCompactStatement.{u} := by
  intro D instD hD x k hxk hk
  exact OrderCore.compact_of_finite_principal_ideal
    hD.toIsScottDomain.algebraic (hD.finitePrincipalIdeals k hk) hxk

end DIDomainClassification.Section02
