import DIDomainClassification.Section02.Configurations
import DIDomainClassification.Section02.ScottDomains
import Mathlib.Order.Hom.Basic

/-!
# Source-facing statements for the prime-event representation theorem

Theorem 2.5 (`thm:events`), manuscript.tex:389--395. These declarations are
propositions awaiting proof. In particular the converse does not assume an
event representation of D, and no structure stores the theorem's conclusion.
The principal-ideal witness is required to be literally the given event's
downset. Countability is of the event carrier or the compact basis, never of
all points of a domain.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

open DIDomainClassification.Preliminaries

def ConfigurationDomainStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] [Countable A]
    (E : FinitaryPrimeEventStructure A),
    IsCountablyBasedDIDomain (Configuration E)

def PrimeEventRepresentationStatement : Prop :=
  ∀ (D : Type u) [PartialOrder D], IsCountablyBasedDIDomain D →
    ∃ (A : Type u) (order : PartialOrder A),
      letI : PartialOrder A := order
      ∃ (_countable : Countable A) (E : FinitaryPrimeEventStructure A),
        Nonempty (D ≃o Configuration E)

def ConfigurationCompactElementsStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] [Countable A]
    (E : FinitaryPrimeEventStructure A) (X : Configuration E),
    Preliminaries.IsCompactElement X ↔ X.val.Finite

def PrincipalConfigurationCompactStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] [Countable A]
    (E : FinitaryPrimeEventStructure A) (a : A),
    ∃ X : Configuration E,
      X.val = Set.Iic a ∧ Preliminaries.IsCompactElement X

end DIDomainClassification.EventStructures
