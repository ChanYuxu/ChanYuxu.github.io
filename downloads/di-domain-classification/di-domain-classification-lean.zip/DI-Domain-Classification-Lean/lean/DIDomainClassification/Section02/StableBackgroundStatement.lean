import DIDomainClassification.Section02.StableCategory
import Mathlib.CategoryTheory.Limits.Shapes.FiniteProducts
import Mathlib.CategoryTheory.Adjunction.Basic

/-!
# Exact Step 3 specification for Theorem 2.2

Source manuscript.tex:220--224, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

This file defines an unproved proposition and its output-construction types.
No inhabitant of the closure or cartesian-closed construction is supplied.
In the public statement the closure proofs and actual stable operations are
existential OUTPUTS, never hypotheses replacing function-space closure.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.Section02.StableBackground

open CategoryTheory CategoryTheory.Limits

abbrev Obj := CountablyBasedDIDomain.{u}
abbrev Core (D : Obj.{u}) := D.toDIDomainObject
abbrev Hom (D E : Obj.{u}) := StableHom (Core D) (Core E)

abbrev unitOrder : PartialOrder PUnit.{u + 1} := inferInstance
abbrev productOrder (D E : Obj.{u}) : PartialOrder (Core D × Core E) := inferInstance
abbrev exponentialOrder (D E : Obj.{u}) : PartialOrder (Hom D E) :=
  @StableHom.instPartialOrder (Core D) (Core E)

/-- Actual dI/compact-countability closure that the theorem must prove.
No full-carrier Countable condition is imposed. -/
structure DomainClosure : Prop where
  terminal : @Preliminaries.IsCountablyBasedDIDomain PUnit.{u + 1} unitOrder
  product (D E : Obj.{u}) :
    @Preliminaries.IsCountablyBasedDIDomain (Core D × Core E) (productOrder D E)
  exponential (D E : Obj.{u}) :
    @Preliminaries.IsCountablyBasedDIDomain (Hom D E) (exponentialOrder D E)

/-- Literal unit, pair and stable-ordered function carriers. These definitions
only package a candidate OUTPUT proof; they do not prove or assume closure in
the public proposition. -/
@[reducible] def terminalObject (C : DomainClosure.{u}) : Obj.{u} where
  toDIDomainObject :=
    { Carrier := PUnit.{u + 1}, partialOrder := unitOrder, isDIDomain := C.terminal.1 }
  countableCompacts := C.terminal.2

@[reducible] def productObject (C : DomainClosure.{u}) (D E : Obj.{u}) : Obj.{u} where
  toDIDomainObject :=
    { Carrier := Core D × Core E
      partialOrder := productOrder D E
      isDIDomain := (C.product D E).1 }
  countableCompacts := (C.product D E).2

@[reducible] def exponentialObject (C : DomainClosure.{u}) (D E : Obj.{u}) : Obj.{u} where
  toDIDomainObject :=
    { Carrier := Hom D E
      partialOrder := exponentialOrder D E
      isDIDomain := (C.exponential D E).1 }
  countableCompacts := (C.exponential D E).2

/-- Cartesian closedness of the actual ambient category: finite products and
right adjoints to its product functors, not of a replacement category. -/
def AmbientCartesianClosed : Prop :=
  ∃ h : HasFiniteProducts Obj.{u},
    letI : HasFiniteProducts Obj.{u} := h
    ∀ D : Obj.{u}, (prod.functor.obj D).IsLeftAdjoint

/-- Directedness and all LUB comparisons use the accepted stable order.
An actual LUB is requested explicitly, and every stable candidate is a
stable-order LUB exactly when its values are the coordinate LUBs. -/
def DirectedSupremaPointwise : Prop :=
  ∀ (D E : Obj.{u}) (A : Set (Hom D E)),
    OrderCore.DirectedSet A →
      (∃ f : Hom D E, IsLUB A f ∧
        ∀ x : Core D, IsLUB ((fun g : Hom D E => g x) '' A) (f x)) ∧
      ∀ f : Hom D E,
        IsLUB A f ↔ ∀ x : Core D, IsLUB ((fun g : Hom D E => g x) '' A) (f x)

/-- Compatibility is in the STABLE order, never the pointwise order.
No assertion about pointwise meets of incompatible maps is made. -/
def CompatibleMeetsPointwise : Prop :=
  ∀ (D E : Obj.{u}) (f g : Hom D E), Compatible f g →
    (∃ m : Hom D E, IsGLB ({f, g} : Set (Hom D E)) m ∧
      ∀ x : Core D, m x = f x ⊓ g x) ∧
    ∀ m : Hom D E,
      IsGLB ({f, g} : Set (Hom D E)) m ↔ ∀ x : Core D, m x = f x ⊓ g x

/-- Actual maps and universal properties of the ordinary products and stable
exponentials. This is output data requiring construction, not an input axiom.
Composition and currying are stable HIGHER-ORDER operators as well as giving
stable component functions. -/
structure CartesianClosedConstruction (C : DomainClosure.{u}) where
  cartesianClosed : AmbientCartesianClosed.{u}
  terminalArrow (D : Obj.{u}) : Hom D (terminalObject C)
  terminal_apply (D : Obj.{u}) (x : Core D) : terminalArrow D x = PUnit.unit
  terminal_unique (D : Obj.{u}) (f : Hom D (terminalObject C)) : f = terminalArrow D
  fst (D E : Obj.{u}) : Hom (productObject C D E) D
  snd (D E : Obj.{u}) : Hom (productObject C D E) E
  pair (X D E : Obj.{u}) : Hom X D → Hom X E → Hom X (productObject C D E)
  fst_apply (D E : Obj.{u}) (p : Core D × Core E) : fst D E p = p.1
  snd_apply (D E : Obj.{u}) (p : Core D × Core E) : snd D E p = p.2
  pair_apply (X D E : Obj.{u}) (f : Hom X D) (g : Hom X E) (x : Core X) :
    pair X D E f g x = (f x, g x)
  pair_fst (X D E : Obj.{u}) (f : Hom X D) (g : Hom X E) :
    StableHom.comp (fst D E) (pair X D E f g) = f
  pair_snd (X D E : Obj.{u}) (f : Hom X D) (g : Hom X E) :
    StableHom.comp (snd D E) (pair X D E f g) = g
  pair_unique (X D E : Obj.{u}) (h : Hom X (productObject C D E)) :
    pair X D E (StableHom.comp (fst D E) h) (StableHom.comp (snd D E) h) = h
  evaluation (D E : Obj.{u}) : Hom (productObject C (exponentialObject C D E) D) E
  evaluation_apply (D E : Obj.{u}) (p : Hom D E × Core D) : evaluation D E p = p.1 p.2
  composition (D E F : Obj.{u}) :
    Hom (productObject C (exponentialObject C E F) (exponentialObject C D E))
      (exponentialObject C D F)
  composition_apply (D E F : Obj.{u}) (p : Hom E F × Hom D E) (x : Core D) :
    composition D E F p x = p.1 (p.2 x)
  curry (X D E : Obj.{u}) :
    Hom (exponentialObject C (productObject C X D) E)
      (exponentialObject C X (exponentialObject C D E))
  curry_apply (X D E : Obj.{u}) (f : Hom (productObject C X D) E)
      (x : Core X) (y : Core D) : curry X D E f x y = f (x, y)
  uncurry (X D E : Obj.{u}) :
    Hom X (exponentialObject C D E) → Hom (productObject C X D) E
  uncurry_apply (X D E : Obj.{u}) (g : Hom X (exponentialObject C D E))
      (p : Core X × Core D) : uncurry X D E g p = g p.1 p.2
  uncurry_curry (X D E : Obj.{u}) (f : Hom (productObject C X D) E) :
    uncurry X D E (curry X D E f) = f
  curry_uncurry (X D E : Obj.{u}) (g : Hom X (exponentialObject C D E)) :
    curry X D E (uncurry X D E g) = g

/-- Exact unproved source-facing target. Every closure proof and all concrete
CCC operations have to be produced as part of proving this proposition. -/
def StableBackgroundStatement : Prop :=
  ∃ C : DomainClosure.{u}, Nonempty (CartesianClosedConstruction C) ∧
    DirectedSupremaPointwise.{u} ∧ CompatibleMeetsPointwise.{u}

end DIDomainClassification.Section02.StableBackground

namespace DIDomainClassification.Section02

/-- Public source-facing Theorem 2.2 target; deliberately unproved. -/
def StableBackgroundStatement : Prop :=
  StableBackground.StableBackgroundStatement.{u}

end DIDomainClassification.Section02
