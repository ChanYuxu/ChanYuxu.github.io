import DIDomainClassification.Section02.Trees
import DIDomainClassification.Section02.MicCoherence

/-!
# Mic trees with actual compact-element labels

Source: `manuscript.tex`, lines 414–422, unnumbered mic-tree definition.
Frozen source SHA-256:
`11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56`.

The accepted rooted-tree carrier already supplies countably many finite-depth
nodes. Properness is an explicit source premise. Labels lie in the actual
compact-element subtype of an arbitrary Scott domain, not in a proxy type or
an assumed countable domain. Injectivity is required on every whole maximal
prefix branch, including infinite branches. Only finite complete branches have
the minimally-inconsistent-image condition.

Every new use of a node order selects the accepted prefix-order instance
explicitly. No finite branching, global node-label injectivity, sibling-only
condition, well-foundedness, rank bound, degree bound, or classification result
is added. The current MicCoherence dependency remains a pending candidate;
this file is a syntax/interface candidate, not an accepted formalization.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.CoherenceDegree

open DIDomainClassification.Preliminaries
open DIDomainClassification.Trees

/-- Select the accepted node-prefix order, never an inherited list/subtype order. -/
abbrev prefixNodeOrder {Index : Type v} (T : RootedPrefixTree Index) :
    PartialOrder T.Node :=
  @RootedPrefixTree.instPartialOrderNode Index T

theorem prefixNodeOrder_le_iff {Index : Type v} (T : RootedPrefixTree Index)
    (x y : T.Node) :
    @LE.le T.Node (prefixNodeOrder T).toLE x y ↔ x.val <+: y.val := Iff.rfl

/-- The source image of a branch, regarded as an actual subset of the Scott domain. -/
def labelImage {D : Type u} [PartialOrder D] {Index : Type v}
    (T : RootedPrefixTree Index) (label : T.Node → ↥(CompactElements D))
    (c : Set T.Node) : Set D :=
  (fun x : T.Node => (label x : D)) '' c

theorem labelImage_mem_iff {D : Type u} [PartialOrder D] {Index : Type v}
    (T : RootedPrefixTree Index) (label : T.Node → ↥(CompactElements D))
    (c : Set T.Node) (d : D) :
    d ∈ labelImage T label c ↔ ∃ x ∈ c, (label x : D) = d := Iff.rfl

/-- Injectivity of compact-subtype labels is exactly injectivity of their D-values. -/
theorem label_injOn_iff_underlying {D : Type u} [PartialOrder D] {Index : Type v}
    (T : RootedPrefixTree Index) (label : T.Node → ↥(CompactElements D))
    (c : Set T.Node) :
    Set.InjOn label c ↔ Set.InjOn (fun x : T.Node => (label x : D)) c := by
  constructor
  · intro h x hx y hy hxy
    exact h hx hy (Subtype.ext hxy)
  · intro h x hx y hy hxy
    exact h hx hy (congrArg Subtype.val hxy)

/-- The source mic-tree condition on an explicit proper tree and compact labelling.
The maximal-chain relation below uses the explicitly selected prefix order.
-/
def IsMicTree {D : Type u} [PartialOrder D] (hD : IsScottDomain D)
    {Index : Type v} (T : RootedPrefixTree Index) (_proper : T.IsProper)
    (label : T.Node → ↥(CompactElements D)) : Prop :=
  letI : PartialOrder T.Node := prefixNodeOrder T
  (∀ c : Set T.Node, IsMaxChain (· ≤ ·) c → Set.InjOn label c) ∧
    ∀ c : Set T.Node, T.IsFiniteCompleteBranch c →
      IsMinimallyInconsistent hD (labelImage T label c)

/-- The explicitly selected maximal chains are precisely the accepted whole branches. -/
theorem isMicTree_iff {D : Type u} [PartialOrder D] (hD : IsScottDomain D)
    {Index : Type v} (T : RootedPrefixTree Index) (proper : T.IsProper)
    (label : T.Node → ↥(CompactElements D)) :
    IsMicTree hD T proper label ↔
      (∀ c : Set T.Node, T.IsBranch c → Set.InjOn label c) ∧
        ∀ c : Set T.Node, T.IsFiniteCompleteBranch c →
          IsMinimallyInconsistent hD (labelImage T label c) := Iff.rfl

namespace IsMicTree

variable {D : Type u} [PartialOrder D] {hD : IsScottDomain D}
  {Index : Type v} {T : RootedPrefixTree Index} {proper : T.IsProper}
  {label : T.Node → ↥(CompactElements D)}

/-- All maximal branches are quantified; no finiteness premise occurs here. -/
theorem branchInjective (h : IsMicTree hD T proper label)
    {c : Set T.Node} (hc : T.IsBranch c) : Set.InjOn label c :=
  ((isMicTree_iff hD T proper label).mp h).1 c hc

/-- A finite complete branch has its actual D-valued label image mic. -/
theorem finiteBranch_mic (h : IsMicTree hD T proper label)
    {c : Set T.Node} (hc : T.IsFiniteCompleteBranch c) :
    IsMinimallyInconsistent hD (labelImage T label c) :=
  ((isMicTree_iff hD T proper label).mp h).2 c hc

/-- The whole-branch condition also controls every infinite branch stream. -/
theorem infiniteBranch_injective (h : IsMicTree hD T proper label)
    (b : T.InfiniteBranch) : Function.Injective (fun n : ℕ => label (b.node n)) := by
  intro m n hmn
  have hi := h.branchInjective (b.range_isBranch T)
  exact b.injective T (hi ⟨m, rfl⟩ ⟨n, rfl⟩ hmn)

end IsMicTree

/-- Optional bundled presentation of exactly the source tree and its labelling.
Only source-defining data and conditions are fields; no degree/rank conclusion is stored.
-/
structure MicTree (D : Type u) [PartialOrder D] (hD : IsScottDomain D)
    (Index : Type v) where
  tree : RootedPrefixTree Index
  proper : tree.IsProper
  label : tree.Node → ↥(CompactElements D)
  isMicTree : IsMicTree hD tree proper label

end DIDomainClassification.CoherenceDegree
