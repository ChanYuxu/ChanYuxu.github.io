import DIDomainClassification.Section02.ScottDomains

/-!
# Section 2.1 source statements awaiting proof

These are proposition-valued specifications, not axioms and not theorem
proofs. The compact-predecessor claim is the unnumbered sentence of Section
2.1 at line 196. It retains the full dI-domain premise even though the
argument uses only algebraicity and finite principal ideals below compacts.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Section02

open DIDomainClassification.Preliminaries

/-- Source claim: every predecessor of a compact element of a dI-domain is
compact. No countability hypothesis is needed or added. -/
def CompactBelowCompactStatement : Prop :=
  ∀ (D : Type u) [PartialOrder D], IsDIDomain D →
    ∀ x k : D, x ≤ k →
      DIDomainClassification.Preliminaries.IsCompactElement k →
      DIDomainClassification.Preliminaries.IsCompactElement x

end DIDomainClassification.Section02
