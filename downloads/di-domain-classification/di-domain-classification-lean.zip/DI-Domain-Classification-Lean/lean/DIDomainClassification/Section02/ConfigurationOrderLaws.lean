import DIDomainClassification.Support.ConfigurationOrderBridges
import Mathlib.Data.Set.Finite.Lattice

/-!
# Directed unions and nonempty intersections of configurations

Source: manuscript.tex:377--385, p:configuration-order-laws, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

The witnesses below are the literal set union and intersection, carrying
newly proved configuration predicates. The exact inherited configuration
order is connected to inclusion by the accepted selected-order bridges.
For directed unions the finite-subset argument reuses the pinned Mathlib
DirectedOn.exists_mem_subset_of_finset_subset_biUnion; no representation or
configuration-domain theorem is assumed. The source states these laws
without a written proof. Independent proof review remains a separate step.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures

namespace Configuration

variable {A : Type u} [PartialOrder A] {E : FinitaryPrimeEventStructure A}

/-- Every finite subset of a nonempty directed union already lies in one
member. The directed relation is the actual selected configuration order. -/
theorem finite_subset_directed_union {C : Set (Configuration E)}
    (hC : OrderCore.DirectedSet C) {F : Set A} (hF : F.Finite)
    (hsub : F ⊆ ⋃ Y ∈ C, Y.val) : ∃ Y ∈ C, F ⊆ Y.val := by
  classical
  have hdir : DirectedOn (fun X Y : Configuration E => X.val ⊆ Y.val) C := by
    intro X hX Y hY
    obtain ⟨Z, hZ, hXZ, hYZ⟩ := hC.2 hX hY
    exact ⟨Z, hZ, (selectedPreorder_le_iff X Z).mp hXZ,
      (selectedPreorder_le_iff Y Z).mp hYZ⟩
  have hfinset : (hF.toFinset : Set A) ⊆ ⋃ Y ∈ C, Y.val := by
    simpa only [hF.coe_toFinset] using hsub
  obtain ⟨Y, hY, hFY⟩ :=
    DirectedOn.exists_mem_subset_of_finset_subset_biUnion hC.1 hdir hfinset
  exact ⟨Y, hY, by simpa only [hF.coe_toFinset] using hFY⟩

/-- The literal directed union satisfies both defining configuration clauses. -/
theorem directed_union_isConfiguration {C : Set (Configuration E)}
    (hC : OrderCore.DirectedSet C) : IsConfiguration E (⋃ Y ∈ C, Y.val) := by
  constructor
  · intro a b hab hb
    obtain ⟨Y, hb⟩ := Set.mem_iUnion.mp hb
    obtain ⟨hY, hb⟩ := Set.mem_iUnion.mp hb
    exact Set.mem_iUnion.mpr ⟨Y, Set.mem_iUnion.mpr
      ⟨hY, Y.property.1 hab hb⟩⟩
  · intro F hF hsub
    obtain ⟨Y, _hY, hFY⟩ := finite_subset_directed_union hC hF hsub
    exact Y.property.2 F hF hFY

/-- The literal nonempty intersection satisfies the configuration clauses.
One member suffices to verify consistency of each finite tested subset. -/
theorem nonempty_intersection_isConfiguration {C : Set (Configuration E)}
    (hC : C.Nonempty) : IsConfiguration E (⋂ Y ∈ C, Y.val) := by
  constructor
  · intro a b hab hb
    apply Set.mem_iInter.mpr
    intro Y
    apply Set.mem_iInter.mpr
    intro hY
    exact Y.property.1 hab (Set.mem_iInter.mp (Set.mem_iInter.mp hb Y) hY)
  · intro F hF hsub
    obtain ⟨Y, hY⟩ := hC
    apply Y.property.2 F hF
    intro a ha
    exact Set.mem_iInter.mp (Set.mem_iInter.mp (hsub ha) Y) hY

end Configuration

/-- Exact directed-union closure, underlying set formula and LUB law. -/
theorem configurationDirectedUnions : ConfigurationDirectedUnionsStatement.{u} := by
  intro A _ E C hC
  let X : Configuration E :=
    ⟨⋃ Y ∈ C, Y.val, Configuration.directed_union_isConfiguration hC⟩
  refine ⟨X, rfl, ?_⟩
  constructor
  · intro Y hY
    apply (Configuration.selectedPreorder_le_iff Y X).mpr
    intro a ha
    exact Set.mem_iUnion.mpr ⟨Y, Set.mem_iUnion.mpr ⟨hY, ha⟩⟩
  · intro Z hZ
    apply (Configuration.selectedPreorder_le_iff X Z).mpr
    intro a ha
    obtain ⟨Y, ha⟩ := Set.mem_iUnion.mp ha
    obtain ⟨hY, ha⟩ := Set.mem_iUnion.mp ha
    exact (Configuration.selectedPreorder_le_iff Y Z).mp (hZ hY) ha

/-- Exact nonempty-intersection closure, underlying set formula and GLB law. -/
theorem configurationNonemptyIntersections : ConfigurationNonemptyIntersectionsStatement.{u} := by
  intro A _ E C hC
  let X : Configuration E :=
    ⟨⋂ Y ∈ C, Y.val, Configuration.nonempty_intersection_isConfiguration hC⟩
  refine ⟨X, rfl, ?_⟩
  constructor
  · intro Y hY
    apply (Configuration.selectedPreorder_le_iff X Y).mpr
    intro a ha
    exact Set.mem_iInter.mp (Set.mem_iInter.mp ha Y) hY
  · intro Z hZ
    apply (Configuration.selectedPreorder_le_iff Z X).mpr
    intro a ha
    apply Set.mem_iInter.mpr
    intro Y
    apply Set.mem_iInter.mpr
    intro hY
    exact (Configuration.selectedPreorder_le_iff Z Y).mp (hZ hY) ha

end DIDomainClassification.EventStructures
