import DIDomainClassification.Section02.CoherenceCharacterizationStatement
import DIDomainClassification.Support.FiniteConsistency

/-!
# The finite-consistency characterization of n-coherence

This proves the exact separately frozen source equivalence. The underlying
Scott-domain and n≥2 conditions are retained; the internal supporting lemmas
do not assume the equivalence or any coherence-degree result.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.CoherenceDegree

theorem coherenceCharacterization : CoherenceCharacterizationStatement.{u} := by
  intro D instD hD n hn
  constructor
  · intro hcoherent X hX
    apply consistent_of_finite_subsets_consistent hD X
    intro F hF hFX
    by_contra hbad
    obtain ⟨M, hMF, hmic⟩ := exists_minimally_inconsistent_subset hD F hF hbad
    exact hmic.2.1 (hX M (hMF.trans hFX) hmic.1 (hcoherent M hmic))
  · intro hX M hmic
    by_contra hcard
    have hlt : n < M.ncard := Nat.lt_of_not_ge hcard
    apply hmic.2.1
    apply hX M
    intro F hFM _hF hsmall
    apply hmic.2.2 F
    refine ⟨hFM, ?_⟩
    intro hMF
    have heq : M = F := Set.Subset.antisymm hMF hFM
    have hle : M.ncard ≤ n := by simpa only [heq] using hsmall
    exact (not_le_of_gt hlt) hle

end DIDomainClassification.CoherenceDegree
