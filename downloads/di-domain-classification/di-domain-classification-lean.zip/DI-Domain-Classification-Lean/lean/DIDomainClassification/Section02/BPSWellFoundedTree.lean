import DIDomainClassification.Section02.BPSStatement
import DIDomainClassification.Support.WellFoundedTreeDegree

/-! Exact proper well-founded tree clause of BPS. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section02.BPSProof

theorem wellFoundedTreeDegree : BPS.WellFoundedTreeDegreeStatement.{u} := by
  intro Index T hp hT
  exact ⟨TreeDomainDegree.treeScottDomain T hp,
    TreeDomainDegree.wellFounded_treeDomain_degree_eq T hp hT⟩

end DIDomainClassification.Section02.BPSProof
