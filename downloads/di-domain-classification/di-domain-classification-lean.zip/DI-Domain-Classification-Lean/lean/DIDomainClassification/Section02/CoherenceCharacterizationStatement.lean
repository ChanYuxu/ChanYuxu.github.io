import DIDomainClassification.Section02.MicCoherence

/-!
# The source finite-consistency characterization

This is the equivalence stated after the mic-cardinality definition in
manuscript.tex, lines 407--412. Only the tested subset F is finite; X is
arbitrary. It is a proposition awaiting proof, not an input field of the
Scott-domain or n-coherence definitions.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.CoherenceDegree

open DIDomainClassification.Preliminaries

def CoherenceCharacterizationStatement : Prop :=
  ∀ (D : Type u) [PartialOrder D] (hD : IsScottDomain D)
    (n : ℕ) (hn : 2 ≤ n),
    IsNCoherent hD n hn ↔
      ∀ X : Set D,
        (∀ F : Set D, F ⊆ X → F.Finite → F.ncard ≤ n → Consistent F) →
        Consistent X

end DIDomainClassification.CoherenceDegree
