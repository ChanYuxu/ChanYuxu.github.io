import DIDomainClassification.Section02.Trees

/-!
# The branch-forbidden tree domain

Source definition: manuscript.tex:435--437 and1162, source SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
The members are arbitrary subsets of the actual nodes; they are NOT required
to be prefix closed. Only finite complete branches are forbidden. No condition
forbids infinite complete branches. Domain/compactness laws are not assumed.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Trees

/-- All node subsets containing no finite complete branch. -/
def TreeDomain {Index : Type u} (T : RootedPrefixTree Index) :=
  {X : Set T.Node // ∀ c : Set T.Node, T.IsFiniteCompleteBranch c → ¬ c ⊆ X}

instance {Index : Type u} (T : RootedPrefixTree Index) : PartialOrder (TreeDomain T) :=
  inferInstanceAs (PartialOrder {X : Set T.Node //
    ∀ c : Set T.Node, T.IsFiniteCompleteBranch c → ¬ c ⊆ X})

theorem treeDomain_le_iff {Index : Type u} (T : RootedPrefixTree Index)
    (X Y : TreeDomain T) : X ≤ Y ↔ X.val ⊆ Y.val := Iff.rfl

end DIDomainClassification.Trees
