import DIDomainClassification.Section02.Trees

/-!
# Branch completion carrier and order (source line 1131, first two sentences)

The generic construction adds one distinct point for every infinite branch of
an accepted rooted prefix tree. The source-facing `BranchCompletion` retains the
manuscript's proper-tree premise. This file does not assert compactness,
suprema, dcpo structure, algebraicity, countable baseness, or dI-domain laws.

Status: Step 3 authoring candidate, pending independent interface review.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.Trees

namespace RootedPrefixTree

variable {Label : Type u} (T : RootedPrefixTree Label)

/-- All infinite maximal branches as sets of finite nodes, without a cardinal bound. -/
def InfiniteMaximalBranch : Type u :=
  {c : Set T.Node // T.IsBranch c ∧ c.Infinite}

/-- A stream's range is its entire infinite maximal branch. -/
def infiniteBranchAsSet (b : T.InfiniteBranch) : T.InfiniteMaximalBranch :=
  ⟨Set.range b.node, b.range_isBranch T,
    Set.infinite_range_of_injective (b.injective T)⟩

theorem InfiniteBranch.range_injective {b c : T.InfiniteBranch}
    (h : Set.range b.node = Set.range c.node) : b = c := by
  apply InfiniteBranch.ext T
  intro n
  have hn : b.node n ∈ Set.range c.node := h ▸ Set.mem_range_self n
  obtain ⟨m, hm⟩ := hn
  have hmn := congrArg T.depth hm
  simp only [InfiniteBranch.depth_eq] at hmn
  subst m
  exact hm.symm

/-- No branch is omitted or represented twice by the stream coordinates. -/
noncomputable def infiniteBranchSetEquiv : T.InfiniteBranch ≃ T.InfiniteMaximalBranch :=
  Equiv.ofBijective (T.infiniteBranchAsSet) ⟨by
    intro b c h
    exact InfiniteBranch.range_injective T (congrArg Subtype.val h), by
    intro c
    choose f hfmem hfdepth using c.property.1.exists_depth T c.property.2
    let b : T.InfiniteBranch := {
      node := f
      root_eq := (T.depth_eq_zero_iff _).mp (hfdepth 0)
      child := fun n => by
        refine ⟨?_, by rw [hfdepth, hfdepth]⟩
        rcases c.property.1.1.total (hfmem n) (hfmem (n + 1)) with h | h
        · exact h
        · have hd := T.depth_mono h
          rw [hfdepth, hfdepth] at hd
          omega }
    refine ⟨b, Subtype.ext ?_⟩
    ext v
    constructor
    · rintro ⟨n, rfl⟩
      exact hfmem n
    · intro hv
      rcases c.property.1.1.total (hfmem (T.depth v)) hv with h | h
      · exact ⟨T.depth v, T.eq_of_le_of_depth_eq h (hfdepth _)⟩
      · exact ⟨T.depth v, (T.eq_of_le_of_depth_eq h (hfdepth _).symm).symm⟩⟩

@[simp] theorem infiniteBranchSetEquiv_coe (b : T.InfiniteBranch) :
    (T.infiniteBranchSetEquiv b).val = Set.range b.node := rfl

end RootedPrefixTree

/-- Generic completion carrier: finite source nodes plus all infinite branches. -/
def PrefixCompletion {Label : Type u} (T : RootedPrefixTree Label) : Type u :=
  T.Node ⊕ T.InfiniteBranch

namespace PrefixCompletion

variable {Label : Type u} (T : RootedPrefixTree Label)

/-- Inclusion of the original finite nodes. -/
def finite (v : T.Node) : PrefixCompletion T := Sum.inl v

/-- The additional point corresponding to a whole infinite branch. -/
def infinite (b : T.InfiniteBranch) : PrefixCompletion T := Sum.inr b

/-- Prefix order on finite nodes, branch membership for mixed comparisons. -/
def Le : PrefixCompletion T → PrefixCompletion T → Prop
  | .inl v, .inl w => v ≤ w
  | .inl v, .inr b => v ∈ Set.range b.node
  | .inr _, .inl _ => False
  | .inr b, .inr c => b = c

instance : PartialOrder (PrefixCompletion T) where
  le := Le T
  le_refl x := by
    rcases x with v | b
    · exact (show v ≤ v from le_rfl)
    · rfl
  le_trans x y z hxy hyz := by
    rcases x with v | b <;> rcases y with w | c <;> rcases z with t | d
    all_goals dsimp [Le] at hxy hyz ⊢
    · exact le_trans hxy hyz
    · exact (d.range_isBranch T).mem_of_le T hyz hxy
    · exact hyz ▸ hxy
    · exact hxy.trans hyz
  le_antisymm x y hxy hyx := by
    rcases x with v | b <;> rcases y with w | c
    all_goals dsimp [Le] at hxy hyx
    · exact congrArg Sum.inl (le_antisymm hxy hyx)
    · exact congrArg Sum.inr hxy

@[simp] theorem finite_le_finite_iff (v w : T.Node) :
    finite T v ≤ finite T w ↔ v ≤ w := Iff.rfl

@[simp] theorem finite_le_infinite_iff (v : T.Node) (b : T.InfiniteBranch) :
    finite T v ≤ infinite T b ↔ v ∈ Set.range b.node := Iff.rfl

@[simp] theorem not_infinite_le_finite (b : T.InfiniteBranch) (v : T.Node) :
    ¬infinite T b ≤ finite T v := id

@[simp] theorem infinite_le_infinite_iff (b c : T.InfiniteBranch) :
    infinite T b ≤ infinite T c ↔ b = c := Iff.rfl

theorem finite_injective : Function.Injective (finite T) := fun _ _ h => Sum.inl.inj h

theorem infinite_injective : Function.Injective (infinite T) := fun _ _ h => Sum.inr.inj h

@[simp] theorem finite_ne_infinite (v : T.Node) (b : T.InfiniteBranch) :
    finite T v ≠ infinite T b := by intro h; cases h

/-- The original tree order is represented by an actual order embedding. -/
def finiteOrderEmbedding : T.Node ↪o PrefixCompletion T where
  toFun := finite T
  inj' := finite_injective T
  map_rel_iff' := Iff.rfl

/-- Each new branch point is maximal in the entire completion. -/
theorem infinite_maximal (b : T.InfiniteBranch) :
    ∀ x : PrefixCompletion T, infinite T b ≤ x → x = infinite T b := by
  intro x h
  rcases x with v | c
  · exact False.elim h
  · exact congrArg Sum.inr h.symm

/-- The carrier contains only the stated two sorts of points. -/
theorem point_cases (x : PrefixCompletion T) :
    (∃ v : T.Node, x = finite T v) ∨ (∃ b : T.InfiniteBranch, x = infinite T b) := by
  rcases x with v | b
  · exact Or.inl ⟨v, rfl⟩
  · exact Or.inr ⟨b, rfl⟩

/-- Literal set-branch presentation of the same carrier. -/
noncomputable def branchSetRepresentation :
    PrefixCompletion T ≃ T.Node ⊕ T.InfiniteMaximalBranch :=
  Equiv.sumCongr (Equiv.refl T.Node) T.infiniteBranchSetEquiv

/-- The source order stated using actual infinite maximal branch sets. -/
def BranchSetLe : T.Node ⊕ T.InfiniteMaximalBranch →
    T.Node ⊕ T.InfiniteMaximalBranch → Prop
  | .inl v, .inl w => v ≤ w
  | .inl v, .inr b => v ∈ b.val
  | .inr _, .inl _ => False
  | .inr b, .inr c => b = c

/-- The carrier bijection preserves and reflects every order comparison. -/
theorem branchSetRepresentation_le_iff (x y : PrefixCompletion T) :
    BranchSetLe T (branchSetRepresentation T x) (branchSetRepresentation T y) ↔ x ≤ y := by
  rcases x with v | b <;> rcases y with w | c
  · rfl
  · rfl
  · rfl
  · exact T.infiniteBranchSetEquiv.injective.eq_iff

end PrefixCompletion

/-- The manuscript's `H_τ`, explicitly retaining its proper-tree premise. -/
abbrev BranchCompletion {Label : Type u} (T : RootedPrefixTree Label)
    (_proper : T.IsProper) : Type u := PrefixCompletion T

namespace BranchCompletion

variable {Label : Type u} (T : RootedPrefixTree Label) (proper : T.IsProper)

/-- Source-facing inclusion of finite nodes into `H_τ`. -/
abbrev finite (v : T.Node) : BranchCompletion T proper := PrefixCompletion.finite T v

/-- Source-facing new maximal point for each infinite branch. -/
abbrev infinite (b : T.InfiniteBranch) : BranchCompletion T proper := PrefixCompletion.infinite T b

theorem finite_order (v w : T.Node) :
    finite T proper v ≤ finite T proper w ↔ v.val <+: w.val := Iff.rfl

theorem finite_below_branch (v : T.Node) (b : T.InfiniteBranch) :
    finite T proper v ≤ infinite T proper b ↔ v ∈ Set.range b.node := Iff.rfl

theorem branch_points_maximal (b : T.InfiniteBranch) :
    ∀ x : BranchCompletion T proper, infinite T proper b ≤ x → x = infinite T proper b :=
  PrefixCompletion.infinite_maximal T b

end BranchCompletion

end DIDomainClassification.Trees
