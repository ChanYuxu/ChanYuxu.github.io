import DIDomainClassification.Section02.TwoExponentialStatement
import DIDomainClassification.Support.TwoExponentialOrderIso

/-! Source296--300: all three maps, native stable order, the pointwise
comparison, absence of a common stable upper bound, and the actual stable iso. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02

theorem twoExponential : TwoExponentialStatement.{u} := by
  refine ⟨TwoExponentialOrderIso.cubeCountablyBased, TwoExponentialOrderIso.classify,
    TwoExponentialOrderIso.zero_ne_identity, TwoExponentialOrderIso.zero_ne_oneMap,
    TwoExponentialOrderIso.identity_ne_one, TwoExponentialOrderIso.zeroMap_le,
    TwoExponentialOrderIso.identity_pointwise_one, TwoExponentialOrderIso.no_common_upper,
    ⟨TwoExponentialOrderIso.stableIso⟩⟩

end DIDomainClassification.Section02
