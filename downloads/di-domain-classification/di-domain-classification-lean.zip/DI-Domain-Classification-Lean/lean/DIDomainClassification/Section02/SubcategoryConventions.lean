import DIDomainClassification.Section02.StableCategory
import Mathlib.CategoryTheory.ObjectProperty.FullSubcategory
import Mathlib.CategoryTheory.ObjectProperty.ClosedUnderIsomorphisms
import Mathlib.CategoryTheory.Limits.Shapes.FiniteProducts
import Mathlib.CategoryTheory.Adjunction.Basic

/-!
# Full subcategories and intrinsic cartesian closedness

Provisional source-facing definitions for manuscript.tex:135, frozen source
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
This file does not assert that ambient products or exponentials lie in a
subcategory. Finite products are chosen inside the full subcategory itself,
and its own product functors must have right adjoints.

Reuse: actual Mathlib ObjectProperty.FullSubcategory, isomorphism closure,
HasFiniteProducts, prod.functor and Functor.IsLeftAdjoint at the fixed pin.
This is a definition interface, not a cartesian-closedness proof.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.Subcategories

open CategoryTheory
open CategoryTheory.Limits

/-- An arbitrary collection of the actual ambient countably based dI objects. -/
abbrev ObjectClass := ObjectProperty CountablyBasedDIDomain.{u}

/-- Fullness uses every ambient stable map between the selected objects. -/
abbrev FullStableSubcategory (P : ObjectClass.{u}) := P.FullSubcategory

/-- Closed under the actual ambient category isomorphisms. -/
def IsReplete (P : ObjectClass.{u}) : Prop := P.IsClosedUnderIsomorphisms

/-- Nontrivial means two different points in one included object. -/
def IsNontrivial (P : ObjectClass.{u}) : Prop :=
  ∃ D : CountablyBasedDIDomain.{u}, P D ∧ ∃ x y : D, x ≠ y

/-- Intrinsic finite products and right adjoints to intrinsic product functors.
No condition refers to ambient product or stable-function-space membership. -/
def IsIntrinsicallyCartesianClosed (P : ObjectClass.{u}) : Prop :=
  ∃ h : HasFiniteProducts (FullStableSubcategory P),
    letI : HasFiniteProducts (FullStableSubcategory P) := h
    ∀ D : FullStableSubcategory P, (prod.functor.obj D).IsLeftAdjoint

/-- Explicit full-Hom bridge to the previously accepted actual stable maps. -/
def homEquiv (P : ObjectClass.{u}) (D E : FullStableSubcategory P) :
    (D ⟶ E) ≃ StableHom D.obj.toDIDomainObject E.obj.toDIDomainObject where
  toFun f := CountablyBasedDIDomain.toStableHom f.hom
  invFun f := ObjectProperty.homMk f
  left_inv f := by cases f; rfl
  right_inv f := rfl

theorem homEquiv_apply (P : ObjectClass.{u}) (D E : FullStableSubcategory P)
    (f : D ⟶ E) : homEquiv P D E f = CountablyBasedDIDomain.toStableHom f.hom := rfl

theorem replete_iff (P : ObjectClass.{u}) :
    IsReplete P ↔ ∀ {D E : CountablyBasedDIDomain.{u}}, (D ≅ E) → P D → P E := by
  constructor
  · intro h D E e hD
    exact h.of_iso e hD
  · intro h
    exact ⟨h⟩

end DIDomainClassification.Subcategories
