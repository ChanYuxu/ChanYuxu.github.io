import DIDomainClassification.Section02.CountableRetractStatement
import DIDomainClassification.Support.OrderCoreLemmas

/-!
# Countable bases of Scott-continuous retracts

Source: Section 2.1, the unnumbered clause at manuscript line 264. The source
specification was independently reviewed before this proof was started.
The concrete basis is the retraction image of all ambient compact elements.
The target is not assumed or concluded algebraic; the split maps need not
preserve a least element or satisfy an embedding-projection inequality.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.Section02

theorem scottCountableRetract : ScottCountableRetractStatement.{u, v} := by
  intro D E instD instE hD s r hs hr hleft
  refine ⟨OrderCore.dcpo_of_continuous_split hD.1.1 hs hr hleft, ?_⟩
  refine ⟨r '' OrderCore.CompactSet D, hD.2.image r, ?_⟩
  exact OrderCore.basis_image_of_continuous_split
    (OrderCore.algebraic_compactBasis hD.1) hs hr hleft

end DIDomainClassification.Section02
