import DIDomainClassification.Section02.QualitativeDomains

/-! Source specification for the qualitative forbidden-family presentation,
manuscript.tex399--402. No family minimality or countability is added. -/

set_option autoImplicit false
universe u

namespace DIDomainClassification.Section02

open EventStructures

def QualitativeForbiddenRepresentationStatement : Prop :=
  ∀ (A : Type u) [PartialOrder A] (E : FinitaryPrimeEventStructure A),
    IsQualitativePresentation E →
      ∃ F : Set (Set A), IsForbiddenFamilyPresentation E F

end DIDomainClassification.Section02
