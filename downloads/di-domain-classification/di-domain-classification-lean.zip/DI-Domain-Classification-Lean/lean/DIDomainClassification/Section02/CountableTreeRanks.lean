import DIDomainClassification.Section02.CountableTreeRanksStatement
import DIDomainClassification.Support.CountableTreeRankRealization
import DIDomainClassification.Support.CountableRankCofinality

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02
open CountableTreeRankRealization

theorem countableTreeRanks : CountableTreeRanksStatement.{u} := by
  intro γ hγ hpos
  obtain ⟨α, hα, hlift⟩ := exists_countable_unlift γ hγ
  have hαpos : 0 < α := by
    by_contra h
    have hzero : α = 0 := le_antisymm (le_of_not_gt h) (zero_le _)
    have hγzero : γ = 0 := by simpa only [hzero, Ordinal.lift_zero] using hlift.symm
    exact (not_le_of_gt (zero_lt_one : (0 : Ordinal.{u+1}) < 1))
      (by simpa only [hγzero] using hpos)
  refine ⟨ULift.{u} ℕ, tree α hα, tree_proper_of_pos α hα hαpos,
    tree_wellFounded α hα, ?_⟩
  rw [tree_rank, hlift]

end DIDomainClassification.Section02
