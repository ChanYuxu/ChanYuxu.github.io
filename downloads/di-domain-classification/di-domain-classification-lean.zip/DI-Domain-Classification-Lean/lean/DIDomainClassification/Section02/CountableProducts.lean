import DIDomainClassification.Section02.CountableProductsStatement
import DIDomainClassification.Support.PiScottProperties
import DIDomainClassification.Support.PiCountability

/-!
# Products of countably based dI-domains

Source: manuscript.tex:196, p:countable-products, SHA-256
11bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.

This proves the independently accepted exact source proposition, including
both compactness implications and arbitrary countable dependent index types,
with the empty index retained. The source supplies no written proof here.
The Pi dcpo component adapts the existing book proof; the compactness,
algebraicity, finite-ideal, countability and intrinsic distributivity arguments
are supplied in the explicit Pi support modules. No source conclusion is an
input assumption. Independent review/handoff is separate from compilation.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.Section02

open Preliminaries

theorem countableProducts : CountableProductsStatement.{u, v} := by
  intro I _ D _ hD
  letI : (i : I) → OrderBot (D i) := fun i =>
    { bot := (hD i).1.toIsScottDomain.bottom
      bot_le := (hD i).1.toIsScottDomain.bottom_le }
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · exact PiTheory.pi_isDIDomain (fun i => (hD i).1)
  · exact PiTheory.pi_compact_countable (fun i => (hD i).2)
  · intro x
    exact PiTheory.compact_pi_iff x

end DIDomainClassification.Section02
