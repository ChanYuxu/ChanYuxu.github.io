import DIDomainClassification.Section02.SubcategoryConventions
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section03.StableFunctionModels

/-! Unproved source-facing target lem:inherited, manuscript.tex322--325.
Source SHA25611bc23ad558e77221aa7d9289b84d8a62875f5f5956bbc79d36588148daa8b56.
Intrinsic chosen products and ANY actual right adjoint of the intrinsic
product functor are compared to the literal ambient carriers by native
stable-category isomorphisms. Ambient membership is not a hypothesis. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.Section02
open CategoryTheory CategoryTheory.Limits Subcategories
open Section03.StableFunctionModels

def InheritedStatement : Prop :=
  ∀ P : ObjectClass.{u}, IsReplete P → IsNontrivial P →
    (∀ D E : CountablyBasedDIDomain.{u}, P E →
      HasStableRetraction (Core D) (Core E) → P D) →
    IsIntrinsicallyCartesianClosed P →
    ∀ h : HasFiniteProducts (FullStableSubcategory P),
      letI : HasFiniteProducts (FullStableSubcategory P) := h
      ∀ D E : FullStableSubcategory P,
        Nonempty ((prod D E).obj ≅
          StableBackground.productObject trueClosure D.obj E.obj) ∧
        ∀ R : FullStableSubcategory P ⥤ FullStableSubcategory P,
          ((prod.functor.obj D) ⊣ R) →
          Nonempty ((R.obj E).obj ≅ exponential D.obj E.obj)

end DIDomainClassification.Section02
