import Mathlib.Combinatorics.SimpleGraph.Basic
import Mathlib.Data.Set.Finite.Basic
import Mathlib.Data.Fintype.Pigeonhole

/-! An explicit two-color infinite graph theorem. Repeated infinite thinning
gives distinct vertices whose later edges depend only on the earlier vertex;
the finite-color infinite-fiber theorem then yields a homogeneous subsequence.
No Ramsey theorem is assumed as an axiom or a field of a certificate. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.InfiniteGraphHomogeneous

variable {A : Type u}

abbrev State (A : Type u) := {S : Set A // S.Infinite}

def pick (S : State A) : A := S.property.nonempty.choose

theorem pick_mem (S : State A) : pick S ∈ S.val := S.property.nonempty.choose_spec

def neighbors (G : SimpleGraph A) (S : State A) : Set A :=
  {a | a ∈ S.val ∧ G.Adj (pick S) a}

def nonNeighbors (G : SimpleGraph A) (S : State A) : Set A :=
  {a | a ∈ S.val ∧ a ≠ pick S ∧ ¬ G.Adj (pick S) a}

theorem nonNeighbors_infinite (G : SimpleGraph A) (S : State A)
    (h : ¬ (neighbors G S).Infinite) : (nonNeighbors G S).Infinite := by
  intro hFin
  have hN : (neighbors G S).Finite := Set.not_infinite.mp h
  apply S.property.diff (Set.finite_singleton (pick S))
  apply (hN.union hFin).subset
  intro a ha
  by_cases hadj : G.Adj (pick S) a
  · exact Or.inl ⟨ha.1, hadj⟩
  · exact Or.inr ⟨ha.1, fun heq => ha.2 (Set.mem_singleton_iff.mpr heq), hadj⟩

def next (G : SimpleGraph A) (S : State A) : State A := by
  classical
  exact if h : (neighbors G S).Infinite then ⟨neighbors G S, h⟩
    else ⟨nonNeighbors G S, nonNeighbors_infinite G S h⟩

def color (G : SimpleGraph A) (S : State A) : Bool := by
  classical
  exact if (neighbors G S).Infinite then true else false

theorem next_subset (G : SimpleGraph A) (S : State A) : (next G S).val ⊆ S.val := by
  classical
  by_cases h : (neighbors G S).Infinite
  · intro a ha
    simp only [next, dif_pos h] at ha
    exact ha.1
  · intro a ha
    simp only [next, dif_neg h] at ha
    exact ha.1

theorem next_ne (G : SimpleGraph A) (S : State A) {a : A}
    (ha : a ∈ (next G S).val) : a ≠ pick S := by
  classical
  by_cases h : (neighbors G S).Infinite
  · simp only [next, dif_pos h] at ha
    intro heq
    subst a
    exact G.irrefl ha.2
  · simp only [next, dif_neg h] at ha
    exact ha.2.1

theorem next_adj (G : SimpleGraph A) (S : State A) {a : A}
    (ha : a ∈ (next G S).val) : G.Adj (pick S) a ↔ color G S = true := by
  classical
  by_cases h : (neighbors G S).Infinite
  · simp only [next, dif_pos h] at ha
    constructor
    · intro _
      simp [color, h]
    · intro _
      exact ha.2
  · simp only [next, dif_neg h] at ha
    constructor
    · intro hAdj
      exact False.elim (ha.2.2 hAdj)
    · intro hEq
      simp [color, h] at hEq

variable [Infinite A]

def sequence (G : SimpleGraph A) (n : ℕ) : State A :=
  Nat.rec (⟨Set.univ, Set.infinite_univ⟩ : State A) (fun _ S => next G S) n

def vertex (G : SimpleGraph A) (n : ℕ) : A := pick (sequence G n)

theorem sequence_subset (G : SimpleGraph A) {n m : ℕ} (hnm : n ≤ m) :
    (sequence G m).val ⊆ (sequence G n).val := by
  induction hnm with
  | refl => exact Set.Subset.rfl
  | @step m _ ih => exact (next_subset G (sequence G m)).trans ih

theorem later_mem (G : SimpleGraph A) {n m : ℕ} (hnm : n < m) :
    vertex G m ∈ (next G (sequence G n)).val :=
  sequence_subset G (Nat.succ_le_of_lt hnm) (pick_mem (sequence G m))

theorem vertex_injective (G : SimpleGraph A) : Function.Injective (vertex G) := by
  intro n m hEq
  by_contra hne
  rcases lt_or_gt_of_ne hne with hlt | hlt
  · exact next_ne G (sequence G n) (later_mem G hlt) hEq.symm
  · exact next_ne G (sequence G m) (later_mem G hlt) hEq

theorem earlier_color (G : SimpleGraph A) {n m : ℕ} (hnm : n < m) :
    G.Adj (vertex G n) (vertex G m) ↔ color G (sequence G n) = true :=
  next_adj G (sequence G n) (later_mem G hnm)

theorem exists_homogeneous (G : SimpleGraph A) :
    ∃ e : ℕ ↪ A,
      (∀ n m : ℕ, n ≠ m → G.Adj (e n) (e m)) ∨
      (∀ n m : ℕ, ¬ G.Adj (e n) (e m)) := by
  classical
  obtain ⟨b, hb⟩ := Finite.exists_infinite_fiber (fun n => color G (sequence G n))
  letI : Infinite ((fun n => color G (sequence G n)) ⁻¹' {b}) := hb
  let j := Infinite.natEmbedding ((fun n => color G (sequence G n)) ⁻¹' {b})
  let i : ℕ → ℕ := fun n => (j n).val
  have hi : Function.Injective i := Subtype.val_injective.comp j.injective
  have hcolor (n : ℕ) : color G (sequence G (i n)) = b := (j n).property
  let e : ℕ ↪ A := ⟨fun n => vertex G (i n), (vertex_injective G).comp hi⟩
  refine ⟨e, ?_⟩
  cases b with
  | false =>
      right
      intro n m hAdj
      rcases lt_trichotomy (i n) (i m) with hlt | heq | hlt
      · have h := (earlier_color G hlt).mp hAdj
        rw [hcolor n] at h
        cases h
      · have hSame : e n = e m := congrArg (vertex G) heq
        rw [hSame] at hAdj
        exact G.irrefl hAdj
      · have h := (earlier_color G hlt).mp hAdj.symm
        rw [hcolor m] at h
        cases h
  | true =>
      left
      intro n m hne
      have hne' : i n ≠ i m := fun h => hne (hi h)
      rcases lt_or_gt_of_ne hne' with hlt | hlt
      · exact (earlier_color G hlt).mpr (hcolor n)
      · exact ((earlier_color G hlt).mpr (hcolor m)).symm

end DIDomainClassification.InfiniteGraphHomogeneous
