import DIDomainClassification.Support.MinimalInputTraces
import DIDomainClassification.Support.StableHomPointwiseSupport

/-!
Generic finite-trace approximation support. No source-facing paper wrapper,
CCC/function-space closure input or countability assumption is used. Source
proof acceptance is a separate obligation.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.FiniteTraceApproximations

open Preliminaries EventStructures
open MinimalInputTraces

variable {D : Type u} {A : Type v} [PartialOrder D] [PartialOrder A]
  {E : FinitaryPrimeEventStructure A} {f : D → Configuration E}

/-- Admissible finite subsets of the literal trace, not assumed approximating maps. -/
structure FiniteSupport (f : D → Configuration E) where
  carrier : Set (D × A)
  finite : carrier.Finite
  subtrace : carrier ⊆ trace f
  closed : IsPredecessorClosed f carrier

def values (F : Set (D × A)) (x : D) : Set A :=
  {a | ∃ k : D, (k, a) ∈ F ∧ k ≤ x}

omit [PartialOrder A] in
theorem values_mono (F : Set (D × A)) {x y : D} (hxy : x ≤ y) :
    values F x ⊆ values F y := by
  rintro a ⟨k, hk, hkx⟩
  exact ⟨k, hk, hkx.trans hxy⟩

theorem values_subset (hf : ScottContinuous f) {F : Set (D × A)}
    (hF : F ⊆ trace f) (x : D) : values F x ⊆ (f x).val := by
  rintro a ⟨k, hk, hkx⟩
  exact (Configuration.le_iff_subset _ _).mp (hf.monotone hkx) (hF hk).2.1

theorem values_isLowerSet (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    {F : Set (D × A)} (hF : F ⊆ trace f) (hclosed : IsPredecessorClosed f F)
    (x : D) : IsLowerSet (values F x) := by
  rintro b a hba ⟨k, hk, hkx⟩
  obtain ⟨l, hl, _hlunique⟩ := existsUnique_predecessorInput hD hf hm (hF hk) hba
  exact ⟨l, hclosed _ hk hl, hl.2.1.trans hkx⟩

theorem values_isConfiguration (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    {F : Set (D × A)} (hF : F ⊆ trace f) (hclosed : IsPredecessorClosed f F)
    (x : D) : IsConfiguration E (values F x) := by
  refine ⟨values_isLowerSet hD hf hm hF hclosed x, ?_⟩
  intro U hU hsub
  exact (f x).property.2 U hU (hsub.trans (values_subset hf hF x))

def approximation (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    (S : FiniteSupport f) (x : D) : Configuration E :=
  ⟨values S.carrier x, values_isConfiguration hD hf hm S.subtrace S.closed x⟩

theorem approximation_val (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    (S : FiniteSupport f) (x : D) :
    (approximation hD hf hm S x).val = values S.carrier x := rfl

theorem approximation_monotone (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f) :
    Monotone (approximation hD hf hm S) := by
  intro x y hxy
  exact (Configuration.le_iff_subset _ _).mpr (values_mono S.carrier hxy)

theorem approximation_scottContinuous (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f) :
    ScottContinuous (approximation hD hf hm S) := by
  intro B hne hdir s hs
  constructor
  · rintro _ ⟨x, hx, rfl⟩
    exact approximation_monotone hD hf hm S (hs.1 hx)
  · intro Z hZ
    apply (Configuration.le_iff_subset _ _).mpr
    rintro a ⟨k, hk, hks⟩
    obtain ⟨x, hx, hkx⟩ := (S.subtrace hk).1 ⟨hne, hdir⟩ hs hks
    exact (Configuration.le_iff_subset _ _).mp (hZ ⟨x, hx, rfl⟩) ⟨k, hk, hkx⟩

theorem approximation_directed_union (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f)
    (B : Set D) (hB : OrderCore.DirectedSet B) (s : D) (hs : IsLUB B s) :
    (approximation hD hf hm S s).val = ⋃ x ∈ B, (approximation hD hf hm S x).val := by
  ext a
  constructor
  · rintro ⟨k, hk, hks⟩
    obtain ⟨x, hx, hkx⟩ := (S.subtrace hk).1 hB hs hks
    exact Set.mem_iUnion.mpr ⟨x, Set.mem_iUnion.mpr ⟨hx, ⟨k, hk, hkx⟩⟩⟩
  · intro ha
    obtain ⟨x, ha⟩ := Set.mem_iUnion.mp ha
    obtain ⟨hx, k, hk, hkx⟩ := Set.mem_iUnion.mp ha
    exact ⟨k, hk, hkx.trans (hs.1 hx)⟩

theorem approximation_meet_val (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f)
    (x y : D) (hxy : Compatible x y) :
    (approximation hD hf hm S (hD.toIsScottDomain.inf x y)).val =
      (approximation hD hf hm S x).val ∩ (approximation hD hf hm S y).val := by
  ext a
  constructor
  · rintro ⟨k, hk, hkinf⟩
    exact ⟨⟨k, hk, hkinf.trans (hD.toIsScottDomain.inf_le_left x y)⟩,
      ⟨k, hk, hkinf.trans (hD.toIsScottDomain.inf_le_right x y)⟩⟩
  · rintro ⟨⟨k, hk, hkx⟩, ⟨l, hl, hly⟩⟩
    obtain ⟨z, hxz, hyz⟩ := hxy
    have hkl := trace_unique_below hD.toIsScottDomain hm
      (S.subtrace hk) (S.subtrace hl) (hkx.trans hxz) (hly.trans hyz)
    subst l
    exact ⟨k, hk, hD.toIsScottDomain.le_inf hkx hly⟩

theorem approximation_below_equation (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f)
    (x y : D) (hxy : x ≤ y) :
    (approximation hD hf hm S x).val =
      (approximation hD hf hm S y).val ∩ (f x).val := by
  ext a
  constructor
  · intro ha
    exact ⟨values_mono S.carrier hxy ha, values_subset hf S.subtrace x ha⟩
  · rintro ⟨⟨k, hk, hky⟩, hax⟩
    obtain ⟨l, hlx, hl⟩ := exists_trace_below hD hf hax
    have hkl := trace_unique_below hD.toIsScottDomain hm (S.subtrace hk) hl
      hky (hlx.trans hxy)
    exact ⟨k, hk, hkl ▸ hlx⟩

/-- Literal bundling of the given domain; no new carrier/order is chosen. -/
abbrev sourceObject (hD : IsDIDomain D) : DIDomainObject.{u} :=
  DIDomainObject.ofType D hD

abbrev configurationObject (E : FinitaryPrimeEventStructure A) : DIDomainObject.{v} :=
  DIDomainObject.ofType (Configuration E) (ConfigurationDomain.dIDomain E)

theorem source_inf_eq (hD : IsDIDomain D) (x y : sourceObject hD) :
    x ⊓ y = hD.toIsScottDomain.inf x y :=
  (DIDomainObject.inf_isGLB (sourceObject hD) x y).unique
    (hD.toIsScottDomain.inf_isGLB x y)

theorem target_inf_eq (X Y : configurationObject E) :
    X ⊓ Y = ConfigurationDomain.intersection E X Y :=
  (DIDomainObject.inf_isGLB (configurationObject E) X Y).unique
    (ConfigurationDomain.intersection_isGLB E X Y)

theorem target_inf_val (X Y : configurationObject E) :
    (X ⊓ Y).val = X.val ∩ Y.val := by
  rw [target_inf_eq]
  rfl

abbrev Hom (hD : IsDIDomain D) (E : FinitaryPrimeEventStructure A) :=
  StableHom (sourceObject hD) (configurationObject E)

def baseHom (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) : Hom hD E :=
  StableHom.ofFunction f ⟨hf, by
    intro x y hxy
    apply Subtype.ext
    rw [source_inf_eq, target_inf_val]
    exact compatible_meet_val hD.toIsScottDomain hm x y hxy⟩

def approximationHom (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f) : Hom hD E :=
  StableHom.ofFunction (approximation hD hf hm S)
    ⟨approximation_scottContinuous hD hf hm S, by
      intro x y hxy
      apply Subtype.ext
      rw [source_inf_eq, target_inf_val]
      exact approximation_meet_val hD hf hm S x y hxy⟩

theorem approximationHom_apply (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f) (x : D) :
    approximationHom hD hf hm S x = approximation hD hf hm S x := rfl

theorem hom_le_pointwise (hD : IsDIDomain D) {g h : Hom hD E} (hgh : g ≤ h)
    (x : D) : g x ≤ h x :=
  StableHomPointwiseSupport.stableLE_pointwise hgh x

theorem hom_le_of_pointwise_of_common_upper (hD : IsDIDomain D)
    {g h U : Hom hD E} (hgU : g ≤ U) (hhU : h ≤ U)
    (hgh : ∀ x : D, g x ≤ h x) : g ≤ h := by
  intro x y hxy
  apply le_antisymm
  · exact le_inf ((StableHom.isStable g).1.monotone hxy) (hgh x)
  · calc
      g y ⊓ h x ≤ g y ⊓ U x := inf_le_inf_left _ (hom_le_pointwise hD hhU x)
      _ = g x := (hgU x y hxy).symm

theorem approximationHom_le_base (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f) :
    approximationHom hD hf hm S ≤ baseHom hD hf hm := by
  intro x y hxy
  apply Subtype.ext
  rw [target_inf_val]
  exact approximation_below_equation hD hf hm S x y hxy

theorem approximationHom_mono (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S T : FiniteSupport f)
    (hST : S.carrier ⊆ T.carrier) :
    approximationHom hD hf hm S ≤ approximationHom hD hf hm T := by
  apply hom_le_of_pointwise_of_common_upper hD
    (approximationHom_le_base hD hf hm S) (approximationHom_le_base hD hf hm T)
  intro x
  apply (Configuration.le_iff_subset _ _).mpr
  rintro a ⟨k, hk, hkx⟩
  exact ⟨k, hST hk, hkx⟩

theorem approximation_order_equation (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S T : FiniteSupport f)
    (hST : S.carrier ⊆ T.carrier) (x y : D) (hxy : x ≤ y) :
    (approximation hD hf hm S x).val =
      (approximation hD hf hm S y).val ∩ (approximation hD hf hm T x).val := by
  have h := approximationHom_mono hD hf hm S T hST x y hxy
  exact (congrArg (fun X : configurationObject E => X.val) h).trans (target_inf_val _ _)

def emptySupport (f : D → Configuration E) : FiniteSupport f where
  carrier := ∅
  finite := Set.finite_empty
  subtrace := Set.empty_subset _
  closed := by intro p hp; cases hp

theorem approximation_empty_val (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (x : D) :
    (approximation hD hf hm (emptySupport f) x).val = ∅ := by
  ext a
  constructor
  · rintro ⟨k, hk, _⟩
    cases hk
  · intro ha
    cases ha

def unionSupport (S T : FiniteSupport f) : FiniteSupport f where
  carrier := S.carrier ∪ T.carrier
  finite := S.finite.union T.finite
  subtrace := by
    intro p hp
    exact hp.elim (fun hp => S.subtrace hp) (fun hp => T.subtrace hp)
  closed := by
    intro p hp q hq
    rcases hp with hp | hp
    · exact Or.inl (S.closed p hp hq)
    · exact Or.inr (T.closed p hp hq)

def causalSupport (hD : IsScottDomain D) (hm : PreservesCompatibleMeets hD f)
    (k : D) (a : A) : FiniteSupport f where
  carrier := predecessorSupport f k a
  finite := predecessorSupport_finite hD hm k a
  subtrace := predecessorSupport_subset_trace k a
  closed := predecessorSupport_closed k a

def approximants (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) : Set (Hom hD E) :=
  Set.range (approximationHom hD hf hm)

/-- Nonempty directedness in the actual stable Hom partial order, including empty support. -/
theorem approximants_directed (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) :
    OrderCore.DirectedSet (approximants hD hf hm) := by
  constructor
  · exact ⟨approximationHom hD hf hm (emptySupport f), ⟨emptySupport f, rfl⟩⟩
  · rintro _ ⟨S, rfl⟩ _ ⟨T, rfl⟩
    exact ⟨approximationHom hD hf hm (unionSupport S T), ⟨unionSupport S T, rfl⟩,
      approximationHom_mono hD hf hm S (unionSupport S T) Set.subset_union_left,
      approximationHom_mono hD hf hm T (unionSupport S T) Set.subset_union_right⟩

/-- Literal pointwise union over all admissible finite supports equals the given map. -/
theorem pointwise_union (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (x : D) :
    (f x).val = ⋃ S : FiniteSupport f, (approximationHom hD hf hm S x).val := by
  ext a
  constructor
  · intro ha
    obtain ⟨k, hkx, hk⟩ := exists_trace_below hD hf ha
    refine Set.mem_iUnion.mpr ⟨causalSupport hD.toIsScottDomain hm k a, ?_⟩
    exact ⟨k, self_mem_predecessorSupport hk, hkx⟩
  · intro ha
    obtain ⟨S, haS⟩ := Set.mem_iUnion.mp ha
    exact values_subset hf S.subtrace x haS

theorem approximants_values_isLUB (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (x : D) :
    IsLUB ((fun g : Hom hD E => g x) '' approximants hD hf hm) (f x) := by
  constructor
  · rintro _ ⟨_, ⟨S, rfl⟩, rfl⟩
    exact (Configuration.le_iff_subset _ _).mpr (values_subset hf S.subtrace x)
  · intro Z hZ
    apply (Configuration.le_iff_subset _ _).mpr
    intro a ha
    rw [pointwise_union hD hf hm x] at ha
    obtain ⟨S, haS⟩ := Set.mem_iUnion.mp ha
    exact (Configuration.le_iff_subset _ _).mp
      (hZ ⟨approximationHom hD hf hm S, ⟨S, rfl⟩, rfl⟩) haS

/-- LUB is proved in the actual stable order, using the donor's proved pointwise bridge. -/
theorem approximants_isLUB (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) :
    IsLUB (approximants hD hf hm) (baseHom hD hf hm) := by
  apply (StableHomPointwiseSupport.hom_isLUB_iff_values _
    (approximants_directed hD hf hm) (baseHom hD hf hm)).mpr
  exact approximants_values_isLUB hD hf hm

/-- Finitely many positive event tests can be witnessed in one directed member. -/
theorem directed_finite_event_tests (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : OrderCore.DirectedSet B) (F : Set (D × A)) (hF : F.Finite)
    (hTests : ∀ p ∈ F, ∃ g ∈ B, p.2 ∈ (g p.1).val) :
    ∃ g ∈ B, ∀ p ∈ F, p.2 ∈ (g p.1).val := by
  revert hTests
  induction F, hF using Set.Finite.induction_on with
  | empty =>
      intro _
      obtain ⟨g, hg⟩ := hB.1
      exact ⟨g, hg, by intro p hp; cases hp⟩
  | @insert p F hp hF ih =>
      intro hTests
      obtain ⟨g, hg, hgTests⟩ := ih (fun q hq => hTests q (Set.mem_insert_of_mem p hq))
      obtain ⟨h, hh, hpTest⟩ := hTests p (Set.mem_insert p F)
      obtain ⟨U, hU, hgU, hhU⟩ := hB.2 hg hh
      refine ⟨U, hU, ?_⟩
      intro q hq
      rcases Set.mem_insert_iff.mp hq with hqp | hq
      · subst q
        exact (Configuration.le_iff_subset _ _).mp (hom_le_pointwise hD hhU p.1) hpTest
      · exact (Configuration.le_iff_subset _ _).mp
          (hom_le_pointwise hD hgU q.1) (hgTests q hq)

/-- Actual compactness in StableHom's STABLE order, not the pointwise order.
No algebraicity/compactness/function-space closure conclusion is an input.
-/
theorem approximationHom_compact (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f) (S : FiniteSupport f) :
    IsCompactElement (approximationHom hD hf hm S) := by
  intro B s hB hs hApprox
  have hTests : ∀ p ∈ S.carrier, ∃ g ∈ B, p.2 ∈ (g p.1).val := by
    intro p hp
    have hpos : p.2 ∈ (approximationHom hD hf hm S p.1).val := ⟨p.1, hp, le_rfl⟩
    have hps : p.2 ∈ (s p.1).val :=
      (Configuration.le_iff_subset _ _).mp (hom_le_pointwise hD hApprox p.1) hpos
    have hValues : IsLUB ((fun g : Hom hD E => g p.1) '' B) (s p.1) :=
      (StableHomPointwiseSupport.hom_isLUB_iff_values B hB s).mp hs p.1
    have hValuesDirected : OrderCore.DirectedSet ((fun g : Hom hD E => g p.1) '' B) :=
      hB.image (fun g h hgh => hom_le_pointwise hD hgh p.1)
    obtain ⟨Y, ⟨g, hg, rfl⟩, hprincipal⟩ :=
      (principal_compact E p.2) hValuesDirected hValues
        ((principal_le_iff E p.2 (s p.1)).mpr hps)
    exact ⟨g, hg, (principal_le_iff E p.2 (g p.1)).mp hprincipal⟩
  obtain ⟨g, hg, hgTests⟩ :=
    directed_finite_event_tests hD B hB S.carrier S.finite hTests
  refine ⟨g, hg, ?_⟩
  apply hom_le_of_pointwise_of_common_upper hD hApprox (hs.1 hg)
  intro x
  apply (Configuration.le_iff_subset _ _).mpr
  rintro a ⟨k, hk, hkx⟩
  exact (Configuration.le_iff_subset _ _).mp ((StableHom.isStable g).1.monotone hkx)
    (hgTests (k, a) hk)

end DIDomainClassification.FiniteTraceApproximations
