import DIDomainClassification.Section04.TruncatedRetractionsStatement
import DIDomainClassification.Support.ForbiddenFiniteDomains
import DIDomainClassification.Support.FiniteOrderDomains

/-! Literal lifted proper-subset cubes and the actual nonempty-block maps.
The owner is a surjection (here modular reduction), not a coordinate projection.
All domain certificates and stability/splitting laws below are outputs. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FiniteCubeRetractions

open Preliminaries Section04 Section04.FiniteCategoryModels
open Section04.PartitionRetractionModels

def forbidden (n : ℕ) : Set (Set (Fin n)) := {Set.univ}

theorem forbidden_admissible (n : ℕ) (hn : 2 ≤ n) :
    ForbiddenFiniteDomains.Admissible (forbidden n) := by
  constructor
  · intro U _hU
    exact Set.toFinite U
  · intro U hU
    have hU : U = Set.univ := Set.mem_singleton_iff.mp hU
    subst U
    exact ⟨⟨0, by omega⟩, Set.mem_univ _⟩
  · intro a U hU hsub
    have hU : U = Set.univ := Set.mem_singleton_iff.mp hU
    subst U
    have hc := Set.ncard_le_ncard hsub
    simp only [Set.ncard_univ, Nat.card_fin, Set.ncard_singleton] at hc
    omega

def avoidanceOrderIso (n : ℕ) (hn : 2 ≤ n) :
    CubeCarrier.{u} n hn ≃o ForbiddenFiniteDomains.AvoidanceDomain (forbidden n) where
  toFun S := ⟨S.down.val, by
    intro U hU hsub
    have hU : U = Set.univ := Set.mem_singleton_iff.mp hU
    apply S.down.property
    apply Set.eq_univ_of_forall
    intro i
    exact (hU ▸ hsub) (Set.mem_univ i)⟩
  invFun X := ⟨⟨X.val, by
    intro heq
    exact X.property Set.univ (Set.mem_singleton _) (heq ▸ Set.Subset.rfl)⟩⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

theorem cubeCountablyBased (n : ℕ) (hn : 2 ≤ n) :
    IsCountablyBasedDIDomain (CubeCarrier.{u} n hn) :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff (avoidanceOrderIso n hn)).mpr
    (ForbiddenFiniteDomains.isCountablyBasedDIDomain (forbidden n) (forbidden_admissible n hn))

theorem cube_ext {n : ℕ} {hn : 2 ≤ n} {X Y : CubeCarrier.{u} n hn}
    (h : X.down.val = Y.down.val) : X = Y :=
  ULift.ext _ _ (Subtype.ext h)

instance cubeCore_finite (n : ℕ) (hn : 2 ≤ n)
    (h : IsDIDomain (CubeCarrier.{u} n hn)) : Finite (cubeCore n hn h) :=
  inferInstanceAs (Finite (CubeCarrier.{u} n hn))

/-- The intrinsic Scott meet on the actual source carrier is intersection. -/
theorem cube_inf_values (n : ℕ) (hn : 2 ≤ n)
    (h : IsDIDomain (CubeCarrier.{u} n hn)) (X Y : CubeCarrier.{u} n hn) :
    (h.toIsScottDomain.inf X Y).down.val = X.down.val ∩ Y.down.val := by
  let Z : CubeCarrier.{u} n hn := ⟨⟨X.down.val ∩ Y.down.val, by
    intro heq
    apply X.down.property
    apply Set.eq_univ_of_forall
    intro i
    have hmem : i ∈ X.down.val ∩ Y.down.val := by
      rw [heq]
      exact Set.mem_univ i
    exact hmem.1⟩⟩
  have hZ : IsGLB ({X, Y} : Set (CubeCarrier.{u} n hn)) Z := by
    constructor
    · intro W hW
      rcases Set.mem_insert_iff.mp hW with rfl | hW
      · exact Set.inter_subset_left
      · rw [Set.mem_singleton_iff.mp hW]
        exact Set.inter_subset_right
    · intro W hW
      exact Set.subset_inter (hW (by simp)) (hW (by simp))
  have heq := (h.toIsScottDomain.inf_isGLB X Y).unique hZ
  exact congrArg (fun W : CubeCarrier.{u} n hn => W.down.val) heq

def partition (k m : ℕ) (hk : 2 ≤ k) (hkm : k ≤ m) : BlockPartition k m where
  owner j := ⟨j.val % k, Nat.mod_lt _ (by omega)⟩
  onto i := by
    refine ⟨⟨i.val, lt_of_lt_of_le i.isLt hkm⟩, ?_⟩
    apply Fin.ext
    exact Nat.mod_eq_of_lt i.isLt

variable {k m : ℕ} {hk : 2 ≤ k} {hm : 2 ≤ m} (P : BlockPartition k m)

def sectionMap (S : CubeCarrier.{u} k hk) : CubeCarrier.{u} m hm :=
  ⟨⟨P.sectionValues S.down.val, by
    intro hall
    apply S.down.property
    apply Set.eq_univ_of_forall
    intro i
    obtain ⟨j, hj⟩ := P.onto i
    have hmem : j ∈ P.sectionValues S.down.val := hall ▸ Set.mem_univ j
    change P.owner j ∈ S.down.val at hmem
    simpa only [hj] using hmem⟩⟩

def retraction (X : CubeCarrier.{u} m hm) : CubeCarrier.{u} k hk :=
  ⟨⟨P.retractionValues X.down.val, by
    intro hall
    apply X.down.property
    apply Set.eq_univ_of_forall
    intro j
    have hi : P.owner j ∈ P.retractionValues X.down.val := hall ▸ Set.mem_univ _
    exact hi (show j ∈ P.block (P.owner j) from rfl)⟩⟩

theorem section_monotone : Monotone (sectionMap (hk := hk) (hm := hm) P :
    CubeCarrier.{u} k hk → CubeCarrier.{u} m hm) :=
  fun _ _ h _ hj => h hj

theorem retraction_monotone : Monotone (retraction (hk := hk) (hm := hm) P :
    CubeCarrier.{u} m hm → CubeCarrier.{u} k hk) := by
  intro X Y hXY i hi j hj
  exact hXY (hi hj)

def stableSection (hK : IsCountablyBasedDIDomain (CubeCarrier.{u} k hk))
    (hM : IsCountablyBasedDIDomain (CubeCarrier.{u} m hm)) :
    StableHom (cubeCore k hk hK.1) (cubeCore m hm hM.1) :=
  StableHom.ofFunction (sectionMap P) ⟨
    FiniteOrderDomains.scottContinuous_of_monotone_finite (section_monotone P), by
    intro X Y _hXY
    apply cube_ext
    change P.sectionValues (hK.1.toIsScottDomain.inf X Y).down.val =
      (hM.1.toIsScottDomain.inf (sectionMap P X) (sectionMap P Y)).down.val
    rw [cube_inf_values k hk hK.1, cube_inf_values m hm hM.1]
    rfl⟩

def stableRetraction (hK : IsCountablyBasedDIDomain (CubeCarrier.{u} k hk))
    (hM : IsCountablyBasedDIDomain (CubeCarrier.{u} m hm)) :
    StableHom (cubeCore m hm hM.1) (cubeCore k hk hK.1) :=
  StableHom.ofFunction (retraction P) ⟨
    FiniteOrderDomains.scottContinuous_of_monotone_finite (retraction_monotone P), by
    intro X Y _hXY
    apply cube_ext
    change P.retractionValues (hM.1.toIsScottDomain.inf X Y).down.val =
      (hK.1.toIsScottDomain.inf (retraction P X) (retraction P Y)).down.val
    rw [cube_inf_values m hm hM.1, cube_inf_values k hk hK.1]
    ext i
    constructor
    · intro hi
      exact ⟨fun j hj => (hi hj).1, fun j hj => (hi hj).2⟩
    · rintro ⟨hi, hj⟩ a ha
      exact ⟨hi ha, hj ha⟩⟩

theorem leftInverse : Function.LeftInverse
    (retraction (hk := hk) (hm := hm) P : CubeCarrier.{u} m hm → CubeCarrier.{u} k hk)
    (sectionMap P) := by
  intro S
  apply cube_ext
  ext i
  constructor
  · intro hi
    obtain ⟨j, hj⟩ := P.onto i
    have hjmem : j ∈ P.block i := hj
    have hmem := hi hjmem
    change P.owner j ∈ S.down.val at hmem
    simpa only [hj] using hmem
  · intro hi j hj
    change P.owner j ∈ S.down.val
    change P.owner j = i at hj
    simpa only [hj] using hi

theorem partitionRetraction : TruncatedPartitionRetractionStatement.{u} := by
  intro k m hk hkm
  have hm : 2 ≤ m := hk.trans hkm
  let P := partition k m hk hkm
  let hK := cubeCountablyBased.{u} k hk
  let hM := cubeCountablyBased.{u} m hm
  exact ⟨hm, P, hK, hM, stableSection P hK hM, stableRetraction P hK hM,
    (fun _ => rfl), (fun _ => rfl), leftInverse P⟩

end DIDomainClassification.FiniteCubeRetractions
