import DIDomainClassification.Section02.StableCategory
import Mathlib.Data.Fintype.Powerset

/-! An algebraic domain is determined by the compact elements below each
point. Finitely many compacts therefore imply a finite whole carrier, rather
than imposing countability on all points of an infinite domain. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.InfiniteCompactBasis

open Preliminaries

variable (D : CountablyBasedDIDomain.{u})

def compactProfile (x : D) : Set ↥(CompactElements D.toDIDomainObject) :=
  {k | k.val ≤ x}

theorem compactProfile_injective : Function.Injective (compactProfile D) := by
  intro x y hxy
  have hKx := D.toDIDomainObject.isDIDomain.toIsScottDomain.algebraic.2 x
  have hKy := D.toDIDomainObject.isDIDomain.toIsScottDomain.algebraic.2 y
  apply le_antisymm
  · apply hKx.2.2
    intro k hk
    have hmem : (⟨k, hk.1⟩ : ↥(CompactElements D.toDIDomainObject)) ∈ compactProfile D x := hk.2
    rw [hxy] at hmem
    exact hmem
  · apply hKy.2.2
    intro k hk
    have hmem : (⟨k, hk.1⟩ : ↥(CompactElements D.toDIDomainObject)) ∈ compactProfile D y := hk.2
    rw [← hxy] at hmem
    exact hmem

theorem finite_of_finite_compacts [Finite ↥(CompactElements D.toDIDomainObject)] : Finite D :=
  Finite.of_injective (compactProfile D) (compactProfile_injective D)

theorem infinite_compacts [Infinite D] : Infinite ↥(CompactElements D.toDIDomainObject) := by
  apply not_finite_iff_infinite.mp
  intro hFin
  letI := hFin
  letI : Finite D := finite_of_finite_compacts D
  exact not_finite D

end DIDomainClassification.InfiniteCompactBasis
