import DIDomainClassification.Support.QualitativeConfigurationMIC
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Section04.QualitativeCoherenceStatement
import Mathlib.Order.Preorder.Finite

/-! Degree bounds from actual causal conflicts, the empty-family case, and
an attained finite maximum. The source's countable-configuration-compacts
hypothesis is retained; no countability of events or supplied maximum is used. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.QualitativeCausalCoherence

open Preliminaries EventStructures CoherenceDegree FiniteCausalConflicts
open QualitativeConfigurationMIC

variable {A : Type u} [PartialOrder A]

theorem degree_bound (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)) (n : ℕ) (hn : 2 ≤ n) :
    coherenceDegree hE.1.toIsScottDomain ≤ (n : Ordinal.{u+1}) ↔
      ∀ H ∈ causalConflictFamily E, H.ncard ≤ n :=
  ((Section02.bps.{u}).2.2.2.2.2.2 (Configuration E)
    hE.1.toIsScottDomain hE.2 n hn).trans
      (nCoherent_iff_conflict_bound E hE.1.toIsScottDomain n hn)

theorem conflict_card_le_degree (E : FinitaryPrimeEventStructure A)
    (hD : IsScottDomain (Configuration E)) (H : Set A) (hH : H ∈ causalConflictFamily E) :
    (H.ncard : Ordinal.{u+1}) ≤ coherenceDegree hD := by
  have h := mic_ncard_le_degree hD (principalFamily_mic E hD H hH)
  simpa only [principalFamily_ncard] using h

theorem all_bounded_of_empty (E : FinitaryPrimeEventStructure A)
    (hEmpty : causalConflictFamily E = ∅) (F : Set (Configuration E)) : BddAbove F := by
  apply (bounded_iff_avoids E F).mpr
  intro H hH
  rw [hEmpty] at hH
  exact False.elim hH

theorem completeLatticeOrder_of_empty (E : FinitaryPrimeEventStructure A)
    (hD : IsScottDomain (Configuration E)) (hEmpty : causalConflictFamily E = ∅) :
    Section02.BPS.IsCompleteLatticeOrder (Configuration E) := by
  intro F
  refine ⟨hD.boundedSuprema F (all_bounded_of_empty E hEmpty F), ?_⟩
  obtain ⟨m, hm⟩ := hD.boundedSuprema (lowerBounds F)
    (all_bounded_of_empty E hEmpty (lowerBounds F))
  refine ⟨m, ?_, ?_⟩
  · intro X hX
    exact hm.2 (fun b hb => hb hX)
  · intro b hb
    exact hm.1 hb

theorem empty_degree (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)) (hEmpty : causalConflictFamily E = ∅) :
    coherenceDegree hE.1.toIsScottDomain = 0 :=
  ((Section02.bps.{u}).2.2.2.2.2.1 (Configuration E)
    hE.1.toIsScottDomain hE.2).mpr
      (completeLatticeOrder_of_empty E hE.1.toIsScottDomain hEmpty)

/-- The finite bound gives a finite nonempty set of cardinalities. Its maximum
is chosen and PROVED attained by a member of the actual causal-conflict family. -/
theorem attained_finite_maximum (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (hNonempty : (causalConflictFamily E).Nonempty)
    (hBound : ∃ n : ℕ, ∀ H ∈ causalConflictFamily E, H.ncard ≤ n) :
    ∃ (m : ℕ) (H : Set A), H ∈ causalConflictFamily E ∧ H.ncard = m ∧
      (∀ K ∈ causalConflictFamily E, K.ncard ≤ m) ∧
      coherenceDegree hE.1.toIsScottDomain = (m : Ordinal.{u+1}) := by
  obtain ⟨n, hn⟩ := hBound
  let C : Set ℕ := {m | ∃ H ∈ causalConflictFamily E, H.ncard = m}
  have hFinite : C.Finite := (Set.finite_range (fun i : Fin (n + 1) => i.val)).subset (by
    rintro m ⟨H, hH, rfl⟩
    exact ⟨⟨H.ncard, Nat.lt_succ_of_le (hn H hH)⟩, rfl⟩)
  have hC : C.Nonempty := by
    obtain ⟨H, hH⟩ := hNonempty
    exact ⟨H.ncard, H, hH, rfl⟩
  obtain ⟨m, hm⟩ := hFinite.exists_maximal hC
  obtain ⟨H, hH, hCard⟩ := hm.1
  have hGreatest : ∀ K ∈ causalConflictFamily E, K.ncard ≤ m := by
    intro K hK
    rcases le_total K.ncard m with h | h
    · exact h
    · exact hm.2 ⟨K, hK, rfl⟩ h
  have hm2 : 2 ≤ m := by
    rw [← hCard]
    exact conflict_member_card_ge_two E hH
  have hUpper := (degree_bound E hE m hm2).mpr hGreatest
  have hLower := conflict_card_le_degree E hE.1.toIsScottDomain H hH
  rw [hCard] at hLower
  exact ⟨m, H, hH, hCard, hGreatest, le_antisymm hUpper hLower⟩

end DIDomainClassification.QualitativeCausalCoherence
