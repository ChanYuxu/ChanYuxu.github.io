import DIDomainClassification.Section05.ReflexiveClassification
import DIDomainClassification.Section05.WNonretraction
import DIDomainClassification.Section05.ZhaoKou

/-! The complete-lattice obstruction and the actual U/W example. Actual
two-coherence of [W -> W] is proved before invoking Zhao--Kou universality. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ReflexiveExamples
open Preliminaries CoherenceDegree Subcategories Section05
open Section03.StableFunctionModels Section04.AdditionalSourceModels

theorem complete_not_reflexive : NonreflexiveCompleteLatticeStatement.{u} := by
  intro D hNon hComplete hRef
  have hZero : objectDegree D = 0 :=
    (Section02.bps.2.2.2.2.2.1 (Core D) (Core D).isDIDomain.toIsScottDomain
      D.countableCompacts).mpr hComplete
  have hFun := Section03.functionDegreeNontrivial D D hNon hNon
  change objectDegree (exponential D D) = max 2 (objectDegree D) at hFun
  have hFtwo : objectDegree (exponential D D) = 2 := by
    rw [hFun, hZero]
    exact max_eq_left (zero_le _)
  have hMono := ReflexiveDegreeCut.retract_degree_le (exponential D D) D hRef
  have hBad : (2 : Ordinal.{u+1}) ≤ 0 := hFtwo ▸ (hMono.trans_eq hZero)
  exact (not_le_of_gt zero_lt_two) hBad

theorem base_and_W :
    ∃ hU : IsCountablyBasedDIDomain UniversalBaseCarrier.{u},
      objectDegree (universalBaseObject hU) = 2 ∧
      objectDegree (universalTwoObject hU) = 2 ∧
      ¬ IsStableReflexive (universalBaseObject hU) ∧
      IsStableReflexive (universalTwoObject hU) ∧
      ¬ HasStableRetraction (Core (universalTwoObject hU)) (Core (universalBaseObject hU)) := by
  obtain ⟨hU, hNot⟩ := wDegreeNonretract.{u}
  obtain ⟨_hU', hBase, hW, _hWcoh⟩ := wDegreeModel.{u}
  let W := universalTwoObject hU
  have hFbound : objectDegree (exponential W W) ≤ 2 :=
    (Section03.functionDegreeUpper W W).trans_eq (by rw [hW, max_self])
  have hFcoh : IsNCoherent (Core (exponential W W)).isDIDomain.toIsScottDomain 2 (by decide) :=
    (Section02.bps.2.2.2.2.2.2 _ _ (exponential W W).countableCompacts 2 (by decide)).mp hFbound
  obtain ⟨_hUZ, hZ⟩ := zhaoKou.{u}
  have hRefW : IsStableReflexive W := hZ (exponential W W) hFcoh
  exact ⟨hU, hBase, hW, hNot, hRefW, hNot⟩

end DIDomainClassification.ReflexiveExamples
