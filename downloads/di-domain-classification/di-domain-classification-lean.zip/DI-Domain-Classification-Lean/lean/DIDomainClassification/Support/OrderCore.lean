import Mathlib.Data.Set.Countable
import Mathlib.Order.Bounds.Defs

/-!
# Narrow order-theoretic foundation

Adapted, not newly invented, from the pinned common book definitions of
directed sets, suprema, way-below, compactness and algebraicity. This file
does not import a book umbrella. Its source-facing aliases require fresh
independent interface review after this import-only representation refactor.
No classification result is proved here.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.OrderCore

def DirectedSet {D : Type u} [Preorder D] (A : Set D) : Prop :=
  A.Nonempty ∧ ∀ ⦃x : D⦄, x ∈ A → ∀ ⦃y : D⦄, y ∈ A →
    ∃ z ∈ A, x ≤ z ∧ y ≤ z

def IsUpperBound {D : Type u} [Preorder D] (A : Set D) (x : D) : Prop :=
  ∀ ⦃a : D⦄, a ∈ A → a ≤ x

def IsSup {D : Type u} [Preorder D] (A : Set D) (x : D) : Prop :=
  IsUpperBound A x ∧ ∀ y : D, IsUpperBound A y → x ≤ y

def IsDcpo (D : Type u) [Preorder D] : Prop :=
  ∀ A : Set D, DirectedSet A → ∃ x : D, IsSup A x

def WayBelow {D : Type u} [Preorder D] (x y : D) : Prop :=
  ∀ ⦃A : Set D⦄ ⦃s : D⦄,
    DirectedSet A → IsSup A s → y ≤ s → ∃ a ∈ A, x ≤ a

def Compact {D : Type u} [Preorder D] (x : D) : Prop := WayBelow x x

def CompactSet (D : Type u) [Preorder D] : Set D := {x | Compact x}

def CompactBelow {D : Type u} [Preorder D] (x : D) : Set D :=
  {k | Compact k ∧ k ≤ x}

def IsAlgebraicDcpo (D : Type u) [PartialOrder D] : Prop :=
  IsDcpo D ∧ ∀ x : D, DirectedSet (CompactBelow x) ∧ IsSup (CompactBelow x) x

def IsCountablyBasedAlgebraicDcpo (D : Type u) [PartialOrder D] : Prop :=
  IsAlgebraicDcpo D ∧ (CompactSet D).Countable

def Approximants {D : Type u} [Preorder D] (B : Set D) (x : D) : Set D :=
  {b | b ∈ B ∧ WayBelow b x}

def IsBasis {D : Type u} [Preorder D] (B : Set D) : Prop :=
  ∀ x : D, DirectedSet (Approximants B x) ∧ IsSup (Approximants B x) x

end DIDomainClassification.OrderCore
