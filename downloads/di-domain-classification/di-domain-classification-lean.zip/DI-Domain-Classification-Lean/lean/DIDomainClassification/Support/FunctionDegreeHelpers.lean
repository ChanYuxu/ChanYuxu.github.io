import DIDomainClassification.Section03.FunctionDegreeStatement
import DIDomainClassification.Section03.CompactBridge
import DIDomainClassification.Section03.StableSup
import DIDomainClassification.Section02.StablePointwise
import DIDomainClassification.Support.LargeMicMap
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Section02.RetractionCalculus
import DIDomainClassification.Section02.TwoExponential
import DIDomainClassification.Section02.TwoRetract
import DIDomainClassification.Support.StableMapOperators

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FunctionDegreeHelpers
open Preliminaries CoherenceDegree Section03 Section03.StableFunctionModels

theorem forget_injective (D E : CountablyBasedDIDomain.{u}) :
    Function.Injective (@forgetStable D E) := by
  intro f g hfg
  apply StableHom.ext
  intro x
  exact congrFun (congrArg Subtype.val hfg) x

theorem forget_monotone (D E : CountablyBasedDIDomain.{u}) :
    Monotone (@forgetStable D E) := by
  intro f g hfg x
  exact Section02.stablePointwise (Core D) (Core E) f g hfg x

theorem large_mic_forget (D E : CountablyBasedDIDomain.{u})
    (X : Set (StableSpace D E))
    (hX : IsMinimallyInconsistent (stableScottDomain D E) X) (hsize : 3 ≤ X.ncard) :
    IsMinimallyInconsistent (pointwiseScottDomain D E) (forgetStable '' X) := by
  classical
  have hne : X.Nonempty := by
    rcases Set.eq_empty_or_nonempty X with h | h
    · simp only [h, Set.ncard_empty] at hsize
      omega
    · exact h
  have hpairs : ∀ f ∈ X, ∀ g ∈ X,
      ∃ k : StableSpace D E, f ≤ k ∧ g ≤ k := by
    intro f hf g hg
    have hsub : ({f, g} : Set (StableSpace D E)) ⊆ X := by
      intro z hz
      rcases Set.mem_insert_iff.mp hz with rfl | hz
      · exact hf
      · have heq : z = g := Set.mem_singleton_iff.mp hz
        exact heq ▸ hg
    have hcard : ({f, g} : Set (StableSpace D E)).ncard ≤ 2 := by
      by_cases hfg : f = g
      · subst g
        simp
      · rw [Set.ncard_pair hfg]
    have hneq : ({f, g} : Set (StableSpace D E)) ≠ X := by
      intro heq
      rw [heq] at hcard
      omega
    obtain ⟨k, hk⟩ := hX.2.2 {f, g} (Set.ssubset_iff_subset_ne.mpr ⟨hsub, hneq⟩)
    exact ⟨k, hk (by simp), hk (by simp)⟩
  refine ⟨hX.1.image forgetStable, ?_, ?_⟩
  · rintro ⟨g, hg⟩
    have hbound : ∀ x : Core D, BddAbove (FamilyValues D E X x) := by
      intro x
      refine ⟨g.val x, ?_⟩
      rintro _ ⟨f, hf, rfl⟩
      exact hg ⟨f, hf, rfl⟩ x
    obtain ⟨h, hh, _hvalues⟩ := stableSup D E X hne hpairs hbound
    exact hX.2.1 ⟨h, hh.1⟩
  · intro Y hY
    let Z : Set (StableSpace D E) := X ∩ forgetStable ⁻¹' Y
    have hZ : Z ⊂ X := by
      refine ⟨Set.inter_subset_left, ?_⟩
      intro hback
      apply hY.2
      rintro _ ⟨f, hf, rfl⟩
      exact (hback hf).2
    obtain ⟨k, hk⟩ := hX.2.2 Z hZ
    refine ⟨forgetStable k, ?_⟩
    intro p hp
    obtain ⟨f, hf, hfp⟩ := hY.1 hp
    subst p
    exact forget_monotone D E (hk ⟨hf, hp⟩)

theorem stable_degree_le_pointwise (D E : CountablyBasedDIDomain.{u}) :
    coherenceDegree (stableScottDomain D E) ≤
      max 2 (coherenceDegree (pointwiseScottDomain D E)) := by
  apply LargeMicMap.coherenceDegree_le_of_large_mic_map
    (stableScottDomain D E) (pointwiseScottDomain D E) forgetStable
    (forget_injective D E)
  · intro f hf
    exact (compactBridge D E f hf).1
  · intro X _hK hX hsize
    exact large_mic_forget D E X hX hsize

theorem pointwise_degree_eq (D E : CountablyBasedDIDomain.{u}) :
    coherenceDegree (pointwiseScottDomain D E) =
      coherenceDegree (Core E).isDIDomain.toIsScottDomain := by
  letI : Nonempty (Core D) := ⟨(Core D).isDIDomain.toIsScottDomain.bottom⟩
  obtain ⟨_hFunctions, _hK, hdegree⟩ := Section02.bps.2.2.1 (Core D) (Core E)
    (Core D).isDIDomain.toIsScottDomain (Core E).isDIDomain.toIsScottDomain
    D.countableCompacts E.countableCompacts
  exact hdegree

theorem stable_degree_upper (D E : CountablyBasedDIDomain.{u}) :
    coherenceDegree (stableScottDomain D E) ≤
      max 2 (coherenceDegree (Core E).isDIDomain.toIsScottDomain) := by
  have h := stable_degree_le_pointwise D E
  rw [pointwise_degree_eq D E] at h
  exact h

def constantEmbedding (D E : CountablyBasedDIDomain.{u}) :
    StableHom (Core E) (Core (exponential D E)) :=
  StableCCCOperations.curried trueClosure E D E (StableCCCOperations.fst trueClosure E D)

theorem constantEmbedding_apply (D E : CountablyBasedDIDomain.{u}) (e : Core E) (x : Core D) :
    constantEmbedding D E e x = e := rfl

def evaluationAt (D E : CountablyBasedDIDomain.{u}) (x : Core D) :
    StableHom (Core (exponential D E)) (Core E) :=
  StableHom.comp (StableCCCOperations.evaluation trueClosure D E)
    (StableCCCOperations.pair trueClosure (exponential D E) (exponential D E) D
      (StableHom.id _) (StableMapOperators.constant (exponential D E) D x))

theorem evaluationAt_apply (D E : CountablyBasedDIDomain.{u}) (x : Core D)
    (f : StableSpace D E) : evaluationAt D E x f = f x := rfl

theorem codomain_degree_le (D E : CountablyBasedDIDomain.{u}) :
    coherenceDegree (Core E).isDIDomain.toIsScottDomain ≤
      coherenceDegree (stableScottDomain D E) := by
  let x : Core D := (Core D).isDIDomain.toIsScottDomain.bottom
  apply Section02.bps.1 (Core E) (StableSpace D E)
    (Core E).isDIDomain.toIsScottDomain (stableScottDomain D E)
    E.countableCompacts (exponential D E).countableCompacts
  exact ⟨constantEmbedding D E, evaluationAt D E x,
    (StableHom.isStable (constantEmbedding D E)).1,
    (StableHom.isStable (evaluationAt D E x)).1, by intro e; rfl⟩

theorem two_le_degree (D E : CountablyBasedDIDomain.{u})
    (hD : Nontrivial (Core D)) (hE : Nontrivial (Core E)) :
    2 ≤ coherenceDegree (stableScottDomain D E) := by
  let T : CountablyBasedDIDomain.{u} := FiniteOrderDomains.twoObject
  have hK : (CompactElements (StableSpace T T)).Countable := (exponential T T).countableCompacts
  obtain ⟨_hCube, _every, _hzi, _hzo, _hio, _hz, _hpoint, hnot, _hiso⟩ :=
    Section02.twoExponential.{u}
  have hnezero : coherenceDegree (stableScottDomain T T) ≠ 0 := by
    intro hz
    have hc := (Section02.bps.2.2.2.2.2.1 (StableSpace T T) (stableScottDomain T T) hK).mp hz
    obtain ⟨k, hk⟩ := (hc ({Section02.TwoExponentialModels.identityMap,
      Section02.TwoExponentialModels.oneMap} : Set (StableSpace T T))).1
    exact hnot ⟨k, hk.1 (by simp), hk.1 (by simp)⟩
  have htwo : 2 ≤ coherenceDegree (stableScottDomain T T) :=
    ((Section02.bps.2.2.2.2.1 (StableSpace T T) (stableScottDomain T T) hK).resolve_left hnezero).1
  obtain ⟨sD, rD, hleftD⟩ := (Section02.twoRetract (Core D) hD.exists_pair_ne).2
  obtain ⟨sE, rE, hleftE⟩ := (Section02.twoRetract (Core E) hE.exists_pair_ne).2
  obtain ⟨hs, hr, hleft⟩ := Section02.retractionExponential
    (Core T) (Core T) (Core D) (Core E) sD rD sE rE hleftD hleftE
  have hmono : coherenceDegree (stableScottDomain T T) ≤
      coherenceDegree (stableScottDomain D E) := by
    apply Section02.bps.1 (StableSpace T T) (StableSpace D E)
      (stableScottDomain T T) (stableScottDomain D E)
      hK (exponential D E).countableCompacts
    exact ⟨Section02.RetractionCalculusModels.exponentialSection rD sE,
      Section02.RetractionCalculusModels.exponentialRetraction sD rE, hs.1, hr.1, hleft⟩
  exact htwo.trans hmono

end DIDomainClassification.FunctionDegreeHelpers
