import DIDomainClassification.Support.PointwiseScottMIC
import DIDomainClassification.Support.LeafClassSubtree

/-!
Same-tree output relabelling for MIC trees whose labels are actual step-basis
functions. The output labels are proved compact and branch-injective. This
proves the last relabelling part of the function-degree argument; the preceding
general join-basis rank-refinement theorem is a separate obligation.
-/

set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open OrderCore Preliminaries CoherenceDegree Trees

variable {D : Type u} {E : Type v} [PartialOrder D] [PartialOrder E]

abbrev BasisElement (hE : IsScottDomain E) := {f : Space D E // f ∈ stepBasis hE}

def basisRepresentative (hE : IsScottDomain E) (f : BasisElement (D := D) hE) :
    StepIndex D E := Classical.choose f.property

theorem basisRepresentative_spec (hE : IsScottDomain E) (f : BasisElement (D := D) hE) :
    stepOf hE (basisRepresentative hE f) = f.val := Classical.choose_spec f.property

def basisOutput (hE : IsScottDomain E) (f : BasisElement (D := D) hE) : E :=
  (basisRepresentative hE f).2.val

theorem basisOutput_mic (hD : IsScottDomain D) (hE : IsScottDomain E)
    (M : Set (BasisElement (D := D) hE))
    (hM : IsMinimallyInconsistent (space_isScottDomain hD hE) (Subtype.val '' M)) :
    IsMinimallyInconsistent hE (basisOutput hE '' M) ∧
      Set.InjOn (basisOutput hE) M := by
  classical
  let S : Set (StepIndex D E) := basisRepresentative hE '' M
  have hfinM : M.Finite := hM.1.of_finite_image Subtype.val_injective.injOn
  have hfin : S.Finite := hfinM.image _
  have hinj : Set.InjOn (stepOf hE) S := by
    rintro _ ⟨f, _hf, rfl⟩ _ ⟨g, _hg, rfl⟩ hfg
    have heq : f = g := Subtype.ext ((basisRepresentative_spec hE f).symm.trans
      (hfg.trans (basisRepresentative_spec hE g)))
    exact congrArg (basisRepresentative hE) heq
  have hstep : stepOf hE '' S = Subtype.val '' M := by
    ext f
    constructor
    · rintro ⟨_, ⟨g, hg, rfl⟩, rfl⟩
      exact ⟨g, hg, (basisRepresentative_spec hE g).symm⟩
    · rintro ⟨g, hg, rfl⟩
      exact ⟨basisRepresentative hE g, ⟨g, hg, rfl⟩, basisRepresentative_spec hE g⟩
  have hmic : IsMinimallyInconsistent (space_isScottDomain hD hE)
      (stepOf hE '' S) := by simpa only [hstep] using hM
  have hout : outputs S = basisOutput hE '' M := by
    exact Set.image_image (fun i : StepIndex D E => i.2.val) (basisRepresentative hE) M
  have hOutMic := (step_mic_inputs_outputs hD hE S hfin hinj hmic).2
  have hOutInj := step_mic_outputs_injective hD hE S hfin hinj hmic
  refine ⟨by simpa only [hout] using hOutMic, ?_⟩
  intro f hf g hg hfg
  have heq := hOutInj ⟨f, hf, rfl⟩ ⟨g, hg, rfl⟩ hfg
  apply Subtype.ext
  exact (basisRepresentative_spec hE f).symm.trans
    ((congrArg (stepOf hE) heq).trans (basisRepresentative_spec hE g))

variable (hD : IsScottDomain D) (hE : IsScottDomain E)
  {Index : Type w} (M : MicTree (Space D E) (space_isScottDomain hD hE) Index)
  (hBasis : ∀ x, (M.label x).val ∈ stepBasis hE)

def nodeBasis (x : M.tree.Node) : BasisElement (D := D) hE :=
  ⟨(M.label x).val, hBasis x⟩

def outputLabel (x : M.tree.Node) : ↥(CompactElements E) :=
  (basisRepresentative hE (nodeBasis hD hE M hBasis x)).2

theorem outputLabel_finiteBranch_mic {c : Set M.tree.Node}
    (hc : M.tree.IsFiniteCompleteBranch c) :
    IsMinimallyInconsistent hE (labelImage M.tree (outputLabel hD hE M hBasis) c) := by
  let B : Set (BasisElement (D := D) hE) := nodeBasis hD hE M hBasis '' c
  have hsrc : Subtype.val '' B = labelImage M.tree M.label c := by
    simp only [B, Set.image_image]
    rfl
  have hM : IsMinimallyInconsistent (space_isScottDomain hD hE) (Subtype.val '' B) := by
    rw [hsrc]
    exact M.isMicTree.finiteBranch_mic hc
  have h := (basisOutput_mic hD hE B hM).1
  simpa only [B, Set.image_image, basisOutput, nodeBasis, outputLabel, labelImage] using h

theorem outputLabel_path_injective (leaf : M.tree.Node) (hleaf : M.tree.IsLeaf leaf) :
    Set.InjOn (outputLabel hD hE M hBasis) (M.tree.pathTo leaf) := by
  let c : Set M.tree.Node := M.tree.pathTo leaf
  have hc : M.tree.IsFiniteCompleteBranch c := ⟨leaf, hleaf, rfl⟩
  let B : Set (BasisElement (D := D) hE) := nodeBasis hD hE M hBasis '' c
  have hsrc : Subtype.val '' B = labelImage M.tree M.label c := by
    simp only [B, Set.image_image]
    rfl
  have hM : IsMinimallyInconsistent (space_isScottDomain hD hE) (Subtype.val '' B) := by
    rw [hsrc]
    exact M.isMicTree.finiteBranch_mic hc
  have hOut := (basisOutput_mic hD hE B hM).2
  intro x hx y hy hxy
  have hb := hOut ⟨x, hx, rfl⟩ ⟨y, hy, rfl⟩ (congrArg Subtype.val hxy)
  apply M.isMicTree.branchInjective (hc.isBranch M.tree) hx hy
  have hfun : (M.label x).val = (M.label y).val :=
    congrArg (fun f : BasisElement (D := D) hE => f.val) hb
  exact Subtype.ext hfun

theorem outputLabel_branch_injective (hWF : M.tree.IsWellFounded)
    {c : Set M.tree.Node} (hc : M.tree.IsBranch c) :
    Set.InjOn (outputLabel hD hE M hBasis) c := by
  intro x hx y hy hxy
  rcases hc.1.total hx hy with hxy' | hyx
  · obtain ⟨leaf, hleaf, hyl⟩ :=
      FiniteLeafColourPruning.exists_leaf_extension M.tree hWF y
    exact outputLabel_path_injective hD hE M hBasis leaf hleaf
      (hxy'.trans hyl) hyl hxy
  · obtain ⟨leaf, hleaf, hxl⟩ :=
      FiniteLeafColourPruning.exists_leaf_extension M.tree hWF x
    exact outputLabel_path_injective hD hE M hBasis leaf hleaf
      hxl (hyx.trans hxl) hxy

def outputMicTree (hWF : M.tree.IsWellFounded) : MicTree E hE Index where
  tree := M.tree
  proper := M.proper
  label := outputLabel hD hE M hBasis
  isMicTree := (isMicTree_iff hE M.tree M.proper _).2
    ⟨fun _ hc => outputLabel_branch_injective hD hE M hBasis hWF hc,
      fun _ hc => outputLabel_finiteBranch_mic hD hE M hBasis hc⟩

/-- Actual same-tree/rank upper bound, once a tree is labelled in the proved
step basis. No general refinement theorem is assumed or encoded as a field. -/
theorem stepBasis_tree_contribution_le {D E : Type u} [PartialOrder D] [PartialOrder E]
    (hD : IsScottDomain D) (hE : IsScottDomain E) {Index : Type u}
    (M : MicTree (Space D E) (space_isScottDomain hD hE) Index)
    (hBasis : ∀ x, (M.label x).val ∈ stepBasis hE) (hWF : M.tree.IsWellFounded) :
    Ordinal.lift.{u+1} (M.tree.treeRank hWF + 1) ≤ coherenceDegree hE :=
  treeRank_add_one_le_coherenceDegree hE (outputMicTree hD hE M hBasis hWF) hWF

end DIDomainClassification.PointwiseFunctionSupport
