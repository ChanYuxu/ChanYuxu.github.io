import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.StableFunctionSpaces
import Mathlib.Order.Bounds.OrderIso

/-!
# Literal-order transport of the intrinsic domain predicates

Generic proved support, not an accepted source retraction theorem. Both
carriers retain their supplied partial orders. Directed sets are nonempty;
compactness and algebraicity are the actual narrow OrderCore predicates.
The dI transport preserves arbitrary-third compatible-join distributivity
and finiteness of the entire principal ideal of every compact element.
No whole-carrier countability, strictness, or EP inequality is assumed.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.OrderIsoTransport

open OrderCore
open Preliminaries (IsScottDomain IsDIDomain IsCountablyBasedDIDomain
  CompactElements CompatibleJoinDistributive)

section Transport

variable {D : Type u} {E : Type v} [PartialOrder D] [PartialOrder E]

theorem directedSet_image_iff (e : D ≃o E) (A : Set D) :
    DirectedSet (e '' A) ↔ DirectedSet A := by
  constructor
  · intro h
    simpa only [e.symm_image_image] using h.image e.symm.monotone
  · intro h
    exact h.image e.monotone

theorem isSup_image_iff (e : D ≃o E) {A : Set D} {s : D} :
    IsSup (e '' A) (e s) ↔ IsSup A s := e.isLUB_image'

theorem isSup_preimage_iff (e : D ≃o E) {A : Set E} {s : D} :
    IsSup (e ⁻¹' A) s ↔ IsSup A (e s) := e.isLUB_preimage

theorem wayBelow_map (e : D ≃o E) {x y : D} (hxy : WayBelow x y) :
    WayBelow (e x) (e y) := by
  intro A s hA hs hys
  have hdir : DirectedSet (e.symm '' A) := hA.image e.symm.monotone
  have hsup : IsSup (e.symm '' A) (e.symm s) := e.symm.isLUB_image'.mpr hs
  have hys' : y ≤ e.symm s := by
    simpa only [e.symm_apply_apply] using e.symm.monotone hys
  obtain ⟨_, ⟨a, ha, rfl⟩, hxa⟩ := hxy hdir hsup hys'
  exact ⟨a, ha, by simpa only [e.apply_symm_apply] using e.monotone hxa⟩

theorem wayBelow_iff (e : D ≃o E) (x y : D) :
    WayBelow (e x) (e y) ↔ WayBelow x y := by
  constructor
  · intro h
    simpa only [e.symm_apply_apply] using wayBelow_map e.symm h
  · exact wayBelow_map e

theorem compact_iff (e : D ≃o E) (k : D) : Compact (e k) ↔ Compact k :=
  wayBelow_iff e k k

theorem isDcpo_map (e : D ≃o E) (hD : IsDcpo D) : IsDcpo E := by
  intro A hA
  obtain ⟨s, hs⟩ := hD (e.symm '' A) (hA.image e.symm.monotone)
  refine ⟨e s, ?_⟩
  simpa only [e.image_symm_image] using e.isLUB_image'.mpr hs

theorem isDcpo_iff (e : D ≃o E) : IsDcpo D ↔ IsDcpo E :=
  ⟨isDcpo_map e, isDcpo_map e.symm⟩

theorem compactSet_image (e : D ≃o E) : e '' CompactSet D = CompactSet E := by
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    exact (compact_iff e x).mpr hx
  · intro hy
    refine ⟨e.symm y, ?_, e.apply_symm_apply y⟩
    simpa only [e.apply_symm_apply] using (compact_iff e.symm y).mpr hy

theorem compactBelow_image (e : D ≃o E) (x : D) :
    e '' CompactBelow x = CompactBelow (e x) := by
  ext y
  constructor
  · rintro ⟨k, hk, rfl⟩
    exact ⟨(compact_iff e k).mpr hk.1, e.monotone hk.2⟩
  · rintro ⟨hy, hyx⟩
    refine ⟨e.symm y, ⟨?_, ?_⟩, e.apply_symm_apply y⟩
    · exact (compact_iff e.symm y).mpr hy
    · simpa only [e.symm_apply_apply] using e.symm.monotone hyx

theorem isAlgebraicDcpo_map (e : D ≃o E) (hD : IsAlgebraicDcpo D) :
    IsAlgebraicDcpo E := by
  refine ⟨isDcpo_map e hD.1, ?_⟩
  intro y
  have hdir := (hD.2 (e.symm y)).1.image e.monotone
  have hsup := e.isLUB_image'.mpr (hD.2 (e.symm y)).2
  simpa only [compactBelow_image, e.apply_symm_apply] using And.intro hdir hsup

theorem isAlgebraicDcpo_iff (e : D ≃o E) :
    IsAlgebraicDcpo D ↔ IsAlgebraicDcpo E :=
  ⟨isAlgebraicDcpo_map e, isAlgebraicDcpo_map e.symm⟩

theorem compactElements_countable_map (e : D ≃o E)
    (hK : (CompactElements D).Countable) : (CompactElements E).Countable := by
  have h := hK.image e
  simpa only [compactSet_image] using h

theorem compactElements_countable_iff (e : D ≃o E) :
    (CompactElements D).Countable ↔ (CompactElements E).Countable :=
  ⟨compactElements_countable_map e, compactElements_countable_map e.symm⟩

theorem isCountablyBasedAlgebraicDcpo_iff (e : D ≃o E) :
    IsCountablyBasedAlgebraicDcpo D ↔ IsCountablyBasedAlgebraicDcpo E :=
  and_congr (isAlgebraicDcpo_iff e) (compactElements_countable_iff e)

theorem bddAbove_image_iff (e : D ≃o E) (A : Set D) :
    BddAbove (e '' A) ↔ BddAbove A := by
  constructor
  · rintro ⟨b, hb⟩
    refine ⟨e.symm b, ?_⟩
    intro x hx
    simpa only [e.symm_apply_apply] using e.symm.monotone (hb ⟨x, hx, rfl⟩)
  · rintro ⟨b, hb⟩
    exact ⟨e b, by rintro _ ⟨x, hx, rfl⟩; exact e.monotone (hb hx)⟩

theorem compatible_map (e : D ≃o E) {x y : D} (hxy : Compatible x y) :
    Compatible (e x) (e y) := by
  obtain ⟨z, hxz, hyz⟩ := hxy
  exact ⟨e z, e.monotone hxz, e.monotone hyz⟩

theorem compatible_iff (e : D ≃o E) (x y : D) :
    Compatible (e x) (e y) ↔ Compatible x y := by
  constructor
  · intro h
    simpa only [e.symm_apply_apply] using compatible_map e.symm h
  · exact compatible_map e

theorem isScottDomain_map (e : D ≃o E) (hD : IsScottDomain D) :
    IsScottDomain E := by
  refine ⟨isAlgebraicDcpo_map e hD.algebraic, ?_, ?_⟩
  · obtain ⟨b, hb⟩ := hD.hasLeast
    refine ⟨e b, ?_⟩
    intro y
    simpa only [e.apply_symm_apply] using e.monotone (hb (e.symm y))
  · intro A hA
    have hB : BddAbove (e.symm '' A) := (bddAbove_image_iff e.symm A).mpr hA
    obtain ⟨s, hs⟩ := hD.boundedSuprema (e.symm '' A) hB
    exact ⟨e s, by simpa only [e.image_symm_image] using e.isLUB_image'.mpr hs⟩

theorem isScottDomain_iff (e : D ≃o E) : IsScottDomain D ↔ IsScottDomain E :=
  ⟨isScottDomain_map e, isScottDomain_map e.symm⟩

theorem isLUB_pair_iff (e : D ≃o E) (x y s : D) :
    IsLUB ({e x, e y} : Set E) (e s) ↔ IsLUB ({x, y} : Set D) s := by
  simpa only [Set.image_pair] using (e.isLUB_image' (s := ({x, y} : Set D)) (x := s))

theorem isGLB_pair_iff (e : D ≃o E) (x y i : D) :
    IsGLB ({e x, e y} : Set E) (e i) ↔ IsGLB ({x, y} : Set D) i := by
  simpa only [Set.image_pair] using (e.isGLB_image' (s := ({x, y} : Set D)) (x := i))

theorem compatibleJoinDistributive_map (e : D ≃o E)
    (hD : CompatibleJoinDistributive D) : CompatibleJoinDistributive E := by
  intro x y z joined meet left right hxy hj hm hl hr
  have h := hD (e.symm x) (e.symm y) (e.symm z) (e.symm joined)
    (e.symm meet) (e.symm left) (e.symm right) (compatible_map e.symm hxy)
    ((isLUB_pair_iff e.symm x y joined).mpr hj)
    ((isGLB_pair_iff e.symm joined z meet).mpr hm)
    ((isGLB_pair_iff e.symm x z left).mpr hl)
    ((isGLB_pair_iff e.symm y z right).mpr hr)
  exact (isLUB_pair_iff e.symm left right meet).mp h

theorem compatibleJoinDistributive_iff (e : D ≃o E) :
    CompatibleJoinDistributive D ↔ CompatibleJoinDistributive E :=
  ⟨compatibleJoinDistributive_map e, compatibleJoinDistributive_map e.symm⟩

theorem image_Iic (e : D ≃o E) (k : D) : e '' Set.Iic k = Set.Iic (e k) := by
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    exact e.monotone hx
  · intro hy
    exact ⟨e.symm y, by simpa only [e.symm_apply_apply] using e.symm.monotone hy,
      e.apply_symm_apply y⟩

theorem isDIDomain_map (e : D ≃o E) (hD : IsDIDomain D) : IsDIDomain E where
  toIsScottDomain := isScottDomain_map e hD.toIsScottDomain
  distributive := compatibleJoinDistributive_map e hD.distributive
  finitePrincipalIdeals := by
    intro k hk
    have hkinv : Compact (e.symm k) := (compact_iff e.symm k).mpr hk
    have hfin := (hD.finitePrincipalIdeals (e.symm k) hkinv).image e
    simpa only [image_Iic, e.apply_symm_apply] using hfin

theorem isDIDomain_iff (e : D ≃o E) : IsDIDomain D ↔ IsDIDomain E :=
  ⟨isDIDomain_map e, isDIDomain_map e.symm⟩

theorem isCountablyBasedDIDomain_iff (e : D ≃o E) :
    IsCountablyBasedDIDomain D ↔ IsCountablyBasedDIDomain E :=
  and_congr (isDIDomain_iff e) (compactElements_countable_iff e)

theorem scottContinuous (e : D ≃o E) : ScottContinuous (e : D → E) := by
  intro A _hne _hdir s hs
  exact e.isLUB_image'.mpr hs

theorem map_intrinsic_inf (e : D ≃o E) (hD : IsScottDomain D)
    (hE : IsScottDomain E) (x y : D) :
    e (hD.inf x y) = hE.inf (e x) (e y) :=
  ((isGLB_pair_iff e x y (hD.inf x y)).mpr (hD.inf_isGLB x y)).unique
    (hE.inf_isGLB (e x) (e y))

noncomputable def stableMap (e : D ≃o E) (hD : IsScottDomain D)
    (hE : IsScottDomain E) : @StableMap D E hD.semilatticeInf hE.semilatticeInf := by
  letI : SemilatticeInf D := hD.semilatticeInf
  letI : SemilatticeInf E := hE.semilatticeInf
  exact ⟨e, scottContinuous e, fun x y _hxy => map_intrinsic_inf e hD hE x y⟩

theorem stableMap_apply (e : D ≃o E) (hD : IsScottDomain D)
    (hE : IsScottDomain E) (x : D) :
    @StableMap.toFun D E hD.semilatticeInf hE.semilatticeInf (stableMap e hD hE) x = e x := rfl

end Transport

theorem isStable (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) (e : D ≃o E) :
    DIDomainClassification.IsStable D E (e : D → E) := by
  refine ⟨scottContinuous e, ?_⟩
  intro x y _hxy
  exact map_intrinsic_inf e D.isDIDomain.toIsScottDomain E.isDIDomain.toIsScottDomain x y

noncomputable def stableHom (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (e : D ≃o E) : StableHom D E := StableHom.ofFunction e (isStable D E e)

theorem stableHom_apply (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (e : D ≃o E) (x : D) : stableHom D E e x = e x := rfl

section Split

variable {D : Type u} {E : Type v} [PartialOrder D] [PartialOrder E]

/-- A monotone split identifies the source with the literal fixed-point subtype.
No domain property, continuity, stability, strictness or EP inequality is needed.
The target subtype is definitionally StableIdempotentClosure.Fixed (s ∘ r).
-/
def splitFixedOrderIso (s : D → E) (r : E → D) (hs : Monotone s)
    (hr : Monotone r) (hleft : Function.LeftInverse r s) :
    D ≃o {y : E // s (r y) = y} where
  toFun x := ⟨s x, congrArg s (hleft x)⟩
  invFun y := r y.val
  left_inv := hleft
  right_inv y := Subtype.ext y.property
  map_rel_iff' := by
    intro x y
    change s x ≤ s y ↔ x ≤ y
    constructor
    · intro hxy
      calc
        x = r (s x) := (hleft x).symm
        _ ≤ r (s y) := hr hxy
        _ = y := hleft y
    · exact fun hxy => hs hxy

theorem splitFixedOrderIso_apply (s : D → E) (r : E → D) (hs : Monotone s)
    (hr : Monotone r) (hleft : Function.LeftInverse r s) (x : D) :
    (splitFixedOrderIso s r hs hr hleft x).val = s x := rfl

theorem splitFixedOrderIso_symm_apply (s : D → E) (r : E → D) (hs : Monotone s)
    (hr : Monotone r) (hleft : Function.LeftInverse r s)
    (y : {y : E // s (r y) = y}) :
    (splitFixedOrderIso s r hs hr hleft).symm y = r y.val := rfl

omit [PartialOrder D] [PartialOrder E] in
theorem split_composite_idempotent (s : D → E) (r : E → D)
    (hleft : Function.LeftInverse r s) (y : E) : s (r (s (r y))) = s (r y) :=
  congrArg s (hleft (r y))

end Split

def stableMapSplitFixedOrderIso {D : Type u} {E : Type v}
    [SemilatticeInf D] [SemilatticeInf E] (s : StableMap D E) (r : StableMap E D)
    (hleft : Function.LeftInverse r s) : D ≃o {y : E // s (r y) = y} :=
  splitFixedOrderIso s r s.scottContinuous.monotone r.scottContinuous.monotone hleft

end DIDomainClassification.OrderIsoTransport
