import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.ScottDomains
import DIDomainClassification.Section02.BasicDomains
import DIDomainClassification.Section02.StableCategory
import Mathlib.Data.Fintype.Order
import Mathlib.Order.ULift

/-! Finite order foundations and the literal lifted two-point chain. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.FiniteOrderDomains

open OrderCore Preliminaries

theorem finite_isDcpo (D : Type u) [PartialOrder D] [Finite D] :
    OrderCore.IsDcpo D := by
  intro A hA
  obtain ⟨z, hz, hupper⟩ := hA.exists_upper_finite (Set.toFinite A) (Set.Subset.refl A)
  exact ⟨z, (fun _ hx => hupper _ hx), fun _ hu => hu hz⟩

theorem finite_isCompact {D : Type u} [PartialOrder D] [Finite D] (x : D) :
    IsCompactElement x := by
  intro A s hA hs hxs
  exact ⟨s, hA.isSup_mem_of_finite (Set.toFinite A) hs, hxs⟩

theorem finite_isAlgebraic (D : Type u) [PartialOrder D] [Finite D] :
    OrderCore.IsAlgebraicDcpo D := by
  refine ⟨finite_isDcpo D, ?_⟩
  intro x
  refine ⟨⟨⟨x, finite_isCompact x, le_rfl⟩, ?_⟩, ?_, ?_⟩
  · intro a ha b hb
    exact ⟨x, ⟨finite_isCompact x, le_rfl⟩, ha.2, hb.2⟩
  · intro a ha
    exact ha.2
  · intro y hy
    exact hy ⟨finite_isCompact x, le_rfl⟩

theorem scottContinuous_of_monotone_finite {D : Type u} {E : Type v}
    [PartialOrder D] [PartialOrder E] [Finite D] {f : D → E} (hf : Monotone f) :
    ScottContinuous f := by
  intro A hne hdir s hs
  have hmem : s ∈ A :=
    (show DirectedSet A from ⟨hne, hdir⟩).isSup_mem_of_finite (Set.toFinite A) hs
  constructor
  · rintro _ ⟨a, ha, rfl⟩
    exact hf (hs.1 ha)
  · intro z hz
    exact hz ⟨s, hmem, rfl⟩

theorem stable_of_monotone_finite_total (D : DIDomainObject.{u})
    (E : DIDomainObject.{v}) [Finite D]
    (htotal : ∀ x y : D, x ≤ y ∨ y ≤ x) {f : D → E} (hf : Monotone f) :
    IsStable D E f := by
  refine ⟨scottContinuous_of_monotone_finite hf, ?_⟩
  intro x y _hxy
  rcases htotal x y with hxy | hyx
  · rw [inf_eq_left.mpr hxy, inf_eq_left.mpr (hf hxy)]
  · rw [inf_eq_right.mpr hyx, inf_eq_right.mpr (hf hyx)]

theorem finiteCompleteLattice_isScottDomain (D : Type u)
    [CompleteLattice D] [Finite D] : IsScottDomain D :=
  ⟨finite_isAlgebraic D, ⟨⊥, fun _ => bot_le⟩,
    fun X _hX => ⟨sSup X, isLUB_sSup X⟩⟩

theorem finiteCompleteDistribLattice_isDIDomain (D : Type u)
    [CompleteDistribLattice D] [Finite D] : IsDIDomain D := by
  refine ⟨finiteCompleteLattice_isScottDomain D, ?_, fun _ _ => Set.toFinite _⟩
  intro x y z joined meet left right _hxy hj hm hl hr
  have hjoin : joined = x ⊔ y := hj.unique isLUB_pair
  have hmeet : meet = (x ⊔ y) ⊓ z := by
    rw [← hjoin]
    exact hm.unique isGLB_pair
  have hleft : left = x ⊓ z := hl.unique isGLB_pair
  have hright : right = y ⊓ z := hr.unique isGLB_pair
  rw [hmeet, hleft, hright, inf_sup_right]
  exact isLUB_pair

theorem finiteCompleteDistribLattice_isCountablyBased (D : Type u)
    [CompleteDistribLattice D] [Finite D] : IsCountablyBasedDIDomain D :=
  ⟨finiteCompleteDistribLattice_isDIDomain D, Set.to_countable _⟩

abbrev TwoCarrier := ULift.{u} BasicDomains.Two

def twoOrderIso : TwoCarrier.{u} ≃o BasicDomains.Two where
  toFun x := x.down
  invFun x := ⟨x⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

theorem two_isCountablyBased : IsCountablyBasedDIDomain TwoCarrier.{u} := by
  letI : CompleteDistribLattice TwoCarrier.{u} := Fintype.toCompleteDistribLattice _
  exact finiteCompleteDistribLattice_isCountablyBased TwoCarrier

def twoObject : CountablyBasedDIDomain.{u} where
  toDIDomainObject := DIDomainObject.ofType TwoCarrier two_isCountablyBased.1
  countableCompacts := two_isCountablyBased.2

def zero : TwoCarrier.{u} := ⟨0⟩
def one : TwoCarrier.{u} := ⟨1⟩

theorem zero_le (x : TwoCarrier.{u}) : zero ≤ x := Fin.zero_le _
theorem le_one (x : TwoCarrier.{u}) : x ≤ one := by
  change x.down.val ≤ 1
  have h := x.down.isLt
  omega

theorem zero_ne_one : zero.{u} ≠ one.{u} := by
  intro h
  have hdown := congrArg ULift.down h
  exact (by decide : (0 : BasicDomains.Two) ≠ 1) hdown

theorem eq_zero_or_one (x : TwoCarrier.{u}) : x = zero ∨ x = one := by
  rcases BasicDomains.two_eq_zero_or_one x.down with h | h
  · exact Or.inl (ULift.ext _ _ h)
  · exact Or.inr (ULift.ext _ _ h)

end DIDomainClassification.FiniteOrderDomains
