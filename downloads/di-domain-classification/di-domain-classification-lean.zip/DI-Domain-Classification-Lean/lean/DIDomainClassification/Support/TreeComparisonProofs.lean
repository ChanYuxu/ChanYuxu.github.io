import DIDomainClassification.Support.TreeEdgeBlocks
import DIDomainClassification.Support.TreeRankMaps
import DIDomainClassification.Section04.TreeBlocks
import DIDomainClassification.Support.PrefixCompletionDomain

/-! Actual native stable comparisons from proved tree maps. The infinite-
branch part follows a direct spine map and leaf extensions, an explicitly
different route from the manuscript's two intermediate comb comparisons. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TreeComparisonProofs

open Preliminaries Trees CoherenceDegree Section04 AdditionalSourceModels
variable {A B : Type u}

theorem from_edge_map (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (hp : T.IsProper) (hq : S.IsProper) (f : T.Node → S.Node)
    (hroot : f T.root = S.root)
    (hchild : ∀ {x y : T.Node}, T.IsChild x y → S.IsChild (f x) (f y))
    (hT : IsCountablyBasedDIDomain (TreeDomain T))
    (hS : IsCountablyBasedDIDomain (TreeDomain S)) :
    StableComparison (treeObject T hT) (treeObject S hS) := by
  let L := TreeEdgeBlocks.blocks T S hq f
  have hL := TreeEdgeBlocks.conditions T S hq f hroot hchild
  obtain ⟨hT', hS', hH, hRet⟩ := treeBlocks A B T S hp hq L hL.1 hL.2
  refine ⟨completionCB T hp hH, ?_, ?_⟩
  · exact PrefixCompletionDomain.two_coherent T
  · exact hRet

theorem wellFounded_comparison (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (hp : T.IsProper) (hq : S.IsProper)
    (hT : IsCountablyBasedDIDomain (TreeDomain T))
    (hS : IsCountablyBasedDIDomain (TreeDomain S))
    (wfT : T.IsWellFounded) (wfS : S.IsWellFounded)
    (hRank : T.treeRank wfT ≤ S.treeRank wfS) :
    StableComparison (treeObject T hT) (treeObject S hS) := by
  obtain ⟨f, hroot, hchild, _hBounds⟩ := TreeRankMaps.exists_rank_map T S wfT wfS hRank
  exact from_edge_map T S hp hq f hroot hchild hT hS

def spineMap (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (b : S.InfiniteBranch) (w : T.Node) : S.Node := b.node (T.depth w)

theorem spineMap_root (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (b : S.InfiniteBranch) : spineMap T S b T.root = S.root := by
  simp only [spineMap, T.depth_root, b.root_eq]

theorem spineMap_child (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (b : S.InfiniteBranch) {x y : T.Node} (hxy : T.IsChild x y) :
    S.IsChild (spineMap T S b x) (spineMap T S b y) := by
  unfold spineMap
  rw [hxy.2]
  exact b.child (T.depth x)

/-- Direct native-spine route: no source well-foundedness is assumed. -/
theorem infinite_comparison (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (hp : T.IsProper) (hq : S.IsProper)
    (hT : IsCountablyBasedDIDomain (TreeDomain T))
    (hS : IsCountablyBasedDIDomain (TreeDomain S)) (hInf : S.HasInfiniteBranch) :
    StableComparison (treeObject T hT) (treeObject S hS) := by
  obtain ⟨b⟩ := hInf
  exact from_edge_map T S hp hq (spineMap T S b)
    (spineMap_root T S b) (spineMap_child T S b) hT hS

end DIDomainClassification.TreeComparisonProofs
