import DIDomainClassification.Support.StableHomScottStructure
import DIDomainClassification.Support.OrderIsoTransport
import DIDomainClassification.Support.PrimeEventDecomposition
import DIDomainClassification.Section02.StableCategory

/-!
Generic transfer of stable-exponential closure to arbitrary intrinsic dI
codomains. The value order isomorphism is applied by actual covariant stable
composition; preservation and reflection of the native stable order are
proved from its defining equations. The event presentation is the accepted,
proved complete-prime presentation, not an assumed representation or closure.
Only actual compact elements, never the whole domain, are counted.
No source-facing stable-background wrapper is proved here.
-/

set_option autoImplicit false

universe u v w

noncomputable section

namespace DIDomainClassification.StableExponentialClosure

open Preliminaries EventStructures FiniteTraceApproximations

/-- Actual covariant composition with a value-order isomorphism. -/
def codomainOrderIso (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (F : DIDomainObject.{w}) (e : E ≃o F) : StableHom D E ≃o StableHom D F where
  toFun g := StableHom.comp (OrderIsoTransport.stableHom E F e) g
  invFun h := StableHom.comp (OrderIsoTransport.stableHom F E e.symm) h
  left_inv g := by
    apply StableHom.ext
    intro x
    exact e.symm_apply_apply (g x)
  right_inv h := by
    apply StableHom.ext
    intro x
    exact e.apply_symm_apply (h x)
  map_rel_iff' := by
    intro g h
    constructor
    · intro hgh x y hxy
      have heq := hgh x y hxy
      change e (g x) = e (g y) ⊓ e (h x) at heq
      apply e.injective
      exact heq.trans
        (OrderIsoTransport.map_intrinsic_inf e E.isDIDomain.toIsScottDomain
          F.isDIDomain.toIsScottDomain (g y) (h x)).symm
    · intro hgh x y hxy
      change e (g x) = e (g y) ⊓ e (h x)
      exact (congrArg e (hgh x y hxy)).trans
        (OrderIsoTransport.map_intrinsic_inf e E.isDIDomain.toIsScottDomain
          F.isDIDomain.toIsScottDomain (g y) (h x))

theorem codomainOrderIso_apply (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (F : DIDomainObject.{w}) (e : E ≃o F) (g : StableHom D E) (x : D) :
    codomainOrderIso D E F e g x = e (g x) := rfl

theorem codomainOrderIso_symm_apply (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (F : DIDomainObject.{w}) (e : E ≃o F) (h : StableHom D F) (x : D) :
    (codomainOrderIso D E F e).symm h x = e.symm (h x) := rfl

/-- Literal identification of the raw-source result with the bundled carrier. -/
theorem configurationTarget_isDIDomain (D : DIDomainObject.{u})
    {A : Type v} [PartialOrder A] (E : FinitaryPrimeEventStructure A) :
    IsDIDomain (StableHom D (configurationObject E)) :=
  hom_isDIDomain D.isDIDomain

theorem configurationTarget_isCountablyBasedDIDomain (D : DIDomainObject.{u})
    {A : Type v} [PartialOrder A] [Countable A] (E : FinitaryPrimeEventStructure A)
    (hK : (CompactElements D).Countable) :
    IsCountablyBasedDIDomain (StableHom D (configurationObject E)) :=
  hom_isCountablyBasedDIDomain D.isDIDomain hK

abbrev PrimeEventCarrier (E : DIDomainObject.{v}) : Type v :=
  PrimeEventPresentation.Carrier (FinitePrimeDecomposition.IsCompletePrime (D := E))

def primeEventStructure (E : DIDomainObject.{v}) :
    FinitaryPrimeEventStructure (PrimeEventCarrier E) :=
  PrimeEventPresentation.eventStructure E.isDIDomain
    FinitePrimeDecomposition.IsCompletePrime
    (fun _ hp => FinitePrimeDecomposition.completePrime_isCompact hp)

def primeEventOrderIso (E : DIDomainObject.{v}) :
    E ≃o Configuration (primeEventStructure E) :=
  PrimeEventPresentation.representationOrderIso E.isDIDomain
    FinitePrimeDecomposition.IsCompletePrime
    (fun _ hp => FinitePrimeDecomposition.completePrime_isCompact hp)
    (fun p hp => (FinitePrimeDecomposition.isCompletePrime_iff_lub p).mp hp)
    (FinitePrimeDecomposition.point_isLUB_primes_below E.isDIDomain)

theorem primeEventCarrier_countable (E : DIDomainObject.{v})
    (hK : (CompactElements E).Countable) : Countable (PrimeEventCarrier E) :=
  PrimeEventPresentation.carrier_countable FinitePrimeDecomposition.IsCompletePrime
    (fun _ hp => FinitePrimeDecomposition.completePrime_isCompact hp) hK

/-- General intrinsic closure: neither domain needs to have a countable basis. -/
theorem stableHom_isDIDomain (D : DIDomainObject.{u}) (E : DIDomainObject.{v}) :
    @IsDIDomain (StableHom D E) StableHom.instPartialOrder := by
  let e := codomainOrderIso D E (configurationObject (primeEventStructure E))
    (primeEventOrderIso E)
  exact (OrderIsoTransport.isDIDomain_iff e).mpr
    (configurationTarget_isDIDomain D (primeEventStructure E))

/-- Compact-countability uses only the two actual compact-element sets. -/
theorem stableHom_isCountablyBasedDIDomain_of_compacts
    (D : DIDomainObject.{u}) (E : DIDomainObject.{v})
    (hD : (CompactElements D).Countable) (hE : (CompactElements E).Countable) :
    @IsCountablyBasedDIDomain (StableHom D E) StableHom.instPartialOrder := by
  letI : Countable (PrimeEventCarrier E) := primeEventCarrier_countable E hE
  let e := codomainOrderIso D E (configurationObject (primeEventStructure E))
    (primeEventOrderIso E)
  exact (OrderIsoTransport.isCountablyBasedDIDomain_iff e).mpr
    (configurationTarget_isCountablyBasedDIDomain D (primeEventStructure E) hD)

/-- The requested generic native StableHom export, with no carrier-countability
or function-space-closure premise. The output uses the accepted stable order. -/
theorem stableHom_isCountablyBasedDIDomain
    (D : CountablyBasedDIDomain.{u}) (E : CountablyBasedDIDomain.{v}) :
    @IsCountablyBasedDIDomain
      (StableHom D.toDIDomainObject E.toDIDomainObject) StableHom.instPartialOrder :=
  stableHom_isCountablyBasedDIDomain_of_compacts D.toDIDomainObject E.toDIDomainObject
    D.countableCompacts E.countableCompacts

end DIDomainClassification.StableExponentialClosure
