import DIDomainClassification.Section04.CausalAntichains
import DIDomainClassification.Section04.CausalRetraction
import DIDomainClassification.Section02.CoherenceCharacterization

/-!
Literal configuration unions, principal-configuration MIC families and finite
selection from an arbitrary inconsistent family. The event carrier is arbitrary.
All boundedness, MIC and cardinality conclusions are proved here; no coherence
degree or finite maximum is assumed. Existing lower-interior consistency is
reused on a PROVED lower union, never confused with causal downclosure.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.QualitativeConfigurationMIC

open Preliminaries EventStructures CoherenceDegree FiniteCausalConflicts

variable {A : Type u} [PartialOrder A]

def unionValues {E : FinitaryPrimeEventStructure A} (F : Set (Configuration E)) : Set A :=
  {a | ∃ X ∈ F, a ∈ X.val}

theorem union_isLower (E : FinitaryPrimeEventStructure A) (F : Set (Configuration E)) :
    IsLowerSet (unionValues F) := by
  intro b a hab
  rintro ⟨X, hX, hbX⟩
  exact ⟨X, hX, X.property.1 hab hbX⟩

theorem bounded_iff_union_configuration (E : FinitaryPrimeEventStructure A)
    (F : Set (Configuration E)) : BddAbove F ↔ IsConfiguration E (unionValues F) := by
  constructor
  · rintro ⟨Y, hY⟩
    refine ⟨union_isLower E F, ?_⟩
    intro S hS hsub
    apply Y.property.2 S hS
    intro a ha
    obtain ⟨X, hX, haX⟩ := hsub ha
    exact hY hX haX
  · intro hF
    refine ⟨⟨unionValues F, hF⟩, ?_⟩
    intro X hX a haX
    exact ⟨X, hX, haX⟩

theorem bounded_iff_avoids (E : FinitaryPrimeEventStructure A)
    (F : Set (Configuration E)) :
    BddAbove F ↔ ∀ H ∈ causalConflictFamily E, ¬ H ⊆ unionValues F := by
  constructor
  · intro hF H hH hHU
    let X : Configuration E := ⟨unionValues F, (bounded_iff_union_configuration E F).mp hF⟩
    exact CausalCoverSupport.configuration_avoids E X H hH hHU
  · intro hAvoid
    let Y : QualitativeCover E := ⟨unionValues F, hAvoid⟩
    have h := CausalCoverSupport.interior_isConfiguration E Y
    change IsConfiguration E (lowerInterior (unionValues F)) at h
    rw [lowerInterior_eq_of_lower (union_isLower E F)] at h
    exact (bounded_iff_union_configuration E F).mpr h

theorem unbounded_contains_conflict (E : FinitaryPrimeEventStructure A)
    (F : Set (Configuration E)) (hF : ¬ BddAbove F) :
    ∃ H ∈ causalConflictFamily E, H ⊆ unionValues F := by
  by_contra hNo
  apply hF
  apply (bounded_iff_avoids E F).mpr
  intro H hH hsub
  exact hNo ⟨H, hH, hsub⟩

theorem principal_injective (E : FinitaryPrimeEventStructure A) :
    Function.Injective (ConfigurationDomain.principal E) := by
  intro a b heq
  apply le_antisymm
  · change a ∈ (ConfigurationDomain.principal E b).val
    rw [← heq]
    exact le_rfl
  · change b ∈ (ConfigurationDomain.principal E a).val
    rw [heq]
    exact le_rfl

def principalFamily (E : FinitaryPrimeEventStructure A) (H : Set A) : Set (Configuration E) :=
  ConfigurationDomain.principal E '' H

theorem principalFamily_union (E : FinitaryPrimeEventStructure A) (H : Set A) :
    unionValues (principalFamily E H) = downClosure H := by
  ext a
  constructor
  · rintro ⟨X, ⟨b, hb, rfl⟩, hab⟩
    exact ⟨b, hb, hab⟩
  · rintro ⟨b, hb, hab⟩
    exact ⟨ConfigurationDomain.principal E b, ⟨b, hb, rfl⟩, hab⟩

theorem principalFamily_ncard (E : FinitaryPrimeEventStructure A) (H : Set A) :
    (principalFamily E H).ncard = H.ncard :=
  Set.ncard_image_of_injective H (principal_injective E)

/-- Every actual causal conflict gives the printed family of principal
configurations as a MIC family, with its original event multiplicity retained. -/
theorem principalFamily_mic (E : FinitaryPrimeEventStructure A)
    (hD : IsScottDomain (Configuration E)) (H : Set A) (hH : H ∈ causalConflictFamily E) :
    IsMinimallyInconsistent hD (principalFamily E H) := by
  obtain ⟨U, hU, rfl⟩ := hH
  obtain ⟨hFinite, _hAnti, hDown, _hCard⟩ := (Section04.causalAntichains A E).2.1 U hU
  refine ⟨hFinite.image _, ?_, ?_⟩
  · rintro ⟨Y, hY⟩
    apply hU.2.2.1
    apply Y.property.2 U hU.1
    intro a ha
    have haDown : a ∈ downClosure (maximalEvents U) := hDown.subset ha
    obtain ⟨b, hb, hab⟩ := haDown
    exact hY ⟨b, hb, rfl⟩ hab
  · intro N hN
    let V := unionValues N
    have hVU : V ⊆ U := by
      rintro a ⟨X, hXN, haX⟩
      obtain ⟨b, hb, rfl⟩ := hN.1 hXN
      exact hU.2.1 haX hb.1
    have hProper : V ⊂ U := by
      refine ⟨hVU, ?_⟩
      intro hUV
      apply hN.2
      rintro X ⟨a, ha, rfl⟩
      obtain ⟨Y, hYN, haY⟩ := hUV ha.1
      obtain ⟨b, hb, rfl⟩ := hN.1 hYN
      have hba : b = a := ha.2 b hb.1 haY
      simpa only [hba] using hYN
    have hCon : V ∈ E.Con := hU.2.2.2 V hProper (union_isLower E N)
    apply (bounded_iff_union_configuration E N).mpr
    exact ⟨union_isLower E N, fun S _hS hSV => E.hereditary hSV hCon⟩

/-- Select one original family member for each maximal conflicting event.
The resulting finite subfamily is still inconsistent and has no more members
than H. The original family itself may be arbitrary and infinite. -/
theorem select_finite_unbounded (E : FinitaryPrimeEventStructure A)
    (F : Set (Configuration E)) (H : Set A) (hH : H ∈ causalConflictFamily E)
    (hHF : H ⊆ unionValues F) :
    ∃ N : Set (Configuration E), N ⊆ F ∧ N.Finite ∧ N.ncard ≤ H.ncard ∧ ¬ BddAbove N := by
  classical
  have hHfinite := conflict_member_finite E hH
  letI : Finite H := hHfinite.to_subtype
  have hex : ∀ a : H, ∃ X ∈ F, a.val ∈ X.val := fun a => hHF a.property
  choose pick hpick hcontains using hex
  let N : Set (Configuration E) := pick '' (Set.univ : Set H)
  have hNF : N ⊆ F := by
    rintro X ⟨a, _ha, rfl⟩
    exact hpick a
  have hNfinite : N.Finite := (Set.toFinite (Set.univ : Set H)).image pick
  have hCard : N.ncard ≤ H.ncard := by
    calc
      N.ncard ≤ (Set.univ : Set H).ncard := Set.ncard_image_le
      _ = H.ncard := by rw [Set.ncard_univ, Nat.card_coe_set_eq]
  refine ⟨N, hNF, hNfinite, hCard, ?_⟩
  intro hNbound
  apply ((bounded_iff_avoids E N).mp hNbound) H hH
  intro a ha
  exact ⟨pick ⟨a, ha⟩, ⟨⟨a, ha⟩, Set.mem_univ _, rfl⟩, hcontains ⟨a, ha⟩⟩

theorem nCoherent_iff_conflict_bound (E : FinitaryPrimeEventStructure A)
    (hD : IsScottDomain (Configuration E)) (n : ℕ) (hn : 2 ≤ n) :
    IsNCoherent hD n hn ↔ ∀ H ∈ causalConflictFamily E, H.ncard ≤ n := by
  constructor
  · intro hN H hH
    have h := hN (principalFamily E H) (principalFamily_mic E hD H hH)
    simpa only [principalFamily_ncard] using h
  · intro hBound
    apply (CoherenceDegree.coherenceCharacterization (Configuration E) hD n hn).mpr
    intro M hSmall
    by_contra hMbad
    obtain ⟨H, hH, hHM⟩ := unbounded_contains_conflict E M hMbad
    obtain ⟨N, hNM, _hNfinite, hCard, hNbad⟩ := select_finite_unbounded E M H hH hHM
    exact hNbad (hSmall N hNM _hNfinite (hCard.trans (hBound H hH)))

end DIDomainClassification.QualitativeConfigurationMIC
