import DIDomainClassification.Support.ForestGraft

/-!
Genuine countable-rank realization for the intrinsic relative-prefix tree model.
The transfinite construction is a forest indexed by all smaller ordinals. Only
this actual index is countable; Countable.toSmall justifies its ordinal iSup.
No supplied tree/rank realization or source degree conclusion is assumed.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.CountableTreeRankRealization

open Trees

theorem countable_Iio_of_card_le_aleph0 (α : Ordinal.{u})
    (hα : α.card ≤ Cardinal.aleph0) : Countable (Set.Iio α) := by
  apply Cardinal.mk_le_aleph0_iff.mp
  rw [Cardinal.mk_Iio_ordinal]
  exact Cardinal.lift_le_aleph0.mpr hα

/-- All predecessor successors have supremum α, including α=0. The explicit
smallness premise rules out an unsupported conditional-supremum fallback. -/
theorem iSup_predecessor_succ (α : Ordinal.{u}) [Small.{u} (Set.Iio α)] :
    (⨆ β : Set.Iio α, β.val + 1) = α := by
  apply le_antisymm (Ordinal.iSup_add_one_le fun β : Set.Iio α => β.property)
  by_contra h
  have hlt : (⨆ β : Set.Iio α, β.val + 1) < α := lt_of_not_ge h
  let β : Set.Iio α := ⟨⨆ γ : Set.Iio α, γ.val + 1, hlt⟩
  have hle := Ordinal.le_iSup (fun γ : Set.Iio α => γ.val + 1) β
  have hsucc : (⨆ γ : Set.Iio α, γ.val + 1) <
      (⨆ γ : Set.Iio α, γ.val + 1) + 1 := by
    simpa only [Order.succ_eq_add_one] using
      Order.lt_succ (⨆ γ : Set.Iio α, γ.val + 1)
  exact (not_le_of_gt hsucc) hle

/-- Positive native root rank and actual WF suffice for source properness. -/
theorem isProper_of_pos_rank {A : Type u} (T : RootedPrefixTree A)
    (hT : T.IsWellFounded) (hpos : 0 < T.treeRank hT) : T.IsProper := by
  have hpair : ∃ v : T.Node, v ≠ T.root := by
    by_contra h
    push Not at h
    have hleaf : T.IsLeaf T.root := fun v _hv => h v
    have hzero : T.treeRank hT = 0 := T.nodeRank_leaf hT T.root hleaf
    exact (ne_of_gt hpos) hzero
  obtain ⟨v, hv⟩ := hpair
  apply T.isProper_iff.mpr
  refine ⟨⟨⟨v, T.root, hv⟩⟩, ?_⟩
  intro x
  exact FiniteLeafColourPruning.exists_leaf_extension T hT x

/-- Every ordinal of at most countable cardinality occurs as the ACTUAL native
root rank of a countable, normalized, well-founded prefix tree over ULift ℕ.
Rank zero is allowed and requires no nontriviality assumption. -/
theorem exists_tree_rank (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0) :
    ∃ T : RootedPrefixTree (ULift.{u} ℕ), T.rootList = [] ∧
      ∃ hT : T.IsWellFounded, T.treeRank hT = α := by
  refine WellFoundedLT.induction (motive := fun β : Ordinal.{u} =>
    β.card ≤ Cardinal.aleph0 →
      ∃ T : RootedPrefixTree (ULift.{u} ℕ), T.rootList = [] ∧
        ∃ hT : T.IsWellFounded, T.treeRank hT = β) α ?_ hα
  intro α ih hα
  letI : Countable (Set.Iio α) := countable_Iio_of_card_le_aleph0 α hα
  have hex : ∀ β : Set.Iio α,
      ∃ T : RootedPrefixTree (ULift.{u} ℕ), T.rootList = [] ∧
        ∃ hT : T.IsWellFounded, T.treeRank hT = β.val := fun β =>
    ih β.val β.property ((Ordinal.card_le_card β.property.le).trans hα)
  choose S hroot hS hrank using hex
  obtain ⟨tag, htag⟩ := Countable.exists_injective_nat (Set.Iio α)
  let liftedTag : Set.Iio α → ULift.{u} ℕ := fun β => ULift.up (tag β)
  have hlifted : Function.Injective liftedTag := by
    intro β γ h
    apply htag
    exact congrArg ULift.down h
  refine ⟨TreeGrafting.forest S liftedTag hroot, rfl,
    TreeGrafting.forest_isWellFounded S liftedTag hroot hlifted hS, ?_⟩
  rw [TreeGrafting.forest_treeRank_eq S liftedTag hroot hlifted hS]
  simp_rw [hrank]
  exact iSup_predecessor_succ α

/-- A chosen actual construction, justified by the preceding proved existence. -/
def tree (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0) :
    RootedPrefixTree (ULift.{u} ℕ) := Classical.choose (exists_tree_rank α hα)

theorem tree_root (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0) :
    (tree α hα).rootList = [] := (Classical.choose_spec (exists_tree_rank α hα)).1

theorem tree_wellFounded (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0) :
    (tree α hα).IsWellFounded :=
  Classical.choose (Classical.choose_spec (exists_tree_rank α hα)).2

theorem tree_rank (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0) :
    (tree α hα).treeRank (tree_wellFounded α hα) = α :=
  Classical.choose_spec (Classical.choose_spec (exists_tree_rank α hα)).2

theorem tree_node_countable (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0) :
    Countable (tree α hα).Node := inferInstance

theorem tree_proper_of_pos (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0)
    (hpos : 0 < α) : (tree α hα).IsProper := by
  apply isProper_of_pos_rank (tree α hα) (tree_wellFounded α hα)
  rw [tree_rank]
  exact hpos

end DIDomainClassification.CountableTreeRankRealization

