import DIDomainClassification.Support.PredicateTriggers
import DIDomainClassification.Support.OrderIsoTransport

/-! The explicit clique predicate and its inverse, with the native stable order. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.PredicateCliqueIso
open OrderCore Preliminaries CoherenceDegree FiniteOrderDomains
open Section03.StableFunctionModels Section04.AdditionalSourceModels
open Section04.PredicateModels Section02.BinaryCliqueModels PredicateTriggers

variable (D : CountablyBasedDIDomain.{u})

theorem values_one_iff (M : CliqueCarrier (graph D)) (x : Core D) :
    fromCliqueValues D M x = one ↔
      ∃ k : ↥(CompactElements (Core D)), k ∈ M.val ∧ k.val ≤ x := by
  classical
  by_cases h : ∃ k : ↥(CompactElements (Core D)), k ∈ M.val ∧ k.val ≤ x
  · simp [fromCliqueValues, h]
  · simp [fromCliqueValues, h, zero_ne_one]

theorem values_monotone (M : CliqueCarrier (graph D)) :
    Monotone (fromCliqueValues D M) := by
  intro x y hxy
  rcases eq_zero_or_one (fromCliqueValues D M x) with hx | hx
  · rw [hx]
    exact zero_le _
  · have hy : fromCliqueValues D M y = one := by
      obtain ⟨k, hk, hkx⟩ := (values_one_iff D M x).mp hx
      exact (values_one_iff D M y).mpr ⟨k, hk, hkx.trans hxy⟩
    rw [hx, hy]

theorem values_continuous (M : CliqueCarrier (graph D)) :
    ScottContinuous (fromCliqueValues D M) := by
  intro X hne hdir s hs
  constructor
  · rintro _ ⟨x, hx, rfl⟩
    exact values_monotone D M (hs.1 hx)
  · intro z hz
    rcases eq_zero_or_one (fromCliqueValues D M s) with hzero | hone
    · rw [hzero]
      exact zero_le _
    · obtain ⟨k, hk, hks⟩ := (values_one_iff D M s).mp hone
      obtain ⟨x, hx, hkx⟩ := k.property ⟨hne, hdir⟩ hs hks
      have hfx := (values_one_iff D M x).mpr ⟨k, hk, hkx⟩
      calc
        fromCliqueValues D M s = one := hone
        _ = fromCliqueValues D M x := hfx.symm
        _ ≤ z := hz ⟨x, hx, rfl⟩

theorem values_stable (M : CliqueCarrier (graph D)) :
    IsStable D.toDIDomainObject twoObject.{u}.toDIDomainObject
      (fromCliqueValues D M) := by
  refine ⟨values_continuous D M, ?_⟩
  intro x y hxy
  apply le_antisymm
  · exact le_inf (values_monotone D M inf_le_left)
      (values_monotone D M inf_le_right)
  · rcases eq_zero_or_one (fromCliqueValues D M x) with hx | hx
    · rw [hx]
      exact inf_le_left.trans (FiniteOrderDomains.zero_le _)
    · rcases eq_zero_or_one (fromCliqueValues D M y) with hy | hy
      · rw [hy]
        exact inf_le_right.trans (FiniteOrderDomains.zero_le _)
      · obtain ⟨k, hk, hkx⟩ := (values_one_iff D M x).mp hx
        obtain ⟨l, hl, hly⟩ := (values_one_iff D M y).mp hy
        obtain ⟨b, hxb, hyb⟩ := hxy
        have hkl := clique_eq_of_compatible D M hk hl
          ⟨b, hkx.trans hxb, hly.trans hyb⟩
        subst l
        have hm := (values_one_iff D M (x ⊓ y)).mpr ⟨k, hk, le_inf hkx hly⟩
        rw [hx, hy, inf_idem, hm]

def cliquePredicate (M : CliqueCarrier (graph D)) : StableSpace D twoObject.{u} :=
  StableHom.ofFunction (fromCliqueValues D M) (values_stable D M)

theorem cliquePredicate_apply (M : CliqueCarrier (graph D)) (x : Core D) :
    cliquePredicate D M x = fromCliqueValues D M x := rfl

theorem triggers_cliquePredicate (M : CliqueCarrier (graph D)) :
    minimalTriggers D (cliquePredicate D M) = M.val := by
  apply Set.Subset.antisymm
  · intro k hk
    obtain ⟨m, hm, hmk⟩ := (values_one_iff D M k.val).mp hk.1
    have heq : m.val = k.val := trigger_eq_of_le D _ hk hmk
      ((values_one_iff D M m.val).mpr ⟨m, hm, le_rfl⟩)
    exact (Subtype.ext heq : m = k) ▸ hm
  · intro k hk
    refine ⟨(values_one_iff D M k.val).mpr ⟨k, hk, le_rfl⟩, ?_⟩
    intro l hl
    apply (not_one_iff_zero _).mp
    intro hfl
    obtain ⟨m, hm, hml⟩ := (values_one_iff D M l).mp hfl
    have hmk := clique_eq_of_compatible D M hm hk ⟨k.val, hml.trans hl.le, le_rfl⟩
    subst m
    exact (not_le_of_gt hl) hml

theorem cliquePredicate_triggers (f : StableSpace D twoObject.{u}) :
    cliquePredicate D (triggerClique D f) = f := by
  apply StableHom.ext
  intro x
  rcases eq_zero_or_one (f x) with hx | hx
  · have hnot : ¬ ∃ k ∈ minimalTriggers D f, k.val ≤ x := by
      intro h
      exact zero_ne_one (hx.symm.trans ((reconstruct D f x).mpr h))
    exact (not_one_iff_zero _).mp
      (fun h => hnot ((values_one_iff D (triggerClique D f) x).mp h)) |>.trans hx.symm
  · exact ((values_one_iff D (triggerClique D f) x).mpr
      ((reconstruct D f x).mp hx)).trans hx.symm

theorem order_iff (f g : StableSpace D twoObject.{u}) :
    f ≤ g ↔ minimalTriggers D f ⊆ minimalTriggers D g := by
  constructor
  · intro hfg k hk
    have hgk : g k.val = one := by
      apply (one_le_iff _).mp
      have h := hfg k.val k.val le_rfl
      have hp : f k.val ≤ g k.val := h.trans_le inf_le_right
      simpa only [hk.1] using hp
    obtain ⟨l, hl, hlk⟩ := (reconstruct D g k.val).mp hgk
    have hfl : f l.val = one := by
      rw [hfg l.val k.val hlk, hk.1, hl.1, inf_idem]
    have heq := trigger_eq_of_le D f hk hlk hfl
    exact (Subtype.ext heq : l = k) ▸ hl
  · intro hfg x y hxy
    have hpoint : ∀ z : Core D, f z ≤ g z := by
      intro z
      rcases eq_zero_or_one (f z) with hz | hz
      · rw [hz]; exact zero_le _
      · obtain ⟨k, hk, hkz⟩ := (reconstruct D f z).mp hz
        have hg := (reconstruct D g z).mpr ⟨k, hfg hk, hkz⟩
        rw [hz, hg]
    apply le_antisymm
    · exact le_inf ((StableHom.isStable f).1.monotone hxy) (hpoint x)
    · rcases eq_zero_or_one (f y) with hy | hy
      · rw [hy]
        exact inf_le_left.trans (FiniteOrderDomains.zero_le _)
      · rcases eq_zero_or_one (g x) with hx | hx
        · rw [hx]
          exact inf_le_right.trans (FiniteOrderDomains.zero_le _)
        · obtain ⟨k, hk, hky⟩ := (reconstruct D f y).mp hy
          obtain ⟨l, hl, hlx⟩ := (reconstruct D g x).mp hx
          have hkl := triggers_eq_of_compatible D g (hfg hk) hl
            ⟨y, hky, hlx.trans hxy⟩
          subst l
          have hfx := (reconstruct D f x).mpr ⟨k, hk, hlx⟩
          rw [hy, hx, inf_idem, hfx]

def orderIso : StableSpace D twoObject.{u} ≃o CliqueCarrier (graph D) where
  toFun := triggerClique D
  invFun := cliquePredicate D
  left_inv := cliquePredicate_triggers D
  right_inv M := Subtype.ext (triggers_cliquePredicate D M)
  map_rel_iff' := (order_iff D _ _).symm

def cliqueCountablyBased : IsCountablyBasedDIDomain (CliqueCarrier (graph D)) :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff (orderIso D)).mp
    (CountablyBasedDIDomain.isCountablyBased (exponential D twoObject.{u}))

def stableIso : exponential D twoObject.{u} ≅
    cbObject (CliqueCarrier (graph D)) (cliqueCountablyBased D) where
  hom := OrderIsoTransport.stableHom (exponential D twoObject.{u}).toDIDomainObject
    (cbObject _ (cliqueCountablyBased D)).toDIDomainObject (orderIso D)
  inv := OrderIsoTransport.stableHom (cbObject _ (cliqueCountablyBased D)).toDIDomainObject
    (exponential D twoObject.{u}).toDIDomainObject (orderIso D).symm
  hom_inv_id := StableHom.ext (orderIso D).symm_apply_apply
  inv_hom_id := StableHom.ext (orderIso D).apply_symm_apply

end DIDomainClassification.PredicateCliqueIso
