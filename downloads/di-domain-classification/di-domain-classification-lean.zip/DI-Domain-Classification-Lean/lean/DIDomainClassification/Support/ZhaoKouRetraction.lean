import DIDomainClassification.Support.ZhaoKouCodes
import DIDomainClassification.Section02.RetractionCalculus
import DIDomainClassification.Section02.TwoRetract

/-! The actual compact-code graph embedding gives literal stable image and
preimage maps. The proved predicate-clique isomorphism and a proved two-point
split then yield a retraction from W, with its native stable function order. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ZhaoKouRetraction

open Preliminaries CoherenceDegree FiniteOrderDomains
open Section02 Section02.BinaryCliqueModels Section03.StableFunctionModels
open Section04.AdditionalSourceModels Section04.PredicateModels ZhaoKouCodes

theorem trans {D E F : DIDomainObject.{u}}
    (hDE : HasStableRetraction D E) (hEF : HasStableRetraction E F) :
    HasStableRetraction D F := by
  obtain ⟨s, r, hD⟩ := hDE
  obtain ⟨t, q, hE⟩ := hEF
  exact (retractionComposition D E F s r t q hD hE).2

theorem ofOrderIso (D E : DIDomainObject.{u}) (e : D ≃o E) :
    HasStableRetraction D E :=
  ⟨OrderIsoTransport.stableHom D E e, OrderIsoTransport.stableHom E D e.symm,
    e.symm_apply_apply⟩

theorem graph_into_predicates {A : Type u} [Countable A] (G : SimpleGraph A)
    (hG : IsDIDomain (CliqueCarrier G)) :
    HasStableRetraction (CliqueStableMaps.core G hG)
      (Core (exponential baseObject.{u} twoObject.{u})) := by
  obtain ⟨index, hi⟩ := Countable.exists_injective_nat A
  let H := graph baseObject.{u}
  let hH := PredicateCliqueIso.cliqueCountablyBased baseObject.{u}
  have hGraph : HasStableRetraction (CliqueStableMaps.core G hG)
      (CliqueStableMaps.core H hH.1) :=
    CliqueStableMaps.hasRetraction G H (compactCode G index)
      (compactCode_injective G index hi) (induced_graph G index hi) hG hH.1
  have hIso : HasStableRetraction (CliqueStableMaps.core H hH.1)
      (Core (exponential baseObject.{u} twoObject.{u})) :=
    ofOrderIso _ _ (PredicateCliqueIso.orderIso baseObject.{u}).symm
  exact trans hGraph hIso

theorem predicates_into_W : HasStableRetraction
    (Core (exponential baseObject.{u} twoObject.{u}))
    (Core (universalTwoObject baseCertificate.{u})) := by
  have hNontrivial : ∃ x y : Core baseObject.{u}, x ≠ y := by
    refine ⟨fun _ => TwoExponentialOrderIso.emptyCube,
      fun _ => TwoExponentialOrderIso.atomOneCube, ?_⟩
    intro h
    exact TwoExponentialOrderIso.empty_ne_atomOne (congrFun h 0)
  have hTwo : HasStableRetraction (Core twoObject.{u}) (Core baseObject.{u}) :=
    (twoRetract (Core baseObject.{u}) hNontrivial).2
  obtain ⟨s, r, hleft⟩ := hTwo
  let S : StableHom (Core (exponential baseObject.{u} twoObject.{u}))
      (Core (universalTwoObject baseCertificate.{u})) :=
    RawStableFunctionOperators.postcompose (Core baseObject.{u}) (Core twoObject.{u})
      (Core baseObject.{u}) s
  let R : StableHom (Core (universalTwoObject baseCertificate.{u}))
      (Core (exponential baseObject.{u} twoObject.{u})) :=
    RawStableFunctionOperators.postcompose (Core baseObject.{u}) (Core baseObject.{u})
      (Core twoObject.{u}) r
  refine ⟨S, R, ?_⟩
  intro f
  apply StableHom.ext
  intro x
  change r (s (f x)) = f x
  exact hleft (f x)

theorem graph_into_W {A : Type u} [Countable A] (G : SimpleGraph A)
    (hG : IsDIDomain (CliqueCarrier G)) :
    HasStableRetraction (CliqueStableMaps.core G hG)
      (Core (universalTwoObject baseCertificate.{u})) :=
  trans (graph_into_predicates G hG) predicates_into_W

end DIDomainClassification.ZhaoKouRetraction
