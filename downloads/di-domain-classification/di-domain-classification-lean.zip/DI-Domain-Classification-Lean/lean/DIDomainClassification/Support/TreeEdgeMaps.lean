import DIDomainClassification.Section02.Trees

/-! Native prefix-tree consequences of a root/child-preserving map.
No global injectivity, leaf preservation, well-foundedness or finite branching
is assumed. Every prefix and depth is the literal accepted tree operation. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeEdgeMaps

open Trees

variable {A : Type u} {B : Type v}

def parent (T : RootedPrefixTree A) (w : T.Node) : T.Node :=
  T.prefixAt w (T.depth w - 1)

theorem depth_parent (T : RootedPrefixTree A) (w : T.Node) :
    T.depth (parent T w) = T.depth w - 1 :=
  T.depth_prefixAt w (Nat.sub_le _ _)

theorem parent_child (T : RootedPrefixTree A) (w : T.Node) (hw : w ≠ T.root) :
    T.IsChild (parent T w) w := by
  refine ⟨T.prefixAt_le w _, ?_⟩
  rw [depth_parent]
  have hpos : T.depth w ≠ 0 := fun hz => hw ((T.depth_eq_zero_iff w).mp hz)
  omega

theorem parent_depth_lt (T : RootedPrefixTree A) (w : T.Node) (hw : w ≠ T.root) :
    T.depth (parent T w) < T.depth w := by
  have hc := (parent_child T w hw).2
  omega

theorem parent_eq_of_child (T : RootedPrefixTree A) {x y : T.Node}
    (hxy : T.IsChild x y) : parent T y = x := by
  have hle : x ≤ parent T y := T.le_prefixAt hxy.1 (by have := hxy.2; omega)
  have hd : T.depth x = T.depth (parent T y) := by
    rw [depth_parent]
    have := hxy.2
    omega
  exact (T.eq_of_le_of_depth_eq hle hd).symm

theorem same_depth_ancestors (T : RootedPrefixTree A) {x y z : T.Node}
    (hx : x ≤ z) (hy : y ≤ z) (hd : T.depth x = T.depth y) : x = y := by
  rcases List.prefix_or_prefix_of_prefix hx hy with hxy | hyx
  · exact T.eq_of_le_of_depth_eq hxy hd
  · exact (T.eq_of_le_of_depth_eq hyx hd.symm).symm

variable (T : RootedPrefixTree A) (S : RootedPrefixTree B) (f : T.Node → S.Node)
    (hroot : f T.root = S.root)
    (hchild : ∀ {x y : T.Node}, T.IsChild x y → S.IsChild (f x) (f y))

include hroot hchild

theorem depth_preserved (w : T.Node) : S.depth (f w) = T.depth w := by
  refine (measure T.depth).wf.induction (C := fun w => S.depth (f w) = T.depth w) w ?_
  intro w ih
  by_cases hw : w = T.root
  · subst w
    rw [hroot, S.depth_root, T.depth_root]
  · have hp := ih (parent T w) (parent_depth_lt T w hw)
    calc
      S.depth (f w) = S.depth (f (parent T w)) + 1 := (hchild (parent_child T w hw)).2
      _ = T.depth (parent T w) + 1 := congrArg (fun n : ℕ => n + 1) hp
      _ = T.depth w := (parent_child T w hw).2.symm

omit hroot in
theorem prefix_monotone : Monotone f := by
  intro x w hxw
  have all : ∀ w : T.Node, ∀ x : T.Node, x ≤ w → f x ≤ f w := by
    intro w
    refine (measure T.depth).wf.induction
      (C := fun w => ∀ x : T.Node, x ≤ w → f x ≤ f w) w ?_
    intro w ih x hxw
    by_cases heq : x = w
    · subst x
      exact le_rfl
    · have hlt : T.depth x < T.depth w := by
        have hle := T.depth_mono hxw
        have hne : T.depth x ≠ T.depth w := fun hd => heq (T.eq_of_le_of_depth_eq hxw hd)
        omega
      have hw : w ≠ T.root := by
        intro heqRoot
        rw [heqRoot, T.depth_root] at hlt
        omega
      have hxp : x ≤ parent T w := T.le_prefixAt hxw (by omega)
      exact (ih (parent T w) (parent_depth_lt T w hw) x hxp).trans
        (hchild (parent_child T w hw)).1
  exact all w x hxw

theorem injective_on_path (w : T.Node) : Set.InjOn f (T.pathTo w) := by
  intro x hx y hy hxy
  apply same_depth_ancestors T hx hy
  calc
    T.depth x = S.depth (f x) := (depth_preserved T S f hroot hchild x).symm
    _ = S.depth (f y) := congrArg S.depth hxy
    _ = T.depth y := depth_preserved T S f hroot hchild y

theorem image_path (w : T.Node) : f '' T.pathTo w = S.pathTo (f w) := by
  ext z
  constructor
  · rintro ⟨x, hx, rfl⟩
    exact prefix_monotone T S f hchild hx
  · intro hz
    have hn : S.depth z ≤ T.depth w := by
      have h := S.depth_mono hz
      rw [depth_preserved T S f hroot hchild w] at h
      exact h
    let x := T.prefixAt w (S.depth z)
    have hx : x ≤ w := T.prefixAt_le w _
    have hd : T.depth x = S.depth z := T.depth_prefixAt w hn
    refine ⟨x, hx, ?_⟩
    apply same_depth_ancestors S (prefix_monotone T S f hchild hx) hz
    rw [depth_preserved T S f hroot hchild x, hd]

end DIDomainClassification.TreeEdgeMaps
