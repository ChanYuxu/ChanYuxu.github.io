import DIDomainClassification.Section04.SeparatedSumStatement
import DIDomainClassification.Support.OrderCoreLemmas

/-! Order and directed-supremum calculations in the literal separated sum. -/
set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.SeparatedSumOrder
open OrderCore Preliminaries
open Section03.StableFunctionModels
open Section04.SeparatedSumModels

variable {I : Type v} (H : I → CountablyBasedDIDomain.{u})

theorem component_mono (i : I) : Monotone (component H i) := by
  intro x y hxy
  exact WithBot.coe_le_coe.mpr (Sigma.mk_le_mk_iff.mpr hxy)

theorem component_le_iff (i : I) (x y : Core (H i)) :
    component H i x ≤ component H i y ↔ x ≤ y := by
  exact WithBot.coe_le_coe.trans Sigma.mk_le_mk_iff

theorem component_injective (i : I) : Function.Injective (component H i) := by
  intro x y h
  exact le_antisymm ((component_le_iff H i x y).mp h.le)
    ((component_le_iff H i y x).mp h.symm.le)

theorem component_ne_bottom (i : I) (x : Core (H i)) :
    component H i x ≠ bottom H := WithBot.coe_ne_bot

theorem cases_sum (x : Carrier H) :
    x = bottom H ∨ ∃ (i : I) (a : Core (H i)), x = component H i a := by
  cases x with
  | none => exact Or.inl rfl
  | some q => exact Or.inr ⟨q.1, q.2, rfl⟩

theorem component_le_elim {i : I} {a : Core (H i)} {x : Carrier H}
    (h : component H i a ≤ x) :
    ∃ b : Core (H i), x = component H i b ∧ a ≤ b := by
  cases x with
  | none => exact False.elim ((WithBot.not_coe_le_bot _) h)
  | some q =>
    rcases q with ⟨j, b⟩
    rcases Sigma.le_def.mp (WithBot.coe_le_coe.mp h) with ⟨hij, hab⟩
    cases hij
    exact ⟨b, rfl, hab⟩

theorem compatible_indices {i j : I} {a : Core (H i)} {b : Core (H j)}
    (h : Compatible (component H i a) (component H j b)) : i = j := by
  obtain ⟨z, haz, hbz⟩ := h
  obtain ⟨c, rfl, _hac⟩ := component_le_elim H haz
  exact (Sigma.le_def.mp (WithBot.coe_le_coe.mp hbz)).choose.symm

theorem below_component {i : I} {a : Core (H i)} {x : Carrier H}
    (h : x ≤ component H i a) :
    x = bottom H ∨ ∃ b : Core (H i), x = component H i b ∧ b ≤ a := by
  rcases cases_sum H x with rfl | ⟨j, b, rfl⟩
  · exact Or.inl rfl
  · have hji : j = i := compatible_indices H
      ⟨component H i a, h, le_rfl⟩
    subst j
    exact Or.inr ⟨b, rfl, (component_le_iff H i b a).mp h⟩

def fiberValues (i : I) (X : Set (Carrier H)) : Set (Core (H i)) :=
  {a | component H i a ∈ X}

def InFiber (i : I) (X : Set (Carrier H)) : Prop :=
  ∀ x ∈ X, x = bottom H ∨ ∃ a : Core (H i), x = component H i a

theorem inFiber_of_upper {i : I} {X : Set (Carrier H)} {b : Core (H i)}
    (h : ∀ x ∈ X, x ≤ component H i b) : InFiber H i X := by
  intro x hx
  rcases below_component H (h x hx) with hb | ⟨a, ha, _⟩
  · exact Or.inl hb
  · exact Or.inr ⟨a, ha⟩

theorem directed_inFiber {i : I} {X : Set (Carrier H)}
    (hX : DirectedSet X) {a : Core (H i)} (ha : component H i a ∈ X) :
    InFiber H i X := by
  intro x hx
  rcases cases_sum H x with hb | ⟨j, b, rfl⟩
  · exact Or.inl hb
  · obtain ⟨z, _hz, haz, hbz⟩ := hX.2 ha hx
    have hij : i = j := compatible_indices H ⟨z, haz, hbz⟩
    subst j
    exact Or.inr ⟨b, rfl⟩

theorem fiber_directed {i : I} {X : Set (Carrier H)}
    (hX : DirectedSet X) (hne : (fiberValues H i X).Nonempty) :
    DirectedSet (fiberValues H i X) := by
  refine ⟨hne, ?_⟩
  intro a ha b hb
  obtain ⟨z, hz, haz, hbz⟩ := hX.2 ha hb
  obtain ⟨c, rfl, hac⟩ := component_le_elim H haz
  exact ⟨c, hz, hac, (component_le_iff H i b c).mp hbz⟩

theorem lift_fiber_lub {i : I} {X : Set (Carrier H)} {s : Core (H i)}
    (hX : InFiber H i X) (hne : (fiberValues H i X).Nonempty)
    (hs : IsLUB (fiberValues H i X) s) :
    IsLUB X (component H i s) := by
  constructor
  · intro x hx
    rcases hX x hx with rfl | ⟨a, rfl⟩
    · exact bot_le
    · exact component_mono H i (hs.1 hx)
  · intro z hz
    obtain ⟨a, ha⟩ := hne
    obtain ⟨b, rfl, _⟩ := component_le_elim H (hz ha)
    apply component_mono H i
    exact hs.2 (fun c hc => (component_le_iff H i c b).mp (hz hc))

theorem project_fiber_lub {i : I} {X : Set (Carrier H)} {s : Core (H i)}
    (hs : IsLUB X (component H i s)) :
    IsLUB (fiberValues H i X) s := by
  constructor
  · intro a ha
    exact (component_le_iff H i a s).mp (hs.1 ha)
  · intro b hb
    apply (component_le_iff H i s b).mp
    apply hs.2
    intro x hx
    rcases below_component H (hs.1 hx) with rfl | ⟨a, rfl, _⟩
    · exact bot_le
    · exact component_mono H i (hb hx)

theorem fiber_nonempty_of_lub {i : I} {X : Set (Carrier H)} {s : Core (H i)}
    (hs : IsLUB X (component H i s)) :
    (fiberValues H i X).Nonempty := by
  by_contra hnone
  have hu : ∀ x ∈ X, x ≤ (bottom H) := by
    intro x hx
    rcases below_component H (hs.1 hx) with rfl | ⟨a, rfl, _⟩
    · exact le_rfl
    · exact False.elim (hnone ⟨a, hx⟩)
  exact component_ne_bottom H i s (le_antisymm (hs.2 hu) bot_le)

theorem component_isLUB (i : I) {X : Set (Core (H i))} {s : Core (H i)}
    (hne : X.Nonempty) (hs : IsLUB X s) :
    IsLUB (component H i '' X) (component H i s) := by
  constructor
  · rintro _ ⟨a, ha, rfl⟩
    exact component_mono H i (hs.1 ha)
  · intro z hz
    obtain ⟨a, ha⟩ := hne
    obtain ⟨b, rfl, _⟩ := component_le_elim H (hz ⟨a, ha, rfl⟩)
    exact component_mono H i
      (hs.2 (fun c hc => (component_le_iff H i c b).mp (hz ⟨c, hc, rfl⟩)))

theorem component_continuous (i : I) : ScottContinuous (component H i) := by
  intro X hne _hdir s hs
  exact component_isLUB H i hne hs

theorem sum_isDcpo : OrderCore.IsDcpo (Carrier H) := by
  intro X hX
  by_cases hpos : ∃ (i : I) (a : Core (H i)), component H i a ∈ X
  · obtain ⟨i, a, ha⟩ := hpos
    have hne : (fiberValues H i X).Nonempty := ⟨a, ha⟩
    obtain ⟨s, hs⟩ := (Core (H i)).isDIDomain.toIsScottDomain.algebraic.1
      (fiberValues H i X) (fiber_directed H hX hne)
    exact ⟨component H i s, lift_fiber_lub H (directed_inFiber H hX ha) hne hs⟩
  · refine ⟨bottom H, ?_, ?_⟩
    · intro x hx
      rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
      · exact le_rfl
      · exact False.elim (hpos ⟨i, a, hx⟩)
    · intro z _hz
      exact bot_le

theorem bottom_compact : IsCompactElement (bottom H) := by
  intro X s hX _hs _hbs
  obtain ⟨a, ha⟩ := hX.1
  exact ⟨a, ha, bot_le⟩

theorem compact_component_of_compact (i : I) {a : Core (H i)}
    (ha : IsCompactElement a) : IsCompactElement (component H i a) := by
  intro X s hX hs has
  obtain ⟨b, rfl, hab⟩ := component_le_elim H has
  have hne := fiber_nonempty_of_lub H hs
  obtain ⟨c, hc, hac⟩ := ha (fiber_directed H hX hne)
    (project_fiber_lub H hs) hab
  exact ⟨component H i c, hc, component_mono H i hac⟩

theorem compact_of_compact_component (i : I) {a : Core (H i)}
    (ha : IsCompactElement (component H i a)) : IsCompactElement a := by
  intro X s hX hs has
  obtain ⟨_, ⟨b, hb, rfl⟩, hab⟩ := ha (hX.image (component_mono H i))
    (component_isLUB H i hX.1 hs) (component_mono H i has)
  exact ⟨b, hb, (component_le_iff H i a b).mp hab⟩

theorem compact_component_iff (i : I) (a : Core (H i)) :
    IsCompactElement (component H i a) ↔ IsCompactElement a :=
  ⟨compact_of_compact_component H i, compact_component_of_compact H i⟩

theorem compact_sum_iff (x : Carrier H) :
    IsCompactElement x ↔ x = bottom H ∨
      ∃ (i : I) (a : Core (H i)), IsCompactElement a ∧ x = component H i a := by
  constructor
  · intro hx
    rcases cases_sum H x with hb | ⟨i, a, rfl⟩
    · exact Or.inl hb
    · exact Or.inr ⟨i, a, (compact_component_iff H i a).mp hx, rfl⟩
  · rintro (rfl | ⟨i, a, ha, rfl⟩)
    · exact bottom_compact H
    · exact compact_component_of_compact H i ha

theorem compactBelow_directed (x : Carrier H) :
    DirectedSet (OrderCore.CompactBelow x) := by
  refine ⟨⟨bottom H, bottom_compact H, bot_le⟩, ?_⟩
  intro p hp q hq
  rcases cases_sum H p with rfl | ⟨i, a, rfl⟩
  · exact ⟨q, hq, bot_le, le_rfl⟩
  · rcases cases_sum H q with rfl | ⟨j, b, rfl⟩
    · exact ⟨component H i a, hp, le_rfl, bot_le⟩
    · have hij : i = j := compatible_indices H ⟨x, hp.2, hq.2⟩
      subst j
      obtain ⟨c, rfl, hac⟩ := component_le_elim H hp.2
      have hbc := (component_le_iff H i b c).mp hq.2
      have hK := (Core (H i)).isDIDomain.toIsScottDomain.algebraic.2 c
      obtain ⟨d, hd, had, hbd⟩ := hK.1.2
        ⟨(compact_component_iff H i a).mp hp.1, hac⟩
        ⟨(compact_component_iff H i b).mp hq.1, hbc⟩
      exact ⟨component H i d,
        ⟨compact_component_of_compact H i hd.1, component_mono H i hd.2⟩,
        component_mono H i had, component_mono H i hbd⟩

theorem compactBelow_isSup (x : Carrier H) : IsSup (OrderCore.CompactBelow x) x := by
  refine ⟨fun _ hp => hp.2, ?_⟩
  intro z hz
  rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
  · exact bot_le
  · have hK := (Core (H i)).isDIDomain.toIsScottDomain.algebraic.2 a
    have hL := component_isLUB H i hK.1.1 hK.2
    apply hL.2
    rintro _ ⟨k, hk, rfl⟩
    exact hz ⟨compact_component_of_compact H i hk.1, component_mono H i hk.2⟩

theorem sum_isAlgebraic : OrderCore.IsAlgebraicDcpo (Carrier H) :=
  ⟨sum_isDcpo H, fun x => ⟨compactBelow_directed H x, compactBelow_isSup H x⟩⟩

end DIDomainClassification.SeparatedSumOrder
