import DIDomainClassification.Support.LeafClassSubtree

/-!
Genuine relative-prefix subtrees, including single-node subtrees. These are
generic prerequisites for contextual tree refinement, not source wrappers.
Only actual nodes are counted; the alphabet remains arbitrary.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.TreeGrafting

open Trees
open FiniteLeafColourPruning (nodeRank_le_of_childMap nodeRank_add_one_le_of_child)

variable {Index : Type u}

theorem isChild_iff_prefix_length (T : RootedPrefixTree Index) (x y : T.Node) :
    T.IsChild x y ↔ x.val <+: y.val ∧ y.val.length = x.val.length + 1 := by
  have hx := T.root_length_le x
  have hy := T.root_length_le y
  constructor
  · rintro ⟨hxy, hdepth⟩
    refine ⟨hxy, ?_⟩
    dsimp [RootedPrefixTree.depth] at hdepth
    omega
  · rintro ⟨hxy, hlength⟩
    refine ⟨hxy, ?_⟩
    dsimp [RootedPrefixTree.depth]
    omega

def above (T : RootedPrefixTree Index) (x : T.Node) : RootedPrefixTree Index where
  nodes := {v | v ∈ T.nodes ∧ x.val <+: v}
  rootList := x.val
  root_mem := ⟨x.property, List.prefix_refl _⟩
  root_prefix := fun hv => hv.2
  prefix_closed := by
    intro v w hxv hvw hw
    exact ⟨T.prefix_closed ((T.root_prefix x.property).trans hxv) hvw hw.1, hxv⟩
  countable_nodes := T.countable_nodes.mono (fun _ hv => hv.1)

theorem above_rootList (T : RootedPrefixTree Index) (x : T.Node) :
    (above T x).rootList = x.val := rfl

theorem above_nodes (T : RootedPrefixTree Index) (x : T.Node) (v : List Index) :
    v ∈ (above T x).nodes ↔ v ∈ T.nodes ∧ x.val <+: v := Iff.rfl

def aboveNodeMap (T : RootedPrefixTree Index) (x : T.Node) (v : (above T x).Node) :
    T.Node := ⟨v.val, v.property.1⟩

theorem aboveNodeMap_val (T : RootedPrefixTree Index) (x : T.Node)
    (v : (above T x).Node) : (aboveNodeMap T x v).val = v.val := rfl

theorem aboveNodeMap_root (T : RootedPrefixTree Index) (x : T.Node) :
    aboveNodeMap T x (above T x).root = x := rfl

theorem aboveNodeMap_injective (T : RootedPrefixTree Index) (x : T.Node) :
    Function.Injective (aboveNodeMap T x) := by
  intro v w hvw
  exact Subtype.ext (congrArg (fun y : T.Node => y.val) hvw)

theorem aboveNodeMap_isChild_iff (T : RootedPrefixTree Index) (x : T.Node)
    (v w : (above T x).Node) :
    T.IsChild (aboveNodeMap T x v) (aboveNodeMap T x w) ↔
      (above T x).IsChild v w := by
  rw [isChild_iff_prefix_length, isChild_iff_prefix_length]
  rfl

def aboveEmbedNode (T : RootedPrefixTree Index) (x y : T.Node)
    (hxy : x.val <+: y.val) : (above T x).Node := ⟨y.val, y.property, hxy⟩

theorem aboveNodeMap_embed (T : RootedPrefixTree Index) (x y : T.Node)
    (hxy : x.val <+: y.val) : aboveNodeMap T x (aboveEmbedNode T x y hxy) = y := rfl

theorem above_isWellFounded (T : RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) : (above T x).IsWellFounded := by
  apply (above T x).isWellFounded_iff_wellFounded_reverseChildRelation.mpr
  have h := (T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).onFun
    (f := aboveNodeMap T x)
  exact h.mono (fun _ _ hvw => (aboveNodeMap_isChild_iff T x _ _).mpr hvw)

theorem aboveNodeMap_isLeaf_iff (T : RootedPrefixTree Index) (x : T.Node)
    (v : (above T x).Node) :
    (above T x).IsLeaf v ↔ T.IsLeaf (aboveNodeMap T x v) := by
  constructor
  · intro hv w hvw
    have hxw : x.val <+: w.val := v.property.2.trans hvw
    have heq := hv (aboveEmbedNode T x w hxw) hvw
    exact congrArg (aboveNodeMap T x) heq
  · intro hv w hvw
    apply aboveNodeMap_injective T x
    exact hv _ hvw

theorem above_nodeRank_eq (T : RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) (v : (above T x).Node) :
    (above T x).nodeRank (above_isWellFounded T hT x) v =
      T.nodeRank hT (aboveNodeMap T x v) := by
  let hS := above_isWellFounded T hT x
  refine ((above T x).isWellFounded_iff_wellFounded_reverseChildRelation.mp hS).induction
    (C := fun v : (above T x).Node =>
      (above T x).nodeRank hS v = T.nodeRank hT (aboveNodeMap T x v)) v ?_
  intro v ih
  apply le_antisymm
  · exact nodeRank_le_of_childMap (above T x) T hS hT (aboveNodeMap T x)
      (fun hvw => (aboveNodeMap_isChild_iff T x _ _).mpr hvw) v
  · rw [T.nodeRank_eq hT (aboveNodeMap T x v)]
    apply Ordinal.iSup_le
    intro y
    have hxy : x.val <+: y.val.val := v.property.2.trans y.property.1
    let w := aboveEmbedNode T x y.val hxy
    have hvw : (above T x).IsChild v w :=
      (aboveNodeMap_isChild_iff T x v w).mp y.property
    have hw := ih w hvw
    exact (add_le_add hw.symm.le (le_rfl : (1 : Ordinal.{u}) ≤ 1)).trans
      (nodeRank_add_one_le_of_child (above T x) hS hvw)

theorem above_treeRank_eq (T : RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) :
    (above T x).treeRank (above_isWellFounded T hT x) = T.nodeRank hT x :=
  above_nodeRank_eq T hT x (above T x).root

theorem aboveNodeMap_pathTo (T : RootedPrefixTree Index) (x : T.Node)
    (v : (above T x).Node) :
    aboveNodeMap T x '' (above T x).pathTo v =
      {w : T.Node | x.val <+: w.val ∧ w.val <+: v.val} := by
  ext w
  constructor
  · rintro ⟨z, hz, rfl⟩
    exact ⟨z.property.2, hz⟩
  · rintro ⟨hxw, hwv⟩
    exact ⟨aboveEmbedNode T x w hxw, hwv, rfl⟩

theorem above_path_split (T : RootedPrefixTree Index) (x : T.Node)
    (v : (above T x).Node) :
    T.pathTo (aboveNodeMap T x v) =
      T.pathTo x ∪ aboveNodeMap T x '' (above T x).pathTo v := by
  rw [aboveNodeMap_pathTo]
  ext w
  constructor
  · intro hw
    rcases List.prefix_or_prefix_of_prefix hw v.property.2 with hwx | hxw
    · exact Or.inl hwx
    · exact Or.inr ⟨hxw, hw⟩
  · rintro (hw | hw)
    · exact (show w.val <+: x.val from hw).trans v.property.2
    · exact hw.2

theorem root_child_pathTo (T : RootedPrefixTree Index) {x : T.Node}
    (hx : T.IsChild T.root x) : T.pathTo x = {T.root, x} := by
  ext w
  change (w.val <+: x.val) ↔ w = T.root ∨ w = x
  constructor
  · intro hw
    have hd : T.depth x = 1 := by simpa only [T.depth_root, zero_add] using hx.2
    have hle := T.depth_mono hw
    by_cases hz : T.depth w = 0
    · exact Or.inl ((T.depth_eq_zero_iff w).mp hz)
    · exact Or.inr (T.eq_of_le_of_depth_eq hw (by omega))
  · rintro (rfl | rfl)
    · exact T.root_prefix x.property
    · exact List.prefix_refl _

theorem above_root_child_path_split (T : RootedPrefixTree Index) {x : T.Node}
    (hx : T.IsChild T.root x) (v : (above T x).Node) :
    T.pathTo (aboveNodeMap T x v) =
      {T.root} ∪ aboveNodeMap T x '' (above T x).pathTo v := by
  rw [above_path_split, root_child_pathTo T hx]
  have hximage : x ∈ aboveNodeMap T x '' (above T x).pathTo v :=
    ⟨(above T x).root, (above T x).root_le v, rfl⟩
  ext w
  simp only [Set.mem_union, Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · rintro ((hw | hw) | hw)
    · exact Or.inl hw
    · exact Or.inr (by simpa only [hw] using hximage)
    · exact Or.inr hw
  · rintro (hw | hw)
    · exact Or.inl (Or.inl hw)
    · exact Or.inr hw

theorem above_finiteCompleteBranch (T : RootedPrefixTree Index) (x : T.Node)
    (c : Set (above T x).Node) (hc : (above T x).IsFiniteCompleteBranch c) :
    T.IsFiniteCompleteBranch (T.pathTo x ∪ aboveNodeMap T x '' c) := by
  obtain ⟨v, hv, rfl⟩ := hc
  exact ⟨aboveNodeMap T x v, (aboveNodeMap_isLeaf_iff T x v).mp hv,
    (above_path_split T x v).symm⟩

theorem normalized_nodeRank_eq (T : RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) :
    T.normalized.nodeRank (T.normalized_isWellFounded_iff.mpr hT)
      (T.normalizeOrderIso x) = T.nodeRank hT x := by
  let hN := T.normalized_isWellFounded_iff.mpr hT
  apply le_antisymm
  · have h := nodeRank_le_of_childMap T.normalized T hN hT T.normalizeOrderIso.symm
      (fun {v w} hvw => by
        apply (T.normalizeOrderIso_isChild _ _).mp
        simpa only [OrderIso.apply_symm_apply] using hvw) (T.normalizeOrderIso x)
    simpa only [OrderIso.symm_apply_apply] using h
  · exact nodeRank_le_of_childMap T T.normalized hT hN T.normalizeOrderIso
      (fun hxy => (T.normalizeOrderIso_isChild _ _).mpr hxy) x

theorem normalized_treeRank_eq (T : RootedPrefixTree Index) (hT : T.IsWellFounded) :
    T.normalized.treeRank (T.normalized_isWellFounded_iff.mpr hT) = T.treeRank hT := by
  change T.normalized.nodeRank _ T.normalized.root = T.nodeRank hT T.root
  rw [← T.normalizeOrderIso_root]
  exact normalized_nodeRank_eq T hT T.root

end DIDomainClassification.TreeGrafting

