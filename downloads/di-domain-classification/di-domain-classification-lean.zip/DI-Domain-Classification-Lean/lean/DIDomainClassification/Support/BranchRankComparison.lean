import DIDomainClassification.Support.ChildBranchRestriction

/-!
Generic rank consequence of exact finite-complete-branch SET preservation.

No root-preservation or monotonicity is assumed of the supplied map. At each
inductive step we restrict the target to the spine through the root image and
swap the two nodes occurring on every retained branch. Child restrictions are
then genuine whole-branch maps; their roots may move again, so the induction
quantifies over all such maps rather than only root-preserving ones.

This is a reusable WF-tree result, not a source-facing proof/acceptance of all
parts of BPS Lemma 4.6. Alphabets are arbitrary in the same universe; their full
carriers need not be countable. Singleton trees and empty child families occur
in the induction and are included.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.BranchRankComparison

open Trees

theorem child_treeRank_lt {A : Type u} (S : RootedPrefixTree A)
    (hS : S.IsWellFounded) (c : S.Node) (hc : S.IsChild S.root c) :
    (TreeGrafting.above S c).treeRank (TreeGrafting.above_isWellFounded S hS c) <
      S.treeRank hS := by
  rw [TreeGrafting.above_treeRank_eq S hS c]
  exact (show S.nodeRank hS c < S.nodeRank hS c + 1 by
    simpa only [Order.succ_eq_add_one] using Order.lt_succ (S.nodeRank hS c)).trans_le
      (FiniteLeafColourPruning.nodeRank_add_one_le_of_child S hS hc)

/-- A map bijective on each complete source branch onto an entire target
complete branch cannot increase native source root rank. The map need NOT
preserve roots, prefix order, children, or leaves individually. -/
theorem treeRank_le_of_branch_maps {A B : Type u}
    (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (hT : T.IsWellFounded) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f) :
    S.treeRank hS ≤ T.treeRank hT := by
  have inductionStatement : ∀ α : Ordinal.{u},
      ∀ (A : Type u) (S : RootedPrefixTree A) (hS : S.IsWellFounded),
        S.treeRank hS = α →
        ∀ (B : Type u) (T : RootedPrefixTree B) (hT : T.IsWellFounded)
          (f : S.Node → T.Node),
          MapsFiniteCompleteBranches S T f → InjectiveOnBranches S T f →
            S.treeRank hS ≤ T.treeRank hT := by
    intro α
    refine WellFoundedLT.induction (motive := fun β : Ordinal.{u} =>
      ∀ (A : Type u) (S : RootedPrefixTree A) (hS : S.IsWellFounded),
        S.treeRank hS = β →
        ∀ (B : Type u) (T : RootedPrefixTree B) (hT : T.IsWellFounded)
          (f : S.Node → T.Node),
          MapsFiniteCompleteBranches S T f → InjectiveOnBranches S T f →
            S.treeRank hS ≤ T.treeRank hT) α ?_
    intro α ih A S hS hα B T hT f hf hinj
    obtain ⟨Q, hQ, g, hroot, hg, hginj, hQT⟩ :=
      root_normalization S hS T hT f hf hinj
    have hSQ : S.treeRank hS ≤ Q.treeRank hQ := by
      change S.nodeRank hS S.root ≤ Q.nodeRank hQ Q.root
      rw [S.nodeRank_eq hS S.root]
      apply Ordinal.iSup_le
      intro c
      obtain ⟨d, hd, gc, _hformula, hcmap, hcinj⟩ :=
        child_restriction S hS Q g hg hginj hroot c.val c.property
      have hless := child_treeRank_lt S hS c.val c.property
      rw [hα] at hless
      have hchild := ih _ hless A (TreeGrafting.above S c.val)
        (TreeGrafting.above_isWellFounded S hS c.val) rfl B (TreeGrafting.above Q d)
        (TreeGrafting.above_isWellFounded Q hQ d) gc hcmap hcinj
      rw [TreeGrafting.above_treeRank_eq S hS c.val,
        TreeGrafting.above_treeRank_eq Q hQ d] at hchild
      exact (add_le_add hchild (le_rfl : (1 : Ordinal.{u}) ≤ 1)).trans
        (FiniteLeafColourPruning.nodeRank_add_one_le_of_child Q hQ hd)
    exact hSQ.trans hQT
  exact inductionStatement (S.treeRank hS) A S hS rfl B T hT f hf hinj

end DIDomainClassification.BranchRankComparison

