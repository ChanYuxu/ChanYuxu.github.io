import DIDomainClassification.Support.RootExpansion

/-! Literal carrier and finite-chain index formulas for the frozen expansion.
No frozen donor is edited. These proofs concern the actual node subtype and
do not replace its carrier by a proxy or add an alphabet-countability input. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.TreeGrafting

open Trees

variable {Index : Type u}

theorem rootExpansionAncestors_values (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) :
    (fun v : (rootExpansion S hroot marker n).Node => v.val) ''
        rootExpansionAncestors S hroot marker n =
      {l : List Index | ∃ k : ℕ, k < n ∧ l = List.replicate k marker} := by
  induction n with
  | zero =>
    ext l
    simp only [rootExpansionAncestors, Set.image_empty, Set.mem_empty_iff_false,
      Set.mem_setOf_eq, Nat.not_lt_zero, false_and, exists_false]
  | succ n ih =>
    ext l
    constructor
    · rintro ⟨v, hv, rfl⟩
      rcases hv with hv | ⟨w, hw, rfl⟩
      · have hv' := Set.mem_singleton_iff.mp hv
        subst v
        exact ⟨0, Nat.zero_lt_succ n, rfl⟩
      · have hval : w.val ∈ (fun v : (rootExpansion S hroot marker n).Node => v.val) ''
            rootExpansionAncestors S hroot marker n := ⟨w, hw, rfl⟩
        rw [ih] at hval
        obtain ⟨k, hk, hwval⟩ := hval
        refine ⟨k + 1, Nat.succ_lt_succ hk, ?_⟩
        change marker :: w.val = List.replicate (k + 1) marker
        rw [hwval, List.replicate_succ]
    · rintro ⟨k, hk, hl⟩
      cases k with
      | zero =>
        exact ⟨(rootExpansion S hroot marker (n + 1)).root,
          Or.inl (Set.mem_singleton _), hl.symm⟩
      | succ k =>
        have hval : List.replicate k marker ∈
            (fun v : (rootExpansion S hroot marker n).Node => v.val) ''
              rootExpansionAncestors S hroot marker n :=
          by rw [ih]; exact ⟨k, Nat.lt_of_succ_lt_succ hk, rfl⟩
        obtain ⟨w, hw, hwval⟩ := hval
        refine ⟨forestEmbed (fun _ : Unit => rootExpansion S hroot marker n)
          (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n) () w,
          Or.inr ⟨w, hw, rfl⟩, ?_⟩
        change marker :: w.val = l
        exact (congrArg (List.cons marker) hwval).trans hl.symm

theorem mem_rootExpansionAncestors_values (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) (l : List Index) :
    l ∈ (fun v : (rootExpansion S hroot marker n).Node => v.val) ''
        rootExpansionAncestors S hroot marker n ↔
      ∃ k : ℕ, k < n ∧ l = List.replicate k marker := by
  rw [rootExpansionAncestors_values]
  rfl

theorem rootExpansion_mem_iff (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) (l : List Index) :
    l ∈ (rootExpansion S hroot marker n).nodes ↔
      (∃ k : ℕ, k < n ∧ l = List.replicate k marker) ∨
        ∃ v : S.Node, l = List.replicate n marker ++ v.val := by
  constructor
  · intro hl
    let v : (rootExpansion S hroot marker n).Node := ⟨l, hl⟩
    rcases rootExpansionNode_cases S hroot marker n v with hv | ⟨w, hvw⟩
    · exact Or.inl ((mem_rootExpansionAncestors_values S hroot marker n l).mp ⟨v, hv, rfl⟩)
    · exact Or.inr ⟨w, (congrArg
        (fun z : (rootExpansion S hroot marker n).Node => z.val) hvw).trans
          (rootExpansionEmbed_val S hroot marker n w)⟩
  · rintro (hnew | ⟨v, hl⟩)
    · obtain ⟨v, _hv, hvval⟩ := (mem_rootExpansionAncestors_values S hroot marker n l).mpr hnew
      exact hvval ▸ v.property
    · have heq : (rootExpansionEmbed S hroot marker n v).val = l :=
        (rootExpansionEmbed_val S hroot marker n v).trans hl.symm
      exact heq ▸ (rootExpansionEmbed S hroot marker n v).property

theorem rootExpansionEmbed_length (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) (v : S.Node) :
    (rootExpansionEmbed S hroot marker n v).val.length = n + v.val.length := by
  rw [rootExpansionEmbed_val, List.length_append, List.length_replicate]

theorem rootExpansionAncestors_length_lt (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ)
    (v : (rootExpansion S hroot marker n).Node)
    (hv : v ∈ rootExpansionAncestors S hroot marker n) : v.val.length < n := by
  obtain ⟨k, hk, hvval⟩ := (mem_rootExpansionAncestors_values S hroot marker n v.val).mp ⟨v, hv, rfl⟩
  simpa only [hvval, List.length_replicate] using hk

theorem rootExpansionAncestors_iff_length_lt (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ)
    (v : (rootExpansion S hroot marker n).Node) :
    v ∈ rootExpansionAncestors S hroot marker n ↔ v.val.length < n := by
  constructor
  · exact rootExpansionAncestors_length_lt S hroot marker n v
  · intro hvlen
    rcases rootExpansionNode_cases S hroot marker n v with hv | ⟨w, rfl⟩
    · exact hv
    · rw [rootExpansionEmbed_length] at hvlen
      omega

def rootExpansionAncestorNode (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) (k : Fin n) : (rootExpansion S hroot marker n).Node :=
  ⟨List.replicate k.val marker,
    (rootExpansion_mem_iff S hroot marker n _).mpr (Or.inl ⟨k.val, k.isLt, rfl⟩)⟩

theorem rootExpansionAncestorNode_val (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) (k : Fin n) :
    (rootExpansionAncestorNode S hroot marker n k).val = List.replicate k.val marker := rfl

theorem rootExpansionAncestorNode_injective (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) :
    Function.Injective (rootExpansionAncestorNode S hroot marker n) := by
  intro k l h
  apply Fin.ext
  have hlen := congrArg (fun z : (rootExpansion S hroot marker n).Node => z.val.length) h
  simpa only [rootExpansionAncestorNode, List.length_replicate] using hlen

theorem rootExpansionAncestors_eq_range (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) :
    rootExpansionAncestors S hroot marker n = Set.range (rootExpansionAncestorNode S hroot marker n) := by
  ext v
  constructor
  · intro hv
    obtain ⟨k, hk, hval⟩ := (mem_rootExpansionAncestors_values S hroot marker n v.val).mp ⟨v, hv, rfl⟩
    exact ⟨⟨k, hk⟩, Subtype.ext hval.symm⟩
  · rintro ⟨k, rfl⟩
    apply (rootExpansionAncestors_iff_length_lt S hroot marker n _).mpr
    simpa only [rootExpansionAncestorNode, List.length_replicate] using k.isLt

theorem rootExpansionAncestors_disjoint_old (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) :
    Disjoint (rootExpansionAncestors S hroot marker n)
      (Set.range (rootExpansionEmbed S hroot marker n)) := by
  apply Set.disjoint_left.mpr
  rintro v hv ⟨w, rfl⟩
  have hlen := rootExpansionAncestors_length_lt S hroot marker n _ hv
  rw [rootExpansionEmbed_length] at hlen
  omega

theorem rootExpansionAncestors_ncard (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) :
    (rootExpansionAncestors S hroot marker n).ncard = n := by
  rw [rootExpansionAncestors_eq_range,
    Set.ncard_range_of_injective (rootExpansionAncestorNode_injective S hroot marker n)]
  exact Nat.card_fin n

end DIDomainClassification.TreeGrafting

