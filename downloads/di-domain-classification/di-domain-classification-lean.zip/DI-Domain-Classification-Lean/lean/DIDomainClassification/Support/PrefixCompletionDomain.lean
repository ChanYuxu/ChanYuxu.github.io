import DIDomainClassification.Section04.BranchCompletionPropertiesStatement
import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.CoherenceCharacterization
import Mathlib.Order.Zorn

/-! Domain properties of the literal prefix completion. No domain certificate
or statement from the completion paragraph is an input to these proofs. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PrefixCompletionDomain

open Preliminaries Trees OrderCore

variable {A : Type u} (T : RootedPrefixTree A)

abbrev H := PrefixCompletion T

theorem root_le (x : H T) : PrefixCompletion.finite T T.root ≤ x := by
  rcases x with w | b
  · exact T.root_le w
  · exact ⟨0, b.root_eq⟩

theorem below_finite (v : T.Node) :
    Set.Iic (PrefixCompletion.finite T v) =
      PrefixCompletion.finite T '' Set.Iic v := by
  ext x
  rcases x with w | b
  · constructor
    · intro hw; exact ⟨w, hw, rfl⟩
    · rintro ⟨t, ht, htw⟩
      exact (Sum.inl.inj htw) ▸ ht
  · constructor
    · intro h; exact False.elim h
    · rintro ⟨w, _, h⟩; cases h

theorem below_finite_finite (v : T.Node) :
    (Set.Iic (PrefixCompletion.finite T v)).Finite := by
  rw [below_finite]
  exact (T.pathTo_finite v).image _

theorem comparable_below {x y z : H T} (hx : x ≤ z) (hy : y ≤ z) :
    x ≤ y ∨ y ≤ x := by
  rcases z with w | b
  · rcases x with v | c <;> rcases y with t | d
    · exact List.prefix_or_prefix_of_prefix hx hy
    · exact False.elim hy
    · exact False.elim hx
    · exact False.elim hx
  · rcases x with v | c <;> rcases y with t | d
    · obtain ⟨m, hm⟩ := hx
      obtain ⟨n, hn⟩ := hy
      rcases le_total m n with h | h
      · exact Or.inl (hm ▸ hn ▸ b.monotone T h)
      · exact Or.inr (hm ▸ hn ▸ b.monotone T h)
    · change d = b at hy
      subst d
      exact Or.inl hx
    · change c = b at hx
      subst c
      exact Or.inr hy
    · change c = b at hx
      change d = b at hy
      exact Or.inl (hx.trans hy.symm)

theorem compatible_comparable {x y : H T} (h : Compatible x y) :
    x ≤ y ∨ y ≤ x := by
  obtain ⟨z, hx, hy⟩ := h
  exact comparable_below T hx hy

theorem directed_chain {S : Set (H T)} (hS : DirectedSet S) :
    IsChain (· ≤ ·) S := by
  intro x hx y hy _
  obtain ⟨z, _, hxz, hyz⟩ := hS.2 hx hy
  exact comparable_below T hxz hyz

theorem branch_prefixes_directed (b : T.InfiniteBranch) :
    DirectedSet (PrefixCompletion.finite T '' Set.range b.node) := by
  constructor
  · exact ⟨PrefixCompletion.finite T (b.node 0), ⟨b.node 0, ⟨0, rfl⟩, rfl⟩⟩
  · rintro x ⟨_, ⟨m, rfl⟩, rfl⟩ y ⟨_, ⟨n, rfl⟩, rfl⟩
    exact ⟨PrefixCompletion.finite T (b.node (max m n)),
      ⟨_, ⟨max m n, rfl⟩, rfl⟩, b.monotone T (le_max_left _ _),
      b.monotone T (le_max_right _ _)⟩

theorem branch_prefixes_isLUB (b : T.InfiniteBranch) :
    IsLUB (PrefixCompletion.finite T '' Set.range b.node)
      (PrefixCompletion.infinite T b) := by
  constructor
  · rintro x ⟨v, hv, rfl⟩
    exact hv
  · intro z hz
    rcases z with v | c
    · have h := hz ⟨b.node (T.depth v + 1), ⟨T.depth v + 1, rfl⟩, rfl⟩
      have hd := T.depth_mono h
      rw [b.depth_eq] at hd
      omega
    · change b = c
      apply RootedPrefixTree.InfiniteBranch.range_injective T
      apply (b.range_isBranch T).2 (c.range_isBranch T).1
      intro w hw
      exact hz ⟨w, hw, rfl⟩

theorem infinite_not_compact (b : T.InfiniteBranch) :
    ¬ IsCompactElement (PrefixCompletion.infinite T b) := by
  intro hb
  obtain ⟨x, ⟨v, _, rfl⟩, h⟩ := hb (branch_prefixes_directed T b)
    (branch_prefixes_isLUB T b) le_rfl
  exact h

theorem finite_compact (v : T.Node) :
    IsCompactElement (PrefixCompletion.finite T v) := by
  intro S s hS hs hvs
  classical
  by_cases h : ∃ x ∈ S, PrefixCompletion.finite T v ≤ x
  · exact h
  · have hsub : S ⊆ Set.Iic (PrefixCompletion.finite T v) := by
      intro y hy
      rcases comparable_below T (hs.1 hy) hvs with h | h
      · exact h
      · exact False.elim (‹¬∃ x ∈ S, PrefixCompletion.finite T v ≤ x› ⟨y, hy, h⟩)
    have hfinite : S.Finite := (below_finite_finite T v).subset hsub
    obtain ⟨x, hx, hmax⟩ := hS.exists_upper_finite hfinite (fun _ hx => hx)
    exact ⟨x, hx, hvs.trans (hs.2 x hmax)⟩

theorem compact_iff_finite (x : H T) :
    IsCompactElement x ↔ ∃ v : T.Node, PrefixCompletion.finite T v = x := by
  rcases x with v | b
  · exact ⟨fun _ => ⟨v, rfl⟩, fun _ => finite_compact T v⟩
  · constructor
    · intro hb; exact False.elim (infinite_not_compact T b hb)
    · rintro ⟨v, h⟩; cases h

theorem compact_set_eq : CompactElements (H T) = Set.range (PrefixCompletion.finite T) := by
  ext x
  exact compact_iff_finite T x

theorem compact_countable : (CompactElements (H T)).Countable := by
  rw [compact_set_eq]
  exact Set.countable_range _

theorem chain_has_lub {S : Set (H T)} (hS : IsChain (· ≤ ·) S) :
    ∃ s : H T, IsLUB S s := by
  classical
  by_cases hinf : ∃ b : T.InfiniteBranch, PrefixCompletion.infinite T b ∈ S
  · obtain ⟨b, hb⟩ := hinf
    refine ⟨PrefixCompletion.infinite T b, ?_, fun _ hu => hu hb⟩
    intro x hx
    rcases hS.total hx hb with h | h
    · exact h
    · exact le_of_eq (PrefixCompletion.infinite_maximal T b x h)
  · let C : Set T.Node := {v | PrefixCompletion.finite T v ∈ S}
    have hfinitepoint : ∀ x ∈ S, ∃ v, PrefixCompletion.finite T v = x := by
      intro x hx
      rcases x with v | b
      · exact ⟨v, rfl⟩
      · exact False.elim (hinf ⟨b, hx⟩)
    have hC : IsChain (· ≤ ·) C := by
      intro x hx y hy hne
      exact hS.total hx hy
    by_cases hf : C.Finite
    · by_cases hne : C.Nonempty
      · obtain ⟨v, hv, hmax⟩ := Set.exists_max_image C T.depth hf hne
        refine ⟨PrefixCompletion.finite T v, ?_, fun _ hu => hu hv⟩
        intro x hx
        obtain ⟨w, rfl⟩ := hfinitepoint x hx
        change w ≤ v
        rcases hC.total hx hv with h | h
        · exact h
        · exact le_of_eq (T.eq_of_le_of_depth_eq h
            (Nat.le_antisymm (T.depth_mono h) (hmax w hx))).symm
      · refine ⟨PrefixCompletion.finite T T.root, ?_, fun x _ => root_le T x⟩
        intro x hx
        obtain ⟨w, rfl⟩ := hfinitepoint x hx
        exact False.elim (hne ⟨w, hx⟩)
    · obtain ⟨M, hM, hCM⟩ := hC.exists_maxChain
      have hMinf : M.Infinite := (Set.not_finite.mp hf).mono hCM
      let b : T.InfiniteBranch := T.infiniteBranchSetEquiv.symm ⟨M, hM, hMinf⟩
      have hb : Set.range b.node = M :=
        congrArg Subtype.val (T.infiniteBranchSetEquiv.apply_symm_apply ⟨M, hM, hMinf⟩)
      refine ⟨PrefixCompletion.infinite T b, ?_, ?_⟩
      · intro x hx
        obtain ⟨v, rfl⟩ := hfinitepoint x hx
        change v ∈ Set.range b.node
        rw [hb]
        exact hCM hx
      · intro z hz
        rcases z with v | c
        · exact False.elim (hf ((T.pathTo_finite v).subset (fun w hw => hz hw)))
        · change b = c
          apply RootedPrefixTree.InfiniteBranch.range_injective T
          rw [hb]
          apply hM.2 (c.range_isBranch T).1
          intro v hv
          have hcofinal : ∃ w ∈ C, v ≤ w := by
            by_contra hn
            apply hf
            apply (T.pathTo_finite v).subset
            intro w hw
            rcases hM.1.total (hCM hw) hv with h | h
            · exact h
            · exact False.elim (hn ⟨w, hw, h⟩)
          obtain ⟨w, hw, hvw⟩ := hcofinal
          exact (c.range_isBranch T).mem_of_le T (hz hw) hvw

theorem algebraic : Preliminaries.IsAlgebraicDcpo (H T) := by
  constructor
  · intro S hS
    exact chain_has_lub T (directed_chain T hS)
  · intro x
    constructor
    · constructor
      · exact ⟨PrefixCompletion.finite T T.root, finite_compact T T.root, root_le T x⟩
      · intro a ha b hb
        rcases comparable_below T ha.2 hb.2 with h | h
        · exact ⟨b, hb, h, le_rfl⟩
        · exact ⟨a, ha, le_rfl, h⟩
    · constructor
      · intro k hk
        exact hk.2
      · intro y hy
        rcases x with v | b
        · exact hy ⟨finite_compact T v, le_rfl⟩
        · apply (branch_prefixes_isLUB T b).2
          rintro k ⟨v, hv, rfl⟩
          exact hy ⟨finite_compact T v, hv⟩

theorem scottDomain : IsScottDomain (H T) where
  algebraic := algebraic T
  hasLeast := ⟨PrefixCompletion.finite T T.root, root_le T⟩
  boundedSuprema := by
    intro S hS
    obtain ⟨z, hz⟩ := hS
    apply chain_has_lub T
    intro x hx y hy _
    exact comparable_below T (hz hx) (hz hy)

theorem pair_lub_of_le {D : Type v} [PartialOrder D] {x y : D} (h : x ≤ y) :
    IsLUB ({x, y} : Set D) y := by
  constructor
  · intro z hz
    rcases Set.mem_insert_iff.mp hz with rfl | hz
    · exact h
    · exact le_of_eq (Set.mem_singleton_iff.mp hz)
  · intro z hz
    exact hz (by simp)

theorem distributive : CompatibleJoinDistributive (H T) := by
  intro x y z joined meet left right hxy hjoin hmeet hleft hright
  have onecase : ∀ x y z joined meet left right : H T,
      x ≤ y → IsLUB ({x, y} : Set (H T)) joined →
      IsGLB ({joined, z} : Set (H T)) meet →
      IsGLB ({x, z} : Set (H T)) left →
      IsGLB ({y, z} : Set (H T)) right →
      IsLUB ({left, right} : Set (H T)) meet := by
    intro x y z joined meet left right hxy hjoin hmeet hleft hright
    have hj : joined = y := hjoin.unique (pair_lub_of_le hxy)
    subst joined
    have hm : meet = right := hmeet.unique hright
    rw [hm]
    apply pair_lub_of_le
    apply hright.2
    intro t ht
    rcases Set.mem_insert_iff.mp ht with rfl | ht
    · exact (hleft.1 (by simp)).trans hxy
    · have ht : t = z := Set.mem_singleton_iff.mp ht
      subst t
      exact hleft.1 (by simp)
  rcases compatible_comparable T hxy with h | h
  · exact onecase x y z joined meet left right h hjoin hmeet hleft hright
  · have hp : ({y, x} : Set (H T)) = {x, y} := Set.pair_comm y x
    have hq : ({right, left} : Set (H T)) = {left, right} := Set.pair_comm right left
    rw [← hq]
    apply onecase y x z joined meet right left h
    · simpa only [hp] using hjoin
    · exact hmeet
    · exact hright
    · exact hleft

theorem isDIDomain : IsDIDomain (H T) where
  toIsScottDomain := scottDomain T
  distributive := distributive T
  finitePrincipalIdeals := by
    intro k hk
    obtain ⟨v, rfl⟩ := (compact_iff_finite T k).mp hk
    exact below_finite_finite T v

theorem pairwise_chain {S : Set (H T)}
    (hS : ∀ x ∈ S, ∀ y ∈ S, Compatible x y) : IsChain (· ≤ ·) S := by
  intro x hx y hy _
  exact compatible_comparable T (hS x hx y hy)

theorem two_coherent :
    CoherenceDegree.IsNCoherent (isDIDomain T).toIsScottDomain 2 (by decide) := by
  apply (CoherenceDegree.coherenceCharacterization (H T)
    (isDIDomain T).toIsScottDomain 2 (by decide)).mpr
  intro S hS
  have hp : ∀ x ∈ S, ∀ y ∈ S, Compatible x y := by
    intro x hx y hy
    have hcard : ({x, y} : Set (H T)).ncard ≤ 2 := by
      by_cases h : x = y
      · subst y; simp
      · exact (Set.ncard_pair h).le
    obtain ⟨z, hz⟩ := hS {x, y} (by
      intro w hw; rcases Set.mem_insert_iff.mp hw with rfl | hw
      · exact hx
      · exact Set.mem_singleton_iff.mp hw ▸ hy)
      ((Set.finite_singleton y).insert x) hcard
    exact ⟨z, hz (by simp), hz (by simp)⟩
  obtain ⟨s, hs⟩ := chain_has_lub T (pairwise_chain T hp)
  exact ⟨s, hs.1⟩

theorem continuous_isStable (hH : IsDIDomain (H T))
    (E : DIDomainObject.{v}) (f : H T → E) (hf : ScottContinuous f) :
    IsStable (DIDomainObject.ofType (H T) hH) E f := by
  refine ⟨hf, ?_⟩
  intro x y hxy
  rcases compatible_comparable T hxy with h | h
  · rw [inf_eq_left.mpr h, inf_eq_left.mpr (hf.monotone h)]
  · rw [inf_eq_right.mpr h, inf_eq_right.mpr (hf.monotone h)]

end DIDomainClassification.PrefixCompletionDomain
