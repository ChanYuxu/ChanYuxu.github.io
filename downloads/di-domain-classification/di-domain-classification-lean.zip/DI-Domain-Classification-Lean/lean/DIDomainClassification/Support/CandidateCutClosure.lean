import DIDomainClassification.Section04.CutClassificationStatements
import DIDomainClassification.Support.FullStableSubcategoryClosure
import DIDomainClassification.Section03.FunctionDegreeUpper
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Support.ProductDegree
import DIDomainClassification.Support.OrderIsoTransport
import DIDomainClassification.Support.FiniteOrderDomains

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.CandidateCutClosure

open CategoryTheory Preliminaries CoherenceDegree Subcategories
open Section02.StableBackground (DomainClosure terminalObject)
open Section03.StableFunctionModels

abbrev closure : DomainClosure.{u} := StableClosureWitness.domainClosure.{u}
abbrev prodObject (D E : CountablyBasedDIDomain.{u}) :=
  Section02.StableBackground.productObject closure D E

def pairFamily (D E : CountablyBasedDIDomain.{u}) : ULift.{u} Bool → Type u
  | ⟨false⟩ => Core D
  | ⟨true⟩ => Core E

instance pairFamilyOrder (D E : CountablyBasedDIDomain.{u}) (b : ULift.{u} Bool) :
    PartialOrder (pairFamily D E b) := by
  rcases b with ⟨b⟩
  cases b <;> dsimp [pairFamily] <;> infer_instance

def pairIso (D E : CountablyBasedDIDomain.{u}) :
    (Core D × Core E) ≃o (∀ b : ULift.{u} Bool, pairFamily D E b) where
  toFun x b := match b with
    | ⟨false⟩ => x.1
    | ⟨true⟩ => x.2
  invFun f := (f ⟨false⟩, f ⟨true⟩)
  left_inv _ := rfl
  right_inv f := by
    funext b
    rcases b with ⟨b⟩
    cases b <;> rfl
  map_rel_iff' := by
    intro x y
    constructor
    · intro h
      exact ⟨h ⟨false⟩, h ⟨true⟩⟩
    · intro h b
      rcases b with ⟨b⟩
      cases b
      · exact h.1
      · exact h.2

def pairScott (D E : CountablyBasedDIDomain.{u}) (b : ULift.{u} Bool) :
    IsScottDomain (pairFamily D E b) := by
  rcases b with ⟨b⟩
  cases b
  · exact (Core D).isDIDomain.toIsScottDomain
  · exact (Core E).isDIDomain.toIsScottDomain

theorem product_degree_le (D E : CountablyBasedDIDomain.{u}) :
    objectDegree (prodObject D E) ≤ max (objectDegree D) (objectDegree E) := by
  let e := pairIso D E
  have hmono := coherenceDegree_mono_of_scott_split
    (Core (prodObject D E)).isDIDomain.toIsScottDomain
    (BPSProductDegree.productScottDomain (pairScott D E))
    (OrderIsoTransport.scottContinuous e) (OrderIsoTransport.scottContinuous e.symm)
    e.left_inv
  rw [BPSProductDegree.product_coherenceDegree_eq (pairScott D E)] at hmono
  apply hmono.trans
  apply Ordinal.iSup_le
  intro b
  rcases b with ⟨b⟩
  cases b
  · exact le_max_left _ _
  · exact le_max_right _ _

theorem isoRetraction {D E : CountablyBasedDIDomain.{u}} (e : D ≅ E) :
    HasStableRetraction (Core D) (Core E) := by
  refine ⟨e.hom, e.inv, ?_⟩
  intro x
  exact congrArg (fun f : D ⟶ D => CountablyBasedDIDomain.toStableHom f x) e.hom_inv_id

theorem finite_retract {D E : CountablyBasedDIDomain.{u}} (hE : Finite E)
    (h : HasStableRetraction (Core D) (Core E)) : Finite D := by
  letI : Finite E := hE
  obtain ⟨s, r, hleft⟩ := h
  exact Finite.of_injective (s : Core D → Core E) hleft.injective

theorem finite_product (D E : CountablyBasedDIDomain.{u})
    (hD : Finite D) (hE : Finite E) : Finite (prodObject D E) := by
  letI : Finite D := hD
  letI : Finite E := hE
  change Finite (Core D × Core E)
  infer_instance

theorem finite_exponential (D E : CountablyBasedDIDomain.{u})
    (hD : Finite D) (hE : Finite E) : Finite (exponential D E) := by
  letI : Finite D := hD
  letI : Finite E := hE
  apply Finite.of_injective (fun f : StableSpace D E => (fun x : Core D => f x))
  intro f g h
  apply StableHom.ext
  intro x
  exact congrFun h x

theorem unit_degree : objectDegree (terminalObject closure.{u}) = 0 := by
  apply (Section02.bps.2.2.2.2.2.1 _ _ (terminalObject closure).countableCompacts).mpr
  intro X
  exact ⟨⟨sSup X, isLUB_sSup X⟩, ⟨sInf X, isGLB_sInf X⟩⟩

theorem two_degree_le : objectDegree FiniteOrderDomains.twoObject.{u} ≤ 2 := by
  letI : Finite FiniteOrderDomains.twoObject.{u} := by
    change Finite FiniteOrderDomains.TwoCarrier.{u}
    infer_instance
  apply (Section02.bps.2.2.2.2.2.2 _ _ FiniteOrderDomains.twoObject.countableCompacts
    2 (by decide)).mpr
  intro M _hM
  change Set FiniteOrderDomains.TwoCarrier.{u} at M
  simpa [FiniteOrderDomains.TwoCarrier] using M.ncard_le_card

theorem two_finite : Finite FiniteOrderDomains.twoObject.{u} := by
  change Finite FiniteOrderDomains.TwoCarrier.{u}
  infer_instance

theorem unit_finite : Finite (terminalObject closure.{u}) := by
  change Finite PUnit.{u+1}
  infer_instance

theorem domain_replete (α : Ordinal.{u+1}) : IsReplete (DomainCut α) := by
  refine ⟨?_⟩
  intro D E e hD
  exact domainCut_of_stable_retraction hD (isoRetraction e.symm)

theorem finite_replete (α : Ordinal.{u+1}) : IsReplete (FiniteDomainCut α) := by
  refine ⟨?_⟩
  intro D E e hD
  exact ⟨domainCut_of_stable_retraction hD.1 (isoRetraction e.symm),
    finite_retract hD.2 (isoRetraction e.symm)⟩

theorem two_lt_of_three_le {α : Ordinal.{u+1}} (hα : 3 ≤ α) : 2 < α := by
  have h23 : (2 : Ordinal.{u+1}) < 3 := by
    simpa only [Order.succ_eq_add_one, OfNat.ofNat] using Order.lt_succ (2 : Ordinal.{u+1})
  exact h23.trans_le hα

theorem domain_unit {α : Ordinal.{u+1}} (hα : 3 ≤ α) :
    DomainCut α (terminalObject closure) := by
  change objectDegree (terminalObject closure) < α
  rw [unit_degree]
  have h01 : (0 : Ordinal.{u+1}) < 1 := by
    simpa only [Order.succ_eq_add_one, zero_add] using Order.lt_succ (0 : Ordinal.{u+1})
  have h12 : (1 : Ordinal.{u+1}) < 2 := by
    simpa only [Order.succ_eq_add_one, one_add_one_eq_two] using
      Order.lt_succ (1 : Ordinal.{u+1})
  exact (h01.trans h12).trans (two_lt_of_three_le hα)

theorem domain_product {α : Ordinal.{u+1}} (D E : CountablyBasedDIDomain.{u})
    (hD : DomainCut α D) (hE : DomainCut α E) : DomainCut α (prodObject D E) :=
  (product_degree_le D E).trans_lt (max_lt hD hE)

theorem domain_exponential {α : Ordinal.{u+1}} (hα : 3 ≤ α)
    (D E : CountablyBasedDIDomain.{u}) (_hD : DomainCut α D) (hE : DomainCut α E) :
    DomainCut α (exponential D E) :=
  (Section03.functionDegreeUpper D E).trans_lt (max_lt (two_lt_of_three_le hα) hE)

theorem domain_hypotheses {α : Ordinal.{u+1}} (hα : 3 ≤ α) :
    Section04.CutModels.CategoryHypotheses (DomainCut α) := by
  refine ⟨?_, domain_replete α, ?_, ?_⟩
  · exact ⟨FiniteOrderDomains.twoObject,
      two_degree_le.trans_lt (two_lt_of_three_le hα),
      FiniteOrderDomains.zero, FiniteOrderDomains.one, FiniteOrderDomains.zero_ne_one⟩
  · exact FullStableSubcategoryClosure.intrinsicallyCartesianClosed
      (DomainCut α) (domain_product) (domain_exponential hα) (domain_unit hα)
  · intro D E hE h
    exact domainCut_of_stable_retraction hE h

theorem finite_unit {α : Ordinal.{u+1}} (hα : 3 ≤ α) :
    FiniteDomainCut α (terminalObject closure) := ⟨domain_unit hα, unit_finite⟩

theorem finite_product_cut {α : Ordinal.{u+1}} (D E : CountablyBasedDIDomain.{u})
    (hD : FiniteDomainCut α D) (hE : FiniteDomainCut α E) :
    FiniteDomainCut α (prodObject D E) :=
  ⟨domain_product D E hD.1 hE.1, finite_product D E hD.2 hE.2⟩

theorem finite_exponential_cut {α : Ordinal.{u+1}} (hα : 3 ≤ α)
    (D E : CountablyBasedDIDomain.{u})
    (hD : FiniteDomainCut α D) (hE : FiniteDomainCut α E) :
    FiniteDomainCut α (exponential D E) :=
  ⟨domain_exponential hα D E hD.1 hE.1, finite_exponential D E hD.2 hE.2⟩

theorem finite_hypotheses {α : Ordinal.{u+1}} (hα : 3 ≤ α) :
    Section04.CutModels.CategoryHypotheses (FiniteDomainCut α) := by
  refine ⟨?_, finite_replete α, ?_, ?_⟩
  · exact ⟨FiniteOrderDomains.twoObject,
      ⟨two_degree_le.trans_lt (two_lt_of_three_le hα), two_finite⟩,
      FiniteOrderDomains.zero, FiniteOrderDomains.one, FiniteOrderDomains.zero_ne_one⟩
  · exact FullStableSubcategoryClosure.intrinsicallyCartesianClosed
      (FiniteDomainCut α) (finite_product_cut) (finite_exponential_cut hα) (finite_unit hα)
  · intro D E hE h
    exact ⟨domainCut_of_stable_retraction hE.1 h, finite_retract hE.2 h⟩

end DIDomainClassification.CandidateCutClosure
