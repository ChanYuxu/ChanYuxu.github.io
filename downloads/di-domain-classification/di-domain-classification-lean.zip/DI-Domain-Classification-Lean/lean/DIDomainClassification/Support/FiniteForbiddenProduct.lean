import DIDomainClassification.Support.FiniteRelativePowersets
import DIDomainClassification.Support.RawStableFunctionOperators
import DIDomainClassification.Section04.CausalRetraction

/-! The printed finite forbidden-product section and retraction, on the
literal carriers and coordinate formulas of manuscript1089--1117. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FiniteForbiddenProduct

open Preliminaries EventStructures FiniteCausalConflicts
open Section04 Section04.FiniteGeneratorModels FiniteRelativePowersets

variable {A : Type u} [PartialOrder A]

theorem conflict_card_two (E : FinitaryPrimeEventStructure A)
    (H : causalConflictFamily E) : 2 ≤ H.val.ncard := by
  rcases H with ⟨H, hH⟩
  obtain ⟨U, hU, rfl⟩ := hH
  exact minimalLower_maximalEvents_card_ge_two E hU

def factorDomain (E : FinitaryPrimeEventStructure A) (H : causalConflictFamily E) :
    IsDIDomain (ProperIn H.val) :=
  relativeDomain H.val (conflict_member_finite E H.property) (conflict_card_two E H)

def factorCore (E : FinitaryPrimeEventStructure A) (H : causalConflictFamily E) :
    DIDomainObject.{u} := relativeCore H.val (factorDomain E H)

def domain [Finite A] (E : FinitaryPrimeEventStructure A) :
    IsDIDomain (ForbiddenProduct E) :=
  RawStableFunctionOperators.productDomain
    (DIDomainObject.ofType (Set A)
      (FiniteOrderDomains.finiteCompleteDistribLattice_isDIDomain (Set A)))
    (DIDomainObject.ofType (∀ H : causalConflictFamily E, ProperIn H.val)
      (RawStableFunctionOperators.piDomain (factorCore E)))

def core [Finite A] (E : FinitaryPrimeEventStructure A)
    (h : IsDIDomain (ForbiddenProduct E)) : DIDomainObject.{u} :=
  DIDomainObject.ofType (ForbiddenProduct E) h

instance finiteCoverCore [Finite A] (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) : Finite (qualitativeCoverCore E C) :=
  inferInstanceAs (Finite (QualitativeCover E))

instance finiteProductCore [Finite A] (E : FinitaryPrimeEventStructure A)
    (h : IsDIDomain (ForbiddenProduct E)) : Finite (core E h) :=
  inferInstanceAs (Finite (ForbiddenProduct E))

def sectionMap (E : FinitaryPrimeEventStructure A) (X : QualitativeCover E) :
    ForbiddenProduct E :=
  (X.val, fun H => ⟨sectionCoordinateValues X.val H.val, ⟨Set.inter_subset_right, by
    intro hH
    exact X.property H.val H.property (hH.trans Set.inter_subset_left)⟩⟩)

def retraction (E : FinitaryPrimeEventStructure A) (p : ForbiddenProduct E) :
    QualitativeCover E := ⟨retractionValues E p, by
  intro H hH hsub
  apply (p.2 ⟨H, hH⟩).property.2
  intro a ha
  exact (hsub ha).2 ⟨H, hH⟩ ha⟩

theorem section_monotone (E : FinitaryPrimeEventStructure A) :
    Monotone (sectionMap E) := by
  intro X Y hXY
  exact ⟨hXY, fun H _ ha => ⟨hXY ha.1, ha.2⟩⟩

theorem retraction_monotone (E : FinitaryPrimeEventStructure A) :
    Monotone (retraction E) := by
  intro p q hpq a ha
  exact ⟨hpq.1 ha.1, fun H hH => hpq.2 H (ha.2 H hH)⟩

theorem product_inf_values [Finite A] (E : FinitaryPrimeEventStructure A)
    (h : IsDIDomain (ForbiddenProduct E)) (p q : ForbiddenProduct E) :
    (h.toIsScottDomain.inf p q).1 = p.1 ∩ q.1 ∧
      ∀ H, ((h.toIsScottDomain.inf p q).2 H).val = (p.2 H).val ∩ (q.2 H).val := by
  let Z : ForbiddenProduct E := (p.1 ∩ q.1, fun H =>
    ⟨(p.2 H).val ∩ (q.2 H).val, ⟨Set.inter_subset_left.trans (p.2 H).property.1,
      fun hsub => (p.2 H).property.2 (hsub.trans Set.inter_subset_left)⟩⟩)
  have hZ : IsGLB ({p, q} : Set (ForbiddenProduct E)) Z := by
    constructor
    · intro W hW
      rcases Set.mem_insert_iff.mp hW with rfl | hW
      · exact ⟨Set.inter_subset_left, fun _ => Set.inter_subset_left⟩
      · rw [Set.mem_singleton_iff.mp hW]
        exact ⟨Set.inter_subset_right, fun _ => Set.inter_subset_right⟩
    · intro W hW
      exact ⟨Set.subset_inter (hW (by simp)).1 (hW (by simp)).1,
        fun H => Set.subset_inter ((hW (by simp)).2 H) ((hW (by simp)).2 H)⟩
  have heq := (h.toIsScottDomain.inf_isGLB p q).unique hZ
  exact ⟨congrArg Prod.fst heq, fun H => congrArg (fun p : ForbiddenProduct E => (p.2 H).val) heq⟩

def stableSection [Finite A] (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) (h : IsDIDomain (ForbiddenProduct E)) :
    StableHom (qualitativeCoverCore E C) (core E h) :=
  StableHom.ofFunction (sectionMap E) ⟨
    FiniteOrderDomains.scottContinuous_of_monotone_finite (section_monotone E), by
    intro X Y _hXY
    apply Prod.ext
    · change (X ⊓ Y : qualitativeCoverCore E C).val =
        (h.toIsScottDomain.inf (sectionMap E X) (sectionMap E Y)).1
      rw [CausalCoverSupport.cover_inf_val, (product_inf_values E h _ _).1]
      rfl
    · funext H
      apply Subtype.ext
      change (X ⊓ Y : qualitativeCoverCore E C).val ∩ H.val =
        ((h.toIsScottDomain.inf (sectionMap E X) (sectionMap E Y)).2 H).val
      rw [CausalCoverSupport.cover_inf_val, (product_inf_values E h _ _).2 H]
      ext a
      simp only [sectionMap, sectionCoordinateValues, Set.mem_inter_iff]
      tauto⟩

def stableRetraction [Finite A] (E : FinitaryPrimeEventStructure A)
    (C : QualitativeCoverClosure E) (h : IsDIDomain (ForbiddenProduct E)) :
    StableHom (core E h) (qualitativeCoverCore E C) :=
  StableHom.ofFunction (retraction E) ⟨
    FiniteOrderDomains.scottContinuous_of_monotone_finite (retraction_monotone E), by
    intro p q _hpq
    apply Subtype.ext
    change retractionValues E (h.toIsScottDomain.inf p q) =
      (retraction E p ⊓ retraction E q : qualitativeCoverCore E C).val
    rw [CausalCoverSupport.cover_inf_val]
    ext a
    change (a ∈ (h.toIsScottDomain.inf p q).1 ∧
      ∀ H : causalConflictFamily E, a ∈ H.val → a ∈ ((h.toIsScottDomain.inf p q).2 H).val) ↔
      ((a ∈ p.1 ∧ ∀ H : causalConflictFamily E, a ∈ H.val → a ∈ (p.2 H).val) ∧
       (a ∈ q.1 ∧ ∀ H : causalConflictFamily E, a ∈ H.val → a ∈ (q.2 H).val))
    rw [(product_inf_values E h p q).1]
    simp only [Set.mem_inter_iff]
    constructor
    · rintro ⟨⟨hap, haq⟩, hcoords⟩
      have hc : ∀ H : causalConflictFamily E, a ∈ H.val →
          a ∈ (p.2 H).val ∧ a ∈ (q.2 H).val := by
        intro H haH
        have ha := hcoords H haH
        rw [(product_inf_values E h p q).2 H] at ha
        exact ha
      exact ⟨⟨hap, fun H haH => (hc H haH).1⟩,
        ⟨haq, fun H haH => (hc H haH).2⟩⟩
    · rintro ⟨⟨hap, hp⟩, ⟨haq, hq⟩⟩
      refine ⟨⟨hap, haq⟩, ?_⟩
      intro H haH
      rw [(product_inf_values E h p q).2 H]
      exact ⟨hp H haH, hq H haH⟩⟩

theorem leftInverse (E : FinitaryPrimeEventStructure A) :
    Function.LeftInverse (retraction E) (sectionMap E) := by
  intro X
  apply Subtype.ext
  ext a
  change (a ∈ X.val ∧ ∀ H : causalConflictFamily E, a ∈ H.val →
    a ∈ X.val ∩ H.val) ↔ a ∈ X.val
  exact ⟨fun h => h.1, fun ha => ⟨ha, fun _ hH => ⟨ha, hH⟩⟩⟩

theorem printedConstruction : FiniteForbiddenProductConstructionStatement.{u} := by
  intro A _ _ E
  let C := CausalCoverSupport.closure E
  let h := domain E
  refine ⟨C, h, stableSection E C h, stableRetraction E C h,
    inferInstance, inferInstance, ?_, ?_, leftInverse E⟩
  · intro X
    exact ⟨rfl, fun _ => rfl⟩
  · intro p
    rfl

end DIDomainClassification.FiniteForbiddenProduct
