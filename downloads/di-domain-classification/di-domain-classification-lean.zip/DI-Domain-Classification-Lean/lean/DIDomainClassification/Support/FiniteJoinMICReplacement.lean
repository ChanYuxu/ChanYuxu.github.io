import DIDomainClassification.Support.FiniteConsistency

/-!
Set-theoretic finite-join replacement used in the contextual join-basis
refinement argument. A MIC set containing a distinguished point is refined
by an actual finite family with that point as its actual LUB. No tree/rank
or function-space closure is assumed in this lemma.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries CoherenceDegree

theorem finite_join_mic_replacement {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (A F : Set D) (a : D)
    (ha : a ∉ A) (hM : IsMinimallyInconsistent hD (A ∪ {a}))
    (hF : F.Finite) (hFa : IsLUB F a) :
    ∃ B : Set D, B.Finite ∧ B ⊆ F ∧ B.Nonempty ∧
      Disjoint A B ∧ IsMinimallyInconsistent hD (A ∪ B) := by
  classical
  have hAfin : A.Finite := hM.1.subset Set.subset_union_left
  have hAbdd : Consistent A := hM.2.2 A (by
    refine ⟨Set.subset_union_left, ?_⟩
    intro h
    exact ha (h (Or.inr (Set.mem_singleton a))))
  have hbad : ¬ Consistent (A ∪ F) := by
    rintro ⟨z, hz⟩
    apply hM.2.1
    refine ⟨z, ?_⟩
    intro b hb
    rcases hb with hb | hb
    · exact hz (Or.inl hb)
    · have hba := Set.mem_singleton_iff.mp hb
      subst b
      exact hFa.2 (fun b hb => hz (Or.inr hb))
  obtain ⟨N, hNsub, hNmic⟩ :=
    exists_minimally_inconsistent_subset hD (A ∪ F) (hAfin.union hF) hbad
  have hAN : A ⊆ N := by
    intro b hb
    by_contra hbN
    have hba : b ≠ a := fun h => ha (h ▸ hb)
    have hproper : (A \ {b}) ∪ {a} ⊂ A ∪ {a} := by
      refine ⟨Set.union_subset_union (fun _ hx => hx.1) (Set.Subset.refl _), ?_⟩
      intro h
      rcases h (Or.inl hb) with h | h
      · exact h.2 (Set.mem_singleton b)
      · exact hba (Set.mem_singleton_iff.mp h)
    obtain ⟨z, hz⟩ := hM.2.2 _ hproper
    apply hNmic.2.1
    refine ⟨z, ?_⟩
    intro c hc
    rcases hNsub hc with hcA | hcF
    · exact hz (Or.inl ⟨hcA, by
        intro hcb
        exact hbN (Set.mem_singleton_iff.mp hcb ▸ hc)⟩)
    · exact (hFa.1 hcF).trans (hz (Or.inr (Set.mem_singleton a)))
  let B : Set D := N \ A
  have hBF : B ⊆ F := by
    intro b hb
    exact (hNsub hb.1).resolve_left hb.2
  have hBN : A ∪ B = N := by
    ext b
    constructor
    · intro h
      exact h.elim (fun h => hAN h) (fun h => h.1)
    · intro h
      by_cases hb : b ∈ A
      · exact Or.inl hb
      · exact Or.inr ⟨h, hb⟩
  have hBne : B.Nonempty := by
    by_contra hn
    have hNinA : N ⊆ A := by
      intro b hb
      by_contra hba
      exact hn ⟨b, ⟨hb, hba⟩⟩
    exact hNmic.2.1 (hAbdd.mono hNinA)
  refine ⟨B, hNmic.1.subset (fun _ h => h.1), hBF, hBne, ?_, ?_⟩
  · exact Set.disjoint_left.mpr (fun _ hA hB => hB.2 hA)
  · simpa only [hBN] using hNmic

end DIDomainClassification.PointwiseFunctionSupport
