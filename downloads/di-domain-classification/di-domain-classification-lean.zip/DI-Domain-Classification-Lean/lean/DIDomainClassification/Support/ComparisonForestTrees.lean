import DIDomainClassification.Section04.Forest
import DIDomainClassification.Section04.TreeComparison
import DIDomainClassification.Support.StableSplitUniverseLift
import DIDomainClassification.Support.CountableRankCofinality
import Mathlib.SetTheory.Cardinal.Regular

/-! Actual thin-forest tree comparisons and the ordinal selection steps.
The thin trees stay over Nat. Ambient lifts are genuine prefix trees, and
their comparisons use the proved native stable order and actual split maps. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonForestTrees
open Preliminaries Trees CoherenceDegree Section04 AdditionalSourceModels
open Section03.StableFunctionModels
open ForestUniverseTransport

def liftedCertificate (T : RootedPrefixTree ℕ) (hp : T.IsProper) :
    IsCountablyBasedDIDomain (TreeDomain (liftTree.{u} T)) :=
  TreeRealisationConfigurations.treeCountablyBased _ (proper_liftTree T hp)

def liftedObject (T : RootedPrefixTree ℕ) (hp : T.IsProper) :
    CountablyBasedDIDomain.{u} := treeObject _ (liftedCertificate.{u} T hp)

def liftedToSmallIso (T : RootedPrefixTree ℕ) :
    TreeDomain (liftTree.{u} T) ≃o TreeDomain T :=
  (liftDomainOrderIso T).symm.trans (ForestProductMaps.liftOrderIso _)

theorem lifted_realisation (T : RootedPrefixTree ℕ) (hp : T.IsProper)
    (hT : IsCountablyBasedDIDomain (TreeDomain T))
    (hH : IsCountablyBasedDIDomain (BranchCompletion T hp))
    (E : CountablyBasedDIDomain.{u})
    (hRet : HasStableRetraction (treeCore T hT.1)
      (functionCore (completionCB T hp hH).toDIDomainObject (Core E))) :
    StableComparison (liftedObject.{u} T hp) E := by
  obtain ⟨hL, hL2, hSplit⟩ := StableSplitUniverseLift.transport.{u,0}
    (treeCore T hT.1) (completionCB T hp hH) (Core E)
    (Core (liftedObject T hp)) (liftedToSmallIso T)
    (PrefixCompletionDomain.two_coherent T) hRet
  exact ⟨cbObject _ hL, hL2, hSplit⟩

theorem lifted_wellFounded_comparison (T S : RootedPrefixTree ℕ)
    (hp : T.IsProper) (hq : S.IsProper)
    (wfT : T.IsWellFounded) (wfS : S.IsWellFounded)
    (hRank : T.treeRank wfT ≤ S.treeRank wfS) :
    StableComparison (liftedObject.{u} T hp) (liftedObject.{u} S hq) := by
  apply treeComparison_wellFounded (liftTree T) (liftTree S)
    (proper_liftTree T hp) (proper_liftTree S hq)
    (lift_wellFounded T wfT) (lift_wellFounded S wfS)
  rw [treeRank_lift T wfT, treeRank_lift S wfS]
  exact Ordinal.lift_le.mpr hRank

theorem lifted_infinite_comparison (T S : RootedPrefixTree ℕ)
    (hp : T.IsProper) (hq : S.IsProper) (hInf : S.HasInfiniteBranch) :
    StableComparison (liftedObject.{u} T hp) (liftedObject.{u} S hq) :=
  treeComparison_infinite (liftTree T) (liftTree S)
    (proper_liftTree T hp) (proper_liftTree S hq) ((lift_infinite_iff S).mpr hInf)

def contribution (T : RootedPrefixTree ℕ) (hT : IsScottDomain (TreeDomain T)) :
    Ordinal.{u+1} := Ordinal.lift.{u+1} (coherenceDegree hT)

theorem contribution_wellFounded (T : RootedPrefixTree ℕ) (hp : T.IsProper)
    (hT : IsScottDomain (TreeDomain T)) (wfT : T.IsWellFounded) :
    contribution.{u} T hT = Ordinal.lift.{u+1} (T.treeRank wfT + 1) := by
  unfold contribution
  rw [TreeDomainDegree.wellFounded_treeDomain_degree_eq T hp wfT]
  exact Ordinal.lift_lift _

theorem contribution_infinite (T : RootedPrefixTree ℕ) (hp : T.IsProper)
    (hT : IsScottDomain (TreeDomain T)) (hInf : T.HasInfiniteBranch) :
    contribution.{u} T hT = Subcategories.firstUncountableBound.{u} := by
  unfold contribution
  rw [TreeDomainDegree.infiniteBranch_treeDomain_degree_eq T hp hInf]
  simp only [Subcategories.firstUncountableBound, Cardinal.lift_ord,
    Cardinal.lift_succ, Cardinal.lift_aleph0]

theorem wellFounded_of_contribution_lt (T : RootedPrefixTree ℕ) (hp : T.IsProper)
    (hT : IsScottDomain (TreeDomain T))
    (hLt : contribution.{u} T hT < Subcategories.firstUncountableBound.{u}) :
    T.IsWellFounded := by
  by_contra h
  have hInf : T.HasInfiniteBranch := not_not.mp h
  rw [contribution_infinite T hp hT hInf] at hLt
  exact (lt_irrefl _) hLt

theorem wellFounded_contribution_lt (T : RootedPrefixTree ℕ) (hp : T.IsProper)
    (hT : IsScottDomain (TreeDomain T)) (wfT : T.IsWellFounded) :
    contribution.{u} T hT < Subcategories.firstUncountableBound.{u} := by
  rw [contribution_wellFounded T hp hT wfT]
  have hc : (T.treeRank wfT + 1).card ≤ Cardinal.aleph0 :=
    OrdinalSupport.card_acc_rank_add_one_le_aleph0
      ((T.isWellFounded_iff_wellFounded_reverseChildRelation.mp wfT).apply T.root)
  apply Cardinal.card_le_iff.mp
  rw [← Ordinal.lift_card]
  exact Cardinal.lift_le_aleph0.mpr hc

/-- The source uses a successor below a supremum, not attainment of a supremum. -/
theorem exists_rank_ge {I : Type} (T : RootedPrefixTree ℕ)
    (S : I → RootedPrefixTree ℕ) (wfT : T.IsWellFounded)
    (wfS : ∀ i, (S i).IsWellFounded)
    (hBound : Ordinal.lift.{u+1} (T.treeRank wfT + 1) ≤
      ⨆ i, Ordinal.lift.{u+1} ((S i).treeRank (wfS i) + 1)) :
    ∃ i, T.treeRank wfT ≤ (S i).treeRank (wfS i) := by
  classical
  by_contra h
  have hUpper : (⨆ i, Ordinal.lift.{u+1} ((S i).treeRank (wfS i) + 1)) ≤
      Ordinal.lift.{u+1} (T.treeRank wfT) := by
    apply Ordinal.iSup_le
    intro i
    have hLt : (S i).treeRank (wfS i) < T.treeRank wfT :=
      lt_of_not_ge (fun hi => h ⟨i, hi⟩)
    exact Ordinal.lift_le.mpr (by
      simpa only [Order.succ_eq_add_one] using Order.succ_le_iff.mpr hLt)
  have hStrict : Ordinal.lift.{u+1} (T.treeRank wfT) <
      Ordinal.lift.{u+1} (T.treeRank wfT + 1) :=
    Ordinal.lift_lt.mpr (by
      simpa only [Order.succ_eq_add_one] using Order.lt_succ (T.treeRank wfT))
  exact (not_le_of_gt hStrict) (hBound.trans hUpper)

theorem exists_infinite_of_sup_eq {I : Type} [Countable I]
    (S : I → RootedPrefixTree ℕ) (hp : ∀ i, (S i).IsProper)
    (hS : ∀ i, IsScottDomain (TreeDomain (S i)))
    (hEq : (⨆ i, contribution.{u} (S i) (hS i)) =
      Subcategories.firstUncountableBound.{u}) :
    ∃ i, (S i).HasInfiniteBranch := by
  classical
  by_contra h
  have hWf : ∀ i, (S i).IsWellFounded := fun i hi => h ⟨i, hi⟩
  have hLt : (⨆ i, contribution.{u} (S i) (hS i)) <
      Subcategories.firstUncountableBound.{u} := by
    simpa only [Subcategories.firstUncountableBound, Cardinal.succ_aleph0,
      Cardinal.ord_aleph] using
      (Ordinal.iSup_lt_omega_one (fun i => by
        simpa only [Subcategories.firstUncountableBound, Cardinal.succ_aleph0,
          Cardinal.ord_aleph] using
          (wellFounded_contribution_lt.{u} (S i) (hp i) (hS i) (hWf i))))
  rw [hEq] at hLt
  exact (lt_irrefl _) hLt

end DIDomainClassification.ComparisonForestTrees
