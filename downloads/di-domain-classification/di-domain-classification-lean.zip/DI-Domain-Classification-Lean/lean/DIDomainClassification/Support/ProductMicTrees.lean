import DIDomainClassification.Support.ProductMICProjection
import DIDomainClassification.Support.FiniteLeafColourPruning

/-!
Actual finite-coordinate leaf pruning and coordinate projection of product
MIC trees. The colour family is the FINITE support of the actual compact root.
No finite branching, countability of all coordinates/points, or product degree
or rank-refinement premise is assumed. The source alphabet/root are retained.
-/

set_option autoImplicit false
universe u v w z
noncomputable section

namespace DIDomainClassification.BPSProductDegree

open OrderCore Preliminaries CoherenceDegree Trees FiniteLeafColourPruning

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]

def projectLabel {Index : Type w} (T : RootedPrefixTree Index)
    (label : T.Node → ↥(CompactElements (∀ i, D i))) (i : I) :
    T.Node → ↥(CompactElements (D i)) :=
  fun x => ⟨(label x).val i, compact_projection (label x).property i⟩

theorem labelImage_project {Index : Type w} (T : RootedPrefixTree Index)
    (label : T.Node → ↥(CompactElements (∀ i, D i))) (i : I) (c : Set T.Node) :
    labelImage T (projectLabel T label i) c = Function.eval i '' labelImage T label c := by
  symm
  exact Set.image_image _ _ c

def prunedProjectLabel {Index : Type w} (T S : RootedPrefixTree Index)
    (hsub : S.nodes ⊆ T.nodes) (label : T.Node → ↥(CompactElements (∀ i, D i)))
    (i : I) : S.Node → ↥(CompactElements (D i)) :=
  projectLabel S (fun x => label (inclusionNodeMap T S hsub x)) i

theorem pruned_projection_image {Index : Type w} (T S : RootedPrefixTree Index)
    (hsub : S.nodes ⊆ T.nodes) (hroot : S.rootList = T.rootList)
    (label : T.Node → ↥(CompactElements (∀ i, D i))) (i : I) (leaf : S.Node) :
    labelImage S (prunedProjectLabel T S hsub label i) (S.pathTo leaf) =
      Function.eval i '' labelImage T label (T.pathTo (inclusionNodeMap T S hsub leaf)) := by
  rw [prunedProjectLabel, labelImage_project]
  congr 1
  have hpath := inclusionNodeMap_pathTo T S hsub hroot leaf
  change (fun x => (label (inclusionNodeMap T S hsub x) : ∀ i, D i)) '' S.pathTo leaf = _
  rw [← hpath, labelImage, Set.image_image]

theorem branch_injective_of_leaf_paths {Index : Type w} {P : Type z}
    (T : RootedPrefixTree Index) (hT : T.IsWellFounded) (label : T.Node → P)
    (hPaths : ∀ leaf : T.Node, T.IsLeaf leaf → Set.InjOn label (T.pathTo leaf))
    {c : Set T.Node} (hc : T.IsBranch c) : Set.InjOn label c := by
  intro x hx y hy hxy
  rcases hc.1.total hx hy with hxy' | hyx
  · obtain ⟨leaf, hleaf, hyl⟩ := exists_leaf_extension T hT y
    exact hPaths leaf hleaf (hxy'.trans hyl) hyl hxy
  · obtain ⟨leaf, hleaf, hxl⟩ := exists_leaf_extension T hT x
    exact hPaths leaf hleaf hxl (hyx.trans hxl) hxy

theorem coordinate_path_injective (hD : ∀ i, IsScottDomain (D i)) {Index : Type w}
    (M : MicTree (∀ i, D i) (productScottDomain hD) Index)
    (S : RootedPrefixTree Index) (hsub : S.nodes ⊆ M.tree.nodes)
    (i : I) (leaf : S.Node)
    (hleaf : M.tree.IsLeaf (inclusionNodeMap M.tree S hsub leaf))
    (hbad : ¬ Consistent (Function.eval i '' labelImage M.tree M.label
      (M.tree.pathTo (inclusionNodeMap M.tree S hsub leaf)))) :
    Set.InjOn (prunedProjectLabel M.tree S hsub M.label i) (S.pathTo leaf) := by
  have hmic := M.isMicTree.finiteBranch_mic
    ⟨inclusionNodeMap M.tree S hsub leaf, hleaf, rfl⟩
  have hProj := project_injective_on_mic hD hmic i hbad
  intro x hx y hy hxy
  have hVector : (M.label (inclusionNodeMap M.tree S hsub x)).val =
      (M.label (inclusionNodeMap M.tree S hsub y)).val :=
    hProj ⟨_, hx, rfl⟩ ⟨_, hy, rfl⟩ (congrArg Subtype.val hxy)
  have hNode := M.isMicTree.branchInjective (M.tree.pathTo_isBranch hleaf)
    hx hy (Subtype.ext hVector)
  exact Subtype.ext (congrArg (fun x : M.tree.Node => x.val) hNode)

/-- Every actual WF product MIC tree yields an actual coordinate MIC tree on
a same-root, same-rank subtree of the VERY SAME alphabet. The chosen coordinate
comes from the finite support of the actual compact root, not an input bound.
-/
theorem exists_coordinate_mic_tree (hD : ∀ i, IsScottDomain (D i)) {Index : Type w}
    (M : MicTree (∀ i, D i) (productScottDomain hD) Index) (hM : M.tree.IsWellFounded) :
    ∃ (i : I) (N : MicTree (D i) (hD i) Index) (hN : N.tree.IsWellFounded),
      N.tree.rootList = M.tree.rootList ∧ N.tree.nodes ⊆ M.tree.nodes ∧
      N.tree.treeRank hN = M.tree.treeRank hM := by
  classical
  let k : ∀ i, D i := (M.label M.tree.root).val
  let Colour := rootSupport hD k
  letI : Finite Colour := (rootSupport_finite hD (M.label M.tree.root).property).to_subtype
  let L : Colour → Set M.tree.Node := fun i => {leaf |
    ¬ Consistent (Function.eval i.val '' labelImage M.tree M.label (M.tree.pathTo leaf))}
  have hcover : ∀ leaf : M.tree.Node, M.tree.IsLeaf leaf → ∃ i : Colour, leaf ∈ L i := by
    intro leaf hleaf
    have hmic := M.isMicTree.finiteBranch_mic ⟨leaf, hleaf, rfl⟩
    have hk : k ∈ labelImage M.tree M.label (M.tree.pathTo leaf) :=
      ⟨M.tree.root, M.tree.root_le leaf, rfl⟩
    obtain ⟨i, hiSupport, hiBad, _hiMic, _hiInj⟩ := mic_coordinate_witness hD hmic hk
    exact ⟨⟨i, hiSupport⟩, hiBad⟩
  obtain ⟨i, S, hsub, hS, hroot, hrank, hLeaves, hProper⟩ :=
    finite_leaf_class_pruning M.tree hM L hcover
  have hSproper : S.IsProper := hProper M.proper
  let label := prunedProjectLabel M.tree S hsub M.label i.val
  have hPaths : ∀ leaf : S.Node, S.IsLeaf leaf → Set.InjOn label (S.pathTo leaf) := by
    intro leaf hleaf
    have h := hLeaves leaf hleaf
    exact coordinate_path_injective hD M S hsub i.val leaf h.1 h.2
  have hBranches : ∀ c : Set S.Node, S.IsBranch c → Set.InjOn label c := by
    intro c hc
    exact branch_injective_of_leaf_paths S hS label hPaths hc
  have hFinite : ∀ c : Set S.Node, S.IsFiniteCompleteBranch c →
      IsMinimallyInconsistent (hD i.val) (labelImage S label c) := by
    rintro c ⟨leaf, hleaf, rfl⟩
    have h := hLeaves leaf hleaf
    have hmic := M.isMicTree.finiteBranch_mic ⟨inclusionNodeMap M.tree S hsub leaf, h.1, rfl⟩
    rw [pruned_projection_image M.tree S hsub hroot M.label i.val leaf]
    exact project_mic hD hmic i.val h.2
  let N : MicTree (D i.val) (hD i.val) Index := {
    tree := S
    proper := hSproper
    label := label
    isMicTree := (isMicTree_iff (hD i.val) S hSproper label).2 ⟨hBranches, hFinite⟩ }
  exact ⟨i.val, N, hS, hroot, hsub, hrank⟩

end DIDomainClassification.BPSProductDegree
