import DIDomainClassification.Support.LambdaEnvironment

/-! Structural interpretation of the actual indexed de Bruijn terms. The
kernel syntax recursor returns a stable semantic map, rather than storing
stability or lambda laws as fields of an interpretation certificate. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.LambdaInterpretation

open Preliminaries Section03.StableFunctionModels Section05 Section05.LambdaBetaModels
open LambdaEnvironment

variable {E : CountablyBasedDIDomain.{u}} (p : StableReflexivePair E)

def meaning {n : ℕ} (t : Term n) : StableHom (environmentCore E n) (Core E) :=
  Term.rec (motive := fun n _ => StableHom (environmentCore E n) (Core E))
    (fun i => projection E _ i)
    (fun _ _ hf hx => StableHom.comp (application E p)
      (StableCCCOperations.pair trueClosure (environment E _) E E hf hx))
    (fun _ ht => abstract E p _ ht) t

def interpretation : Interpretation E where
  eval t := meaning p t

abbrev eval {n : ℕ} (t : Term n) (env : Fin n → Core E) : Core E :=
  (interpretation p).eval t env

theorem eval_var {n : ℕ} (i : Fin n) (env : Fin n → Core E) :
    eval p (.var i) env = env i := rfl

theorem eval_app {n : ℕ} (f x : Term n) (env : Fin n → Core E) :
    eval p (.app f x) env = p.application (eval p f env) (eval p x env) := rfl

theorem eval_lam {n : ℕ} (t : Term (n+1)) (env : Fin n → Core E) :
    eval p (.lam t) env = p.sectionMap (curriedBody E n (meaning p t) env) := rfl

theorem lam_congr {n m : ℕ} (t : Term (n+1)) (s : Term (m+1))
    (env : Fin n → Core E) (env' : Fin m → Core E)
    (h : ∀ x : Core E, eval p t (extend x env) = eval p s (extend x env')) :
    eval p (.lam t) env = eval p (.lam s) env' := by
  rw [eval_lam, eval_lam]
  apply congrArg (p.sectionMap : StableSpace E E → Core E)
  apply StableHom.ext
  intro x
  exact h x

theorem apply_lam {n : ℕ} (t : Term (n+1)) (env : Fin n → Core E) (x : Core E) :
    p.application (eval p (.lam t) env) x = eval p t (extend x env) := by
  rw [eval_lam]
  change (p.retractionMap (p.sectionMap (curriedBody E n (meaning p t) env))) x = _
  rw [p.split]
  rfl

theorem equations : Equations p (interpretation p) := by
  refine ⟨fun _ _ _ => rfl, fun _ _ _ _ => rfl, ?_⟩
  intro n t env
  exact ⟨curriedBody E n (meaning p t) env, fun _ => rfl, rfl⟩

theorem stableInterpretation : StableInterpretation (interpretation p) := by
  intro n
  exact ⟨environmentCB E n, fun t => StableHom.isStable (meaning p t)⟩

theorem application_stable :
    ∃ hProduct : IsCountablyBasedDIDomain (Core E × Core E),
      IsStable (Section04.AdditionalSourceModels.cbObject (Core E × Core E) hProduct).toDIDomainObject
        (Core E) (fun xy => p.application xy.1 xy.2) :=
  ⟨trueClosure.product E E, StableHom.isStable (application E p)⟩

end DIDomainClassification.LambdaInterpretation
