import DIDomainClassification.Support.RootExpansion

/-! Explicit arbitrary-root normalization adapters and honest properness
criteria. No frozen relative/forest/expansion module is changed. -/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.TreeGrafting

open Trees

variable {Index : Type u} {Component : Type v}

def normalizedForest (S : Component → RootedPrefixTree Index) (tag : Component → Index)
    [Countable Component] : RootedPrefixTree Index :=
  forest (fun i => (S i).normalized) tag (fun _ => rfl)

def normalizedForestEmbed (S : Component → RootedPrefixTree Index) (tag : Component → Index)
    [Countable Component] (i : Component) (v : (S i).Node) : (normalizedForest S tag).Node :=
  forestEmbed (fun i => (S i).normalized) tag (fun _ => rfl) i ((S i).normalizeOrderIso v)

theorem normalizedForestEmbed_val (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (i : Component) (v : (S i).Node) :
    (normalizedForestEmbed S tag i v).val = tag i :: v.val.drop (S i).rootList.length := rfl

theorem normalizedForest_isWellFounded (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (htag : Function.Injective tag)
    (hS : ∀ i, (S i).IsWellFounded) : (normalizedForest S tag).IsWellFounded :=
  forest_isWellFounded (fun i => (S i).normalized) tag (fun _ => rfl) htag
    (fun i => (S i).normalized_isWellFounded_iff.mpr (hS i))

theorem normalizedForestEmbed_nodeRank_eq (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (htag : Function.Injective tag)
    (hS : ∀ i, (S i).IsWellFounded) (i : Component) (v : (S i).Node) :
    (normalizedForest S tag).nodeRank (normalizedForest_isWellFounded S tag htag hS)
      (normalizedForestEmbed S tag i v) = (S i).nodeRank (hS i) v :=
  (forestEmbed_nodeRank_eq (fun i => (S i).normalized) tag (fun _ => rfl) htag
    (fun i => (S i).normalized_isWellFounded_iff.mpr (hS i)) i
    ((S i).normalizeOrderIso v)).trans (normalized_nodeRank_eq (S i) (hS i) v)

theorem normalizedForest_treeRank_eq (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (htag : Function.Injective tag)
    (hS : ∀ i, (S i).IsWellFounded) :
    (normalizedForest S tag).treeRank (normalizedForest_isWellFounded S tag htag hS) =
      ⨆ i : Component, (S i).treeRank (hS i) + 1 := by
  have h := forest_treeRank_eq (fun i => (S i).normalized) tag (fun _ => rfl) htag
    (fun i => (S i).normalized_isWellFounded_iff.mpr (hS i))
  exact h.trans (congrArg (fun f : Component → Ordinal.{u} => ⨆ i, f i)
    (funext (fun i => congrArg (fun o : Ordinal.{u} => o + 1)
      (normalized_treeRank_eq (S i) (hS i)))))

theorem normalizedForestEmbed_isLeaf_iff (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (htag : Function.Injective tag)
    (i : Component) (v : (S i).Node) :
    (normalizedForest S tag).IsLeaf (normalizedForestEmbed S tag i v) ↔ (S i).IsLeaf v :=
  (forestEmbed_isLeaf_iff (fun i => (S i).normalized) tag (fun _ => rfl) htag i
    ((S i).normalizeOrderIso v)).trans ((S i).normalizeOrderIso_isLeaf v)

theorem normalizedForest_pathTo_embed (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (htag : Function.Injective tag)
    (i : Component) (v : (S i).Node) :
    (normalizedForest S tag).pathTo (normalizedForestEmbed S tag i v) =
      {(normalizedForest S tag).root} ∪ normalizedForestEmbed S tag i '' (S i).pathTo v := by
  have h := forest_pathTo_embed (fun i => (S i).normalized) tag (fun _ => rfl) htag i
    ((S i).normalizeOrderIso v)
  rw [← (S i).normalizeOrderIso_pathTo v, Set.image_image] at h
  exact h

theorem normalizedForest_finiteCompleteBranch (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (htag : Function.Injective tag)
    (i : Component) (c : Set (S i).Node) (hc : (S i).IsFiniteCompleteBranch c) :
    (normalizedForest S tag).IsFiniteCompleteBranch
      ({(normalizedForest S tag).root} ∪ normalizedForestEmbed S tag i '' c) := by
  have h := forest_finiteCompleteBranch (fun i => (S i).normalized) tag (fun _ => rfl) htag i
    ((S i).normalizeOrderIso '' c) (((S i).normalizeOrderIso_isFiniteCompleteBranch c).mpr hc)
  rw [Set.image_image] at h
  exact h

theorem isProper_iff_root_not_leaf (T : RootedPrefixTree Index) (hT : T.IsWellFounded) :
    T.IsProper ↔ ¬ T.IsLeaf T.root := by
  constructor
  · intro hp hleaf
    letI : Nontrivial T.Node := hp.1
    obtain ⟨v, hv⟩ := exists_ne T.root
    exact hv (hleaf v (T.root_le v))
  · intro hn
    have hchild : ∃ v : T.Node, T.IsChild T.root v := by
      by_contra h
      exact hn ((T.isLeaf_iff_no_child T.root).mpr h)
    obtain ⟨v, hv⟩ := hchild
    have hne : v ≠ T.root := by
      intro heq
      exact T.isChild_irrefl T.root (heq ▸ hv)
    refine T.isProper_iff.mpr ⟨⟨⟨v, T.root, hne⟩⟩, ?_⟩
    intro x
    obtain ⟨leaf, hl, hxl⟩ := FiniteLeafColourPruning.exists_leaf_extension T hT x
    exact ⟨leaf, hl, hxl⟩

theorem forest_isProper_iff (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) [Countable Component] (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (hS : ∀ i, (S i).IsWellFounded) :
    (forest S tag hroot).IsProper ↔ Nonempty Component := by
  rw [isProper_iff_root_not_leaf _ (forest_isWellFounded S tag hroot htag hS),
    forest_root_isLeaf_iff]
  constructor
  · intro hn
    by_contra h
    exact hn ⟨fun i => h ⟨i⟩⟩
  · rintro ⟨i⟩ he
    exact he.false i

theorem rootExpansion_isProper_iff (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (hS : S.IsWellFounded) (n : ℕ) :
    (rootExpansion S hroot marker n).IsProper ↔ S.IsProper ∨ 0 < n := by
  cases n with
  | zero =>
    change S.IsProper ↔ S.IsProper ∨ 0 < 0
    simp only [Nat.not_lt_zero, or_false]
  | succ n =>
    have hp : (rootExpansion S hroot marker (n + 1)).IsProper :=
      (forest_isProper_iff (fun _ : Unit => rootExpansion S hroot marker n) (fun _ => marker)
        (fun _ => rootExpansion_rootList S hroot marker n) (fun a b _ => Subsingleton.elim a b)
        (fun _ => rootExpansion_isWellFounded S hroot marker hS n)).mpr ⟨()⟩
    exact ⟨fun _ => Or.inr (Nat.zero_lt_succ n), fun _ => hp⟩

end DIDomainClassification.TreeGrafting

