import DIDomainClassification.Support.SeparatedSumOrder
import DIDomainClassification.Section02.CoherenceCharacterization

/-! The actual dI-domain structure and countable compact basis of the sum. -/
set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.SeparatedSumDomain
open OrderCore Preliminaries
open Section03.StableFunctionModels
open Section04.SeparatedSumModels SeparatedSumOrder

variable {I : Type v} (H : I → CountablyBasedDIDomain.{u})

theorem sum_boundedSuprema (X : Set (Carrier H)) (hX : BddAbove X) :
    ∃ s : Carrier H, IsLUB X s := by
  obtain ⟨z, hz⟩ := hX
  rcases cases_sum H z with rfl | ⟨i, b, rfl⟩
  · exact ⟨bottom H, hz, fun _ _ => bot_le⟩
  · have hF := inFiber_of_upper H (fun x hx => hz hx)
    by_cases hne : (fiberValues H i X).Nonempty
    · have hB : BddAbove (fiberValues H i X) :=
        ⟨b, fun a ha => (component_le_iff H i a b).mp (hz ha)⟩
      obtain ⟨s, hs⟩ := (Core (H i)).isDIDomain.toIsScottDomain.boundedSuprema
        (fiberValues H i X) hB
      exact ⟨component H i s, lift_fiber_lub H hF hne hs⟩
    · refine ⟨bottom H, ?_, fun _ _ => bot_le⟩
      intro x hx
      rcases hF x hx with rfl | ⟨a, rfl⟩
      · exact le_rfl
      · exact False.elim (hne ⟨a, hx⟩)

def scott : IsScottDomain (Carrier H) :=
  ⟨sum_isAlgebraic H, ⟨bottom H, fun _ => bot_le⟩, sum_boundedSuprema H⟩

theorem pair_lub_of_le (x y : Carrier H) (hxy : x ≤ y) :
    IsLUB ({x,y} : Set (Carrier H)) y := by
  constructor
  · intro a ha
    rcases ha with rfl | rfl
    · exact hxy
    · exact le_rfl
  · intro z hz
    exact hz (by simp)

theorem component_compatible_iff (i : I) (x y : Core (H i)) :
    Compatible (component H i x) (component H i y) ↔ Compatible x y := by
  constructor
  · rintro ⟨z, hx, hy⟩
    obtain ⟨b, rfl, hxb⟩ := component_le_elim H hx
    exact ⟨b, hxb, (component_le_iff H i y b).mp hy⟩
  · rintro ⟨z, hx, hy⟩
    exact ⟨component H i z, component_mono H i hx, component_mono H i hy⟩

theorem component_pair_lub (i : I) (x y s : Core (H i))
    (hs : IsLUB ({component H i x,component H i y} : Set (Carrier H))
      (component H i s)) : IsLUB ({x,y} : Set (Core (H i))) s := by
  constructor
  · intro a ha
    apply (component_le_iff H i a s).mp
    apply hs.1
    rcases ha with rfl | rfl <;> simp
  · intro z hz
    apply (component_le_iff H i s z).mp
    apply hs.2
    intro a ha
    rcases ha with rfl | rfl
    · exact component_mono H i (hz (by simp))
    · exact component_mono H i (hz (by simp))

theorem component_pair_glb (i : I) (x y : Core (H i)) :
    IsGLB ({component H i x,component H i y} : Set (Carrier H))
      (component H i (x ⊓ y)) := by
  constructor
  · intro a ha
    rcases ha with rfl | rfl
    · exact component_mono H i inf_le_left
    · exact component_mono H i inf_le_right
  · intro z hz
    rcases below_component H (hz (by simp : component H i x ∈
        ({component H i x,component H i y} : Set (Carrier H)))) with rfl | ⟨a, rfl, hax⟩
    · exact bot_le
    · apply component_mono H i
      exact le_inf hax ((component_le_iff H i a y).mp (hz (by simp)))

theorem inf_component (i : I) (x y : Core (H i)) :
    (scott H).inf (component H i x) (component H i y) =
      component H i (x ⊓ y) :=
  ((scott H).inf_isGLB _ _).unique (component_pair_glb H i x y)

theorem inf_bottom (x : Carrier H) :
    (scott H).inf x (bottom H) = bottom H :=
  le_antisymm ((scott H).inf_le_right _ _) bot_le

theorem bottom_inf (x : Carrier H) :
    (scott H).inf (bottom H) x = bottom H :=
  le_antisymm ((scott H).inf_le_left _ _) bot_le

theorem inf_distinct (i j : I) (x : Core (H i)) (y : Core (H j)) (hij : i ≠ j) :
    (scott H).inf (component H i x) (component H j y) = bottom H := by
  apply ((scott H).inf_isGLB _ _).unique
  constructor
  · intro a _ha
    exact bot_le
  · intro z hz
    rcases below_component H (hz (by simp : component H i x ∈
        ({component H i x,component H j y} : Set (Carrier H)))) with rfl | ⟨a, rfl, _⟩
    · exact le_rfl
    · exact False.elim (hij (compatible_indices H
        ⟨component H j y, hz (by simp), le_rfl⟩))

theorem sum_distributive : CompatibleJoinDistributive (Carrier H) := by
  intro x y z joined meet left right hxy hj hm hl hr
  have hmeet : meet = (scott H).inf joined z :=
    hm.unique ((scott H).inf_isGLB _ _)
  have hleft : left = (scott H).inf x z :=
    hl.unique ((scott H).inf_isGLB _ _)
  have hright : right = (scott H).inf y z :=
    hr.unique ((scott H).inf_isGLB _ _)
  rw [hmeet, hleft, hright]
  rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
  · have hjy : joined = y := hj.unique (pair_lub_of_le H _ _ bot_le)
    rw [hjy, bottom_inf]
    exact pair_lub_of_le H _ _ bot_le
  · rcases cases_sum H y with rfl | ⟨j, b, rfl⟩
    · have hjx : joined = component H i a := by
        apply hj.unique
        simpa only [Set.pair_comm] using pair_lub_of_le H (bottom H) (component H i a) bot_le
      rw [hjx, bottom_inf]
      simpa only [Set.pair_comm] using pair_lub_of_le H (bottom H)
        ((scott H).inf (component H i a) z) bot_le
    · have hij : i = j := compatible_indices H hxy
      subst j
      obtain ⟨c, rfl, _⟩ := component_le_elim H (hj.1
        (by simp : component H i a ∈
          ({component H i a,component H i b} : Set (Carrier H))))
      rcases cases_sum H z with rfl | ⟨j, d, rfl⟩
      · rw [inf_bottom, inf_bottom, inf_bottom]
        exact pair_lub_of_le H _ _ le_rfl
      · by_cases hij : i = j
        · subst j
          rw [inf_component, inf_component, inf_component]
          have hd := (Core (H i)).isDIDomain.distributive a b d c
            (c ⊓ d) (a ⊓ d) (b ⊓ d) ((component_compatible_iff H i a b).mp hxy)
            (component_pair_lub H i a b c hj)
            (DIDomainObject.inf_isGLB _ _ _) (DIDomainObject.inf_isGLB _ _ _)
            (DIDomainObject.inf_isGLB _ _ _)
          have hL := component_isLUB H i (s := c ⊓ d)
            (show ({a ⊓ d,b ⊓ d} : Set (Core (H i))).Nonempty from ⟨a ⊓ d, by simp⟩) hd
          simpa only [Set.image_pair] using hL
        · rw [inf_distinct H i j c d hij, inf_distinct H i j a d hij,
            inf_distinct H i j b d hij]
          exact pair_lub_of_le H _ _ le_rfl

theorem Iic_component (i : I) (a : Core (H i)) :
    Set.Iic (component H i a) =
      insert (bottom H) (component H i '' Set.Iic a) := by
  ext x
  constructor
  · intro hx
    rcases below_component H hx with rfl | ⟨b, rfl, hba⟩
    · exact Set.mem_insert _ _
    · exact Set.mem_insert_of_mem _ ⟨b, hba, rfl⟩
  · rintro (rfl | ⟨b, hb, rfl⟩)
    · change (bottom H) ≤ component H i a
      exact bot_le
    · exact component_mono H i hb

theorem finite_compact_ideals (x : Carrier H) (hx : IsCompactElement x) :
    (Set.Iic x).Finite := by
  rcases (compact_sum_iff H x).mp hx with rfl | ⟨i, a, ha, rfl⟩
  · have heq : Set.Iic (bottom H) = {bottom H} := by
      ext z
      exact ⟨fun h => le_antisymm h bot_le, fun h => h.le⟩
    rw [heq]
    exact Set.finite_singleton _
  · rw [Iic_component]
    exact ((Core (H i)).isDIDomain.finitePrincipalIdeals a ha).image
      (component H i) |>.insert (bottom H)

def sum_isDIDomain : IsDIDomain (Carrier H) where
  toIsScottDomain := scott H
  distributive := sum_distributive H
  finitePrincipalIdeals := finite_compact_ideals H

theorem sum_compacts_countable [Countable I] :
    (CompactElements (Carrier H)).Countable := by
  have hU : (⋃ i : I, component H i '' CompactElements (Core (H i))).Countable :=
    Set.countable_iUnion (fun i => (H i).countableCompacts.image (component H i))
  apply (hU.insert (bottom H)).mono
  intro x hx
  rcases (compact_sum_iff H x).mp hx with rfl | ⟨i, a, ha, rfl⟩
  · exact Set.mem_insert _ _
  · exact Set.mem_insert_of_mem _ (Set.mem_iUnion.mpr ⟨i, ⟨a, ha, rfl⟩⟩)

def sum_countablyBased [Countable I] : IsCountablyBasedDIDomain (Carrier H) :=
  ⟨sum_isDIDomain H, sum_compacts_countable H⟩

theorem small_bounded_of_pairwise {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (F : Set D) (hF : F.Finite) (hcard : F.ncard ≤ 2)
    (hp : ∀ x ∈ F, ∀ y ∈ F, Compatible x y) : BddAbove F := by
  have hc : F.ncard = 0 ∨ F.ncard = 1 ∨ F.ncard = 2 := by omega
  rcases hc with h0 | h1 | h2
  · have heq : F = ∅ := (Set.ncard_eq_zero hF).mp h0
    rw [heq]
    exact ⟨hD.bottom, by simp⟩
  · obtain ⟨a, rfl⟩ := Set.ncard_eq_one.mp h1
    exact ⟨a, by simp⟩
  · obtain ⟨a, b, _hne, rfl⟩ := Set.ncard_eq_two.mp h2
    obtain ⟨z, haz, hbz⟩ := hp a (by simp) b (by simp)
    refine ⟨z, ?_⟩
    intro x hx
    rcases hx with rfl | rfl
    · exact haz
    · exact hbz

theorem sum_two_coherent
    (hH : ∀ i, CoherenceDegree.IsNCoherent
      (Core (H i)).isDIDomain.toIsScottDomain 2 (by decide)) :
    CoherenceDegree.IsNCoherent (scott H) 2 (by decide) := by
  apply (CoherenceDegree.coherenceCharacterization (Carrier H) (scott H) 2 (by decide)).mpr
  intro X hX
  have hPair : ∀ x ∈ X, ∀ y ∈ X, Compatible x y := by
    intro x hx y hy
    have hsub : ({x,y} : Set (Carrier H)) ⊆ X := by
      intro z hz
      rcases hz with rfl | rfl
      · exact hx
      · exact hy
    have hcard : ({x,y} : Set (Carrier H)).ncard ≤ 2 := by
      by_cases hxy : x = y
      · subst y
        simp
      · exact (Set.ncard_pair hxy).le
    obtain ⟨z, hz⟩ := hX {x,y} hsub (Set.toFinite _) hcard
    exact ⟨z, hz (by simp), hz (by simp)⟩
  by_cases hpos : ∃ (i : I) (a : Core (H i)), component H i a ∈ X
  · obtain ⟨i, a, ha⟩ := hpos
    have hF : InFiber H i X := by
      intro x hx
      rcases cases_sum H x with hb | ⟨j, b, rfl⟩
      · exact Or.inl hb
      · have hij : i = j := compatible_indices H (hPair _ ha _ hx)
        subst j
        exact Or.inr ⟨b, rfl⟩
    have hPairF : ∀ x ∈ fiberValues H i X, ∀ y ∈ fiberValues H i X, Compatible x y := by
      intro x hx y hy
      exact (component_compatible_iff H i x y).mp (hPair _ hx _ hy)
    have hB : BddAbove (fiberValues H i X) := by
      apply (CoherenceDegree.coherenceCharacterization (Core (H i))
        (Core (H i)).isDIDomain.toIsScottDomain 2 (by decide)).mp (hH i)
      intro F hFX hF hcard
      exact small_bounded_of_pairwise (Core (H i)).isDIDomain.toIsScottDomain F
        hF hcard (fun x hx y hy => hPairF x (hFX hx) y (hFX hy))
    obtain ⟨b, hb⟩ := hB
    refine ⟨component H i b, ?_⟩
    intro x hx
    rcases hF x hx with rfl | ⟨c, rfl⟩
    · exact bot_le
    · exact component_mono H i (hb hx)
  · refine ⟨bottom H, ?_⟩
    intro x hx
    rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
    · exact le_rfl
    · exact False.elim (hpos ⟨i, a, hx⟩)

end DIDomainClassification.SeparatedSumDomain
