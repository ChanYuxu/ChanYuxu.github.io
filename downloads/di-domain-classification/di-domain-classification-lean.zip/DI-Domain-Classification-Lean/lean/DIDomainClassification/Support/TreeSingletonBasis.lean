import DIDomainClassification.Support.SingletonForbiddenDomains
import DIDomainClassification.Section02.TreeDomainConstruction

/-! Actual singleton basis and complete-branch MIC correspondence for the
literal branch-forbidden TreeDomain. Its points are arbitrary node subsets,
NOT lower sets. No tree degree or branch-rank comparison is assumed.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TreeDomainDegree

open Preliminaries CoherenceDegree Trees
open Section02.TreeDomainConstruction
open PointwiseFunctionSupport (IsFiniteJoinBasis)

variable {Index : Type u} (T : RootedPrefixTree Index)

def treeScottDomain (hp : T.IsProper) : IsScottDomain (TreeDomain T) :=
  (countablyBasedDIDomain T hp).1.toIsScottDomain

def nodePoint (hp : T.IsProper) (x : T.Node) : TreeDomain T :=
  SingletonForbiddenDomains.singletonPoint (forbiddenBranches T) (admissible T hp) x

theorem nodePoint_val (hp : T.IsProper) (x : T.Node) : (nodePoint T hp x).val = {x} := rfl

theorem nodePoint_injective (hp : T.IsProper) : Function.Injective (nodePoint T hp) :=
  SingletonForbiddenDomains.singletonPoint_injective (forbiddenBranches T) (admissible T hp)

theorem nodePoint_compact (hp : T.IsProper) (x : T.Node) : IsCompactElement (nodePoint T hp x) :=
  (compact_iff_finite T hp _).2 (Set.finite_singleton x)

def singletonNodes (hp : T.IsProper) : Set (TreeDomain T) := Set.range (nodePoint T hp)

theorem singletonNodes_isFiniteJoinBasis (hp : T.IsProper) :
    IsFiniteJoinBasis (singletonNodes T hp) :=
  SingletonForbiddenDomains.singleton_isFiniteJoinBasis (forbiddenBranches T) (admissible T hp)

/-- The actual finite complete branches form an inclusion antichain. -/
theorem forbiddenBranches_antichain :
    SingletonForbiddenDomains.ForbiddenAntichain (forbiddenBranches T) := by
  letI : PartialOrder T.Node := prefixNodeOrder T
  intro U hU V hV hUV
  rcases hU with ⟨x, hx, rfl⟩
  rcases hV with ⟨y, _hy, rfl⟩
  have hxy : x ≤ y := hUV (List.prefix_refl _)
  have hyx : y = x := hx y hxy
  rw [hyx]

/-- MIC singleton families are EXACTLY actual finite complete branches.
Arbitrary node subsets X are quantified; lower closure is not an input.
-/
theorem singleton_family_mic_iff (hp : T.IsProper) (X : Set T.Node) :
    IsMinimallyInconsistent (treeScottDomain T hp) (nodePoint T hp '' X) ↔
      T.IsFiniteCompleteBranch X :=
  SingletonForbiddenDomains.singleton_image_mic_iff (forbiddenBranches T) (admissible T hp)
    (forbiddenBranches_antichain T) X

def nodeLabel (hp : T.IsProper) : T.Node → ↥(CompactElements (TreeDomain T)) :=
  fun x => ⟨nodePoint T hp x, nodePoint_compact T hp x⟩

theorem nodeLabel_injective (hp : T.IsProper) : Function.Injective (nodeLabel T hp) := by
  intro x y hxy
  exact nodePoint_injective T hp (congrArg Subtype.val hxy)

/-- The literal identity singleton labelling is an actual MIC tree, even
without WF: injectivity is proved and every finite complete branch is MIC.
-/
def identitySingletonMicTree (hp : T.IsProper) :
    MicTree (TreeDomain T) (treeScottDomain T hp) Index where
  tree := T
  proper := hp
  label := nodeLabel T hp
  isMicTree := by
    apply (isMicTree_iff (treeScottDomain T hp) T hp _).2
    constructor
    · intro c _hc x _hx y _hy hxy
      exact nodeLabel_injective T hp hxy
    · intro c hc
      exact (singleton_family_mic_iff T hp c).2 hc

theorem wellFounded_degree_lower (hp : T.IsProper) (hT : T.IsWellFounded) :
    Ordinal.lift.{u+1} (T.treeRank hT + 1) ≤ coherenceDegree (treeScottDomain T hp) :=
  treeRank_add_one_le_coherenceDegree (treeScottDomain T hp) (identitySingletonMicTree T hp) hT

end DIDomainClassification.TreeDomainDegree
