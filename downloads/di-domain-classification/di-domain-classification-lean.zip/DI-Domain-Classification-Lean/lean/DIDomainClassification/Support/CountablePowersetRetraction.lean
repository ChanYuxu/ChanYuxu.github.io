import DIDomainClassification.Support.ForestProductMaps
import DIDomainClassification.Section02.Retractions
import Mathlib.Order.ULift

/-! Generic powerset retraction along an explicit injection into the naturals.
The carriers and orders are literally Set A and ULift (Set Nat). Countably
based dI certificates, native StableHoms and the split identity are proved
outputs. No comparison, coherence-degree or classification result is stated.

The powerset certificate, LUB membership characterization and literal lift
order isomorphism are reused from ForestProductMaps in the same pinned task.
-/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.CountablePowersetRetraction

open Preliminaries
open Section03.StableFunctionModels Section04.AdditionalSourceModels

def sourceCertificate (A : Type u) (e : A → ℕ) (he : Function.Injective e) :
    IsCountablyBasedDIDomain (Set A) := by
  letI : Countable A := he.countable
  exact ForestProductMaps.powerset_countablyBased A

def targetCertificate : IsCountablyBasedDIDomain NatPowersetCarrier.{u} :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff
    (ForestProductMaps.liftOrderIso (Set ℕ))).mpr
      (ForestProductMaps.powerset_countablyBased ℕ)

def sourceObject (A : Type u) (e : A → ℕ) (he : Function.Injective e) :
    CountablyBasedDIDomain.{u} := cbObject (Set A) (sourceCertificate A e he)

def targetObject : CountablyBasedDIDomain.{u} :=
  natPowersetObject targetCertificate

def imageValue {A : Type u} (e : A → ℕ) (X : Set A) : NatPowersetCarrier.{u} :=
  ⟨e '' X⟩

def preimageValue {A : Type u} (e : A → ℕ) (Y : NatPowersetCarrier.{u}) : Set A :=
  e ⁻¹' Y.down

theorem image_scottContinuous {A : Type u} (e : A → ℕ) :
    ScottContinuous (fun X : Set A => e '' X) := by
  intro C _hne _hdir X hX
  constructor
  · rintro _ ⟨Y, hY, rfl⟩ n ⟨a, ha, rfl⟩
    exact ⟨a, hX.1 hY ha, rfl⟩
  · intro Z hZ n hn
    obtain ⟨a, ha, rfl⟩ := hn
    rw [ForestProductMaps.set_isLUB_values C X hX] at ha
    obtain ⟨Y, hY, haY⟩ := ha
    exact hZ ⟨Y, hY, rfl⟩ ⟨a, haY, rfl⟩

theorem preimage_scottContinuous {A : Type u} (e : A → ℕ) :
    ScottContinuous (fun Y : Set ℕ => e ⁻¹' Y) := by
  intro C _hne _hdir Y hY
  constructor
  · rintro _ ⟨X, hX, rfl⟩ a ha
    exact hY.1 hX ha
  · intro Z hZ a ha
    change e a ∈ Y at ha
    rw [ForestProductMaps.set_isLUB_values C Y hY] at ha
    obtain ⟨X, hX, haX⟩ := ha
    exact hZ ⟨X, hX, rfl⟩ haX

theorem imageValue_scottContinuous {A : Type u} (e : A → ℕ) :
    ScottContinuous (imageValue e) :=
  (image_scottContinuous e).comp
    (OrderIsoTransport.scottContinuous
      (ForestProductMaps.liftOrderIso.{u, 0} (Set ℕ)).symm)

theorem preimageValue_scottContinuous {A : Type u} (e : A → ℕ) :
    ScottContinuous (preimageValue e) :=
  (OrderIsoTransport.scottContinuous
    (ForestProductMaps.liftOrderIso.{u, 0} (Set ℕ))).comp
      (preimage_scottContinuous e)

theorem powerset_inf (A : Type u) (hA : IsDIDomain (Set A)) (X Y : Set A) :
    hA.toIsScottDomain.inf X Y = X ∩ Y := by
  apply (hA.toIsScottDomain.inf_isGLB X Y).unique
  constructor
  · intro Z hZ
    rcases Set.mem_insert_iff.mp hZ with rfl | hZ
    · exact Set.inter_subset_left
    · rw [Set.mem_singleton_iff.mp hZ]
      exact Set.inter_subset_right
  · intro Z hZ
    exact Set.subset_inter (hZ (by simp)) (hZ (by simp))

theorem target_inf (X Y : Core targetObject.{u}) :
    X ⊓ Y = (⟨X.down ∩ Y.down⟩ : NatPowersetCarrier.{u}) := by
  apply (DIDomainObject.inf_isGLB (Core targetObject) X Y).unique
  constructor
  · intro Z hZ
    rcases Set.mem_insert_iff.mp hZ with rfl | hZ
    · exact Set.inter_subset_left
    · rw [Set.mem_singleton_iff.mp hZ]
      exact Set.inter_subset_right
  · intro Z hZ
    exact Set.subset_inter (hZ (by simp)) (hZ (by simp))

theorem source_inf (A : Type u) (e : A → ℕ) (he : Function.Injective e)
    (X Y : Core (sourceObject A e he)) : X ⊓ Y = Set.inter (X : Set A) (Y : Set A) := by
  calc
    X ⊓ Y = (sourceCertificate A e he).1.toIsScottDomain.inf X Y :=
      (DIDomainObject.inf_isGLB (Core (sourceObject A e he)) X Y).unique
        ((sourceCertificate A e he).1.toIsScottDomain.inf_isGLB X Y)
    _ = Set.inter (X : Set A) (Y : Set A) := powerset_inf A (sourceCertificate A e he).1 X Y

def sectionMap (A : Type u) (e : A → ℕ) (he : Function.Injective e) :
    StableHom (Core (sourceObject A e he)) (Core targetObject.{u}) := by
  refine StableHom.ofFunction (imageValue e) ⟨imageValue_scottContinuous e, ?_⟩
  intro X Y _hcompat
  rw [source_inf, target_inf]
  apply ULift.ext
  change e '' Set.inter (X : Set A) (Y : Set A) = (e '' X) ∩ (e '' Y)
  ext n
  constructor
  · rintro ⟨a, ⟨haX, haY⟩, rfl⟩
    exact ⟨⟨a, haX, rfl⟩, ⟨a, haY, rfl⟩⟩
  · rintro ⟨⟨a, haX, han⟩, ⟨b, hbY, hbn⟩⟩
    have hab : a = b := he (han.trans hbn.symm)
    subst b
    exact ⟨a, ⟨haX, hbY⟩, han⟩

def retractionMap (A : Type u) (e : A → ℕ) (he : Function.Injective e) :
    StableHom (Core targetObject.{u}) (Core (sourceObject A e he)) := by
  refine StableHom.ofFunction (preimageValue e) ⟨preimageValue_scottContinuous e, ?_⟩
  intro X Y _hcompat
  rw [target_inf, source_inf]
  rfl

theorem section_apply (A : Type u) (e : A → ℕ) (he : Function.Injective e)
    (X : Set A) : sectionMap A e he X = (⟨e '' X⟩ : NatPowersetCarrier.{u}) := rfl

theorem retraction_apply (A : Type u) (e : A → ℕ) (he : Function.Injective e)
    (Y : NatPowersetCarrier.{u}) : retractionMap A e he Y = e ⁻¹' Y.down := rfl

theorem leftInverse (A : Type u) (e : A → ℕ) (he : Function.Injective e) :
    Function.LeftInverse (retractionMap A e he) (sectionMap A e he) := by
  intro X
  change e ⁻¹' (e '' X) = X
  ext a
  constructor
  · rintro ⟨b, hb, hba⟩
    exact he hba ▸ hb
  · intro ha
    exact ⟨a, ha, rfl⟩

theorem stableRetract (A : Type u) (e : A → ℕ) (he : Function.Injective e) :
    HasStableRetraction (Core (sourceObject A e he)) (Core targetObject.{u}) :=
  ⟨sectionMap A e he, retractionMap A e he, leftInverse A e he⟩

end DIDomainClassification.CountablePowersetRetraction
