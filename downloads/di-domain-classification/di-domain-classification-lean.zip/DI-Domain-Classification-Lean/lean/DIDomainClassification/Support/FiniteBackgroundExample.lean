import DIDomainClassification.Section04.BackgroundExampleStatement
import DIDomainClassification.Support.FiniteCausalConflictRetractions
import Mathlib.Tactic.FinCases

/-! The literal four-event counterexample and its corrected fixed-background
splitting. The event order and all three printed set formulas are unchanged. -/

set_option autoImplicit false
noncomputable section

namespace DIDomainClassification.FiniteBackgroundExample

open Preliminaries EventStructures Section04
open Section04.FiniteCategoryModels Section04.BackgroundExampleModels

def eventStructure : FinitaryPrimeEventStructure Event where
  Con := consistency
  finite_principalIdeal _ := Set.toFinite _
  finite_of_mem_Con h := h.1
  empty_mem_Con := ⟨Set.finite_empty, by
    intro h
    exact h (show Event.a ∈ forbiddenTriple by simp [forbiddenTriple])⟩
  singleton_mem_Con x := ⟨Set.finite_singleton x, by
    intro h
    have ha : Event.a = x := Set.mem_singleton_iff.mp (h (by simp [forbiddenTriple]))
    have hb : Event.b = x := Set.mem_singleton_iff.mp (h (by simp [forbiddenTriple]))
    exact (by decide : Event.a ≠ Event.b) (ha.trans hb.symm)⟩
  hereditary hFG hG := ⟨hG.1.subset hFG, fun h => hG.2 (h.trans hFG)⟩
  causal_closure := by
    intro F x y hF hxy hy
    rcases (event_le_iff x y).mp hxy with rfl | rfl
    · refine ⟨Set.toFinite _, ?_⟩
      intro h
      apply hF.2
      intro x hx
      have hxc : x ≠ Event.c := by
        simp only [forbiddenTriple, Set.mem_insert_iff, Set.mem_singleton_iff] at hx
        rcases hx with rfl | rfl | rfl <;> decide
      rcases h hx with hxF | hxC
      · exact hxF
      · exact False.elim (hxc (Set.mem_singleton_iff.mp hxC))
    · simpa only [Set.union_singleton, Set.insert_eq_of_mem hy] using hF

theorem lower_contains_triple_eq_univ (U : Set Event) (hU : IsLowerSet U)
    (hTriple : forbiddenTriple ⊆ U) : U = Set.univ := by
  have hc : Event.c ∈ U :=
    hU (show Event.c ≤ Event.a from Or.inl rfl) (hTriple (by simp [forbiddenTriple]))
  apply Set.eq_univ_of_forall
  intro x
  cases x with
  | c => exact hc
  | a => exact hTriple (by simp [forbiddenTriple])
  | b => exact hTriple (by simp [forbiddenTriple])
  | d => exact hTriple (by simp [forbiddenTriple])

theorem univ_minimal : IsMinimallyInconsistentFiniteLowerSet eventStructure Set.univ := by
  refine ⟨Set.toFinite _, (by intro _ _ _ _; trivial), ?_, ?_⟩
  · intro h
    exact h.2 (Set.subset_univ _)
  · intro V hV hLower
    refine ⟨Set.toFinite _, ?_⟩
    intro hTriple
    exact hV.2 (lower_contains_triple_eq_univ V hLower hTriple ▸ Set.Subset.rfl)

theorem maximal_univ : maximalEvents (Set.univ : Set Event) = forbiddenTriple := by
  ext x
  have hMax : x ∈ maximalEvents (Set.univ : Set Event) ↔ x ≠ Event.c := by
    constructor
    · intro hx hxc
      subst x
      have ha := hx.2 Event.a (Set.mem_univ _) (Or.inl rfl)
      cases ha
    · intro hxc
      refine ⟨Set.mem_univ _, ?_⟩
      intro y _hy hxy
      rcases (event_le_iff x y).mp hxy with hc | hxy
      · exact False.elim (hxc hc)
      · exact hxy.symm
  rw [hMax]
  cases x <;> simp [forbiddenTriple]

theorem conflictFamily : causalConflictFamily eventStructure = {forbiddenTriple} := by
  ext H
  constructor
  · rintro ⟨U, hU, hH⟩
    have hTriple : forbiddenTriple ⊆ U := by
      by_contra hbad
      exact hU.2.2.1 ⟨hU.1, hbad⟩
    have hUniv := lower_contains_triple_eq_univ U hU.2.1 hTriple
    apply Set.mem_singleton_iff.mpr
    exact hH.trans (hUniv ▸ maximal_univ)
  · intro hH
    exact ⟨Set.univ, univ_minimal, (Set.mem_singleton_iff.mp hH).trans maximal_univ.symm⟩

def leafEquiv : Fin 3 ≃ forbiddenTriple where
  toFun i := ⟨leaf i, by fin_cases i <;> simp [leaf, forbiddenTriple]⟩
  invFun x := match x.val with
    | Event.c => 0
    | Event.a => 0
    | Event.b => 1
    | Event.d => 2
  left_inv i := by fin_cases i <;> rfl
  right_inv x := by
    rcases x with ⟨x, hx⟩
    cases x with
    | c => simp [forbiddenTriple] at hx
    | a => apply Subtype.ext; rfl
    | b => apply Subtype.ext; rfl
    | d => apply Subtype.ext; rfl

theorem background_eq : (Set.univ : Set Event) \ forbiddenTriple = {Event.c} := by
  ext x
  cases x <;> simp [forbiddenTriple]

def cubeCountablyBased : IsCountablyBasedDIDomain Three :=
  FiniteCubeRetractions.cubeCountablyBased 3 (by decide)

def stableSection : StableHom (cubeCore 3 (by decide) cubeCountablyBased.1)
    (configurationCore eventStructure) :=
  FiniteCausalConflictRetractions.stableSection eventStructure Set.univ forbiddenTriple
    univ_minimal maximal_univ.symm leafEquiv (by decide) cubeCountablyBased

def stableRetraction : StableHom (configurationCore eventStructure)
    (cubeCore 3 (by decide) cubeCountablyBased.1) :=
  FiniteCausalConflictRetractions.stableRetraction eventStructure Set.univ forbiddenTriple
    univ_minimal maximal_univ.symm leafEquiv (by decide) cubeCountablyBased

theorem stableSection_values (S : Three) : (stableSection S).val = sectionValues S.down.val := by
  change (Set.univ \ forbiddenTriple) ∪ leaf '' S.down.val = {Event.c} ∪ leaf '' S.down.val
  rw [background_eq]

theorem stableRetraction_values (X : Configuration eventStructure) :
    (stableRetraction X).down.val = retractionValues X.val := rfl

theorem leftInverse : Function.LeftInverse (stableRetraction : Configuration eventStructure → Three)
    (stableSection : Three → Configuration eventStructure) :=
  FiniteCausalConflictRetractions.leftInverse eventStructure Set.univ forbiddenTriple
    univ_minimal maximal_univ.symm leafEquiv (by decide)

theorem closure_subset_section (S : Set (Fin 3)) : closureValues S ⊆ sectionValues S := by
  rintro x ⟨i, hi, hxi⟩
  rcases (event_le_iff x (leaf i)).mp hxi with hx | hx
  · exact Or.inl (Set.mem_singleton_iff.mpr hx)
  · exact Or.inr ⟨i, hi, hx.symm⟩

theorem closure_lower (S : Set (Fin 3)) : IsLowerSet (closureValues S) := by
  intro y x hxy
  rintro ⟨i, hi, hyi⟩
  exact ⟨i, hi, hxy.trans hyi⟩

def closureMap (S : Three) : Configuration eventStructure := by
  refine ⟨closureValues S.down.val, closure_lower _, ?_⟩
  intro F hF hsub
  apply (stableSection S).property.2 F hF
  rw [stableSection_values]
  exact hsub.trans (closure_subset_section _)

theorem closure_intersection :
    closureValues ({0} : Set (Fin 3)) ∩ closureValues ({1} : Set (Fin 3)) = {Event.c} := by
  ext x
  cases x <;> simp [closureValues, leaf, event_le_iff]

theorem closure_empty : closureValues (∅ : Set (Fin 3)) = ∅ := by
  simp [closureValues]

theorem closure_intersection_ne_empty :
    closureValues ({0} : Set (Fin 3)) ∩ closureValues ({1} : Set (Fin 3)) ≠
      closureValues (∅ : Set (Fin 3)) := by
  rw [closure_intersection, closure_empty]
  exact Set.singleton_ne_empty _

def firstPoint : Three := ⟨⟨{0}, by
  intro h
  have hi : (2 : Fin 3) ∈ ({0} : Set (Fin 3)) := by rw [h]; trivial
  exact (by decide : (2 : Fin 3) ≠ 0) (Set.mem_singleton_iff.mp hi)⟩⟩

def secondPoint : Three := ⟨⟨{1}, by
  intro h
  have hi : (2 : Fin 3) ∈ ({1} : Set (Fin 3)) := by rw [h]; trivial
  exact (by decide : (2 : Fin 3) ≠ 1) (Set.mem_singleton_iff.mp hi)⟩⟩

def commonUpperPoint : Three := ⟨⟨{0, 1}, by
  intro h
  have hi : (2 : Fin 3) ∈ ({0, 1} : Set (Fin 3)) := by rw [h]; trivial
  rcases hi with hi | hi
  · exact (by decide : (2 : Fin 3) ≠ 0) hi
  · exact (by decide : (2 : Fin 3) ≠ 1) (Set.mem_singleton_iff.mp hi)⟩⟩

theorem closure_not_stable :
    ¬ IsStable (cubeCore 3 (by decide) cubeCountablyBased.1)
      (configurationCore eventStructure) closureMap := by
  intro h
  have hCompatible : Compatible (D := cubeCore 3 (by decide) cubeCountablyBased.1)
      firstPoint secondPoint := by
    refine ⟨commonUpperPoint, ?_, ?_⟩ <;> intro i hi
    · exact Or.inl hi
    · exact Or.inr hi
  have hmeet := congrArg Subtype.val (h.2 firstPoint secondPoint hCompatible)
  change closureValues (cubeCountablyBased.1.toIsScottDomain.inf firstPoint secondPoint).down.val =
    _ at hmeet
  rw [FiniteCubeRetractions.cube_inf_values 3 (by decide) cubeCountablyBased.1,
    FiniteCausalConflictRetractions.configuration_inf_values] at hmeet
  change closureValues (({0} : Set (Fin 3)) ∩ {1}) =
    closureValues ({0} : Set (Fin 3)) ∩ closureValues ({1} : Set (Fin 3)) at hmeet
  have hInter : ({0} : Set (Fin 3)) ∩ {1} = ∅ := by
    ext i
    simp only [Set.mem_inter_iff, Set.mem_singleton_iff, Set.mem_empty_iff_false]
    constructor
    · rintro ⟨rfl, h01⟩
      exact (by decide : (0 : Fin 3) ≠ 1) h01
    · exact False.elim
  rw [hInter, closure_empty, closure_intersection] at hmeet
  exact (Set.singleton_ne_empty Event.c) hmeet.symm

end DIDomainClassification.FiniteBackgroundExample
