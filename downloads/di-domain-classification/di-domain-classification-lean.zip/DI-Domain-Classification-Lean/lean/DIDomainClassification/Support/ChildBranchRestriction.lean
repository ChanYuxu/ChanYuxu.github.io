import DIDomainClassification.Support.RootChildGeometry

/-! Exact branch SET equality after restricting a root-normalized map to
one source root-child subtree. The new map need not preserve the child root;
that condition is deliberately NOT assumed or concluded. -/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.BranchRankComparison

open Trees

variable {A : Type u} {B : Type v}

theorem childMap_maps_branches (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f)
    (hroot : f S.root = T.root) (c : S.Node) (hc : S.IsChild S.root c) :
    MapsFiniteCompleteBranches (TreeGrafting.above S c)
      (TreeGrafting.above T (firstChild T (f c))) (childMap S hS T f hf hinj hroot c hc) := by
  rintro b ⟨leaf, hleaf, rfl⟩
  have hSourceLeaf := (TreeGrafting.aboveNodeMap_isLeaf_iff S c leaf).mp hleaf
  obtain ⟨target, hTarget, hImage⟩ := (mapsFiniteCompleteBranches_iff_leaves S T f).mp hf
    (TreeGrafting.aboveNodeMap S c leaf) hSourceLeaf
  let d := firstChild T (f c)
  have hd : T.IsChild T.root d :=
    firstChild_isChild T (f c) (map_ne_root S hS T f hinj hroot c (child_ne_root S hc))
  have hcTarget : (f c).val <+: target.val := by
    have hmem : f c ∈ T.pathTo target := by
      rw [← hImage]
      exact ⟨c, leaf.property.2, rfl⟩
    exact hmem
  have hdTarget : d.val <+: target.val := (firstChild_le T (f c)).trans hcTarget
  let target' : (TreeGrafting.above T d).Node := ⟨target.val, target.property, hdTarget⟩
  refine ⟨target', (TreeGrafting.aboveNodeMap_isLeaf_iff T d target').mpr hTarget, ?_⟩
  ext z
  constructor
  · rintro ⟨x, hx, rfl⟩
    have hxSource : TreeGrafting.aboveNodeMap S c x ∈
        S.pathTo (TreeGrafting.aboveNodeMap S c leaf) := by
      rw [TreeGrafting.above_root_child_path_split S hc leaf]
      exact Or.inr ⟨x, hx, rfl⟩
    have hxTarget : f (TreeGrafting.aboveNodeMap S c x) ∈ T.pathTo target := by
      rw [← hImage]
      exact ⟨TreeGrafting.aboveNodeMap S c x, hxSource, rfl⟩
    exact hxTarget
  · intro hz
    have hzTarget : TreeGrafting.aboveNodeMap T d z ∈ T.pathTo target := hz
    rw [← hImage] at hzTarget
    obtain ⟨s, hs, hfs⟩ := hzTarget
    have hsSplit : s ∈ {S.root} ∪ TreeGrafting.aboveNodeMap S c ''
        (TreeGrafting.above S c).pathTo leaf := by
      rw [← TreeGrafting.above_root_child_path_split S hc leaf]
      exact hs
    rcases hsSplit with hsRoot | ⟨x, hx, hxs⟩
    · have hsRoot' : s = S.root := Set.mem_singleton_iff.mp hsRoot
      have hzRoot : TreeGrafting.aboveNodeMap T d z = T.root :=
        hfs.symm.trans ((congrArg f hsRoot').trans hroot)
      exact (above_rootChild_ne_root T hd z hzRoot).elim
    · refine ⟨x, hx, ?_⟩
      have hfx : f (TreeGrafting.aboveNodeMap S c x) = TreeGrafting.aboveNodeMap T d z :=
        (congrArg f hxs).trans hfs
      exact Subtype.ext (congrArg (fun y : T.Node => y.val) hfx)

theorem childMap_injective_branches (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f)
    (hroot : f S.root = T.root) (c : S.Node) (hc : S.IsChild S.root c) :
    InjectiveOnBranches (TreeGrafting.above S c)
      (TreeGrafting.above T (firstChild T (f c))) (childMap S hS T f hf hinj hroot c hc) := by
  rintro b ⟨leaf, hleaf, rfl⟩ x hx y hy hxy
  have hSourceLeaf := (TreeGrafting.aboveNodeMap_isLeaf_iff S c leaf).mp hleaf
  have hSourceInj := injectiveOnBranches_path S T f hinj
    (TreeGrafting.aboveNodeMap S c leaf) hSourceLeaf
  have hxSource : TreeGrafting.aboveNodeMap S c x ∈
      S.pathTo (TreeGrafting.aboveNodeMap S c leaf) := by
    rw [TreeGrafting.above_root_child_path_split S hc leaf]
    exact Or.inr ⟨x, hx, rfl⟩
  have hySource : TreeGrafting.aboveNodeMap S c y ∈
      S.pathTo (TreeGrafting.aboveNodeMap S c leaf) := by
    rw [TreeGrafting.above_root_child_path_split S hc leaf]
    exact Or.inr ⟨y, hy, rfl⟩
  apply TreeGrafting.aboveNodeMap_injective S c
  apply hSourceInj hxSource hySource
  exact congrArg (TreeGrafting.aboveNodeMap T (firstChild T (f c))) hxy

/-- Literal construction contract used by source-rank induction. -/
theorem child_restriction (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f)
    (hroot : f S.root = T.root) (c : S.Node) (hc : S.IsChild S.root c) :
    ∃ (d : T.Node) (_hd : T.IsChild T.root d)
      (g : (TreeGrafting.above S c).Node → (TreeGrafting.above T d).Node),
      (∀ x, TreeGrafting.aboveNodeMap T d (g x) = f (TreeGrafting.aboveNodeMap S c x)) ∧
      MapsFiniteCompleteBranches (TreeGrafting.above S c) (TreeGrafting.above T d) g ∧
      InjectiveOnBranches (TreeGrafting.above S c) (TreeGrafting.above T d) g :=
  ⟨firstChild T (f c), firstChild_isChild T (f c)
      (map_ne_root S hS T f hinj hroot c (child_ne_root S hc)),
    childMap S hS T f hf hinj hroot c hc, childMap_formula S hS T f hf hinj hroot c hc,
    childMap_maps_branches S hS T f hf hinj hroot c hc,
    childMap_injective_branches S hS T f hf hinj hroot c hc⟩

end DIDomainClassification.BranchRankComparison

