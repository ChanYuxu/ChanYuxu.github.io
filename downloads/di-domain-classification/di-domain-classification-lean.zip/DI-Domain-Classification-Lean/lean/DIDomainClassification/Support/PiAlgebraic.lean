import DIDomainClassification.Support.PiCompact

/-!
# Full compact-below algebraicity of dependent pointed products

The compact approximation set is exactly OrderCore.CompactBelow, not an
assumed or substituted basis. Countability and nonemptiness of the index
are not needed. Finite-support compactness was proved independently first.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.PiTheory

open OrderCore

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]
  [∀ i, OrderBot (D i)]

theorem pi_compactBelow_directed (hD : ∀ i, IsAlgebraicDcpo (D i)) (x : ∀ i, D i) :
    DirectedSet (CompactBelow x) := by
  classical
  constructor
  · exact ⟨⊥, compact_bot, bot_le⟩
  · intro f hf g hg
    have hcoord : ∀ i : I, ∃ k : D i,
        Compact k ∧ k ≤ x i ∧ f i ≤ k ∧ g i ≤ k := by
      intro i
      obtain ⟨k, hk, hfk, hgk⟩ := (hD i).2 (x i) |>.1.2
        ⟨compact_coordinate hf.1 i, hf.2 i⟩
        ⟨compact_coordinate hg.1 i, hg.2 i⟩
      exact ⟨k, hk.1, hk.2, hfk, hgk⟩
    choose k hkComp hkx hfk hgk using hcoord
    let S : Set I := support f ∪ support g
    have hS : S.Finite := (compact_finite_support hf.1).union (compact_finite_support hg.1)
    let F : Finset I := hS.toFinset
    let z : ∀ i, D i := truncate F k
    have hzComp : Compact z := by
      apply compact_of_finite_support (support_truncate_finite F k)
      intro i
      by_cases hi : i ∈ F
      · simpa only [z, truncate_apply_mem F k hi] using hkComp i
      · simpa only [z, truncate_apply_not_mem F k hi] using
          (compact_bot : Compact (⊥ : D i))
    have hzle : z ≤ x := by
      intro i
      by_cases hi : i ∈ F
      · simpa only [z, truncate_apply_mem F k hi] using hkx i
      · simp only [z, truncate_apply_not_mem F k hi, bot_le]
    refine ⟨z, ⟨hzComp, hzle⟩, ?_, ?_⟩
    · intro i
      by_cases hi : i ∈ F
      · simpa only [z, truncate_apply_mem F k hi] using hfk i
      · have hiS : i ∉ S := by simpa only [F, Set.Finite.mem_toFinset] using hi
        have hfi : f i = ⊥ := (not_mem_support f i).mp (fun h => hiS (Or.inl h))
        simp only [hfi, bot_le]
    · intro i
      by_cases hi : i ∈ F
      · simpa only [z, truncate_apply_mem F k hi] using hgk i
      · have hiS : i ∉ S := by simpa only [F, Set.Finite.mem_toFinset] using hi
        have hgi : g i = ⊥ := (not_mem_support g i).mp (fun h => hiS (Or.inr h))
        simp only [hgi, bot_le]

theorem pi_compactBelow_isSup (hD : ∀ i, IsAlgebraicDcpo (D i)) (x : ∀ i, D i) :
    IsSup (CompactBelow x) x := by
  constructor
  · intro k hk
    exact hk.2
  · intro y hy i
    apply (hD i).2 (x i) |>.2.2 (y i)
    intro k hk
    have hsingle : single i k ∈ CompactBelow x :=
      ⟨compact_single i hk.1, single_le i hk.2⟩
    simpa only [single_self] using hy hsingle i

theorem pi_isAlgebraicDcpo (hD : ∀ i, IsAlgebraicDcpo (D i)) :
    IsAlgebraicDcpo (∀ i, D i) :=
  ⟨pi_isDcpo (fun i => (hD i).1),
    fun x => ⟨pi_compactBelow_directed hD x, pi_compactBelow_isSup hD x⟩⟩

end DIDomainClassification.PiTheory
