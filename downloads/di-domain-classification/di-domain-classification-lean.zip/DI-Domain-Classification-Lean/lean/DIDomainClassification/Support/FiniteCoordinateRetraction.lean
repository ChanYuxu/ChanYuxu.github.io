import DIDomainClassification.Support.StarCliqueObstruction
import DIDomainClassification.Support.ZhaoKouUniversality
import DIDomainClassification.Support.CompactRetractLift
import Mathlib.Data.Fintype.EquivFin

/-!
A direct finite-coordinate obstruction, not an assumed FCI classification.
A compact lift of the star point p has finite support. Each incompatible q_n
must use a coordinate of that support. Two q_n cannot use the same coordinate:
in the literal flat T2 their values there agree, so meet preservation forces
that conflicting value below the image of the empty configuration and hence
below the image of p. This injects N into a finite support, a contradiction.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FiniteCoordinateRetraction

open OrderCore Preliminaries CoherenceDegree TwoExponentialOrderIso
open Section03.StableFunctionModels Section04.AdditionalSourceModels ZhaoKouCodes StarCliqueObstruction

local instance cubeOrderBot : OrderBot Cube.{u} where
  bot := emptyCube
  bot_le := ZhaoKouCodes.empty_le

theorem cube_eq_of_incompatible_left (c x y : Cube.{u})
    (hcx : ¬ Compatible c x) (hcy : ¬ Compatible c y) : x = y := by
  rcases cube_cases c with rfl | rfl | rfl <;>
    rcases cube_cases x with rfl | rfl | rfl <;>
    rcases cube_cases y with rfl | rfl | rfl <;>
    first
    | rfl
    | exact False.elim (hcx ⟨_, le_rfl, le_rfl⟩)
    | exact False.elim (hcy ⟨_, le_rfl, le_rfl⟩)
    | exact False.elim (hcx ⟨_, ZhaoKouCodes.empty_le _, le_rfl⟩)
    | exact False.elim (hcx ⟨_, le_rfl, ZhaoKouCodes.empty_le _⟩)
    | exact False.elim (hcy ⟨_, ZhaoKouCodes.empty_le _, le_rfl⟩)
    | exact False.elim (hcy ⟨_, le_rfl, ZhaoKouCodes.empty_le _⟩)

theorem compatible_iff_coordinate (x y : UniversalBaseCarrier.{u}) :
    Compatible x y ↔ ∀ i : ℕ, Compatible (x i) (y i) := by
  constructor
  · rintro ⟨upper, hx, hy⟩ i
    exact ⟨upper i, hx i, hy i⟩
  · intro h
    choose upper hx hy using h
    exact ⟨upper, hx, hy⟩

theorem native_inf_at_of_eq (x y : Core baseObject.{u}) (i : ℕ) (hxy : x i = y i) :
    (x ⊓ y : Core baseObject.{u}) i = x i := by
  classical
  let z : Core baseObject.{u} := fun j => if j = i then x i else emptyCube
  have hzx : z ≤ x := by
    intro j
    by_cases hji : j = i
    · subst j
      simp only [z, if_pos rfl]
      exact le_rfl
    · change (if j = i then x i else emptyCube) ≤ x j
      rw [if_neg hji]
      exact ZhaoKouCodes.empty_le _
  have hzy : z ≤ y := by
    intro j
    by_cases hji : j = i
    · subst j
      simpa only [z, if_pos rfl] using hxy.le
    · change (if j = i then x i else emptyCube) ≤ y j
      rw [if_neg hji]
      exact ZhaoKouCodes.empty_le _
  have hzi : x i ≤ (x ⊓ y : Core baseObject.{u}) i := by
    have h := (le_inf hzx hzy : z ≤ (x ⊓ y : Core baseObject.{u})) i
    simpa only [z, if_pos rfl] using h
  exact le_antisymm ((inf_le_left : (x ⊓ y : Core baseObject.{u}) ≤ x) i) hzi

theorem star_not_retract_base : ¬ HasStableRetraction starCore.{u} (Core baseObject.{u}) := by
  classical
  rintro ⟨s, r, hleft⟩
  have hsMon := (StableHom.isStable s).1.monotone
  have hrMon := (StableHom.isStable r).1.monotone
  obtain ⟨c, hc, hcp, hrc⟩ := CompactRetractLift.exists_compact_lift
    (Core baseObject.{u}).isDIDomain.toIsScottDomain.algebraic
    (StableHom.isStable r).1 hleft p_compact
  let F : Set ℕ := {i | c i ≠ emptyCube}
  have hF : F.Finite := PiTheory.compact_finite_support hc
  have hWitness : ∀ n : ℕ, ∃ i ∈ F, ¬ Compatible (c i) (s (qPoint n) i) := by
    intro n
    have hNot : ¬ Compatible c (s (qPoint n)) := by
      rintro ⟨upper, hcUpper, hqUpper⟩
      apply p_incompatible_q n
      have hp := hrMon hcUpper
      have hq := hrMon hqUpper
      rw [hrc] at hp
      rw [hleft (qPoint n)] at hq
      exact ⟨r upper, hp, hq⟩
    have hCoordinate : ∃ i : ℕ, ¬ Compatible (c i) (s (qPoint n) i) := by
      by_contra hNo
      apply hNot
      apply (compatible_iff_coordinate c (s (qPoint n))).mpr
      intro i
      by_contra hBad
      exact hNo ⟨i, hBad⟩
    obtain ⟨i, hi⟩ := hCoordinate
    refine ⟨i, ?_, hi⟩
    change c i ≠ emptyCube
    intro hEmpty
    apply hi
    refine ⟨s (qPoint n) i, ?_, le_rfl⟩
    rw [hEmpty]
    exact ZhaoKouCodes.empty_le _
  choose locate hLocate hIncompatible using hWitness
  let select : ℕ → F := fun n => ⟨locate n, hLocate n⟩
  have hInjective : Function.Injective select := by
    intro n m hSelect
    by_contra hnm
    have hCoordinate : locate n = locate m := congrArg Subtype.val hSelect
    have hEqual : s (qPoint n) (locate n) = s (qPoint m) (locate n) :=
      cube_eq_of_incompatible_left _ _ _ (hIncompatible n)
        (by simpa only [hCoordinate] using hIncompatible m)
    have hStable := (StableHom.isStable s).2 (qPoint n) (qPoint m) (q_compatible n m)
    rw [q_inf n m hnm] at hStable
    have hEmptyValue : s emptyPoint (locate n) = s (qPoint n) (locate n) := by
      calc
        s emptyPoint (locate n) = (s (qPoint n) ⊓ s (qPoint m) : Core baseObject.{u}) (locate n) :=
          congrFun hStable (locate n)
        _ = s (qPoint n) (locate n) := native_inf_at_of_eq _ _ _ hEqual
    apply hIncompatible n
    refine ⟨s pPoint (locate n), hcp (locate n), ?_⟩
    rw [← hEmptyValue]
    exact hsMon empty_le_p (locate n)
  letI : Finite F := hF.to_subtype
  exact not_injective_infinite_finite select hInjective

end DIDomainClassification.FiniteCoordinateRetraction
