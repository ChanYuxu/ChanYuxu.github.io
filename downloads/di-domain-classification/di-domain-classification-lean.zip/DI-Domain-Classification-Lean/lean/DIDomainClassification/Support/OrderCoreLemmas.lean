import DIDomainClassification.Support.OrderCore
import Mathlib.Order.ScottContinuity
import Mathlib.Order.Bounds.Basic

/-!
# Narrow order-theoretic API

The finite-directed and basis-image arguments adapt the corresponding common
book proofs to the same explicit predicates without importing its umbrella.
No paper classification statement or external mathematical axiom is assumed.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.OrderCore

variable {D : Type u} {E : Type v}

theorem isSup_iff_isLUB [Preorder D] {A : Set D} {x : D} :
    IsSup A x ↔ IsLUB A x := Iff.rfl

theorem directedSet_iff [Preorder D] {A : Set D} :
    DirectedSet A ↔ A.Nonempty ∧ DirectedOn (· ≤ ·) A := Iff.rfl

theorem DirectedSet.image [Preorder D] [Preorder E] {A : Set D} {f : D → E}
    (hA : DirectedSet A) (hf : Monotone f) : DirectedSet (f '' A) := by
  constructor
  · obtain ⟨a, ha⟩ := hA.1
    exact ⟨f a, ⟨a, ha, rfl⟩⟩
  · rintro x ⟨a, ha, rfl⟩ y ⟨b, hb, rfl⟩
    obtain ⟨c, hc, hac, hbc⟩ := hA.2 ha hb
    exact ⟨f c, ⟨c, hc, rfl⟩, hf hac, hf hbc⟩

theorem DirectedSet.exists_upper_finite [Preorder D] {A F : Set D}
    (hA : DirectedSet A) (hF : F.Finite) (hsub : F ⊆ A) :
    ∃ z ∈ A, ∀ x ∈ F, x ≤ z := by
  induction F, hF using Set.Finite.induction_on with
  | empty =>
      obtain ⟨z, hz⟩ := hA.1
      exact ⟨z, hz, by intro x hx; cases hx⟩
  | @insert a F ha _ ih =>
      have hFsub : F ⊆ A := fun x hx => hsub (by simp [hx])
      obtain ⟨z, hz, hFz⟩ := ih hFsub
      have haA : a ∈ A := hsub (by simp)
      obtain ⟨w, hw, haw, hzw⟩ := hA.2 haA hz
      refine ⟨w, hw, ?_⟩
      intro x hx
      rcases Set.mem_insert_iff.mp hx with rfl | hx
      · exact haw
      · exact (hFz x hx).trans hzw

theorem DirectedSet.isSup_mem_of_finite [PartialOrder D]
    {A : Set D} {x : D} (hA : DirectedSet A) (hfin : A.Finite)
    (hsup : IsSup A x) : x ∈ A := by
  obtain ⟨z, hz, hAz⟩ := hA.exists_upper_finite hfin (Set.Subset.refl A)
  have hxz : x = z := le_antisymm (hsup.2 z hAz) (hsup.1 hz)
  simpa only [hxz] using hz

theorem scottContinuous_isSup [Preorder D] [Preorder E]
    {f : D → E} (hf : _root_.ScottContinuous f)
    {A : Set D} {x : D} (hA : DirectedSet A) (hx : IsSup A x) :
    IsSup (f '' A) (f x) := hf hA.1 hA.2 hx

private theorem singleton_directed [Preorder D] (x : D) :
    DirectedSet ({x} : Set D) := by
  refine ⟨⟨x, by simp⟩, ?_⟩
  intro a ha b hb
  have hax : a = x := Set.mem_singleton_iff.mp ha
  have hbx : b = x := Set.mem_singleton_iff.mp hb
  subst a
  subst b
  exact ⟨x, by simp, le_rfl, le_rfl⟩

private theorem singleton_isSup [Preorder D] (x : D) :
    IsSup ({x} : Set D) x := by
  constructor
  · intro a ha
    simpa only [Set.mem_singleton_iff.mp ha] using (le_rfl : x ≤ x)
  · intro y hy
    exact hy (by simp)

theorem WayBelow.le [Preorder D] {x y : D} (hxy : WayBelow x y) : x ≤ y := by
  obtain ⟨a, ha, hxa⟩ := hxy (singleton_directed y) (singleton_isSup y) le_rfl
  simpa only [Set.mem_singleton_iff.mp ha] using hxa

theorem wayBelow_iff_le_of_compact [Preorder D] {k x : D} (hk : Compact k) :
    WayBelow k x ↔ k ≤ x := by
  constructor
  · exact WayBelow.le
  · intro hkx A s hA hs hxs
    exact hk hA hs (hkx.trans hxs)

theorem compactBelow_eq_approximants [Preorder D] (x : D) :
    CompactBelow x = Approximants (CompactSet D) x := by
  ext k
  constructor
  · intro hk
    exact ⟨hk.1, (wayBelow_iff_le_of_compact hk.1).2 hk.2⟩
  · intro hk
    exact ⟨hk.1, hk.2.le⟩

theorem algebraic_compactBasis [PartialOrder D] (hD : IsAlgebraicDcpo D) :
    IsBasis (CompactSet D) := by
  intro x
  rw [← compactBelow_eq_approximants x]
  exact hD.2 x

theorem compact_of_finite_principal_ideal [PartialOrder D]
    (hD : IsAlgebraicDcpo D) {k x : D} (hfin : (Set.Iic k).Finite)
    (hxk : x ≤ k) : Compact x := by
  have hfinite : (CompactBelow x).Finite :=
    hfin.subset (fun _ ha => ha.2.trans hxk)
  have hxmem := (hD.2 x).1.isSup_mem_of_finite hfinite (hD.2 x).2
  exact hxmem.1

theorem isBasis_of_directed_approximants [Preorder D] {B : Set D}
    (hB : ∀ x : D, ∃ A : Set D,
      A ⊆ Approximants B x ∧ DirectedSet A ∧ IsSup A x) : IsBasis B := by
  intro x
  obtain ⟨A, hsub, hdir, hsup⟩ := hB x
  have cofinal : ∀ b ∈ Approximants B x, ∃ a ∈ A, b ≤ a := by
    intro b hb
    exact hb.2 hdir hsup le_rfl
  constructor
  · constructor
    · obtain ⟨a, ha⟩ := hdir.1
      exact ⟨a, hsub ha⟩
    · intro b hb c hc
      obtain ⟨a, ha, hba⟩ := cofinal b hb
      obtain ⟨d, hd, hcd⟩ := cofinal c hc
      obtain ⟨e, he, hae, hde⟩ := hdir.2 ha hd
      exact ⟨e, hsub he, hba.trans hae, hcd.trans hde⟩
  · constructor
    · intro b hb
      exact hb.2.le
    · intro z hz
      exact hsup.2 z (fun a ha => hz (hsub ha))

theorem basis_image_of_continuous_split [Preorder D] [Preorder E]
    {B : Set D} (hB : IsBasis B)
    {s : E → D} {r : D → E} (hs : _root_.ScottContinuous s)
    (hr : _root_.ScottContinuous r) (hleft : Function.LeftInverse r s) :
    IsBasis (r '' B) := by
  apply isBasis_of_directed_approximants
  intro x
  let A : Set D := Approximants B (s x)
  refine ⟨r '' A, ?_, (hB (s x)).1.image hr.monotone, ?_⟩
  · rintro y ⟨b, hb, rfl⟩
    refine ⟨⟨b, hb.1, rfl⟩, ?_⟩
    intro C c hC hc hxc
    have hSdir := hC.image hs.monotone
    have hSsup := scottContinuous_isSup hs hC hc
    obtain ⟨d, hd, hbd⟩ := hb.2 hSdir hSsup (hs.monotone hxc)
    obtain ⟨e, he, rfl⟩ := hd
    refine ⟨e, he, ?_⟩
    calc
      r b ≤ r (s e) := hr.monotone hbd
      _ = e := hleft e
  · have hsup := scottContinuous_isSup hr (hB (s x)).1 (hB (s x)).2
    simpa only [A, hleft x] using hsup

theorem dcpo_of_continuous_split [Preorder D] [Preorder E] (hD : IsDcpo D)
    {s : E → D} {r : D → E} (hs : _root_.ScottContinuous s)
    (hr : _root_.ScottContinuous r) (hleft : Function.LeftInverse r s) : IsDcpo E := by
  intro C hC
  obtain ⟨d, hd⟩ := hD (s '' C) (hC.image hs.monotone)
  have hrSup := scottContinuous_isSup hr (hC.image hs.monotone) hd
  have image_eq : r '' (s '' C) = C := by
    ext x
    constructor
    · rintro ⟨y, ⟨z, hz, rfl⟩, hzx⟩
      have hzx' : z = x := (hleft z).symm.trans hzx
      exact hzx' ▸ hz
    · intro hx
      exact ⟨s x, ⟨x, hx, rfl⟩, hleft x⟩
  exact ⟨r d, by simpa only [image_eq] using hrSup⟩

end DIDomainClassification.OrderCore
