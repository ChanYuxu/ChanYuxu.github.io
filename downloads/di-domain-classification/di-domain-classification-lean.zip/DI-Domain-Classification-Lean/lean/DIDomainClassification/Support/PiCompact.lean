import DIDomainClassification.Support.PiOrderCore

/-!
# Compact tuples: exact coordinate and finite-support characterization

Compactness is the accepted arbitrary nonempty-directed-supremum predicate.
Coordinate compactness is proved with coordinate-update test families, not
inferred from Scott continuity. No dcpo/algebraicity or countability premise
is required for these generic pointed-product results.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.PiTheory

open OrderCore

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]

theorem compact_coordinate {x : ∀ i, D i} (hx : Compact x) (i : I) : Compact (x i) := by
  classical
  intro A s hA hs hxs
  obtain ⟨_, ⟨a, ha, rfl⟩, hxa⟩ := hx
    (hA.image (update_monotone x i)) (update_isSup x i hA.1 hs)
    (le_update_of_le x i hxs)
  exact ⟨a, ha, by simpa using hxa i⟩

section Bottom

variable [∀ i, OrderBot (D i)]

theorem compact_finite_support {x : ∀ i, D i} (hx : Compact x) : (support x).Finite := by
  classical
  obtain ⟨_, ⟨F, rfl⟩, hxt⟩ := hx (truncations_directed x) (truncations_isSup x) le_rfl
  apply F.finite_toSet.subset
  intro i hi
  by_contra hnot
  change i ∉ F at hnot
  have hle : x i ≤ ⊥ := by
    simpa only [truncate_apply_not_mem F x hnot] using hxt i
  exact hi (le_antisymm hle bot_le)

theorem compact_of_finite_support {x : ∀ i, D i}
    (hfinite : (support x).Finite) (hcoord : ∀ i, Compact (x i)) : Compact x := by
  classical
  intro A s hA hs hxs
  have hwitness : ∀ i : I, ∃ a : (∀ i, D i), a ∈ A ∧ x i ≤ a i := by
    intro i
    obtain ⟨_, ⟨a, ha, rfl⟩, hxa⟩ := hcoord i
      (hA.image (fun _ _ h => h i)) (coordinate_isSup hs i) (hxs i)
    exact ⟨a, ha, hxa⟩
  choose a ha hxa using hwitness
  have himageFinite : (a '' support x).Finite := hfinite.image a
  have himageSub : a '' support x ⊆ A := by
    rintro _ ⟨i, _, rfl⟩
    exact ha i
  obtain ⟨z, hz, haz⟩ := hA.exists_upper_finite himageFinite himageSub
  refine ⟨z, hz, ?_⟩
  intro i
  by_cases hi : x i = ⊥
  · simp [hi]
  · exact (hxa i).trans (haz (a i) ⟨i, hi, rfl⟩ i)

theorem compact_pi_iff (x : ∀ i, D i) :
    Compact x ↔ (∀ i, Compact (x i)) ∧ (support x).Finite := by
  constructor
  · intro hx
    exact ⟨compact_coordinate hx, compact_finite_support hx⟩
  · rintro ⟨hcoord, hfinite⟩
    exact compact_of_finite_support hfinite hcoord

theorem compact_single (i : I) {a : D i} (ha : Compact a) : Compact (single i a) := by
  classical
  apply compact_of_finite_support (support_single_finite i a)
  intro j
  by_cases hji : j = i
  · subst j
    simpa using ha
  · simpa only [single_other i a hji] using
      (compact_bot : Compact (⊥ : D j))

end Bottom

end DIDomainClassification.PiTheory
