import DIDomainClassification.Support.ForestGraft

/-! Finite root expansion by repeatedly grafting a SINGLE actual component.
n means n NEW ancestors, with the original root retained as the n-prefixed
embedded node. The marker need not be fresh. No source wrapper/claim.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.TreeGrafting

open Trees

variable {Index : Type u}

abbrev NormalizedTree (Index : Type u) := {T : RootedPrefixTree Index // T.rootList = []}

def pushRootData (marker : Index) (Q : NormalizedTree Index) : NormalizedTree Index :=
  ⟨forest (fun _ : Unit => Q.val) (fun _ => marker) (fun _ => Q.property), rfl⟩

def rootExpansionData (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) : ℕ → NormalizedTree Index
  | 0 => ⟨S, hroot⟩
  | n + 1 => pushRootData marker (rootExpansionData S hroot marker n)

def rootExpansion (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) : RootedPrefixTree Index :=
  (rootExpansionData S hroot marker n).val

theorem rootExpansion_rootList (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) : (rootExpansion S hroot marker n).rootList = [] :=
  (rootExpansionData S hroot marker n).property

theorem rootExpansion_zero (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) : rootExpansion S hroot marker 0 = S := rfl

theorem rootExpansion_succ (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) : rootExpansion S hroot marker (n + 1) =
    forest (fun _ : Unit => rootExpansion S hroot marker n) (fun _ => marker)
      (fun _ => rootExpansion_rootList S hroot marker n) := rfl

def rootExpansionEmbed (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) : ∀ n : ℕ, S.Node → (rootExpansion S hroot marker n).Node
  | 0, v => v
  | n + 1, v => forestEmbed (fun _ : Unit => rootExpansion S hroot marker n)
      (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n) ()
      (rootExpansionEmbed S hroot marker n v)

theorem rootExpansionEmbed_val (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) (v : S.Node) :
    (rootExpansionEmbed S hroot marker n v).val = List.replicate n marker ++ v.val := by
  induction n with
  | zero => rfl
  | succ n ih =>
    change marker :: (rootExpansionEmbed S hroot marker n v).val = _
    rw [ih, List.replicate_succ]
    rfl

theorem rootExpansionEmbed_injective (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) : Function.Injective (rootExpansionEmbed S hroot marker n) := by
  intro v w hvw
  apply Subtype.ext
  have h := congrArg (fun z : (rootExpansion S hroot marker n).Node => z.val) hvw
  change (rootExpansionEmbed S hroot marker n v).val =
    (rootExpansionEmbed S hroot marker n w).val at h
  rw [rootExpansionEmbed_val, rootExpansionEmbed_val] at h
  exact List.append_cancel_left h

theorem rootExpansionEmbed_isChild_iff (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) (v w : S.Node) :
    (rootExpansion S hroot marker n).IsChild (rootExpansionEmbed S hroot marker n v)
      (rootExpansionEmbed S hroot marker n w) ↔ S.IsChild v w := by
  induction n with
  | zero => exact Iff.rfl
  | succ n ih =>
    exact (forestEmbed_isChild_iff (fun _ : Unit => rootExpansion S hroot marker n)
      (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n) () _ _).trans ih

theorem rootExpansionEmbed_isLeaf_iff (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) (v : S.Node) :
    (rootExpansion S hroot marker n).IsLeaf (rootExpansionEmbed S hroot marker n v) ↔
      S.IsLeaf v := by
  induction n with
  | zero => exact Iff.rfl
  | succ n ih =>
    exact (forestEmbed_isLeaf_iff (fun _ : Unit => rootExpansion S hroot marker n)
      (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n)
      (fun a b _ => Subsingleton.elim a b) () _).trans ih

theorem rootExpansion_isWellFounded (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (hS : S.IsWellFounded) (n : ℕ) :
    (rootExpansion S hroot marker n).IsWellFounded := by
  induction n with
  | zero => exact hS
  | succ n ih =>
    exact forest_isWellFounded (fun _ : Unit => rootExpansion S hroot marker n)
      (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n)
      (fun a b _ => Subsingleton.elim a b) (fun _ => ih)

theorem rootExpansion_isWellFounded_iff (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) :
    (rootExpansion S hroot marker n).IsWellFounded ↔ S.IsWellFounded := by
  constructor
  · intro hE
    apply S.isWellFounded_iff_wellFounded_reverseChildRelation.mpr
    have h := ((rootExpansion S hroot marker n).isWellFounded_iff_wellFounded_reverseChildRelation.mp
      hE).onFun (f := rootExpansionEmbed S hroot marker n)
    exact h.mono (fun _ _ hxy => (rootExpansionEmbed_isChild_iff S hroot marker n _ _).mpr hxy)
  · exact fun hS => rootExpansion_isWellFounded S hroot marker hS n

theorem rootExpansionEmbed_nodeRank_eq (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (hS : S.IsWellFounded) (n : ℕ) (v : S.Node) :
    (rootExpansion S hroot marker n).nodeRank (rootExpansion_isWellFounded S hroot marker hS n)
      (rootExpansionEmbed S hroot marker n v) = S.nodeRank hS v := by
  induction n with
  | zero => rfl
  | succ n ih =>
    exact (forestEmbed_nodeRank_eq (fun _ : Unit => rootExpansion S hroot marker n)
      (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n)
      (fun a b _ => Subsingleton.elim a b)
      (fun _ => rootExpansion_isWellFounded S hroot marker hS n) ()
      (rootExpansionEmbed S hroot marker n v)).trans ih

theorem rootExpansion_treeRank_succ (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (hS : S.IsWellFounded) (n : ℕ) :
    (rootExpansion S hroot marker (n + 1)).treeRank
        (rootExpansion_isWellFounded S hroot marker hS (n + 1)) =
      (rootExpansion S hroot marker n).treeRank
        (rootExpansion_isWellFounded S hroot marker hS n) + 1 := by
  calc
    _ = ⨆ _i : Unit, (rootExpansion S hroot marker n).treeRank
        (rootExpansion_isWellFounded S hroot marker hS n) + 1 :=
      forest_treeRank_eq (fun _ : Unit => rootExpansion S hroot marker n)
        (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n)
        (fun a b _ => Subsingleton.elim a b)
        (fun _ => rootExpansion_isWellFounded S hroot marker hS n)
    _ = _ := le_antisymm (Ordinal.iSup_le (fun _ => le_rfl))
      (Ordinal.le_iSup (fun _i : Unit => (rootExpansion S hroot marker n).treeRank
        (rootExpansion_isWellFounded S hroot marker hS n) + 1) ())

theorem rootExpansion_treeRank_eq (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (hS : S.IsWellFounded) (n : ℕ) :
    (rootExpansion S hroot marker n).treeRank (rootExpansion_isWellFounded S hroot marker hS n) =
      S.treeRank hS + (n : Ordinal.{u}) := by
  induction n with
  | zero => exact (add_zero _).symm
  | succ n ih =>
    rw [rootExpansion_treeRank_succ S hroot marker hS n, ih, Nat.cast_succ, add_assoc]

theorem rootExpansion_treeRank_ge (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (hS : S.IsWellFounded) (n : ℕ) :
    S.treeRank hS ≤ (rootExpansion S hroot marker n).treeRank
      (rootExpansion_isWellFounded S hroot marker hS n) := by
  induction n with
  | zero => exact le_rfl
  | succ n ih =>
    rw [rootExpansion_treeRank_succ S hroot marker hS n]
    exact ih.trans (by simpa only [Order.succ_eq_add_one] using
      (Order.lt_succ ((rootExpansion S hroot marker n).treeRank
        (rootExpansion_isWellFounded S hroot marker hS n))).le)

def rootExpansionAncestors (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) : ∀ n : ℕ, Set (rootExpansion S hroot marker n).Node
  | 0 => ∅
  | n + 1 => {(rootExpansion S hroot marker (n + 1)).root} ∪
      forestEmbed (fun _ : Unit => rootExpansion S hroot marker n) (fun _ => marker)
        (fun _ => rootExpansion_rootList S hroot marker n) () ''
        rootExpansionAncestors S hroot marker n

theorem rootExpansionAncestors_finite (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) :
    (rootExpansionAncestors S hroot marker n).Finite := by
  induction n with
  | zero => exact Set.finite_empty
  | succ n ih => exact (Set.finite_singleton _).union (ih.image _)

theorem rootExpansionNode_cases (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) (v : (rootExpansion S hroot marker n).Node) :
    v ∈ rootExpansionAncestors S hroot marker n ∨
      ∃ w : S.Node, v = rootExpansionEmbed S hroot marker n w := by
  induction n with
  | zero => exact Or.inr ⟨v, rfl⟩
  | succ n ih =>
    rcases forestNode_cases (fun _ : Unit => rootExpansion S hroot marker n)
      (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n) v with
      hrootv | ⟨i, w, hvw⟩
    · exact Or.inl (Or.inl (Set.mem_singleton_iff.mpr hrootv))
    · cases i
      rcases ih w with hw | ⟨z, hw⟩
      · exact Or.inl (Or.inr ⟨w, hw, hvw.symm⟩)
      · exact Or.inr ⟨z, hvw.trans (congrArg
          (forestEmbed (fun _ : Unit => rootExpansion S hroot marker n)
            (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n) ()) hw)⟩

theorem rootExpansion_leaf_original (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ)
    (v : (rootExpansion S hroot marker n).Node)
    (hv : (rootExpansion S hroot marker n).IsLeaf v) :
    ∃ w : S.Node, S.IsLeaf w ∧ v = rootExpansionEmbed S hroot marker n w := by
  induction n with
  | zero => exact ⟨v, hv, rfl⟩
  | succ n ih =>
    rcases forestNode_cases (fun _ : Unit => rootExpansion S hroot marker n)
      (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n) v with
      hrootv | ⟨i, w, hvw⟩
    · have hleaf := hrootv ▸ hv
      have hempty := (forest_root_isLeaf_iff (fun _ : Unit => rootExpansion S hroot marker n)
        (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n)).mp hleaf
      exact (hempty.false ()).elim
    · cases i
      have hw := (forestEmbed_isLeaf_iff (fun _ : Unit => rootExpansion S hroot marker n)
        (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n)
        (fun a b _ => Subsingleton.elim a b) () w).mp (hvw ▸ hv)
      obtain ⟨z, hz, hwz⟩ := ih w hw
      exact ⟨z, hz, hvw.trans (congrArg
        (forestEmbed (fun _ : Unit => rootExpansion S hroot marker n)
          (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n) ()) hwz)⟩

theorem rootExpansion_pathTo (S : RootedPrefixTree Index) (hroot : S.rootList = [])
    (marker : Index) (n : ℕ) (v : S.Node) :
    (rootExpansion S hroot marker n).pathTo (rootExpansionEmbed S hroot marker n v) =
      rootExpansionAncestors S hroot marker n ∪
        rootExpansionEmbed S hroot marker n '' S.pathTo v := by
  induction n with
  | zero =>
    change S.pathTo v = ∅ ∪ id '' S.pathTo v
    simp only [Set.empty_union, Set.image_id]
  | succ n ih =>
    rw [show (rootExpansion S hroot marker (n + 1)).pathTo
        (rootExpansionEmbed S hroot marker (n + 1) v) =
        {(rootExpansion S hroot marker (n + 1)).root} ∪
        forestEmbed (fun _ : Unit => rootExpansion S hroot marker n) (fun _ => marker)
          (fun _ => rootExpansion_rootList S hroot marker n) () ''
          (rootExpansion S hroot marker n).pathTo (rootExpansionEmbed S hroot marker n v) from
      forest_pathTo_embed (fun _ : Unit => rootExpansion S hroot marker n)
        (fun _ => marker) (fun _ => rootExpansion_rootList S hroot marker n)
        (fun a b _ => Subsingleton.elim a b) () _]
    rw [ih, Set.image_union, Set.image_image]
    change _ = ({_} ∪ _) ∪ _
    rw [Set.union_assoc]
    rfl

theorem rootExpansion_finiteCompleteBranch (S : RootedPrefixTree Index)
    (hroot : S.rootList = []) (marker : Index) (n : ℕ) (c : Set S.Node)
    (hc : S.IsFiniteCompleteBranch c) :
    (rootExpansion S hroot marker n).IsFiniteCompleteBranch
      (rootExpansionAncestors S hroot marker n ∪ rootExpansionEmbed S hroot marker n '' c) := by
  obtain ⟨v, hv, rfl⟩ := hc
  exact ⟨rootExpansionEmbed S hroot marker n v,
    (rootExpansionEmbed_isLeaf_iff S hroot marker n v).mpr hv,
    (rootExpansion_pathTo S hroot marker n v).symm⟩

end DIDomainClassification.TreeGrafting

