import DIDomainClassification.Section02.RetractionCalculus
import DIDomainClassification.Section02.TwoRetract
import DIDomainClassification.Section04.TruncatedRetractions
import DIDomainClassification.Support.FiniteForbiddenProduct
import DIDomainClassification.Support.CoherenceDegreeBounds
import DIDomainClassification.Support.TerminalProductClosure

/-! Native finite products, true stable splittings, and finite reindexing.
Only generic split data are inputs; no finite-generator theorem is assumed. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FiniteGeneratorCalculus

open Preliminaries EventStructures CoherenceDegree FiniteOrderDomains
open Section02.RetractionCalculusModels Section04.FiniteCategoryModels
open Section04.FiniteGeneratorModels

theorem trans {D E F : DIDomainObject.{u}}
    (hDE : HasStableRetraction D E) (hEF : HasStableRetraction E F) :
    HasStableRetraction D F := by
  obtain ⟨s, r, hsr⟩ := hDE
  obtain ⟨t, q, htq⟩ := hEF
  exact ((Section02.retractionCalculus.{u,u}).1 D E F s r t q hsr htq).2

theorem ofOrderIso (D E : DIDomainObject.{u}) (e : D ≃o E) :
    HasStableRetraction D E :=
  ⟨OrderIsoTransport.stableHom D E e,
    OrderIsoTransport.stableHom E D e.symm, e.left_inv⟩

theorem degree_eq (D E : DIDomainObject.{u}) (e : D ≃o E) :
    coherenceDegree D.isDIDomain.toIsScottDomain =
      coherenceDegree E.isDIDomain.toIsScottDomain := by
  apply le_antisymm
  · exact coherenceDegree_mono_of_scott_split D.isDIDomain.toIsScottDomain
      E.isDIDomain.toIsScottDomain (OrderIsoTransport.scottContinuous e)
      (OrderIsoTransport.scottContinuous e.symm) e.left_inv
  · exact coherenceDegree_mono_of_scott_split E.isDIDomain.toIsScottDomain
      D.isDIDomain.toIsScottDomain (OrderIsoTransport.scottContinuous e.symm)
      (OrderIsoTransport.scottContinuous e) e.right_inv

theorem finiteCountablyBased (D : DIDomainObject.{u}) [Finite D] :
    IsCountablyBasedDIDomain D := ⟨D.isDIDomain, Set.to_countable _⟩

def reindexOrderIso {I : Type u} (n : ℕ) (hn : 2 ≤ n) (m : ℕ) (e : I ≃ Fin m) :
    (I → CubeCarrier.{u} n hn) ≃o CubePower.{u} n hn m where
  toFun f j := f (e.symm j)
  invFun g i := g (e i)
  left_inv f := by funext i; exact congrArg f (e.symm_apply_apply i)
  right_inv g := by funext j; exact congrArg g (e.apply_symm_apply j)
  map_rel_iff' := by
    intro f g
    constructor
    · intro h i
      have hi := h (e i)
      change f (e.symm (e i)) ≤ g (e.symm (e i)) at hi
      simpa only [e.symm_apply_apply] using hi
    · intro h j
      change f (e.symm j) ≤ g (e.symm j)
      exact h (e.symm j)

theorem finiteProductPower {I : Type u} [Finite I]
    (F : I → DIDomainObject.{u}) [∀ i, Finite (F i)]
    (n : ℕ) (hn : 2 ≤ n) (hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn))
    (hFactors : ∀ i, HasStableRetraction (F i) (cubeCore n hn hCube.1)) :
    ∃ (m : ℕ) (hPi : IsCountablyBasedDIDomain (∀ i, F i))
      (hPower : IsCountablyBasedDIDomain (CubePower.{u} n hn m)),
      HasStableRetraction (piCore F hPi.1) (powerCore n hn m hPower.1) := by
  classical
  choose s r hleft using hFactors
  let D : I → CountablyBasedDIDomain.{u} := fun i =>
    { toDIDomainObject := F i
      countableCompacts := (finiteCountablyBased (F i)).2 }
  let C : I → CountablyBasedDIDomain.{u} := fun _ => cubeObject n hn hCube
  obtain ⟨hPi, hTarget, hS, hR, hL⟩ :=
    (Section02.retractionCalculus.{u,u}).2.2.1 I D C s r hleft
  letI : Fintype I := Fintype.ofFinite I
  let m := Fintype.card I
  let hPower := (Section02.countableProducts (Fin m)
    (fun _ => CubeCarrier.{u} n hn) (fun _ => hCube)).1
  let e := reindexOrderIso n hn m (Fintype.equivFin I)
  refine ⟨m, hPi, hPower, ?_⟩
  apply trans (E := piCore (fun _ : I => cubeCore n hn hCube.1) hTarget.1)
  · exact ⟨StableHom.ofFunction (piMap s) hS, StableHom.ofFunction (piMap r) hR, hL⟩
  · exact ofOrderIso _ _ e

def bitValue {A : Type u} (S : Set A) (a : A) : TwoCarrier.{u} := by
  classical
  exact if a ∈ S then one else zero

theorem bit_le_iff {A : Type u} (S T : Set A) (a : A) :
    bitValue S a ≤ bitValue T a ↔ (a ∈ S → a ∈ T) := by
  classical
  have hnot : ¬ (one.{u} ≤ zero.{u}) := by
    change ¬ (1 : Fin 2) ≤ 0
    decide
  by_cases hS : a ∈ S <;> by_cases hT : a ∈ T <;>
    simp [bitValue, hS, hT, hnot, FiniteOrderDomains.zero_le]

variable {A : Type u} [PartialOrder A]

def factorFamily (E : FinitaryPrimeEventStructure A) :
    A ⊕ causalConflictFamily E → DIDomainObject.{u}
  | .inl _ => twoObject.toDIDomainObject
  | .inr H => FiniteForbiddenProduct.factorCore E H

instance finiteFactor [Finite A] (E : FinitaryPrimeEventStructure A)
    (i : A ⊕ causalConflictFamily E) : Finite (factorFamily E i) := by
  cases i
  · exact inferInstanceAs (Finite TwoCarrier.{u})
  · exact inferInstanceAs (Finite (Section04.FiniteGeneratorModels.ProperIn _))

def productOrderIso (E : FinitaryPrimeEventStructure A) :
    ForbiddenProduct E ≃o (∀ i, factorFamily E i) where
  toFun p i := match i with
    | .inl a => bitValue p.1 a
    | .inr H => p.2 H
  invFun f := ({a | f (.inl a) = one}, fun H => f (.inr H))
  left_inv p := by
    classical
    apply Prod.ext
    · ext a
      change (bitValue p.1 a = one) ↔ a ∈ p.1
      by_cases h : a ∈ p.1 <;> simp [bitValue, h, FiniteOrderDomains.zero_ne_one]
    · rfl
  right_inv f := by
    classical
    funext i
    cases i with
    | inl a =>
      change (if f (.inl a) = one then one else zero) = f (.inl a)
      rcases eq_zero_or_one (f (.inl a)) with h | h
      · rw [h]
        exact if_neg (FiniteOrderDomains.zero_ne_one.{u})
      · rw [h]
        exact if_pos rfl
    | inr H => rfl
  map_rel_iff' := by
    intro p q
    constructor
    · intro h
      refine ⟨?_, fun H => h (.inr H)⟩
      intro a ha
      exact (bit_le_iff p.1 q.1 a).mp (h (.inl a)) ha
    · intro h i
      cases i with
      | inl a => exact (bit_le_iff p.1 q.1 a).mpr (fun ha => h.1 ha)
      | inr H => exact h.2 H

theorem cube_nontrivial (n : ℕ) (hn : 2 ≤ n)
    (h : IsDIDomain (CubeCarrier.{u} n hn)) :
    ∃ x y : cubeCore n hn h, x ≠ y := by
  let i : Fin n := ⟨0, by omega⟩
  let j : Fin n := ⟨1, by omega⟩
  have hji : j ≠ i := by
    intro hij
    have hc := congrArg Fin.val hij
    change (1 : ℕ) = 0 at hc
    omega
  let X : CubeCarrier.{u} n hn := ⟨⟨∅, by
    intro heq
    have : i ∈ (∅ : Set (Fin n)) := heq ▸ Set.mem_univ i
    exact this⟩⟩
  let Y : CubeCarrier.{u} n hn := ⟨⟨{i}, by
    intro heq
    have : j ∈ ({i} : Set (Fin n)) := heq ▸ Set.mem_univ j
    exact hji (Set.mem_singleton_iff.mp this)⟩⟩
  refine ⟨X, Y, ?_⟩
  intro heq
  have hsets := congrArg (fun W : CubeCarrier.{u} n hn => W.down.val) heq
  change (∅ : Set (Fin n)) = {i} at hsets
  have : i ∈ (∅ : Set (Fin n)) := by
    rw [hsets]
    exact Set.mem_singleton i
  exact this

/-- The singleton boundary really permits exponent zero, rather than merely
leaving the finite exponent unspecified in the general existence theorem. -/
theorem singletonZeroPower (n : ℕ) (hn : 2 ≤ n) :
    ∃ (_hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn))
      (hPower : IsCountablyBasedDIDomain (CubePower.{u} n hn 0)),
      HasStableRetraction
        (DIDomainObject.ofType PUnit.{u+1} TerminalProductClosure.unit_isDIDomain)
        (powerCore n hn 0 hPower.1) := by
  let hCube := FiniteCubeRetractions.cubeCountablyBased.{u} n hn
  let hPower := (Section02.countableProducts (Fin 0)
    (fun _ => CubeCarrier.{u} n hn) (fun _ => hCube)).1
  let e : PUnit.{u+1} ≃o CubePower.{u} n hn 0 := {
    toFun := fun _ i => False.elim (Nat.not_lt_zero i.val i.isLt)
    invFun := fun _ => PUnit.unit
    left_inv := fun x => Subsingleton.elim _ x
    right_inv := fun f => funext (fun i => False.elim (Nat.not_lt_zero i.val i.isLt))
    map_rel_iff' := by
      intro x y
      constructor
      · intro _
        exact (Subsingleton.elim x y) ▸ le_rfl
      · intro _ i
        exact False.elim (Nat.not_lt_zero i.val i.isLt) }
  exact ⟨hCube, hPower, ofOrderIso _ _ e⟩

end DIDomainClassification.FiniteGeneratorCalculus
