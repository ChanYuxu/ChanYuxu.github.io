import DIDomainClassification.Section01.Classification
import DIDomainClassification.Section04.GeneratedCategoryWellDefined
import DIDomainClassification.Section05.UniversalSourceStatements
import DIDomainClassification.Support.FinitePowerMembership

/-! The literal raw generated class, with the source's unqualified limit
clause kept separate. No classification or least-category fact is assumed. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.SingleGeneratorProof
open Preliminaries Subcategories Section04 Section04.CutModels
open Section03.StableFunctionModels Section04.AdditionalSourceModels

def parameter (D : CountablyBasedDIDomain.{u}) : Ordinal.{u+1} :=
  max 2 (objectDegree D) + 1

theorem three_le_parameter (D : CountablyBasedDIDomain.{u}) : 3 ≤ parameter D := by
  have h : (2 : Ordinal.{u+1}) + 1 ≤ max 2 (objectDegree D) + 1 :=
    by simpa only [Order.succ_eq_add_one] using
      Order.succ_le_succ (le_max_left (2 : Ordinal.{u+1}) (objectDegree D))
  norm_num at h
  exact h

theorem degree_lt_parameter (D : CountablyBasedDIDomain.{u}) :
    objectDegree D < parameter D :=
  (le_max_right _ _).trans_lt (Order.lt_succ (max 2 (objectDegree D)))

theorem two_le_bound : (2 : Ordinal.{u+1}) ≤ firstUncountableBound.{u} := by
  have h := objectDegree_le_firstUncountableBound (OrdinalCutWitnesses.finiteCube.{u} 2 (by decide))
  rw [OrdinalCutWitnesses.finiteCube_degree] at h
  exact h

theorem parameter_domain (D : CountablyBasedDIDomain.{u}) : DomainParameters (parameter D) := by
  refine ⟨three_le_parameter D, ?_⟩
  exact Order.succ_le_succ
    (max_le two_le_bound (objectDegree_le_firstUncountableBound D))

theorem parameter_lt_omega (D : CountablyBasedDIDomain.{u}) (hD : Finite D) :
    parameter D < Ordinal.omega0 := by
  letI : Finite (Core D) := hD
  have h : max (2 : Ordinal.{u+1}) (objectDegree D) < Ordinal.omega0 :=
    max_lt (Ordinal.nat_lt_omega0 2) (FinitePowerMembership.finite_degree_lt_omega D)
  simpa only [parameter, Order.succ_eq_add_one] using Ordinal.isSuccLimit_omega0.succ_lt h

theorem parameter_finite (D : CountablyBasedDIDomain.{u}) (hD : Finite D) :
    FiniteParameters (parameter D) := ⟨three_le_parameter D, (parameter_lt_omega D hD).le⟩

theorem generated_hypotheses (D : CountablyBasedDIDomain.{u}) (hD : Nontrivial (Core D)) :
    CategoryHypotheses (GeneratedClass D) := by
  letI := hD
  obtain ⟨x, y, hxy⟩ := exists_pair_ne (Core D)
  exact ⟨⟨D, GeneratedClassClosure.generatedContainsGenerator D, x, y, hxy⟩,
    GeneratedClassClosure.generatedAdmissible D⟩

theorem generated_eq_of_isGeneratedBy (D : CountablyBasedDIDomain.{u})
    (P : ObjectClass.{u}) (hP : IsGeneratedBy D P) : GeneratedClass D = P := by
  funext E
  apply propext
  exact ⟨fun h => h P hP.1 hP.2.1,
    fun h => hP.2.2 (GeneratedClass D) (GeneratedClassClosure.generatedAdmissible D)
      (GeneratedClassClosure.generatedContainsGenerator D) E h⟩

theorem parameter_le_of_mem (D : CountablyBasedDIDomain.{u}) (a : Ordinal.{u+1})
    (h3 : 3 ≤ a) (hD : objectDegree D < a) : parameter D ≤ a := by
  apply Order.succ_le_iff.mpr
  exact max_lt (CandidateCutClosure.two_lt_of_three_le h3) hD

theorem finite_generated (D : CountablyBasedDIDomain.{u})
    (hN : Nontrivial (Core D)) (hD : Finite D) :
    GeneratedClass D = FiniteDomainCut (parameter D) := by
  have hParams := parameter_finite D hD
  have hCat := Section03.candidateClosure.2 (parameter D) hParams
  have hIncl := GeneratedClassClosure.generatedLeast D (FiniteDomainCut (parameter D))
    hCat.2 ⟨degree_lt_parameter D, hD⟩
  have hAll : AllFinite (GeneratedClass D) := fun E hE => (hIncl E hE).2
  obtain ⟨a, ha, hEq⟩ :=
    (Section04.cutRecovery (GeneratedClass D) (generated_hypotheses D hN)).2.mpr hAll
  have hDmem := GeneratedClassClosure.generatedContainsGenerator D
  rw [hEq] at hDmem
  have hLe := parameter_le_of_mem D a ha.1 hDmem.1
  have hReverse := (Section04.distinctCuts.1 (parameter D) a hParams ha).mpr hLe
  funext E
  apply propext
  exact ⟨hIncl E, fun hE => hEq ▸ hReverse E hE⟩

theorem infinite_generated (D : CountablyBasedDIDomain.{u})
    (hN : Nontrivial (Core D)) (hD : Infinite D) :
    GeneratedClass D = DomainCut (parameter D) := by
  have hParams := parameter_domain D
  have hCat := Section03.candidateClosure.1 (parameter D) hParams
  have hIncl := GeneratedClassClosure.generatedLeast D (DomainCut (parameter D))
    hCat.2 (degree_lt_parameter D)
  have hNotAll : ¬ AllFinite (GeneratedClass D) := by
    intro hAll
    letI := hD
    letI := hAll D (GeneratedClassClosure.generatedContainsGenerator D)
    exact not_finite D
  rcases (Section04.cutRecovery (GeneratedClass D) (generated_hypotheses D hN)).1 with
    hFinite | hDomain
  · exact False.elim (hNotAll (CutRecoveryProof.finite_alternative_allFinite _ hFinite.1))
  · obtain ⟨a, ha, hEq⟩ := hDomain.1
    have hDmem := GeneratedClassClosure.generatedContainsGenerator D
    rw [hEq] at hDmem
    have hLe := parameter_le_of_mem D a ha.1 hDmem
    have hReverse := (Section04.distinctCuts.2.1 (parameter D) a hParams ha).mpr hLe
    funext E
    apply propext
    exact ⟨hIncl E, fun hE => hEq ▸ hReverse E hE⟩

theorem singleton_subsingleton (D : CountablyBasedDIDomain.{u})
    (hD : SingletonClass D) : Subsingleton (Core D) := by
  obtain ⟨x, hx⟩ := hD
  exact ⟨fun y z => (hx y).trans (hx z).symm⟩

theorem singleton_of_subsingleton (D : CountablyBasedDIDomain.{u})
    (hD : Subsingleton (Core D)) : SingletonClass D :=
  ⟨(Core D).isDIDomain.toIsScottDomain.bottom, fun y => hD.elim _ _⟩

theorem singleton_retract (D E : CountablyBasedDIDomain.{u})
    (hE : SingletonClass E) (hR : HasStableRetraction (Core D) (Core E)) :
    SingletonClass D := by
  obtain ⟨x, hx⟩ := hE
  obtain ⟨s, r, hleft⟩ := hR
  refine ⟨r x, ?_⟩
  intro y
  rw [← hleft y, hx (s y)]

theorem singleton_admissible : IsAdmissibleGeneratedClass SingletonClass.{u} := by
  refine ⟨?_, ?_, singleton_retract⟩
  · apply (replete_iff SingletonClass).mpr
    intro D E e hD
    exact singleton_retract E D hD (CandidateCutClosure.isoRetraction e.symm)
  · exact FullStableSubcategoryClosure.intrinsicallyCartesianClosed SingletonClass
      (fun D E hD hE => singleton_of_subsingleton _
        (GeneratedClassClosure.productSubsingleton D E
          (singleton_subsingleton D hD) (singleton_subsingleton E hE)))
      (fun D E _hD hE => singleton_of_subsingleton _
        (GeneratedClassClosure.exponentialSubsingleton D E (singleton_subsingleton E hE)))
      (singleton_of_subsingleton GeneratedClassClosure.unit inferInstance)

theorem singleton_generated (D : CountablyBasedDIDomain.{u})
    (hD : SingletonClass D) : GeneratedClass D = SingletonClass := by
  funext E
  apply propext
  refine ⟨fun h => h SingletonClass singleton_admissible hD, ?_⟩
  intro hE P hP hPD
  have hUnit := GeneratedClassClosure.unitMem P hP.2.2 D hPD
  exact (replete_iff P).mp hP.1
    (GeneratedClassClosure.unitIsoOfSubsingleton E (singleton_subsingleton E hE)) hUnit

theorem finite_omega_not_single_generated : FiniteOmegaNotSingleGeneratedStatement.{u} := by
  rintro ⟨D, hD⟩
  have hDF : Finite D := hD.2.1.2
  have hEq := generated_eq_of_isGeneratedBy D _ hD
  rcases subsingleton_or_nontrivial (Core D) with hSub | hNon
  · have hSingle := singleton_generated D (singleton_of_subsingleton D hSub)
    have hTwo : FiniteDomainCut Ordinal.omega0 FiniteOrderDomains.twoObject.{u} :=
      ⟨CandidateCutClosure.two_degree_le.trans_lt (Ordinal.nat_lt_omega0 2),
        CandidateCutClosure.two_finite⟩
    have hBad : SingletonClass FiniteOrderDomains.twoObject.{u} := by
      rw [← hSingle, hEq]
      exact hTwo
    exact FiniteOrderDomains.zero_ne_one ((singleton_subsingleton _ hBad).elim _ _)
  · have hFiniteEq := finite_generated D hNon hDF
    have hParamEq : parameter D = Ordinal.omega0 :=
      (Section01.classificationDistinct.1 _ _ (parameter_finite D hDF)
        ⟨(Ordinal.nat_lt_omega0 3).le, le_rfl⟩).mp (hFiniteEq.symm.trans hEq)
    exact (ne_of_lt (parameter_lt_omega D hDF)) hParamEq

theorem omega_le_bound : Ordinal.omega0.{u+1} ≤ firstUncountableBound.{u} := by
  apply le_of_lt
  apply Cardinal.card_le_iff.mp
  simp

/-- This witnesses the original range defect without changing its interface. -/
theorem above_bound_limit_generated :
    ∃ D : CountablyBasedDIDomain.{u}, IsGeneratedBy D (DomainCut aboveBoundLimit.{u}) := by
  obtain ⟨D, hDegree⟩ := Section02.degreeRealizability.1 firstUncountableBound.{u}
    (Or.inr ⟨two_le_bound, le_rfl⟩)
  have hN : Nontrivial (Core D) :=
    FinitePowerMembership.nontrivial_of_two_le_degree D (by rw [hDegree]; exact two_le_bound)
  have hNotFinite : ¬ Finite D := by
    intro hF
    letI : Finite (Core D) := hF
    have hSmall := FinitePowerMembership.finite_degree_lt_omega D
    rw [hDegree] at hSmall
    exact (not_lt_of_ge omega_le_bound) hSmall
  have hInf : Infinite D := not_finite_iff_infinite.mp hNotFinite
  have hEq : GeneratedClass D = DomainCut (firstUncountableBound.{u}+1) := by
    have h := infinite_generated D hN hInf
    simpa only [parameter, hDegree, max_eq_right two_le_bound] using h
  refine ⟨D, ?_⟩
  rw [domainCut_aboveBoundLimit_eq_successor, ← hEq]
  exact Section04.generatedCategoryWellDefined D

end DIDomainClassification.SingleGeneratorProof
