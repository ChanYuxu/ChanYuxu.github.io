import DIDomainClassification.Support.RootReplacementContext
import DIDomainClassification.Support.FiniteBasisEnumeration
import DIDomainClassification.Support.PointwiseScottMIC

/-!
Actual contextual finite-join-basis refinement. Every arbitrary input alphabet
is quantified. The newly constructed output is coded over ULift Nat by proved
injective tags on actual countable child nodes; source trees are NOT restricted
to that alphabet, nor is any coding/rank/refinement conclusion an assumption.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries CoherenceDegree Trees TreeGrafting FiniteLeafColourPruning

variable {D : Type u} [PartialOrder D] (hD : IsScottDomain D)

/-- One genuine root step: finite decomposition, same-rank colour pruning,
then actual nonempty finite chain replacement. All non-root labels were
already in the basis; the constructed result has EVERY label in the basis. -/
theorem contextual_basis_root {A : Type v} (B : Set D) (hB : IsFiniteJoinBasis B)
    (T : RootedPrefixTree A) (hroot : T.rootList = []) (hT : T.IsWellFounded)
    (marker : A) (W : Set D) (label : T.Node → ↥(CompactElements D))
    (hC : IsContextualMicTree hD T W label)
    (hNonroot : ∀ x : T.Node, x ≠ T.root → (label x : D) ∈ B) :
    ∃ (R : RootedPrefixTree A) (hR : R.IsWellFounded)
      (newLabel : R.Node → ↥(CompactElements D)),
      R.rootList = [] ∧ IsContextualMicTree hD R W newLabel ∧
      (∀ x, (newLabel x : D) ∈ B) ∧ T.treeRank hT ≤ R.treeRank hR := by
  classical
  obtain ⟨F, hFfin, hFB, hFlub⟩ := hB.2 (label T.root : D) (label T.root).property
  obtain ⟨C, S, hsub, hS, hCfin, hCF, hCne, hSroot, hSrank, hLeaves⟩ :=
    contextual_uniform_root_replacement hD T hT hC F hFfin hFlub
  let f := inclusionNodeMap T S hsub
  let oldLabel : S.Node → ↥(CompactElements D) := fun x => label (f x)
  have hS0 : S.rootList = [] := hSroot.trans hroot
  have hOld : IsContextualMicTree hD S W oldLabel :=
    contextual_pruned hD T hC S hsub hSroot (fun x hx => (hLeaves x hx).1)
  have hfInj : Function.Injective f := by
    intro x y hxy
    exact Subtype.ext (congrArg (fun x : T.Node => x.val) hxy)
  have hfRoot : f S.root = T.root := inclusionNodeMap_root T S hsub hSroot
  have hOldBasis : ∀ x : S.Node, x ≠ S.root → (oldLabel x : D) ∈ B := by
    intro x hx
    apply hNonroot
    intro hfx
    exact hx (hfInj (hfx.trans hfRoot.symm))
  have hCC : C ⊆ CompactElements D := fun x hx => hB.1 (hFB (hCF hx))
  obtain ⟨n, e, heInj, heRange⟩ := finite_compact_enumeration_succ C hCfin hCne hCC
  have heBasis : ∀ i, (e i : D) ∈ B := fun i => hFB (hCF (heRange.subset ⟨i, rfl⟩))
  have hData : RootReplacementLeafData hD S W oldLabel (Set.range (fun i => (e i : D))) := by
    intro leaf hleaf
    refine ⟨?_, ?_, ?_, ?_⟩
    · intro x hx y hy hxy
      exact hOld.2.2.2.1 leaf hx.1 hy.1 hxy
    · intro x _hx
      exact hOld.2.2.1 x
    · rw [heRange, tailLabelImage_pruned hD T hC S hsub hSroot leaf]
      exact (hLeaves leaf hleaf).2.1
    · rw [heRange, tailLabelImage_pruned hD T hC S hsub hSroot leaf]
      exact (hLeaves leaf hleaf).2.2
  obtain ⟨newLabel, hNew, hAllBasis⟩ := root_replacement_chain hD S hS0 hS marker
    oldLabel B hOldBasis n e heInj heBasis W hC.1 hC.2.1 hData
  refine ⟨rootExpansion S hS0 marker n, rootExpansion_isWellFounded S hS0 marker hS n,
    newLabel, rootExpansion_rootList S hS0 marker n, hNew, hAllBasis, ?_⟩
  exact hSrank.symm.le.trans (rootExpansion_treeRank_ge S hS0 marker hS n)

/-- Full source-tree coverage: all arbitrary relative-prefix input trees and
compact contexts are handled by actual rank induction. The output coding,
WF/context conditions and rank bound are proved, not input proxy fields. -/
theorem finiteJoinBasis_refinement (B : Set D) (hB : IsFiniteJoinBasis B)
    {Index : Type v} (T : RootedPrefixTree Index) (hT : T.IsWellFounded)
    (W : Set D) (label : T.Node → ↥(CompactElements D))
    (hC : IsContextualMicTree hD T W label) :
    ∃ (S : RootedPrefixTree (ULift.{v} ℕ)) (hS : S.IsWellFounded)
      (newLabel : S.Node → ↥(CompactElements D)),
      S.rootList = [] ∧ IsContextualMicTree hD S W newLabel ∧
      (∀ x, (newLabel x : D) ∈ B) ∧ T.treeRank hT ≤ S.treeRank hS := by
  classical
  have main : ∀ α : Ordinal.{v}, ∀ (Index : Type v) (T : RootedPrefixTree Index)
      (hT : T.IsWellFounded) (W : Set D) (label : T.Node → ↥(CompactElements D)),
      T.treeRank hT = α → IsContextualMicTree hD T W label →
      ∃ (S : RootedPrefixTree (ULift.{v} ℕ)) (hS : S.IsWellFounded)
        (newLabel : S.Node → ↥(CompactElements D)),
        S.rootList = [] ∧ IsContextualMicTree hD S W newLabel ∧
        (∀ x, (newLabel x : D) ∈ B) ∧ T.treeRank hT ≤ S.treeRank hS := by
    intro α
    refine WellFoundedLT.induction (motive := fun α : Ordinal.{v} =>
      ∀ (Index : Type v) (T : RootedPrefixTree Index) (hT : T.IsWellFounded)
        (W : Set D) (label : T.Node → ↥(CompactElements D)),
        T.treeRank hT = α → IsContextualMicTree hD T W label →
        ∃ (S : RootedPrefixTree (ULift.{v} ℕ)) (hS : S.IsWellFounded)
          (newLabel : S.Node → ↥(CompactElements D)),
          S.rootList = [] ∧ IsContextualMicTree hD S W newLabel ∧
          (∀ x, (newLabel x : D) ∈ B) ∧ T.treeRank hT ≤ S.treeRank hS) α ?_
    intro α ih Index T hT W label hRank hContext
    let Children := {x : T.Node // T.IsChild T.root x}
    let a := label T.root
    let Wchild : Set D := W ∪ {(a : D)}
    have hChildWF (i : Children) : (above T i.val).IsWellFounded := above_isWellFounded T hT i.val
    have hChildContext (i : Children) :
        IsContextualMicTree hD (above T i.val) Wchild (childLabel T label i.val) :=
      contextual_child hD T hContext i.property
    have hRec (i : Children) :
        ∃ (S : RootedPrefixTree (ULift.{v} ℕ)) (hS : S.IsWellFounded)
          (newLabel : S.Node → ↥(CompactElements D)),
          S.rootList = [] ∧ IsContextualMicTree hD S Wchild newLabel ∧
          (∀ x, (newLabel x : D) ∈ B) ∧
          (above T i.val).treeRank (hChildWF i) ≤ S.treeRank hS := by
      apply ih ((above T i.val).treeRank (hChildWF i))
        ((child_subtree_rank_lt T hT i.property).trans_eq hRank)
        Index (above T i.val) (hChildWF i) Wchild (childLabel T label i.val) rfl (hChildContext i)
    choose S hS labels roots contexts bases ranks using hRec
    let tags : Children → ULift.{v} ℕ := countableTag Children
    have hTags : Function.Injective tags := countableTag_injective Children
    let F := forest S tags roots
    have hF : F.IsWellFounded := forest_isWellFounded S tags roots hTags hS
    let L := forestLabel S tags roots a labels
    have hFContext : IsContextualMicTree hD F W L := by
      apply contextual_forest S tags roots hD hTags a W labels hContext.1 hContext.2.1
        (hContext.2.2.1 T.root) contexts
      intro hEmpty
      exact contextual_root_mic_of_no_children hD T hContext hEmpty
    have hNonroot : ∀ x : F.Node, x ≠ F.root → (L x : D) ∈ B :=
      fun x hx => forestLabel_nonroot_basis S tags roots hTags a labels B bases x hx
    have hTtoF : T.treeRank hT ≤ F.treeRank hF := by
      apply forest_rank_dominates Index T hT S tags roots hTags hS
      intro i
      have h := ranks i
      rw [above_treeRank_eq] at h
      exact h
    obtain ⟨R, hR, newLabel, hRroot, hRcontext, hRBasis, hFtoR⟩ :=
      contextual_basis_root hD B hB F rfl hF (⟨0⟩ : ULift.{v} ℕ) W L hFContext hNonroot
    exact ⟨R, hR, newLabel, hRroot, hRcontext, hRBasis, hTtoF.trans hFtoR⟩
  exact main (T.treeRank hT) Index T hT W label rfl hC

end DIDomainClassification.PointwiseFunctionSupport
