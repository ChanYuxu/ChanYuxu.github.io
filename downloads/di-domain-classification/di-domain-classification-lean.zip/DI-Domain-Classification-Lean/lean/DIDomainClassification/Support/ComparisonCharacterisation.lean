import DIDomainClassification.Section04.ComparisonCore

/-! The two directions of the source comparison criterion. The forward
direction uses the actual Scott split and function-degree upper bound. The
reverse direction uses the literal stable exponential from the two-point
chain, genuine constant/evaluation maps, and the proved comparison core. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonCharacterisation
open Preliminaries CoherenceDegree Subcategories Section04
open Section03.StableFunctionModels

theorem two_nontrivial : Nontrivial (Core FiniteOrderDomains.twoObject.{u}) :=
  ⟨⟨FiniteOrderDomains.zero, FiniteOrderDomains.one, FiniteOrderDomains.zero_ne_one⟩⟩

theorem two_twoCoherent :
    IsNCoherent (Core FiniteOrderDomains.twoObject.{u}).isDIDomain.toIsScottDomain
      2 (by decide) := by
  intro M hM
  exact False.elim (hM.2.1 ⟨FiniteOrderDomains.one, fun x _hx => FiniteOrderDomains.le_one x⟩)

theorem function_nontrivial (E : CountablyBasedDIDomain.{u}) (hE : Nontrivial (Core E)) :
    Nontrivial (Core (exponential FiniteOrderDomains.twoObject E)) := by
  obtain ⟨x, y, hxy⟩ := hE.exists_pair_ne
  refine ⟨⟨FunctionDegreeHelpers.constantEmbedding FiniteOrderDomains.twoObject E x,
    FunctionDegreeHelpers.constantEmbedding FiniteOrderDomains.twoObject E y, ?_⟩⟩
  intro h
  exact hxy (congrArg
    (fun f : Core (exponential FiniteOrderDomains.twoObject E) => f FiniteOrderDomains.zero) h)

theorem degree_bound (D E : CountablyBasedDIDomain.{u}) (h : StableComparison D E) :
    objectDegree D ≤ max 2 (objectDegree E) := by
  obtain ⟨H, _hH, s, r, hLeft⟩ := h
  have hMono : objectDegree D ≤ objectDegree (exponential H E) := by
    apply Section02.bps.1 (Core D) (Core (exponential H E))
      (Core D).isDIDomain.toIsScottDomain (Core (exponential H E)).isDIDomain.toIsScottDomain
      D.countableCompacts (exponential H E).countableCompacts
    exact ⟨s, r, (StableHom.isStable s).1, (StableHom.isStable r).1, hLeft⟩
  exact hMono.trans (Section03.functionDegreeUpper H E)

theorem of_degree_bound (D E : CountablyBasedDIDomain.{u}) (hE : Nontrivial (Core E))
    (h : objectDegree D ≤ max 2 (objectDegree E)) : StableComparison D E := by
  let T : CountablyBasedDIDomain.{u} := FiniteOrderDomains.twoObject
  let F := exponential T E
  have hF : Nontrivial (Core F) := function_nontrivial E hE
  have hFdegree : objectDegree F = max 2 (objectDegree E) :=
    Section03.functionDegreeNontrivial T E two_nontrivial hE
  have hDF : StableComparison D F := comparisonCore D F hF (h.trans_eq hFdegree.symm)
  have hFE : StableComparison F E :=
    ⟨T, two_twoCoherent, StableHom.id _, StableHom.id _, fun _ => rfl⟩
  exact comparisonTransitivity D F E hDF hFE

end DIDomainClassification.ComparisonCharacterisation
