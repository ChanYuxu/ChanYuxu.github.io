import DIDomainClassification.Support.ProductMicTrees

/-!
Generic degree equality for literal dependent products of raw Scott domains.
The coordinate MIC tree is actually constructed by finite root-support leaf
pruning and actual compact projection; no product degree theorem is assumed.
The public source BPSStatement wrapper/claim remains the coordinator's scope.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.BPSProductDegree

open Preliminaries CoherenceDegree

variable {I : Type u} {D : I → Type u} [∀ i, PartialOrder (D i)]

theorem product_tree_contribution_le_iSup (hD : ∀ i, IsScottDomain (D i))
    {Index : Type u} (M : MicTree (∀ i, D i) (productScottDomain hD) Index)
    (hM : M.tree.IsWellFounded) :
    Ordinal.lift.{u+1} (M.tree.treeRank hM + 1) ≤ ⨆ i, coherenceDegree (hD i) := by
  obtain ⟨i, N, hN, _hRoot, _hNodes, hRank⟩ := exists_coordinate_mic_tree hD M hM
  have h := treeRank_add_one_le_coherenceDegree (hD i) N hN
  rw [hRank] at h
  exact h.trans (Ordinal.le_iSup (fun i => coherenceDegree (hD i)) i)

theorem product_coherenceDegree_le (hD : ∀ i, IsScottDomain (D i)) :
    coherenceDegree (productScottDomain hD) ≤ ⨆ i, coherenceDegree (hD i) := by
  apply (coherenceDegree_le_iff (productScottDomain hD) _).2
  intro Index M hM
  exact product_tree_contribution_le_iSup hD M hM

/-- The generic equality itself does not need countability/nonemptiness of I.
The accepted separable nonempty countable case follows using the separately
proved actual compact-set countability, without counting all product points.
-/
theorem product_coherenceDegree_eq (hD : ∀ i, IsScottDomain (D i)) :
    coherenceDegree (productScottDomain hD) = ⨆ i, coherenceDegree (hD i) :=
  le_antisymm (product_coherenceDegree_le hD) (iSup_factor_coherenceDegree_le hD)

end DIDomainClassification.BPSProductDegree
