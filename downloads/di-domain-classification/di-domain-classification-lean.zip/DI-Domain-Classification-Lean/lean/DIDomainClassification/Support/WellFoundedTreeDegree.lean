import DIDomainClassification.Support.SingletonBranchMaps
import DIDomainClassification.Support.BranchRankComparison

/-!
Actual WF TreeDomain degree. The upper bound uses the genuinely proved branch-
set rank comparison; it never assumes that the singleton node map preserves
roots or order. The public BPS source wrapper remains coordinator-owned.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TreeDomainDegree

open Preliminaries CoherenceDegree Trees

variable {Index : Type u} (T : RootedPrefixTree Index) (hp : T.IsProper)

theorem wellFounded_degree_upper (hT : T.IsWellFounded) :
    coherenceDegree (treeScottDomain T hp) ≤ Ordinal.lift.{u+1} (T.treeRank hT + 1) := by
  apply (coherenceDegree_le_iff (treeScottDomain T hp) _).2
  intro J M hM
  obtain ⟨R, hR, _hProper, f, hRank, hMaps, hInj⟩ := exists_branch_map_refinement T hp M hM
  have hFiniteInj : BranchRankComparison.InjectiveOnBranches R T f := by
    intro c hc
    exact hInj c (hc.isBranch R)
  have hRT : R.treeRank hR ≤ T.treeRank hT :=
    BranchRankComparison.treeRank_le_of_branch_maps R hR T hT f hMaps hFiniteInj
  exact Ordinal.lift_le.mpr (add_le_add (hRank.trans hRT) (le_rfl : (1 : Ordinal.{u}) ≤ 1))

theorem wellFounded_treeDomain_degree_eq (hT : T.IsWellFounded) :
    coherenceDegree (treeScottDomain T hp) = Ordinal.lift.{u+1} (T.treeRank hT + 1) :=
  le_antisymm (wellFounded_degree_upper T hp hT) (wellFounded_degree_lower T hp hT)

end DIDomainClassification.TreeDomainDegree
