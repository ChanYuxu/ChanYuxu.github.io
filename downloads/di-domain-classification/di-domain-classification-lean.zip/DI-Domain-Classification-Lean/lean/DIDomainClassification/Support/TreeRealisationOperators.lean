import DIDomainClassification.Support.TreeRealisationSectionMaps

/-! Actual higher-order stable section/retraction. Both Scott continuity
proofs use the native stable Hom order and its proved pointwise directed LUBs. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeRealisationOperators

open Preliminaries EventStructures Trees OrderCore
open Section04 Section04.TreeRealisationModels Section04.AdditionalSourceModels
open TreeRealisationGeometry TreeRealisationConfigurations TreeRealisationSectionMaps

variable {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A)
  {B : Type v} (T : RootedPrefixTree B) (L : T.Node → Set A)
  (hL : BlockCondition T E L) (hp : T.IsProper)

def sourceCore : DIDomainObject.{v} := treeCore T (treeCountablyBased T hp).1

def targetCore : DIDomainObject.{max u v} :=
  functionCore (completionCore T hp) (causalConfigurationCore E)

abbrev NativeHom := StableHom (completionCore T hp) (causalConfigurationCore E)

def asHom (f : targetCore E T hp) : NativeHom E T hp := f

include hL

theorem section_scottContinuous : ScottContinuous (sectionFunction E T L hL hp) := by
  intro C hne hdir X hX
  have hC : DirectedSet C := ⟨hne, hdir⟩
  have hImage := hC.image (section_monotone E T L hL hp)
  apply (StableHomPointwiseSupport.hom_isLUB_iff_values _ hImage _).mpr
  intro z
  apply configuration_isLUB_of_values E _ _
  rw [section_union_values E T L hL hp C hne X hX z]
  ext a
  constructor
  · rintro ⟨Y, hY, ha⟩
    exact ⟨sectionFunction E T L hL hp Y z,
      ⟨sectionFunction E T L hL hp Y, ⟨Y, hY, rfl⟩, rfl⟩, ha⟩
  · rintro ⟨Z, ⟨f, ⟨Y, hY, rfl⟩, rfl⟩, ha⟩
    exact ⟨Y, hY, ha⟩

theorem section_preservesInf (X Y : sourceCore T hp) (hXY : Compatible X Y) :
    sectionFunction E T L hL hp (X ⊓ Y : sourceCore T hp) =
      (sectionFunction E T L hL hp X ⊓ sectionFunction E T L hL hp Y : targetCore E T hp) := by
  obtain ⟨Z, hXZ, hYZ⟩ := hXY
  have hComp : Compatible (sectionFunction E T L hL hp X) (sectionFunction E T L hL hp Y) :=
    ⟨sectionFunction E T L hL hp Z, section_monotone E T L hL hp hXZ,
      section_monotone E T L hL hp hYZ⟩
  have hValues := (StableHomPointwiseSupport.hom_isGLB_pair_iff_values
    (sectionFunction E T L hL hp X) (sectionFunction E T L hL hp Y) hComp _).mp
    (DIDomainObject.inf_isGLB (targetCore E T hp)
      (sectionFunction E T L hL hp X) (sectionFunction E T L hL hp Y))
  apply StableHom.ext
  intro z
  apply Subtype.ext
  change (sectionFunction E T L hL hp ((treeCountablyBased T hp).1.toIsScottDomain.inf X Y) z).val =
    (asHom E T hp
      (sectionFunction E T L hL hp X ⊓ sectionFunction E T L hL hp Y : targetCore E T hp) z).val
  have hValue : asHom E T hp
      (sectionFunction E T L hL hp X ⊓ sectionFunction E T L hL hp Y : targetCore E T hp) z =
      sectionFunction E T L hL hp X z ⊓ sectionFunction E T L hL hp Y z := hValues z
  rw [hValue, CausalCoverSupport.configuration_inf_val]
  exact section_inter_values E T L hL hp (treeCountablyBased T hp).1 X Y z

def stableSection : StableHom (sourceCore T hp) (targetCore E T hp) :=
  StableHom.ofFunction (sectionFunction E T L hL hp)
    ⟨section_scottContinuous E T L hL hp, section_preservesInf E T L hL hp⟩

def retractionValues (f : NativeHom E T hp) : Set T.Node :=
  {z | L z ⊆ (f (BranchCompletion.finite T hp z)).val}

def retraction (f : NativeHom E T hp) : TreeDomain T := ⟨retractionValues E T L hp f, by
  intro c hc hCR
  have hForbidden := (hL.2 c hc).2
  obtain ⟨leaf, _hLeaf, rfl⟩ := hc
  apply CausalCoverSupport.configuration_avoids E (f (BranchCompletion.finite T hp leaf)) _ hForbidden
  intro a ha
  obtain ⟨z, haz⟩ := Set.mem_iUnion.mp ha
  obtain ⟨hz, haL⟩ := Set.mem_iUnion.mp haz
  have hzR : L z ⊆ (f (BranchCompletion.finite T hp z)).val := hCR hz
  have hle : BranchCompletion.finite T hp z ≤ BranchCompletion.finite T hp leaf :=
    (BranchCompletion.finite_order T hp z leaf).mpr hz
  exact (StableHom.isStable f).1.monotone hle (hzR haL)⟩

theorem retraction_monotone : Monotone (retraction E T L hL hp) := by
  intro f g hfg z hz a ha
  exact StableHomPointwiseSupport.stableLE_pointwise hfg
    (BranchCompletion.finite T hp z) (hz ha)

theorem retraction_scottContinuous : ScottContinuous (retraction E T L hL hp) := by
  intro C hne hdir f hf
  have hC : DirectedSet C := ⟨hne, hdir⟩
  constructor
  · rintro _ ⟨g, hg, rfl⟩
    exact retraction_monotone E T L hL hp (hf.1 hg)
  · intro X hX z hz
    change L z ⊆ (f (BranchCompletion.finite T hp z)).val at hz
    let G : Set (Configuration E) :=
      (fun g : NativeHom E T hp => g (BranchCompletion.finite T hp z)) '' C
    have hEvalMono : Monotone (fun g : NativeHom E T hp => g (BranchCompletion.finite T hp z)) :=
      fun _ _ h => StableHomPointwiseSupport.stableLE_pointwise h _
    have hG : DirectedSet G := hC.image hEvalMono
    have hEval : IsLUB G (f (BranchCompletion.finite T hp z)) :=
      (StableHomPointwiseSupport.hom_isLUB_iff_values C hC f).mp hf _
    have hValues := configuration_directedLUB_values E G hG _ hEval
    have hSub : L z ⊆ ⋃ Y ∈ G, Y.val := by
      intro a ha
      obtain ⟨Y, hY, haY⟩ := hValues.subset (hz ha)
      exact Set.mem_iUnion.mpr ⟨Y, Set.mem_iUnion.mpr ⟨hY, haY⟩⟩
    obtain ⟨Y, hY, hLY⟩ := Configuration.finite_subset_directed_union hG (hL.1 z).1 hSub
    obtain ⟨g, hg, rfl⟩ := hY
    exact hX ⟨g, hg, rfl⟩ hLY

theorem retraction_preservesInf (f g : NativeHom E T hp) (hfg : Compatible f g) :
    retraction E T L hL hp (f ⊓ g : targetCore E T hp) =
      (retraction E T L hL hp f ⊓ retraction E T L hL hp g : sourceCore T hp) := by
  have hValues := (StableHomPointwiseSupport.hom_isGLB_pair_iff_values f g hfg _).mp
    (DIDomainObject.inf_isGLB (targetCore E T hp) f g)
  apply Subtype.ext
  change retractionValues E T L hp (f ⊓ g : targetCore E T hp) =
    ((treeCountablyBased T hp).1.toIsScottDomain.inf
      (retraction E T L hL hp f) (retraction E T L hL hp g)).val
  rw [tree_inf_values T (treeCountablyBased T hp).1
    (retraction E T L hL hp f) (retraction E T L hL hp g)]
  ext z
  change (L z ⊆ (asHom E T hp (f ⊓ g : targetCore E T hp)
    (BranchCompletion.finite T hp z)).val) ↔
    ((L z ⊆ (f (BranchCompletion.finite T hp z)).val) ∧
      (L z ⊆ (g (BranchCompletion.finite T hp z)).val))
  have hValue : asHom E T hp (f ⊓ g : targetCore E T hp) (BranchCompletion.finite T hp z) =
      f (BranchCompletion.finite T hp z) ⊓ g (BranchCompletion.finite T hp z) := hValues _
  rw [hValue, CausalCoverSupport.configuration_inf_val]
  exact Set.subset_inter_iff

def stableRetraction : StableHom (targetCore E T hp) (sourceCore T hp) :=
  StableHom.ofFunction (retraction E T L hL hp)
    ⟨retraction_scottContinuous E T L hL hp, retraction_preservesInf E T L hL hp⟩

theorem leftInverse : Function.LeftInverse (retraction E T L hL hp)
    (sectionFunction E T L hL hp) := by
  intro X
  apply Subtype.ext
  ext z
  change (L z ⊆ (sectionFunction E T L hL hp X (BranchCompletion.finite T hp z)).val) ↔ z ∈ X.val
  rw [section_finite]
  exact label_subset_section_iff T L E hL hp X.val z

end DIDomainClassification.TreeRealisationOperators
