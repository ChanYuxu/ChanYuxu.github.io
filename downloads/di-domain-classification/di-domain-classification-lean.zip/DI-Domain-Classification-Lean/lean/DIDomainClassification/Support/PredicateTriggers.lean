import DIDomainClassification.Section04.PredicatesStatement
import DIDomainClassification.Section02.CompactPredecessors
import Mathlib.Order.Preorder.Finite

/-! Minimal compact triggers for the literal stable predicates into two. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.PredicateTriggers
open OrderCore Preliminaries CoherenceDegree FiniteOrderDomains
open Section03.StableFunctionModels
open Section04.PredicateModels Section02.BinaryCliqueModels

variable (D : CountablyBasedDIDomain.{u})

theorem one_le_iff (a : TwoCarrier.{u}) : one ≤ a ↔ a = one :=
  ⟨fun h => le_antisymm (le_one a) h, fun h => h.symm.le⟩

theorem not_one_iff_zero (a : TwoCarrier.{u}) : a ≠ one ↔ a = zero := by
  rcases eq_zero_or_one a with rfl | rfl
  · exact ⟨fun _ => rfl, fun _ => zero_ne_one⟩
  · exact ⟨fun h => False.elim (h rfl), fun h => False.elim (zero_ne_one h.symm)⟩

theorem exists_compact_one (f : StableSpace D twoObject.{u})
    (x : Core D) (hx : f x = one) :
    ∃ c : Core D, IsCompactElement c ∧ c ≤ x ∧ f c = one := by
  have hK := D.toDIDomainObject.isDIDomain.toIsScottDomain.algebraic.2 x
  have hdir := hK.1.image (StableHom.isStable f).1.monotone
  have hsup := OrderCore.scottContinuous_isSup (StableHom.isStable f).1 hK.1 hK.2
  have hOne : IsCompactElement (one : Core twoObject.{u}) :=
    finite_isCompact one
  obtain ⟨_, ⟨c, hc, rfl⟩, hfc⟩ :=
    hOne hdir hsup (show one ≤ f x by rw [hx])
  exact ⟨c, hc.1, hc.2, (one_le_iff _).mp hfc⟩

theorem reconstruct (f : StableSpace D twoObject.{u}) (x : Core D) :
    f x = one ↔ ∃ k ∈ minimalTriggers D f, k.val ≤ x := by
  constructor
  · intro hx
    obtain ⟨c, hc, hcx, hfc⟩ := exists_compact_one D f x hx
    let S : Set (Core D) := {y | y ≤ c ∧ f y = one}
    have hS : S.Finite :=
      (D.toDIDomainObject.isDIDomain.finitePrincipalIdeals c hc).subset
        (fun _ hy => hy.1)
    obtain ⟨k, hk⟩ := hS.exists_minimal ⟨c, le_rfl, hfc⟩
    refine ⟨⟨k, Section02.compactBelowCompact (Core D)
      D.toDIDomainObject.isDIDomain k c hk.1.1 hc⟩, ⟨hk.1.2, ?_⟩,
      hk.1.1.trans hcx⟩
    intro l hl
    apply (not_one_iff_zero _).mp
    intro hfl
    exact (not_le_of_gt hl) (hk.2 ⟨hl.le.trans hk.1.1, hfl⟩ hl.le)
  · rintro ⟨k, hk, hkx⟩
    apply (one_le_iff _).mp
    simpa only [hk.1] using (StableHom.isStable f).1.monotone hkx

theorem trigger_eq_of_le (f : StableSpace D twoObject.{u})
    {k : ↥(CompactElements (Core D))} (hk : k ∈ minimalTriggers D f)
    {x : Core D} (hxk : x ≤ k.val) (hfx : f x = one) : x = k.val := by
  by_contra hne
  have hzero := hk.2 x (lt_of_le_of_ne hxk hne)
  exact zero_ne_one (hzero.symm.trans hfx)

theorem triggers_eq_of_compatible (f : StableSpace D twoObject.{u})
    {k l : ↥(CompactElements (Core D))}
    (hk : k ∈ minimalTriggers D f) (hl : l ∈ minimalTriggers D f)
    (hkl : Compatible k.val l.val) : k = l := by
  have hm : f (k.val ⊓ l.val) = one := by
    rw [(StableHom.isStable f).2 _ _ hkl, hk.1, hl.1, inf_idem]
  have hmk := trigger_eq_of_le D f hk inf_le_left hm
  have hml := trigger_eq_of_le D f hl inf_le_right hm
  exact Subtype.ext (hmk.symm.trans hml)

theorem triggers_isClique (f : StableSpace D twoObject.{u}) :
    (graph D).IsClique (minimalTriggers D f) := by
  intro k hk l hl hne
  exact ⟨hne, fun hkl => hne (triggers_eq_of_compatible D f hk hl hkl)⟩

def triggerClique (f : StableSpace D twoObject.{u}) : CliqueCarrier (graph D) :=
  ⟨minimalTriggers D f, triggers_isClique D f⟩

theorem clique_eq_of_compatible (M : CliqueCarrier (graph D))
    {k l : ↥(CompactElements (Core D))} (hk : k ∈ M.val) (hl : l ∈ M.val)
    (hkl : Compatible k.val l.val) : k = l := by
  by_contra hne
  exact (M.property hk hl hne).2 hkl

end DIDomainClassification.PredicateTriggers
