import DIDomainClassification.Support.LeafClassSubtree

/-!
Finite, possibly overlapping leaf classes preserve the exact ordinal rank
in an actual same-root prefix subtree, without creating any new leaf.
Generic supporting mathematics, not a source BPS wrapper or acceptance.
The finite maximum is taken only over classes occurring BELOW THE CURRENT
NODE; that local class type is proved nonempty by genuine WF leaf extension.
No finite-branching, nontrivial-tree or countable-alphabet assumption.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.FiniteLeafColourPruning

open Trees

variable {Index : Type u} {Colour : Type v}

abbrev NodeColour (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (x : T.Node) : Type v := {i : Colour // ReachesClass T L i x.val}

theorem nodeColour_nonempty (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (hT : T.IsWellFounded) (hcover : ∀ leaf : T.Node, T.IsLeaf leaf → ∃ i, leaf ∈ L i)
    (x : T.Node) : Nonempty (NodeColour T L x) := by
  obtain ⟨leaf, hleaf, hxleaf⟩ := exists_leaf_extension T hT x
  obtain ⟨i, hi⟩ := hcover leaf hleaf
  exact ⟨⟨i, leaf, hleaf, hi, hxleaf⟩⟩

def rootReach (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (x : T.Node) (i : NodeColour T L x) : ReachesClass T L i.val T.rootList :=
  reachesClass_of_prefix T L i.val (T.root_prefix x.property) i.property

def colourRank (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (hT : T.IsWellFounded) (x : T.Node) (i : NodeColour T L x) : Ordinal.{u} :=
  (classTree T L i.val (rootReach T L x i)).nodeRank
    (classTree_isWellFounded T L i.val (rootReach T L x i) hT)
    (embedNode T L i.val (rootReach T L x i) x i.property)

theorem colourRank_le (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (hT : T.IsWellFounded) (x : T.Node) (i : NodeColour T L x) :
    colourRank T L hT x i ≤ T.nodeRank hT x :=
  classTree_nodeRank_le T L i.val (rootReach T L x i) hT
    (embedNode T L i.val (rootReach T L x i) x i.property)

def parentColour (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    {x y : T.Node} (hxy : T.IsChild x y) (i : NodeColour T L y) : NodeColour T L x :=
  ⟨i.val, reachesClass_of_prefix T L i.val hxy.1 i.property⟩

theorem colourRank_child_add_one_le (T : RootedPrefixTree Index)
    (L : Colour → Set T.Node) (hT : T.IsWellFounded) {x y : T.Node}
    (hxy : T.IsChild x y) (i : NodeColour T L y) :
    colourRank T L hT y i + 1 ≤ colourRank T L hT x (parentColour T L hxy i) := by
  apply nodeRank_add_one_le_of_child
    (classTree T L i.val (rootReach T L y i))
    (classTree_isWellFounded T L i.val (rootReach T L y i) hT)
  exact ⟨hxy.1, hxy.2⟩

/-- Finite local colour ranks attain a maximum, even at a one-node tree.
The induction takes the child-successor supremum only in the actual source
rank; no infinite-colour ordinal supremum is assumed to attain a maximum. -/
theorem exists_colour_rank_eq (T : RootedPrefixTree Index)
    (L : Colour → Set T.Node) [Finite Colour] (hT : T.IsWellFounded)
    (hcover : ∀ leaf : T.Node, T.IsLeaf leaf → ∃ i, leaf ∈ L i) (x : T.Node) :
    ∃ i : NodeColour T L x, T.nodeRank hT x = colourRank T L hT x i := by
  classical
  refine (T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).induction
    (C := fun x : T.Node =>
      ∃ i : NodeColour T L x, T.nodeRank hT x = colourRank T L hT x i) x ?_
  intro x ih
  letI : Nonempty (NodeColour T L x) := nodeColour_nonempty T L hT hcover x
  obtain ⟨i, _hi, hmax⟩ := Set.exists_max_image (Set.univ : Set (NodeColour T L x))
    (colourRank T L hT x) Set.finite_univ Set.univ_nonempty
  refine ⟨i, le_antisymm ?_ (colourRank_le T L hT x i)⟩
  rw [T.nodeRank_eq hT x]
  apply Ordinal.iSup_le
  intro y
  obtain ⟨j, hj⟩ := ih y.val y.property
  calc
    T.nodeRank hT y.val + 1 = colourRank T L hT y.val j + 1 := congrArg (· + 1) hj
    _ ≤ colourRank T L hT x (parentColour T L y.property j) :=
      colourRank_child_add_one_le T L hT y.property j
    _ ≤ colourRank T L hT x i := hmax _ (Set.mem_univ _)

/-- The inclusion used by the final existential contract is identical on lists. -/
def inclusionNodeMap (T S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
    (x : S.Node) : T.Node := ⟨x.val, hsub x.property⟩

theorem inclusionNodeMap_val (T S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
    (x : S.Node) : (inclusionNodeMap T S hsub x).val = x.val := rfl

theorem inclusionNodeMap_root (T S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
    (hroot : S.rootList = T.rootList) : inclusionNodeMap T S hsub S.root = T.root :=
  Subtype.ext hroot

theorem inclusionNodeMap_isChild_iff (T S : RootedPrefixTree Index)
    (hsub : S.nodes ⊆ T.nodes) (hroot : S.rootList = T.rootList) (x y : S.Node) :
    T.IsChild (inclusionNodeMap T S hsub x) (inclusionNodeMap T S hsub y) ↔
      S.IsChild x y := by
  change (x.val <+: y.val ∧ y.val.length - T.rootList.length =
    x.val.length - T.rootList.length + 1) ↔
    (x.val <+: y.val ∧ y.val.length - S.rootList.length =
      x.val.length - S.rootList.length + 1)
  rw [hroot]

/-- Same-root relative prefix closure retains the ENTIRE original path to
each retained endpoint, with the literal identity-on-list inclusion. -/
theorem inclusionNodeMap_pathTo (T S : RootedPrefixTree Index)
    (hsub : S.nodes ⊆ T.nodes) (hroot : S.rootList = T.rootList) (x : S.Node) :
    inclusionNodeMap T S hsub '' S.pathTo x =
      T.pathTo (inclusionNodeMap T S hsub x) := by
  ext y
  constructor
  · rintro ⟨z, hzx, rfl⟩
    exact hzx
  · intro hy
    have hrooty : S.rootList <+: y.val := by
      rw [hroot]
      exact T.root_prefix y.property
    have hyS : y.val ∈ S.nodes := S.prefix_closed hrooty hy x.property
    exact ⟨⟨y.val, hyS⟩, hy, rfl⟩

theorem inclusionNodeMap_finiteCompleteBranch (T S : RootedPrefixTree Index)
    (hsub : S.nodes ⊆ T.nodes) (hroot : S.rootList = T.rootList)
    (hleaf : ∀ x : S.Node, S.IsLeaf x → T.IsLeaf (inclusionNodeMap T S hsub x))
    (c : Set S.Node) (hc : S.IsFiniteCompleteBranch c) :
    T.IsFiniteCompleteBranch (inclusionNodeMap T S hsub '' c) := by
  obtain ⟨x, hx, rfl⟩ := hc
  exact ⟨inclusionNodeMap T S hsub x, hleaf x hx,
    inclusionNodeMap_pathTo T S hsub hroot x⟩

/-- A general WF same-root pruning with no new leaves preserves properness
when the original is proper; properness is NOT a hypothesis of pruning. -/
theorem isProper_of_no_new_leaves (T S : RootedPrefixTree Index)
    (hsub : S.nodes ⊆ T.nodes) (hroot : S.rootList = T.rootList)
    (hS : S.IsWellFounded)
    (hleaf : ∀ x : S.Node, S.IsLeaf x → T.IsLeaf (inclusionNodeMap T S hsub x))
    (hproper : T.IsProper) : S.IsProper := by
  have hnotleaf : ¬ S.IsLeaf S.root := by
    intro hrootLeaf
    have htleaf := hleaf S.root hrootLeaf
    rw [inclusionNodeMap_root T S hsub hroot] at htleaf
    letI : Nontrivial T.Node := hproper.1
    obtain ⟨x, hx⟩ := exists_ne T.root
    exact hx (htleaf x (T.root_le x))
  have hchild : ∃ x : S.Node, S.IsChild S.root x := by
    by_contra h
    exact hnotleaf ((S.isLeaf_iff_no_child S.root).mpr h)
  obtain ⟨x, hx⟩ := hchild
  have hne : x ≠ S.root := by
    intro heq
    exact S.isChild_irrefl S.root (heq ▸ hx)
  have hn : Nontrivial S.Node := ⟨⟨x, S.root, hne⟩⟩
  apply (S.isProper_iff).mpr
  refine ⟨hn, ?_⟩
  intro x
  obtain ⟨leaf, hleaf, hxleaf⟩ := exists_leaf_extension S hS x
  exact ⟨leaf, hleaf, hxleaf⟩

/-- BPS leaf-class pruning as genuine generic mathematics. The finite classes
may overlap, the alphabet may be arbitrary, and the original may be one node.
Both the WF proof and the exact rank equality are OUTPUTS, not hidden inputs. -/
theorem finite_leaf_class_pruning (T : RootedPrefixTree Index)
    (hT : T.IsWellFounded) (L : Colour → Set T.Node) [Finite Colour]
    (hcover : ∀ leaf : T.Node, T.IsLeaf leaf → ∃ i, leaf ∈ L i) :
    ∃ (i : Colour) (S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
      (hS : S.IsWellFounded),
      S.rootList = T.rootList ∧ S.treeRank hS = T.treeRank hT ∧
      (∀ leaf : S.Node, S.IsLeaf leaf →
        T.IsLeaf (inclusionNodeMap T S hsub leaf) ∧
          inclusionNodeMap T S hsub leaf ∈ L i) ∧
      (T.IsProper → S.IsProper) := by
  obtain ⟨i, hi⟩ := exists_colour_rank_eq T L hT hcover T.root
  let S := classTree T L i.val i.property
  let hsub : S.nodes ⊆ T.nodes := classTree_nodes_subset T L i.val i.property
  let hS : S.IsWellFounded := classTree_isWellFounded T L i.val i.property hT
  have hleaves : ∀ leaf : S.Node, S.IsLeaf leaf →
      T.IsLeaf (inclusionNodeMap T S hsub leaf) ∧
        inclusionNodeMap T S hsub leaf ∈ L i.val :=
    leaf_nodeMap T L i.val i.property
  refine ⟨i.val, S, hsub, hS, rfl, ?_, hleaves, ?_⟩
  · exact hi.symm
  · exact isProper_of_no_new_leaves T S hsub rfl hS (fun x hx => (hleaves x hx).1)

/-- The usual finite-colouring formulation, using only leaf values of colour. -/
theorem finite_leaf_colour_pruning (T : RootedPrefixTree Index)
    (hT : T.IsWellFounded) (colour : T.Node → Colour) [Finite Colour] :
    ∃ (i : Colour) (S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
      (hS : S.IsWellFounded),
      S.rootList = T.rootList ∧ S.treeRank hS = T.treeRank hT ∧
      (∀ leaf : S.Node, S.IsLeaf leaf →
        T.IsLeaf (inclusionNodeMap T S hsub leaf) ∧
          colour (inclusionNodeMap T S hsub leaf) = i) ∧
      (T.IsProper → S.IsProper) :=
  finite_leaf_class_pruning T hT (fun i => {leaf | colour leaf = i})
    (fun leaf _ => ⟨colour leaf, rfl⟩)

end DIDomainClassification.FiniteLeafColourPruning
