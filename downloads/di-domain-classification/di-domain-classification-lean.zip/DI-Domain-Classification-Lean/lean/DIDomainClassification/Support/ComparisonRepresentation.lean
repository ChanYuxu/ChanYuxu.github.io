import DIDomainClassification.Support.ComparisonEventCore
import DIDomainClassification.Section02.EventRepresentation

/-! Transport the proved configuration comparison to arbitrary countably
based dI-domains. Only the event carriers, not whole domains, are counted. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonRepresentation
open Preliminaries EventStructures CoherenceDegree Section04 AdditionalSourceModels
open Section03.StableFunctionModels Subcategories

theorem comparison (D E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hLe : objectDegree D ≤ objectDegree E) : StableComparison D E := by
  classical
  obtain ⟨A, ordA, hAE⟩ := primeEventRepresentation (Core D)
    ⟨(Core D).isDIDomain, D.countableCompacts⟩
  letI : PartialOrder A := ordA
  obtain ⟨cntA, ED, ⟨qD⟩⟩ := hAE
  letI : Countable A := cntA
  obtain ⟨B, ordB, hBE⟩ := primeEventRepresentation (Core E)
    ⟨(Core E).isDIDomain, E.countableCompacts⟩
  letI : PartialOrder B := ordB
  obtain ⟨cntB, EE, ⟨qE⟩⟩ := hBE
  letI : Countable B := cntB
  let hED := configurationDomain A ED
  let hEE := configurationDomain B EE
  have hCfgNon : Nontrivial (Configuration EE) := by
    obtain ⟨x, y, hxy⟩ := hNon.exists_pair_ne
    exact ⟨⟨qE x, qE y, fun h => hxy (qE.injective h)⟩⟩
  have hDdeg := ForestUniverseTransport.degree_orderIso
    (Core D).isDIDomain.toIsScottDomain hED.1.toIsScottDomain qD
  have hEdeg := ForestUniverseTransport.degree_orderIso
    (Core E).isDIDomain.toIsScottDomain hEE.1.toIsScottDomain qE
  have hCfgLe : coherenceDegree hED.1.toIsScottDomain ≤ coherenceDegree hEE.1.toIsScottDomain :=
    hDdeg.symm.le.trans (hLe.trans hEdeg.le)
  have hCfg := ComparisonEventCore.configurations ED EE hED hEE hCfgNon hCfgLe
  have hDsplit := ComparisonOperations.iso_split (Core D) (Core (configurationCB ED hED)) qD
  have hEsplit := ComparisonOperations.iso_split (Core (configurationCB EE hEE)) (Core E) qE.symm
  exact comparisonTransitivity _ _ _
    (ComparisonOperations.split_comparison hDsplit hCfg) (comparisonRetraction _ _ hEsplit)

end DIDomainClassification.ComparisonRepresentation
