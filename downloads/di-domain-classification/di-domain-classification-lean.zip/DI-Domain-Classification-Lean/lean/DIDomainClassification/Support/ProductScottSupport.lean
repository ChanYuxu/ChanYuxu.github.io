import DIDomainClassification.Support.PiScottProperties
import DIDomainClassification.Support.PiCountability
import DIDomainClassification.Support.CoherenceDegreeBounds

/-!
Raw dependent-product support on the literal Pi carrier/native coordinate order.
Coordinate least elements are derived from actual Scott-domain hypotheses.
No dI, Countable whole carrier, strictness or product closure premise is used.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.BPSProductDegree

open OrderCore Preliminaries CoherenceDegree

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]

theorem product_le_iff (x y : ∀ i, D i) : x ≤ y ↔ ∀ i, x i ≤ y i := Iff.rfl

/-- This adds only the least-element operation/property to each GIVEN order. -/
def coordinateOrderBot (hD : ∀ i, IsScottDomain (D i)) : ∀ i, OrderBot (D i) :=
  fun i => { bot := (hD i).bottom, bot_le := (hD i).bottom_le }

def productScottDomain (hD : ∀ i, IsScottDomain (D i)) : IsScottDomain (∀ i, D i) := by
  letI : ∀ i, OrderBot (D i) := coordinateOrderBot hD
  exact PiTheory.pi_isScottDomain hD

theorem product_compactSet_countable [Countable I] (hD : ∀ i, IsScottDomain (D i))
    (hK : ∀ i, (CompactElements (D i)).Countable) :
    (CompactElements (∀ i, D i)).Countable := by
  letI : ∀ i, OrderBot (D i) := coordinateOrderBot hD
  exact PiTheory.pi_compact_countable hK

def rootSupport (hD : ∀ i, IsScottDomain (D i)) (k : ∀ i, D i) : Set I :=
  {i | k i ≠ (hD i).bottom}

theorem rootSupport_finite (hD : ∀ i, IsScottDomain (D i))
    {k : ∀ i, D i} (hk : Compact k) : (rootSupport hD k).Finite := by
  letI : ∀ i, OrderBot (D i) := coordinateOrderBot hD
  exact PiTheory.compact_finite_support hk

theorem compact_projection {k : ∀ i, D i} (hk : Compact k) (i : I) :
    Compact (k i) := PiTheory.compact_coordinate hk i

def coordinateSection (hD : ∀ i, IsScottDomain (D i)) (i : I) : D i → ∀ j, D j := by
  letI : ∀ j, OrderBot (D j) := coordinateOrderBot hD
  exact PiTheory.single i

theorem coordinateSection_self (hD : ∀ i, IsScottDomain (D i)) (i : I) (a : D i) :
    coordinateSection hD i a i = a := by
  letI : ∀ j, OrderBot (D j) := coordinateOrderBot hD
  exact PiTheory.single_self i a

theorem coordinateSection_scottContinuous (hD : ∀ i, IsScottDomain (D i)) (i : I) :
    ScottContinuous (coordinateSection hD i) := by
  classical
  letI : ∀ j, OrderBot (D j) := coordinateOrderBot hD
  intro A hA _hdir a ha
  exact PiTheory.update_isSup (fun j => (⊥ : D j)) i hA ha

theorem coordinateEval_scottContinuous (i : I) :
    ScottContinuous (Function.eval i : (∀ i, D i) → D i) := by
  intro A _hA _hdir a ha
  exact PiTheory.coordinate_isSup ha i

theorem factor_coherenceDegree_le {I : Type u} {D : I → Type u}
    [∀ i, PartialOrder (D i)] (hD : ∀ i, IsScottDomain (D i)) (i : I) :
    coherenceDegree (hD i) ≤ coherenceDegree (productScottDomain hD) :=
  coherenceDegree_mono_of_scott_split (hD i) (productScottDomain hD)
    (coordinateSection_scottContinuous hD i) (coordinateEval_scottContinuous i)
    (coordinateSection_self hD i)

theorem iSup_factor_coherenceDegree_le {I : Type u} {D : I → Type u}
    [∀ i, PartialOrder (D i)] (hD : ∀ i, IsScottDomain (D i)) :
    (⨆ i, coherenceDegree (hD i)) ≤ coherenceDegree (productScottDomain hD) :=
  Ordinal.iSup_le (fun i => factor_coherenceDegree_le hD i)

end DIDomainClassification.BPSProductDegree
