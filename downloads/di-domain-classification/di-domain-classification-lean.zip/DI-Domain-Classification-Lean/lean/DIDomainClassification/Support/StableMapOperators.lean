import DIDomainClassification.Support.StableClosureWitness

/-! Actual stable higher-order precomposition and postcomposition. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.StableMapOperators

open Section02.StableBackground StableCCCOperations

abbrev closure : DomainClosure.{u} := StableClosureWitness.domainClosure.{u}
abbrev product (D E : Obj.{u}) := productObject closure D E
abbrev exponential (D E : Obj.{u}) := exponentialObject closure D E

def constant (X Y : Obj.{u}) (y : Core Y) : Hom X Y :=
  StableHom.ofFunction (fun _ => y)
    ⟨ScottContinuous.const y, fun _ _ _ => (inf_idem y).symm⟩

theorem constant_apply (X Y : Obj.{u}) (y : Core Y) (x : Core X) :
    constant X Y y x = y := rfl

def postcompose (D E F : Obj.{u}) (g : Hom E F) :
    Hom (exponential D E) (exponential D F) :=
  StableHom.comp (composition closure D E F)
    (pair closure (exponential D E) (exponential E F) (exponential D E)
      (constant (exponential D E) (exponential E F) g)
      (StableHom.id (Core (exponential D E))))

theorem postcompose_apply (D E F : Obj.{u}) (g : Hom E F)
    (f : Hom D E) (x : Core D) : postcompose D E F g f x = g (f x) := rfl

def precompose (A D E : Obj.{u}) (r : Hom A D) :
    Hom (exponential D E) (exponential A E) :=
  StableHom.comp (composition closure A D E)
    (pair closure (exponential D E) (exponential D E) (exponential A D)
      (StableHom.id (Core (exponential D E)))
      (constant (exponential D E) (exponential A D) r))

theorem precompose_apply (A D E : Obj.{u}) (r : Hom A D)
    (f : Hom D E) (x : Core A) : precompose A D E r f x = f (r x) := rfl

def reindex (A D E B : Obj.{u}) (r : Hom A D) (s : Hom E B) :
    Hom (exponential D E) (exponential A B) :=
  StableHom.comp (postcompose A E B s) (precompose A D E r)

theorem reindex_apply (A D E B : Obj.{u}) (r : Hom A D) (s : Hom E B)
    (f : Hom D E) (x : Core A) : reindex A D E B r s f x = s (f (r x)) := rfl

def productMap (D E A B : Obj.{u}) (f : Hom D A) (g : Hom E B) :
    Hom (product D E) (product A B) :=
  pair closure (product D E) A B
    (StableHom.comp f (fst closure D E))
    (StableHom.comp g (snd closure D E))

theorem productMap_apply (D E A B : Obj.{u}) (f : Hom D A) (g : Hom E B)
    (x : Core D × Core E) : productMap D E A B f g x = (f x.1, g x.2) := rfl

end DIDomainClassification.StableMapOperators
