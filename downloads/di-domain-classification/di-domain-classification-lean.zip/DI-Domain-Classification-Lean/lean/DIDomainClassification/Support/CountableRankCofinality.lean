import DIDomainClassification.Support.CountableTreeRankRealization

/-!
Actual cross-universe cofinality of countable ordinal successor lifts.
The target first uncountable is the real initial ordinal of succ aleph0.
The proof unpacks a hypothetical countable upper bound through the genuine
Mathlib lift-range theorem; no arbitrary uncountable ordinal is supplied.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.CountableTreeRankRealization

theorem card_add_one_le_aleph0 (α : Ordinal.{u})
    (hα : α.card ≤ Cardinal.aleph0) : (α + 1).card ≤ Cardinal.aleph0 := by
  rw [Ordinal.card_add_one]
  exact (add_le_add hα (le_rfl : (1 : Cardinal.{u}) ≤ 1)).trans
    (Cardinal.add_one_of_aleph0_le le_rfl).le

/-- A countable ordinal in the next universe really is a lift of a countable
ordinal in the original universe. This is proved, not an assumed unlift API. -/
theorem exists_countable_unlift (a : Ordinal.{u+1})
    (ha : a.card ≤ Cardinal.aleph0) :
    ∃ α : Ordinal.{u}, α.card ≤ Cardinal.aleph0 ∧ Ordinal.lift.{u+1} α = a := by
  have hcard : a.card ≤ Cardinal.lift.{u+1} Cardinal.aleph0.{u} := by
    simpa only [Cardinal.lift_aleph0] using ha
  obtain ⟨α, hα⟩ := Ordinal.mem_range_lift_of_card_le
    (a := Cardinal.aleph0.{u}) (b := a) hcard
  refine ⟨α, Cardinal.lift_le_aleph0.mp ?_, hα⟩
  rw [Ordinal.lift_card, hα]
  exact ha

theorem firstUncountable_le_of_countable_successor_lifts
    (a : Ordinal.{u+1})
    (ha : ∀ α : Ordinal.{u}, α.card ≤ Cardinal.aleph0 →
      Ordinal.lift.{u+1} (α + 1) ≤ a) :
    (Order.succ Cardinal.aleph0.{u+1}).ord ≤ a := by
  by_contra h
  have hcount : a.card ≤ Cardinal.aleph0 := Cardinal.card_le_iff.mpr (lt_of_not_ge h)
  obtain ⟨α, hα, hlift⟩ := exists_countable_unlift a hcount
  have hlt : Ordinal.lift.{u+1} α < Ordinal.lift.{u+1} (α + 1) :=
    Ordinal.lift_lt.mpr (by simpa only [Order.succ_eq_add_one] using Order.lt_succ α)
  rw [hlift] at hlt
  exact (not_le_of_gt hlt) (ha α hα)

/-- Exact positive-rank input used by proper WF tree realizations; α=0 need not
be supplied by the caller. A further successor supplies positivity/countability. -/
theorem firstUncountable_le_of_pos_countable_successor_lifts
    (a : Ordinal.{u+1})
    (ha : ∀ α : Ordinal.{u}, α.card ≤ Cardinal.aleph0 → 0 < α →
      Ordinal.lift.{u+1} (α + 1) ≤ a) :
    (Order.succ Cardinal.aleph0.{u+1}).ord ≤ a := by
  apply firstUncountable_le_of_countable_successor_lifts a
  intro α hα
  have hpos : 0 < α + 1 :=
    (zero_le α).trans_lt (by simpa only [Order.succ_eq_add_one] using Order.lt_succ α)
  have hbound := ha (α + 1) (card_add_one_le_aleph0 α hα) hpos
  exact (Ordinal.lift_le.mpr (show α + 1 ≤ (α + 1) + 1 by
    simpa only [Order.succ_eq_add_one] using Order.le_succ (α + 1))).trans hbound

end DIDomainClassification.CountableTreeRankRealization

