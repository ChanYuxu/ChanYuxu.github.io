import DIDomainClassification.Support.ForestProductMaps
import DIDomainClassification.Support.RelativeSubtree
import DIDomainClassification.Support.InfiniteTreeDegree
import DIDomainClassification.Support.WellFoundedTreeDegree

/-! Genuine universe transport for the countable natural-index trees used
by the forest. It changes the coding alphabet, not the literal forest output. -/

set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.ForestUniverseTransport
open Preliminaries Trees CoherenceDegree

def upList (l : List ℕ) : List (ULift.{u} ℕ) := l.map ULift.up
def downList (l : List (ULift.{u} ℕ)) : List ℕ := l.map ULift.down

theorem down_up (l : List ℕ) : downList (upList.{u} l) = l := by
  simp [upList, downList, List.map_map, Function.comp_def]

theorem up_down (l : List (ULift.{u} ℕ)) : upList (downList l) = l := by
  induction l with
  | nil => rfl
  | cons a l ih => simpa only [upList, downList, List.map_cons] using congrArg (a :: ·) ih

def liftTree (T : RootedPrefixTree ℕ) : RootedPrefixTree (ULift.{u} ℕ) where
  nodes := {l | downList l ∈ T.nodes}
  rootList := upList T.rootList
  root_mem := by simpa only [Set.mem_setOf_eq, down_up] using T.root_mem
  root_prefix := by
    intro l hl
    have h := (T.root_prefix hl).map ULift.up
    change upList T.rootList <+: upList (downList l) at h
    rw [up_down] at h
    exact h
  prefix_closed := by
    intro l m hroot hlm hm
    apply T.prefix_closed
    · have h := hroot.map ULift.down
      change downList (upList T.rootList) <+: downList l at h
      rw [down_up] at h
      exact h
    · exact hlm.map ULift.down
    · exact hm
  countable_nodes := Set.to_countable _

local instance liftNodeOrder (T : RootedPrefixTree ℕ) : PartialOrder (liftTree.{u} T).Node :=
  (liftTree T).instPartialOrderNode

def nodeEquiv (T : RootedPrefixTree ℕ) : T.Node ≃ (liftTree.{u} T).Node where
  toFun v := ⟨upList v.val, by simpa only [liftTree, Set.mem_setOf_eq, down_up] using v.property⟩
  invFun v := ⟨downList v.val, v.property⟩
  left_inv v := Subtype.ext (down_up v.val)
  right_inv v := Subtype.ext (up_down v.val)

def nodeOrderIso (T : RootedPrefixTree ℕ) :
    @OrderIso T.Node (liftTree.{u} T).Node T.instPartialOrderNode.toLE
      (liftTree T).instPartialOrderNode.toLE where
  toEquiv := nodeEquiv T
  map_rel_iff' := by
    intro v w
    change upList v.val <+: upList w.val ↔ v.val <+: w.val
    constructor
    · intro h
      have h' := h.map ULift.down
      change downList (upList v.val) <+: downList (upList w.val) at h'
      simpa only [down_up] using h'
    · intro h
      exact h.map ULift.up

theorem node_root (T : RootedPrefixTree ℕ) :
    nodeOrderIso.{u} T T.root = (liftTree T).root := rfl

theorem node_child_iff (T : RootedPrefixTree ℕ) (v w : T.Node) :
    (liftTree T).IsChild (nodeOrderIso.{u} T v) (nodeOrderIso T w) ↔ T.IsChild v w := by
  rw [TreeGrafting.isChild_iff_prefix_length, TreeGrafting.isChild_iff_prefix_length]
  change (upList v.val <+: upList w.val ∧
      (upList w.val).length = (upList v.val).length + 1) ↔
    (v.val <+: w.val ∧ w.val.length = v.val.length + 1)
  constructor
  · rintro ⟨h, hn⟩
    exact ⟨(nodeOrderIso T).map_rel_iff.mp h, by simpa only [upList, List.length_map] using hn⟩
  · rintro ⟨h, hn⟩
    exact ⟨(nodeOrderIso T).map_rel_iff.mpr h, by simpa only [upList, List.length_map] using hn⟩

theorem leaf_orderIso {B : Type v} {C : Type w} (S : RootedPrefixTree B)
    (T : RootedPrefixTree C) (q : S.Node ≃o T.Node) (x : S.Node) :
    T.IsLeaf (q x) ↔ S.IsLeaf x := by
  constructor
  · intro hx y hxy
    exact q.injective (hx (q y) (q.monotone hxy))
  · intro hx y hxy
    have h : x ≤ q.symm y := by
      apply q.le_iff_le.mp
      simpa only [q.apply_symm_apply] using hxy
    exact (q.apply_symm_apply y).symm.trans (congrArg q (hx _ h))

theorem path_orderIso {B : Type v} {C : Type w} (S : RootedPrefixTree B)
    (T : RootedPrefixTree C) (q : S.Node ≃o T.Node) (x : S.Node) :
    q '' S.pathTo x = T.pathTo (q x) := q.image_Iic x

theorem finiteBranch_orderIso {B : Type v} {C : Type w} (S : RootedPrefixTree B)
    (T : RootedPrefixTree C) (q : S.Node ≃o T.Node) (c : Set S.Node)
    (hc : S.IsFiniteCompleteBranch c) : T.IsFiniteCompleteBranch (q '' c) := by
  obtain ⟨x, hx, rfl⟩ := hc
  exact ⟨q x, (leaf_orderIso S T q x).mpr hx, path_orderIso S T q x⟩

theorem proper_liftTree (T : RootedPrefixTree ℕ) (hp : T.IsProper) :
    (liftTree.{u} T).IsProper := by
  letI : PartialOrder T.Node := T.instPartialOrderNode
  letI : PartialOrder (liftTree.{u} T).Node := (liftTree T).instPartialOrderNode
  letI : LE T.Node := T.instPartialOrderNode.toLE
  letI : LE (liftTree.{u} T).Node := (liftTree T).instPartialOrderNode.toLE
  apply (liftTree T).isProper_iff.mpr
  constructor
  · obtain ⟨x, y, hxy⟩ := hp.1.exists_pair_ne
    exact ⟨⟨nodeOrderIso T x, nodeOrderIso T y,
      fun h => hxy ((nodeOrderIso T).injective h)⟩⟩
  · intro v
    obtain ⟨w, hw, hvw⟩ := (T.isProper_iff.mp hp).2 ((nodeOrderIso T).symm v)
    refine ⟨nodeOrderIso T w, (leaf_orderIso T (liftTree T) (nodeOrderIso T) w).mpr hw, ?_⟩
    have hmap := (nodeOrderIso T).map_rel_iff.mpr hvw
    have hcancel : nodeOrderIso.{u} T ((nodeOrderIso.{u} T).symm v) = v :=
      (nodeEquiv.{u} T).apply_symm_apply v
    rw [hcancel] at hmap
    exact hmap

def domainOrderIso {B : Type v} {C : Type w} (S : RootedPrefixTree B)
    (T : RootedPrefixTree C) (q : S.Node ≃o T.Node) : TreeDomain S ≃o TreeDomain T where
  toFun X := ⟨q '' X.val, by
    intro c hc hsub
    have hback := finiteBranch_orderIso T S q.symm c hc
    apply X.property (q.symm '' c) hback
    rintro _ ⟨z, hz, rfl⟩
    obtain ⟨x, hx, hqx⟩ := hsub hz
    simpa only [← hqx, q.symm_apply_apply] using hx⟩
  invFun X := ⟨q.symm '' X.val, by
    intro c hc hsub
    have hback := finiteBranch_orderIso S T q c hc
    apply X.property (q '' c) hback
    rintro _ ⟨z, hz, rfl⟩
    obtain ⟨x, hx, hqx⟩ := hsub hz
    simpa only [← hqx, q.apply_symm_apply] using hx⟩
  left_inv X := Subtype.ext (q.symm_image_image X.val)
  right_inv X := Subtype.ext (q.image_symm_image X.val)
  map_rel_iff' := by
    intro X Y
    exact Set.image_subset_image_iff q.injective

def liftDomainOrderIso (T : RootedPrefixTree ℕ) :
    ULift.{u} (TreeDomain T) ≃o TreeDomain (liftTree.{u} T) :=
  (ForestProductMaps.liftOrderIso (TreeDomain T)).trans
    (domainOrderIso T (liftTree T) (nodeOrderIso T))

theorem lift_wellFounded (T : RootedPrefixTree ℕ) (hT : T.IsWellFounded) :
    (liftTree.{u} T).IsWellFounded := by
  apply (liftTree T).isWellFounded_iff_wellFounded_reverseChildRelation.mpr
  have h := (T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).onFun
    (f := (nodeEquiv.{u} T).symm)
  apply h.mono
  intro x y hxy
  change T.IsChild ((nodeEquiv T).symm y) ((nodeEquiv T).symm x)
  apply (node_child_iff T ((nodeEquiv T).symm y) ((nodeEquiv T).symm x)).mp
  change (liftTree T).IsChild ((nodeEquiv T) ((nodeEquiv T).symm y))
    ((nodeEquiv T) ((nodeEquiv T).symm x))
  change (liftTree T).IsChild y x at hxy
  rw [(nodeEquiv.{u} T).apply_symm_apply y, (nodeEquiv.{u} T).apply_symm_apply x]
  exact hxy

theorem wellFounded_of_lift (T : RootedPrefixTree ℕ)
    (hT : (liftTree.{u} T).IsWellFounded) : T.IsWellFounded := by
  apply T.isWellFounded_iff_wellFounded_reverseChildRelation.mpr
  have h := ((liftTree T).isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).onFun
    (f := nodeEquiv.{u} T)
  exact h.mono (fun x y hxy => (node_child_iff T y x).mpr hxy)

theorem lift_wellFounded_iff (T : RootedPrefixTree ℕ) :
    (liftTree.{u} T).IsWellFounded ↔ T.IsWellFounded :=
  ⟨wellFounded_of_lift T, lift_wellFounded T⟩

theorem lift_infinite_iff (T : RootedPrefixTree ℕ) :
    (liftTree.{u} T).HasInfiniteBranch ↔ T.HasInfiniteBranch := by
  classical
  have h := lift_wellFounded_iff.{u} T
  change (¬ (liftTree T).HasInfiniteBranch ↔ ¬ T.HasInfiniteBranch) at h
  exact not_iff_not.mp h

theorem lift_small_iSup {I : Type} (f : I → Ordinal.{0}) :
    Ordinal.lift.{u} (⨆ i, f i) = ⨆ i, Ordinal.lift.{u} (f i) := by
  cases isEmpty_or_nonempty I with
  | inl h =>
      letI : IsEmpty I := h
      have h0 : (⨆ i, f i) = 0 := Ordinal.iSup_eq_zero_iff.mpr (fun i => isEmptyElim i)
      have h1 : (⨆ i, Ordinal.lift.{u} (f i)) = 0 :=
        Ordinal.iSup_eq_zero_iff.mpr (fun i => isEmptyElim i)
      rw [h0, h1, Ordinal.lift_zero]
  | inr h =>
      letI : Nonempty I := h
      exact (Ordinal.liftInitialSeg.{u,0}.isNormal).map_iSup Ordinal.bddAbove_of_small

theorem nodeRank_lift (T : RootedPrefixTree ℕ) (hT : T.IsWellFounded) (v : T.Node) :
    (liftTree.{u} T).nodeRank (lift_wellFounded T hT) (nodeEquiv T v) =
      Ordinal.lift.{u} (T.nodeRank hT v) := by
  let L := liftTree.{u} T
  let hL := lift_wellFounded.{u} T hT
  refine (T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).induction
    (C := fun v => L.nodeRank hL (nodeEquiv T v) = Ordinal.lift.{u} (T.nodeRank hT v)) v ?_
  intro v ih
  rw [L.nodeRank_eq hL, T.nodeRank_eq hT, lift_small_iSup]
  apply le_antisymm
  · apply Ordinal.iSup_le
    intro y
    let x := (nodeEquiv T).symm y.val
    have hmap : nodeEquiv T x = y.val := (nodeEquiv T).apply_symm_apply y.val
    have hchild : T.IsChild v x := by
      apply (node_child_iff T v x).mp
      change L.IsChild (nodeEquiv T v) (nodeEquiv T x)
      rw [hmap]
      exact y.property
    have hrank : L.nodeRank hL y.val = Ordinal.lift.{u} (T.nodeRank hT x) :=
      (congrArg (L.nodeRank hL) hmap).symm.trans (ih x hchild)
    rw [hrank, ← Ordinal.lift_add_one]
    exact Ordinal.le_iSup (fun z : {z : T.Node // T.IsChild v z} =>
      Ordinal.lift.{u} (T.nodeRank hT z.val + 1)) ⟨x, hchild⟩
  · apply Ordinal.iSup_le
    intro x
    have hchild := (node_child_iff.{u} T v x.val).mpr x.property
    calc
      Ordinal.lift.{u} (T.nodeRank hT x.val + 1) =
          L.nodeRank hL (nodeEquiv T x.val) + 1 := by
        rw [Ordinal.lift_add_one, ih x.val x.property]
      _ ≤ ⨆ y : {y : L.Node // L.IsChild (nodeEquiv T v) y}, L.nodeRank hL y.val + 1 :=
        Ordinal.le_iSup
          (fun y : {y : L.Node // L.IsChild (nodeEquiv T v) y} => L.nodeRank hL y.val + 1)
          ⟨nodeEquiv T x.val, hchild⟩

theorem treeRank_lift (T : RootedPrefixTree ℕ) (hT : T.IsWellFounded) :
    (liftTree.{u} T).treeRank (lift_wellFounded T hT) =
      Ordinal.lift.{u} (T.treeRank hT) :=
  nodeRank_lift T hT T.root

theorem degree_orderIso {D E : Type u} [PartialOrder D] [PartialOrder E]
    (hD : IsScottDomain D) (hE : IsScottDomain E) (q : D ≃o E) :
    coherenceDegree hD = coherenceDegree hE := by
  apply le_antisymm
  · exact coherenceDegree_mono_of_scott_split hD hE
      (OrderIsoTransport.scottContinuous q) (OrderIsoTransport.scottContinuous q.symm)
      (fun x => q.symm_apply_apply x)
  · exact coherenceDegree_mono_of_scott_split hE hD
      (OrderIsoTransport.scottContinuous q.symm) (OrderIsoTransport.scottContinuous q)
      (fun x => q.apply_symm_apply x)

theorem lifted_tree_degree (T : RootedPrefixTree ℕ) (hp : T.IsProper)
    (hSmall : IsScottDomain (TreeDomain T))
    (hBig : IsScottDomain (ULift.{u} (TreeDomain T))) :
    coherenceDegree hBig = Ordinal.lift.{u+1} (coherenceDegree hSmall) := by
  calc
    coherenceDegree hBig =
        coherenceDegree (TreeDomainDegree.treeScottDomain (liftTree.{u} T)
          (proper_liftTree T hp)) :=
      degree_orderIso hBig _ (liftDomainOrderIso T)
    _ = Ordinal.lift.{u+1} (coherenceDegree hSmall) := by
      classical
      by_cases hT : T.IsWellFounded
      · rw [TreeDomainDegree.wellFounded_treeDomain_degree_eq (liftTree T)
          (proper_liftTree T hp) (lift_wellFounded T hT),
          TreeDomainDegree.wellFounded_treeDomain_degree_eq T hp hT, treeRank_lift T hT]
        simp only [Ordinal.lift_add_one, Ordinal.lift_lift]
      · have hInf : T.HasInfiniteBranch := not_not.mp hT
        have hLInf := (lift_infinite_iff.{u} T).mpr hInf
        rw [TreeDomainDegree.infiniteBranch_treeDomain_degree_eq (liftTree T)
          (proper_liftTree T hp) hLInf,
          TreeDomainDegree.infiniteBranch_treeDomain_degree_eq T hp hInf,
          Cardinal.lift_ord, Cardinal.lift_succ, Cardinal.lift_aleph0]

def inputOrderIso (D : DIDomainObject.{v}) (A E : DIDomainObject.{u})
    (q : A ≃o D) : StableHom D E ≃o StableHom A E where
  toFun f := StableHom.comp f (OrderIsoTransport.stableHom A D q)
  invFun f := StableHom.comp f (OrderIsoTransport.stableHom D A q.symm)
  left_inv f := by
    apply StableHom.ext
    intro x
    exact congrArg f (q.apply_symm_apply x)
  right_inv f := by
    apply StableHom.ext
    intro x
    exact congrArg f (q.symm_apply_apply x)
  map_rel_iff' := by
    intro f g
    constructor
    · intro h x y hxy
      have ht := h (q.symm x) (q.symm y) (q.symm.monotone hxy)
      change f (q (q.symm x)) = f (q (q.symm y)) ⊓ g (q (q.symm x)) at ht
      simpa only [q.apply_symm_apply] using ht
    · intro h x y hxy
      exact h (q x) (q y) (q.monotone hxy)

end DIDomainClassification.ForestUniverseTransport
