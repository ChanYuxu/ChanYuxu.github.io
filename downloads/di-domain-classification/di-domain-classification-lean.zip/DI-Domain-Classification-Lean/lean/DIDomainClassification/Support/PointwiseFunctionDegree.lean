import DIDomainClassification.Support.JoinBasisRefinement
import DIDomainClassification.Support.StepBasisMicTrees

/-!
Generic degree equality for the literal ALL-Scott function subtype with its
native pointwise order. This uses the proved full contextual basis refinement,
not a refinement assumption, a stable-function replacement, or a published
degree theorem. It is not the public BPSStatement proof wrapper/receipt.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries CoherenceDegree Trees

variable {D E : Type u} [PartialOrder D] [PartialOrder E]

theorem pointwise_coherenceDegree_le (hD : IsScottDomain D) (hE : IsScottDomain E) :
    coherenceDegree (space_isScottDomain hD hE) ≤ coherenceDegree hE := by
  let hF := space_isScottDomain hD hE
  apply (coherenceDegree_le_iff hF (coherenceDegree hE)).2
  intro Index M hWF
  have hContext := contextual_of_micTree hF M hWF
  obtain ⟨S, hS, L, _hRoot, hRefinedContext, hBasis, hRanks⟩ :=
    finiteJoinBasis_refinement hF (stepBasis hE) (stepBasis_isFiniteJoinBasis hD hE)
      M.tree hWF ∅ M.label hContext
  have hProper : S.IsProper := contextual_empty_isProper hF S hS hRefinedContext
  let N : MicTree (Space D E) hF (ULift.{u} ℕ) := {
    tree := S
    proper := hProper
    label := L
    isMicTree := contextual_isMicTree hF S hRefinedContext hProper }
  have hUpper : Ordinal.lift.{u+1} (S.treeRank hS + 1) ≤ coherenceDegree hE :=
    stepBasis_tree_contribution_le hD hE N hBasis hS
  have hRankLift : Ordinal.lift.{u+1} (M.tree.treeRank hWF + 1) ≤
      Ordinal.lift.{u+1} (S.treeRank hS + 1) :=
    Ordinal.lift_le.mpr (add_le_add hRanks (le_rfl : (1 : Ordinal.{u}) ≤ 1))
  exact hRankLift.trans hUpper

/-- No countability of points, dI structure, stable-map restriction, strictness,
or assumed function-space closure/refinement occurs. Separability is separately
proved by `space_compactSet_countable` on the actual compact-element set. -/
theorem pointwise_coherenceDegree_eq [Nonempty D]
    (hD : IsScottDomain D) (hE : IsScottDomain E) :
    coherenceDegree (space_isScottDomain hD hE) = coherenceDegree hE :=
  le_antisymm (pointwise_coherenceDegree_le hD hE) (codomain_coherenceDegree_le hD hE)

end DIDomainClassification.PointwiseFunctionSupport
