import DIDomainClassification.Section04.GeneratedCategory
import DIDomainClassification.Section02.Inherited
import DIDomainClassification.Support.FullStableSubcategoryClosure

/-!
# Actual closure of the raw generated object class

Source line 2093 presupposes a least replete full stable-retract-closed
cartesian closed subcategory, without a written existence proof. This module
supplies a new valid proof route for the literal raw intersection. No
nontriviality premise is imposed on the generator. Native closure of each
admissible class is proved by separating the nontrivial and singleton cases.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.GeneratedClassClosure

open CategoryTheory CategoryTheory.Limits
open Subcategories Section02.StableBackground

abbrev closure : DomainClosure.{u} := StableClosureWitness.domainClosure.{u}
abbrev unit : Obj.{u} := terminalObject closure
abbrev product (D E : Obj.{u}) : Obj.{u} := productObject closure D E
abbrev exponential (D E : Obj.{u}) : Obj.{u} := exponentialObject closure D E

/-- The actual literal unit is a stable retract of every actual source object. -/
theorem unitStableRetract (D : Obj.{u}) :
    HasStableRetraction unit.{u}.toDIDomainObject D.toDIDomainObject := by
  refine ⟨CountablyBasedDIDomain.toStableHom (IntrinsicAmbient.constant unit.{u} D
      D.toDIDomainObject.isDIDomain.toIsScottDomain.bottom),
    CountablyBasedDIDomain.toStableHom (IntrinsicAmbient.constant D unit.{u} PUnit.unit), ?_⟩
  intro x
  exact Subsingleton.elim _ _

theorem unitMem (P : ObjectClass.{u}) (hP : IsStableRetractClosed P)
    (D : Obj.{u}) (hD : P D) : P unit :=
  hP unit D hD (unitStableRetract D)

/-- Failure of class nontriviality gives an actual singleton carrier for every
included object, not merely an absence of a chosen pair of witnesses. -/
theorem carrierSubsingleton (P : ObjectClass.{u}) (hP : ¬ IsNontrivial P)
    (D : Obj.{u}) (hD : P D) : Subsingleton (Core D) := by
  constructor
  intro x y
  by_contra hxy
  exact hP ⟨D, hD, x, y, hxy⟩

/-- The actual stable-map category isomorphism to any singleton object. -/
def unitIsoOfSubsingleton (D : Obj.{u}) (hD : Subsingleton (Core D)) : unit ≅ D where
  hom := IntrinsicAmbient.constant unit D D.toDIDomainObject.isDIDomain.toIsScottDomain.bottom
  inv := IntrinsicAmbient.constant D unit PUnit.unit
  hom_inv_id := StableHom.ext (fun _ => Subsingleton.elim _ _)
  inv_hom_id := StableHom.ext (fun _ => hD.elim _ _)

theorem productSubsingleton (D E : Obj.{u}) (hD : Subsingleton (Core D))
    (hE : Subsingleton (Core E)) : Subsingleton (Core (product D E)) := by
  constructor
  intro x y
  exact Prod.ext (hD.elim x.1 y.1) (hE.elim x.2 y.2)

/-- A singleton target makes the literal stable function-space carrier a
singleton, regardless of the source. The actual native stable order is kept. -/
theorem exponentialSubsingleton (D E : Obj.{u}) (hE : Subsingleton (Core E)) :
    Subsingleton (Core (exponential D E)) := by
  change Subsingleton (StableHom D.toDIDomainObject E.toDIDomainObject)
  constructor
  intro f g
  exact StableHom.ext (fun _ => hE.elim _ _)

/-- Every admissible class containing unit is closed under the literal product.
In the nontrivial case the membership is an OUTPUT of the proved intrinsic
product comparison. In the other case a proved stable singleton isomorphism
and repleteness give membership. -/
theorem nativeProductMem (P : ObjectClass.{u}) (hP : IsAdmissibleGeneratedClass P)
    (hUnit : P unit) (D E : Obj.{u}) (hD : P D) (hE : P E) : P (product D E) := by
  by_cases hN : IsNontrivial P
  · obtain ⟨hProducts, hAdjoints⟩ := hP.2.1
    letI : HasFiniteProducts (FullStableSubcategory P) := hProducts
    let X : FullStableSubcategory P := ⟨D, hD⟩
    let Y : FullStableSubcategory P := ⟨E, hE⟩
    obtain ⟨e⟩ := (Section02.inherited P hP.1 hN hP.2.2 hP.2.1 hProducts X Y).1
    exact (replete_iff P).mp hP.1 e (prod X Y).property
  · exact (replete_iff P).mp hP.1
      (unitIsoOfSubsingleton (product D E)
        (productSubsingleton D E (carrierSubsingleton P hN D hD)
          (carrierSubsingleton P hN E hE))) hUnit

/-- Every admissible class containing unit is closed under the actual stable
exponential. The native exponential is not assumed to be an object of P. -/
theorem nativeExponentialMem (P : ObjectClass.{u}) (hP : IsAdmissibleGeneratedClass P)
    (hUnit : P unit) (D E : Obj.{u}) (hD : P D) (hE : P E) : P (exponential D E) := by
  by_cases hN : IsNontrivial P
  · obtain ⟨hProducts, hAdjoints⟩ := hP.2.1
    letI : HasFiniteProducts (FullStableSubcategory P) := hProducts
    let X : FullStableSubcategory P := ⟨D, hD⟩
    let Y : FullStableSubcategory P := ⟨E, hE⟩
    obtain ⟨R, ⟨A⟩⟩ := (hAdjoints X).exists_rightAdjoint
    obtain ⟨e⟩ := (Section02.inherited P hP.1 hN hP.2.2 hP.2.1 hProducts X Y).2 R A
    exact (replete_iff P).mp hP.1 e (R.obj Y).property
  · exact (replete_iff P).mp hP.1
      (unitIsoOfSubsingleton (exponential D E)
        (exponentialSubsingleton D E (carrierSubsingleton P hN E hE))) hUnit

theorem generatedUnitMem (D : Obj.{u}) : GeneratedClass D unit := by
  intro P hP hD
  exact unitMem P hP.2.2 D hD

theorem generatedProductClosed (D A B : Obj.{u})
    (hA : GeneratedClass D A) (hB : GeneratedClass D B) : GeneratedClass D (product A B) := by
  intro P hP hD
  exact nativeProductMem P hP (unitMem P hP.2.2 D hD) A B
    (hA P hP hD) (hB P hP hD)

theorem generatedExponentialClosed (D A B : Obj.{u})
    (hA : GeneratedClass D A) (hB : GeneratedClass D B) :
    GeneratedClass D (exponential A B) := by
  intro P hP hD
  exact nativeExponentialMem P hP (unitMem P hP.2.2 D hD) A B
    (hA P hP hD) (hB P hP hD)

theorem generatedReplete (D : Obj.{u}) : IsReplete (GeneratedClass D) := by
  apply (replete_iff (GeneratedClass D)).mpr
  intro A B e hA P hP hD
  exact (replete_iff P).mp hP.1 e (hA P hP hD)

theorem generatedRetractClosed (D : Obj.{u}) : IsStableRetractClosed (GeneratedClass D) := by
  intro A B hB hR P hP hD
  exact hP.2.2 A B (hB P hP hD) hR

/-- Intrinsic CCC is now constructed from the native closures just PROVED
for the raw intersection, not from an assumed least class or assumed CCC. -/
theorem generatedCartesianClosed (D : Obj.{u}) :
    IsIntrinsicallyCartesianClosed (GeneratedClass D) :=
  FullStableSubcategoryClosure.intrinsicallyCartesianClosed (GeneratedClass D)
    (generatedProductClosed D) (generatedExponentialClosed D) (generatedUnitMem D)

theorem generatedAdmissible (D : Obj.{u}) : IsAdmissibleGeneratedClass (GeneratedClass D) :=
  ⟨generatedReplete D, generatedCartesianClosed D, generatedRetractClosed D⟩

theorem generatedContainsGenerator (D : Obj.{u}) : GeneratedClass D D := by
  intro P _hP hD
  exact hD

theorem generatedLeast (D : Obj.{u}) (P : ObjectClass.{u})
    (hP : IsAdmissibleGeneratedClass P) (hD : P D) :
    ∀ E, GeneratedClass D E → P E := by
  intro E hE
  exact hE P hP hD

end DIDomainClassification.GeneratedClassClosure
