import DIDomainClassification.Support.FiniteGeneratorCalculus
import DIDomainClassification.Section02.EventRepresentation
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Section04.QualitativeCoherence

/-! Source1070--1127. Finite whole carriers supply finite event
representations; all cube/power and stable-splitting certificates are outputs. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FiniteGeneratorProofs

open Preliminaries EventStructures CoherenceDegree FiniteOrderDomains
open Section02.RetractionCalculusModels Section04.FiniteCategoryModels
open Section04.FiniteGeneratorModels FiniteGeneratorCalculus

theorem finiteRepresentation (D : DIDomainObject.{u}) [Finite D] :
    ∃ (A : Type u) (order : PartialOrder A),
      letI : PartialOrder A := order
      ∃ (_finite : Finite A) (E : FinitaryPrimeEventStructure A),
        Nonempty (D ≃o Configuration E) := by
  obtain ⟨A, order, h⟩ := primeEventRepresentation D (finiteCountablyBased D)
  letI : PartialOrder A := order
  obtain ⟨hCount, E, ⟨e⟩⟩ := h
  letI : Countable A := hCount
  letI : Finite (Configuration E) := Finite.of_injective e.symm e.symm.injective
  have hFinite : Finite A := Finite.of_injective (ConfigurationDomain.principal E)
    (QualitativeConfigurationMIC.principal_injective E)
  exact ⟨A, order, hFinite, E, ⟨e⟩⟩

theorem factor_retract {A : Type u} [PartialOrder A]
    (E : FinitaryPrimeEventStructure A) (n : ℕ) (hn : 2 ≤ n)
    (hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn))
    (hBound : ∀ H ∈ causalConflictFamily E, H.ncard ≤ n)
    (i : A ⊕ causalConflictFamily E) :
    HasStableRetraction (factorFamily E i) (cubeCore n hn hCube.1) := by
  cases i with
  | inl a =>
    exact (Section02.twoRetract (cubeCore n hn hCube.1)
      (cube_nontrivial n hn hCube.1)).2
  | inr H =>
    have hk := FiniteForbiddenProduct.conflict_card_two E H
    obtain ⟨hm, P, hK, hM, s, r, _hs, _hr, hleft⟩ :=
      (Section04.truncatedRetractions.{u}).1 H.val.ncard n hk (hBound H.val H.property)
    have hIso := FiniteRelativePowersets.cubeOrderIso H.val H.val.ncard hk
      (FiniteCausalConflictRetractions.enumeration H.val
        (FiniteCausalConflicts.conflict_member_finite E H.property))
    exact FiniteGeneratorCalculus.trans
      (ofOrderIso (factorFamily E (.inr H)) (cubeCore H.val.ncard hk hK.1)
      hIso.symm) ⟨s, r, hleft⟩

theorem intoFinitePower (n : ℕ) (hn : 2 ≤ n) (D : DIDomainObject.{u})
    [Finite D] (hN : IsNCoherent D.isDIDomain.toIsScottDomain n hn) :
    ∃ (m : ℕ) (_hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn))
      (hPower : IsCountablyBasedDIDomain (CubePower.{u} n hn m)),
      HasStableRetraction D (powerCore n hn m hPower.1) := by
  obtain ⟨A, order, h⟩ := finiteRepresentation D
  letI : PartialOrder A := order
  obtain ⟨hFinite, E, ⟨e⟩⟩ := h
  letI : Finite A := hFinite
  let hE := configurationDomain A E
  have hDegreeD : coherenceDegree D.isDIDomain.toIsScottDomain ≤
      (n : Ordinal.{u+1}) :=
    ((Section02.bps.{u}).2.2.2.2.2.2 D D.isDIDomain.toIsScottDomain
      (finiteCountablyBased D).2 n hn).mpr hN
  have hDegreeE : coherenceDegree hE.1.toIsScottDomain ≤ (n : Ordinal.{u+1}) := by
    exact (degree_eq D (configurationCore E) e).symm.le.trans hDegreeD
  have hBound : ∀ H ∈ causalConflictFamily E, H.ncard ≤ n :=
    ((Section04.qualitativeCoherence.{u}).1 A E hE n hn).mp hDegreeE
  let hCube := FiniteCubeRetractions.cubeCountablyBased.{u} n hn
  obtain ⟨m, hPi, hPower, hPowerSplit⟩ :=
    finiteProductPower (factorFamily E) n hn hCube (factor_retract E n hn hCube hBound)
  obtain ⟨C, s, r, _hS, _hR, hleft, _hBelow⟩ := Section04.causalRetraction A E
  obtain ⟨C', hP, j, R, _finQ, _finP, _jFormula, _rFormula, hJ⟩ :=
    FiniteForbiddenProduct.printedConstruction A E
  have hDConf : HasStableRetraction D (configurationCore E) := ofOrderIso _ _ e
  have hConfQ : HasStableRetraction (configurationCore E) (qualitativeCoverCore E C) :=
    ⟨s, r, hleft⟩
  have hQP : HasStableRetraction (qualitativeCoverCore E C)
      (FiniteForbiddenProduct.core E hP) := ⟨j, R, hJ⟩
  have hPPi : HasStableRetraction (FiniteForbiddenProduct.core E hP)
      (piCore (factorFamily E) hPi.1) := ofOrderIso _ _ (productOrderIso E)
  exact ⟨m, hCube, hPower, FiniteGeneratorCalculus.trans hDConf
    (FiniteGeneratorCalculus.trans hConfQ (FiniteGeneratorCalculus.trans hQP
      (FiniteGeneratorCalculus.trans hPPi hPowerSplit)))⟩

theorem containsDegreeCube (n : ℕ) (hn : 2 ≤ n) (D : DIDomainObject.{u})
    [Finite D] (hDegreeD : coherenceDegree D.isDIDomain.toIsScottDomain =
      (n : Ordinal.{u+1})) :
    ∃ hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn),
      HasStableRetraction (cubeCore n hn hCube.1) D := by
  obtain ⟨A, order, h⟩ := finiteRepresentation D
  letI : PartialOrder A := order
  obtain ⟨hFinite, E, ⟨e⟩⟩ := h
  letI : Finite A := hFinite
  let hE := configurationDomain A E
  have hDegreeE : coherenceDegree hE.1.toIsScottDomain = (n : Ordinal.{u+1}) :=
    (degree_eq D (configurationCore E) e).symm.trans hDegreeD
  have hBound : ∀ H ∈ causalConflictFamily E, H.ncard ≤ n :=
    ((Section04.qualitativeCoherence.{u}).1 A E hE n hn).mp hDegreeE.le
  have hNonempty : (causalConflictFamily E).Nonempty := by
    by_contra hEmpty
    have hz := (Section04.qualitativeCoherence.{u}).2.1 A E hE
      (Set.not_nonempty_iff_eq_empty.mp hEmpty)
    have hnzero : (n : Ordinal.{u+1}) = 0 := hDegreeE.symm.trans hz
    have hnzeroNat : n = 0 := by exact_mod_cast hnzero
    omega
  obtain ⟨m, H, hH, hCard, _hMax, hDegreeMax⟩ :=
    (Section04.qualitativeCoherence.{u}).2.2 A E hE hNonempty ⟨n, hBound⟩
  have hmn : m = n := by exact_mod_cast hDegreeMax.symm.trans hDegreeE
  subst m
  subst n
  obtain ⟨hm, U, _hU, _eH, hCube, s, r, _hHU, _hS, _hR, hleft⟩ :=
    (Section04.truncatedRetractions.{u}).2 A E H hH
  exact ⟨hCube, FiniteGeneratorCalculus.trans ⟨s, r, hleft⟩
    (ofOrderIso (configurationCore E) D e.symm)⟩

end DIDomainClassification.FiniteGeneratorProofs
