import DIDomainClassification.Support.CompactMicChains
import DIDomainClassification.Section02.BPSPreliminaries

/-! Zero coherence degree and completeness of the original underlying order. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.CoherenceDegree

open Preliminaries

variable {D : Type u} [PartialOrder D] (hD : IsScottDomain D)

theorem no_mic_of_degree_zero (hz : coherenceDegree hD = 0)
    {M : Set D} (hM : IsMinimallyInconsistent hD M) : False := by
  have hbound := mic_ncard_le_degree hD hM
  have htwo : (2 : Ordinal.{u+1}) ≤ (M.ncard : Ordinal.{u+1}) := by
    exact_mod_cast mic_ncard_ge_two hD hM
  rw [hz] at hbound
  have hpos : (0 : Ordinal.{u+1}) < 2 := by
    exact_mod_cast (by decide : (0 : ℕ) < 2)
  exact (not_le_of_gt hpos) (htwo.trans hbound)

theorem every_set_consistent_of_degree_zero (hz : coherenceDegree hD = 0)
    (X : Set D) : Consistent X := by
  apply consistent_of_finite_subsets_consistent hD X
  intro F hF _hFX
  by_contra hbad
  obtain ⟨M, _hMF, hM⟩ := exists_minimally_inconsistent_subset hD F hF hbad
  exact no_mic_of_degree_zero hD hz hM

theorem complete_lattice_order_of_degree_zero (hz : coherenceDegree hD = 0) :
    Section02.BPS.IsCompleteLatticeOrder D := by
  intro X
  refine ⟨hD.boundedSuprema X (every_set_consistent_of_degree_zero hD hz X), ?_⟩
  obtain ⟨m, hm⟩ := hD.boundedSuprema (lowerBounds X)
    (every_set_consistent_of_degree_zero hD hz (lowerBounds X))
  refine ⟨m, ?_, ?_⟩
  · intro x hx
    exact hm.2 (fun b hb => hb hx)
  · intro b hb
    exact hm.1 hb

theorem degree_zero_iff_complete_lattice_order :
    coherenceDegree hD = 0 ↔ Section02.BPS.IsCompleteLatticeOrder D :=
  ⟨complete_lattice_order_of_degree_zero hD,
    Section02.BPSProof.degree_zero_of_complete hD⟩

end DIDomainClassification.CoherenceDegree
