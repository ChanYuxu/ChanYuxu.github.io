import DIDomainClassification.Support.ContextualMicTrees
import DIDomainClassification.Support.ForestGraft

/-! Actual compact labelling of the frozen normalized forest construction.
The graft itself, its WF and rank recurrence are proved in the generic donor;
this file proves the full contextual MIC conditions for its actual nodes.
-/

set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries CoherenceDegree Trees TreeGrafting

variable {D : Type u} [PartialOrder D] {A : Type v} {I : Type w} [Countable I]
  (S : I → RootedPrefixTree A) (tag : I → A) (hroot : ∀ i, (S i).rootList = [])

def ForestLabelRelation (a : ↥(CompactElements D))
    (labels : ∀ i, (S i).Node → ↥(CompactElements D))
    (v : (forest S tag hroot).Node) (k : ↥(CompactElements D)) : Prop :=
  (v = (forest S tag hroot).root ∧ k = a) ∨
    ∃ i w, v = forestEmbed S tag hroot i w ∧ k = labels i w

theorem forest_label_exists (a : ↥(CompactElements D))
    (labels : ∀ i, (S i).Node → ↥(CompactElements D))
    (v : (forest S tag hroot).Node) : ∃ k, ForestLabelRelation S tag hroot a labels v k := by
  rcases forestNode_cases S tag hroot v with rfl | ⟨i, w, rfl⟩
  · exact ⟨a, Or.inl ⟨rfl, rfl⟩⟩
  · exact ⟨labels i w, Or.inr ⟨i, w, rfl, rfl⟩⟩

def forestLabel (a : ↥(CompactElements D))
    (labels : ∀ i, (S i).Node → ↥(CompactElements D)) :
    (forest S tag hroot).Node → ↥(CompactElements D) :=
  fun v => Classical.choose (forest_label_exists S tag hroot a labels v)

theorem forestLabel_spec (a : ↥(CompactElements D))
    (labels : ∀ i, (S i).Node → ↥(CompactElements D))
    (v : (forest S tag hroot).Node) :
    ForestLabelRelation S tag hroot a labels v (forestLabel S tag hroot a labels v) :=
  Classical.choose_spec (forest_label_exists S tag hroot a labels v)

theorem forestLabel_root (a : ↥(CompactElements D))
    (labels : ∀ i, (S i).Node → ↥(CompactElements D)) :
    forestLabel S tag hroot a labels (forest S tag hroot).root = a := by
  rcases forestLabel_spec S tag hroot a labels (forest S tag hroot).root with h | h
  · exact h.2
  · obtain ⟨i, w, heq, _⟩ := h
    exact (forestEmbed_ne_root S tag hroot i w heq.symm).elim

theorem forestLabel_embed (htag : Function.Injective tag) (a : ↥(CompactElements D))
    (labels : ∀ i, (S i).Node → ↥(CompactElements D)) (i : I) (v : (S i).Node) :
    forestLabel S tag hroot a labels (forestEmbed S tag hroot i v) = labels i v := by
  rcases forestLabel_spec S tag hroot a labels (forestEmbed S tag hroot i v) with h | h
  · exact (forestEmbed_ne_root S tag hroot i v h.1).elim
  · obtain ⟨j, w, heq, hk⟩ := h
    have hij : i = j := forestEmbed_index_eq S tag hroot htag v w heq
    subst j
    have hvw := forestEmbed_injective S tag hroot i heq
    simpa only [hvw] using hk

theorem forestLabel_pathImage (htag : Function.Injective tag) (a : ↥(CompactElements D))
    (labels : ∀ i, (S i).Node → ↥(CompactElements D)) (i : I) (v : (S i).Node) :
    labelImage (forest S tag hroot) (forestLabel S tag hroot a labels)
      ((forest S tag hroot).pathTo (forestEmbed S tag hroot i v)) =
      {(a : D)} ∪ labelImage (S i) (labels i) ((S i).pathTo v) := by
  rw [labelImage, forest_pathTo_embed S tag hroot htag i v,
    Set.image_union, Set.image_singleton, forestLabel_root, Set.image_image]
  congr 1
  apply Set.image_congr
  intro w _hw
  exact congrArg Subtype.val (forestLabel_embed S tag hroot htag a labels i w)

theorem contextual_forest (hD : IsScottDomain D) (htag : Function.Injective tag)
    (a : ↥(CompactElements D)) (W : Set D)
    (labels : ∀ i, (S i).Node → ↥(CompactElements D))
    (hW : W.Finite) (hWC : W ⊆ CompactElements D) (haW : (a : D) ∉ W)
    (hC : ∀ i, IsContextualMicTree hD (S i) (W ∪ {(a : D)}) (labels i))
    (hRoot : IsEmpty I → IsMinimallyInconsistent hD (W ∪ {(a : D)})) :
    IsContextualMicTree hD (forest S tag hroot) W (forestLabel S tag hroot a labels) := by
  classical
  let F := forest S tag hroot
  let L := forestLabel S tag hroot a labels
  have hLroot : forestLabel S tag hroot a labels (forest S tag hroot).root = a :=
    forestLabel_root S tag hroot a labels
  have hLembed (i : I) (w : (S i).Node) :
      forestLabel S tag hroot a labels (forestEmbed S tag hroot i w) = labels i w :=
    forestLabel_embed S tag hroot htag a labels i w
  have hrootpath : F.pathTo F.root = {F.root} := by
    ext x
    constructor
    · intro hx
      exact Set.mem_singleton_iff.mpr (Subtype.ext (List.prefix_nil.mp hx))
    · rintro rfl
      exact List.prefix_refl _
  refine ⟨hW, hWC, ?_, ?_, ?_⟩
  · intro x
    rcases forestNode_cases S tag hroot x with rfl | ⟨i, w, rfl⟩
    · simpa only [hLroot] using haW
    · rw [hLembed]
      exact fun hw => (hC i).2.2.1 w (Or.inl hw)
  · intro x
    rcases forestNode_cases S tag hroot x with rfl | ⟨i, v, rfl⟩
    · intro y hy z hz _heq
      rw [hrootpath] at hy hz
      exact (Set.mem_singleton_iff.mp hy).trans (Set.mem_singleton_iff.mp hz).symm
    · intro y hy z hz heq
      rw [forest_pathTo_embed S tag hroot htag i v] at hy hz
      rcases hy with hy | ⟨w, hw, hy⟩
      · have hyr : y = F.root := Set.mem_singleton_iff.mp hy
        subst y
        rcases hz with hz | ⟨w, hw, hz⟩
        · exact (Set.mem_singleton_iff.mp hz).symm
        · subst z
          have hval : (labels i w : D) = (a : D) := by
            simpa only [hLroot, hLembed] using (congrArg Subtype.val heq).symm
          exact ((hC i).2.2.1 w (Or.inr (Set.mem_singleton_iff.mpr hval))).elim
      · subst y
        rcases hz with hz | ⟨q, hq, hz⟩
        · have hzr : z = F.root := Set.mem_singleton_iff.mp hz
          subst z
          have hval : (labels i w : D) = (a : D) := by
            simpa only [hLroot, hLembed] using congrArg Subtype.val heq
          exact ((hC i).2.2.1 w (Or.inr (Set.mem_singleton_iff.mpr hval))).elim
        · subst z
          have hlabels : labels i w = labels i q := by simpa only [hLembed] using heq
          exact congrArg (forestEmbed S tag hroot i) ((hC i).2.2.2.1 v hw hq hlabels)
  · intro x hx
    rcases forestNode_cases S tag hroot x with rfl | ⟨i, v, rfl⟩
    · have hempty := (forest_root_isLeaf_iff S tag hroot).1 hx
      have himage : labelImage F L (F.pathTo F.root) = {(a : D)} := by
        dsimp only [L]
        rw [labelImage, hrootpath, Set.image_singleton, hLroot]
      rw [himage]
      exact hRoot hempty
    · have hv := (forestEmbed_isLeaf_iff S tag hroot htag i v).1 hx
      rw [forestLabel_pathImage S tag hroot htag a labels i v, ← Set.union_assoc]
      exact (hC i).2.2.2.2 v hv

theorem forestLabel_nonroot_basis (htag : Function.Injective tag)
    (a : ↥(CompactElements D)) (labels : ∀ i, (S i).Node → ↥(CompactElements D))
    (B : Set D) (hB : ∀ i x, (labels i x : D) ∈ B)
    (x : (forest S tag hroot).Node) (hx : x ≠ (forest S tag hroot).root) :
    (forestLabel S tag hroot a labels x : D) ∈ B := by
  rcases forestNode_cases S tag hroot x with h | ⟨i, w, rfl⟩
  · exact (hx h).elim
  · rw [forestLabel_embed S tag hroot htag a labels i w]
    exact hB i w

theorem pathTo_root_eq_singleton {Input : Type v} (T : RootedPrefixTree Input) :
    T.pathTo T.root = {T.root} := by
  ext x
  constructor
  · intro hx
    exact Set.mem_singleton_iff.mpr
      (@le_antisymm T.Node (prefixNodeOrder T) x T.root hx (T.root_le x))
  · rintro rfl
    exact List.prefix_refl _

theorem contextual_root_mic_of_no_children (hD : IsScottDomain D)
    {Input : Type v} (T : RootedPrefixTree Input) {W : Set D}
    {label : T.Node → ↥(CompactElements D)} (hC : IsContextualMicTree hD T W label)
    (hEmpty : IsEmpty {x : T.Node // T.IsChild T.root x}) :
    IsMinimallyInconsistent hD (W ∪ {(label T.root : D)}) := by
  have hleaf : T.IsLeaf T.root := by
    apply (T.isLeaf_iff_no_child T.root).2
    rintro ⟨x, hx⟩
    exact hEmpty.false ⟨x, hx⟩
  have h := hC.2.2.2.2 T.root hleaf
  simpa only [labelImage, pathTo_root_eq_singleton T, Set.image_singleton] using h

/-- The actual source-root rank is dominated by the actual graft rank when
each component dominates its corresponding actual immediate-child rank. -/
theorem forest_rank_dominates (Input : Type v) (T : RootedPrefixTree Input)
    (hT : T.IsWellFounded)
    (S : {x : T.Node // T.IsChild T.root x} → RootedPrefixTree A)
    (tag : {x : T.Node // T.IsChild T.root x} → A)
    (hroot : ∀ i, (S i).rootList = []) (htag : Function.Injective tag)
    (hS : ∀ i, (S i).IsWellFounded)
    (hRank : ∀ i, T.nodeRank hT i.val ≤ (S i).treeRank (hS i)) :
    T.treeRank hT ≤ (forest S tag hroot).treeRank
      (forest_isWellFounded S tag hroot htag hS) := by
  rw [forest_treeRank_eq S tag hroot htag hS]
  change T.nodeRank hT T.root ≤ _
  rw [T.nodeRank_eq hT T.root]
  apply Ordinal.iSup_le
  intro i
  exact (add_le_add (hRank i) (le_rfl : (1 : Ordinal.{v}) ≤ 1)).trans
    (Ordinal.le_iSup (fun i : {x : T.Node // T.IsChild T.root x} =>
      (S i).treeRank (hS i) + 1) i)

end DIDomainClassification.PointwiseFunctionSupport
