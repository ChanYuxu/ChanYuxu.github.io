import DIDomainClassification.Support.TreeSingletonBasis
import DIDomainClassification.Support.JoinBasisRefinement

/-!
Actual node maps obtained from singleton-labelled TreeDomain MIC trees. Maps
preserve complete branch SETS and are injective on every whole branch; they
are NOT assumed monotone or root preserving. General rank comparison is a
separate prerequisite and is not assumed/proved by this module.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeDomainDegree

open Preliminaries CoherenceDegree Trees PointwiseFunctionSupport

variable {Index : Type u} (T : RootedPrefixTree Index) (hp : T.IsProper)

def singletonNodeOf (X : TreeDomain T) (hX : X ∈ singletonNodes T hp) : T.Node :=
  Classical.choose hX

theorem nodePoint_singletonNodeOf (X : TreeDomain T) (hX : X ∈ singletonNodes T hp) :
    nodePoint T hp (singletonNodeOf T hp X hX) = X := Classical.choose_spec hX

def singletonLabelNodeMap {J : Type v}
    (M : MicTree (TreeDomain T) (treeScottDomain T hp) J)
    (hBasis : ∀ x, (M.label x).val ∈ singletonNodes T hp) : M.tree.Node → T.Node :=
  fun x => singletonNodeOf T hp (M.label x).val (hBasis x)

theorem nodePoint_singletonLabelNodeMap {J : Type v}
    (M : MicTree (TreeDomain T) (treeScottDomain T hp) J)
    (hBasis : ∀ x, (M.label x).val ∈ singletonNodes T hp) (x : M.tree.Node) :
    nodePoint T hp (singletonLabelNodeMap T hp M hBasis x) = (M.label x).val :=
  nodePoint_singletonNodeOf T hp (M.label x).val (hBasis x)

theorem singletonLabelNodeMap_image {J : Type v}
    (M : MicTree (TreeDomain T) (treeScottDomain T hp) J)
    (hBasis : ∀ x, (M.label x).val ∈ singletonNodes T hp) (c : Set M.tree.Node) :
    nodePoint T hp '' (singletonLabelNodeMap T hp M hBasis '' c) = labelImage M.tree M.label c := by
  rw [Set.image_image, labelImage]
  apply Set.image_congr
  intro x _hx
  exact nodePoint_singletonLabelNodeMap T hp M hBasis x

theorem singletonLabelNodeMap_completeBranches {J : Type v}
    (M : MicTree (TreeDomain T) (treeScottDomain T hp) J)
    (hBasis : ∀ x, (M.label x).val ∈ singletonNodes T hp)
    (c : Set M.tree.Node) (hc : M.tree.IsFiniteCompleteBranch c) :
    T.IsFiniteCompleteBranch (singletonLabelNodeMap T hp M hBasis '' c) := by
  apply (singleton_family_mic_iff T hp _).1
  rw [singletonLabelNodeMap_image T hp M hBasis c]
  exact M.isMicTree.finiteBranch_mic hc

theorem singletonLabelNodeMap_branchInjective {J : Type v}
    (M : MicTree (TreeDomain T) (treeScottDomain T hp) J)
    (hBasis : ∀ x, (M.label x).val ∈ singletonNodes T hp)
    (c : Set M.tree.Node) (hc : M.tree.IsBranch c) :
    Set.InjOn (singletonLabelNodeMap T hp M hBasis) c := by
  intro x hx y hy hxy
  have hpoints : (M.label x).val = (M.label y).val :=
    (nodePoint_singletonLabelNodeMap T hp M hBasis x).symm.trans
      ((congrArg (nodePoint T hp) hxy).trans (nodePoint_singletonLabelNodeMap T hp M hBasis y))
  exact M.isMicTree.branchInjective hc hx hy (Subtype.ext hpoints)

/-- For EVERY source alphabet and WF MIC tree in the literal tree domain,
construct a basis refinement of at least its rank and a genuine complete-
branch-set preserving map into T. No root-image or rank comparison is assumed.
-/
theorem exists_branch_map_refinement {J : Type v}
    (M : MicTree (TreeDomain T) (treeScottDomain T hp) J) (hM : M.tree.IsWellFounded) :
    ∃ (R : RootedPrefixTree (ULift.{v} ℕ)) (hR : R.IsWellFounded)
      (_hProper : R.IsProper) (f : R.Node → T.Node),
      M.tree.treeRank hM ≤ R.treeRank hR ∧
      (∀ c : Set R.Node, R.IsFiniteCompleteBranch c → T.IsFiniteCompleteBranch (f '' c)) ∧
      ∀ c : Set R.Node, R.IsBranch c → Set.InjOn f c := by
  have hContext := contextual_of_micTree (treeScottDomain T hp) M hM
  obtain ⟨R, hR, labels, _hRoot, hRcontext, hBasis, hRank⟩ :=
    finiteJoinBasis_refinement (treeScottDomain T hp) (singletonNodes T hp)
      (singletonNodes_isFiniteJoinBasis T hp) M.tree hM ∅ M.label hContext
  have hProper : R.IsProper := contextual_empty_isProper (treeScottDomain T hp) R hR hRcontext
  let N : MicTree (TreeDomain T) (treeScottDomain T hp) (ULift.{v} ℕ) := {
    tree := R
    proper := hProper
    label := labels
    isMicTree := contextual_isMicTree (treeScottDomain T hp) R hRcontext hProper }
  let f := singletonLabelNodeMap T hp N hBasis
  exact ⟨R, hR, hProper, f, hRank,
    singletonLabelNodeMap_completeBranches T hp N hBasis,
    singletonLabelNodeMap_branchInjective T hp N hBasis⟩

end DIDomainClassification.TreeDomainDegree
