import Mathlib.SetTheory.Ordinal.Family

/-! Generic ordinal cuts for small families of objects. A caller must prove
validity and downward closure; no domain classification is assumed here. -/
set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.OrdinalObjectCut
variable {ι : Type v} [Small.{u} ι]

def cutOrdinal (d : ι → Ordinal.{u}) (P : ι → Prop) : Ordinal.{u} :=
  ⨆ i : {i // P i}, d i.val + 1

theorem below_cut_iff (d : ι → Ordinal.{u}) (P : ι → Prop) (a : Ordinal.{u}) :
    a < cutOrdinal d P ↔ ∃ i, P i ∧ a ≤ d i := by
  change a < ⨆ i : {i // P i}, d i.val + 1 ↔ _
  rw [Ordinal.lt_iSup_add_one_iff]
  constructor
  · rintro ⟨⟨i,hi⟩,h⟩
    exact ⟨i,hi,h⟩
  · rintro ⟨i,hi,h⟩
    exact ⟨⟨i,hi⟩,h⟩

theorem member_below_cut (d : ι → Ordinal.{u}) (P : ι → Prop) {i : ι} (hi : P i) :
    d i < cutOrdinal d P :=
  Ordinal.lt_iSup_add_one (fun j : {j // P j} => d j.val) ⟨i,hi⟩

theorem succ_le_cut (d : ι → Ordinal.{u}) (P : ι → Prop) {i : ι} (hi : P i) :
    d i + 1 ≤ cutOrdinal d P :=
  Ordinal.le_iSup (fun j : {j // P j} => d j.val + 1) ⟨i,hi⟩

theorem cut_le (d : ι → Ordinal.{u}) (P : ι → Prop) (a : Ordinal.{u})
    (h : ∀ i, P i → d i < a) : cutOrdinal d P ≤ a :=
  Ordinal.iSup_add_one_le (fun i : {i // P i} => h i.val i.property)

theorem mem_cut_iff (d : ι → Ordinal.{u}) (P V : ι → Prop)
    (hV : ∀ i, P i → V i)
    (hDown : ∀ i j, V i → d i ≤ d j → P j → P i) (i : ι) :
    P i ↔ V i ∧ d i < cutOrdinal d P := by
  constructor
  · intro hi
    exact ⟨hV i hi,member_below_cut d P hi⟩
  · rintro ⟨hVi,hi⟩
    obtain ⟨j,hPj,hij⟩ := (below_cut_iff d P (d i)).mp hi
    exact hDown i j hVi hij hPj

theorem class_eq_cut (d : ι → Ordinal.{u}) (P V : ι → Prop)
    (hV : ∀ i, P i → V i)
    (hDown : ∀ i j, V i → d i ≤ d j → P j → P i) :
    P = fun i => V i ∧ d i < cutOrdinal d P := by
  funext i
  exact propext (mem_cut_iff d P V hV hDown i)

end DIDomainClassification.OrdinalObjectCut
