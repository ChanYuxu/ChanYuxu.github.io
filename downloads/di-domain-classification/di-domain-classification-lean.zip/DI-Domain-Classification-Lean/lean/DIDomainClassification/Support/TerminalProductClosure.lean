import DIDomainClassification.Section02.StableBackgroundStatement
import DIDomainClassification.Section02.CountableProducts
import DIDomainClassification.Support.OrderIsoTransport

/-! Literal unit and binary-product dI closure, without exponential assumptions. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.TerminalProductClosure

open Preliminaries

private theorem unit_le (x y : PUnit.{u + 1}) : x ≤ y :=
  le_of_eq (Subsingleton.elim x y)

theorem unit_isLUB (S : Set PUnit.{u + 1}) (x : PUnit.{u + 1}) : IsLUB S x :=
  ⟨fun _ _ => unit_le _ _, fun _ _ => unit_le _ _⟩

theorem unit_compact (x : PUnit.{u + 1}) : IsCompactElement x := by
  intro B s hB _hs _hxs
  obtain ⟨b, hb⟩ := hB.1
  exact ⟨b, hb, unit_le _ _⟩

theorem unit_algebraic : IsAlgebraicDcpo PUnit.{u + 1} := by
  constructor
  · intro B _hB
    exact ⟨PUnit.unit, unit_isLUB B PUnit.unit⟩
  · intro x
    refine ⟨⟨⟨x, unit_compact x, le_rfl⟩, ?_⟩, unit_isLUB _ x⟩
    intro a _ha b _hb
    exact ⟨x, ⟨unit_compact x, le_rfl⟩, unit_le _ _, unit_le _ _⟩

theorem unit_isDIDomain : IsDIDomain PUnit.{u + 1} where
  toIsScottDomain := {
    algebraic := unit_algebraic
    hasLeast := ⟨PUnit.unit, fun x => unit_le _ x⟩
    boundedSuprema := fun S _ => ⟨PUnit.unit, unit_isLUB S PUnit.unit⟩ }
  distributive := by
    intro _x _y _z _joined meet left right _hcompat _hj _hm _hl _hr
    exact unit_isLUB {left, right} meet
  finitePrincipalIdeals := fun _ _ => Set.finite_univ.subset (Set.subset_univ _)

theorem unit_isCountablyBasedDIDomain : IsCountablyBasedDIDomain PUnit.{u + 1} :=
  ⟨unit_isDIDomain, Set.to_countable _⟩

abbrev Obj := CountablyBasedDIDomain.{u}
abbrev Core (D : Obj.{u}) := D.toDIDomainObject

def Family (D E : Obj.{u}) : Bool → Type u
  | false => Core D
  | true => Core E

instance familyPartialOrder (D E : Obj.{u}) (b : Bool) : PartialOrder (Family D E b) := by
  cases b
  · change PartialOrder (Core D)
    infer_instance
  · change PartialOrder (Core E)
    infer_instance

/-- Exact literal product, with its original coordinatewise order. -/
def productPiOrderIso (D E : Obj.{u}) : (∀ b : Bool, Family D E b) ≃o (Core D × Core E) where
  toFun f := (f false, f true)
  invFun p := fun b => match b with
    | false => p.1
    | true => p.2
  left_inv f := by
    funext b
    cases b <;> rfl
  right_inv _p := rfl
  map_rel_iff' := by
    intro f g
    constructor
    · intro h b
      cases b
      · exact h.1
      · exact h.2
    · intro h
      exact ⟨h false, h true⟩

theorem family_isCountablyBasedDIDomain (D E : Obj.{u}) (b : Bool) :
    IsCountablyBasedDIDomain (Family D E b) := by
  cases b
  · exact ⟨(Core D).isDIDomain, D.countableCompacts⟩
  · exact ⟨(Core E).isDIDomain, E.countableCompacts⟩

theorem product_isCountablyBasedDIDomain (D E : Obj.{u}) :
    IsCountablyBasedDIDomain (Core D × Core E) := by
  have hPi : IsCountablyBasedDIDomain (∀ b : Bool, Family D E b) :=
    (Section02.countableProducts Bool (Family D E) (family_isCountablyBasedDIDomain D E)).1
  exact (OrderIsoTransport.isCountablyBasedDIDomain_iff (productPiOrderIso D E)).mp hPi

end DIDomainClassification.TerminalProductClosure
