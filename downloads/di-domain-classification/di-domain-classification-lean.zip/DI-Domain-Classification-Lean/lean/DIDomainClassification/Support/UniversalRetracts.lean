import DIDomainClassification.Section02.StableBackground
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section03.StableFunctionModels
import DIDomainClassification.Support.StableMapOperators

/-! Actual contravariant exponential splits. Higher-order composition and
pairing are taken from the proved public stable-background construction.
All exponential carriers and orders remain literal; different DomainClosure
arguments are proof certificates of the same proposition, not new models.
-/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.UniversalRetracts
open Section03.StableFunctionModels

def backgroundPrecompose (C : Section02.StableBackground.DomainClosure.{u})
    (K : Section02.StableBackground.CartesianClosedConstruction C)
    (A D E : CountablyBasedDIDomain.{u}) (r : StableHom (Core A) (Core D)) :
    StableHom (Core (exponential D E)) (Core (exponential A E)) :=
  StableHom.comp (K.composition A D E)
    (K.pair (exponential D E) (exponential D E) (exponential A D)
      (StableHom.id _)
      (StableMapOperators.constant (exponential D E) (exponential A D) r))

theorem backgroundPrecompose_apply (C : Section02.StableBackground.DomainClosure.{u})
    (K : Section02.StableBackground.CartesianClosedConstruction C)
    (A D E : CountablyBasedDIDomain.{u}) (r : StableHom (Core A) (Core D))
    (f : StableHom (Core D) (Core E)) (x : Core A) :
    backgroundPrecompose C K A D E r f x = f (r x) := by
  simp only [backgroundPrecompose, StableHom.comp_apply, K.composition_apply,
    K.pair_apply, StableHom.id_apply, StableMapOperators.constant_apply]

theorem domainExponentialRetraction (H W E : CountablyBasedDIDomain.{u})
    (hHW : HasStableRetraction (Core H) (Core W)) :
    HasStableRetraction (Core (exponential H E)) (Core (exponential W E)) := by
  obtain ⟨i, p, hpi⟩ := hHW
  obtain ⟨C, ⟨K⟩, _hSup, _hMeet⟩ := Section02.stableBackground.{u}
  refine ⟨backgroundPrecompose C K W H E p, backgroundPrecompose C K H W E i, ?_⟩
  intro f
  apply StableHom.ext
  intro x
  rw [backgroundPrecompose_apply, backgroundPrecompose_apply, hpi x]

end DIDomainClassification.UniversalRetracts
