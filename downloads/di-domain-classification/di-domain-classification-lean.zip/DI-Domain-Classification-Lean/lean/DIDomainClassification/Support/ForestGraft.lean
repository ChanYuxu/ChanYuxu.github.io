import DIDomainClassification.Support.RelativeSubtree
import Mathlib.Data.Countable.Small

/-! Literal normalized-root forest grafting over an arbitrary alphabet.
Only the component INDEX is countable, and each supplied tree counts its own
nodes. Tags need only be injective for the structural/rank theorems; no global
countability or order on the alphabet is assumed. Empty forests retain a root.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.TreeGrafting

open Trees
open FiniteLeafColourPruning (nodeRank_le_of_childMap nodeRank_add_one_le_of_child)

variable {Index : Type u} {Component : Type v}

def forestNodes (S : Component → RootedPrefixTree Index) (tag : Component → Index) :
    Set (List Index) := {[]} ∪ ⋃ i, List.cons (tag i) '' (S i).nodes

theorem mem_forestNodes (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (v : List Index) :
    v ∈ forestNodes S tag ↔ v = [] ∨ ∃ (i : Component) (w : (S i).Node),
      v = tag i :: w.val := by
  constructor
  · intro hv
    rcases hv with hv | hv
    · exact Or.inl (Set.mem_singleton_iff.mp hv)
    · obtain ⟨i, hi⟩ := Set.mem_iUnion.mp hv
      obtain ⟨w, hw, hv⟩ := hi
      exact Or.inr ⟨i, ⟨w, hw⟩, hv.symm⟩
  · rintro (rfl | ⟨i, w, rfl⟩)
    · exact Or.inl (Set.mem_singleton _)
    · exact Or.inr (Set.mem_iUnion.mpr ⟨i, ⟨w.val, w.property, rfl⟩⟩)

def forest (S : Component → RootedPrefixTree Index) (tag : Component → Index)
    [Countable Component] (hroot : ∀ i, (S i).rootList = []) : RootedPrefixTree Index where
  nodes := forestNodes S tag
  rootList := []
  root_mem := (mem_forestNodes S tag []).mpr (Or.inl rfl)
  root_prefix := fun _ => List.nil_prefix
  prefix_closed := by
    intro v w _hroot hvw hw
    apply (mem_forestNodes S tag v).mpr
    rcases (mem_forestNodes S tag w).mp hw with rfl | ⟨i, z, rfl⟩
    · exact Or.inl (List.prefix_nil.mp hvw)
    · cases v with
      | nil => exact Or.inl rfl
      | cons a v =>
        obtain ⟨rfl, hvz⟩ := List.cons_prefix_cons.mp hvw
        have hv : v ∈ (S i).nodes := (S i).prefix_closed
          (by rw [hroot i]; exact List.nil_prefix) hvz z.property
        exact Or.inr ⟨i, ⟨v, hv⟩, rfl⟩
  countable_nodes := (Set.finite_singleton ([] : List Index)).countable.union
    (Set.countable_iUnion (fun i => (S i).countable_nodes.image (List.cons (tag i))))

variable [Countable Component]

def forestEmbed (S : Component → RootedPrefixTree Index) (tag : Component → Index)
    (hroot : ∀ i, (S i).rootList = []) (i : Component) (v : (S i).Node) :
    (forest S tag hroot).Node :=
  ⟨tag i :: v.val, (mem_forestNodes S tag _).mpr (Or.inr ⟨i, v, rfl⟩)⟩

theorem forestEmbed_val (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (i : Component) (v : (S i).Node) :
    (forestEmbed S tag hroot i v).val = tag i :: v.val := rfl

theorem forestNode_cases (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (v : (forest S tag hroot).Node) :
    v = (forest S tag hroot).root ∨ ∃ i w, v = forestEmbed S tag hroot i w := by
  rcases (mem_forestNodes S tag v.val).mp v.property with hv | ⟨i, w, hv⟩
  · exact Or.inl (Subtype.ext hv)
  · exact Or.inr ⟨i, w, Subtype.ext hv⟩

theorem forestEmbed_ne_root (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (i : Component) (v : (S i).Node) :
    forestEmbed S tag hroot i v ≠ (forest S tag hroot).root := by
  intro h
  have hval : tag i :: v.val = ([] : List Index) :=
    congrArg (fun z : (forest S tag hroot).Node => z.val) h
  cases hval

theorem forestEmbed_injective (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = []) (i : Component) :
    Function.Injective (forestEmbed S tag hroot i) := by
  intro v w h
  exact Subtype.ext (List.cons.inj
    (congrArg (fun z : (forest S tag hroot).Node => z.val) h)).2

theorem forestEmbed_index_eq (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) {i j : Component} (v : (S i).Node) (w : (S j).Node)
    (h : forestEmbed S tag hroot i v = forestEmbed S tag hroot j w) : i = j :=
  htag (List.cons.inj (congrArg (fun z : (forest S tag hroot).Node => z.val) h)).1

theorem forestEmbed_isChild_iff (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (i : Component) (v w : (S i).Node) :
    (forest S tag hroot).IsChild (forestEmbed S tag hroot i v) (forestEmbed S tag hroot i w) ↔
      (S i).IsChild v w := by
  rw [isChild_iff_prefix_length, isChild_iff_prefix_length]
  constructor
  · rintro ⟨hp, hl⟩
    refine ⟨(List.cons_prefix_cons.mp hp).2, ?_⟩
    change (tag i :: w.val).length = (tag i :: v.val).length + 1 at hl
    simp only [List.length_cons] at hl
    omega
  · rintro ⟨hp, hl⟩
    refine ⟨List.cons_prefix_cons.mpr ⟨rfl, hp⟩, ?_⟩
    change (tag i :: w.val).length = (tag i :: v.val).length + 1
    simp only [List.length_cons]
    omega

theorem forestEmbed_root_child (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = []) (i : Component) :
    (forest S tag hroot).IsChild (forest S tag hroot).root
      (forestEmbed S tag hroot i (S i).root) := by
  apply (isChild_iff_prefix_length _ _ _).mpr
  refine ⟨List.nil_prefix, ?_⟩
  change (tag i :: (S i).rootList).length = 0 + 1
  simp only [hroot i, List.length_cons, List.length_nil]

theorem forest_child_root (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    {v : (forest S tag hroot).Node}
    (hv : (forest S tag hroot).IsChild (forest S tag hroot).root v) :
    ∃ i, v = forestEmbed S tag hroot i (S i).root := by
  rcases forestNode_cases S tag hroot v with rfl | ⟨i, w, rfl⟩
  · exact ((forest S tag hroot).isChild_irrefl _ hv).elim
  · have hl := ((isChild_iff_prefix_length _ _ _).mp hv).2
    change (tag i :: w.val).length = 0 + 1 at hl
    have hwlen : w.val.length = 0 := by simp only [List.length_cons] at hl; omega
    have hwval : w.val = [] := by
      cases heq : w.val with
      | nil => rfl
      | cons a tail => simp only [heq, List.length_cons] at hwlen; omega
    have hw : w = (S i).root := Subtype.ext (hwval.trans (hroot i).symm)
    exact ⟨i, congrArg (forestEmbed S tag hroot i) hw⟩

theorem forest_child_of_embed (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) {i : Component} (v : (S i).Node)
    {y : (forest S tag hroot).Node}
    (hvy : (forest S tag hroot).IsChild (forestEmbed S tag hroot i v) y) :
    ∃ w : (S i).Node, (S i).IsChild v w ∧ y = forestEmbed S tag hroot i w := by
  rcases forestNode_cases S tag hroot y with rfl | ⟨j, w, rfl⟩
  · have hp : tag i :: v.val <+: ([] : List Index) := hvy.1
    have hnil := List.prefix_nil.mp hp
    cases hnil
  · have hp := List.cons_prefix_cons.mp hvy.1
    have hij : i = j := htag hp.1
    subst j
    exact ⟨w, (forestEmbed_isChild_iff S tag hroot i v w).mp hvy, rfl⟩

theorem forestEmbed_isLeaf_iff (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (i : Component) (v : (S i).Node) :
    (forest S tag hroot).IsLeaf (forestEmbed S tag hroot i v) ↔ (S i).IsLeaf v := by
  rw [(forest S tag hroot).isLeaf_iff_no_child, (S i).isLeaf_iff_no_child]
  constructor
  · intro h ⟨w, hw⟩
    exact h ⟨forestEmbed S tag hroot i w, (forestEmbed_isChild_iff S tag hroot i v w).mpr hw⟩
  · intro h ⟨y, hy⟩
    obtain ⟨w, hw, _⟩ := forest_child_of_embed S tag hroot htag v hy
    exact h ⟨w, hw⟩

theorem forest_root_isLeaf_iff (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = []) :
    (forest S tag hroot).IsLeaf (forest S tag hroot).root ↔ IsEmpty Component := by
  constructor
  · intro h
    exact ⟨fun i => forestEmbed_ne_root S tag hroot i (S i).root
      (h _ ((forest S tag hroot).root_le _))⟩
  · intro h v _hv
    rcases forestNode_cases S tag hroot v with hv | ⟨i, _⟩
    · exact hv
    · exact (h.false i).elim

theorem forestEmbed_acc (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (hS : ∀ i, (S i).IsWellFounded)
    (i : Component) (v : (S i).Node) :
    Acc (forest S tag hroot).ReverseChildRelation (forestEmbed S tag hroot i v) := by
  refine ((S i).isWellFounded_iff_wellFounded_reverseChildRelation.mp (hS i)).induction
    (C := fun v : (S i).Node =>
      Acc (forest S tag hroot).ReverseChildRelation (forestEmbed S tag hroot i v)) v ?_
  intro v ih
  constructor
  intro y hy
  obtain ⟨w, hw, rfl⟩ := forest_child_of_embed S tag hroot htag v hy
  exact ih w hw

theorem forest_isWellFounded (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (hS : ∀ i, (S i).IsWellFounded) :
    (forest S tag hroot).IsWellFounded := by
  apply (forest S tag hroot).isWellFounded_iff_wellFounded_reverseChildRelation.mpr
  have hrootAcc : Acc (forest S tag hroot).ReverseChildRelation (forest S tag hroot).root := by
    constructor
    intro y hy
    obtain ⟨i, rfl⟩ := forest_child_root S tag hroot hy
    exact forestEmbed_acc S tag hroot htag hS i (S i).root
  constructor
  intro v
  rcases forestNode_cases S tag hroot v with rfl | ⟨i, w, rfl⟩
  · exact hrootAcc
  · exact forestEmbed_acc S tag hroot htag hS i w

theorem forestEmbed_nodeRank_eq (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (hS : ∀ i, (S i).IsWellFounded)
    (i : Component) (v : (S i).Node) :
    (forest S tag hroot).nodeRank (forest_isWellFounded S tag hroot htag hS)
      (forestEmbed S tag hroot i v) = (S i).nodeRank (hS i) v := by
  let hF := forest_isWellFounded S tag hroot htag hS
  refine ((S i).isWellFounded_iff_wellFounded_reverseChildRelation.mp (hS i)).induction
    (C := fun v : (S i).Node =>
      (forest S tag hroot).nodeRank hF (forestEmbed S tag hroot i v) =
        (S i).nodeRank (hS i) v) v ?_
  intro v ih
  apply le_antisymm
  · rw [(forest S tag hroot).nodeRank_eq hF (forestEmbed S tag hroot i v)]
    apply Ordinal.iSup_le
    intro y
    obtain ⟨w, hw, heq⟩ := forest_child_of_embed S tag hroot htag v y.property
    have heqRank := congrArg ((forest S tag hroot).nodeRank hF) heq
    exact (add_le_add (heqRank.trans (ih w hw)).le (le_rfl : (1 : Ordinal.{u}) ≤ 1)).trans
      (nodeRank_add_one_le_of_child (S i) (hS i) hw)
  · exact nodeRank_le_of_childMap (S i) (forest S tag hroot) (hS i) hF
      (forestEmbed S tag hroot i)
      (fun hvw => (forestEmbed_isChild_iff S tag hroot i _ _).mpr hvw) v

theorem forest_treeRank_eq (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (hS : ∀ i, (S i).IsWellFounded) :
    (forest S tag hroot).treeRank (forest_isWellFounded S tag hroot htag hS) =
      ⨆ i : Component, (S i).treeRank (hS i) + 1 := by
  let hF := forest_isWellFounded S tag hroot htag hS
  apply le_antisymm
  · change (forest S tag hroot).nodeRank hF (forest S tag hroot).root ≤ _
    rw [(forest S tag hroot).nodeRank_eq hF (forest S tag hroot).root]
    apply Ordinal.iSup_le
    intro y
    obtain ⟨i, heq⟩ := forest_child_root S tag hroot y.property
    have hr := congrArg ((forest S tag hroot).nodeRank hF) heq
    exact (add_le_add (hr.trans (forestEmbed_nodeRank_eq S tag hroot htag hS i (S i).root)).le
      (le_rfl : (1 : Ordinal.{u}) ≤ 1)).trans
        (Ordinal.le_iSup (fun i : Component => (S i).treeRank (hS i) + 1) i)
  · apply Ordinal.iSup_le
    intro i
    change (S i).nodeRank (hS i) (S i).root + 1 ≤
      (forest S tag hroot).nodeRank hF (forest S tag hroot).root
    have h := nodeRank_add_one_le_of_child (forest S tag hroot) hF
      (forestEmbed_root_child S tag hroot i)
    have heq : (forest S tag hroot).nodeRank hF
        (forestEmbed S tag hroot i (S i).root) = (S i).nodeRank (hS i) (S i).root :=
      forestEmbed_nodeRank_eq S tag hroot htag hS i (S i).root
    rw [heq] at h
    exact h

theorem forest_pathTo_embed (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (i : Component) (v : (S i).Node) :
    (forest S tag hroot).pathTo (forestEmbed S tag hroot i v) =
      {(forest S tag hroot).root} ∪ forestEmbed S tag hroot i '' (S i).pathTo v := by
  ext w
  constructor
  · intro hw
    rcases forestNode_cases S tag hroot w with rfl | ⟨j, z, rfl⟩
    · exact Or.inl (Set.mem_singleton _)
    · have hp := List.cons_prefix_cons.mp hw
      have hji : j = i := htag hp.1
      subst j
      exact Or.inr ⟨z, hp.2, rfl⟩
  · rintro (hw | ⟨z, hz, rfl⟩)
    · have hw' := Set.mem_singleton_iff.mp hw
      subst w
      exact (forest S tag hroot).root_le _
    · exact List.cons_prefix_cons.mpr ⟨rfl, hz⟩

theorem forest_finiteCompleteBranch (S : Component → RootedPrefixTree Index)
    (tag : Component → Index) (hroot : ∀ i, (S i).rootList = [])
    (htag : Function.Injective tag) (i : Component) (c : Set (S i).Node)
    (hc : (S i).IsFiniteCompleteBranch c) :
    (forest S tag hroot).IsFiniteCompleteBranch
      ({(forest S tag hroot).root} ∪ forestEmbed S tag hroot i '' c) := by
  obtain ⟨v, hv, rfl⟩ := hc
  exact ⟨forestEmbed S tag hroot i v, (forestEmbed_isLeaf_iff S tag hroot htag i v).mpr hv,
    (forest_pathTo_embed S tag hroot htag i v).symm⟩

end DIDomainClassification.TreeGrafting

