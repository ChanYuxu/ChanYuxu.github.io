import DIDomainClassification.Support.ZhaoKouCodes
import DIDomainClassification.Section03.FunctionDegree
import DIDomainClassification.Section02.BPS

/-! Positive degree computations for the actual U and W models. A lifted
index is used only in the generic product-degree application; an explicit
coordinate-preserving order isomorphism returns to the literal natural power. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.UniversalDegreeModels

open Preliminaries CoherenceDegree Subcategories FiniteOrderDomains TwoExponentialOrderIso
open Section02 Section03 Section03.StableFunctionModels
open Section04.AdditionalSourceModels ZhaoKouCodes

theorem degree_orderIso {D E : Type u} [PartialOrder D] [PartialOrder E]
    (e : D ≃o E) (hD : IsScottDomain D) (hE : IsScottDomain E) :
    coherenceDegree hD = coherenceDegree hE := by
  apply le_antisymm
  · exact coherenceDegree_mono_of_scott_split hD hE
      (OrderIsoTransport.scottContinuous e) (OrderIsoTransport.scottContinuous e.symm)
      e.symm_apply_apply
  · exact coherenceDegree_mono_of_scott_split hE hD
      (OrderIsoTransport.scottContinuous e.symm) (OrderIsoTransport.scottContinuous e)
      e.apply_symm_apply

theorem two_degree_zero : objectDegree twoObject.{u} = 0 := by
  letI : CompleteDistribLattice TwoCarrier.{u} := Fintype.toCompleteDistribLattice _
  apply (BPSProof.degreeZeroIffCompleteLattice TwoCarrier.{u}
    two_isCountablyBased.1.toIsScottDomain two_isCountablyBased.2).mpr
  intro X
  exact ⟨⟨sSup X, isLUB_sSup X⟩, ⟨sInf X, isGLB_sInf X⟩⟩

theorem two_exponential_degree : objectDegree (exponential twoObject.{u} twoObject.{u}) = 2 := by
  have h := functionDegreeNontrivial twoObject.{u} twoObject.{u}
    ⟨⟨zero, one, zero_ne_one⟩⟩ ⟨⟨zero, one, zero_ne_one⟩⟩
  change objectDegree (exponential twoObject.{u} twoObject.{u}) =
    max (2 : Ordinal.{u+1}) (objectDegree twoObject.{u}) at h
  rw [two_degree_zero] at h
  exact h.trans (max_eq_left bot_le)

theorem cube_degree : coherenceDegree cubeCountablyBased.{u}.1.toIsScottDomain = 2 := by
  have hIso := degree_orderIso TwoExponentialOrderIso.orderIso.{u}
    (Core (exponential twoObject.{u} twoObject.{u})).isDIDomain.toIsScottDomain
    cubeCountablyBased.{u}.1.toIsScottDomain
  exact hIso.symm.trans two_exponential_degree

def naturalPowerLiftedOrderIso : UniversalBaseCarrier.{u} ≃o (ULift.{u} ℕ → Cube.{u}) where
  toFun x i := x i.down
  invFun y n := y ⟨n⟩
  left_inv _ := rfl
  right_inv y := by
    funext i
    cases i
    rfl
  map_rel_iff' := by
    intro x y
    constructor
    · intro h n
      exact h ⟨n⟩
    · intro h i
      exact h i.down

theorem base_degree : objectDegree baseObject.{u} = 2 := by
  obtain ⟨hProduct, _hK, hDegree⟩ := BPSProof.countableProductDegree
    (ULift.{u} ℕ) (fun _ => Cube.{u})
    (fun _ => cubeCountablyBased.{u}.1.toIsScottDomain)
    (fun _ => cubeCountablyBased.{u}.2)
  have hLifted : coherenceDegree hProduct = 2 := by
    rw [hDegree]
    simp only [cube_degree, ciSup_const]
  exact (degree_orderIso naturalPowerLiftedOrderIso
    baseCertificate.{u}.1.toIsScottDomain hProduct).trans hLifted

theorem base_nontrivial : Nontrivial (Core baseObject.{u}) := by
  refine ⟨⟨fun _ => emptyCube, fun _ => atomOneCube, ?_⟩⟩
  intro h
  exact empty_ne_atomOne (congrFun h 0)

theorem W_degree : objectDegree (universalTwoObject baseCertificate.{u}) = 2 := by
  have h := functionDegreeNontrivial baseObject.{u} baseObject.{u}
    base_nontrivial base_nontrivial
  change objectDegree (universalTwoObject baseCertificate.{u}) =
    max (2 : Ordinal.{u+1}) (objectDegree baseObject.{u}) at h
  rw [base_degree, max_self] at h
  exact h

theorem W_twoCoherent : IsNCoherent
    (Core (universalTwoObject baseCertificate.{u})).isDIDomain.toIsScottDomain 2 (by decide) := by
  apply (BPSProof.finiteDegreeIffCoherent
    (Core (universalTwoObject baseCertificate.{u}))
    (Core (universalTwoObject baseCertificate.{u})).isDIDomain.toIsScottDomain
    (universalTwoObject baseCertificate.{u}).countableCompacts 2 (by decide)).mp
  exact W_degree.le

end DIDomainClassification.UniversalDegreeModels
