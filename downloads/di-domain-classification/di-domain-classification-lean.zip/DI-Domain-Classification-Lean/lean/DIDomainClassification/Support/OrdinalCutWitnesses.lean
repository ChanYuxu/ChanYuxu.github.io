import DIDomainClassification.Support.FiniteCubeRetractions
import DIDomainClassification.Support.SingletonForbiddenDomains
import DIDomainClassification.Support.QualitativeConfigurationMIC
import DIDomainClassification.Support.CompactMicChains
import DIDomainClassification.Support.ForestProductMaps
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Section02.DegreeRealizability

/-! Concrete witnesses for the source ordinal cuts. Proper-subset cubes retain
their literal ULift carrier; the infinite witness is the literal lifted powerset
of the naturals. Domain, finiteness and degree assertions are proved outputs. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.OrdinalCutWitnesses

open Preliminaries CoherenceDegree Subcategories EventStructures
open Section04.FiniteCategoryModels Section04.AdditionalSourceModels
open FiniteCubeRetractions

theorem bounded_image_orderIso {D : Type u} {E : Type v}
    [PartialOrder D] [PartialOrder E] (q : D ≃o E) (M : Set D) :
    BddAbove (q '' M) ↔ BddAbove M := by
  constructor
  · rintro ⟨y, hy⟩
    refine ⟨q.symm y, ?_⟩
    intro x hx
    simpa only [q.symm_apply_apply] using q.symm.monotone (hy ⟨x, hx, rfl⟩)
  · rintro ⟨x, hx⟩
    refine ⟨q x, ?_⟩
    rintro _ ⟨z, hz, rfl⟩
    exact q.monotone (hx hz)

theorem mic_image_orderIso {D : Type u} {E : Type v}
    [PartialOrder D] [PartialOrder E] (q : D ≃o E)
    (hD : IsScottDomain D) (hE : IsScottDomain E) {M : Set D}
    (hM : IsMinimallyInconsistent hD M) :
    IsMinimallyInconsistent hE (q '' M) :=
  CompactRetractLift.finite_minimally_unbounded_image (bounded_image_orderIso q) hM

/-- Finite MIC coherence is invariant under the actual order isomorphism,
even when the two carriers are in different universes. -/
theorem nCoherent_orderIso {D : Type u} {E : Type v}
    [PartialOrder D] [PartialOrder E] (q : D ≃o E)
    (hD : IsScottDomain D) (hE : IsScottDomain E)
    (n : ℕ) (hn : 2 ≤ n) (h : IsNCoherent hE n hn) :
    IsNCoherent hD n hn := by
  intro M hM
  have hb := h (q '' M) (mic_image_orderIso q hD hE hM)
  simpa only [Set.ncard_image_of_injective M q.injective] using hb

theorem cube_nCoherent (n : ℕ) (hn : 2 ≤ n) :
    IsNCoherent (cubeCountablyBased.{u} n hn).1.toIsScottDomain n hn := by
  let H := forbidden n
  let hH := forbidden_admissible n hn
  letI : PartialOrder (Fin n) := ForbiddenFiniteDomains.equalityOrder (Fin n)
  let E := ForbiddenFiniteDomains.eventStructure H hH
  let hE := ConfigurationDomain.dIDomain E
  have hN : IsNCoherent hE.toIsScottDomain n hn := by
    apply (QualitativeConfigurationMIC.nCoherent_iff_conflict_bound E
      hE.toIsScottDomain n hn).mpr
    intro K _hK
    have hb := Set.ncard_le_ncard (Set.subset_univ K)
    simpa only [Set.ncard_univ, Nat.card_fin] using hb
  let q := (avoidanceOrderIso.{u} n hn).trans
    (ForbiddenFiniteDomains.configurationOrderIso H hH).symm
  exact nCoherent_orderIso q (cubeCountablyBased n hn).1.toIsScottDomain
    hE.toIsScottDomain n hn hN

theorem cube_degree (n : ℕ) (hn : 2 ≤ n) :
    coherenceDegree (cubeCountablyBased.{u} n hn).1.toIsScottDomain =
      (n : Ordinal.{u+1}) := by
  apply le_antisymm
  · exact (Section02.bps.2.2.2.2.2.2 _
      (cubeCountablyBased n hn).1.toIsScottDomain (cubeCountablyBased n hn).2 n hn).mpr
        (cube_nCoherent n hn)
  · let H := forbidden n
    let hH := forbidden_admissible n hn
    let f := SingletonForbiddenDomains.singletonPoint H hH
    have hAnti : SingletonForbiddenDomains.ForbiddenAntichain H := by
      intro U hU V hV _hUV
      exact (Set.mem_singleton_iff.mp hU).trans (Set.mem_singleton_iff.mp hV).symm
    have hM := (SingletonForbiddenDomains.singleton_image_mic_iff H hH hAnti
      (Set.univ : Set (Fin n))).mpr (Set.mem_singleton _)
    let q := (avoidanceOrderIso.{u} n hn).symm
    have hImage := mic_image_orderIso q (ForbiddenFiniteDomains.isScottDomain H hH)
      (cubeCountablyBased n hn).1.toIsScottDomain hM
    have hb := mic_ncard_le_degree (cubeCountablyBased n hn).1.toIsScottDomain hImage
    simpa only [Set.ncard_image_of_injective _ q.injective,
      Set.ncard_image_of_injective _ (SingletonForbiddenDomains.singletonPoint_injective H hH),
      Set.ncard_univ, Nat.card_fin] using hb

def finiteCube (n : ℕ) (hn : 2 ≤ n) : CountablyBasedDIDomain.{u} :=
  cubeObject n hn (cubeCountablyBased n hn)

theorem finiteCube_degree (n : ℕ) (hn : 2 ≤ n) :
    objectDegree (finiteCube.{u} n hn) = (n : Ordinal.{u+1}) := cube_degree n hn

theorem finiteCube_finite (n : ℕ) (hn : 2 ≤ n) : Finite (finiteCube.{u} n hn) :=
  inferInstanceAs (Finite (CubeCarrier.{u} n hn))

theorem powersetCB : IsCountablyBasedDIDomain NatPowersetCarrier.{u} :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff
    (ForestProductMaps.liftOrderIso (Set ℕ))).mpr
      (ForestProductMaps.powerset_countablyBased ℕ)

def infinitePowerset : CountablyBasedDIDomain.{u} := natPowersetObject powersetCB

theorem infinitePowerset_degree : objectDegree infinitePowerset.{u} = 0 := by
  apply (Section02.bps.2.2.2.2.2.1 infinitePowerset
    powersetCB.1.toIsScottDomain powersetCB.2).mpr
  change Section02.BPS.IsCompleteLatticeOrder (ULift.{u} (Set ℕ))
  intro M
  exact ⟨⟨sSup M, isLUB_sSup M⟩, ⟨sInf M, isGLB_sInf M⟩⟩

theorem infinitePowerset_not_finite : ¬ Finite infinitePowerset.{u} := by
  intro hFinite
  letI : Finite NatPowersetCarrier.{u} := hFinite
  have hinj : Function.Injective (fun n : ℕ =>
      (⟨({n} : Set ℕ)⟩ : NatPowersetCarrier.{u})) := by
    intro a b hab
    have heq : ({a} : Set ℕ) = {b} := congrArg ULift.down hab
    exact Set.mem_singleton_iff.mp (heq ▸ Set.mem_singleton a)
  haveI : Finite ℕ := Finite.of_injective _ hinj
  exact not_finite ℕ

end DIDomainClassification.OrdinalCutWitnesses
