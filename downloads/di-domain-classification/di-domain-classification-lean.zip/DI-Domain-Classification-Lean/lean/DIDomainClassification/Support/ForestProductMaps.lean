import DIDomainClassification.Support.ForestOccurrenceBounds
import DIDomainClassification.Support.TerminalProductClosure

/-! Literal forest product and the source j/R maps. All subset coordinates
and all label occurrences are retained, including an empty root family. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.ForestProductMaps
open Preliminaries EventStructures Trees OrderCore
open Section04.ForestModels Section04.AdditionalSourceModels
open ForestPrefixTrees

def liftOrderIso (D : Type v) [PartialOrder D] : ULift.{u} D ≃o D where
  toFun x := x.down
  invFun x := ⟨x⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

def liftProductOrderIso (D : Type u) (E : Type v) [PartialOrder D] [PartialOrder E] :
    (ULift.{v} D × ULift.{u} E) ≃o (D × E) where
  toFun p := (p.1.down, p.2.down)
  invFun p := (⟨p.1⟩, ⟨p.2⟩)
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

theorem mixed_product_countablyBased (D : Type u) (E : Type v)
    [PartialOrder D] [PartialOrder E]
    (hD : IsCountablyBasedDIDomain D) (hE : IsCountablyBasedDIDomain E) :
    IsCountablyBasedDIDomain (D × E) := by
  let hDL := (OrderIsoTransport.isCountablyBasedDIDomain_iff (liftOrderIso D)).mpr hD
  let hEL := (OrderIsoTransport.isCountablyBasedDIDomain_iff (liftOrderIso E)).mpr hE
  exact (OrderIsoTransport.isCountablyBasedDIDomain_iff (liftProductOrderIso D E)).mp
    (TerminalProductClosure.product_isCountablyBasedDIDomain
      (cbObject (ULift.{v} D) hDL) (cbObject (ULift.{u} E) hEL))

def emptyAdmissible (A : Type u) :
    ForbiddenFiniteDomains.Admissible (∅ : Set (Set A)) where
  finite := by intro H hH; cases hH
  nonempty := by intro H hH; cases hH
  no_subset_singleton := by intro a H hH; cases hH

def powersetOrderIso (A : Type u) :
    ForbiddenFiniteDomains.AvoidanceDomain (∅ : Set (Set A)) ≃o Set A where
  toFun X := X.val
  invFun X := ⟨X, by intro H hH; cases hH⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

theorem powerset_countablyBased (A : Type u) [Countable A] :
    IsCountablyBasedDIDomain (Set A) :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff (powersetOrderIso A)).mp
    (ForbiddenFiniteDomains.isCountablyBasedDIDomain ∅ (emptyAdmissible A))

variable {A : Type u} [PartialOrder A]

abbrev Product (E : FinitaryPrimeEventStructure A) (e : A → ℕ) :=
  ProductCarrier E (data E e)

def treeCB (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) :
    IsCountablyBasedDIDomain (TreeDomain (tree E e i)) :=
  TreeRealisationConfigurations.treeCountablyBased (tree E e i) (proper E e he i)

def productCB (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) [Countable A] : IsCountablyBasedDIDomain (Product E e) := by
  have hPi : IsCountablyBasedDIDomain (∀ i : Roots E e, TreeDomain (tree E e i)) :=
    (Section02.countableProducts (Roots E e) (fun i => TreeDomain (tree E e i))
      (treeCB E e he)).1
  exact mixed_product_countablyBased (Set A) _ (powerset_countablyBased A) hPi

def coordinate (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (X : QualitativeCover E) (i : Roots E e) :
    TreeDomain (tree E e i) := by
  refine ⟨sectionCoordinate E (data E e) X i, ?_⟩
  rintro c ⟨w, hw, rfl⟩ hsub
  obtain ⟨H, hH, hhead, rfl⟩ := (leaf_iff_full E e he i w).mp hw
  apply X.property H hH
  intro a ha
  obtain ⟨v, hv, hva⟩ := exists_node_of_mem_full E e he i H hH hhead a ha
  have hmem := hsub hv
  change label E e i v ∈ X.val at hmem
  exact hva ▸ hmem

def sectionMap (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (X : QualitativeCover E) : Product E e :=
  (X.val, coordinate E e he X)

theorem retraction_avoids (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (P : Product E e) :
    ∀ H ∈ causalConflictFamily E, ¬ H ⊆ retractionValues E (data E e) P := by
  intro H hH hsub
  obtain ⟨i, hhead⟩ := exists_root_of_conflict E e H hH
  apply (P.2 i).property ((tree E e i).pathTo (fullNode E e i H hH hhead))
    ⟨fullNode E e i H hH hhead, fullNode_isLeaf E e he i H hH hhead, rfl⟩
  intro v hv
  have hlabel := label_mem_full E e he i H hH hhead v hv
  exact (hsub hlabel).2 i v rfl

def retractionMap (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (P : Product E e) : QualitativeCover E :=
  ⟨retractionValues E (data E e) P, retraction_avoids E e he P⟩

theorem section_monotone (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) : Monotone (sectionMap E e he) := by
  intro X Y hXY
  exact ⟨hXY, fun _ _ hv => hXY hv⟩

theorem retraction_monotone (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) : Monotone (retractionMap E e he) := by
  intro P Q hPQ a ha
  exact ⟨hPQ.1 ha.1, fun i v hv => hPQ.2 i (ha.2 i v hv)⟩

theorem leftInverse (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) : Function.LeftInverse (retractionMap E e he)
      (sectionMap E e he) := by
  intro X
  apply Subtype.ext
  ext a
  constructor
  · intro ha
    exact ha.1
  · intro ha
    refine ⟨ha, ?_⟩
    intro i v hva
    change label E e i v ∈ X.val
    change label E e i v = a at hva
    rw [hva]
    exact ha

def productInf (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (P Q : Product E e) : Product E e :=
  (P.1 ∩ Q.1, fun i => ⟨(P.2 i).val ∩ (Q.2 i).val, by
    intro c hc hsub
    exact (P.2 i).property c hc (hsub.trans Set.inter_subset_left)⟩)

theorem productInf_isGLB (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (P Q : Product E e) : IsGLB ({P, Q} : Set (Product E e)) (productInf E e P Q) := by
  constructor
  · intro Z hZ
    rcases Set.mem_insert_iff.mp hZ with rfl | hZ
    · exact ⟨Set.inter_subset_left, fun _ => Set.inter_subset_left⟩
    · rw [Set.mem_singleton_iff.mp hZ]
      exact ⟨Set.inter_subset_right, fun _ => Set.inter_subset_right⟩
  · intro Z hZ
    have hP : Z ≤ P := hZ (by simp)
    have hQ : Z ≤ Q := hZ (by simp)
    exact ⟨Set.subset_inter hP.1 hQ.1, fun i => Set.subset_inter (hP.2 i) (hQ.2 i)⟩

theorem product_inf_eq (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (hP : IsCountablyBasedDIDomain (Product E e)) (P Q : Product E e) :
    (hP.1.toIsScottDomain.inf P Q) = productInf E e P Q :=
  (hP.1.toIsScottDomain.inf_isGLB P Q).unique (productInf_isGLB E e P Q)

theorem cover_isLUB_values (E : FinitaryPrimeEventStructure A)
    (C : Set (QualitativeCover E)) (X : QualitativeCover E) (hX : IsLUB C X) :
    X.val = {a | ∃ Y ∈ C, a ∈ Y.val} := by
  let U : QualitativeCover E := ⟨{a | ∃ Y ∈ C, a ∈ Y.val}, by
    intro H hH hsub
    apply X.property H hH
    intro a ha
    obtain ⟨Y, hY, haY⟩ := hsub ha
    exact hX.1 hY haY⟩
  apply Set.Subset.antisymm
  · have hXU : X ≤ U := hX.2 (fun Y hY a ha => ⟨Y, hY, ha⟩)
    exact hXU
  · rintro a ⟨Y, hY, ha⟩
    exact hX.1 hY ha

theorem set_isLUB_values {B : Type v} (C : Set (Set B)) (X : Set B)
    (hX : IsLUB C X) : X = {a | ∃ Y ∈ C, a ∈ Y} := by
  apply Set.Subset.antisymm
  · exact hX.2 (fun Y hY a ha => ⟨Y, hY, ha⟩)
  · rintro a ⟨Y, hY, ha⟩
    exact hX.1 hY ha

theorem product_first_LUB_values (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (C : Set (Product E e)) (P : Product E e) (hP : IsLUB C P) (a : A) :
    a ∈ P.1 ↔ ∃ Q ∈ C, a ∈ Q.1 := by
  rw [set_isLUB_values (Prod.fst '' C) P.1 (isLUB_prod.mp hP).1]
  simp only [Set.mem_setOf_eq, Set.mem_image, exists_exists_and_eq_and]

theorem product_tree_LUB_values (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (C : Set (Product E e)) (P : Product E e) (hP : IsLUB C P)
    (i : Roots E e) (v : (tree E e i).Node) :
    v ∈ (P.2 i).val ↔ ∃ Q ∈ C, v ∈ (Q.2 i).val := by
  have hi := isLUB_pi.mp (isLUB_prod.mp hP).2 i
  rw [TreeRealisationConfigurations.tree_isLUB_values (tree E e i) _ (P.2 i) hi]
  change (∃ Y ∈ Function.eval i '' (Prod.snd '' C), v ∈ Y.val) ↔ _
  constructor
  · rintro ⟨Y, ⟨f, ⟨Q, hQ, rfl⟩, rfl⟩, hv⟩
    exact ⟨Q, hQ, hv⟩
  · rintro ⟨Q, hQ, hv⟩
    exact ⟨Q.2 i, ⟨Q.2, ⟨Q, hQ, rfl⟩, rfl⟩, hv⟩

theorem section_scottContinuous (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) : ScottContinuous (sectionMap E e he) := by
  intro C _hne _hdir X hX
  constructor
  · rintro _ ⟨Y, hY, rfl⟩
    exact section_monotone E e he (hX.1 hY)
  · intro P hP
    constructor
    · intro a ha
      change a ∈ X.val at ha
      rw [cover_isLUB_values E C X hX] at ha
      obtain ⟨Y, hY, haY⟩ := ha
      exact (hP ⟨Y, hY, rfl⟩).1 haY
    · intro i v hv
      change label E e i v ∈ X.val at hv
      rw [cover_isLUB_values E C X hX] at hv
      obtain ⟨Y, hY, hvY⟩ := hv
      exact (hP ⟨Y, hY, rfl⟩).2 i hvY

theorem retraction_scottContinuous (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) : ScottContinuous (retractionMap E e he) := by
  classical
  intro C hne hdir P hP
  constructor
  · rintro _ ⟨Q, hQ, rfl⟩
    exact retraction_monotone E e he (hP.1 hQ)
  · intro Y hY a ha
    change a ∈ retractionValues E (data E e) P at ha
    obtain ⟨Q0, hQ0, haQ0⟩ := (product_first_LUB_values E e C P hP a).mp ha.1
    let O := occurrences E (data E e) a
    letI : Finite O := (ForestOccurrenceBounds.finite_and_bound E e a).1.to_subtype
    have hOcc : ∀ x : O, ∃ Q ∈ C, x.val.2 ∈ (Q.2 x.val.1).val := by
      intro x
      exact (product_tree_LUB_values E e C P hP x.val.1 x.val.2).mp
        (ha.2 x.val.1 x.val.2 x.property)
    choose q hq hqv using hOcc
    let F : Set (Product E e) := insert Q0 (Set.range q)
    have hFfinite : F.Finite := (Set.finite_range q).insert Q0
    have hFC : F ⊆ C := by
      intro Q hQ
      rcases Set.mem_insert_iff.mp hQ with rfl | hQ
      · exact hQ0
      · obtain ⟨x, rfl⟩ := hQ
        exact hq x
    obtain ⟨Q, hQ, hFQ⟩ := (show DirectedSet C from ⟨hne, hdir⟩).exists_upper_finite
      hFfinite hFC
    have haR : a ∈ (retractionMap E e he Q).val := by
      refine ⟨(hFQ Q0 (by exact Or.inl rfl)).1 haQ0, ?_⟩
      intro i v hva
      let x : O := ⟨⟨i, v⟩, hva⟩
      exact (hFQ (q x) (Or.inr (Set.mem_range_self x))).2 i (hqv x)
    exact hY ⟨Q, hQ, rfl⟩ haR

def sectionHom (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (C : QualitativeCoverClosure E)
    (hP : IsCountablyBasedDIDomain (Product E e)) :
    StableHom (qualitativeCoverCore E C) (cbObject (Product E e) hP).toDIDomainObject := by
  refine StableHom.ofFunction (sectionMap E e he) ⟨section_scottContinuous E e he, ?_⟩
  intro X Y _hXY
  change sectionMap E e he (C.domain.toIsScottDomain.inf X Y) =
    hP.1.toIsScottDomain.inf (sectionMap E e he X) (sectionMap E e he Y)
  rw [product_inf_eq E e hP]
  apply Prod.ext
  · exact CausalCoverSupport.cover_inf_val E C X Y
  · funext i
    apply Subtype.ext
    ext v
    change label E e i v ∈ (C.domain.toIsScottDomain.inf X Y).val ↔
      label E e i v ∈ X.val ∩ Y.val
    exact Set.ext_iff.mp (CausalCoverSupport.cover_inf_val E C X Y) (label E e i v)

def retraction (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (C : QualitativeCoverClosure E)
    (hP : IsCountablyBasedDIDomain (Product E e)) :
    StableHom (cbObject (Product E e) hP).toDIDomainObject (qualitativeCoverCore E C) := by
  refine StableHom.ofFunction (retractionMap E e he) ⟨retraction_scottContinuous E e he, ?_⟩
  intro P Q _hPQ
  apply Subtype.ext
  rw [CausalCoverSupport.cover_inf_val E C]
  change retractionValues E (data E e) (hP.1.toIsScottDomain.inf P Q) =
    retractionValues E (data E e) P ∩ retractionValues E (data E e) Q
  rw [product_inf_eq E e hP]
  ext a
  constructor
  · intro ha
    exact ⟨⟨ha.1.1, fun i v hv => (ha.2 i v hv).1⟩,
      ⟨ha.1.2, fun i v hv => (ha.2 i v hv).2⟩⟩
  · intro ha
    exact ⟨⟨ha.1.1, ha.2.1⟩, fun i v hv => ⟨ha.1.2 i v hv, ha.2.2 i v hv⟩⟩

theorem section_first_values (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (C : QualitativeCoverClosure E)
    (hP : IsCountablyBasedDIDomain (Product E e)) (X : QualitativeCover E) :
    (sectionHom E e he C hP X).1 = X.val := rfl

theorem section_coordinate_values (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (C : QualitativeCoverClosure E)
    (hP : IsCountablyBasedDIDomain (Product E e)) (X : QualitativeCover E) (i : Roots E e) :
    ((sectionHom E e he C hP X).2 i).val = sectionCoordinate E (data E e) X i := rfl

theorem retraction_values (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (C : QualitativeCoverClosure E)
    (hP : IsCountablyBasedDIDomain (Product E e)) (P : Product E e) :
    (retraction E e he C hP P).val = retractionValues E (data E e) P := rfl

theorem native_leftInverse (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (C : QualitativeCoverClosure E)
    (hP : IsCountablyBasedDIDomain (Product E e)) :
    Function.LeftInverse (retraction E e he C hP : Product E e → QualitativeCover E)
      (sectionHom E e he C hP : QualitativeCover E → Product E e) :=
  leftInverse E e he

end DIDomainClassification.ForestProductMaps
