import DIDomainClassification.Support.FiniteConsistency
import DIDomainClassification.Section02.ScottOperations
import Mathlib.Data.Set.Finite.Range

/-! Finite minimally inconsistent sets can be approximated by equally many
actual compact elements. No finite-coherence or rank theorem is assumed. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.CoherenceDegree

open Preliminaries OrderCore

variable {D : Type u} [PartialOrder D] (hD : IsScottDomain D)

theorem mic_ncard_ge_two {M : Set D} (hM : IsMinimallyInconsistent hD M) :
    2 ≤ M.ncard := by
  by_contra hn
  have hsub : M.Subsingleton := (Set.ncard_le_one hM.1).mp (by omega)
  apply hM.2.1
  by_cases hne : M.Nonempty
  · obtain ⟨x, hx⟩ := hne
    exact ⟨x, fun y hy => (hsub hy hx).le⟩
  · exact ⟨hD.bottom, by intro y hy; exact (hne ⟨y, hy⟩).elim⟩

/-- A pointwise-smaller inconsistent image of a mic set is again mic, and the
map is automatically injective; repeated images would contradict minimality. -/
theorem mic_image_of_le {M : Set D} (hM : IsMinimallyInconsistent hD M)
    (c : M → D) (hle : ∀ x : M, c x ≤ x.val)
    (hbad : ¬ Consistent (Set.range c)) :
    IsMinimallyInconsistent hD (Set.range c) ∧ Function.Injective c := by
  classical
  letI : Fintype M := hM.1.fintype
  have hwithout (x : M) : ∃ z : D, ∀ y : M, y ≠ x → c y ≤ z := by
    have hp : M \ {x.val} ⊂ M := by
      refine ⟨Set.diff_subset, ?_⟩
      intro h
      have hx := h x.property
      exact hx.2 (by simp)
    obtain ⟨z, hz⟩ := hM.2.2 _ hp
    refine ⟨z, ?_⟩
    intro y hy
    apply (hle y).trans
    apply hz
    refine ⟨y.property, ?_⟩
    intro hxy
    exact hy (Subtype.ext (Set.mem_singleton_iff.mp hxy))
  have hinj : Function.Injective c := by
    intro x y hxy
    by_contra hne
    obtain ⟨z, hz⟩ := hwithout x
    apply hbad
    refine ⟨z, ?_⟩
    rintro _ ⟨a, rfl⟩
    by_cases ha : a = x
    · subst a
      rw [hxy]
      exact hz y (Ne.symm hne)
    · exact hz a ha
  refine ⟨⟨Set.finite_range c, hbad, ?_⟩, hinj⟩
  intro N hN
  obtain ⟨z, hz, hzN⟩ := Set.not_subset.mp hN.2
  obtain ⟨x, rfl⟩ := hz
  obtain ⟨b, hb⟩ := hwithout x
  refine ⟨b, ?_⟩
  intro z hz
  obtain ⟨y, rfl⟩ := hN.1 hz
  apply hb y
  intro hy
  exact hzN (hy ▸ hz)

/-- Compact approximation preserves the exact cardinality of an arbitrary
finite mic set, not just a mic set already restricted to the compact basis. -/
theorem exists_compact_mic_approximation {M : Set D}
    (hM : IsMinimallyInconsistent hD M) :
    ∃ N : Set D, IsMinimallyInconsistent hD N ∧
      N ⊆ CompactElements D ∧ N.ncard = M.ncard := by
  classical
  let A : Set D := {k | IsCompactElement k ∧ ∃ x ∈ M, k ≤ x}
  have hAbad : ¬ Consistent A := by
    rintro ⟨z, hz⟩
    apply hM.2.1
    refine ⟨z, ?_⟩
    intro x hx
    apply (hD.algebraic.2 x).2.2
    intro k hk
    exact hz ⟨hk.1, x, hx, hk.2⟩
  have hF : ∃ F : Set D, F.Finite ∧ F ⊆ A ∧ ¬ Consistent F := by
    by_contra hn
    apply hAbad
    apply consistent_of_finite_subsets_consistent hD A
    intro F hF hFA
    by_contra hb
    exact hn ⟨F, hF, hFA, hb⟩
  obtain ⟨F, hFfin, hFA, hFbad⟩ := hF
  have hchoices (x : M) : ∃ c : D, c ∈ OrderCore.CompactBelow x.val ∧
      ∀ k ∈ F ∩ OrderCore.CompactBelow x.val, k ≤ c := by
    exact (hD.algebraic.2 x.val).1.exists_upper_finite
      (hFfin.subset (fun _ hk => hk.1)) (fun _ hk => hk.2)
  choose c hc hFc using hchoices
  have hbad : ¬ Consistent (Set.range c) := by
    rintro ⟨z, hz⟩
    apply hFbad
    refine ⟨z, ?_⟩
    intro k hk
    obtain ⟨x, hx, hkx⟩ := (hFA hk).2
    exact (hFc ⟨x, hx⟩ k ⟨hk, (hFA hk).1, hkx⟩).trans (hz ⟨⟨x, hx⟩, rfl⟩)
  obtain ⟨hNmic, hinj⟩ := mic_image_of_le hD hM c (fun x => (hc x).2) hbad
  refine ⟨Set.range c, hNmic, ?_, ?_⟩
  · rintro _ ⟨x, rfl⟩
    exact (hc x).1
  · simpa only [Nat.card_coe_set_eq] using (Nat.card_congr (Equiv.ofInjective c hinj)).symm

end DIDomainClassification.CoherenceDegree
