import DIDomainClassification.Support.ForestEnumeration
import DIDomainClassification.Section04.TreeRealisation

/-! Literal trees of nonempty prefixes of sorted causal conflicts. The root
is [i], not an artificially normalized empty list. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ForestPrefixTrees
open Preliminaries EventStructures Trees FiniteCausalConflicts
open Section04.ForestModels ForestEnumeration

variable {A : Type u} [PartialOrder A]

def tree (E : FinitaryPrimeEventStructure A) (e : A → ℕ) (i : Roots E e) :
    RootedPrefixTree ℕ where
  nodes := nodeLists E e i
  rootList := [i.val]
  root_mem := by
    obtain ⟨H, hH, hmin⟩ := i.property
    have hh := sorted_head_of_minimum E e H hH i.val hmin
    exact ⟨List.cons_ne_nil _ _, H, hH, hh, singleton_prefix_of_head hh⟩
  root_prefix := by
    rintro v ⟨hne, H, hH, hhead, hpre⟩
    exact singleton_prefix_of_head (indexHead_of_nonempty_prefix hne hpre hhead)
  prefix_closed := by
    intro v w hroot hvw hw
    refine ⟨?_, ?_⟩
    · intro hv
      rw [hv] at hroot
      cases List.prefix_nil.mp hroot
    · obtain ⟨_hne, H, hH, hhead, hpre⟩ := hw
      exact ⟨H, hH, hhead, hvw.trans hpre⟩
  countable_nodes := Set.to_countable _

theorem tree_nodes (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) : (tree E e i).nodes = nodeLists E e i := rfl

theorem tree_rootList (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) : (tree E e i).rootList = [i.val] := rfl

theorem node_strict (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) (v : (tree E e i).Node) : v.val.Pairwise (· < ·) := by
  obtain ⟨_hne, H, hH, _hhead, hpre⟩ := v.property
  exact List.Pairwise.sublist hpre.sublist (sorted_strict E e H hH)

theorem node_head (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) (v : (tree E e i).Node) : indexHead v.val = some i.val := by
  obtain ⟨hne, H, hH, hhead, hpre⟩ := v.property
  exact indexHead_of_nonempty_prefix hne hpre hhead

theorem conflict_subset_of_sorted_prefix (E : FinitaryPrimeEventStructure A)
    (e : A → ℕ) (he : Function.Injective e) (H K : Set A)
    (hH : H ∈ causalConflictFamily E) (hK : K ∈ causalConflictFamily E)
    (hpre : sortedIndices E e H hH <+: sortedIndices E e K hK) : H ⊆ K := by
  intro a ha
  have hm : e a ∈ sortedIndices E e K hK :=
    hpre.subset ((mem_sorted E e H hH (e a)).mpr ⟨a, ha, rfl⟩)
  obtain ⟨b, hb, hba⟩ := (mem_sorted E e K hK (e a)).mp hm
  exact he hba ▸ hb

def fullNode (E : FinitaryPrimeEventStructure A) (e : A → ℕ) (i : Roots E e)
    (H : Set A) (hH : H ∈ causalConflictFamily E)
    (hhead : indexHead (sortedIndices E e H hH) = some i.val) : (tree E e i).Node :=
  ⟨sortedIndices E e H hH,
    sorted_nonempty E e H hH, H, hH, hhead, List.prefix_refl _⟩

theorem fullNode_isLeaf (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) (H : Set A)
    (hH : H ∈ causalConflictFamily E)
    (hhead : indexHead (sortedIndices E e H hH) = some i.val) :
    (tree E e i).IsLeaf (fullNode E e i H hH hhead) := by
  intro w hfw
  change sortedIndices E e H hH <+: w.val at hfw
  obtain ⟨_hne, K, hK, _hkhead, hwK⟩ := w.property
  have hpre : sortedIndices E e H hH <+: sortedIndices E e K hK := hfw.trans hwK
  have hHK : H = K := conflict_member_eq_of_subset E hH hK
    (conflict_subset_of_sorted_prefix E e he H K hH hK hpre)
  subst K
  apply Subtype.ext
  exact hwK.eq_of_length (Nat.le_antisymm hwK.length_le hfw.length_le)

theorem node_has_full_extension (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) (v : (tree E e i).Node) :
    ∃ (H : Set A) (hH : H ∈ causalConflictFamily E)
      (hhead : indexHead (sortedIndices E e H hH) = some i.val),
      v.val <+: (fullNode E e i H hH hhead).val := by
  obtain ⟨_hne, H, hH, hhead, hpre⟩ := v.property
  exact ⟨H, hH, hhead, hpre⟩

theorem leaf_iff_full (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) (v : (tree E e i).Node) :
    (tree E e i).IsLeaf v ↔
      ∃ (H : Set A) (hH : H ∈ causalConflictFamily E)
        (hhead : indexHead (sortedIndices E e H hH) = some i.val),
        v = fullNode E e i H hH hhead := by
  constructor
  · intro hv
    obtain ⟨H, hH, hhead, hvf⟩ := node_has_full_extension E e i v
    exact ⟨H, hH, hhead, (hv _ hvf).symm⟩
  · rintro ⟨H, hH, hhead, rfl⟩
    exact fullNode_isLeaf E e he i H hH hhead

theorem sorted_length_ge_two (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (H : Set A) (hH : H ∈ causalConflictFamily E) :
    2 ≤ (sortedIndices E e H hH).length := by
  classical
  have hlen : (sortedIndices E e H hH).length = H.ncard := by
    rw [sortedIndices, Finset.length_sort, Finset.card_image_of_injective _ he]
    exact (Set.ncard_eq_toFinset_card H (conflict_member_finite E hH)).symm
  rw [hlen]
  exact conflict_member_card_ge_two E hH

theorem proper (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) : (tree E e i).IsProper := by
  apply (tree E e i).isProper_iff.mpr
  constructor
  · obtain ⟨H, hH, hmin⟩ := i.property
    have hh := sorted_head_of_minimum E e H hH i.val hmin
    have hsize := sorted_length_ge_two E e he H hH
    refine ⟨⟨fullNode E e i H hH hh, (tree E e i).root, ?_⟩⟩
    intro heq
    have hlen := congrArg (fun v : (tree E e i).Node => v.val.length) heq
    change (sortedIndices E e H hH).length = 1 at hlen
    omega
  · intro v
    obtain ⟨H, hH, hhead, hpre⟩ := node_has_full_extension E e i v
    exact ⟨fullNode E e i H hH hhead, fullNode_isLeaf E e he i H hH hhead, hpre⟩

theorem indexLast_append_singleton (d : ℕ) (l : List ℕ) (n : ℕ) :
    indexLast d (l ++ [n]) = n := by
  simp only [indexLast, List.foldl_append, List.foldl_cons, List.foldl_nil]

theorem indexLast_eq_getLast (d : ℕ) (l : List ℕ) (hne : l ≠ []) :
    indexLast d l = l.getLast hne := by
  conv_lhs => rw [← List.dropLast_append_getLast hne]
  exact indexLast_append_singleton d l.dropLast (l.getLast hne)

theorem indexLast_mem (d : ℕ) (l : List ℕ) (hne : l ≠ []) : indexLast d l ∈ l := by
  rw [indexLast_eq_getLast d l hne]
  exact List.getLast_mem hne

theorem last_in_range (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) (v : (tree E e i).Node) :
    ∃ a : A, e a = indexLast i.val v.val := by
  obtain ⟨hne, H, hH, _hhead, hpre⟩ := v.property
  obtain ⟨a, _ha, hea⟩ := (mem_sorted E e H hH _).mp
    (hpre.subset (indexLast_mem i.val v.val hne))
  exact ⟨a, hea⟩

def label (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) (v : (tree E e i).Node) : A :=
  Classical.choose (last_in_range E e i v)

theorem enumerate_label (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) (v : (tree E e i).Node) :
    e (label E e i v) = indexLast i.val v.val :=
  Classical.choose_spec (last_in_range E e i v)

def data (E : FinitaryPrimeEventStructure A) (e : A → ℕ) : Data E where
  enumerate := e
  trees := tree E e
  label := label E e

theorem label_mem_full (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) (H : Set A)
    (hH : H ∈ causalConflictFamily E)
    (hhead : indexHead (sortedIndices E e H hH) = some i.val)
    (v : (tree E e i).Node) (hv : v.val <+: sortedIndices E e H hH) :
    label E e i v ∈ H := by
  obtain ⟨a, ha, hea⟩ := (mem_sorted E e H hH _).mp
    (hv.subset (indexLast_mem i.val v.val v.property.1))
  have heq : a = label E e i v := he (hea.trans (enumerate_label E e i v).symm)
  exact heq ▸ ha

theorem exists_node_of_mem_full (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) (H : Set A)
    (hH : H ∈ causalConflictFamily E)
    (hhead : indexHead (sortedIndices E e H hH) = some i.val)
    (a : A) (ha : a ∈ H) :
    ∃ v : (tree E e i).Node,
      v.val <+: sortedIndices E e H hH ∧ label E e i v = a := by
  have hm := (mem_sorted E e H hH (e a)).mpr ⟨a, ha, rfl⟩
  obtain ⟨p, q, hlist⟩ := List.mem_iff_append.mp hm
  let l := p ++ [e a]
  have hlne : l ≠ [] := List.append_ne_nil_of_right_ne_nil _ (List.cons_ne_nil _ _)
  have hlpre : l <+: sortedIndices E e H hH := by
    rw [hlist]
    exact ⟨q, by simp only [l, List.append_assoc, List.singleton_append]⟩
  have hlhead : indexHead l = some i.val := indexHead_of_nonempty_prefix hlne hlpre hhead
  let v : (tree E e i).Node := ⟨l, hlne, H, hH, hhead, hlpre⟩
  refine ⟨v, hlpre, he ?_⟩
  exact (enumerate_label E e i v).trans (indexLast_append_singleton i.val p (e a))

theorem prefix_eq_of_getLast_eq {p q : List ℕ} (hp : p ≠ []) (hq : q ≠ [])
    (hpre : p <+: q) (hstrict : q.Pairwise (· < ·))
    (hlast : p.getLast hp = q.getLast hq) : p = q := by
  obtain ⟨r, rfl⟩ := hpre
  by_cases hr : r = []
  · simp only [hr, List.append_nil]
  · have hcross := (List.pairwise_append.mp hstrict).2.2
    have hlt : p.getLast hp < r.getLast hr :=
      hcross _ (List.getLast_mem hp) _ (List.getLast_mem hr)
    have heq : p.getLast hp = r.getLast hr := by
      simpa only [List.getLast_append_of_right_ne_nil p r hr] using hlast
    exact (lt_irrefl _ (heq ▸ hlt)).elim

theorem label_injective_on_path (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (i : Roots E e) (w : (tree E e i).Node) :
    Set.InjOn (label E e i) ((tree E e i).pathTo w) := by
  intro x hx y hy hxy
  change x.val <+: w.val at hx
  change y.val <+: w.val at hy
  have hlast : x.val.getLast x.property.1 = y.val.getLast y.property.1 := by
    rw [← indexLast_eq_getLast i.val x.val x.property.1,
      ← indexLast_eq_getLast i.val y.val y.property.1,
      ← enumerate_label E e i x, ← enumerate_label E e i y, hxy]
  rcases List.prefix_or_prefix_of_prefix hx hy with h | h
  · exact Subtype.ext (prefix_eq_of_getLast_eq x.property.1 y.property.1 h
      (node_strict E e i y) hlast)
  · exact Subtype.ext (prefix_eq_of_getLast_eq y.property.1 x.property.1 h
      (node_strict E e i x) hlast.symm).symm

theorem labels_path_full (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) (H : Set A)
    (hH : H ∈ causalConflictFamily E)
    (hhead : indexHead (sortedIndices E e H hH) = some i.val) :
    label E e i '' (tree E e i).pathTo (fullNode E e i H hH hhead) = H := by
  ext a
  constructor
  · rintro ⟨v, hv, rfl⟩
    exact label_mem_full E e he i H hH hhead v hv
  · intro ha
    obtain ⟨v, hv, hva⟩ := exists_node_of_mem_full E e he i H hH hhead a ha
    exact ⟨v, hv, hva⟩

theorem exists_root_of_conflict (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (H : Set A) (hH : H ∈ causalConflictFamily E) :
    ∃ i : Roots E e, indexHead (sortedIndices E e H hH) = some i.val := by
  obtain ⟨a, ha, hmin⟩ := Set.exists_min_image H e
    (conflict_member_finite E hH) (conflict_member_nonempty E hH)
  let i : Roots E e := ⟨e a, H, hH, a, ha, rfl, hmin⟩
  exact ⟨i, sorted_head_of_minimum E e H hH (e a) ⟨a, ha, rfl, hmin⟩⟩

theorem singleton_blocks (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) :
    Section04.TreeRealisationModels.BlockCondition (tree E e i) E
      (fun v => {label E e i v}) := by
  constructor
  · intro v
    exact ⟨Set.finite_singleton _, Set.singleton_nonempty _⟩
  · rintro c ⟨w, hw, rfl⟩
    obtain ⟨H, hH, hhead, rfl⟩ := (leaf_iff_full E e he i w).mp hw
    constructor
    · intro x hx y hy hne
      apply Set.disjoint_singleton.mpr
      intro heq
      exact hne (label_injective_on_path E e i (fullNode E e i H hH hhead) hx hy heq)
    · have hUnion : (⋃ v ∈ (tree E e i).pathTo (fullNode E e i H hH hhead),
          ({label E e i v} : Set A)) =
          label E e i '' (tree E e i).pathTo (fullNode E e i H hH hhead) := by
        ext a
        simp only [Set.mem_iUnion, Set.mem_singleton_iff, Set.mem_image]
        constructor
        · rintro ⟨v, hv, hav⟩
          exact ⟨v, hv, hav.symm⟩
        · rintro ⟨v, hv, hva⟩
          exact ⟨v, hv, hva.symm⟩
      rw [hUnion, labels_path_full E e he i H hH hhead]
      exact hH

theorem realised_tree (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (i : Roots E e) :
    ∃ (hT : IsCountablyBasedDIDomain (TreeDomain (tree E e i)))
      (hH : IsCountablyBasedDIDomain
        (BranchCompletion (tree E e i) (proper E e he i))),
      HasStableRetraction
        (Section04.AdditionalSourceModels.treeCore (tree E e i) hT.1)
        (Section04.AdditionalSourceModels.functionCore
          (Section04.AdditionalSourceModels.completionCB (tree E e i)
            (proper E e he i) hH).toDIDomainObject (causalConfigurationCore E)) := by
  obtain ⟨hT, hH, s, r, _hf, _hb, _hr, hleft⟩ :=
    Section04.treeRealisation A E ℕ (tree E e i) (proper E e he i)
      (fun v => {label E e i v}) (singleton_blocks E e he i)
  exact ⟨hT, hH, s, r, hleft⟩

end DIDomainClassification.ForestPrefixTrees
