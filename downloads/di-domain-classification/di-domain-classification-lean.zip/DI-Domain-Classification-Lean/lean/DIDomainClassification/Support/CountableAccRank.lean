import Mathlib.SetTheory.Ordinal.Rank

/-!
Generic staged support: ranks of accessible elements of a countable relation.
No paper-specific degree, model substitution, countability of domain points,
source statement acceptance, or whole-paper completion is asserted here.

Reuse: actual Acc.mem_range_rank_of_le at the pinned Mathlib revision,
Ordinal/Rank.lean SHA9e1fd56a9198226af16f3dab0a28fa87af2eca39b5a6369cf4ca20bec564e3bf.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.OrdinalSupport

noncomputable section

theorem countable_Iic_acc_rank {A : Type u} [Countable A]
    {r : A → A → Prop} {a : A} (ha : Acc r a) : Countable (Set.Iic ha.rank) := by
  classical
  have hex (o : Set.Iic ha.rank) : ∃ b : A, ∃ hb : Acc r b, hb.rank = o.val :=
    Acc.mem_range_rank_of_le ha o.property
  let f (o : Set.Iic ha.rank) : {b : A // Acc r b} :=
    ⟨Classical.choose (hex o), Classical.choose (Classical.choose_spec (hex o))⟩
  have hf (o : Set.Iic ha.rank) : (f o).property.rank = o.val :=
    Classical.choose_spec (Classical.choose_spec (hex o))
  have hinj : Function.Injective f := by
    intro o p h
    apply Subtype.ext
    exact (hf o).symm.trans
      ((congrArg (fun b : {b : A // Acc r b} => b.property.rank) h).trans (hf p))
  exact hinj.countable

theorem countable_Iio_acc_rank {A : Type u} [Countable A]
    {r : A → A → Prop} {a : A} (ha : Acc r a) : Countable (Set.Iio ha.rank) := by
  letI := countable_Iic_acc_rank ha
  let f (o : Set.Iio ha.rank) : Set.Iic ha.rank :=
    ⟨o.val, (show o.val ≤ ha.rank from le_of_lt (show o.val < ha.rank from o.property))⟩
  have hinj : Function.Injective f := by
    intro o p h
    apply Subtype.ext
    exact congrArg (fun q : Set.Iic ha.rank => q.val) h
  exact hinj.countable

theorem card_acc_rank_le_aleph0 {A : Type u} [Countable A]
    {r : A → A → Prop} {a : A} (ha : Acc r a) : ha.rank.card ≤ Cardinal.aleph0 := by
  letI := countable_Iio_acc_rank ha
  have h := Cardinal.mk_le_aleph0 (α := Set.Iio ha.rank)
  rw [Cardinal.mk_Iio_ordinal] at h
  exact Cardinal.lift_le_aleph0.mp h

theorem acc_rank_lt_firstUncountable {A : Type u} [Countable A]
    {r : A → A → Prop} {a : A} (ha : Acc r a) :
    ha.rank < (Order.succ Cardinal.aleph0).ord :=
  Cardinal.card_le_iff.mp (card_acc_rank_le_aleph0 ha)


end

end DIDomainClassification.OrdinalSupport
