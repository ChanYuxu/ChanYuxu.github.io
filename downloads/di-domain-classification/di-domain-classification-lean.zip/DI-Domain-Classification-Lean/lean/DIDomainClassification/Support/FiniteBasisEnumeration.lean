import DIDomainClassification.Section02.DomainDefinitions
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Logic.Encodable.Basic

/-!
Actual finite-basis enumeration and injective tags for countable child sets.
The latter codes the NEWLY CONSTRUCTED output trees. It does not restrict the
source MIC-tree supremum to natural-number alphabets or assert a coding/rank
bridge without proof. The eventual refinement theorem must cover every input
alphabet and prove its actual output rank bound.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries

def countableTag (I : Type v) [Countable I] : I → ULift.{v} ℕ :=
  fun i => ⟨@Encodable.encode I (Encodable.ofCountable I) i⟩

theorem countableTag_injective (I : Type v) [Countable I] :
    Function.Injective (countableTag I) := by
  intro i j hij
  letI : Encodable I := Encodable.ofCountable I
  exact Encodable.encode_injective (congrArg ULift.down hij)

theorem finite_compact_enumeration {D : Type u} [PartialOrder D]
    (B : Set D) (hB : B.Finite) (hBne : B.Nonempty) (hcompact : B ⊆ CompactElements D) :
    ∃ (n : ℕ) (_hn : 0 < n) (e : Fin n → ↥(CompactElements D)),
      Function.Injective e ∧ Set.range (fun i => (e i : D)) = B := by
  classical
  letI : Finite B := hB.to_subtype
  letI : Fintype B := Fintype.ofFinite B
  let n := Fintype.card B
  have hn : 0 < n := Fintype.card_pos_iff.mpr (by
    obtain ⟨b, hb⟩ := hBne
    exact ⟨⟨b, hb⟩⟩)
  let f : Fin n → B := (Fintype.equivFin B).symm
  let e : Fin n → ↥(CompactElements D) := fun i => ⟨(f i).val, hcompact (f i).property⟩
  refine ⟨n, hn, e, ?_, ?_⟩
  · intro i j hij
    apply (Fintype.equivFin B).symm.injective
    have hval : (f i).val = (f j).val :=
      congrArg (fun b : ↥(CompactElements D) => b.val) hij
    exact Subtype.ext hval
  · ext b
    constructor
    · rintro ⟨i, rfl⟩
      exact (f i).property
    · intro hb
      refine ⟨Fintype.equivFin B ⟨b, hb⟩, ?_⟩
      exact congrArg Subtype.val ((Fintype.equivFin B).symm_apply_apply ⟨b, hb⟩)

theorem finite_compact_enumeration_succ {D : Type u} [PartialOrder D]
    (B : Set D) (hB : B.Finite) (hBne : B.Nonempty) (hcompact : B ⊆ CompactElements D) :
    ∃ (n : ℕ) (e : Fin (n + 1) → ↥(CompactElements D)),
      Function.Injective e ∧ Set.range (fun i => (e i : D)) = B := by
  obtain ⟨n, hn, e, hinj, hrange⟩ := finite_compact_enumeration B hB hBne hcompact
  cases n with
  | zero => exact (Nat.not_lt_zero _ hn).elim
  | succ n => exact ⟨n, e, hinj, hrange⟩

end DIDomainClassification.PointwiseFunctionSupport
