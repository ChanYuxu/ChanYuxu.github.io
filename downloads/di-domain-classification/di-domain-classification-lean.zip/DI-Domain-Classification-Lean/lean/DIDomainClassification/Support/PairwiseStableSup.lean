import DIDomainClassification.Support.StableHomGeneralClosure

/-!
Generic suprema of pairwise-compatible stable maps with pointwise bounds.
Adapted from the bounded-union construction in StableHomScottStructure.
There is no common stable upper-bound premise for the whole family.
No source-facing statement or completion receipt is supplied by this module.
-/

set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.PairwiseStableSup

open Preliminaries EventStructures MinimalInputTraces FiniteTraceApproximations
open StableExponentialClosure

variable {D : Type u} {A : Type v} [PartialOrder D] [PartialOrder A]
  {E : FinitaryPrimeEventStructure A}

def PointwiseBounded (hD : IsDIDomain D) (B : Set (Hom hD E)) : Prop :=
  ∀ x : D, BddAbove ((fun g : Hom hD E => g x) '' B)

def PairwiseBounded (hD : IsDIDomain D) (B : Set (Hom hD E)) : Prop :=
  ∀ g ∈ B, ∀ h ∈ B, ∃ U : Hom hD E, g ≤ U ∧ h ≤ U

theorem values_isConfiguration (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (x : D) :
    IsConfiguration E (supValues hD B x) := by
  constructor
  · intro a b hab hb
    obtain ⟨g, hb⟩ := Set.mem_iUnion.mp hb
    obtain ⟨hg, hb⟩ := Set.mem_iUnion.mp hb
    exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, (g x).property.1 hab hb⟩⟩
  · intro F hF hsub
    obtain ⟨Z, hZ⟩ := hB x
    apply Z.property.2 F hF
    intro a ha
    obtain ⟨g, ha⟩ := Set.mem_iUnion.mp (hsub ha)
    obtain ⟨hg, ha⟩ := Set.mem_iUnion.mp ha
    exact (Configuration.le_iff_subset _ _).mp (hZ ⟨g, hg, rfl⟩) ha

def unionConfiguration (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (x : D) : Configuration E :=
  ⟨supValues hD B x, values_isConfiguration hD B hB x⟩

theorem member_le_union (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) {g : Hom hD E} (hg : g ∈ B) (x : D) :
    g x ≤ unionConfiguration hD B hB x := by
  intro a ha
  exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, ha⟩⟩

theorem union_monotone (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) : Monotone (unionConfiguration hD B hB) := by
  intro x y hxy a ha
  obtain ⟨g, ha⟩ := Set.mem_iUnion.mp ha
  obtain ⟨hg, ha⟩ := Set.mem_iUnion.mp ha
  exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg,
    (StableHom.isStable g).1.monotone hxy ha⟩⟩

theorem union_scottContinuous (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) :
    ScottContinuous (unionConfiguration hD B hB) := by
  intro C hne hdir s hs
  constructor
  · rintro _ ⟨x, hx, rfl⟩
    exact union_monotone hD B hB (hs.1 hx)
  · intro Z hZ a ha
    obtain ⟨g, ha⟩ := Set.mem_iUnion.mp ha
    obtain ⟨hg, ha⟩ := Set.mem_iUnion.mp ha
    have hgZ : g s ≤ Z := ((StableHom.isStable g).1 hne hdir hs).2 (by
      rintro _ ⟨x, hx, rfl⟩
      exact (member_le_union hD B hB hg x).trans (hZ ⟨x, hx, rfl⟩))
    exact hgZ ha

theorem union_meet_val (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (hPair : PairwiseBounded hD B)
    (x y : D) (hxy : Compatible x y) :
    (unionConfiguration hD B hB (hD.toIsScottDomain.inf x y)).val =
      (unionConfiguration hD B hB x).val ∩ (unionConfiguration hD B hB y).val := by
  ext a
  constructor
  · intro ha
    exact ⟨union_monotone hD B hB (hD.toIsScottDomain.inf_le_left x y) ha,
      union_monotone hD B hB (hD.toIsScottDomain.inf_le_right x y) ha⟩
  · rintro ⟨hax, hay⟩
    obtain ⟨g, hax⟩ := Set.mem_iUnion.mp hax
    obtain ⟨hg, hax⟩ := Set.mem_iUnion.mp hax
    obtain ⟨h, hay⟩ := Set.mem_iUnion.mp hay
    obtain ⟨hh, hay⟩ := Set.mem_iUnion.mp hay
    obtain ⟨U, hgU, hhU⟩ := hPair g hg h hh
    have haU : a ∈ (U (hD.toIsScottDomain.inf x y)).val := by
      rw [compatible_meet_val hD.toIsScottDomain (hom_preserves_meets hD U) x y hxy]
      exact ⟨hom_le_pointwise hD hgU x hax, hom_le_pointwise hD hhU y hay⟩
    have hag : a ∈ (g (hD.toIsScottDomain.inf x y)).val := by
      rw [hom_le_val_eq hD hgU _ x (hD.toIsScottDomain.inf_le_left x y)]
      exact ⟨hax, haU⟩
    exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, hag⟩⟩

def unionHom (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (hPair : PairwiseBounded hD B) : Hom hD E :=
  StableHom.ofFunction (unionConfiguration hD B hB)
    ⟨union_scottContinuous hD B hB, by
      intro x y hxy
      apply Subtype.ext
      rw [source_inf_eq, target_inf_val]
      exact union_meet_val hD B hB hPair x y hxy⟩

theorem member_le_unionHom (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (hPair : PairwiseBounded hD B)
    {g : Hom hD E} (hg : g ∈ B) : g ≤ unionHom hD B hB hPair := by
  intro x y hxy
  apply Subtype.ext
  rw [target_inf_val]
  ext a
  constructor
  · intro ha
    exact ⟨(StableHom.isStable g).1.monotone hxy ha, member_le_union hD B hB hg x ha⟩
  · rintro ⟨hay, hax⟩
    obtain ⟨h, hax⟩ := Set.mem_iUnion.mp hax
    obtain ⟨hh, hax⟩ := Set.mem_iUnion.mp hax
    obtain ⟨U, hgU, hhU⟩ := hPair g hg h hh
    rw [hom_le_val_eq hD hgU x y hxy]
    exact ⟨hay, hom_le_pointwise hD hhU x hax⟩

theorem unionHom_le (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (hPair : PairwiseBounded hD B)
    (V : Hom hD E) (hV : ∀ g ∈ B, g ≤ V) : unionHom hD B hB hPair ≤ V := by
  intro x y hxy
  apply Subtype.ext
  rw [target_inf_val]
  ext a
  constructor
  · intro ha
    exact ⟨union_monotone hD B hB hxy ha, supValues_subset hD B V hV x ha⟩
  · rintro ⟨hay, haV⟩
    obtain ⟨g, hay⟩ := Set.mem_iUnion.mp hay
    obtain ⟨hg, hay⟩ := Set.mem_iUnion.mp hay
    have hax : a ∈ (g x).val := by
      rw [hom_le_val_eq hD (hV g hg) x y hxy]
      exact ⟨hay, haV⟩
    exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, hax⟩⟩

theorem unionHom_isLUB (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (hPair : PairwiseBounded hD B) :
    IsLUB B (unionHom hD B hB hPair) :=
  ⟨fun _ hg => member_le_unionHom hD B hB hPair hg,
    fun V hV => unionHom_le hD B hB hPair V (fun _ hg => hV hg)⟩

theorem unionHom_values_isLUB (hD : IsDIDomain D) (B : Set (Hom hD E))
    (hB : PointwiseBounded hD B) (hPair : PairwiseBounded hD B) (x : D) :
    IsLUB ((fun g : Hom hD E => g x) '' B) (unionHom hD B hB hPair x) := by
  constructor
  · rintro _ ⟨g, hg, rfl⟩
    exact member_le_union hD B hB hg x
  · intro Z hZ a ha
    obtain ⟨g, ha⟩ := Set.mem_iUnion.mp ha
    obtain ⟨hg, ha⟩ := Set.mem_iUnion.mp ha
    exact hZ ⟨g, hg, rfl⟩ ha

theorem exists_native_supremum (D : DIDomainObject.{u}) (F : DIDomainObject.{w})
    (B : Set (StableHom D F))
    (hPair : ∀ g ∈ B, ∀ h ∈ B, ∃ U : StableHom D F, g ≤ U ∧ h ≤ U)
    (hB : ∀ x : D, BddAbove ((fun g : StableHom D F => g x) '' B)) :
    ∃ U : StableHom D F, IsLUB B U ∧
      ∀ x : D, IsLUB ((fun g : StableHom D F => g x) '' B) (U x) := by
  let E := primeEventStructure F
  let e := primeEventOrderIso F
  let φ := codomainOrderIso D F (configurationObject E) e
  let C : Set (StableHom D (configurationObject E)) := φ '' B
  have hCB : PointwiseBounded D.isDIDomain C := by
    intro x
    obtain ⟨Z, hZ⟩ := hB x
    refine ⟨e Z, ?_⟩
    rintro _ ⟨g, ⟨f, hf, rfl⟩, rfl⟩
    change e (f x) ≤ e Z
    exact e.monotone (hZ ⟨f, hf, rfl⟩)
  have hCP : PairwiseBounded D.isDIDomain C := by
    rintro _ ⟨g, hg, rfl⟩ _ ⟨h, hh, rfl⟩
    obtain ⟨U, hgU, hhU⟩ := hPair g hg h hh
    exact ⟨φ U, φ.monotone hgU, φ.monotone hhU⟩
  let V := unionHom D.isDIDomain C hCB hCP
  have hV := unionHom_isLUB D.isDIDomain C hCB hCP
  refine ⟨φ.symm V, ?_, ?_⟩
  · have h := φ.symm.isLUB_image'.mpr hV
    simpa only [C, φ.symm_image_image] using h
  · intro x
    have hValues : e '' ((fun g : StableHom D F => g x) '' B) =
        (fun g : StableHom D (configurationObject E) => g x) '' C := by
      ext z
      constructor
      · rintro ⟨_, ⟨g, hg, rfl⟩, rfl⟩
        exact ⟨φ g, ⟨g, hg, rfl⟩, rfl⟩
      · rintro ⟨_, ⟨g, hg, rfl⟩, rfl⟩
        exact ⟨g x, ⟨g, hg, rfl⟩, rfl⟩
    have h := unionHom_values_isLUB D.isDIDomain C hCB hCP x
    have hImage : IsLUB (e '' ((fun g : StableHom D F => g x) '' B))
        (e ((φ.symm V) x)) := by
      rw [hValues]
      change IsLUB ((fun g : StableHom D (configurationObject E) => g x) '' C)
        (e (e.symm (V x)))
      rw [e.apply_symm_apply]
      exact h
    exact e.isLUB_image'.mp hImage

end DIDomainClassification.PairwiseStableSup
