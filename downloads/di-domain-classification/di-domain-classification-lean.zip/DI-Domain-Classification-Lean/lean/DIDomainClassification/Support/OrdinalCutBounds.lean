import DIDomainClassification.Section01.OrdinalCuts
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Support.CoherenceDegreeBounds
import Mathlib.SetTheory.Ordinal.Arithmetic

/-!
Literal cut consequences of the proved degree upper bound. These are
supporting diagnostics, not a proof or a silent repair of Corollary4.23.
No existence of a universal object or single generator is assumed or claimed.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.Subcategories

def firstUncountableBound : Ordinal.{u+1} :=
  (Order.succ Cardinal.aleph0.{u+1}).ord

theorem objectDegree_le_firstUncountableBound (D : CountablyBasedDIDomain.{u}) :
    objectDegree D ≤ firstUncountableBound.{u} :=
  CoherenceDegree.coherenceDegree_le_firstUncountable
    D.toDIDomainObject.isDIDomain.toIsScottDomain

theorem domainCut_eq_all_of_bound_lt {a : Ordinal.{u+1}}
    (ha : firstUncountableBound.{u} < a) :
    DomainCut a = fun _ => True := by
  funext D
  apply propext
  constructor
  · intro _
    trivial
  · intro _
    exact (objectDegree_le_firstUncountableBound D).trans_lt ha

theorem domainCut_eq_of_bounds_lt {a b : Ordinal.{u+1}}
    (ha : firstUncountableBound.{u} < a) (hb : firstUncountableBound.{u} < b) :
    DomainCut a = DomainCut b := by
  rw [domainCut_eq_all_of_bound_lt ha, domainCut_eq_all_of_bound_lt hb]

theorem finiteDomainCut_eq_finite_of_bound_lt {a : Ordinal.{u+1}}
    (ha : firstUncountableBound.{u} < a) :
    FiniteDomainCut a = fun D : CountablyBasedDIDomain.{u} => Finite D := by
  funext D
  apply propext
  change DomainCut a D ∧ Finite D ↔ Finite D
  rw [domainCut_eq_all_of_bound_lt ha]
  exact ⟨And.right, fun h => ⟨trivial, h⟩⟩

theorem domainCut_mono {a b : Ordinal.{u+1}} (hab : a ≤ b)
    {D : CountablyBasedDIDomain.{u}} (hD : DomainCut a D) : DomainCut b D :=
  hD.trans_le hab

theorem objectDegree_mono_of_scott_retraction {D E : CountablyBasedDIDomain.{u}}
    (h : HasScottRetraction D.toDIDomainObject E.toDIDomainObject) :
    objectDegree D ≤ objectDegree E := by
  obtain ⟨s, r, hs, hr, hleft⟩ := h
  exact CoherenceDegree.coherenceDegree_mono_of_scott_split
    D.toDIDomainObject.isDIDomain.toIsScottDomain
    E.toDIDomainObject.isDIDomain.toIsScottDomain hs hr hleft

theorem objectDegree_mono_of_stable_retraction {D E : CountablyBasedDIDomain.{u}}
    (h : HasStableRetraction D.toDIDomainObject E.toDIDomainObject) :
    objectDegree D ≤ objectDegree E := by
  obtain ⟨s, r, hleft⟩ := h
  exact objectDegree_mono_of_scott_retraction
    ⟨s, r, (StableHom.isStable s).1, (StableHom.isStable r).1, hleft⟩

theorem domainCut_of_stable_retraction {a : Ordinal.{u+1}}
    {D E : CountablyBasedDIDomain.{u}} (hE : DomainCut a E)
    (h : HasStableRetraction D.toDIDomainObject E.toDIDomainObject) : DomainCut a D :=
  (objectDegree_mono_of_stable_retraction h).trans_lt hE

/-- An explicit limit parameter beyond the actual degree upper bound. -/
def aboveBoundLimit : Ordinal.{u+1} :=
  (firstUncountableBound.{u} + 1) + Ordinal.omega0

theorem aboveBoundLimit_isSuccLimit : Order.IsSuccLimit aboveBoundLimit.{u} :=
  Ordinal.isSuccLimit_add _ Ordinal.isSuccLimit_omega0

theorem bound_lt_aboveBoundLimit : firstUncountableBound.{u} < aboveBoundLimit.{u} :=
  (Order.lt_succ firstUncountableBound.{u}).trans_le
    (show firstUncountableBound.{u} + 1 ≤ aboveBoundLimit.{u} from le_self_add)

theorem domainCut_aboveBoundLimit_eq_successor :
    DomainCut aboveBoundLimit.{u} = DomainCut (firstUncountableBound.{u} + 1) := by
  apply domainCut_eq_of_bounds_lt bound_lt_aboveBoundLimit
  exact Order.lt_succ _

end DIDomainClassification.Subcategories
