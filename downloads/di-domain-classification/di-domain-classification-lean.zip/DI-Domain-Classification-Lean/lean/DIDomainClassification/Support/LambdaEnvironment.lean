import DIDomainClassification.Section05.LambdaModelStatement
import DIDomainClassification.Section02.CountableProducts
import DIDomainClassification.Support.RawStableFunctionOperators
import DIDomainClassification.Support.StableCCCOperations

/-! Literal finite environments, including the empty environment, with actual
countably based domain proofs. The head/tail environment isomorphism, native
projections, joint application and curried abstraction are actual stable maps. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.LambdaEnvironment

open Preliminaries Section03.StableFunctionModels Section04.AdditionalSourceModels
open Section05 Section05.LambdaBetaModels

variable (E : CountablyBasedDIDomain.{u})

def environmentCB (n : ℕ) : IsCountablyBasedDIDomain (Fin n → Core E) :=
  (Section02.countableProducts (Fin n) (fun _ => Core E)
    (fun _ => ⟨(Core E).isDIDomain, E.countableCompacts⟩)).1

def environment (n : ℕ) : CountablyBasedDIDomain.{u} :=
  cbObject (Fin n → Core E) (environmentCB E n)

abbrev environmentCore (n : ℕ) : DIDomainObject.{u} := Core (environment E n)

abbrev product (X Y : CountablyBasedDIDomain.{u}) : CountablyBasedDIDomain.{u} :=
  Section02.StableBackground.productObject trueClosure X Y

def projection (n : ℕ) (i : Fin n) : StableHom (environmentCore E n) (Core E) := by
  refine StableHom.ofFunction (fun env => env i) ⟨?_, ?_⟩
  · intro A _hne _hdir a ha
    exact PiTheory.coordinate_isSup ha i
  · intro x y _hxy
    exact RawStableFunctionOperators.pi_inf_apply (fun _ : Fin n => Core E)
      (environmentCB E n).1 x y i

def extendOrderIso (n : ℕ) :
    (Core (environment E n) × Core E) ≃o (Fin (n+1) → Core E) where
  toFun p := extend p.2 p.1
  invFun env := (fun i => env i.succ, env 0)
  left_inv _ := rfl
  right_inv env := by
    funext i
    exact Fin.cases rfl (fun _ => rfl) i
  map_rel_iff' := by
    intro p q
    constructor
    · intro h
      exact ⟨fun i => h i.succ, h 0⟩
    · intro h i
      exact Fin.cases h.2 (fun j => h.1 j) i

def extension (n : ℕ) : StableHom (Core (product (environment E n) E))
    (environmentCore E (n+1)) :=
  OrderIsoTransport.stableHom _ _ (extendOrderIso E n)

def application (p : StableReflexivePair E) :
    StableHom (Core (product E E)) (Core E) :=
  StableHom.comp (StableCCCOperations.evaluation trueClosure E E)
    (StableCCCOperations.pair trueClosure (product E E) (exponential E E) E
      (StableHom.comp p.retractionMap (StableCCCOperations.fst trueClosure E E))
      (StableCCCOperations.snd trueClosure E E))

theorem application_apply (p : StableReflexivePair E) (xy : Core E × Core E) :
    application E p xy = p.application xy.1 xy.2 := rfl

def curriedBody (n : ℕ) (f : StableHom (environmentCore E (n+1)) (Core E)) :
    StableHom (environmentCore E n) (Core (exponential E E)) :=
  StableCCCOperations.curried trueClosure (environment E n) E E
    (StableHom.comp f (extension E n))

theorem curriedBody_apply (n : ℕ) (f : StableHom (environmentCore E (n+1)) (Core E))
    (env : Fin n → Core E) (x : Core E) :
    curriedBody E n f env x = f (extend x env) := rfl

def abstract (p : StableReflexivePair E) (n : ℕ)
    (f : StableHom (environmentCore E (n+1)) (Core E)) :
    StableHom (environmentCore E n) (Core E) :=
  StableHom.comp p.sectionMap (curriedBody E n f)

end DIDomainClassification.LambdaEnvironment
