import DIDomainClassification.Section02.EventStructures
import Mathlib.Order.UpperLower.Basic
import Mathlib.Data.Set.Finite.Lattice

/-!
Literal LOWER INTERIOR of an arbitrary event subset. This is NOT downclosure:
it removes a whenever any causal predecessor is missing. These generic set
identities do not identify a qualitative-cover carrier or prove a retraction.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.FiniteCausalConflicts

variable {A : Type u} [PartialOrder A]

def lowerInterior (Y : Set A) : Set A := {a | Set.Iic a ⊆ Y}

theorem mem_lowerInterior {Y : Set A} {a : A} :
    a ∈ lowerInterior Y ↔ Set.Iic a ⊆ Y := Iff.rfl

theorem lowerInterior_subset (Y : Set A) : lowerInterior Y ⊆ Y :=
  fun _ ha => ha le_rfl

theorem lowerInterior_isLower (Y : Set A) : IsLowerSet (lowerInterior Y) := by
  intro a b hab hb c hca
  exact hb (hca.trans hab)

theorem lowerInterior_mono {Y Z : Set A} (hYZ : Y ⊆ Z) :
    lowerInterior Y ⊆ lowerInterior Z :=
  fun _ ha _b hba => hYZ (ha hba)

theorem subset_lowerInterior_iff {X Y : Set A} (hX : IsLowerSet X) :
    X ⊆ lowerInterior Y ↔ X ⊆ Y := by
  constructor
  · exact fun h => h.trans (lowerInterior_subset Y)
  · intro h a ha b hba
    exact h (hX hba ha)

theorem lowerInterior_eq_of_lower {X : Set A} (hX : IsLowerSet X) :
    lowerInterior X = X :=
  Set.Subset.antisymm (lowerInterior_subset X)
    ((subset_lowerInterior_iff hX).mpr Set.Subset.rfl)

theorem lowerInterior_idempotent (Y : Set A) :
    lowerInterior (lowerInterior Y) = lowerInterior Y :=
  lowerInterior_eq_of_lower (lowerInterior_isLower Y)

theorem lowerInterior_empty : lowerInterior (∅ : Set A) = ∅ :=
  Set.Subset.antisymm (lowerInterior_subset ∅) (Set.empty_subset _)

theorem lowerInterior_univ : lowerInterior (Set.univ : Set A) = Set.univ := by
  apply Set.Subset.antisymm (Set.subset_univ _)
  intro a _ha _b _hba
  exact Set.mem_univ _

theorem lowerInterior_inter (Y Z : Set A) :
    lowerInterior (Y ∩ Z) = lowerInterior Y ∩ lowerInterior Z := by
  ext a
  change (Set.Iic a ⊆ Y ∩ Z) ↔ Set.Iic a ⊆ Y ∧ Set.Iic a ⊆ Z
  exact Set.subset_inter_iff

/-- Arbitrary intersections, including empty-index intersections. -/
theorem lowerInterior_iInter {I : Sort v} (Y : I → Set A) :
    lowerInterior (⋂ i, Y i) = ⋂ i, lowerInterior (Y i) := by
  ext a
  simp only [lowerInterior, Set.mem_setOf_eq, Set.subset_iInter_iff, Set.mem_iInter]

theorem lowerInterior_sInter (C : Set (Set A)) :
    lowerInterior (⋂₀ C) = ⋂₀ (lowerInterior '' C) := by
  ext a
  constructor
  · intro ha
    apply Set.mem_sInter.mpr
    intro Y hY
    obtain ⟨Z, hZ, rfl⟩ := hY
    intro b hba
    exact Set.mem_sInter.mp (ha hba) Z hZ
  · intro ha b hba
    apply Set.mem_sInter.mpr
    intro Y hY
    have haY : a ∈ lowerInterior Y := Set.mem_sInter.mp ha
      (lowerInterior Y) ⟨Y, hY, rfl⟩
    exact haY hba

/-- Directed unions use finiteness of the ENTIRE principal ideal. The empty
family is also covered: observation membership itself would give a member. -/
theorem lowerInterior_directed_sUnion
    (hIic : ∀ a : A, (Set.Iic a).Finite) {C : Set (Set A)}
    (hC : DirectedOn (· ⊆ ·) C) :
    lowerInterior (⋃₀ C) = ⋃₀ (lowerInterior '' C) := by
  ext a
  constructor
  · intro ha
    have hnonempty : C.Nonempty := by
      obtain ⟨Y, hY, _haY⟩ := Set.mem_sUnion.mp (lowerInterior_subset (⋃₀ C) ha)
      exact ⟨Y, hY⟩
    obtain ⟨Y, hY, hsub⟩ :=
      DirectedOn.exists_mem_subset_of_finite_of_subset_sUnion
        hnonempty hC (hIic a) ha
    exact Set.mem_sUnion.mpr ⟨lowerInterior Y, ⟨Y, hY, rfl⟩, hsub⟩
  · intro ha
    obtain ⟨Z, hZ, haZ⟩ := Set.mem_sUnion.mp ha
    obtain ⟨Y, hY, rfl⟩ := hZ
    intro b hba
    exact Set.mem_sUnion.mpr ⟨Y, hY, haZ hba⟩

theorem event_lowerInterior_directed_sUnion
    (E : EventStructures.FinitaryPrimeEventStructure A) {C : Set (Set A)}
    (hC : DirectedOn (· ⊆ ·) C) :
    lowerInterior (⋃₀ C) = ⋃₀ (lowerInterior '' C) :=
  lowerInterior_directed_sUnion E.finite_principalIdeal hC

end DIDomainClassification.FiniteCausalConflicts







