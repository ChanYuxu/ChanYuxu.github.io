import DIDomainClassification.Support.FiniteLeafColourPruning
import DIDomainClassification.Support.BoundedMicTreeRanks

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.LargeMicMap
open Trees CoherenceDegree Preliminaries FiniteLeafColourPruning

theorem long_leaf_subtree {Index : Type u} (T : RootedPrefixTree Index)
    (hT : T.IsWellFounded) (hp : T.IsProper) (hr : 2 ≤ T.treeRank hT) :
    ∃ (S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
      (hS : S.IsWellFounded), S.rootList = T.rootList ∧
      S.treeRank hS = T.treeRank hT ∧ S.IsProper ∧
      ∀ leaf : S.Node, S.IsLeaf leaf →
        T.IsLeaf (inclusionNodeMap T S hsub leaf) ∧ 2 ≤ S.depth leaf := by
  classical
  let colour : T.Node → Bool := fun x => if 2 ≤ T.depth x then true else false
  obtain ⟨i, S, hsub, hS, hroot, hrank, hcol, hproper⟩ :=
    finite_leaf_colour_pruning T hT colour
  have hdepth_eq (x : S.Node) : T.depth (inclusionNodeMap T S hsub x) = S.depth x := by
    change x.val.length - T.rootList.length = x.val.length - S.rootList.length
    rw [hroot]
  cases i with
  | false =>
    have hdepth : ∀ x : S.Node, S.depth x ≤ 1 := by
      intro x
      obtain ⟨leaf, hleaf, hxleaf⟩ := exists_leaf_extension S hS x
      have hc := (hcol leaf hleaf).2
      have hsmall : T.depth (inclusionNodeMap T S hsub leaf) ≤ 1 := by
        by_contra h
        have hlarge : 2 ≤ T.depth (inclusionNodeMap T S hsub leaf) := by omega
        change (if 2 ≤ T.depth (inclusionNodeMap T S hsub leaf) then true else false) =
          false at hc
        rw [if_pos hlarge] at hc
        cases hc
      rw [hdepth_eq] at hsmall
      exact (S.depth_mono hxleaf).trans hsmall
    have hbound : S.treeRank hS ≤ (1 : Ordinal.{u}) := by
      simpa only [Nat.cast_one] using S.treeRank_le_of_depth_bound hS 1 hdepth
    have hbad : (2 : Ordinal.{u}) ≤ 1 := hr.trans (hrank ▸ hbound)
    have h12 : (1 : Ordinal.{u}) < 2 := by
      simpa only [Order.succ_eq_add_one, one_add_one_eq_two] using
        Order.lt_succ (1 : Ordinal.{u})
    exact False.elim ((not_le_of_gt h12) hbad)
  | true =>
    refine ⟨S, hsub, hS, hroot, hrank, hproper hp, ?_⟩
    intro leaf hleaf
    refine ⟨(hcol leaf hleaf).1, ?_⟩
    have hc := (hcol leaf hleaf).2
    have hlarge : 2 ≤ T.depth (inclusionNodeMap T S hsub leaf) := by
      by_contra h
      change (if 2 ≤ T.depth (inclusionNodeMap T S hsub leaf) then true else false) =
        true at hc
      rw [if_neg h] at hc
      cases hc
    rwa [hdepth_eq] at hlarge

theorem coherenceDegree_le_of_large_mic_map {D E : Type u}
    [PartialOrder D] [PartialOrder E] (hD : IsScottDomain D) (hE : IsScottDomain E)
    (φ : D → E) (hinj : Function.Injective φ)
    (hK : ∀ k : D, IsCompactElement k → IsCompactElement (φ k))
    (hmic : ∀ X : Set D, X ⊆ CompactElements D →
      IsMinimallyInconsistent hD X → 3 ≤ X.ncard →
        IsMinimallyInconsistent hE (φ '' X)) :
    coherenceDegree hD ≤ max 2 (coherenceDegree hE) := by
  classical
  apply (coherenceDegree_le_iff hD _).mpr
  intro Index M hM
  by_cases hr : 2 ≤ M.tree.treeRank hM
  · obtain ⟨S, hsub, hS, hroot, hrank, hp, hleaves⟩ :=
      long_leaf_subtree M.tree hM M.proper hr
    let inc : S.Node → M.tree.Node := inclusionNodeMap M.tree S hsub
    have hi : Function.Injective inc := by
      intro x y hxy
      exact Subtype.ext (congrArg (fun z : M.tree.Node => z.val) hxy)
    have hbranch (c : Set S.Node) (hc : S.IsFiniteCompleteBranch c) :
        M.tree.IsFiniteCompleteBranch (inc '' c) :=
      inclusionNodeMap_finiteCompleteBranch M.tree S hsub hroot
        (fun x hx => (hleaves x hx).1) c hc
    let labelD : S.Node → ↥(CompactElements D) := fun x => M.label (inc x)
    have hdInj (c : Set S.Node) (hc : S.IsFiniteCompleteBranch c) :
        Set.InjOn (fun x : S.Node => (labelD x).val) c := by
      intro x hx y hy hxy
      apply hi
      apply M.isMicTree.branchInjective ((hbranch c hc).isBranch M.tree)
        ⟨x, hx, rfl⟩ ⟨y, hy, rfl⟩
      exact Subtype.ext hxy
    let label : S.Node → ↥(CompactElements E) :=
      fun x => ⟨φ (labelD x).val, hK _ (labelD x).property⟩
    have hmap : IsMicTree hE S hp label := by
      constructor
      · intro c hc x hx y hy hxy
        have hfc : S.IsFiniteCompleteBranch c :=
          (S.isFiniteCompleteBranch_iff (c := c)).mpr
            ⟨(S.isWellFounded_iff.mp hS) c hc, hc⟩
        apply hdInj c hfc hx hy
        apply hinj
        exact congrArg Subtype.val hxy
      · intro c hc
        have hdMic : IsMinimallyInconsistent hD (labelImage S labelD c) := by
          have h := M.isMicTree.finiteBranch_mic (hbranch c hc)
          simpa only [labelImage, Set.image_image, labelD, Function.comp_def] using h
        have hdK : labelImage S labelD c ⊆ CompactElements D := by
          rintro _ ⟨x, _hx, rfl⟩
          exact (labelD x).property
        have hsize : 3 ≤ (labelImage S labelD c).ncard := by
          obtain ⟨leaf, hleaf, rfl⟩ := hc
          have hcard := (hdInj (S.pathTo leaf) ⟨leaf, hleaf, rfl⟩).ncard_image
          change 3 ≤ ((fun x : S.Node => (labelD x).val) '' S.pathTo leaf).ncard
          rw [hcard, S.pathTo_ncard]
          have hlarge := (hleaves leaf hleaf).2
          omega
        have h := hmic (labelImage S labelD c) hdK hdMic hsize
        simpa only [labelImage, Set.image_image, label, Function.comp_def] using h
    let N : MicTree E hE Index := ⟨S, hp, label, hmap⟩
    have hb := treeRank_add_one_le_coherenceDegree hE N hS
    change Ordinal.lift.{u+1} (S.treeRank hS + 1) ≤ coherenceDegree hE at hb
    rw [hrank] at hb
    exact hb.trans (le_max_right _ _)
  · have hs : M.tree.treeRank hM ≤ (1 : Ordinal.{u}) := by
      apply Order.lt_succ_iff.mp
      simpa only [Order.succ_eq_add_one, one_add_one_eq_two] using lt_of_not_ge hr
    have hb : M.tree.treeRank hM + 1 ≤ (2 : Ordinal.{u}) := by
      simpa only [one_add_one_eq_two] using add_le_add hs (le_rfl : (1 : Ordinal.{u}) ≤ 1)
    have hl : Ordinal.lift.{u+1} (M.tree.treeRank hM + 1) ≤ (2 : Ordinal.{u+1}) := by
      simpa using Ordinal.lift_le.{u+1}.mpr hb
    exact hl.trans (le_max_left _ _)

end DIDomainClassification.LargeMicMap
