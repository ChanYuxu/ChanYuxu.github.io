import DIDomainClassification.Support.ContextualMicTrees
import DIDomainClassification.Support.RelativeSubtree

/-!
Explicit normalized-root/context transport. Further child-subtree/graft
bridges will use only their actually frozen generic tree construction donor.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries CoherenceDegree Trees

variable {D : Type u} [PartialOrder D] (hD : IsScottDomain D)
  {Index : Type v} (T : RootedPrefixTree Index)

def normalizedLabel (label : T.Node → ↥(CompactElements D)) :
    T.normalized.Node → ↥(CompactElements D) := fun x => label (T.normalizeOrderIso.symm x)

theorem normalizedLabel_root (label : T.Node → ↥(CompactElements D)) :
    normalizedLabel T label T.normalized.root = label T.root := by
  change label (T.normalizeOrderIso.symm T.normalized.root) = _
  rw [← T.normalizeOrderIso_root, OrderIso.symm_apply_apply]

theorem normalizedLabel_pathImage (label : T.Node → ↥(CompactElements D))
    (x : T.normalized.Node) :
    labelImage T.normalized (normalizedLabel T label) (T.normalized.pathTo x) =
      labelImage T label (T.pathTo (T.normalizeOrderIso.symm x)) := by
  ext d
  constructor
  · rintro ⟨y, hy, rfl⟩
    exact ⟨T.normalizeOrderIso.symm y, T.normalizeOrderIso.symm.monotone hy, rfl⟩
  · rintro ⟨y, hy, rfl⟩
    refine ⟨T.normalizeOrderIso y, ?_, ?_⟩
    · have h := T.normalizeOrderIso.monotone hy
      simpa only [OrderIso.apply_symm_apply] using h
    · simp only [normalizedLabel, OrderIso.symm_apply_apply]

theorem contextual_normalized {W : Set D}
    {label : T.Node → ↥(CompactElements D)} (hC : IsContextualMicTree hD T W label) :
    IsContextualMicTree hD T.normalized W (normalizedLabel T label) := by
  refine ⟨hC.1, hC.2.1, fun x => hC.2.2.1 _, ?_, ?_⟩
  · intro x y hy z hz heq
    apply T.normalizeOrderIso.symm.injective
    exact hC.2.2.2.1 (T.normalizeOrderIso.symm x)
      (T.normalizeOrderIso.symm.monotone hy) (T.normalizeOrderIso.symm.monotone hz) heq
  · intro x hx
    rw [normalizedLabel_pathImage]
    have hxT : T.IsLeaf (T.normalizeOrderIso.symm x) := by
      apply (T.normalizeOrderIso_isLeaf _).1
      simpa only [OrderIso.apply_symm_apply] using hx
    exact hC.2.2.2.2 _ hxT

theorem contextual_normalized_basis {B : Set D}
    {label : T.Node → ↥(CompactElements D)} (hB : ∀ x, (label x : D) ∈ B) :
    ∀ x, (normalizedLabel T label x : D) ∈ B := fun x => hB _

def childLabel (label : T.Node → ↥(CompactElements D)) (x : T.Node) :
    (TreeGrafting.above T x).Node → ↥(CompactElements D) :=
  fun y => label (TreeGrafting.aboveNodeMap T x y)

/-- The actual immediate-child subtree has the old root added to its context.
No WF or degree statement is needed to prove these literal path conditions. -/
theorem contextual_child {W : Set D} {label : T.Node → ↥(CompactElements D)}
    (hC : IsContextualMicTree hD T W label) {x : T.Node} (hx : T.IsChild T.root x) :
    IsContextualMicTree hD (TreeGrafting.above T x)
      (W ∪ {(label T.root : D)}) (childLabel T label x) := by
  refine ⟨hC.1.union (Set.finite_singleton _), ?_, ?_, ?_, ?_⟩
  · intro a ha
    rcases ha with hw | ha
    · exact hC.2.1 hw
    · simpa only [Set.mem_singleton_iff.mp ha] using (label T.root).property
  · intro y hy
    rcases hy with hw | hy
    · exact hC.2.2.1 _ hw
    · have hnode : TreeGrafting.aboveNodeMap T x y = T.root :=
        hC.2.2.2.1 (TreeGrafting.aboveNodeMap T x y)
          (List.prefix_refl _) (T.root_le _) (Subtype.ext (Set.mem_singleton_iff.mp hy))
      have hxr : x.val <+: T.root.val := by
        simpa only [← hnode] using y.property.2
      have hdepth := T.depth_mono hxr
      have hxdepth := hx.2
      simp only [T.depth_root] at hdepth hxdepth
      omega
  · intro y z hz w hw heq
    have h := hC.2.2.2.1 (TreeGrafting.aboveNodeMap T x y) hz hw heq
    exact TreeGrafting.aboveNodeMap_injective T x h
  · intro y hy
    have hyleaf := (TreeGrafting.aboveNodeMap_isLeaf_iff T x y).1 hy
    have hmic := hC.2.2.2.2 (TreeGrafting.aboveNodeMap T x y) hyleaf
    have hsplit := TreeGrafting.above_root_child_path_split T hx y
    rw [labelImage, hsplit, Set.image_union, Set.image_singleton, Set.image_image] at hmic
    simpa only [childLabel, labelImage, Set.union_assoc] using hmic

/-- It is enough to verify all context conditions on actual complete paths;
WF supplies a complete extension for every node/path, with no finite branching.
-/
theorem contextual_of_leaf_paths {W : Set D} {label : T.Node → ↥(CompactElements D)}
    (hT : T.IsWellFounded) (hW : W.Finite) (hWcompact : W ⊆ CompactElements D)
    (hLeaves : ∀ leaf : T.Node, T.IsLeaf leaf →
      Set.InjOn label (T.pathTo leaf) ∧
      (∀ x ∈ T.pathTo leaf, (label x : D) ∉ W) ∧
      IsMinimallyInconsistent hD (W ∪ labelImage T label (T.pathTo leaf))) :
    IsContextualMicTree hD T W label := by
  refine ⟨hW, hWcompact, ?_, ?_, ?_⟩
  · intro x
    obtain ⟨leaf, hleaf, hxl⟩ := FiniteLeafColourPruning.exists_leaf_extension T hT x
    exact (hLeaves leaf hleaf).2.1 x hxl
  · intro x y hy z hz heq
    obtain ⟨leaf, hleaf, hxl⟩ := FiniteLeafColourPruning.exists_leaf_extension T hT x
    exact (hLeaves leaf hleaf).1
      ((show y.val <+: x.val from hy).trans hxl)
      ((show z.val <+: x.val from hz).trans hxl) heq
  · intro leaf hleaf
    exact (hLeaves leaf hleaf).2.2

theorem child_subtree_rank_lt (hT : T.IsWellFounded) {x : T.Node}
    (hx : T.IsChild T.root x) :
    (TreeGrafting.above T x).treeRank (TreeGrafting.above_isWellFounded T hT x) <
      T.treeRank hT := by
  rw [TreeGrafting.above_treeRank_eq]
  have hsucc : T.nodeRank hT x < T.nodeRank hT x + 1 := by
    simpa only [Order.succ_eq_add_one] using Order.lt_succ (T.nodeRank hT x)
  exact hsucc.trans_le (FiniteLeafColourPruning.nodeRank_add_one_le_of_child T hT hx)

theorem tailLabelImage_eq_diff {label : T.Node → ↥(CompactElements D)}
    (x : T.Node) (hinj : Set.InjOn label (T.pathTo x)) :
    tailLabelImage T label x =
      labelImage T label (T.pathTo x) \ {(label T.root : D)} := by
  have hi : Set.InjOn (fun y => (label y : D)) (T.pathTo x) :=
    fun _ hy _ hz heq => hinj hy hz (Subtype.ext heq)
  have hsub : ({T.root} : Set T.Node) ⊆ T.pathTo x := by
    rintro y rfl
    exact T.root_le x
  simpa only [tailLabelImage, labelImage, Set.image_singleton] using hi.image_diff_subset hsub

theorem tailLabelImage_pruned {W : Set D} {label : T.Node → ↥(CompactElements D)}
    (hC : IsContextualMicTree hD T W label)
    (S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
    (hroot : S.rootList = T.rootList) (x : S.Node) :
    tailLabelImage S (fun y => label (FiniteLeafColourPruning.inclusionNodeMap T S hsub y)) x =
      tailLabelImage T label (FiniteLeafColourPruning.inclusionNodeMap T S hsub x) := by
  let f := FiniteLeafColourPruning.inclusionNodeMap T S hsub
  have hinj : Set.InjOn (fun y => label (f y)) (S.pathTo x) := by
    intro y hy z hz heq
    have h := hC.2.2.2.1 (f x) hy hz heq
    exact Subtype.ext (congrArg (fun y : T.Node => y.val) h)
  rw [tailLabelImage_eq_diff S x hinj,
    tailLabelImage_eq_diff T (f x) (hC.2.2.2.1 (f x))]
  have hpath := FiniteLeafColourPruning.inclusionNodeMap_pathTo T S hsub hroot x
  have himage : labelImage S (fun y => label (f y)) (S.pathTo x) =
      labelImage T label (T.pathTo (f x)) := by
    change (fun y => (label (f y) : D)) '' S.pathTo x = _
    rw [← hpath, labelImage, Set.image_image]
  rw [himage]
  change _ \ {(label (f S.root) : D)} = _
  rw [show f S.root = T.root from
    FiniteLeafColourPruning.inclusionNodeMap_root T S hsub hroot]

end DIDomainClassification.PointwiseFunctionSupport
