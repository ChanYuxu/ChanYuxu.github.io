import DIDomainClassification.Support.ComparisonCoherence
import DIDomainClassification.Section04.SeparatedSum

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonProducts
open Preliminaries Section03.StableFunctionModels
open Section04 AdditionalSourceModels Section02.RetractionCalculusModels

theorem countable_product : ComparisonCountableProductStatement.{u} := by
  classical
  intro I _ D E hDE
  by_cases hI : Nonempty I
  · letI : Nonempty I := hI
    choose H hH hs using hDE
    choose s r hleft using hs
    obtain ⟨hD,hA,hS,hR,hleftPi⟩ := Section02.retractionCountableProduct I D
      (fun i => exponential (H i) E) s r hleft
    obtain ⟨hSum,hFamily,_hCompact,hTwo,S,R,_hSv,_hRv,hSR⟩ :=
      Section04.separatedSumGeneral I H E
    let Sum := cbObject (Section04.SeparatedSumModels.Carrier H) hSum
    refine ⟨hD,Sum,hTwo hH, ?_⟩
    have hPi : HasStableRetraction (Core (cbObject (∀ i, Core (D i)) hD))
        (Core (cbObject (∀ i, StableSpace (H i) E) hA)) :=
      ⟨StableHom.ofFunction _ hS,StableHom.ofFunction _ hR,hleftPi⟩
    exact ComparisonOperations.split_trans hPi ⟨S,R,hSR⟩
  · let hD := (Section02.countableProducts I (fun i => Core (D i))
      (fun i => ⟨(Core (D i)).isDIDomain,(D i).countableCompacts⟩)).1
    let A := cbObject (∀ i, Core (D i)) hD
    let a : Core A := fun i => False.elim (hI ⟨i⟩)
    have hAE : HasStableRetraction (Core A) (Core E) := by
      refine ⟨StableMapOperators.constant A E (Core E).isDIDomain.toIsScottDomain.bottom,
        StableMapOperators.constant E A a, ?_⟩
      intro x
      funext i
      exact False.elim (hI ⟨i⟩)
    exact ⟨hD,ComparisonOperations.retraction_comparison A E hAE⟩

def liftPiOrderIso {J : Type} (D : J → CountablyBasedDIDomain.{u}) :
    (∀ j, Core (D j)) ≃o (∀ j : ULift.{u} J, Core (D j.down)) where
  toFun f j := f j.down
  invFun g j := g ⟨j⟩
  left_inv _ := rfl
  right_inv g := by funext j; cases j; rfl
  map_rel_iff' := by
    intro f g
    constructor
    · intro h j; exact h ⟨j⟩
    · intro h j; exact h j.down

theorem small_product {J : Type} [Countable J] (D : J → CountablyBasedDIDomain.{u})
    (E : CountablyBasedDIDomain.{u}) (h : ∀ j, StableComparison (D j) E) :
    ∃ hD : IsCountablyBasedDIDomain (∀ j, Core (D j)),
      StableComparison (cbObject (∀ j, Core (D j)) hD) E := by
  obtain ⟨hLift,hC⟩ := countable_product (ULift.{u} J) (fun j => D j.down) E
    (fun j => h j.down)
  let e := liftPiOrderIso D
  let hD := (OrderIsoTransport.isCountablyBasedDIDomain_iff e).mpr hLift
  refine ⟨hD,ComparisonOperations.split_comparison ?_ hC⟩
  exact ComparisonOperations.iso_split _ _ e

theorem nat_product : ComparisonNatProductStatement.{u} := by
  intro D E h
  exact small_product D E h

theorem finite_product : ComparisonFiniteProductStatement.{u} := by
  intro n D E h
  exact small_product D E h

end DIDomainClassification.ComparisonProducts
