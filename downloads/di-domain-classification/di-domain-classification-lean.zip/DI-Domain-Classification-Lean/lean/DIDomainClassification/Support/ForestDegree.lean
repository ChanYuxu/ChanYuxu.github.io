import DIDomainClassification.Support.ForestUniverseTransport
import DIDomainClassification.Section03.FunctionDegreeUpper
import DIDomainClassification.Section04.QualitativeCoherence

/-! Coherence-degree calculations for the actual literal forest product.
Universe lifts are proved for the tree factors, never supplied as premises. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ForestDegree
open Preliminaries EventStructures Trees CoherenceDegree
open Section04.ForestModels Section04.AdditionalSourceModels
open ForestPrefixTrees ForestProductMaps ForestUniverseTransport

theorem powerset_degree_zero (A : Type u) [Countable A]
    (hA : IsScottDomain (Set A)) : coherenceDegree hA = 0 := by
  apply ((Section02.bps.{u}).2.2.2.2.2.1 (Set A) hA (powerset_countablyBased A).2).mpr
  intro C
  exact ⟨⟨sSup C, isLUB_sSup C⟩, ⟨sInf C, isGLB_sInf C⟩⟩

variable {A : Type u} [PartialOrder A]

abbrev ProductIndex (E : FinitaryPrimeEventStructure A) (e : A → ℕ) :=
  PUnit.{u+1} ⊕ ULift.{u} (Roots E e)

instance productIndexCountable (E : FinitaryPrimeEventStructure A) (e : A → ℕ) :
    Countable (ProductIndex E e) := by
  dsimp [ProductIndex]
  infer_instance

def ProductFactor (E : FinitaryPrimeEventStructure A) (e : A → ℕ) :
    ProductIndex E e → Type u
  | .inl _ => Set A
  | .inr i => ULift.{u} (TreeDomain (tree E e i.down))

instance factorOrder (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (k : ProductIndex E e) : PartialOrder (ProductFactor E e k) := by
  cases k with
  | inl _ => exact inferInstanceAs (PartialOrder (Set A))
  | inr i => exact inferInstanceAs (PartialOrder (ULift.{u} (TreeDomain (tree E e i.down))))

def factorCB (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) [Countable A] (k : ProductIndex E e) :
    IsCountablyBasedDIDomain (ProductFactor E e k) := by
  cases k with
  | inl _ => exact powerset_countablyBased A
  | inr i =>
      exact (OrderIsoTransport.isCountablyBasedDIDomain_iff
        (ForestProductMaps.liftOrderIso (TreeDomain (tree E e i.down)))).mpr
        (treeCB E e he i.down)

def productFactorIso (E : FinitaryPrimeEventStructure A) (e : A → ℕ) :
    (∀ k : ProductIndex E e, ProductFactor E e k) ≃o Product E e where
  toFun f := (f (.inl PUnit.unit), fun i => (f (.inr ⟨i⟩)).down)
  invFun P := fun k => match k with
    | .inl _ => P.1
    | .inr i => ⟨P.2 i.down⟩
  left_inv f := by
    funext k
    cases k with
    | inl x => cases x; rfl
    | inr i => cases i; rfl
  right_inv _ := rfl
  map_rel_iff' := by
    intro f g
    constructor
    · intro h k
      cases k with
      | inl x => cases x; exact h.1
      | inr i => exact h.2 i.down
    · intro h
      exact ⟨h (.inl PUnit.unit), fun i => h (.inr ⟨i⟩)⟩

theorem tree_factor_degree (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) [Countable A] (i : Roots E e) :
    coherenceDegree (factorCB E e he (.inr ⟨i⟩)).1.toIsScottDomain =
      Ordinal.lift.{u+1} (coherenceDegree (treeCB E e he i).1.toIsScottDomain) :=
  lifted_tree_degree (tree E e i) (proper E e he i) _ _

theorem product_degree (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) [Countable A]
    (hP : IsCountablyBasedDIDomain (Product E e)) :
    coherenceDegree hP.1.toIsScottDomain =
      ⨆ i : Roots E e, Ordinal.lift.{u+1}
        (coherenceDegree (treeCB E e he i).1.toIsScottDomain) := by
  let hD := fun k : ProductIndex E e => (factorCB E e he k).1.toIsScottDomain
  calc
    coherenceDegree hP.1.toIsScottDomain =
        coherenceDegree (BPSProductDegree.productScottDomain hD) :=
      degree_orderIso _ _ (productFactorIso E e).symm
    _ = ⨆ k : ProductIndex E e, coherenceDegree (hD k) :=
      BPSProductDegree.product_coherenceDegree_eq hD
    _ = ⨆ i : Roots E e, Ordinal.lift.{u+1}
        (coherenceDegree (treeCB E e he i).1.toIsScottDomain) := by
      apply le_antisymm
      · apply Ordinal.iSup_le
        intro k
        cases k with
        | inl x =>
            exact (powerset_degree_zero A (hD (.inl x))).le.trans (zero_le _)
        | inr i =>
            change coherenceDegree (factorCB E e he (.inr i)).1.toIsScottDomain ≤ _
            rw [tree_factor_degree E e he i.down]
            exact Ordinal.le_iSup
              (fun j : Roots E e => Ordinal.lift.{u+1}
                (coherenceDegree (treeCB E e he j).1.toIsScottDomain)) i.down
      · apply Ordinal.iSup_le
        intro i
        have h := Ordinal.le_iSup (fun k : ProductIndex E e => coherenceDegree (hD k))
          (.inr ⟨i⟩)
        change coherenceDegree (factorCB E e he (.inr ⟨i⟩)).1.toIsScottDomain ≤ _ at h
        rw [tree_factor_degree E e he i] at h
        exact h

def emptyCoverIso (E : FinitaryPrimeEventStructure A)
    (hEmpty : causalConflictFamily E = ∅) : QualitativeCover E ≃o Set A where
  toFun X := X.val
  invFun X := ⟨X, by intro H hH; rw [hEmpty] at hH; cases hH⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

theorem empty_degrees (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) [Countable A]
    (hE : IsCountablyBasedDIDomain (Configuration E)) (C : QualitativeCoverClosure E)
    (hEmpty : causalConflictFamily E = ∅) :
    coherenceDegree hE.1.toIsScottDomain = 0 ∧
      coherenceDegree C.domain.toIsScottDomain = 0 ∧
      (⨆ i : Roots E e, Ordinal.lift.{u+1}
        (coherenceDegree (treeCB E e he i).1.toIsScottDomain)) = 0 := by
  refine ⟨QualitativeCausalCoherence.empty_degree E hE hEmpty, ?_, ?_⟩
  · exact (degree_orderIso C.domain.toIsScottDomain
      (powerset_countablyBased A).1.toIsScottDomain (emptyCoverIso E hEmpty)).trans
      (powerset_degree_zero A _)
  · apply Ordinal.iSup_eq_zero_iff.mpr
    intro i
    obtain ⟨H, hH, _⟩ := i.property
    rw [hEmpty] at hH
    exact False.elim hH

theorem tree_degree_le_function_upper (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) (hE : IsCountablyBasedDIDomain (Configuration E))
    (i : Roots E e) :
    Ordinal.lift.{u+1} (coherenceDegree (treeCB E e he i).1.toIsScottDomain) ≤
      max 2 (coherenceDegree hE.1.toIsScottDomain) := by
  obtain ⟨hT, hH, s, r, hleft⟩ := realised_tree E e he i
  let T := tree E e i
  let Ts := treeCore T hT.1
  let Hs := (completionCB T (proper E e he i) hH).toDIDomainObject
  let Ec := causalConfigurationCore E
  let hTb : IsCountablyBasedDIDomain (ULift.{u} (TreeDomain T)) :=
    (OrderIsoTransport.isCountablyBasedDIDomain_iff
      (ForestProductMaps.liftOrderIso (TreeDomain T))).mpr hT
  let Tb := cbObject (ULift.{u} (TreeDomain T)) hTb
  let qT : Tb.toDIDomainObject ≃o Ts := ForestProductMaps.liftOrderIso (TreeDomain T)
  let hHb : IsCountablyBasedDIDomain (ULift.{u} Hs) :=
    (OrderIsoTransport.isCountablyBasedDIDomain_iff (ForestProductMaps.liftOrderIso Hs)).mpr hH
  let Hb := cbObject (ULift.{u} Hs) hHb
  let qH : Hb.toDIDomainObject ≃o Hs := ForestProductMaps.liftOrderIso Hs
  let Fs : DIDomainObject.{u} := functionCore Hs Ec
  let Fb : DIDomainObject.{u} := functionCore Hb.toDIDomainObject Ec
  let sb : StableHom Tb.toDIDomainObject Fs :=
    StableHom.comp s (OrderIsoTransport.stableHom _ _ qT)
  let rb : StableHom Fs Tb.toDIDomainObject :=
    StableHom.comp (OrderIsoTransport.stableHom _ _ qT.symm) r
  have hsplit : Function.LeftInverse (rb : Fs → Tb.toDIDomainObject)
      (sb : Tb.toDIDomainObject → Fs) := by
    intro x
    change qT.symm (r (s (qT x))) = x
    rw [hleft (qT x), qT.symm_apply_apply]
  have hmono : coherenceDegree hTb.1.toIsScottDomain ≤
      coherenceDegree Fs.isDIDomain.toIsScottDomain :=
    coherenceDegree_mono_of_scott_split _ _ (StableHom.isStable sb).1
      (StableHom.isStable rb).1 hsplit
  have hFuncIso : coherenceDegree Fs.isDIDomain.toIsScottDomain =
      coherenceDegree Fb.isDIDomain.toIsScottDomain :=
    degree_orderIso _ _ (inputOrderIso Hs Hb.toDIDomainObject Ec qH)
  have hUpper : coherenceDegree Fb.isDIDomain.toIsScottDomain ≤
      max 2 (coherenceDegree hE.1.toIsScottDomain) :=
    Section03.functionDegreeUpper Hb (configurationCB E hE)
  calc
    Ordinal.lift.{u+1} (coherenceDegree (treeCB E e he i).1.toIsScottDomain) =
        coherenceDegree hTb.1.toIsScottDomain :=
      (lifted_tree_degree T (proper E e he i) _ hTb.1.toIsScottDomain).symm
    _ ≤ coherenceDegree Fs.isDIDomain.toIsScottDomain := hmono
    _ = coherenceDegree Fb.isDIDomain.toIsScottDomain := hFuncIso
    _ ≤ max 2 (coherenceDegree hE.1.toIsScottDomain) := hUpper

theorem two_le_of_nonempty (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (hne : (causalConflictFamily E).Nonempty) : 2 ≤ coherenceDegree hE.1.toIsScottDomain := by
  obtain ⟨H, hH⟩ := hne
  have hc : (2 : Ordinal.{u+1}) ≤ (H.ncard : Ordinal.{u+1}) := by
    exact_mod_cast FiniteCausalConflicts.conflict_member_card_ge_two E hH
  exact hc.trans (QualitativeCausalCoherence.conflict_card_le_degree E
    hE.1.toIsScottDomain H hH)

theorem degree_equalities (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (he : Function.Injective e) [Countable A]
    (hE : IsCountablyBasedDIDomain (Configuration E)) (C : QualitativeCoverClosure E)
    (hP : IsCountablyBasedDIDomain (Product E e))
    (hCausal : HasStableRetraction (causalConfigurationCore E) (qualitativeCoverCore E C)) :
    coherenceDegree hE.1.toIsScottDomain = coherenceDegree C.domain.toIsScottDomain ∧
      coherenceDegree C.domain.toIsScottDomain =
        ⨆ i : Roots E e, Ordinal.lift.{u+1}
          (coherenceDegree (treeCB E e he i).1.toIsScottDomain) := by
  classical
  by_cases hEmpty : causalConflictFamily E = ∅
  · obtain ⟨hE0, hC0, hI0⟩ := empty_degrees E e he hE C hEmpty
    exact ⟨hE0.trans hC0.symm, hC0.trans hI0.symm⟩
  · have hne : (causalConflictFamily E).Nonempty := Set.nonempty_iff_ne_empty.mpr hEmpty
    have hTwo := two_le_of_nonempty E hE hne
    have hTree : ∀ i : Roots E e,
        Ordinal.lift.{u+1} (coherenceDegree (treeCB E e he i).1.toIsScottDomain) ≤
          coherenceDegree hE.1.toIsScottDomain := by
      intro i
      exact (tree_degree_le_function_upper E e he hE i).trans (max_le hTwo le_rfl)
    have hIE : (⨆ i : Roots E e, Ordinal.lift.{u+1}
        (coherenceDegree (treeCB E e he i).1.toIsScottDomain)) ≤
        coherenceDegree hE.1.toIsScottDomain := Ordinal.iSup_le hTree
    have hEC : coherenceDegree hE.1.toIsScottDomain ≤
        coherenceDegree C.domain.toIsScottDomain := by
      obtain ⟨s, r, hleft⟩ := hCausal
      exact coherenceDegree_mono_of_scott_split _ _ (StableHom.isStable s).1
        (StableHom.isStable r).1 hleft
    have hCI : coherenceDegree C.domain.toIsScottDomain ≤
        ⨆ i : Roots E e, Ordinal.lift.{u+1}
          (coherenceDegree (treeCB E e he i).1.toIsScottDomain) := by
      have hmono := coherenceDegree_mono_of_scott_split C.domain.toIsScottDomain
        hP.1.toIsScottDomain (StableHom.isStable (sectionHom E e he C hP)).1
        (StableHom.isStable (retraction E e he C hP)).1 (native_leftInverse E e he C hP)
      exact hmono.trans_eq (product_degree E e he hP)
    exact ⟨le_antisymm hEC (hCI.trans hIE), le_antisymm hCI (hIE.trans hEC)⟩

end DIDomainClassification.ForestDegree
