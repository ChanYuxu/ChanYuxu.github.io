import DIDomainClassification.Support.SeparatedSumFunctions
import DIDomainClassification.Support.RawStableFunctionOperators
import DIDomainClassification.Support.StableHomPointwiseSupport
import DIDomainClassification.Support.PiCountability
import DIDomainClassification.Section02.CountableProducts

/-! Stability of the section/restriction in the native higher-order orders. -/
set_option autoImplicit false
universe u v w a b
noncomputable section

namespace DIDomainClassification.SeparatedSumHomOperations
open OrderCore Preliminaries
open Section03.StableFunctionModels Section04.AdditionalSourceModels
open Section04.SeparatedSumModels SeparatedSumOrder SeparatedSumDomain SeparatedSumFunctions

variable {I : Type v} (H : I → CountablyBasedDIDomain.{u})
  (E : CountablyBasedDIDomain.{w})

def homFamily (i : I) : DIDomainObject.{max u w} :=
  functionCore (Core (H i)) (Core E)

def familyCore : DIDomainObject.{max u v w} :=
  DIDomainObject.ofType (∀ i, StableHom (Core (H i)) (Core E))
    (RawStableFunctionOperators.piDomain (homFamily H E))

def targetCore : DIDomainObject.{max u v w} :=
  functionCore (sumCore H) (Core E)

theorem family_countablyBased [Countable I] :
    IsCountablyBasedDIDomain (∀ i, StableHom (Core (H i)) (Core E)) := by
  exact (Section02.countableProducts I
    (fun i => StableHom (Core (H i)) (Core E))
    (fun i => StableExponentialClosure.stableHom_isCountablyBasedDIDomain (H i) E)).1

theorem raw_inf_apply {D : DIDomainObject.{a}} {F : DIDomainObject.{b}}
    (f g : StableHom D F) (hfg : Compatible f g) (x : D) :
    functionValue D F ((functionCore D F).isDIDomain.toIsScottDomain.inf f g) x =
      f x ⊓ g x :=
  (StableHomPointwiseSupport.hom_isGLB_pair_iff_values f g hfg _).mp
    ((functionCore D F).isDIDomain.toIsScottDomain.inf_isGLB f g) x

theorem family_compatible (f g : familyCore H E) (hfg : Compatible f g) (i : I) :
    Compatible (f i) (g i) := by
  obtain ⟨h, hfh, hgh⟩ := hfg
  exact ⟨h i, hfh i, hgh i⟩

theorem family_inf_eval (f g : familyCore H E) (hfg : Compatible f g)
    (i : I) (x : Core (H i)) :
    (((familyCore H E).isDIDomain.toIsScottDomain.inf f g) i) x =
      f i x ⊓ g i x := by
  have hp := RawStableFunctionOperators.pi_inf_apply (homFamily H E)
    (familyCore H E).isDIDomain f g i
  change (((familyCore H E).isDIDomain.toIsScottDomain.inf f g) i) =
      ((homFamily H E i).isDIDomain.toIsScottDomain.inf (f i) (g i)) at hp
  rw [hp]
  exact raw_inf_apply (f i) (g i) (family_compatible H E f g hfg i) x

theorem section_continuous :
    ScottContinuous (sectionHom H E : familyCore H E → targetCore H E) := by
  intro X hne hdir s hs
  have hX : DirectedSet X := ⟨hne, hdir⟩
  have hSX := hX.image (sectionHom_monotone H E)
  apply (StableHomPointwiseSupport.hom_isLUB_iff_values
    (sectionHom H E '' X) hSX (sectionHom H E s)).mpr
  intro x
  rw [Set.image_image]
  rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
  · constructor
    · rintro _ ⟨f, _hf, rfl⟩
      exact le_rfl
    · intro z _hz
      exact (Core E).isDIDomain.toIsScottDomain.bottom_le _
  · have hI : DirectedSet (Function.eval i '' X) := hX.image (fun _ _ h => h i)
    have hsI := PiTheory.coordinate_isSup hs i
    have hsI' : IsLUB (Function.eval i '' X) (s i) :=
      OrderCore.isSup_iff_isLUB.mp hsI
    have hv := (StableHomPointwiseSupport.hom_isLUB_iff_values
      (D := Core (H i)) (E := Core E)
      (Function.eval i '' X) hI (s i)).mp hsI' a
    simpa only [Set.image_image, Function.comp_def] using hv

theorem section_map_compatible (f g : familyCore H E) (hfg : Compatible f g) :
    Compatible (sectionHom H E f) (sectionHom H E g) := by
  obtain ⟨h, hfh, hgh⟩ := hfg
  exact ⟨sectionHom H E h, sectionHom_monotone H E hfh, sectionHom_monotone H E hgh⟩

theorem section_stable :
    IsStable (familyCore H E) (targetCore H E) (sectionHom H E) := by
  refine ⟨section_continuous H E, ?_⟩
  intro f g hfg
  apply StableHom.ext
  intro x
  change sectionHom H E ((familyCore H E).isDIDomain.toIsScottDomain.inf f g) x =
    functionValue (sumCore H) (Core E)
      ((functionCore (sumCore H) (Core E)).isDIDomain.toIsScottDomain.inf
        (sectionHom H E f) (sectionHom H E g)) x
  rw [raw_inf_apply _ _ (section_map_compatible H E f g hfg)]
  rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
  · change (Core E).isDIDomain.toIsScottDomain.bottom =
      (Core E).isDIDomain.toIsScottDomain.bottom ⊓
        (Core E).isDIDomain.toIsScottDomain.bottom
    exact (inf_idem _).symm
  · exact family_inf_eval H E f g hfg i a

theorem restriction_continuous :
    ScottContinuous (restriction H E : targetCore H E → familyCore H E) := by
  intro X hne hdir s hs
  have hX : DirectedSet X := ⟨hne, hdir⟩
  have hRX := hX.image (restriction_monotone H E)
  apply isLUB_pi.mpr
  intro i
  have hI : DirectedSet (Function.eval i '' (restriction H E '' X)) :=
    hRX.image (fun _ _ h => h i)
  apply (StableHomPointwiseSupport.hom_isLUB_iff_values
    (Function.eval i '' (restriction H E '' X)) hI (restriction H E s i)).mpr
  intro x
  have hv := (StableHomPointwiseSupport.hom_isLUB_iff_values X hX s).mp hs
    (component H i x)
  simpa only [Set.image_image, Function.comp_def] using hv

theorem restriction_map_compatible (f g : targetCore H E) (hfg : Compatible f g) :
    Compatible (restriction H E f) (restriction H E g) := by
  obtain ⟨h, hfh, hgh⟩ := hfg
  exact ⟨restriction H E h, restriction_monotone H E hfh, restriction_monotone H E hgh⟩

theorem restriction_stable :
    IsStable (targetCore H E) (familyCore H E) (restriction H E) := by
  refine ⟨restriction_continuous H E, ?_⟩
  intro f g hfg
  funext i
  apply StableHom.ext
  intro x
  change functionValue (sumCore H) (Core E)
      ((functionCore (sumCore H) (Core E)).isDIDomain.toIsScottDomain.inf f g)
      (component H i x) =
    (((familyCore H E).isDIDomain.toIsScottDomain.inf
      (restriction H E f) (restriction H E g)) i) x
  rw [family_inf_eval H E _ _ (restriction_map_compatible H E f g hfg)]
  exact raw_inf_apply f g hfg (component H i x)

def sectionMap : StableHom (familyCore H E) (targetCore H E) :=
  StableHom.ofFunction (sectionHom H E) (section_stable H E)

def restrictionMap : StableHom (targetCore H E) (familyCore H E) :=
  StableHom.ofFunction (restriction H E) (restriction_stable H E)

theorem maps_leftInverse :
    Function.LeftInverse (restrictionMap H E : targetCore H E → familyCore H E)
      (sectionMap H E : familyCore H E → targetCore H E) :=
  restriction_section H E

end DIDomainClassification.SeparatedSumHomOperations
