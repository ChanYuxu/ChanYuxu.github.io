import DIDomainClassification.Support.PiCompact
import Mathlib.Data.Set.Countable
import Mathlib.Logic.Equiv.List

/-!
# Countability of the finite-support compact product basis

Finite restricted products, their extension images, and the countable union
over Finset I are used. No unrestricted countable product of countable sets
is claimed to be countable, and the full product carrier is not enumerated.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.PiTheory

open OrderCore

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]
  [∀ i, OrderBot (D i)]

noncomputable def extend (F : Finset I) (a : (i : F) → D i) : ∀ i, D i := by
  classical
  exact fun i => if hi : i ∈ F then a ⟨i, hi⟩ else ⊥

theorem pi_compact_countable [Countable I]
    (hK : ∀ i, (CompactSet (D i)).Countable) : (CompactSet (∀ i, D i)).Countable := by
  classical
  let C (F : Finset I) : Set ((i : F) → D i) := {a | ∀ i, Compact (a i)}
  have hC (F : Finset I) : (C F).Countable :=
    Set.countable_pi (fun i : F => hK i)
  have hUnion : (⋃ F : Finset I, extend F '' C F).Countable :=
    Set.countable_iUnion (fun F => (hC F).image (extend F))
  apply Set.Countable.mono ?_ hUnion
  intro x hx
  have hfinite := compact_finite_support hx
  let F : Finset I := hfinite.toFinset
  apply Set.mem_iUnion.mpr
  refine ⟨F, (fun i : F => x i), ?_, ?_⟩
  · intro i
    exact compact_coordinate hx i
  · funext i
    by_cases hi : i ∈ F
    · simp [extend, hi]
    · have hinot : i ∉ support x := by
        simpa only [F, Set.Finite.mem_toFinset] using hi
      have hxi : x i = ⊥ := (not_mem_support x i).mp hinot
      simp [extend, hi, hxi]

end DIDomainClassification.PiTheory
