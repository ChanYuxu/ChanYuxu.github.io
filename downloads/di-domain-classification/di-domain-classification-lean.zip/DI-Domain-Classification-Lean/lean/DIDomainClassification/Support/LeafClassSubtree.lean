import DIDomainClassification.Section02.RankDegree

/-!
Generic ancestor-closed leaf-class subtrees. Source motivation: BPS2014,
Lemma4.2, printed20, with its use for possibly trivial contextual trees at21.
No source-facing BPS wrapper, properness or finite-branching input.
Every comparison below is a literal list prefix or a frozen source-tree
predicate, avoiding inherited List/subtype order instances.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.FiniteLeafColourPruning

open Trees

variable {Index : Type u} {Colour : Type v}

theorem exists_leaf_extension (T : RootedPrefixTree Index) (hT : T.IsWellFounded)
    (x : T.Node) : ∃ y : T.Node, T.IsLeaf y ∧ x.val <+: y.val := by
  classical
  refine (T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).induction
    (C := fun x : T.Node => ∃ y : T.Node, T.IsLeaf y ∧ x.val <+: y.val) x ?_
  intro x ih
  by_cases hx : T.IsLeaf x
  · exact ⟨x, hx, List.prefix_refl _⟩
  · have hchild : ∃ y : T.Node, T.IsChild x y := by
      by_contra h
      exact hx ((T.isLeaf_iff_no_child x).mpr h)
    obtain ⟨y, hy⟩ := hchild
    obtain ⟨z, hz, hyz⟩ := ih y hy
    exact ⟨z, hz, hy.1.trans hyz⟩

def ReachesClass (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (v : List Index) : Prop :=
  ∃ leaf : T.Node, T.IsLeaf leaf ∧ leaf ∈ L i ∧ v <+: leaf.val

theorem reachesClass_of_prefix (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) {v w : List Index} (hvw : v <+: w) (hw : ReachesClass T L i w) :
    ReachesClass T L i v := by
  obtain ⟨leaf, hleaf, hclass, hwleaf⟩ := hw
  exact ⟨leaf, hleaf, hclass, hvw.trans hwleaf⟩

def classTree (T : RootedPrefixTree Index) (L : Colour → Set T.Node) (i : Colour)
    (hi : ReachesClass T L i T.rootList) : RootedPrefixTree Index where
  nodes := {v | v ∈ T.nodes ∧ ReachesClass T L i v}
  rootList := T.rootList
  root_mem := ⟨T.root_mem, hi⟩
  root_prefix := fun hv => T.root_prefix hv.1
  prefix_closed := by
    intro v w hroot hvw hw
    exact ⟨T.prefix_closed hroot hvw hw.1, reachesClass_of_prefix T L i hvw hw.2⟩
  countable_nodes := T.countable_nodes.mono (fun _ hv => hv.1)

theorem classTree_rootList (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList) :
    (classTree T L i hi).rootList = T.rootList := rfl

theorem classTree_nodes_subset (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList) :
    (classTree T L i hi).nodes ⊆ T.nodes := fun _ hx => hx.1

def nodeMap (T : RootedPrefixTree Index) (L : Colour → Set T.Node) (i : Colour)
    (hi : ReachesClass T L i T.rootList) (x : (classTree T L i hi).Node) : T.Node :=
  ⟨x.val, x.property.1⟩

theorem nodeMap_val (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList)
    (x : (classTree T L i hi).Node) : (nodeMap T L i hi x).val = x.val := rfl

theorem nodeMap_injective (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList) :
    Function.Injective (nodeMap T L i hi) := by
  intro x y h
  exact Subtype.ext (congrArg (fun z : T.Node => z.val) h)

theorem nodeMap_root (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList) :
    nodeMap T L i hi (classTree T L i hi).root = T.root := rfl

theorem nodeMap_depth (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList)
    (x : (classTree T L i hi).Node) :
    T.depth (nodeMap T L i hi x) = (classTree T L i hi).depth x := rfl

theorem nodeMap_isChild_iff (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList)
    (x y : (classTree T L i hi).Node) :
    T.IsChild (nodeMap T L i hi x) (nodeMap T L i hi y) ↔
      (classTree T L i hi).IsChild x y := Iff.rfl

def embedNode (T : RootedPrefixTree Index) (L : Colour → Set T.Node) (i : Colour)
    (hi : ReachesClass T L i T.rootList) (x : T.Node)
    (hx : ReachesClass T L i x.val) : (classTree T L i hi).Node :=
  ⟨x.val, x.property, hx⟩

theorem nodeMap_embedNode (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList) (x : T.Node)
    (hx : ReachesClass T L i x.val) :
    nodeMap T L i hi (embedNode T L i hi x hx) = x := rfl

theorem classTree_isWellFounded (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList) (hT : T.IsWellFounded) :
    (classTree T L i hi).IsWellFounded := by
  rintro ⟨b⟩
  apply hT
  refine ⟨{ node := fun n => nodeMap T L i hi (b.node n), root_eq := ?_, child := ?_ }⟩
  · rw [b.root_eq]
    exact nodeMap_root T L i hi
  · intro n
    exact (nodeMap_isChild_iff T L i hi _ _).mpr (b.child n)

theorem original_leaf_isLeaf (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList)
    (x : (classTree T L i hi).Node) (hx : T.IsLeaf (nodeMap T L i hi x)) :
    (classTree T L i hi).IsLeaf x := by
  intro y hxy
  apply nodeMap_injective T L i hi
  exact hx _ hxy

/-- An ancestor-closed class subtree has NO newly created leaf. -/
theorem leaf_nodeMap (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList)
    (x : (classTree T L i hi).Node) (hx : (classTree T L i hi).IsLeaf x) :
    T.IsLeaf (nodeMap T L i hi x) ∧ nodeMap T L i hi x ∈ L i := by
  obtain ⟨leaf, hleaf, hclass, hxleaf⟩ := x.property.2
  have hleafClass : ReachesClass T L i leaf.val :=
    ⟨leaf, hleaf, hclass, List.prefix_refl _⟩
  have heq := hx (embedNode T L i hi leaf hleafClass) hxleaf
  have heqT : leaf = nodeMap T L i hi x :=
    Subtype.ext (congrArg (fun z : (classTree T L i hi).Node => z.val) heq)
  exact ⟨heqT ▸ hleaf, heqT ▸ hclass⟩

theorem nodeRank_add_one_le_of_child (T : RootedPrefixTree Index)
    (hT : T.IsWellFounded) {x y : T.Node} (hxy : T.IsChild x y) :
    T.nodeRank hT y + 1 ≤ T.nodeRank hT x := by
  rw [T.nodeRank_eq hT x]
  exact Ordinal.le_iSup (fun z : {z : T.Node // T.IsChild x z} =>
    T.nodeRank hT z.val + 1) ⟨y, hxy⟩

theorem nodeRank_le_of_childMap (S T : RootedPrefixTree Index)
    (hS : S.IsWellFounded) (hT : T.IsWellFounded) (f : S.Node → T.Node)
    (hf : ∀ {x y : S.Node}, S.IsChild x y → T.IsChild (f x) (f y))
    (x : S.Node) : S.nodeRank hS x ≤ T.nodeRank hT (f x) := by
  refine (S.isWellFounded_iff_wellFounded_reverseChildRelation.mp hS).induction
    (C := fun x : S.Node => S.nodeRank hS x ≤ T.nodeRank hT (f x)) x ?_
  intro x ih
  rw [S.nodeRank_eq hS x]
  apply Ordinal.iSup_le
  intro y
  exact (add_le_add (ih y.val y.property) (le_rfl : (1 : Ordinal.{u}) ≤ 1)).trans
    (nodeRank_add_one_le_of_child T hT (hf y.property))

theorem classTree_nodeRank_le (T : RootedPrefixTree Index) (L : Colour → Set T.Node)
    (i : Colour) (hi : ReachesClass T L i T.rootList) (hT : T.IsWellFounded)
    (x : (classTree T L i hi).Node) :
    (classTree T L i hi).nodeRank (classTree_isWellFounded T L i hi hT) x ≤
      T.nodeRank hT (nodeMap T L i hi x) :=
  nodeRank_le_of_childMap (classTree T L i hi) T
    (classTree_isWellFounded T L i hi hT) hT (nodeMap T L i hi)
    (fun hxy => (nodeMap_isChild_iff T L i hi _ _).mpr hxy) x

end DIDomainClassification.FiniteLeafColourPruning
