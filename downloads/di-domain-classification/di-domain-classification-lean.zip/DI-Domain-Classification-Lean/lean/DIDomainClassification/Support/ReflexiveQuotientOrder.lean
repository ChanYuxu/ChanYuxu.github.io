import DIDomainClassification.Section05.ReflexiveClassification
import DIDomainClassification.Section05.SuccessorUniversal
import DIDomainClassification.Support.CandidateCutClosure

/-! The actual mutual-stable-retraction quotient of nontrivial reflexive
objects. Realization uses the literal successor universal domain. The degree
map descends to this quotient, and its inverse is obtained from proved
surjectivity. The quotient and ordinal interval have different universe
levels; no Small hypothesis or universe identification is assumed. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ReflexiveQuotientOrder
open Subcategories Section03.StableFunctionModels Section05 Section05.ReflexiveModels
open Section04.AdditionalSourceModels

theorem realize (β : Ordinal.{u+1}) (hβ : 2 ≤ β)
    (hBound : β ≤ firstUncountableBound.{u}) :
    ∃ D : ReflexiveObject.{u}, objectDegree D.val = β := by
  obtain ⟨E, hE⟩ := Section02.degreeRealizability.1 β (Or.inr ⟨hβ, hBound⟩)
  obtain ⟨hU, hDegree, _hRetracts, hUniversal⟩ := successorUniversal β hβ hBound E hE
  let U : CountablyBasedDIDomain.{u} := successorUniversalObject hU E
  have hDegree' : objectDegree U = β := hDegree
  have hNon : Nontrivial (Core U) :=
    FinitePowerMembership.nontrivial_of_two_le_degree U (by simpa only [hDegree'] using hβ)
  have hThree : 3 ≤ β + 1 := by
    simpa only [Order.succ_eq_add_one, OfNat.ofNat] using Order.succ_le_succ hβ
  have hExp : DomainCut (β + 1) (exponential U U) :=
    CandidateCutClosure.domain_exponential hThree U U hUniversal.1 hUniversal.1
  have hRef : IsStableReflexive U := hUniversal.2 (exponential U U) hExp
  exact ⟨⟨U, hNon, hRef⟩, hDegree'⟩

def representativeDegree (D : ReflexiveObject.{u}) : DegreeInterval.{u} :=
  ⟨objectDegree D.val,
    ReflexiveRetractionClass.two_le_degree D.val D.property.1 D.property.2,
    objectDegree_le_firstUncountableBound D.val⟩

theorem representativeDegree_eq_of_mutual (D E : ReflexiveObject.{u})
    (h : AntisymmRel (fun D E : ReflexiveObject.{u} => D ≤ E) D E) :
    representativeDegree D = representativeDegree E := by
  apply Subtype.ext
  exact le_antisymm (ReflexiveDegreeCut.retract_degree_le D.val E.val h.1)
    (ReflexiveDegreeCut.retract_degree_le E.val D.val h.2)

def degreeMap : ReflexiveClass.{u} → DegreeInterval.{u} :=
  Quotient.lift representativeDegree representativeDegree_eq_of_mutual

theorem degreeMap_classOf (D : ReflexiveObject.{u}) :
    degreeMap (classOf D) = representativeDegree D := rfl

theorem degreeMap_le_iff (x y : ReflexiveClass.{u}) :
    degreeMap x ≤ degreeMap y ↔ x ≤ y := by
  refine Quotient.inductionOn₂' x y fun D E => ?_
  change objectDegree D.val ≤ objectDegree E.val ↔
    HasStableRetraction (Core D.val) (Core E.val)
  exact (reflexiveRetractIff E.val E.property.1 E.property.2 D.val).symm

theorem degreeMap_injective : Function.Injective degreeMap.{u} := by
  intro x y h
  exact le_antisymm ((degreeMap_le_iff x y).mp (le_of_eq h))
    ((degreeMap_le_iff y x).mp (le_of_eq h.symm))

theorem degreeMap_surjective : Function.Surjective degreeMap.{u} := by
  intro β
  obtain ⟨D, hD⟩ := realize β.val β.property.1 β.property.2
  refine ⟨classOf D, ?_⟩
  apply Subtype.ext
  exact hD

def degreeOrderIso : ReflexiveClass.{u} ≃o DegreeInterval.{u} where
  toEquiv := Equiv.ofBijective degreeMap ⟨degreeMap_injective, degreeMap_surjective⟩
  map_rel_iff' := by
    intro x y
    exact degreeMap_le_iff x y

theorem degreeOrderIso_classOf (D : ReflexiveObject.{u}) :
    (degreeOrderIso (classOf D)).val = objectDegree D.val := rfl

end DIDomainClassification.ReflexiveQuotientOrder
