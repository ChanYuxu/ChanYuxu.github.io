import DIDomainClassification.Support.CliqueStableMaps
import DIDomainClassification.Support.TwoExponentialOrderIso
import DIDomainClassification.Support.PredicateCliqueIso
import DIDomainClassification.Section02.CountableProducts

/-!
Finite-coordinate Zhao-Kou marker codes in the actual U=T₂^ℕ.
At its own index a code is marker1. At an earlier index of an adjacent
vertex it is marker0. Elsewhere it is bottom. Thus adjacency, not nonadjacency,
becomes incompatibility of compact codes. This is the original thesis polarity.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ZhaoKouCodes

open OrderCore Preliminaries CoherenceDegree FiniteOrderDomains TwoExponentialOrderIso
open Section02 Section02.BinaryCliqueModels Section04.AdditionalSourceModels
open Section04.PredicateModels Section03.StableFunctionModels

def baseCertificate : IsCountablyBasedDIDomain UniversalBaseCarrier.{u} :=
  (countableProducts ℕ (fun _ => Cube.{u}) (fun _ => cubeCountablyBased.{u})).1

abbrev baseObject : CountablyBasedDIDomain.{u} := universalBaseObject baseCertificate.{u}

theorem empty_le (x : Cube.{u}) : emptyCube ≤ x := Set.empty_subset _

local instance cubeOrderBot : OrderBot Cube.{u} where
  bot := emptyCube
  bot_le := empty_le

theorem atoms_incompatible : ¬ Compatible atomOneCube.{u} atomZeroCube := by
  rintro ⟨z, h1, h0⟩
  have h1z : atomOneCube.{u} = z :=
    ((cube_order_iff _ _).mp h1).resolve_left empty_ne_atomOne.symm
  have h0z : atomZeroCube.{u} = z :=
    ((cube_order_iff _ _).mp h0).resolve_left empty_ne_atomZero.symm
  exact atomZero_ne_atomOne (h0z.trans h1z.symm)

variable {A : Type u} (G : SimpleGraph A) (index : A → ℕ)

def code (a : A) (n : ℕ) : Cube.{u} := by
  classical
  exact if n = index a then atomOneCube
    else if ∃ b : A, index b = n ∧ n < index a ∧ G.Adj b a
      then atomZeroCube else emptyCube

theorem code_self (a : A) : code G index a (index a) = atomOneCube := by
  classical
  simp [code]

theorem code_above (a : A) (n : ℕ) (hn : index a < n) :
    code G index a n = emptyCube := by
  classical
  have hne : n ≠ index a := ne_of_gt hn
  have hNo : ¬ ∃ b : A, index b = n ∧ n < index a ∧ G.Adj b a := by
    rintro ⟨b, _hb, hlt, _hAdj⟩
    exact (not_lt_of_ge hn.le) hlt
  simp [code, hne, hNo]

theorem one_mem_code_iff (a : A) (n : ℕ) :
    (1 : Fin 2) ∈ (code G index a n).down.val ↔ n = index a := by
  classical
  by_cases hn : n = index a
  · simp [code, hn, atomOneCube]
  · by_cases h : ∃ b : A, index b = n ∧ n < index a ∧ G.Adj b a
    · simp [code, hn, h, atomZeroCube, (by decide : (1 : Fin 2) ≠ 0)]
    · simp [code, hn, h, emptyCube]

theorem code_support_finite (a : A) : (PiTheory.support (code G index a)).Finite := by
  apply (Set.finite_range (fun n : Fin (index a + 1) => n.val)).subset
  intro n hn
  have hle : n ≤ index a := by
    by_contra hnot
    exact hn (code_above G index a n (Nat.lt_of_not_ge hnot))
  exact ⟨⟨n, Nat.lt_succ_of_le hle⟩, rfl⟩

theorem code_compact (a : A) : IsCompactElement (code G index a) :=
  PiTheory.compact_of_finite_support (code_support_finite G index a)
    (fun n => finite_isCompact (code G index a n))

theorem code_injective (hi : Function.Injective index) :
    Function.Injective (code G index) := by
  intro a b hab
  have h1 : (1 : Fin 2) ∈ (code G index a (index a)).down.val :=
    (one_mem_code_iff G index a (index a)).mpr rfl
  rw [hab] at h1
  exact hi ((one_mem_code_iff G index b (index a)).mp h1)

theorem code_at_nonedge (hi : Function.Injective index) (a b : A)
    (hab : a ≠ b) (hnadj : ¬ G.Adj a b) : code G index b (index a) = emptyCube := by
  classical
  have hne : index a ≠ index b := fun h => hab (hi h)
  have hNo : ¬ ∃ c : A, index c = index a ∧ index a < index b ∧ G.Adj c b := by
    rintro ⟨c, hca, _hlt, hcb⟩
    exact hnadj ((hi hca) ▸ hcb)
  simp [code, hne, hNo]

theorem code_nonmarker (a : A) (n : ℕ) (hn : n ≠ index a) :
    code G index a n = emptyCube ∨ code G index a n = atomZeroCube := by
  classical
  by_cases h : ∃ b : A, index b = n ∧ n < index a ∧ G.Adj b a
  · exact Or.inr (by simp [code, hn, h])
  · exact Or.inl (by simp [code, hn, h])

theorem codes_compatible_of_not_adj (hi : Function.Injective index) (a b : A)
    (hnadj : ¬ G.Adj a b) : Compatible (code G index a) (code G index b) := by
  classical
  have hcoord : ∀ n : ℕ, Compatible (code G index a n) (code G index b n) := by
    intro n
    by_cases hab : a = b
    · subst b
      exact ⟨code G index a n, le_rfl, le_rfl⟩
    by_cases hna : n = index a
    · subst n
      refine ⟨code G index a (index a), le_rfl, ?_⟩
      rw [code_at_nonedge G index hi a b hab hnadj]
      exact empty_le _
    by_cases hnb : n = index b
    · subst n
      refine ⟨code G index b (index b), ?_, le_rfl⟩
      rw [code_at_nonedge G index hi b a (Ne.symm hab) (fun h => hnadj (G.symm h))]
      exact empty_le _
    rcases code_nonmarker G index a n hna with ha | ha
    · refine ⟨code G index b n, ?_, le_rfl⟩
      rw [ha]
      exact empty_le _
    · rcases code_nonmarker G index b n hnb with hb | hb
      · refine ⟨code G index a n, le_rfl, ?_⟩
        rw [hb]
        exact empty_le _
      · exact ⟨atomZeroCube, ha.le, hb.le⟩
  choose upper hA hB using hcoord
  exact ⟨upper, hA, hB⟩

theorem codes_incompatible_of_lt_adj (a b : A) (hlt : index a < index b)
    (hAdj : G.Adj a b) : ¬ Compatible (code G index a) (code G index b) := by
  classical
  have hb : code G index b (index a) = atomZeroCube := by
    have hne : index a ≠ index b := ne_of_lt hlt
    have hWitness : ∃ c : A, index c = index a ∧ index a < index b ∧ G.Adj c b :=
      ⟨a, rfl, hlt, hAdj⟩
    simp [code, hne, hWitness]
  rintro ⟨upper, hA, hB⟩
  apply atoms_incompatible
  refine ⟨upper (index a), ?_, ?_⟩
  · simpa only [code_self] using hA (index a)
  · simpa only [hb] using hB (index a)

theorem codes_incompatible_of_adj (hi : Function.Injective index) (a b : A)
    (hAdj : G.Adj a b) : ¬ Compatible (code G index a) (code G index b) := by
  have hne : index a ≠ index b := fun h => hAdj.ne (hi h)
  rcases lt_or_gt_of_ne hne with hlt | hlt
  · exact codes_incompatible_of_lt_adj G index a b hlt hAdj
  · rintro ⟨upper, hA, hB⟩
    exact codes_incompatible_of_lt_adj G index b a hlt (G.symm hAdj) ⟨upper, hB, hA⟩

def compactCode (a : A) : ↥(CompactElements (Core baseObject.{u})) :=
  ⟨code G index a, code_compact G index a⟩

theorem compactCode_injective (hi : Function.Injective index) :
    Function.Injective (compactCode G index) := by
  intro a b hab
  exact code_injective G index hi (congrArg Subtype.val hab)

theorem induced_graph (hi : Function.Injective index) (a b : A) :
    G.Adj a b ↔ (graph baseObject.{u}).Adj (compactCode G index a) (compactCode G index b) := by
  constructor
  · intro hAdj
    exact ⟨(fun h => hAdj.ne (compactCode_injective G index hi h)),
      codes_incompatible_of_adj G index hi a b hAdj⟩
  · intro hAdj
    by_contra hnadj
    exact hAdj.2 (codes_compatible_of_not_adj G index hi a b hnadj)

end DIDomainClassification.ZhaoKouCodes
