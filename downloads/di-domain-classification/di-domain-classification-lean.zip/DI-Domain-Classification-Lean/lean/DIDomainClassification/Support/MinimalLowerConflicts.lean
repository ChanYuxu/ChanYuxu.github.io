import DIDomainClassification.Support.FiniteLowerMaxima
import DIDomainClassification.Support.ConfigurationDomain

/-!
Generic finite inconsistency extraction and conflict-family properties for the
actual accepted event structure and actual accepted causal-conflict definitions.
These are separately reusable lemmas, not a source-facing antichains/retraction
wrapper. The family may be EMPTY; only each of its members must be nonempty.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.FiniteCausalConflicts

open EventStructures

variable {A : Type u} [PartialOrder A]

theorem minimalLower_nonempty (E : FinitaryPrimeEventStructure A) {U : Set A}
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) : U.Nonempty := by
  apply Set.nonempty_iff_ne_empty.mpr
  intro h
  apply hU.2.2.1
  simpa only [h] using E.empty_mem_Con

theorem minimalLower_maximalEvents_nonempty (E : FinitaryPrimeEventStructure A) {U : Set A}
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) : (maximalEvents U).Nonempty := by
  obtain ⟨a, ha⟩ := minimalLower_nonempty E hU
  obtain ⟨b, _hab, hb⟩ := hU.1.exists_le_maximal ha
  exact ⟨b, maximalEvents_iff_maximal.mpr hb⟩

theorem minimalLower_maximalEvents_nontrivial (E : FinitaryPrimeEventStructure A) {U : Set A}
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) : (maximalEvents U).Nontrivial := by
  obtain ⟨a, ha⟩ := minimalLower_maximalEvents_nonempty E hU
  have hnot : ¬ maximalEvents U ⊆ {a} := by
    intro hsingle
    apply hU.2.2.1
    apply E.hereditary (G := Set.Iic a) ?_ (ConfigurationDomain.principal_mem_Con E a)
    intro x hx
    have hxDown : x ∈ downClosure (maximalEvents U) :=
      (finite_lower_eq_down_maximalEvents hU.1 hU.2.1) ▸ hx
    obtain ⟨b, hb, hxb⟩ := hxDown
    have hba : b = a := Set.mem_singleton_iff.mp (hsingle hb)
    simpa only [hba] using hxb
  obtain ⟨b, hb, hba⟩ := Set.not_subset.mp hnot
  exact ⟨a, ha, b, hb, fun hab => hba (Set.mem_singleton_iff.mpr hab.symm)⟩

theorem minimalLower_maximalEvents_card_ge_two (E : FinitaryPrimeEventStructure A)
    {U : Set A} (hU : IsMinimallyInconsistentFiniteLowerSet E U) :
    2 ≤ (maximalEvents U).ncard := by
  have h := (Set.one_lt_ncard (maximalEvents_finite hU.1)).mpr
    (minimalLower_maximalEvents_nontrivial E hU)
  omega

/-- Minimality is among proper LOWER subsets, not arbitrary subsets. -/
theorem exists_minimalLower_subset (E : FinitaryPrimeEventStructure A) {V : Set A}
    (hV : V.Finite) (hLower : IsLowerSet V) (hBad : V ∉ E.Con) :
    ∃ U : Set A, U ⊆ V ∧ IsMinimallyInconsistentFiniteLowerSet E U := by
  let B : Set (Set A) := {W | W ⊆ V ∧ IsLowerSet W ∧ W ∉ E.Con}
  have hBfinite : B.Finite := hV.powerset.subset (fun _ hW => hW.1)
  have hBnonempty : B.Nonempty := ⟨V, Set.Subset.rfl, hLower, hBad⟩
  obtain ⟨U, hU, hmin⟩ := hBfinite.exists_minimal hBnonempty
  refine ⟨U, hU.1, hV.subset hU.1, hU.2.1, hU.2.2, ?_⟩
  intro W hWU hWlower
  by_contra hWbad
  have hWB : W ∈ B := ⟨hWU.1.trans hU.1, hWlower, hWbad⟩
  exact hWU.2 (hmin hWB hWU.1)

theorem exists_minimalLower_in_downClosure (E : FinitaryPrimeEventStructure A)
    {F : Set A} (hF : F.Finite) (hBad : F ∉ E.Con) :
    ∃ U : Set A, U ⊆ downClosure F ∧ IsMinimallyInconsistentFiniteLowerSet E U := by
  apply exists_minimalLower_subset E
    (downClosure_finite hF fun a _ha => E.finite_principalIdeal a)
    (downClosure_isLower F)
  intro hCon
  exact hBad (E.hereditary (subset_downClosure F) hCon)

theorem conflict_member_finite (E : FinitaryPrimeEventStructure A) {H : Set A}
    (hH : H ∈ causalConflictFamily E) : H.Finite := by
  obtain ⟨U, hU, rfl⟩ := hH
  exact maximalEvents_finite hU.1

theorem conflict_member_isAntichain (E : FinitaryPrimeEventStructure A) {H : Set A}
    (hH : H ∈ causalConflictFamily E) : IsAntichain (· ≤ ·) H := by
  obtain ⟨U, _hU, rfl⟩ := hH
  exact maximalEvents_isAntichain U

theorem conflict_member_nonempty (E : FinitaryPrimeEventStructure A) {H : Set A}
    (hH : H ∈ causalConflictFamily E) : H.Nonempty := by
  obtain ⟨U, hU, rfl⟩ := hH
  exact minimalLower_maximalEvents_nonempty E hU

theorem conflict_member_card_ge_two (E : FinitaryPrimeEventStructure A) {H : Set A}
    (hH : H ∈ causalConflictFamily E) : 2 ≤ H.ncard := by
  obtain ⟨U, hU, rfl⟩ := hH
  exact minimalLower_maximalEvents_card_ge_two E hU

theorem empty_not_conflictFamily (E : FinitaryPrimeEventStructure A) :
    (∅ : Set A) ∉ causalConflictFamily E := by
  intro h
  exact Set.not_nonempty_empty (conflict_member_nonempty E h)

theorem singleton_not_conflictFamily (E : FinitaryPrimeEventStructure A) (a : A) :
    ({a} : Set A) ∉ causalConflictFamily E := by
  intro h
  have hc := conflict_member_card_ge_two E h
  simp only [Set.ncard_singleton] at hc
  omega

theorem conflict_member_eq_of_subset (E : FinitaryPrimeEventStructure A)
    {H K : Set A} (hH : H ∈ causalConflictFamily E) (hK : K ∈ causalConflictFamily E)
    (hHK : H ⊆ K) : H = K := by
  obtain ⟨U, hU, rfl⟩ := hH
  obtain ⟨V, hV, rfl⟩ := hK
  have hUV : U ⊆ V := by
    calc
      U = downClosure (maximalEvents U) := finite_lower_eq_down_maximalEvents hU.1 hU.2.1
      _ ⊆ downClosure (maximalEvents V) := downClosure_mono hHK
      _ = V := (finite_lower_eq_down_maximalEvents hV.1 hV.2.1).symm
  have heq : U = V := by
    by_contra hne
    exact hU.2.2.1 (hV.2.2.2 U (Set.ssubset_iff_subset_ne.mpr ⟨hUV, hne⟩) hU.2.1)
  exact congrArg maximalEvents heq

theorem conflictFamily_isAntichain (E : FinitaryPrimeEventStructure A) :
    IsAntichain (fun H K : Set A => H ⊆ K) (causalConflictFamily E) := by
  intro H hH K hK hne hHK
  exact hne (conflict_member_eq_of_subset E hH hK hHK)

/-- Global nonemptiness is CONDITIONAL and characterized, never silently assumed. -/
theorem conflictFamily_nonempty_iff (E : FinitaryPrimeEventStructure A) :
    (causalConflictFamily E).Nonempty ↔
      ∃ V : Set A, V.Finite ∧ IsLowerSet V ∧ V ∉ E.Con := by
  constructor
  · rintro ⟨H, U, hU, _hH⟩
    exact ⟨U, hU.1, hU.2.1, hU.2.2.1⟩
  · rintro ⟨V, hV, hLower, hBad⟩
    obtain ⟨U, _hUV, hU⟩ := exists_minimalLower_subset E hV hLower hBad
    exact ⟨maximalEvents U, U, hU, rfl⟩

end DIDomainClassification.FiniteCausalConflicts







