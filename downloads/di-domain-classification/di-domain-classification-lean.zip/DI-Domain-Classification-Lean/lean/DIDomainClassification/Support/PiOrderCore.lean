import DIDomainClassification.Support.OrderCoreLemmas
import Mathlib.Order.Bounds.Image
import Mathlib.Data.Finset.Basic
import Mathlib.Logic.Function.Basic

/-!
# Pointwise product infrastructure

The dcpo proof adapts AmadioCurien.DomainTheory.pi_isDcpo from
DomainsLambdaCalculi/DomainTheory/Core.lean to the accepted narrow OrderCore
predicates. No book umbrella is imported and no dependency pins are changed.
All index types, including the empty type, are retained.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.PiTheory

open OrderCore

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]

theorem coordinate_isSup {A : Set (∀ i, D i)} {s : ∀ i, D i}
    (hs : IsSup A s) (i : I) : IsSup (Function.eval i '' A) (s i) :=
  isLUB_pi.mp hs i

/-- Adapted from the existing dependent Pi-dcpo proof at identical conventions. -/
theorem pi_isDcpo (hD : ∀ i, IsDcpo (D i)) : IsDcpo (∀ i, D i) := by
  intro A hA
  have hcoordinate (i : I) : DirectedSet (Function.eval i '' A) :=
    hA.image (fun _ _ h => h i)
  choose s hs using fun i => hD i (Function.eval i '' A) (hcoordinate i)
  exact ⟨s, isLUB_pi.mpr hs⟩

theorem update_monotone [DecidableEq I] (x : ∀ i, D i) (i : I) :
    Monotone (fun a : D i => Function.update x i a) := by
  classical
  intro a b hab j
  by_cases hji : j = i
  · subst j
    simpa using hab
  · simp [Function.update_of_ne hji]

theorem update_isSup [DecidableEq I] (x : ∀ i, D i) (i : I)
    {A : Set (D i)} {s : D i} (hA : A.Nonempty) (hs : IsSup A s) :
    IsSup ((fun a : D i => Function.update x i a) '' A) (Function.update x i s) := by
  classical
  constructor
  · rintro _ ⟨a, ha, rfl⟩ j
    by_cases hji : j = i
    · subst j
      simpa using hs.1 ha
    · simp [Function.update_of_ne hji]
  · intro y hy j
    by_cases hji : j = i
    · subst j
      have hsy : s ≤ y i := hs.2 (y i) (by
        intro a ha
        simpa using hy ⟨a, ha, rfl⟩ i)
      simpa using hsy
    · obtain ⟨a, ha⟩ := hA
      simpa [Function.update_of_ne hji] using hy ⟨a, ha, rfl⟩ j

theorem le_update_of_le [DecidableEq I] (x : ∀ i, D i) (i : I) {a : D i} (h : x i ≤ a) :
    x ≤ Function.update x i a := by
  classical
  intro j
  by_cases hji : j = i
  · subst j
    simpa using h
  · simp [Function.update_of_ne hji]

section Bottom

variable [∀ i, OrderBot (D i)]

theorem compact_bot {E : Type*} [Preorder E] [OrderBot E] : Compact (⊥ : E) := by
  intro A s hA _hs _hle
  obtain ⟨a, ha⟩ := hA.1
  exact ⟨a, ha, bot_le⟩

def support (x : ∀ i, D i) : Set I := {i | x i ≠ ⊥}

@[simp] theorem mem_support (x : ∀ i, D i) (i : I) : i ∈ support x ↔ x i ≠ ⊥ := Iff.rfl

@[simp] theorem not_mem_support (x : ∀ i, D i) (i : I) :
    i ∉ support x ↔ x i = ⊥ := not_not

noncomputable def truncate (F : Finset I) (x : ∀ i, D i) : ∀ i, D i := by
  classical
  exact fun i => if i ∈ F then x i else ⊥

@[simp] theorem truncate_apply_mem (F : Finset I) (x : ∀ i, D i) {i : I} (hi : i ∈ F) :
    truncate F x i = x i := by
  classical
  simp [truncate, hi]

@[simp] theorem truncate_apply_not_mem (F : Finset I) (x : ∀ i, D i) {i : I} (hi : i ∉ F) :
    truncate F x i = ⊥ := by
  classical
  simp [truncate, hi]

theorem truncate_le (F : Finset I) (x : ∀ i, D i) : truncate F x ≤ x := by
  classical
  intro i
  by_cases hi : i ∈ F <;> simp [truncate, hi]

theorem truncate_mono {F G : Finset I} (hFG : F ⊆ G) (x : ∀ i, D i) :
    truncate F x ≤ truncate G x := by
  classical
  intro i
  by_cases hi : i ∈ F
  · simp [truncate, hi, hFG hi]
  · simp [truncate, hi]

theorem support_truncate_finite (F : Finset I) (x : ∀ i, D i) :
    (support (truncate F x)).Finite := by
  classical
  apply F.finite_toSet.subset
  intro i hi
  by_contra hnot
  exact hi (truncate_apply_not_mem F x hnot)

theorem truncations_directed (x : ∀ i, D i) :
    DirectedSet (Set.range (fun F : Finset I => truncate F x)) := by
  classical
  refine ⟨⟨truncate ∅ x, ⟨∅, rfl⟩⟩, ?_⟩
  rintro _ ⟨F, rfl⟩ _ ⟨G, rfl⟩
  exact ⟨truncate (F ∪ G) x, ⟨F ∪ G, rfl⟩,
    truncate_mono Finset.subset_union_left x, truncate_mono Finset.subset_union_right x⟩

theorem truncations_isSup (x : ∀ i, D i) :
    IsSup (Set.range (fun F : Finset I => truncate F x)) x := by
  classical
  constructor
  · rintro _ ⟨F, rfl⟩
    exact truncate_le F x
  · intro y hy i
    simpa [truncate] using hy ⟨{i}, rfl⟩ i

noncomputable def single (i : I) (a : D i) : ∀ j, D j := by
  classical
  exact Function.update (fun j => (⊥ : D j)) i a

@[simp] theorem single_self (i : I) (a : D i) : single i a i = a := by
  classical
  simp [single]

@[simp] theorem single_other (i : I) (a : D i) {j : I} (hji : j ≠ i) :
    single i a j = ⊥ := by
  classical
  simp [single, Function.update_of_ne hji]

theorem single_le (i : I) {a : D i} {x : ∀ j, D j} (h : a ≤ x i) : single i a ≤ x := by
  classical
  intro j
  by_cases hji : j = i
  · subst j
    simpa using h
  · simp [single_other i a hji]

theorem support_single_finite (i : I) (a : D i) : (support (single i a)).Finite := by
  classical
  apply (Set.finite_singleton i).subset
  intro j hj
  by_contra hne
  exact hj (single_other i a (by simpa using hne))

end Bottom

end DIDomainClassification.PiTheory
