import DIDomainClassification.Support.SeparatedSumDomain
import DIDomainClassification.Section02.StableCategory

/-! The literal inclusion, section and restriction functions of the sum. -/
set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.SeparatedSumFunctions
open OrderCore Preliminaries
open Section03.StableFunctionModels
open Section04.AdditionalSourceModels Section04.SeparatedSumModels
open SeparatedSumOrder SeparatedSumDomain

variable {I : Type v} (H : I → CountablyBasedDIDomain.{u})
  (E : CountablyBasedDIDomain.{w})

def sumCore : DIDomainObject.{max u v} :=
  DIDomainObject.ofType (Carrier H) (sum_isDIDomain H)

def inclusion (i : I) : StableHom (Core (H i)) (sumCore H) := by
  refine StableHom.ofFunction (component H i) ⟨component_continuous H i, ?_⟩
  intro x y _hxy
  exact (inf_component H i x y).symm

theorem inclusion_apply (i : I) (x : Core (H i)) :
    inclusion H i x = component H i x := rfl

theorem section_bottom (f : ∀ i, StableHom (Core (H i)) (Core E)) :
    sectionValues H E f (bottom H) = (Core E).isDIDomain.toIsScottDomain.bottom := rfl

theorem section_component (f : ∀ i, StableHom (Core (H i)) (Core E))
    (i : I) (x : Core (H i)) :
    sectionValues H E f (component H i x) = f i x := rfl

theorem section_values_monotone (f : ∀ i, StableHom (Core (H i)) (Core E)) :
    Monotone (sectionValues H E f) := by
  intro x y hxy
  rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
  · exact (Core E).isDIDomain.toIsScottDomain.bottom_le _
  · obtain ⟨b, rfl, hab⟩ := component_le_elim H hxy
    exact (StableHom.isStable (f i)).1.monotone hab

theorem section_values_continuous (f : ∀ i, StableHom (Core (H i)) (Core E)) :
    ScottContinuous (sectionValues H E f) := by
  intro X hne hdir s hs
  rcases cases_sum H s with rfl | ⟨i, a, rfl⟩
  · constructor
    · rintro _ ⟨x, hx, rfl⟩
      have hxb : x = bottom H := le_antisymm (hs.1 hx) bot_le
      subst x
      exact le_rfl
    · intro z _hz
      exact (Core E).isDIDomain.toIsScottDomain.bottom_le _
  · have hFn := fiber_nonempty_of_lub H hs
    have hFd := fiber_directed H ⟨hne, hdir⟩ hFn
    have hFs := project_fiber_lub H hs
    have hf := OrderCore.scottContinuous_isSup (StableHom.isStable (f i)).1 hFd hFs
    constructor
    · rintro _ ⟨x, hx, rfl⟩
      rcases below_component H (hs.1 hx) with rfl | ⟨b, rfl, _⟩
      · exact (Core E).isDIDomain.toIsScottDomain.bottom_le _
      · exact hf.1 ⟨b, hx, rfl⟩
    · intro z hz
      apply hf.2 z
      rintro _ ⟨b, hb, rfl⟩
      exact hz ⟨component H i b, hb, rfl⟩

theorem section_values_stable (f : ∀ i, StableHom (Core (H i)) (Core E)) :
    IsStable (sumCore H) (Core E) (sectionValues H E f) := by
  refine ⟨section_values_continuous H E f, ?_⟩
  intro x y hxy
  change sectionValues H E f ((scott H).inf x y) =
    sectionValues H E f x ⊓ sectionValues H E f y
  rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
  · rw [bottom_inf, section_bottom]
    exact (inf_eq_left.mpr ((Core E).isDIDomain.toIsScottDomain.bottom_le _)).symm
  · rcases cases_sum H y with rfl | ⟨j, b, rfl⟩
    · rw [inf_bottom, section_bottom]
      exact (inf_eq_right.mpr ((Core E).isDIDomain.toIsScottDomain.bottom_le _)).symm
    · have hij : i = j := compatible_indices H hxy
      subst j
      rw [inf_component, section_component, section_component, section_component]
      exact (StableHom.isStable (f i)).2 a b ((component_compatible_iff H i a b).mp hxy)

def sectionHom (f : ∀ i, StableHom (Core (H i)) (Core E)) :
    StableHom (sumCore H) (Core E) :=
  StableHom.ofFunction (sectionValues H E f) (section_values_stable H E f)

theorem sectionHom_apply (f : ∀ i, StableHom (Core (H i)) (Core E)) (x : Carrier H) :
    sectionHom H E f x = sectionValues H E f x := rfl

theorem sectionHom_monotone : Monotone (sectionHom H E) := by
  intro f g hfg x y hxy
  rcases cases_sum H x with rfl | ⟨i, a, rfl⟩
  · change (Core E).isDIDomain.toIsScottDomain.bottom =
      sectionHom H E f y ⊓ (Core E).isDIDomain.toIsScottDomain.bottom
    exact (inf_eq_right.mpr ((Core E).isDIDomain.toIsScottDomain.bottom_le _)).symm
  · obtain ⟨b, rfl, hab⟩ := component_le_elim H hxy
    exact hfg i a b hab

def restriction (g : StableHom (sumCore H) (Core E)) :
    ∀ i, StableHom (Core (H i)) (Core E) :=
  fun i => StableHom.comp g (inclusion H i)

theorem restriction_apply (g : StableHom (sumCore H) (Core E)) (i : I) (x : Core (H i)) :
    restriction H E g i x = g (component H i x) := rfl

theorem restriction_monotone : Monotone (restriction H E) := by
  intro f g hfg i x y hxy
  exact hfg (component H i x) (component H i y) (component_mono H i hxy)

theorem restriction_section (f : ∀ i, StableHom (Core (H i)) (Core E)) :
    restriction H E (sectionHom H E f) = f := by
  funext i
  apply StableHom.ext
  intro x
  rfl

end DIDomainClassification.SeparatedSumFunctions
