import DIDomainClassification.Section02.ConfigurationOrderLaws
import DIDomainClassification.Section02.ScottDomains
import DIDomainClassification.Support.OrderCoreLemmas
import Mathlib.Data.Set.Countable
import Mathlib.Data.Set.Finite.Powerset

/-!
# Generic configuration-domain support

Source support for Theorem 2.5 (manuscript.tex:389--395). The finite-state
argument is adapted from the inspected book event-state proofs, but all
carriers and orders below are the accepted paper configurations. The paper
cites the representation theorem without a written proof; these are local
Lean arguments, not a claim to reproduce the cited proof. No book module,
enabling model, countable whole-domain premise or target field is assumed.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures.ConfigurationDomain

open DIDomainClassification.Preliminaries

variable {A : Type u} [PartialOrder A]

theorem finite_causal_extension (E : FinitaryPrimeEventStructure A)
    {F G : Set A} (hF : F ∈ E.Con) (hG : G.Finite)
    (hcauses : ∀ a ∈ G, ∃ b ∈ F, a ≤ b) : F ∪ G ∈ E.Con := by
  classical
  induction G, hG using Set.Finite.induction_on with
  | empty => simpa only [Set.union_empty] using hF
  | @insert a G ha hG ih =>
      have htail : ∀ x ∈ G, ∃ b ∈ F, x ≤ b := by
        intro x hx
        exact hcauses x (Set.mem_insert_of_mem a hx)
      obtain ⟨b, hb, hab⟩ := hcauses a (by simp)
      have hstep := E.causal_closure (ih htail) hab (Set.mem_union_left G hb)
      simpa only [Set.union_singleton, Set.union_insert] using hstep

theorem principal_mem_Con (E : FinitaryPrimeEventStructure A) (a : A) :
    Set.Iic a ∈ E.Con := by
  have h := finite_causal_extension E (E.singleton_mem_Con a)
    (E.finite_principalIdeal a) (by
      intro b hb
      exact ⟨a, by simp, hb⟩)
  exact E.hereditary Set.subset_union_right h

def principal (E : FinitaryPrimeEventStructure A) (a : A) : Configuration E :=
  ⟨Set.Iic a, by
    constructor
    · intro x y hxy hy
      exact hxy.trans hy
    · intro F _hF hsub
      exact E.hereditary hsub (principal_mem_Con E a)⟩

def empty (E : FinitaryPrimeEventStructure A) : Configuration E :=
  ⟨∅, by
    constructor
    · intro _ _ _ hb
      exact False.elim hb
    · intro F _hF hsub
      exact E.hereditary hsub E.empty_mem_Con⟩

theorem empty_le (E : FinitaryPrimeEventStructure A) (X : Configuration E) :
    empty E ≤ X := by
  exact (Configuration.le_iff_subset _ _).mpr (Set.empty_subset _)

def unionBelow (E : FinitaryPrimeEventStructure A)
    (X Y Z : Configuration E) (hY : Y ≤ X) (hZ : Z ≤ X) : Configuration E :=
  ⟨Y.val ∪ Z.val, by
    constructor
    · intro a b hab hb
      rcases hb with hb | hb
      · exact Or.inl (Y.property.1 hab hb)
      · exact Or.inr (Z.property.1 hab hb)
    · intro F hF hsub
      apply X.property.2 F hF
      intro a ha
      rcases hsub ha with haY | haZ
      · exact (Configuration.le_iff_subset Y X).mp hY haY
      · exact (Configuration.le_iff_subset Z X).mp hZ haZ⟩

theorem unionBelow_isLUB (E : FinitaryPrimeEventStructure A)
    (X Y Z : Configuration E) (hY : Y ≤ X) (hZ : Z ≤ X) :
    IsLUB ({Y, Z} : Set (Configuration E)) (unionBelow E X Y Z hY hZ) := by
  constructor
  · intro W hW
    rcases Set.mem_insert_iff.mp hW with rfl | hW
    · exact (Configuration.le_iff_subset _ _).mpr Set.subset_union_left
    · have heq : W = Z := Set.mem_singleton_iff.mp hW
      subst W
      exact (Configuration.le_iff_subset _ _).mpr Set.subset_union_right
  · intro W hW
    apply (Configuration.le_iff_subset _ _).mpr
    exact Set.union_subset
      ((Configuration.le_iff_subset Y W).mp (hW (by simp)))
      ((Configuration.le_iff_subset Z W).mp (hW (by simp)))

def intersection (E : FinitaryPrimeEventStructure A)
    (X Y : Configuration E) : Configuration E :=
  ⟨X.val ∩ Y.val, by
    constructor
    · intro a b hab hb
      exact ⟨X.property.1 hab hb.1, Y.property.1 hab hb.2⟩
    · intro F hF hsub
      exact X.property.2 F hF (fun _ ha => (hsub ha).1)⟩

theorem intersection_isGLB (E : FinitaryPrimeEventStructure A)
    (X Y : Configuration E) :
    IsGLB ({X, Y} : Set (Configuration E)) (intersection E X Y) := by
  constructor
  · intro W hW
    rcases Set.mem_insert_iff.mp hW with rfl | hW
    · exact (Configuration.le_iff_subset _ _).mpr Set.inter_subset_left
    · have heq : W = Y := Set.mem_singleton_iff.mp hW
      subst W
      exact (Configuration.le_iff_subset _ _).mpr Set.inter_subset_right
  · intro W hW
    apply (Configuration.le_iff_subset _ _).mpr
    exact Set.subset_inter
      ((Configuration.le_iff_subset W X).mp (hW (by simp)))
      ((Configuration.le_iff_subset W Y).mp (hW (by simp)))

def boundedUnion (E : FinitaryPrimeEventStructure A)
    (C : Set (Configuration E)) (X : Configuration E)
    (hCX : ∀ Y ∈ C, Y ≤ X) : Configuration E :=
  ⟨⋃ Y ∈ C, Y.val, by
    constructor
    · intro a b hab hb
      obtain ⟨Y, hb⟩ := Set.mem_iUnion.mp hb
      obtain ⟨hY, hb⟩ := Set.mem_iUnion.mp hb
      exact Set.mem_iUnion.mpr ⟨Y, Set.mem_iUnion.mpr ⟨hY, Y.property.1 hab hb⟩⟩
    · intro F hF hsub
      apply X.property.2 F hF
      intro a ha
      obtain ⟨Y, ha⟩ := Set.mem_iUnion.mp (hsub ha)
      obtain ⟨hY, ha⟩ := Set.mem_iUnion.mp ha
      exact (Configuration.le_iff_subset Y X).mp (hCX Y hY) ha⟩

theorem boundedUnion_isLUB (E : FinitaryPrimeEventStructure A)
    (C : Set (Configuration E)) (X : Configuration E)
    (hCX : ∀ Y ∈ C, Y ≤ X) : IsLUB C (boundedUnion E C X hCX) := by
  constructor
  · intro Y hY
    apply (Configuration.le_iff_subset _ _).mpr
    intro a ha
    exact Set.mem_iUnion.mpr ⟨Y, Set.mem_iUnion.mpr ⟨hY, ha⟩⟩
  · intro Z hZ
    apply (Configuration.le_iff_subset _ _).mpr
    intro a ha
    obtain ⟨Y, ha⟩ := Set.mem_iUnion.mp ha
    obtain ⟨hY, ha⟩ := Set.mem_iUnion.mp ha
    exact (Configuration.le_iff_subset Y Z).mp (hZ hY) ha

def finiteSubconfigurations (E : FinitaryPrimeEventStructure A)
    (X : Configuration E) : Set (Configuration E) :=
  {Y | Y.val.Finite ∧ Y ≤ X}

theorem finiteSubconfigurations_directed (E : FinitaryPrimeEventStructure A)
    (X : Configuration E) : OrderCore.DirectedSet (finiteSubconfigurations E X) := by
  constructor
  · exact ⟨empty E, Set.finite_empty, empty_le E X⟩
  · intro Y hY Z hZ
    let W := unionBelow E X Y Z hY.2 hZ.2
    have hW : W ≤ X := (unionBelow_isLUB E X Y Z hY.2 hZ.2).2 (by
      intro V hV
      rcases Set.mem_insert_iff.mp hV with rfl | hV
      · exact hY.2
      · simpa only [Set.mem_singleton_iff.mp hV] using hZ.2)
    exact ⟨W, ⟨hY.1.union hZ.1, hW⟩,
      (unionBelow_isLUB E X Y Z hY.2 hZ.2).1 (by simp),
      (unionBelow_isLUB E X Y Z hY.2 hZ.2).1 (by simp)⟩

theorem finiteSubconfigurations_isSup (E : FinitaryPrimeEventStructure A)
    (X : Configuration E) : OrderCore.IsSup (finiteSubconfigurations E X) X := by
  constructor
  · intro Y hY
    exact hY.2
  · intro Z hZ
    apply (Configuration.le_iff_subset _ _).mpr
    intro a ha
    have hbelow : principal E a ≤ X := by
      apply (Configuration.le_iff_subset _ _).mpr
      intro b hb
      exact X.property.1 hb ha
    have hmem : principal E a ∈ finiteSubconfigurations E X :=
      ⟨E.finite_principalIdeal a, hbelow⟩
    exact (Configuration.le_iff_subset _ _).mp (hZ hmem) le_rfl

theorem compact_of_finite (E : FinitaryPrimeEventStructure A)
    (X : Configuration E) (hX : X.val.Finite) : Preliminaries.IsCompactElement X := by
  intro C s hC hs hXs
  obtain ⟨U, hUval, hU⟩ := configurationDirectedUnions A E C hC
  have hsU : s = U := (OrderCore.isSup_iff_isLUB.mp hs).unique hU
  have hsub : X.val ⊆ ⋃ Y ∈ C, Y.val := by
    rw [← hUval]
    exact (Configuration.le_iff_subset X U).mp (hsU ▸ hXs)
  obtain ⟨Y, hY, hXY⟩ := Configuration.finite_subset_directed_union hC hX hsub
  exact ⟨Y, hY, (Configuration.le_iff_subset X Y).mpr hXY⟩

theorem compact_iff_finite (E : FinitaryPrimeEventStructure A)
    (X : Configuration E) : Preliminaries.IsCompactElement X ↔ X.val.Finite := by
  constructor
  · intro hX
    obtain ⟨Y, hY, hXY⟩ := hX (finiteSubconfigurations_directed E X)
      (finiteSubconfigurations_isSup E X) le_rfl
    exact hY.1.subset ((Configuration.le_iff_subset X Y).mp hXY)
  · exact compact_of_finite E X

theorem algebraic (E : FinitaryPrimeEventStructure A) :
    Preliminaries.IsAlgebraicDcpo (Configuration E) := by
  constructor
  · intro C hC
    obtain ⟨X, _hXval, hX⟩ := configurationDirectedUnions A E C hC
    exact ⟨X, OrderCore.isSup_iff_isLUB.mpr hX⟩
  · intro X
    have heq : OrderCore.CompactBelow X = finiteSubconfigurations E X := by
      ext Y
      exact and_congr (compact_iff_finite E Y) Iff.rfl
    rw [heq]
    exact ⟨finiteSubconfigurations_directed E X, finiteSubconfigurations_isSup E X⟩

theorem scottDomain (E : FinitaryPrimeEventStructure A) :
    Preliminaries.IsScottDomain (Configuration E) where
  algebraic := algebraic E
  hasLeast := ⟨empty E, empty_le E⟩
  boundedSuprema := by
    intro C hC
    obtain ⟨X, hX⟩ := hC
    exact ⟨boundedUnion E C X (fun Y hY => hX hY),
      boundedUnion_isLUB E C X (fun Y hY => hX hY)⟩

theorem distributive (E : FinitaryPrimeEventStructure A) :
    Preliminaries.CompatibleJoinDistributive (Configuration E) := by
  intro X Y Z joined mid left right hXY hJoined hMid hLeft hRight
  obtain ⟨U, hXU, hYU⟩ := hXY
  have hJoinedVal : joined.val = X.val ∪ Y.val :=
    congrArg (fun W : Configuration E => W.val)
      (hJoined.unique (unionBelow_isLUB E U X Y hXU hYU))
  have hMidVal : mid.val = joined.val ∩ Z.val :=
    congrArg (fun W : Configuration E => W.val)
      (hMid.unique (intersection_isGLB E joined Z))
  have hLeftVal : left.val = X.val ∩ Z.val :=
    congrArg (fun W : Configuration E => W.val)
      (hLeft.unique (intersection_isGLB E X Z))
  have hRightVal : right.val = Y.val ∩ Z.val :=
    congrArg (fun W : Configuration E => W.val)
      (hRight.unique (intersection_isGLB E Y Z))
  have hVal : mid.val = left.val ∪ right.val := by
    rw [hMidVal, hJoinedVal, hLeftVal, hRightVal]
    exact Set.union_inter_distrib_right _ _ _
  constructor
  · intro W hW
    rcases Set.mem_insert_iff.mp hW with rfl | hW
    · apply (Configuration.le_iff_subset _ _).mpr
      rw [hVal]
      exact Set.subset_union_left
    · have heq : W = right := Set.mem_singleton_iff.mp hW
      subst W
      apply (Configuration.le_iff_subset _ _).mpr
      rw [hVal]
      exact Set.subset_union_right
  · intro W hW
    apply (Configuration.le_iff_subset _ _).mpr
    rw [hVal]
    exact Set.union_subset
      ((Configuration.le_iff_subset left W).mp (hW (by simp)))
      ((Configuration.le_iff_subset right W).mp (hW (by simp)))

theorem dIDomain (E : FinitaryPrimeEventStructure A) :
    Preliminaries.IsDIDomain (Configuration E) where
  toIsScottDomain := scottDomain E
  distributive := distributive E
  finitePrincipalIdeals := by
    intro X hX
    have hfinite : X.val.Finite := (compact_iff_finite E X).mp hX
    have hpreimage : (Subtype.val ⁻¹' X.val.powerset : Set (Configuration E)).Finite :=
      hfinite.powerset.preimage Subtype.val_injective.injOn
    exact hpreimage.subset (fun Y hY => (Configuration.le_iff_subset Y X).mp hY)

theorem compactElements_countable [Countable A] (E : FinitaryPrimeEventStructure A) :
    (Preliminaries.CompactElements (Configuration E)).Countable := by
  have hfinite : ({F : Set A | F.Finite} : Set (Set A)).Countable :=
    Set.Countable.setOf_finite
  have hpreimage : ({X : Configuration E | X.val.Finite} : Set (Configuration E)).Countable :=
    hfinite.preimage Subtype.val_injective
  exact hpreimage.mono (fun X hX => (compact_iff_finite E X).mp hX)

end DIDomainClassification.EventStructures.ConfigurationDomain
