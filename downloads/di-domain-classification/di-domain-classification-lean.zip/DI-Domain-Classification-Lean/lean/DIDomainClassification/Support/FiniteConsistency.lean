import DIDomainClassification.Section02.ScottDomains
import DIDomainClassification.Section02.MicCoherence
import DIDomainClassification.Support.OrderCoreLemmas
import Mathlib.Data.Set.Finite.Lemmas
import Mathlib.Data.Set.Finite.Powerset

/-!
# Elementary consequences of the accepted Scott-domain and mic definitions

These supporting lemmas use only the already frozen domain predicates.
They do not assume the finite-consistency characterization or any degree law.
The full source characterization remains a separate statement/proof target.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.CoherenceDegree

open DIDomainClassification.Preliminaries

theorem consistent_of_finite_subsets_consistent {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (X : Set D)
    (hX : ∀ F : Set D, F.Finite → F ⊆ X → Consistent F) : Consistent X := by
  classical
  let carrier (F : Finset X) : Set D := Subtype.val '' (↑F : Set X)
  have hcarrier (F : Finset X) : Consistent (carrier F) := by
    apply hX
    · exact F.finite_toSet.image Subtype.val
    · rintro x ⟨a, _ha, rfl⟩
      exact a.property
  choose sup hsup using fun F : Finset X => hD.boundedSuprema (carrier F) (hcarrier F)
  have hmono {F G : Finset X} (hFG : F ⊆ G) : sup F ≤ sup G := by
    apply (hsup F).2
    rintro x ⟨a, ha, rfl⟩
    exact (hsup G).1 ⟨a, hFG ha, rfl⟩
  have hdir : OrderCore.DirectedSet (Set.range sup) := by
    refine ⟨⟨sup ∅, ⟨∅, rfl⟩⟩, ?_⟩
    rintro x ⟨F, rfl⟩ y ⟨G, rfl⟩
    exact ⟨sup (F ∪ G), ⟨F ∪ G, rfl⟩,
      hmono Finset.subset_union_left, hmono Finset.subset_union_right⟩
  obtain ⟨s, hs⟩ := hD.algebraic.1 (Set.range sup) hdir
  refine ⟨s, ?_⟩
  intro x hx
  have hxs : x ≤ sup {⟨x, hx⟩} :=
    (hsup {⟨x, hx⟩}).1 ⟨⟨x, hx⟩, by simp, rfl⟩
  exact hxs.trans (hs.1 ⟨{⟨x, hx⟩}, rfl⟩)

theorem exists_minimally_inconsistent_subset {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (S : Set D) (hS : S.Finite)
    (hbad : ¬ Consistent S) :
    ∃ M : Set D, M ⊆ S ∧ IsMinimallyInconsistent hD M := by
  classical
  let bad : Set (Set D) := {M | M ⊆ S ∧ ¬ Consistent M}
  have hbadfin : bad.Finite := hS.powerset.subset (fun _ h => h.1)
  obtain ⟨M, hMbad, hMmin⟩ :=
    Set.exists_min_image bad Set.ncard hbadfin ⟨S, Set.Subset.refl S, hbad⟩
  have hMfin : M.Finite := hS.subset hMbad.1
  refine ⟨M, hMbad.1, hMfin, hMbad.2, ?_⟩
  intro N hNM
  by_contra hNbad
  have hNmem : N ∈ bad := ⟨hNM.subset.trans hMbad.1, hNbad⟩
  exact (not_le_of_gt (Set.ncard_lt_ncard hNM hMfin)) (hMmin N hNmem)

end DIDomainClassification.CoherenceDegree
