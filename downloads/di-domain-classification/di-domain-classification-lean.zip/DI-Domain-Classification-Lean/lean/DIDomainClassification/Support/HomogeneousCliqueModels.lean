import DIDomainClassification.Support.InfiniteGraphHomogeneous
import DIDomainClassification.Support.InfiniteCompactBasis
import DIDomainClassification.Support.StarCliqueObstruction
import DIDomainClassification.Support.ZhaoKouRetraction
import DIDomainClassification.Support.FlatPowerRetraction

/-! The homogeneous graph alternatives are the actual powerset and flat
natural-number domains, not a proxy graph certificate. The stable retractions
are the proved image/preimage maps followed by the actual predicate isomorphism.
The second predicate step uses the literal common upper bound in the powerset. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.HomogeneousCliqueModels

open Preliminaries Section02.BinaryCliqueModels Section03.StableFunctionModels
open Section04.AdditionalSourceModels Section04.PredicateModels

abbrev Event : Type u := ULift.{u} ℕ
def complete : SimpleGraph Event.{u} := ⊤
def discrete : SimpleGraph Event.{u} := ⊥

def cliqueCB (G : SimpleGraph Event.{u}) : IsCountablyBasedDIDomain (CliqueCarrier G) :=
  StarCliqueObstruction.cliqueCertificate G

def cliqueObject (G : SimpleGraph Event.{u}) : CountablyBasedDIDomain.{u} :=
  cbObject (CliqueCarrier G) (cliqueCB G)

def powersetOrderIso : CliqueCarrier complete.{u} ≃o NatPowersetCarrier.{u} where
  toFun Y := ⟨{n | (⟨n⟩ : Event.{u}) ∈ Y.val}⟩
  invFun X := ⟨{n | n.down ∈ X.down}, by
    intro a _ b _ hab
    exact (SimpleGraph.top_adj a b).mpr hab⟩
  left_inv Y := by
    apply Subtype.ext
    ext a
    rcases a with ⟨a⟩
    rfl
  right_inv X := by
    apply ULift.ext
    rfl
  map_rel_iff' := by
    intro X Y
    constructor
    · intro h a ha
      exact h ha
    · intro h n hn
      exact h hn

def powersetCB : IsCountablyBasedDIDomain NatPowersetCarrier.{u} :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff powersetOrderIso).mp (cliqueCB complete)

abbrev powersetObject : CountablyBasedDIDomain.{u} := natPowersetObject powersetCB.{u}

theorem powerset_infinite : Infinite NatPowersetCarrier.{u} := by
  apply Infinite.of_injective (fun n : ℕ => (⟨{n}⟩ : NatPowersetCarrier.{u}))
  intro n m h
  have heq : ({n} : Set ℕ) = {m} := congrArg ULift.down h
  have hm : n ∈ ({m} : Set ℕ) := heq ▸ (by simp)
  exact Set.mem_singleton_iff.mp hm

theorem powerset_compatible (X Y : Core powersetObject.{u}) : Compatible X Y :=
  ⟨⟨Set.univ⟩, Set.subset_univ _, Set.subset_univ _⟩

def flatClique : FlatCarrier.{u} → CliqueCarrier discrete.{u}
  | ⟨BasicDomains.FlatNat.bot⟩ => ⟨∅, SimpleGraph.isClique_empty⟩
  | ⟨BasicDomains.FlatNat.nat n⟩ => StarCliqueObstruction.singleton discrete ⟨n⟩

theorem flatClique_le_iff (X Y : FlatCarrier.{u}) :
    flatClique X ≤ flatClique Y ↔ X ≤ Y := by
  rcases X with ⟨X⟩
  rcases Y with ⟨Y⟩
  cases X with
  | bot =>
      constructor
      · intro _
        exact Or.inl rfl
      · intro _
        exact Set.empty_subset _
  | nat n =>
      cases Y with
      | bot =>
          constructor
          · intro h
            have hn : (⟨n⟩ : Event.{u}) ∈ (∅ : Set Event.{u}) := h (by simp [flatClique, StarCliqueObstruction.singleton])
            exact False.elim hn
          · intro h
            exact False.elim (BasicDomains.FlatNat.nat_not_le_bot n h)
      | nat m =>
          change ({(⟨n⟩ : Event.{u})} : Set Event.{u}) ⊆ {⟨m⟩} ↔
            BasicDomains.FlatNat.nat n ≤ BasicDomains.FlatNat.nat m
          rw [Set.singleton_subset_iff, Set.mem_singleton_iff,
            BasicDomains.FlatNat.nat_le_nat_iff]
          constructor
          · exact congrArg ULift.down
          · intro h
            subst m
            rfl

theorem flatClique_injective : Function.Injective flatClique.{u} := by
  intro X Y h
  exact le_antisymm ((flatClique_le_iff X Y).mp h.le)
    ((flatClique_le_iff Y X).mp h.symm.le)

theorem flatClique_surjective : Function.Surjective flatClique.{u} := by
  intro Y
  have hUnique {a b : Event.{u}} (ha : a ∈ Y.val) (hb : b ∈ Y.val) : a = b := by
    by_contra hab
    exact Y.property ha hb hab
  by_cases hne : Y.val.Nonempty
  · obtain ⟨a, ha⟩ := hne
    refine ⟨⟨BasicDomains.FlatNat.nat a.down⟩, ?_⟩
    apply Subtype.ext
    change ({⟨a.down⟩} : Set Event.{u}) = Y.val
    have hLift : (⟨a.down⟩ : Event.{u}) = a := by cases a; rfl
    rw [hLift]
    exact Set.Subset.antisymm (Set.singleton_subset_iff.mpr ha)
      (fun b hb => Set.mem_singleton_iff.mpr (hUnique hb ha))
  · refine ⟨⟨BasicDomains.FlatNat.bot⟩, ?_⟩
    apply Subtype.ext
    change (∅ : Set Event.{u}) = Y.val
    ext a
    simp only [Set.mem_empty_iff_false, false_iff]
    intro ha
    exact hne ⟨a, ha⟩

def flatOrderIso : FlatCarrier.{u} ≃o CliqueCarrier discrete.{u} where
  toEquiv := Equiv.ofBijective flatClique ⟨flatClique_injective, flatClique_surjective⟩
  map_rel_iff' := by intro X Y; exact flatClique_le_iff X Y

abbrev flatCertificate := FlatPowerRetraction.flat_countablyBased.{u}
abbrev flatDomain : CountablyBasedDIDomain.{u} := flatObject flatCertificate.{u}

theorem into_predicates (D : CountablyBasedDIDomain.{u}) (G : SimpleGraph Event.{u})
    (i : Event.{u} → ↥(CompactElements (Core D))) (hi : Function.Injective i)
    (hAdj : ∀ a b, G.Adj a b ↔ (graph D).Adj (i a) (i b)) :
    HasStableRetraction (Core (cliqueObject G)) (Core (exponential D FiniteOrderDomains.twoObject.{u})) := by
  have hClique : HasStableRetraction (Core (cliqueObject G))
      (CliqueStableMaps.core (graph D) (PredicateCliqueIso.cliqueCountablyBased D).1) :=
    CliqueStableMaps.hasRetraction G (graph D) i hi hAdj (cliqueCB G).1
      (PredicateCliqueIso.cliqueCountablyBased D).1
  exact ZhaoKouRetraction.trans hClique
    (ZhaoKouRetraction.ofOrderIso _ _ (PredicateCliqueIso.orderIso D).symm)

theorem flat_into_predicates (D : CountablyBasedDIDomain.{u})
    (i : Event.{u} → ↥(CompactElements (Core D))) (hi : Function.Injective i)
    (hAdj : ∀ a b, ¬ (graph D).Adj (i a) (i b)) :
    HasStableRetraction (Core flatDomain.{u}) (Core (exponential D FiniteOrderDomains.twoObject.{u})) := by
  have hGraph : ∀ a b, discrete.Adj a b ↔ (graph D).Adj (i a) (i b) := by
    intro a b
    exact iff_of_false (fun h => h) (hAdj a b)
  exact ZhaoKouRetraction.trans
    (ZhaoKouRetraction.ofOrderIso (Core flatDomain) (Core (cliqueObject discrete)) flatOrderIso)
    (into_predicates D discrete i hi hGraph)

theorem infinite_predicate_alternatives (D : CountablyBasedDIDomain.{u}) [Infinite D] :
    HasStableRetraction (Core flatDomain.{u}) (Core (exponential D FiniteOrderDomains.twoObject.{u})) ∨
    HasStableRetraction (Core powersetObject.{u}) (Core (exponential D FiniteOrderDomains.twoObject.{u})) := by
  letI : Infinite ↥(CompactElements (Core D)) := InfiniteCompactBasis.infinite_compacts D
  obtain ⟨e, hComplete | hDiscrete⟩ := InfiniteGraphHomogeneous.exists_homogeneous (graph D)
  · right
    let i : Event.{u} → ↥(CompactElements (Core D)) := fun n => e n.down
    have hi : Function.Injective i := by
      intro a b h
      apply ULift.ext
      exact e.injective h
    have hAdj : ∀ a b, complete.Adj a b ↔ (graph D).Adj (i a) (i b) := by
      intro a b
      constructor
      · intro h
        apply hComplete
        intro hEq
        exact ((SimpleGraph.top_adj a b).mp h) (by apply ULift.ext; exact hEq)
      · intro h
        apply (SimpleGraph.top_adj a b).mpr
        intro hEq
        subst b
        exact (graph D).irrefl h
    exact ZhaoKouRetraction.trans
      (ZhaoKouRetraction.ofOrderIso (Core powersetObject) (Core (cliqueObject complete)) powersetOrderIso.symm)
      (into_predicates D complete i hi hAdj)
  · left
    let i : Event.{u} → ↥(CompactElements (Core D)) := fun n => e n.down
    have hi : Function.Injective i := by
      intro a b h
      apply ULift.ext
      exact e.injective h
    exact flat_into_predicates D i hi (fun a b => hDiscrete a.down b.down)

theorem flat_into_powerset_predicates : HasStableRetraction (Core flatDomain.{u})
    (Core (exponential powersetObject.{u} FiniteOrderDomains.twoObject.{u})) := by
  letI : Infinite (Core powersetObject.{u}) := powerset_infinite
  letI : Infinite ↥(CompactElements (Core powersetObject.{u})) :=
    InfiniteCompactBasis.infinite_compacts powersetObject
  let e := Infinite.natEmbedding ↥(CompactElements (Core powersetObject.{u}))
  let i : Event.{u} → ↥(CompactElements (Core powersetObject.{u})) := fun n => e n.down
  have hi : Function.Injective i := by
    intro a b h
    apply ULift.ext
    exact e.injective h
  apply flat_into_predicates powersetObject i hi
  intro a b hAdj
  exact hAdj.2 (powerset_compatible (i a).val (i b).val)

end DIDomainClassification.HomogeneousCliqueModels
