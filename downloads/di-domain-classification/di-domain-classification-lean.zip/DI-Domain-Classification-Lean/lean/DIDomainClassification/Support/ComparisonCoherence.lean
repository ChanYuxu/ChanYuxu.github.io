import DIDomainClassification.Support.ComparisonOperations
import DIDomainClassification.Support.SeparatedSumDomain

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonCoherence
open OrderCore Preliminaries Section03.StableFunctionModels
open Section04 AdditionalSourceModels

theorem pairwise_of_small {X : Type u} [PartialOrder X] (A : Set X)
    (hA : ∀ F ⊆ A, F.Finite → F.ncard ≤ 2 → BddAbove F) :
    ∀ x ∈ A, ∀ y ∈ A, Compatible x y := by
  intro x hx y hy
  have hsub : ({x,y} : Set X) ⊆ A := by
    intro z hz
    rcases hz with rfl | rfl
    · exact hx
    · exact hy
  have hc : ({x,y} : Set X).ncard ≤ 2 := by
    by_cases hxy : x=y
    · subst y; simp
    · exact (Set.ncard_pair hxy).le
  obtain ⟨z,hz⟩ := hA {x,y} hsub (Set.toFinite _) hc
  exact ⟨z,hz (by simp),hz (by simp)⟩

theorem bounded_of_pairwise (D : CountablyBasedDIDomain.{u})
    (hD : CoherenceDegree.IsNCoherent (Core D).isDIDomain.toIsScottDomain 2 (by decide))
    (A : Set (Core D)) (hp : ∀ x ∈ A, ∀ y ∈ A, Compatible x y) : BddAbove A := by
  apply (CoherenceDegree.coherenceCharacterization (Core D)
    (Core D).isDIDomain.toIsScottDomain 2 (by decide)).mp hD
  intro F hFA hF hcard
  exact SeparatedSumDomain.small_bounded_of_pairwise
    (Core D).isDIDomain.toIsScottDomain F hF hcard
    (fun x hx y hy => hp x (hFA hx) y (hFA hy))

theorem product_two (H K : CountablyBasedDIDomain.{u})
    (hH : CoherenceDegree.IsNCoherent (Core H).isDIDomain.toIsScottDomain 2 (by decide))
    (hK : CoherenceDegree.IsNCoherent (Core K).isDIDomain.toIsScottDomain 2 (by decide)) :
    CoherenceDegree.IsNCoherent
      (Core (Section02.StableBackground.productObject trueClosure H K)).isDIDomain.toIsScottDomain
      2 (by decide) := by
  let P := Section02.StableBackground.productObject trueClosure H K
  apply (CoherenceDegree.coherenceCharacterization (Core P)
    (Core P).isDIDomain.toIsScottDomain 2 (by decide)).mpr
  intro A hA
  have hp := pairwise_of_small A hA
  have hbH : BddAbove (Prod.fst '' A) := by
    apply bounded_of_pairwise H hH
    rintro x ⟨a,ha,rfl⟩ y ⟨b,hb,rfl⟩
    obtain ⟨z,haz,hbz⟩ := hp a ha b hb
    exact ⟨z.1,haz.1,hbz.1⟩
  have hbK : BddAbove (Prod.snd '' A) := by
    apply bounded_of_pairwise K hK
    rintro x ⟨a,ha,rfl⟩ y ⟨b,hb,rfl⟩
    obtain ⟨z,haz,hbz⟩ := hp a ha b hb
    exact ⟨z.2,haz.2,hbz.2⟩
  obtain ⟨x,hx⟩ := hbH
  obtain ⟨y,hy⟩ := hbK
  exact ⟨(x,y),fun a ha => ⟨hx ⟨a,ha,rfl⟩,hy ⟨a,ha,rfl⟩⟩⟩

theorem comparison_transitive : ComparisonTransitivityStatement.{u} := by
  intro D E F hDE hEF
  obtain ⟨H,hH,hD⟩ := hDE
  obtain ⟨K,hK,hE⟩ := hEF
  let P := Section02.StableBackground.productObject trueClosure H K
  refine ⟨P,product_two H K hH hK, ?_⟩
  apply ComparisonOperations.split_trans hD
  apply ComparisonOperations.split_trans (ComparisonOperations.exponential_split H E (exponential K F) hE)
  exact ComparisonOperations.iso_split _ _
    (StableCCCOperations.curryingOrderIso trueClosure H K F).symm

end DIDomainClassification.ComparisonCoherence
