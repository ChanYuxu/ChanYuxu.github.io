import DIDomainClassification.Support.OrderIsoTransport
import DIDomainClassification.Support.StableIdempotentClosure

/-!
Generic stable-split closure theorems. These are not source-facing retraction
interfaces and assert no source-theorem acceptance. The final theorem derives
the source carrier's domain property; it does not assume that property.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.StableSplitClosure

open OrderIsoTransport
open Preliminaries (IsDIDomain IsCountablyBasedDIDomain CompactElements)

def literalFixedBridge {D : Type u} {E : Type v} [PartialOrder D] [PartialOrder E]
    (s : D → E) (r : E → D) (hs : Monotone s) (hr : Monotone r)
    (hleft : Function.LeftInverse r s) :
    D ≃o StableIdempotentClosure.Fixed (fun y : E => s (r y)) :=
  splitFixedOrderIso s r hs hr hleft

theorem stableComposite_preservesCompatibleInfima {D : Type u} {E : Type v}
    [SemilatticeInf D] [SemilatticeInf E] (s : StableMap D E) (r : StableMap E D) :
    StableIdempotentClosure.PreservesCompatibleInfima (fun y : E => s (r y)) := by
  intro x y m hxy hm
  have hm_eq : m = x ⊓ y := hm.unique isGLB_pair
  have hrcomp : Compatible (r x) (r y) := by
    obtain ⟨z, hxz, hyz⟩ := hxy
    exact ⟨r z, r.scottContinuous.monotone hxz, r.scottContinuous.monotone hyz⟩
  change IsGLB ({s (r x), s (r y)} : Set E) (s (r m))
  rw [hm_eq, r.map_inf_of_compatible x y hxy,
    s.map_inf_of_compatible (r x) (r y) hrcomp]
  exact isGLB_pair

/-- The source has no assumed algebraicity, compact countability or dI axiom.
The supplied semilattice orders are literal; raw stable maps and a left inverse
are sufficient. Fixed-point closure is the actual canonical proved theorem.
-/
theorem countablyBased_of_rawStableSplit {D : Type u} {E : Type v}
    [SemilatticeInf D] [SemilatticeInf E] (hE : IsDIDomain E)
    (hK : (CompactElements E).Countable) (s : StableMap D E) (r : StableMap E D)
    (hleft : Function.LeftInverse r s) : IsCountablyBasedDIDomain D := by
  have hf : ScottContinuous (fun y : E => s (r y)) :=
    r.scottContinuous.comp s.scottContinuous
  have hid : StableIdempotentClosure.Idempotent (fun y : E => s (r y)) :=
    split_composite_idempotent s r hleft
  have hfixed := StableIdempotentClosure.fixed_isCountablyBasedDIDomain hE hf hid
    (stableComposite_preservesCompatibleInfima s r) hK
  exact (isCountablyBasedDIDomain_iff (stableMapSplitFixedOrderIso s r hleft)).mpr hfixed

end DIDomainClassification.StableSplitClosure
