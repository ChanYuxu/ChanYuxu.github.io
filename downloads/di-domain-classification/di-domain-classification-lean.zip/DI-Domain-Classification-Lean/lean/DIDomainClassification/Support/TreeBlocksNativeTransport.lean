import DIDomainClassification.Section04.AdditionalSourceModels
import DIDomainClassification.Support.OrderIsoTransport

/-! Actual stable-Hom target transport in independent source/target universes.
The stable comparison, not pointwise comparison, is preserved and reflected. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeBlocksNativeTransport

variable (H : DIDomainObject.{u}) (D E : DIDomainObject.{v}) (e : D ≃o E)

def postMap (f : StableHom H D) : StableHom H E :=
  StableHom.comp (OrderIsoTransport.stableHom D E e) f

theorem postMap_apply (f : StableHom H D) (x : H) : postMap H D E e f x = e (f x) := rfl

theorem postMap_order_iff (f g : StableHom H D) :
    postMap H D E e f ≤ postMap H D E e g ↔ f ≤ g := by
  constructor
  · intro h x y hxy
    have hv := h x y hxy
    change e (f x) = e (f y) ⊓ e (g x) at hv
    apply e.injective
    exact hv.trans (OrderIsoTransport.map_intrinsic_inf e D.isDIDomain.toIsScottDomain
      E.isDIDomain.toIsScottDomain (f y) (g x)).symm
  · intro h x y hxy
    change e (f x) = e (f y) ⊓ e (g x)
    rw [h x y hxy]
    exact OrderIsoTransport.map_intrinsic_inf e D.isDIDomain.toIsScottDomain
      E.isDIDomain.toIsScottDomain (f y) (g x)

theorem postMap_leftInverse :
    Function.LeftInverse (postMap H E D e.symm) (postMap H D E e) := by
  intro f
  apply StableHom.ext
  intro x
  change e.symm (e (f x)) = f x
  exact e.symm_apply_apply (f x)

theorem postMap_rightInverse :
    Function.RightInverse (postMap H E D e.symm) (postMap H D E e) := by
  intro f
  apply StableHom.ext
  intro x
  change e (e.symm (f x)) = f x
  exact e.apply_symm_apply (f x)

def postOrderIso : StableHom H D ≃o StableHom H E where
  toFun := postMap H D E e
  invFun := postMap H E D e.symm
  left_inv := postMap_leftInverse H D E e
  right_inv := postMap_rightInverse H D E e
  map_rel_iff' := by
    intro f g
    exact postMap_order_iff H D E e f g

end DIDomainClassification.TreeBlocksNativeTransport
