import DIDomainClassification.Support.HomogeneousCliqueModels
import DIDomainClassification.Section02.Inherited
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Section04.SeparatedSum
import DIDomainClassification.Section05.ZhaoKou

/-! Infinite generation from the exact intrinsic category hypotheses. Ambient
exponential membership is derived through the actual inherited isomorphism,
not added as a closure assumption. Powers use the proved literal flat split.
The final U and W are the same constructed objects as local Zhao--Kou. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.InfiniteCategoryGeneration

open CategoryTheory CategoryTheory.Limits Preliminaries Subcategories CoherenceDegree
open Section03.StableFunctionModels Section04 Section04.CutModels
open Section04.AdditionalSourceModels HomogeneousCliqueModels

variable (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
include hP

theorem two_mem : P FiniteOrderDomains.twoObject.{u} := by
  obtain ⟨D, hD, hxy⟩ := hP.1
  exact hP.2.2.2 _ D hD (Section02.twoRetract (Core D) hxy).2

theorem exponential_mem (D E : CountablyBasedDIDomain.{u}) (hD : P D) (hE : P E) :
    P (exponential D E) := by
  obtain ⟨hProducts, hAdj⟩ := hP.2.2.1
  letI : HasFiniteProducts (FullStableSubcategory P) := hProducts
  let X : FullStableSubcategory P := ⟨D, hD⟩
  let Y : FullStableSubcategory P := ⟨E, hE⟩
  letI : (prod.functor.obj X).IsLeftAdjoint := hAdj X
  let R := (prod.functor.obj X).rightAdjoint
  have A : (prod.functor.obj X) ⊣ R := Adjunction.ofIsLeftAdjoint _
  obtain ⟨e⟩ := ((Section02.inherited P hP.2.1 hP.1 hP.2.2.2 hP.2.2.1)
    hProducts X Y).2 R A
  exact (replete_iff P).mp hP.2.1 e (R.obj Y).property

theorem flat_mem (hInfinite : ∃ D : CountablyBasedDIDomain.{u}, P D ∧ Infinite D) :
    P flatDomain.{u} := by
  obtain ⟨D, hD, hInf⟩ := hInfinite
  letI : Infinite D := hInf
  have hPred : P (exponential D FiniteOrderDomains.twoObject.{u}) :=
    exponential_mem P hP D _ hD (two_mem P hP)
  rcases infinite_predicate_alternatives D with hFlat | hPower
  · exact hP.2.2.2 _ _ hPred hFlat
  · have hPow : P powersetObject.{u} := hP.2.2.2 _ _ hPred hPower
    have hPowPred : P (exponential powersetObject.{u} FiniteOrderDomains.twoObject.{u}) :=
      exponential_mem P hP _ _ hPow (two_mem P hP)
    exact hP.2.2.2 _ _ hPowPred flat_into_powerset_predicates

theorem countable_powers_of_flat (hFlat : P flatDomain.{u})
    (X : CountablyBasedDIDomain.{u}) (hX : P X) :
    ∃ hPower : IsCountablyBasedDIDomain (ℕ → Core X), P (cbObject (ℕ → Core X) hPower) := by
  obtain ⟨hF, hPower, _hCoherent, S, R, _hS, _hR, hLeft⟩ := countablePowersRetraction X
  have hFMem : P (flatObject hF) := hFlat
  have hExp : P (exponential (flatObject hF) X) :=
    exponential_mem P hP _ _ hFMem hX
  refine ⟨hPower, hP.2.2.2 _ _ hExp ?_⟩
  exact ⟨S, R, hLeft⟩

theorem countable_powers_mem (hInfinite : ∃ D : CountablyBasedDIDomain.{u}, P D ∧ Infinite D)
    (X : CountablyBasedDIDomain.{u}) (hX : P X) :
    ∃ hPower : IsCountablyBasedDIDomain (ℕ → Core X), P (cbObject (ℕ → Core X) hPower) :=
  countable_powers_of_flat P hP (flat_mem P hP hInfinite) X hX

theorem cube_mem : P (FiniteCategoryModels.cubeObject 2 (by decide)
    TwoExponentialOrderIso.cubeCountablyBased.{u}) := by
  have hExp : P (exponential FiniteOrderDomains.twoObject.{u} FiniteOrderDomains.twoObject.{u}) :=
    exponential_mem P hP _ _ (two_mem P hP) (two_mem P hP)
  exact (replete_iff P).mp hP.2.1 TwoExponentialOrderIso.stableIso hExp

theorem base_mem (hFlat : P flatDomain.{u}) : P ZhaoKouCodes.baseObject.{u} := by
  obtain ⟨hPower, hMem⟩ := countable_powers_of_flat P hP hFlat
    (FiniteCategoryModels.cubeObject 2 (by decide) TwoExponentialOrderIso.cubeCountablyBased.{u})
    (cube_mem P hP)
  exact hMem

theorem W_mem (hFlat : P flatDomain.{u}) :
    P (universalTwoObject ZhaoKouCodes.baseCertificate.{u}) :=
  exponential_mem P hP _ _ (base_mem P hP hFlat) (base_mem P hP hFlat)

omit hP in
theorem domainCut_three_twoCoherent (D : CountablyBasedDIDomain.{u})
    (hD : DomainCut 3 D) : IsNCoherent (Core D).isDIDomain.toIsScottDomain 2 (by decide) := by
  have hDegree : coherenceDegree (Core D).isDIDomain.toIsScottDomain ≤ (2 : Ordinal.{u+1}) := by
    change coherenceDegree (Core D).isDIDomain.toIsScottDomain < (2 : Ordinal.{u+1}) + 1 at hD
    rwa [← Order.succ_eq_add_one, Order.lt_succ_iff] at hD
  exact (Section02.BPSProof.finiteDegreeIffCoherent D
    (Core D).isDIDomain.toIsScottDomain D.countableCompacts 2 (by decide)).mp hDegree

theorem all_twoCoherent_mem (hFlat : P flatDomain.{u})
    (D : CountablyBasedDIDomain.{u}) (hD : DomainCut 3 D) : P D :=
  hP.2.2.2 D _ (W_mem P hP hFlat)
    (ZhaoKouUniversality.universality D (domainCut_three_twoCoherent D hD))

end DIDomainClassification.InfiniteCategoryGeneration
