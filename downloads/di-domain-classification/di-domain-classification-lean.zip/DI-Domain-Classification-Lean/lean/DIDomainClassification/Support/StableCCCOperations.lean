import DIDomainClassification.Section02.StableBackgroundStatement
import DIDomainClassification.Support.OrderIsoTransport
import DIDomainClassification.Support.StableHomPointwiseSupport

/-!
# Conditional actual stable cartesian-closed operations

Generic support conditional on an arbitrary DomainClosure C. This file does
not inhabit DomainClosure and is not a source Theorem 2.2/CCC acceptance.
Products and exponentials are the exact literal carriers of the accepted
specification, with their original orders and intrinsic derived infima.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.StableCCCOperations

open OrderCore
open Section02.StableBackground

noncomputable section

theorem hom_pointwise_le {D E : Obj.{u}} {f g : Hom D E} (hfg : f ≤ g) (x : Core D) :
    f x ≤ g x :=
  StableHomPointwiseSupport.stableLE_pointwise
    ((StableHomPointwiseSupport.hom_le_iff_raw f g).mp hfg) x

theorem product_inf_eq (C : DomainClosure.{u}) (D E : Obj.{u})
    (p q : Core D × Core E) :
    (Core (productObject C D E)).isDIDomain.toIsScottDomain.inf p q =
      (p.1 ⊓ q.1, p.2 ⊓ q.2) := by
  apply (DIDomainObject.inf_isGLB (Core (productObject C D E)) p q).unique
  constructor
  · intro z hz
    rcases Set.mem_insert_iff.mp hz with hz | hz
    · subst z
      exact ⟨inf_le_left, inf_le_left⟩
    · have heq : z = q := Set.mem_singleton_iff.mp hz
      subst z
      exact ⟨inf_le_right, inf_le_right⟩
  · intro z hz
    have hzp : z ≤ p := hz (by simp)
    have hzq : z ≤ q := hz (by simp)
    exact ⟨le_inf hzp.1 hzq.1, le_inf hzp.2 hzq.2⟩

/-- Actual exponential intrinsic infima are pointwise ONLY for stable-compatible maps. -/
theorem exponential_inf_apply (C : DomainClosure.{u}) (D E : Obj.{u})
    (f g : Hom D E) (hcomp : Compatible f g) (x : Core D) :
    ((Core (exponentialObject C D E)).isDIDomain.toIsScottDomain.inf f g) x = f x ⊓ g x :=
  (StableHomPointwiseSupport.hom_isGLB_pair_iff_values f g hcomp _).mp
    (DIDomainObject.inf_isGLB (Core (exponentialObject C D E)) f g) x

def terminalArrow (C : DomainClosure.{u}) (D : Obj.{u}) : Hom D (terminalObject C) :=
  StableHom.ofFunction (fun _ => PUnit.unit)
    ⟨ScottContinuous.const _, fun _ _ _ => Subsingleton.elim _ _⟩

theorem terminal_apply (C : DomainClosure.{u}) (D : Obj.{u}) (x : Core D) :
    terminalArrow C D x = PUnit.unit := rfl

theorem terminal_unique (C : DomainClosure.{u}) (D : Obj.{u})
    (f : Hom D (terminalObject C)) : f = terminalArrow C D :=
  StableHom.ext (fun _ => Subsingleton.elim _ _)

def fst (C : DomainClosure.{u}) (D E : Obj.{u}) : Hom (productObject C D E) D := by
  refine StableHom.ofFunction Prod.fst ⟨ScottContinuous.fst, ?_⟩
  intro p q _hcomp
  change ((Core (productObject C D E)).isDIDomain.toIsScottDomain.inf p q).1 = p.1 ⊓ q.1
  rw [product_inf_eq]

def snd (C : DomainClosure.{u}) (D E : Obj.{u}) : Hom (productObject C D E) E := by
  refine StableHom.ofFunction Prod.snd ⟨ScottContinuous.snd, ?_⟩
  intro p q _hcomp
  change ((Core (productObject C D E)).isDIDomain.toIsScottDomain.inf p q).2 = p.2 ⊓ q.2
  rw [product_inf_eq]

def pair (C : DomainClosure.{u}) (X D E : Obj.{u}) (f : Hom X D) (g : Hom X E) :
    Hom X (productObject C D E) := by
  refine StableHom.ofFunction (fun x => (f x, g x))
    ⟨(StableHom.isStable f).1.prodMk (StableHom.isStable g).1, ?_⟩
  intro x y hxy
  change (f (x ⊓ y), g (x ⊓ y)) =
    (Core (productObject C D E)).isDIDomain.toIsScottDomain.inf (f x, g x) (f y, g y)
  rw [product_inf_eq, (StableHom.isStable f).2 x y hxy,
    (StableHom.isStable g).2 x y hxy]

theorem fst_apply (C : DomainClosure.{u}) (D E : Obj.{u}) (p : Core D × Core E) :
    fst C D E p = p.1 := rfl

theorem snd_apply (C : DomainClosure.{u}) (D E : Obj.{u}) (p : Core D × Core E) :
    snd C D E p = p.2 := rfl

theorem pair_apply (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom X D) (g : Hom X E) (x : Core X) : pair C X D E f g x = (f x, g x) := rfl

theorem pair_fst (C : DomainClosure.{u}) (X D E : Obj.{u}) (f : Hom X D) (g : Hom X E) :
    StableHom.comp (fst C D E) (pair C X D E f g) = f := StableHom.ext (fun _ => rfl)

theorem pair_snd (C : DomainClosure.{u}) (X D E : Obj.{u}) (f : Hom X D) (g : Hom X E) :
    StableHom.comp (snd C D E) (pair C X D E f g) = g := StableHom.ext (fun _ => rfl)

theorem pair_unique (C : DomainClosure.{u}) (X D E : Obj.{u})
    (h : Hom X (productObject C D E)) :
    pair C X D E (StableHom.comp (fst C D E) h) (StableHom.comp (snd C D E) h) = h :=
  StableHom.ext (fun _ => rfl)

/-- Common STABLE uppers provide the rectangle identity needed by evaluation. -/
theorem eval_rectangle {D E : Obj.{u}} (f g U : Hom D E) (hfU : f ≤ U) (hgU : g ≤ U)
    (x y : Core D) (hxy : Compatible x y) :
    f (x ⊓ y) ⊓ g (x ⊓ y) = f x ⊓ g y := by
  apply le_antisymm
  · exact inf_le_inf ((StableHom.isStable f).1.monotone inf_le_left)
      ((StableHom.isStable g).1.monotone inf_le_right)
  · have hwU : f x ⊓ g y ≤ U (x ⊓ y) := by
      rw [(StableHom.isStable U).2 x y hxy]
      exact inf_le_inf (hom_pointwise_le hfU x) (hom_pointwise_le hgU y)
    apply le_inf
    · rw [(StableHom.le_iff f U).mp hfU (x ⊓ y) x inf_le_left]
      exact le_inf inf_le_left hwU
    · rw [(StableHom.le_iff g U).mp hgU (x ⊓ y) y inf_le_right]
      exact le_inf inf_le_right hwU

/-- Joint evaluation continuity is proved from actual stable-order value LUBs. -/
theorem evaluation_scottContinuous (D E : Obj.{u}) :
    ScottContinuous (fun p : Hom D E × Core D => p.1 p.2) := by
  intro A hne hdir s hs
  let hA : DirectedSet A := ⟨hne, hdir⟩
  have hFdir : DirectedSet (Prod.fst '' A) := hA.image (fun _ _ h => h.1)
  have hXdir : DirectedSet (Prod.snd '' A) := hA.image (fun _ _ h => h.2)
  have hFsup : IsLUB (Prod.fst '' A) s.1 :=
    scottContinuous_isSup ScottContinuous.fst hA hs
  have hXsup : IsLUB (Prod.snd '' A) s.2 :=
    scottContinuous_isSup ScottContinuous.snd hA hs
  have hValues := (StableHomPointwiseSupport.hom_isLUB_iff_values
    (Prod.fst '' A) hFdir s.1).mp hFsup s.2
  constructor
  · rintro _ ⟨p, hp, rfl⟩
    exact (hom_pointwise_le (hs.1 hp).1 p.2).trans
      ((StableHom.isStable s.1).1.monotone (hs.1 hp).2)
  · intro z hz
    apply hValues.2
    rintro _ ⟨_, ⟨p, hp, rfl⟩, rfl⟩
    apply ((StableHom.isStable p.1).1 hXdir.1 hXdir.2 hXsup).2
    rintro _ ⟨_, ⟨q, hq, rfl⟩, rfl⟩
    obtain ⟨r, hr, hpr, hqr⟩ := hdir p hp q hq
    calc
      p.1 q.2 ≤ r.1 q.2 := hom_pointwise_le hpr.1 q.2
      _ ≤ r.1 r.2 := (StableHom.isStable r.1).1.monotone hqr.2
      _ ≤ z := hz ⟨r, hr, rfl⟩

def evaluation (C : DomainClosure.{u}) (D E : Obj.{u}) :
    Hom (productObject C (exponentialObject C D E) D) E := by
  refine StableHom.ofFunction (fun p => p.1 p.2) ⟨evaluation_scottContinuous D E, ?_⟩
  intro p q hcomp
  obtain ⟨r, hpr, hqr⟩ := hcomp
  have hmaps : Compatible p.1 q.1 := ⟨r.1, hpr.1, hqr.1⟩
  have hpoints : Compatible p.2 q.2 := ⟨r.2, hpr.2, hqr.2⟩
  change ((Core (productObject C (exponentialObject C D E) D)).isDIDomain.toIsScottDomain.inf p q).1
    ((Core (productObject C (exponentialObject C D E) D)).isDIDomain.toIsScottDomain.inf p q).2 =
    p.1 p.2 ⊓ q.1 q.2
  rw [product_inf_eq]
  change ((Core (exponentialObject C D E)).isDIDomain.toIsScottDomain.inf p.1 q.1)
    (p.2 ⊓ q.2) = p.1 p.2 ⊓ q.1 q.2
  rw [exponential_inf_apply C D E p.1 q.1 hmaps]
  exact eval_rectangle p.1 q.1 r.1 hpr.1 hqr.1 p.2 q.2 hpoints

theorem evaluation_apply (C : DomainClosure.{u}) (D E : Obj.{u})
    (p : Hom D E × Core D) : evaluation C D E p = p.1 p.2 := rfl

def slice (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) (x : Core X) : Hom D E := by
  refine StableHom.ofFunction (fun y => f (x, y)) ⟨?_, ?_⟩
  · exact ((ScottContinuous.const x).prodMk ScottContinuous.id).comp (StableHom.isStable f).1
  · intro y z hcomp
    obtain ⟨w, hyw, hzw⟩ := hcomp
    have hpair : Compatible (x, y) (x, z) :=
      ⟨(x, w), ⟨le_rfl, hyw⟩, ⟨le_rfl, hzw⟩⟩
    have h := (StableHom.isStable f).2 (x, y) (x, z) hpair
    change f ((Core (productObject C X D)).isDIDomain.toIsScottDomain.inf (x, y) (x, z)) =
      f (x, y) ⊓ f (x, z) at h
    rw [product_inf_eq C X D] at h
    simpa only [inf_idem] using h

theorem slice_apply (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) (x : Core X) (y : Core D) :
    slice C X D E f x y = f (x, y) := rfl

theorem slice_left_scottContinuous (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) (y : Core D) :
    ScottContinuous (fun x : Core X => f (x, y)) :=
  (ScottContinuous.id.prodMk (ScottContinuous.const y)).comp (StableHom.isStable f).1

theorem slice_monotone (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) : Monotone (slice C X D E f) := by
  intro x z hxz
  apply (StableHom.le_iff _ _).mpr
  intro y w hyw
  have hpair : Compatible (x, w) (z, y) :=
    ⟨(z, w), ⟨hxz, le_rfl⟩, ⟨le_rfl, hyw⟩⟩
  have h := (StableHom.isStable f).2 (x, w) (z, y) hpair
  change f ((Core (productObject C X D)).isDIDomain.toIsScottDomain.inf (x, w) (z, y)) =
    f (x, w) ⊓ f (z, y) at h
  rw [product_inf_eq C X D] at h
  simpa only [inf_eq_left.mpr hxz, inf_eq_right.mpr hyw] using h

def curried (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) : Hom X (exponentialObject C D E) := by
  refine StableHom.ofFunction (slice C X D E f) ⟨?_, ?_⟩
  · intro A hne hdir a ha
    let hA : DirectedSet A := ⟨hne, hdir⟩
    have hB : DirectedSet ((slice C X D E f) '' A) :=
      hA.image (slice_monotone C X D E f)
    apply (StableHomPointwiseSupport.hom_isLUB_iff_values _ hB (slice C X D E f a)).mpr
    intro y
    have h := slice_left_scottContinuous C X D E f y hne hdir ha
    simpa only [Set.image_image] using h
  · intro x z hcomp
    obtain ⟨w, hxw, hzw⟩ := hcomp
    have hmaps : Compatible (slice C X D E f x) (slice C X D E f z) :=
      ⟨slice C X D E f w, slice_monotone C X D E f hxw, slice_monotone C X D E f hzw⟩
    apply StableHom.ext
    intro y
    change f (x ⊓ z, y) =
      ((Core (exponentialObject C D E)).isDIDomain.toIsScottDomain.inf
        (slice C X D E f x) (slice C X D E f z)) y
    rw [exponential_inf_apply C D E _ _ hmaps]
    have hpair : Compatible (x, y) (z, y) :=
      ⟨(w, y), ⟨hxw, le_rfl⟩, ⟨hzw, le_rfl⟩⟩
    have h := (StableHom.isStable f).2 (x, y) (z, y) hpair
    change f ((Core (productObject C X D)).isDIDomain.toIsScottDomain.inf (x, y) (z, y)) =
      f (x, y) ⊓ f (z, y) at h
    rw [product_inf_eq C X D] at h
    simpa only [inf_idem] using h

theorem curried_apply (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) (x : Core X) (y : Core D) :
    curried C X D E f x y = f (x, y) := rfl

def uncurried (C : DomainClosure.{u}) (X D E : Obj.{u})
    (g : Hom X (exponentialObject C D E)) : Hom (productObject C X D) E :=
  StableHom.comp (evaluation C D E)
    (pair C (productObject C X D) (exponentialObject C D E) D
      (StableHom.comp g (fst C X D)) (snd C X D))

theorem uncurried_apply (C : DomainClosure.{u}) (X D E : Obj.{u})
    (g : Hom X (exponentialObject C D E)) (p : Core X × Core D) :
    uncurried C X D E g p = g p.1 p.2 := rfl

theorem uncurried_curried (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) : uncurried C X D E (curried C X D E f) = f :=
  StableHom.ext (fun _ => rfl)

theorem curried_uncurried (C : DomainClosure.{u}) (X D E : Obj.{u})
    (g : Hom X (exponentialObject C D E)) : curried C X D E (uncurried C X D E g) = g := by
  apply StableHom.ext
  intro x
  exact StableHom.ext (fun _ => rfl)

theorem slice_le_of_le (C : DomainClosure.{u}) (X D E : Obj.{u})
    {f g : Hom (productObject C X D) E} (hfg : f ≤ g) (x : Core X) :
    slice C X D E f x ≤ slice C X D E g x := by
  apply (StableHom.le_iff _ _).mpr
  intro y z hyz
  exact (StableHom.le_iff f g).mp hfg (x, y) (x, z) ⟨le_rfl, hyz⟩

/-- Ordinary currying is monotone in the actual stable order on both levels. -/
theorem curried_monotone (C : DomainClosure.{u}) (X D E : Obj.{u}) :
    Monotone (curried C X D E) := by
  intro f g hfg
  apply (StableHom.le_iff _ _).mpr
  intro x z hxz
  apply StableHom.ext
  intro y
  have hmaps : Compatible (slice C X D E f z) (slice C X D E g x) :=
    ⟨slice C X D E g z, slice_le_of_le C X D E hfg z, slice_monotone C X D E g hxz⟩
  change f (x, y) = ((Core (exponentialObject C D E)).isDIDomain.toIsScottDomain.inf
    (slice C X D E f z) (slice C X D E g x)) y
  rw [exponential_inf_apply C D E _ _ hmaps]
  exact (StableHom.le_iff f g).mp hfg (x, y) (z, y) ⟨hxz, le_rfl⟩

theorem uncurried_monotone (C : DomainClosure.{u}) (X D E : Obj.{u}) :
    Monotone (uncurried C X D E) := by
  intro f g hfg
  apply (StableHom.le_iff _ _).mpr
  intro p q hpq
  have hfqgq : f q.1 ≤ g q.1 := hom_pointwise_le hfg q.1
  have hgpq : g p.1 ≤ g q.1 := (StableHom.isStable g).1.monotone hpq.1
  have hmaps : Compatible (f q.1) (g p.1) := ⟨g q.1, hfqgq, hgpq⟩
  have hval : f p.1 p.2 = f q.1 p.2 ⊓ g p.1 p.2 := by
    have h := congrArg (fun k : Hom D E => k p.2)
      ((StableHom.le_iff f g).mp hfg p.1 q.1 hpq.1)
    change f p.1 p.2 = ((Core (exponentialObject C D E)).isDIDomain.toIsScottDomain.inf
      (f q.1) (g p.1)) p.2 at h
    rw [exponential_inf_apply C D E _ _ hmaps] at h
    exact h
  change f p.1 p.2 = f q.1 q.2 ⊓ g p.1 p.2
  rw [hval]
  have h := eval_rectangle (f q.1) (g p.1) (g q.1) hfqgq hgpq q.2 p.2
    ⟨q.2, le_rfl, hpq.2⟩
  simpa only [inf_eq_right.mpr hpq.2] using h

/-- The literal currying functions form an order isomorphism in stable order. -/
def curryingOrderIso (C : DomainClosure.{u}) (X D E : Obj.{u}) :
    Hom (productObject C X D) E ≃o Hom X (exponentialObject C D E) where
  toFun := curried C X D E
  invFun := uncurried C X D E
  left_inv := uncurried_curried C X D E
  right_inv := curried_uncurried C X D E
  map_rel_iff' := by
    intro f g
    change curried C X D E f ≤ curried C X D E g ↔ f ≤ g
    constructor
    · intro hfg
      have h := uncurried_monotone C X D E hfg
      simpa only [uncurried_curried C X D E] using h
    · exact fun hfg => curried_monotone C X D E hfg

/-- Higher-order currying is stable by the proved literal order isomorphism.
OrderIsoTransport compares actual intrinsic GLBs; no meet formula is assumed.
-/
def curryOperator (C : DomainClosure.{u}) (X D E : Obj.{u}) :
    Hom (exponentialObject C (productObject C X D) E)
      (exponentialObject C X (exponentialObject C D E)) :=
  OrderIsoTransport.stableHom
    (Core (exponentialObject C (productObject C X D) E))
    (Core (exponentialObject C X (exponentialObject C D E))) (curryingOrderIso C X D E)

theorem curryOperator_apply (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) (x : Core X) (y : Core D) :
    curryOperator C X D E f x y = f (x, y) := rfl

theorem uncurried_curryOperator (C : DomainClosure.{u}) (X D E : Obj.{u})
    (f : Hom (productObject C X D) E) : uncurried C X D E (curryOperator C X D E f) = f :=
  uncurried_curried C X D E f

theorem curryOperator_uncurried (C : DomainClosure.{u}) (X D E : Obj.{u})
    (g : Hom X (exponentialObject C D E)) : curryOperator C X D E (uncurried C X D E g) = g :=
  curried_uncurried C X D E g

abbrev CompositionSource (C : DomainClosure.{u}) (D E F : Obj.{u}) : Obj.{u} :=
  productObject C (exponentialObject C E F) (exponentialObject C D E)

def compositionBody (C : DomainClosure.{u}) (D E F : Obj.{u}) :
    Hom (productObject C (CompositionSource C D E F) D) F :=
  StableHom.comp (evaluation C E F)
    (pair C (productObject C (CompositionSource C D E F) D) (exponentialObject C E F) E
      (StableHom.comp (fst C (exponentialObject C E F) (exponentialObject C D E))
        (fst C (CompositionSource C D E F) D))
      (StableHom.comp (evaluation C D E)
        (pair C (productObject C (CompositionSource C D E F) D) (exponentialObject C D E) D
          (StableHom.comp (snd C (exponentialObject C E F) (exponentialObject C D E))
            (fst C (CompositionSource C D E F) D))
          (snd C (CompositionSource C D E F) D))))

/-- Actual stable HIGHER-ORDER composition, obtained by currying real evaluation. -/
def composition (C : DomainClosure.{u}) (D E F : Obj.{u}) :
    Hom (CompositionSource C D E F) (exponentialObject C D F) :=
  curried C (CompositionSource C D E F) D F (compositionBody C D E F)

theorem composition_apply (C : DomainClosure.{u}) (D E F : Obj.{u})
    (p : Hom E F × Hom D E) (x : Core D) : composition C D E F p x = p.1 (p.2 x) := rfl

end

end DIDomainClassification.StableCCCOperations
