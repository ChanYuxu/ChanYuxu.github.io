import DIDomainClassification.Support.FiniteCutRecovery
import DIDomainClassification.Section04.ComparisonTheorem
import DIDomainClassification.Section05.InfiniteGeneration

/-! Degree downward closure in the presence of an actual infinite object.
The needed two-coherent objects and ambient exponentials are proved members,
not hypotheses hidden in a category record. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.CutRecoveryProof
open Preliminaries Subcategories CoherenceDegree
open Section03.StableFunctionModels Section04 Section04.CutModels

theorem infinite_degree_downward (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (hInfinite : HasInfiniteObject P) (D E : CountablyBasedDIDomain.{u})
    (hDE : objectDegree D ≤ objectDegree E) (hE : P E) : P D := by
  obtain ⟨_hFlat, _hFlatMem, hSmallMem⟩ := Section05.infiniteGeneration P hP hInfinite
  by_cases hSmall : objectDegree D ≤ 2
  · exact hSmallMem D (hSmall.trans_lt
      (by exact_mod_cast (show (2 : ℕ) < 3 by decide) : (2 : Ordinal.{u+1}) < 3))
  · have hLarge : 2 < objectDegree D := lt_of_not_ge hSmall
    have hTwoE : 2 ≤ objectDegree E := hLarge.le.trans hDE
    letI : Nontrivial (Core E) := FinitePowerMembership.nontrivial_of_two_le_degree E hTwoE
    obtain ⟨H, hH, hSplit⟩ := comparisonOfDegreeBound D E inferInstance
      (hDE.trans (le_max_right 2 (objectDegree E)))
    have hDegreeH : objectDegree H ≤ 2 :=
      (finite_degree_iff_nCoherent (Core H).isDIDomain.toIsScottDomain 2 (by decide)).mpr hH
    have hHMem : P H :=
      hSmallMem H (hDegreeH.trans_lt
        (by exact_mod_cast (show (2 : ℕ) < 3 by decide) : (2 : Ordinal.{u+1}) < 3))
    exact hP.2.2.2 D _ (InfiniteCategoryGeneration.exponential_mem P hP H E hHMem hE) hSplit

theorem infinite_class_eq (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (hInfinite : HasInfiniteObject P) : P = DomainCut (parameter P) := by
  funext D
  apply propext
  have h := OrdinalObjectCut.mem_cut_iff objectDegree P
    (fun _ : CountablyBasedDIDomain.{u} => True) (fun _ _ => True.intro)
    (fun A B _ hAB hB => infinite_degree_downward P hP hInfinite A B hAB hB) D
  change P D ↔ objectDegree D < parameter P
  exact h.trans ⟨And.right, fun hD => ⟨True.intro, hD⟩⟩

theorem domain_alternative (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (hInfinite : HasInfiniteObject P) : DomainAlternative P :=
  ⟨parameter P, ⟨parameter_ge_three P hP, parameter_le_bound P⟩,
    infinite_class_eq P hP hInfinite⟩

end DIDomainClassification.CutRecoveryProof
