import DIDomainClassification.Support.ReflexiveProducts
import DIDomainClassification.Support.GeneratedClassClosure
import DIDomainClassification.Section03.FunctionDegree

/-! The actual stable-retract class of E. Native unit/product/exponential
membership is proved before invoking the intrinsic-CCC construction. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ReflexiveRetractionClass
open CategoryTheory Preliminaries CoherenceDegree Subcategories
open Section03.StableFunctionModels Section04.CutModels Section05

def objects (E : CountablyBasedDIDomain.{u}) : ObjectClass.{u} :=
  fun D => HasStableRetraction (Core D) (Core E)

theorem self_mem (E : CountablyBasedDIDomain.{u}) : objects E E :=
  ReflexiveModels.retract_refl (Core E)

theorem replete (E : CountablyBasedDIDomain.{u}) : IsReplete (objects E) := by
  apply (replete_iff _).mpr
  intro A B q hA
  exact ComparisonOperations.split_trans
    (ComparisonOperations.iso_split _ _ (IntrinsicAmbient.isoOrderIso q).symm) hA

theorem retract_closed (E : CountablyBasedDIDomain.{u}) : RetractClosed (objects E) := by
  intro A B hB hAB
  exact ComparisonOperations.split_trans hAB hB

theorem product_closed (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) (A B : CountablyBasedDIDomain.{u})
    (hA : objects E A) (hB : objects E B) :
    objects E (Section02.StableBackground.productObject trueClosure A B) := by
  obtain ⟨sA, rA, hA⟩ := hA
  obtain ⟨sB, rB, hB⟩ := hB
  obtain ⟨_hAB, _hEE, hs, hr, hLeft⟩ := Section02.retractionBinaryProduct
    (Core A) (Core B) (Core E) (Core E) sA rA sB rB hA hB
  exact ComparisonOperations.split_trans
    ⟨StableHom.ofFunction _ hs, StableHom.ofFunction _ hr, hLeft⟩
    (ReflexiveProducts.square_retract E hNon hRef)

theorem exponential_closed (E : CountablyBasedDIDomain.{u}) (hRef : IsStableReflexive E)
    (A B : CountablyBasedDIDomain.{u}) (hA : objects E A) (hB : objects E B) :
    objects E (exponential A B) :=
  ComparisonOperations.split_trans (ReflexiveProducts.exponential_retract A B E E hA hB) hRef

theorem category_hypotheses (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) : CategoryHypotheses (objects E) := by
  refine ⟨⟨E, self_mem E, hNon.exists_pair_ne⟩, replete E, ?_, retract_closed E⟩
  exact FullStableSubcategoryClosure.intrinsicallyCartesianClosed (objects E)
    (product_closed E hNon hRef) (exponential_closed E hRef)
    (GeneratedClassClosure.unitStableRetract E)

/-- Constants give an injective self-map of a finite E; the nonconstant
identity is not in its image. This is the source's cardinality obstruction. -/
theorem not_finite (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) : ¬ Finite E := by
  intro hFin
  letI : Finite (Core E) := hFin
  obtain ⟨s, r, hLeft⟩ := hRef
  let c : Core E → Core E := fun x => s (FunctionDegreeHelpers.constantEmbedding E E x)
  have hc : Function.Injective c := by
    intro x y hxy
    exact congrArg (fun f : Core (exponential E E) =>
      f (Core E).isDIDomain.toIsScottDomain.bottom) (hLeft.injective hxy)
  have hSurj : Function.Surjective c := Finite.surjective_of_injective hc
  obtain ⟨a, ha⟩ := hSurj (s (StableHom.id (Core E)))
  have hConst : FunctionDegreeHelpers.constantEmbedding E E a = StableHom.id (Core E) :=
    hLeft.injective ha
  have hAll : ∀ x : Core E, a = x :=
    fun x => congrArg (fun f : Core (exponential E E) => f x) hConst
  obtain ⟨x, y, hxy⟩ := hNon.exists_pair_ne
  exact hxy ((hAll x).symm.trans (hAll y))

theorem infinite (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) : Infinite E := by
  rcases finite_or_infinite E with hF | hI
  · exact False.elim (not_finite E hNon hRef hF)
  · exact hI

theorem two_le_degree (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) : 2 ≤ objectDegree E := by
  obtain ⟨hCube, s, r, hLeft⟩ := ReflexiveProducts.cubeTwo_retract E hNon hRef
  let T := Section04.FiniteCategoryModels.cubeObject 2 (by decide) hCube
  have hT : objectDegree T = 2 := OrdinalCutWitnesses.cube_degree 2 (by decide)
  have hMono : objectDegree T ≤ objectDegree E := by
    apply Section02.bps.1 (Core T) (Core E)
      (Core T).isDIDomain.toIsScottDomain (Core E).isDIDomain.toIsScottDomain
      T.countableCompacts E.countableCompacts
    exact ⟨s, r, (StableHom.isStable s).1, (StableHom.isStable r).1, hLeft⟩
  exact hT ▸ hMono

end DIDomainClassification.ReflexiveRetractionClass
