import DIDomainClassification.Section02.Comb
import DIDomainClassification.Support.TreeRankLowerBounds

/-!
Actual depth/leaf map from every proper relative-prefix tree into the literal
comb. Whole finite complete branch SETS are mapped onto comb branches, with
branchwise injectivity. Pullback of actual compact comb-label MIC data yields
a genuine MIC tree on the ORIGINAL source tree, including whole infinite
branch injectivity. No well-foundedness or degree conclusion is an input.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.CombMicPullback

open Preliminaries CoherenceDegree Trees

variable {Index : Type v} (S : RootedPrefixTree Index)

local instance : PartialOrder S.Node := prefixNodeOrder S

def depthCombVertex (x : S.Node) : Comb.Vertex := by
  classical
  exact if S.IsLeaf x then Comb.Vertex.leaf (S.depth x - 1)
    else Comb.Vertex.spine (S.depth x)

theorem depthCombVertex_leaf (x : S.Node) (hx : S.IsLeaf x) :
    depthCombVertex S x = Comb.Vertex.leaf (S.depth x - 1) := by
  classical
  simp [depthCombVertex, hx]

theorem depthCombVertex_nonleaf (x : S.Node) (hx : ¬ S.IsLeaf x) :
    depthCombVertex S x = Comb.Vertex.spine (S.depth x) := by
  classical
  simp [depthCombVertex, hx]

theorem leaf_depth_pos (hp : S.IsProper) (z : S.Node) (hz : S.IsLeaf z) :
    0 < S.depth z := by
  apply Nat.pos_of_ne_zero
  intro hzero
  have heq := (S.depth_eq_zero_iff z).mp hzero
  exact S.root_not_leaf_of_proper hp (heq ▸ hz)

theorem depthCombVertex_injOn_path (z : S.Node) :
    Set.InjOn (depthCombVertex S) (S.pathTo z) := by
  classical
  intro x hx y hy hEq
  by_cases hxl : S.IsLeaf x
  · by_cases hyl : S.IsLeaf y
    · exact (hxl z hx).symm.trans (hyl z hy)
    · simp [depthCombVertex, hxl, hyl] at hEq
  · by_cases hyl : S.IsLeaf y
    · simp [depthCombVertex, hxl, hyl] at hEq
    · have hd : S.depth x = S.depth y := by
        simpa [depthCombVertex, hxl, hyl] using hEq
      rcases List.prefix_or_prefix_of_prefix hx hy with hxy | hyx
      · exact S.eq_of_le_of_depth_eq hxy hd
      · exact (S.eq_of_le_of_depth_eq hyx hd.symm).symm

theorem depthCombVertex_path_image (hp : S.IsProper) (z : S.Node) (hz : S.IsLeaf z) :
    depthCombVertex S '' S.pathTo z = Comb.Vertex.finiteBranch (S.depth z - 1) := by
  classical
  have hpos := leaf_depth_pos S hp z hz
  apply Set.Subset.antisymm
  · rintro v ⟨x, hx, rfl⟩
    by_cases hxl : S.IsLeaf x
    · have hxz : x = z := (hxl z hx).symm
      subst x
      rw [depthCombVertex_leaf S z hz]
      exact (Comb.Vertex.leaf_mem_finiteBranch _ _).2 rfl
    · rw [depthCombVertex_nonleaf S x hxl]
      apply (Comb.Vertex.spine_mem_finiteBranch _ _).2
      have hle := S.depth_mono hx
      have hne : S.depth x ≠ S.depth z := by
        intro hd
        exact hxl ((S.eq_of_le_of_depth_eq hx hd).symm ▸ hz)
      omega
  · rintro v (⟨k, hk, rfl⟩ | rfl)
    · have hkd : k < S.depth z := by omega
      let x := S.prefixAt z k
      have hx : x ∈ S.pathTo z := S.prefixAt_le z k
      have hdx : S.depth x = k := S.depth_prefixAt z hkd.le
      have hxl : ¬ S.IsLeaf x := by
        intro hleaf
        have heq : z = x := hleaf z hx
        have := congrArg S.depth heq
        omega
      exact ⟨x, hx, by rw [depthCombVertex_nonleaf S x hxl, hdx]⟩
    · exact ⟨z, List.prefix_refl _, depthCombVertex_leaf S z hz⟩

section Labels

variable {D : Type u} [PartialOrder D] (hD : IsScottDomain D)
  (g : Comb.Vertex → ↥(CompactElements D))
  (hinj : ∀ n, Set.InjOn g (Comb.Vertex.finiteBranch n))
  (hmic : ∀ n, IsMinimallyInconsistent hD
    ((fun v => (g v : D)) '' Comb.Vertex.finiteBranch n))

def pullbackLabel : S.Node → ↥(CompactElements D) := fun x => g (depthCombVertex S x)

include hinj in
theorem pullbackLabel_injOn_path (hp : S.IsProper) (z : S.Node) (hz : S.IsLeaf z) :
    Set.InjOn (pullbackLabel S g) (S.pathTo z) := by
  intro x hx y hy heq
  apply depthCombVertex_injOn_path S z hx hy
  apply hinj (S.depth z - 1)
  · rw [← depthCombVertex_path_image S hp z hz]
    exact ⟨x, hx, rfl⟩
  · rw [← depthCombVertex_path_image S hp z hz]
    exact ⟨y, hy, rfl⟩
  · exact heq

include hinj in
theorem pullbackLabel_injOn_branch (hp : S.IsProper) (c : Set S.Node)
    (hc : S.IsBranch c) : Set.InjOn (pullbackLabel S g) c := by
  intro x hx y hy heq
  rcases hc.1.total hx hy with hxy | hyx
  · obtain ⟨z, hz, hyz⟩ := (S.isProper_iff.mp hp).2 y
    exact pullbackLabel_injOn_path S g hinj hp z hz (hxy.trans hyz) hyz heq
  · obtain ⟨z, hz, hxz⟩ := (S.isProper_iff.mp hp).2 x
    exact pullbackLabel_injOn_path S g hinj hp z hz hxz (hyx.trans hxz) heq

theorem pullbackLabel_image (hp : S.IsProper) (z : S.Node) (hz : S.IsLeaf z) :
    labelImage S (pullbackLabel S g) (S.pathTo z) =
      (fun v => (g v : D)) '' Comb.Vertex.finiteBranch (S.depth z - 1) := by
  change ((fun v => (g v : D)) ∘ depthCombVertex S) '' S.pathTo z = _
  rw [Set.image_comp, depthCombVertex_path_image S hp z hz]

def micTree (hp : S.IsProper) : MicTree D hD Index where
  tree := S
  proper := hp
  label := pullbackLabel S g
  isMicTree := by
    apply (isMicTree_iff hD S hp _).2
    constructor
    · exact pullbackLabel_injOn_branch S g hinj hp
    · rintro c ⟨z, hz, rfl⟩
      rw [pullbackLabel_image S g hp z hz]
      exact hmic (S.depth z - 1)

end Labels

end DIDomainClassification.CombMicPullback

