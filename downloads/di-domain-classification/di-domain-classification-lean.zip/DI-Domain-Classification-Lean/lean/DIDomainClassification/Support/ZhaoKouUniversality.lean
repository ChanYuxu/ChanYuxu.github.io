import DIDomainClassification.Support.ZhaoKouRetraction
import DIDomainClassification.Section02.EventRepresentation
import DIDomainClassification.Support.QualitativeCausalCoherence

/-!
The causal qualitative cover of a 2-coherent configuration domain has binary
conflicts. Its exact configuration/clique order isomorphism, the literal
compact-marker graph embedding and the actual stable split maps yield the
Zhao-Kou universality statement for arbitrary countably based dI-domains.
Countability of events is derived from the compact basis by the proved event
representation theorem; countability of all domain points is never assumed.
This uses the source marker polarity through a separately proved cover route.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ZhaoKouUniversality

open Preliminaries CoherenceDegree EventStructures FiniteCausalConflicts
open Section02 Section02.BinaryCliqueModels Section03.StableFunctionModels
open Section04.AdditionalSourceModels ZhaoKouCodes ZhaoKouRetraction

variable {A : Type u} [originalOrder : PartialOrder A]

def coverEvents (E : FinitaryPrimeEventStructure A) :
    @FinitaryPrimeEventStructure A (ForbiddenFiniteDomains.equalityOrder A) :=
  ForbiddenFiniteDomains.eventStructure (causalConflictFamily E) (CausalCoverSupport.admissible E)

def coverGraph (E : FinitaryPrimeEventStructure A) : SimpleGraph A :=
  @compatibilityGraph A (ForbiddenFiniteDomains.equalityOrder A) (coverEvents E)

def coverCliqueOrderIso (E : FinitaryPrimeEventStructure A)
    (hBinary : HasBinaryMinimalMembers (causalConflictFamily E)) :
    QualitativeCover E ≃o CliqueCarrier (coverGraph E) := by
  let H := causalConflictFamily E
  let hH := CausalCoverSupport.admissible E
  have hForward := @binaryForbiddenCliqueForward.{u} A
    (ForbiddenFiniteDomains.equalityOrder A) (coverEvents E) H
    (ForbiddenFiniteDomains.isQualitativePresentation H hH)
    (ForbiddenFiniteDomains.isForbiddenFamilyPresentation H hH) hBinary
  exact (ForbiddenFiniteDomains.configurationOrderIso H hH).symm.trans
    (@BinaryCliqueSupport.configurationCliqueOrderIso A
      (ForbiddenFiniteDomains.equalityOrder A) (coverEvents E) (coverGraph E) hForward.1)

theorem conflicts_binary (E : FinitaryPrimeEventStructure A)
    (hTwo : IsNCoherent (ConfigurationDomain.scottDomain E) 2 (by decide)) :
    HasBinaryMinimalMembers (causalConflictFamily E) := by
  intro H hH _hMin
  exact le_antisymm
    ((QualitativeConfigurationMIC.nCoherent_iff_conflict_bound E
      (ConfigurationDomain.scottDomain E) 2 (by decide)).mp hTwo H hH)
    (conflict_member_card_ge_two E hH)

theorem configuration_into_W [Countable A] (E : FinitaryPrimeEventStructure A)
    (hTwo : IsNCoherent (ConfigurationDomain.scottDomain E) 2 (by decide)) :
    HasStableRetraction (causalConfigurationCore E)
      (Core (universalTwoObject baseCertificate.{u})) := by
  let C := CausalCoverSupport.closure E
  let e := coverCliqueOrderIso E (conflicts_binary E hTwo)
  let hG : IsDIDomain (CliqueCarrier (coverGraph E)) :=
    OrderIsoTransport.isDIDomain_map e C.domain
  have hCover : HasStableRetraction (causalConfigurationCore E) (qualitativeCoverCore E C) :=
    ⟨StableHom.ofFunction (CausalCoverSupport.sectionMap E)
      (CausalCoverSupport.section_stable E C),
      StableHom.ofFunction (CausalCoverSupport.retractionMap E)
        (CausalCoverSupport.retraction_stable E C),
      CausalCoverSupport.leftInverse E⟩
  have hGraph : HasStableRetraction (qualitativeCoverCore E C)
      (CliqueStableMaps.core (coverGraph E) hG) :=
    ofOrderIso _ _ e
  exact trans (trans hCover hGraph) (graph_into_W (coverGraph E) hG)

theorem universality (D : CountablyBasedDIDomain.{u})
    (hTwo : IsNCoherent (Core D).isDIDomain.toIsScottDomain 2 (by decide)) :
    HasStableRetraction (Core D) (Core (universalTwoObject baseCertificate.{u})) := by
  obtain ⟨A, order, hRest⟩ := primeEventRepresentation (Core D)
    ⟨(Core D).isDIDomain, D.countableCompacts⟩
  letI : PartialOrder A := order
  obtain ⟨hA, E, ⟨e⟩⟩ := hRest
  letI : Countable A := hA
  let hC := ConfigurationDomain.scottDomain E
  have hDegreeD : coherenceDegree (Core D).isDIDomain.toIsScottDomain ≤
      (2 : Ordinal.{u+1}) :=
    (finite_degree_iff_nCoherent (Core D).isDIDomain.toIsScottDomain 2 (by decide)).mpr hTwo
  have hDegreeC : coherenceDegree hC ≤ coherenceDegree (Core D).isDIDomain.toIsScottDomain :=
    coherenceDegree_mono_of_scott_split hC (Core D).isDIDomain.toIsScottDomain
      (OrderIsoTransport.scottContinuous e.symm) (OrderIsoTransport.scottContinuous e)
      e.apply_symm_apply
  have hTwoC : IsNCoherent hC 2 (by decide) :=
    (finite_degree_iff_nCoherent hC 2 (by decide)).mp (hDegreeC.trans hDegreeD)
  exact trans (ofOrderIso (Core D) (causalConfigurationCore E) e)
    (configuration_into_W E hTwoC)

end DIDomainClassification.ZhaoKouUniversality
