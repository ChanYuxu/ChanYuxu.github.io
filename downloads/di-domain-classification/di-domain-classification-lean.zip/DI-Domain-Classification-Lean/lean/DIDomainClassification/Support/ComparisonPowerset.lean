import DIDomainClassification.Support.ComparisonProducts
import DIDomainClassification.Section02.TwoRetract

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonPowerset
open Preliminaries Section03.StableFunctionModels FiniteOrderDomains
open Section04 AdditionalSourceModels

def characteristic (A : NatPowersetCarrier.{u}) (n : ℕ) : TwoCarrier.{u} := by
  classical
  exact if n ∈ A.down then one else zero

def powersetOrderIso : NatPowersetCarrier.{u} ≃o (ℕ → TwoCarrier.{u}) where
  toFun := characteristic.{u}
  invFun f := ⟨{n | f n = one.{u}}⟩
  left_inv A := by
    classical
    apply ULift.ext
    ext n
    change (if n ∈ A.down then one.{u} else zero.{u}) = one ↔ n ∈ A.down
    by_cases hn : n ∈ A.down <;> simp [hn,FiniteOrderDomains.zero_ne_one.{u}]
  right_inv f := by
    classical
    funext n
    rcases eq_zero_or_one.{u} (f n) with h | h
    · simp [characteristic,h,FiniteOrderDomains.zero_ne_one.{u}]
    · simp [characteristic,h]
  map_rel_iff' := by
    classical
    intro A B
    change (∀ n, characteristic.{u} A n ≤ characteristic.{u} B n) ↔ A.down ⊆ B.down
    constructor
    · intro h n hn
      by_contra hnot
      have hp := h n
      simp only [characteristic,if_pos hn,if_neg hnot] at hp
      exact FiniteOrderDomains.zero_ne_one.{u}
        (le_antisymm (zero_le.{u} one.{u}) hp)
    · intro h n
      by_cases hn : n ∈ A.down
      · simp only [characteristic,if_pos hn,if_pos (h hn)]
        exact le_rfl
      · simpa only [characteristic,if_neg hn] using
          zero_le.{u} (characteristic.{u} B n)

theorem powerset_comparison : ComparisonPowersetStatement.{u} := by
  intro E hE
  letI : Nontrivial (Core E) := hE
  let T : CountablyBasedDIDomain.{u} := twoObject
  obtain ⟨hFlat,hPower,hTwo,S,R,_hSv,_hRv,hleft⟩ :=
    Section04.countablePowersRetraction T
  let N := flatObject hFlat
  let P := cbObject (ℕ → Core T) hPower
  let hSet : IsCountablyBasedDIDomain NatPowersetCarrier.{u} :=
    (OrderIsoTransport.isCountablyBasedDIDomain_iff powersetOrderIso).mpr hPower
  let A := natPowersetObject hSet
  have hAP : HasStableRetraction (Core A) (Core P) :=
    ComparisonOperations.iso_split _ _ powersetOrderIso
  have hPN : HasStableRetraction (Core P) (Core (exponential N T)) := ⟨S,R,hleft⟩
  have hTE : HasStableRetraction (Core T) (Core E) :=
    (Section02.twoRetract (Core E) (exists_pair_ne (Core E))).2
  refine ⟨hSet,N,hTwo,ComparisonOperations.split_trans hAP ?_⟩
  exact ComparisonOperations.split_trans hPN
    (ComparisonOperations.exponential_split N T E hTE)

end DIDomainClassification.ComparisonPowerset
