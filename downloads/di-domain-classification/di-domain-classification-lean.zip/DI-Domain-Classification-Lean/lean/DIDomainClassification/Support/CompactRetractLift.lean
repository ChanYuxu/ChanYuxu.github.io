import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.MicTrees

/-!
# Generic compact lifting through a Scott-continuous split

Staged source-independent supporting mathematics only. No BPS source wrapper,
source interface, tree-rank bound or coherence-degree inequality is asserted.
The chosen lifts, not arbitrary continuous images of compact elements, are
compact. The split has no strictness or embedding-projection inequality.
-/

set_option autoImplicit false

universe u v w

namespace DIDomainClassification.CompactRetractLift

open OrderCore CoherenceDegree Trees
open Preliminaries (CompactElements IsScottDomain)

variable {D : Type u} {E : Type v} [PartialOrder D] [PartialOrder E]

/-- A compact source point has a compact preimage below its section image.
Only the ambient algebraicity and retraction continuity are needed here. -/
theorem exists_compact_lift (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s)
    {p : D} (hp : OrderCore.Compact p) :
    ∃ q : E, OrderCore.Compact q ∧ q ≤ s p ∧ r q = p := by
  have hdir := (hE.2 (s p)).1
  have hsup := scottContinuous_isSup hr hdir (hE.2 (s p)).2
  have hpsup : p ≤ r (s p) := by rw [hleft p]
  obtain ⟨_, ⟨q, hq, rfl⟩, hpq⟩ := hp (hdir.image hr.monotone) hsup hpsup
  refine ⟨q, hq.1, hq.2, le_antisymm ?_ hpq⟩
  simpa only [hleft p] using hr.monotone hq.2

/-- The choice is made on the actual accepted compact-element subtypes. -/
noncomputable def compactLift (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s)
    (p : ↥(CompactElements D)) : ↥(CompactElements E) :=
  ⟨Classical.choose (exists_compact_lift hE hr hleft p.property),
    (Classical.choose_spec (exists_compact_lift hE hr hleft p.property)).1⟩

theorem compactLift_le (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s)
    (p : ↥(CompactElements D)) : (compactLift hE hr hleft p : E) ≤ s p :=
  (Classical.choose_spec (exists_compact_lift hE hr hleft p.property)).2.1

@[simp] theorem retract_compactLift (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s)
    (p : ↥(CompactElements D)) : r (compactLift hE hr hleft p : E) = (p : D) :=
  (Classical.choose_spec (exists_compact_lift hE hr hleft p.property)).2.2

theorem compactLift_injective (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s) :
    Function.Injective (compactLift hE hr hleft) := by
  intro p q hpq
  apply Subtype.ext
  have h := congrArg (fun z : ↥(CompactElements E) => r (z : E)) hpq
  simpa only [retract_compactLift] using h

/-- A technical total extension of the compact choice, equal to the section
on noncompact inputs. It need not be continuous or monotone. -/
noncomputable def liftElement (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s) (p : D) : E := by
  classical
  exact if hp : OrderCore.Compact p then
    (compactLift hE hr hleft ⟨p, hp⟩ : E) else s p

theorem liftElement_of_compact (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s)
    {p : D} (hp : OrderCore.Compact p) :
    liftElement hE hr hleft p = (compactLift hE hr hleft ⟨p, hp⟩ : E) := by
  classical
  simp only [liftElement, dif_pos hp]

@[simp] theorem retract_liftElement (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s) (p : D) :
    r (liftElement hE hr hleft p) = p := by
  classical
  by_cases hp : OrderCore.Compact p
  · rw [liftElement_of_compact hE hr hleft hp]
    exact retract_compactLift hE hr hleft ⟨p, hp⟩
  · simp only [liftElement, dif_neg hp, hleft p]

theorem liftElement_le (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s) (p : D) :
    liftElement hE hr hleft p ≤ s p := by
  classical
  by_cases hp : OrderCore.Compact p
  · rw [liftElement_of_compact hE hr hleft hp]
    exact compactLift_le hE hr hleft ⟨p, hp⟩
  · simp only [liftElement, dif_neg hp, le_rfl]

theorem liftElement_compact (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s)
    {p : D} (hp : OrderCore.Compact p) : OrderCore.Compact (liftElement hE hr hleft p) := by
  rw [liftElement_of_compact hE hr hleft hp]
  exact (compactLift hE hr hleft ⟨p, hp⟩).property

theorem liftElement_injective (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s) :
    Function.Injective (liftElement hE hr hleft) := by
  intro p q hpq
  have h := congrArg r hpq
  simpa only [retract_liftElement] using h

theorem liftElement_image_ncard (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s) (M : Set D) :
    (liftElement hE hr hleft '' M).ncard = M.ncard :=
  (liftElement_injective hE hr hleft).injOn.ncard_image

theorem liftElement_image_compact (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s) {M : Set D}
    (hcompact : M ⊆ CompactElements D) :
    liftElement hE hr hleft '' M ⊆ CompactElements E := by
  rintro _ ⟨p, hp, rfl⟩
  exact liftElement_compact hE hr hleft (hcompact hp)

/-- Boundedness is preserved and reflected for every subset, without any
cardinality, compactness, directedness, or nonemptiness restriction on it. -/
theorem bddAbove_liftElement_image_iff (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (X : Set D) :
    BddAbove (liftElement hE hr hleft '' X) ↔ BddAbove X := by
  constructor
  · rintro ⟨b, hb⟩
    refine ⟨r b, ?_⟩
    intro p hp
    have h := hr.monotone (hb ⟨p, hp, rfl⟩)
    simpa only [retract_liftElement] using h
  · rintro ⟨b, hb⟩
    refine ⟨s b, ?_⟩
    rintro _ ⟨p, hp, rfl⟩
    exact (liftElement_le hE hr hleft p).trans (hs.monotone (hb hp))

/-- Generic minimal-unbounded-set transport under boundedness equivalence.
No Scott-domain or compactness hypothesis is built into this set-theoretic law. -/
theorem finite_minimally_unbounded_image {f : D → E}
    (hbounded : ∀ X : Set D, BddAbove (f '' X) ↔ BddAbove X)
    {M : Set D}
    (hM : M.Finite ∧ ¬ BddAbove M ∧ ∀ N : Set D, N ⊂ M → BddAbove N) :
    (f '' M).Finite ∧ ¬ BddAbove (f '' M) ∧
      ∀ N : Set E, N ⊂ f '' M → BddAbove N := by
  refine ⟨hM.1.image f, fun h => hM.2.1 ((hbounded M).mp h), ?_⟩
  intro N hN
  let P : Set D := M ∩ f ⁻¹' N
  have hP : P ⊂ M := by
    refine ⟨fun _ hp => hp.1, ?_⟩
    intro hMP
    apply hN.2
    rintro _ ⟨p, hp, rfl⟩
    exact (hMP hp).2
  have hPN : f '' P = N := by
    ext y
    constructor
    · rintro ⟨p, hp, rfl⟩
      exact hp.2
    · intro hy
      obtain ⟨p, hp, rfl⟩ := hN.1 hy
      exact ⟨p, ⟨hp, hy⟩, rfl⟩
  have h := (hbounded P).mpr (hM.2.2 P hP)
  simpa only [hPN] using h

/-- Specialization to the actual accepted MIC predicate. Scott-domain inputs
are needed only because that source predicate is scoped to Scott domains. -/
theorem isMinimallyInconsistent_lift (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (hDScott : IsScottDomain D)
    (hEScott : IsScottDomain E) {M : Set D}
    (hM : IsMinimallyInconsistent hDScott M) :
    IsMinimallyInconsistent hEScott (liftElement hE hr hleft '' M) :=
  finite_minimally_unbounded_image
    (bddAbove_liftElement_image_iff hE hs hr hleft) hM

/-- A finite MIC subset of the actual compact points lifts to a MIC subset
of ambient compact points with exactly the same finite cardinality. -/
theorem compact_mic_lift (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (hDScott : IsScottDomain D)
    (hEScott : IsScottDomain E) {M : Set D}
    (hM : IsMinimallyInconsistent hDScott M) (hcompact : M ⊆ CompactElements D) :
    IsMinimallyInconsistent hEScott (liftElement hE hr hleft '' M) ∧
      (liftElement hE hr hleft '' M ⊆ CompactElements E) ∧
      (liftElement hE hr hleft '' M).ncard = M.ncard :=
  ⟨isMinimallyInconsistent_lift hE hs hr hleft hDScott hEScott hM,
    liftElement_image_compact hE hr hleft hcompact,
    liftElement_image_ncard hE hr hleft M⟩

/-- On any branch set the compact-subtype label map has exactly the chosen
ambient lift image, not an arbitrary isomorphic replacement. -/
theorem labelImage_lift (hE : IsAlgebraicDcpo E) {s : D → E} {r : E → D}
    (hr : ScottContinuous r) (hleft : Function.LeftInverse r s)
    {Index : Type w} (T : RootedPrefixTree Index)
    (label : T.Node → ↥(CompactElements D)) (c : Set T.Node) :
    labelImage T (fun x => compactLift hE hr hleft (label x)) c =
      liftElement hE hr hleft '' labelImage T label c := by
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    exact ⟨(label x : D), ⟨x, hx, rfl⟩,
      liftElement_of_compact hE hr hleft (label x).property⟩
  · rintro ⟨_, ⟨x, hx, rfl⟩, rfl⟩
    exact ⟨x, hx, (liftElement_of_compact hE hr hleft (label x).property).symm⟩

/-- The actual compact labels transfer the MIC-tree condition on exactly T.
No rank, tree completion, new branching assumption, or degree theorem is used. -/
theorem isMicTree_lift (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (hDScott : IsScottDomain D)
    (hEScott : IsScottDomain E) {Index : Type w} {T : RootedPrefixTree Index}
    {proper : T.IsProper} {label : T.Node → ↥(CompactElements D)}
    (hT : IsMicTree hDScott T proper label) :
    IsMicTree hEScott T proper (fun x => compactLift hE hr hleft (label x)) := by
  apply (isMicTree_iff hEScott T proper _).mpr
  constructor
  · intro c hc x hx y hy hxy
    exact hT.branchInjective hc hx hy (compactLift_injective hE hr hleft hxy)
  · intro c hc
    rw [labelImage_lift hE hr hleft]
    exact isMinimallyInconsistent_lift hE hs hr hleft hDScott hEScott
      (hT.finiteBranch_mic hc)

/-- A relabelling of the very same source tree, with compact ambient labels. -/
noncomputable def liftMicTree (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (hDScott : IsScottDomain D)
    (hEScott : IsScottDomain E) {Index : Type w} (M : MicTree D hDScott Index) :
    MicTree E hEScott Index where
  tree := M.tree
  proper := M.proper
  label := fun x => compactLift hE hr hleft (M.label x)
  isMicTree := isMicTree_lift hE hs hr hleft hDScott hEScott M.isMicTree

@[simp] theorem liftMicTree_tree (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (hDScott : IsScottDomain D)
    (hEScott : IsScottDomain E) {Index : Type w} (M : MicTree D hDScott Index) :
    (liftMicTree hE hs hr hleft hDScott hEScott M).tree = M.tree := rfl

theorem liftMicTree_branch_iff (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (hDScott : IsScottDomain D)
    (hEScott : IsScottDomain E) {Index : Type w} (M : MicTree D hDScott Index)
    (c : Set M.tree.Node) :
    (liftMicTree hE hs hr hleft hDScott hEScott M).tree.IsBranch c ↔
      M.tree.IsBranch c := Iff.rfl

theorem liftMicTree_wellFounded_iff (hE : IsAlgebraicDcpo E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) (hDScott : IsScottDomain D)
    (hEScott : IsScottDomain E) {Index : Type w} (M : MicTree D hDScott Index) :
    (liftMicTree hE hs hr hleft hDScott hEScott M).tree.IsWellFounded ↔
      M.tree.IsWellFounded := Iff.rfl

end DIDomainClassification.CompactRetractLift
