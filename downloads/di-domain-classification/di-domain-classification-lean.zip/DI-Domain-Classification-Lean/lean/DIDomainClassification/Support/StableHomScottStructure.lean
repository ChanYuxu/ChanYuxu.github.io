import DIDomainClassification.Support.StableHomTraceOrder

/-! Arbitrary stable-bounded suprema and full intrinsic dI closure.
The third element of compatible-join distributivity is unrestricted. -/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.StableExponentialClosure

open Preliminaries EventStructures MinimalInputTraces FiniteTraceApproximations

variable {D : Type u} {A : Type v} [PartialOrder D] [PartialOrder A]
  {E : FinitaryPrimeEventStructure A}

def bottomHom (hD : IsDIDomain D) (E : FinitaryPrimeEventStructure A) : Hom hD E :=
  StableHom.ofFunction (fun _ => ConfigurationDomain.empty E)
    ⟨ScottContinuous.const _, by intro x y hxy; exact (inf_eq_left.mpr le_rfl).symm⟩

theorem bottomHom_le (hD : IsDIDomain D) (g : Hom hD E) : bottomHom hD E ≤ g := by
  intro x y hxy
  exact (inf_eq_left.mpr (ConfigurationDomain.empty_le E (g x))).symm

def supValues (hD : IsDIDomain D) (B : Set (Hom hD E)) (x : D) : Set A :=
  ⋃ g ∈ B, (g x).val

theorem supValues_subset (hD : IsDIDomain D) (B : Set (Hom hD E)) (U : Hom hD E)
    (hBU : ∀ g ∈ B, g ≤ U) (x : D) : supValues hD B x ⊆ (U x).val := by
  intro a ha
  obtain ⟨g, ha⟩ := Set.mem_iUnion.mp ha
  obtain ⟨hg, ha⟩ := Set.mem_iUnion.mp ha
  exact (Configuration.le_iff_subset _ _).mp (hom_le_pointwise hD (hBU g hg) x) ha

theorem supValues_isConfiguration (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) (x : D) :
    IsConfiguration E (supValues hD B x) := by
  constructor
  · intro a b hab hb
    obtain ⟨g, hb⟩ := Set.mem_iUnion.mp hb
    obtain ⟨hg, hb⟩ := Set.mem_iUnion.mp hb
    exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, (g x).property.1 hab hb⟩⟩
  · intro F hF hsub
    exact (U x).property.2 F hF (hsub.trans (supValues_subset hD B U hBU x))

def supConfiguration (hD : IsDIDomain D) (B : Set (Hom hD E)) (U : Hom hD E)
    (hBU : ∀ g ∈ B, g ≤ U) (x : D) : Configuration E :=
  ⟨supValues hD B x, supValues_isConfiguration hD B U hBU x⟩

theorem member_le_supConfiguration (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) {g : Hom hD E} (hg : g ∈ B) (x : D) :
    g x ≤ supConfiguration hD B U hBU x := by
  apply (Configuration.le_iff_subset _ _).mpr
  intro a ha
  exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, ha⟩⟩

theorem supConfiguration_monotone (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) :
    Monotone (supConfiguration hD B U hBU) := by
  intro x y hxy
  apply (Configuration.le_iff_subset _ _).mpr
  intro a ha
  obtain ⟨g, ha⟩ := Set.mem_iUnion.mp ha
  obtain ⟨hg, ha⟩ := Set.mem_iUnion.mp ha
  exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg,
    (Configuration.le_iff_subset _ _).mp ((StableHom.isStable g).1.monotone hxy) ha⟩⟩

theorem supConfiguration_scottContinuous (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) :
    ScottContinuous (supConfiguration hD B U hBU) := by
  intro C hne hdir s hs
  constructor
  · rintro _ ⟨x, hx, rfl⟩
    exact supConfiguration_monotone hD B U hBU (hs.1 hx)
  · intro Z hZ
    apply (Configuration.le_iff_subset _ _).mpr
    intro a ha
    obtain ⟨g, ha⟩ := Set.mem_iUnion.mp ha
    obtain ⟨hg, ha⟩ := Set.mem_iUnion.mp ha
    have hgZ : g s ≤ Z := ((StableHom.isStable g).1 hne hdir hs).2 (by
      rintro _ ⟨x, hx, rfl⟩
      exact (member_le_supConfiguration hD B U hBU hg x).trans (hZ ⟨x, hx, rfl⟩))
    exact (Configuration.le_iff_subset _ _).mp hgZ ha

theorem supConfiguration_meet_val (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) (x y : D) (hxy : Compatible x y) :
    (supConfiguration hD B U hBU (hD.toIsScottDomain.inf x y)).val =
      (supConfiguration hD B U hBU x).val ∩ (supConfiguration hD B U hBU y).val := by
  ext a
  constructor
  · intro ha
    exact ⟨(Configuration.le_iff_subset _ _).mp
      (supConfiguration_monotone hD B U hBU (hD.toIsScottDomain.inf_le_left x y)) ha,
      (Configuration.le_iff_subset _ _).mp
      (supConfiguration_monotone hD B U hBU (hD.toIsScottDomain.inf_le_right x y)) ha⟩
  · rintro ⟨hax, hay⟩
    obtain ⟨g, hax⟩ := Set.mem_iUnion.mp hax
    obtain ⟨hg, hax⟩ := Set.mem_iUnion.mp hax
    have hUinf : a ∈ (U (hD.toIsScottDomain.inf x y)).val := by
      rw [compatible_meet_val hD.toIsScottDomain (hom_preserves_meets hD U) x y hxy]
      exact ⟨(Configuration.le_iff_subset _ _).mp (hom_le_pointwise hD (hBU g hg) x) hax,
        supValues_subset hD B U hBU y hay⟩
    have hginf : a ∈ (g (hD.toIsScottDomain.inf x y)).val := by
      rw [hom_le_val_eq hD (hBU g hg) _ x (hD.toIsScottDomain.inf_le_left x y)]
      exact ⟨hax, hUinf⟩
    exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, hginf⟩⟩

def boundedSupHom (hD : IsDIDomain D) (B : Set (Hom hD E)) (U : Hom hD E)
    (hBU : ∀ g ∈ B, g ≤ U) : Hom hD E :=
  StableHom.ofFunction (supConfiguration hD B U hBU)
    ⟨supConfiguration_scottContinuous hD B U hBU, by
      intro x y hxy
      apply Subtype.ext
      rw [source_inf_eq, target_inf_val]
      exact supConfiguration_meet_val hD B U hBU x y hxy⟩

/-- The upper V here can be different from the construction's upper U. -/
theorem supConfiguration_le_equation (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) (V : Hom hD E)
    (hBV : ∀ g ∈ B, g ≤ V) (x y : D) (hxy : x ≤ y) :
    (supConfiguration hD B U hBU x).val =
      (supConfiguration hD B U hBU y).val ∩ (V x).val := by
  ext a
  constructor
  · intro ha
    exact ⟨(Configuration.le_iff_subset _ _).mp (supConfiguration_monotone hD B U hBU hxy) ha,
      supValues_subset hD B V hBV x ha⟩
  · rintro ⟨hay, haV⟩
    obtain ⟨g, hay⟩ := Set.mem_iUnion.mp hay
    obtain ⟨hg, hay⟩ := Set.mem_iUnion.mp hay
    have hax : a ∈ (g x).val := by
      rw [hom_le_val_eq hD (hBV g hg) x y hxy]
      exact ⟨hay, haV⟩
    exact Set.mem_iUnion.mpr ⟨g, Set.mem_iUnion.mpr ⟨hg, hax⟩⟩

theorem boundedSupHom_le (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) (V : Hom hD E)
    (hBV : ∀ g ∈ B, g ≤ V) : boundedSupHom hD B U hBU ≤ V := by
  intro x y hxy
  apply Subtype.ext
  rw [target_inf_val]
  exact supConfiguration_le_equation hD B U hBU V hBV x y hxy

theorem member_le_boundedSupHom (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) {g : Hom hD E} (hg : g ∈ B) :
    g ≤ boundedSupHom hD B U hBU :=
  hom_le_of_pointwise_of_common_upper hD (hBU g hg)
    (boundedSupHom_le hD B U hBU U hBU)
    (member_le_supConfiguration hD B U hBU hg)

/-- All cardinalities of B, including empty; boundedness is in the STABLE order. -/
theorem boundedSupHom_isLUB (hD : IsDIDomain D) (B : Set (Hom hD E))
    (U : Hom hD E) (hBU : ∀ g ∈ B, g ≤ U) :
    IsLUB B (boundedSupHom hD B U hBU) := by
  constructor
  · intro g hg
    exact member_le_boundedSupHom hD B U hBU hg
  · intro V hV
    exact boundedSupHom_le hD B U hBU V (fun g hg => hV hg)

theorem hom_isScottDomain (hD : IsDIDomain D) : IsScottDomain (Hom hD E) where
  algebraic := hom_isAlgebraicDcpo hD
  hasLeast := ⟨bottomHom hD E, bottomHom_le hD⟩
  boundedSuprema := by
    intro B hB
    obtain ⟨U, hU⟩ := hB
    exact ⟨boundedSupHom hD B U (fun g hg => hU hg),
      boundedSupHom_isLUB hD B U (fun g hg => hU hg)⟩

theorem pair_bounds {P : Type*} [PartialOrder P] {g h U : P} (hg : g ≤ U) (hh : h ≤ U) :
    ∀ p ∈ ({g, h} : Set P), p ≤ U := by
  intro p hp
  rcases Set.mem_insert_iff.mp hp with rfl | hp
  · exact hg
  · simpa only [Set.mem_singleton_iff.mp hp] using hh

theorem pair_lower_bounds {P : Type*} [PartialOrder P] {g h U : P}
    (hg : U ≤ g) (hh : U ≤ h) : ∀ p ∈ ({g, h} : Set P), U ≤ p := by
  intro p hp
  rcases Set.mem_insert_iff.mp hp with rfl | hp
  · exact hg
  · simpa only [Set.mem_singleton_iff.mp hp] using hh

theorem boundedSupHom_pair_val (hD : IsDIDomain D) (g h U : Hom hD E)
    (hgU : g ≤ U) (hhU : h ≤ U) (x : D) :
    (boundedSupHom hD {g, h} U (pair_bounds hgU hhU) x).val =
      (g x).val ∪ (h x).val := by
  change (⋃ p ∈ ({g, h} : Set (Hom hD E)), (p x).val) = _
  simp

theorem compatible_join_val (hD : IsDIDomain D) (g h joined : Hom hD E)
    (hgh : Compatible g h) (hJoined : IsLUB ({g, h} : Set (Hom hD E)) joined) (x : D) :
    (joined x).val = (g x).val ∪ (h x).val := by
  obtain ⟨U, hgU, hhU⟩ := hgh
  have heq : joined = boundedSupHom hD {g, h} U (pair_bounds hgU hhU) :=
    hJoined.unique (boundedSupHom_isLUB hD {g, h} U (pair_bounds hgU hhU))
  rw [heq]
  exact boundedSupHom_pair_val hD g h U hgU hhU x

theorem compatible_glb_val (hD : IsDIDomain D) (g h meet : Hom hD E)
    (hgh : Compatible g h) (hMeet : IsGLB ({g, h} : Set (Hom hD E)) meet) (x : D) :
    (meet x).val = (g x).val ∩ (h x).val := by
  have heq : meet = StableHomPointwiseSupport.homPointwiseInf g h :=
    hMeet.unique (StableHomPointwiseSupport.homPointwiseInf_isGLB g h hgh)
  calc
    (meet x).val = (StableHomPointwiseSupport.homPointwiseInf g h x).val :=
      congrArg (fun m : Hom hD E => (m x).val) heq
    _ = (g x ⊓ h x).val := congrArg (fun X : configurationObject E => X.val)
      (StableHomPointwiseSupport.homPointwiseInf_apply g h x)
    _ = (g x).val ∩ (h x).val := target_inf_val _ _

theorem isLUB_pair_of_union_values (hD : IsDIDomain D) (g h U q : Hom hD E)
    (hgU : g ≤ U) (hhU : h ≤ U)
    (hq : ∀ x : D, (q x).val = (g x).val ∪ (h x).val) :
    IsLUB ({g, h} : Set (Hom hD E)) q := by
  have heq : q = boundedSupHom hD {g, h} U (pair_bounds hgU hhU) :=
    StableHom.ext (fun x => Subtype.ext
      ((hq x).trans (boundedSupHom_pair_val hD g h U hgU hhU x).symm))
  rw [heq]
  exact boundedSupHom_isLUB hD {g, h} U (pair_bounds hgU hhU)

/-- Pure-order reduction: if g<=q, then glb(g,z)=glb(g,glb(q,z)). -/
theorem isGLB_pair_replace_right {P : Type*} [PartialOrder P] {g q z m l : P}
    (hgq : g ≤ q) (hm : IsGLB ({q, z} : Set P) m)
    (hl : IsGLB ({g, z} : Set P) l) : IsGLB ({g, m} : Set P) l := by
  have hlg : l ≤ g := hl.1 (by simp)
  have hlz : l ≤ z := hl.1 (by simp)
  have hlm : l ≤ m := hm.2 (pair_lower_bounds (hlg.trans hgq) hlz)
  constructor
  · exact pair_lower_bounds hlg hlm
  · intro p hp
    exact hl.2 (pair_lower_bounds (hp (by simp)) ((hp (by simp)).trans (hm.1 (by simp))))

/-- Source distributivity with compatible g,h and a completely arbitrary third z. -/
theorem hom_compatibleJoinDistributive (hD : IsDIDomain D) :
    CompatibleJoinDistributive (Hom hD E) := by
  intro g h z joined meet left right hgh hJoined hMeet hLeft hRight
  have hgj : g ≤ joined := hJoined.1 (by simp)
  have hhj : h ≤ joined := hJoined.1 (by simp)
  have hmj : meet ≤ joined := hMeet.1 (by simp)
  have hLeft' := isGLB_pair_replace_right hgj hMeet hLeft
  have hRight' := isGLB_pair_replace_right hhj hMeet hRight
  have hlm : left ≤ meet := hLeft'.1 (by simp)
  have hrm : right ≤ meet := hRight'.1 (by simp)
  apply isLUB_pair_of_union_values hD left right meet meet hlm hrm
  intro x
  rw [compatible_glb_val hD g meet left ⟨joined, hgj, hmj⟩ hLeft' x,
    compatible_glb_val hD h meet right ⟨joined, hhj, hmj⟩ hRight' x,
    ← Set.union_inter_distrib_right, ← compatible_join_val hD g h joined hgh hJoined x]
  exact (Set.inter_eq_right.mpr
    ((Configuration.le_iff_subset _ _).mp (hom_le_pointwise hD hmj x))).symm

theorem hom_isDIDomain (hD : IsDIDomain D) : IsDIDomain (Hom hD E) where
  toIsScottDomain := hom_isScottDomain hD
  distributive := hom_compatibleJoinDistributive hD
  finitePrincipalIdeals := finite_entire_compact_ideal hD

theorem hom_isCountablyBasedDIDomain (hD : IsDIDomain D)
    (hK : (CompactElements D).Countable) [Countable A] :
    IsCountablyBasedDIDomain (Hom hD E) :=
  ⟨hom_isDIDomain hD, hom_compactElements_countable hD hK⟩

end DIDomainClassification.StableExponentialClosure
