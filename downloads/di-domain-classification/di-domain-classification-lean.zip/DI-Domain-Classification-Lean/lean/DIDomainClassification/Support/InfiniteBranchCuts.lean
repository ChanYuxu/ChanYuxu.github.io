import DIDomainClassification.Section02.Trees

/-! Actual finite off-spine cuts selected from properness along an infinite
branch. Every selected side set is nonempty and finite, and the displayed
union is an ENTIRE finite complete branch, not an assumed block axiom.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TreeDomainDegree

open Trees

variable {Index : Type u} (T : RootedPrefixTree Index) (b : T.InfiniteBranch)

theorem infinite_node_not_leaf (n : ℕ) : ¬ T.IsLeaf (b.node n) := by
  intro hleaf
  have hEq := hleaf (b.node (n + 1)) (b.child n).1
  have hNat : n + 1 = n := b.injective T hEq
  omega

theorem leaf_not_on_spine (leaf : T.Node) (hleaf : T.IsLeaf leaf) :
    leaf ∉ Set.range b.node := by
  rintro ⟨n, hn⟩
  apply infinite_node_not_leaf T b n
  simpa only [hn] using hleaf

def sideSet (leaf : T.Node) : Set T.Node := T.pathTo leaf \ Set.range b.node

theorem sideSet_finite (leaf : T.Node) : (sideSet T b leaf).Finite :=
  (T.pathTo_finite leaf).diff

theorem sideSet_nonempty (leaf : T.Node) (hleaf : T.IsLeaf leaf) :
    (sideSet T b leaf).Nonempty :=
  ⟨leaf, List.prefix_refl _, leaf_not_on_spine T b leaf hleaf⟩

theorem sideSet_disjoint_spine (leaf : T.Node) :
    Disjoint (sideSet T b leaf) (Set.range b.node) :=
  Set.disjoint_left.mpr (fun _ hx hy => hx.2 hy)

theorem exists_cut_after (hp : T.IsProper) (n : ℕ) :
    ∃ (i : ℕ) (leaf : T.Node), n < i ∧ T.IsLeaf leaf ∧
      ∀ k : ℕ, (b.node k).val <+: leaf.val ↔ k < i := by
  classical
  obtain ⟨leaf, hleaf, hnleaf⟩ := ((T.isProper_iff).1 hp).2 (b.node n)
  have hex : ∃ k : ℕ, ¬ (b.node k).val <+: leaf.val := by
    refine ⟨T.depth leaf + 1, ?_⟩
    intro h
    have hdepth := T.depth_mono h
    rw [b.depth_eq T (T.depth leaf + 1)] at hdepth
    omega
  let i := Nat.find hex
  have hiNot : ¬ (b.node i).val <+: leaf.val := Nat.find_spec hex
  have hiff (k : ℕ) : (b.node k).val <+: leaf.val ↔ k < i := by
    constructor
    · intro hk
      by_contra hki
      have hik : i ≤ k := Nat.le_of_not_gt hki
      exact hiNot ((b.monotone T hik).trans hk)
    · intro hk
      by_contra hnot
      have hle : i ≤ k := Nat.find_min' hex hnot
      exact Nat.not_lt_of_ge hle hk
  exact ⟨i, leaf, (hiff n).1 hnleaf, hleaf, hiff⟩

def cutStop (hp : T.IsProper) (n : ℕ) : ℕ := Classical.choose (exists_cut_after T b hp n)

def cutLeaf (hp : T.IsProper) (n : ℕ) : T.Node :=
  Classical.choose (Classical.choose_spec (exists_cut_after T b hp n))

theorem cutStop_gt (hp : T.IsProper) (n : ℕ) : n < cutStop T b hp n :=
  (Classical.choose_spec (Classical.choose_spec (exists_cut_after T b hp n))).1

theorem cutLeaf_isLeaf (hp : T.IsProper) (n : ℕ) : T.IsLeaf (cutLeaf T b hp n) :=
  (Classical.choose_spec (Classical.choose_spec (exists_cut_after T b hp n))).2.1

theorem cut_prefix_iff (hp : T.IsProper) (n k : ℕ) :
    (b.node k).val <+: (cutLeaf T b hp n).val ↔ k < cutStop T b hp n :=
  (Classical.choose_spec (Classical.choose_spec (exists_cut_after T b hp n))).2.2 k

theorem path_split_at_cut (hp : T.IsProper) (n : ℕ) :
    T.pathTo (cutLeaf T b hp n) =
      b.node '' Set.Iio (cutStop T b hp n) ∪ sideSet T b (cutLeaf T b hp n) := by
  classical
  ext x
  constructor
  · intro hx
    by_cases hxSpine : x ∈ Set.range b.node
    · obtain ⟨k, rfl⟩ := hxSpine
      exact Or.inl ⟨k, (cut_prefix_iff T b hp n k).1 hx, rfl⟩
    · exact Or.inr ⟨hx, hxSpine⟩
  · rintro (⟨k, hk, rfl⟩ | hx)
    · exact (cut_prefix_iff T b hp n k).2 hk
    · exact hx.1

def cutIndex (hp : T.IsProper) : ℕ → ℕ
  | 0 => 0
  | n + 1 => cutStop T b hp (cutIndex hp n)

theorem cutIndex_zero (hp : T.IsProper) : cutIndex T b hp 0 = 0 := rfl

theorem cutIndex_succ (hp : T.IsProper) (n : ℕ) :
    cutIndex T b hp (n + 1) = cutStop T b hp (cutIndex T b hp n) := rfl

theorem cutIndex_strictMono (hp : T.IsProper) : StrictMono (cutIndex T b hp) :=
  strictMono_nat_of_lt_succ (fun n => cutStop_gt T b hp (cutIndex T b hp n))

def spineBlock (hp : T.IsProper) (n : ℕ) : Set T.Node :=
  b.node '' Set.Ico (cutIndex T b hp n) (cutIndex T b hp (n + 1))

theorem spineBlock_finite (hp : T.IsProper) (n : ℕ) : (spineBlock T b hp n).Finite := by
  apply Set.Finite.image
  exact (Set.finite_le_nat (cutIndex T b hp (n + 1))).subset (fun _ hk => Nat.le_of_lt hk.2)

theorem spineBlock_nonempty (hp : T.IsProper) (n : ℕ) : (spineBlock T b hp n).Nonempty :=
  ⟨b.node (cutIndex T b hp n), ⟨cutIndex T b hp n,
    ⟨le_rfl, cutStop_gt T b hp (cutIndex T b hp n)⟩, rfl⟩⟩

theorem spineBlock_subset_spine (hp : T.IsProper) (n : ℕ) :
    spineBlock T b hp n ⊆ Set.range b.node := by
  rintro _ ⟨k, _hk, rfl⟩
  exact ⟨k, rfl⟩

theorem spineBlock_disjoint (hp : T.IsProper) {n m : ℕ} (hnm : n ≠ m) :
    Disjoint (spineBlock T b hp n) (spineBlock T b hp m) := by
  apply Set.disjoint_left.mpr
  rintro x ⟨i, hi, rfl⟩ ⟨j, hj, heq⟩
  have hji : j = i := b.injective T heq
  subst j
  rcases lt_or_gt_of_ne hnm with hnm | hmn
  · have hIndex : cutIndex T b hp (n + 1) ≤ cutIndex T b hp m :=
      (cutIndex_strictMono T b hp).monotone (Nat.succ_le_of_lt hnm)
    have hin := hi.2
    have him := hj.1
    omega
  · have hIndex : cutIndex T b hp (m + 1) ≤ cutIndex T b hp n :=
      (cutIndex_strictMono T b hp).monotone (Nat.succ_le_of_lt hmn)
    have him := hj.2
    have hin := hi.1
    omega

theorem index_interval_cover (hp : T.IsProper) (n k : ℕ) :
    k < cutIndex T b hp (n + 1) ↔
      ∃ j ≤ n, cutIndex T b hp j ≤ k ∧ k < cutIndex T b hp (j + 1) := by
  have hCover : ∀ n k : ℕ, k < cutIndex T b hp (n + 1) →
      ∃ j ≤ n, cutIndex T b hp j ≤ k ∧ k < cutIndex T b hp (j + 1) := by
    intro n
    induction n with
    | zero =>
        intro k hk
        exact ⟨0, le_rfl, Nat.zero_le _, hk⟩
    | succ n ih =>
        intro k hk
        by_cases hOld : k < cutIndex T b hp (n + 1)
        · obtain ⟨j, hj, hjk, hkj⟩ := ih k hOld
          exact ⟨j, hj.trans (Nat.le_succ _), hjk, hkj⟩
        · exact ⟨n + 1, le_rfl, Nat.le_of_not_gt hOld, hk⟩
  constructor
  · exact hCover n k
  · rintro ⟨j, hj, _hjk, hkj⟩
    exact hkj.trans_le ((cutIndex_strictMono T b hp).monotone (Nat.succ_le_succ hj))

end DIDomainClassification.TreeDomainDegree

