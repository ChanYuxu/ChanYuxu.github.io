import DIDomainClassification.Support.ForestContext
import DIDomainClassification.Support.ContextualTreeBridges
import DIDomainClassification.Support.RootExpansion

/-! Genuine nonempty finite root replacement by recursive singleton forests.
The old root VALUE is replaced; every old non-root value is retained. Complete
leaf paths carry the actual finite replacement set and its disjoint old tail.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries CoherenceDegree Trees TreeGrafting

variable {D : Type u} [PartialOrder D] {A : Type v}

def replaceRootLabel (S : RootedPrefixTree A)
    (label : S.Node → ↥(CompactElements D)) (k : ↥(CompactElements D)) :
    S.Node → ↥(CompactElements D) := by
  classical
  exact fun x => if x = S.root then k else label x

theorem replaceRootLabel_root (S : RootedPrefixTree A)
    (label : S.Node → ↥(CompactElements D)) (k : ↥(CompactElements D)) :
    replaceRootLabel S label k S.root = k := by
  classical
  exact if_pos rfl

theorem replaceRootLabel_nonroot (S : RootedPrefixTree A)
    (label : S.Node → ↥(CompactElements D)) (k : ↥(CompactElements D))
    (x : S.Node) (hx : x ≠ S.root) : replaceRootLabel S label k x = label x := by
  classical
  exact if_neg hx

theorem replaceRootLabel_pathImage (S : RootedPrefixTree A)
    (label : S.Node → ↥(CompactElements D)) (k : ↥(CompactElements D)) (leaf : S.Node) :
    labelImage S (replaceRootLabel S label k) (S.pathTo leaf) =
      {(k : D)} ∪ tailLabelImage S label leaf := by
  classical
  ext d
  constructor
  · rintro ⟨x, hx, rfl⟩
    by_cases hxr : x = S.root
    · exact Or.inl (Set.mem_singleton_iff.mpr
        (congrArg Subtype.val (by simpa only [hxr] using replaceRootLabel_root S label k)))
    · exact Or.inr ⟨x, ⟨hx, by simpa only [Set.mem_singleton_iff] using hxr⟩,
        (congrArg Subtype.val (replaceRootLabel_nonroot S label k x hxr)).symm⟩
  · intro hd
    rcases hd with hd | ⟨x, hx, rfl⟩
    · refine ⟨S.root, S.root_le leaf, ?_⟩
      exact (congrArg Subtype.val (replaceRootLabel_root S label k)).trans
        (Set.mem_singleton_iff.mp hd).symm
    · exact ⟨x, hx.1, congrArg Subtype.val
        (replaceRootLabel_nonroot S label k x (by simpa only [Set.mem_singleton_iff] using hx.2))⟩

def RootReplacementLeafData (hD : IsScottDomain D) (S : RootedPrefixTree A)
    (W : Set D) (label : S.Node → ↥(CompactElements D)) (B : Set D) : Prop :=
  ∀ leaf : S.Node, S.IsLeaf leaf →
    Set.InjOn label (S.pathTo leaf \ {S.root}) ∧
    (∀ x ∈ S.pathTo leaf \ {S.root}, (label x : D) ∉ W) ∧
    Disjoint (W ∪ tailLabelImage S label leaf) B ∧
    IsMinimallyInconsistent hD ((W ∪ tailLabelImage S label leaf) ∪ B)

/-- Construct actual compact labels on the n-new-ancestor expansion. No rank,
WF, closure, or refined-tree conclusion is supplied as a premise. The only
leaf data are the finite MIC replacement and old-tail injectivity/avoidance.
-/
theorem root_replacement_chain (hD : IsScottDomain D) (S : RootedPrefixTree A)
    (hroot : S.rootList = []) (hS : S.IsWellFounded) (marker : A)
    (label : S.Node → ↥(CompactElements D)) (B : Set D)
    (hTailBasis : ∀ x : S.Node, x ≠ S.root → (label x : D) ∈ B)
    (n : ℕ) (e : Fin (n + 1) → ↥(CompactElements D))
    (hinj : Function.Injective e) (hBasis : ∀ i, (e i : D) ∈ B)
    (W : Set D) (hW : W.Finite) (hWC : W ⊆ CompactElements D)
    (hData : RootReplacementLeafData hD S W label (Set.range (fun i => (e i : D)))) :
    ∃ newLabel : (rootExpansion S hroot marker n).Node → ↥(CompactElements D),
      IsContextualMicTree hD (rootExpansion S hroot marker n) W newLabel ∧
      ∀ x, (newLabel x : D) ∈ B := by
  classical
  induction n generalizing W with
  | zero =>
      let k := e 0
      have hrange : Set.range (fun i => (e i : D)) = {(k : D)} := by
        ext d
        constructor
        · rintro ⟨i, rfl⟩
          have hi : i = 0 := Fin.ext (by have hi := i.isLt; omega)
          exact Set.mem_singleton_iff.mpr (congrArg (fun i => (e i : D)) hi)
        · rintro rfl
          exact ⟨0, rfl⟩
      refine ⟨replaceRootLabel S label k, ?_, ?_⟩
      · apply contextual_of_leaf_paths hD S hS hW hWC
        intro leaf hleaf
        obtain ⟨hTailInj, hAvoid, hDis, hMic⟩ := hData leaf hleaf
        refine ⟨?_, ?_, ?_⟩
        · intro x hx y hy hxy
          by_cases hxr : x = S.root
          · subst x
            by_cases hyr : y = S.root
            · exact hyr.symm
            · have hyTail : y ∈ S.pathTo leaf \ {S.root} :=
                ⟨hy, by simpa only [Set.mem_singleton_iff] using hyr⟩
              have hval : (label y : D) = (k : D) := by
                simpa only [replaceRootLabel_root, replaceRootLabel_nonroot S label k y hyr]
                  using (congrArg Subtype.val hxy).symm
              exact (Set.disjoint_left.mp hDis (Or.inr ⟨y, hyTail, rfl⟩)
                ⟨0, hval.symm⟩).elim
          · by_cases hyr : y = S.root
            · subst y
              have hxTail : x ∈ S.pathTo leaf \ {S.root} :=
                ⟨hx, by simpa only [Set.mem_singleton_iff] using hxr⟩
              have hval : (label x : D) = (k : D) := by
                simpa only [replaceRootLabel_root, replaceRootLabel_nonroot S label k x hxr]
                  using congrArg Subtype.val hxy
              exact (Set.disjoint_left.mp hDis (Or.inr ⟨x, hxTail, rfl⟩)
                ⟨0, hval.symm⟩).elim
            · apply hTailInj
              · exact ⟨hx, by simpa only [Set.mem_singleton_iff] using hxr⟩
              · exact ⟨hy, by simpa only [Set.mem_singleton_iff] using hyr⟩
              · simpa only [replaceRootLabel_nonroot S label k x hxr,
                  replaceRootLabel_nonroot S label k y hyr] using hxy
        · intro x hx
          by_cases hxr : x = S.root
          · subst x
            rw [replaceRootLabel_root]
            exact fun hkW => Set.disjoint_left.mp hDis (Or.inl hkW) ⟨0, rfl⟩
          · rw [replaceRootLabel_nonroot S label k x hxr]
            exact hAvoid x ⟨hx, by simpa only [Set.mem_singleton_iff] using hxr⟩
        · rw [replaceRootLabel_pathImage]
          rw [hrange, Set.union_right_comm W (tailLabelImage S label leaf) {(k : D)},
            Set.union_assoc] at hMic
          exact hMic
      · intro x
        by_cases hxr : x = S.root
        · subst x
          rw [replaceRootLabel_root]
          exact hBasis 0
        · rw [replaceRootLabel_nonroot S label k x hxr]
          exact hTailBasis x hxr
  | succ n ih =>
      let eTail : Fin (n + 1) → ↥(CompactElements D) := fun i => e i.succ
      let C : Set D := Set.range (fun i => (e i : D))
      let CTail : Set D := Set.range (fun i => (eTail i : D))
      let k := e 0
      have hRange : C = {(k : D)} ∪ CTail := by
        ext d
        constructor
        · rintro ⟨i, rfl⟩
          refine Fin.cases (Or.inl (Set.mem_singleton _)) (fun j => Or.inr ⟨j, rfl⟩) i
        · rintro (hd | ⟨i, rfl⟩)
          · exact ⟨0, (Set.mem_singleton_iff.mp hd).symm⟩
          · exact ⟨i.succ, rfl⟩
      have hTailSub : CTail ⊆ C := by
        rintro _ ⟨i, rfl⟩
        exact ⟨i.succ, rfl⟩
      have hTailInj : Function.Injective eTail := fun i j hij =>
        Fin.succ_injective _ (hinj hij)
      have hNewData : RootReplacementLeafData hD S (W ∪ {(k : D)}) label CTail := by
        intro leaf hleaf
        obtain ⟨hInj, hAvoid, hDis, hMic⟩ := hData leaf hleaf
        refine ⟨hInj, ?_, ?_, ?_⟩
        · intro x hx hxW
          rcases hxW with hxW | hxK
          · exact hAvoid x hx hxW
          · have hval := Set.mem_singleton_iff.mp hxK
            exact Set.disjoint_left.mp hDis (Or.inr ⟨x, hx, rfl⟩) ⟨0, hval.symm⟩
        · apply Set.disjoint_left.mpr
          intro d hd hdTail
          rcases hd with (hdW | hdK) | hdOld
          · exact Set.disjoint_left.mp hDis (Or.inl hdW) (hTailSub hdTail)
          · obtain ⟨i, hi⟩ := hdTail
            have hval : (k : D) = (eTail i : D) :=
              (Set.mem_singleton_iff.mp hdK).symm.trans hi.symm
            have hidx := hinj (Subtype.ext hval)
            exact Fin.succ_ne_zero i hidx.symm
          · exact Set.disjoint_left.mp hDis (Or.inr hdOld) (hTailSub hdTail)
        · change IsMinimallyInconsistent hD
            (((W ∪ {(k : D)}) ∪ tailLabelImage S label leaf) ∪ CTail)
          change IsMinimallyInconsistent hD ((W ∪ tailLabelImage S label leaf) ∪ C) at hMic
          rw [hRange, ← Set.union_assoc (W ∪ tailLabelImage S label leaf) {(k : D)} CTail,
            Set.union_right_comm W (tailLabelImage S label leaf) {(k : D)}] at hMic
          exact hMic
      obtain ⟨tailLabel, hTailContext, hTailAllBasis⟩ := ih eTail hTailInj (fun i => hBasis i.succ)
        (W ∪ {(k : D)}) (hW.union (Set.finite_singleton _))
        (by
          intro d hd
          rcases hd with hd | hd
          · exact hWC hd
          · simpa only [Set.mem_singleton_iff.mp hd] using k.property) hNewData
      let R := rootExpansion S hroot marker n
      have hRroot : R.rootList = [] := rootExpansion_rootList S hroot marker n
      have hkW : (k : D) ∉ W := by
        obtain ⟨leaf, hleaf, _⟩ := FiniteLeafColourPruning.exists_leaf_extension S hS S.root
        exact fun hw => Set.disjoint_left.mp (hData leaf hleaf).2.2.1 (Or.inl hw) ⟨0, rfl⟩
      let children := fun _ : Unit => R
      let tags := fun _ : Unit => marker
      have hTags : Function.Injective tags := fun i j _ => Subsingleton.elim i j
      let roots := fun _ : Unit => hRroot
      refine ⟨forestLabel children tags roots k (fun _ => tailLabel), ?_, ?_⟩
      · exact contextual_forest children tags roots hD hTags k W (fun _ => tailLabel)
          hW hWC hkW (fun _ => hTailContext) (fun h => (h.false ()).elim)
      · intro x
        rcases forestNode_cases children tags roots x with hx | ⟨i, v, hx⟩
        · rw [hx, forestLabel_root]
          exact hBasis 0
        · rw [hx, forestLabel_embed children tags roots hTags]
          exact hTailAllBasis v

end DIDomainClassification.PointwiseFunctionSupport
