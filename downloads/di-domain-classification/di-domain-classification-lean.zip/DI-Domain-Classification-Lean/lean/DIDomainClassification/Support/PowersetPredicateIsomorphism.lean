import DIDomainClassification.Support.HomogeneousCliqueModels
import Mathlib.Logic.Denumerable

/-!
Source proof-only claim (manuscript.tex, introduction line 117 and proof
lines 1887--1893): the WHOLE non-strict stable-map space [P(N) ->_st 2],
with the native stable order, is order-isomorphic to the countable flat
domain N_bottom. This is an actual two-sided order isomorphism, not merely
a stable retract. The powerset and flat carriers retain their literal
historical ULift representations.

The proof uses all compact vertices in the predicate-clique representation.
Powerset compatibility makes their graph edgeless; countability and infinitely
many compact elements give a bijective reindexing by ULift Nat. No mapped
infinite-category generation or classification conclusion is used.
-/

set_option autoImplicit false
universe u v w
noncomputable section

namespace DIDomainClassification.PowersetPredicateIsomorphism

open Preliminaries Section02.BinaryCliqueModels Section03.StableFunctionModels
open Section04.AdditionalSourceModels Section04.PredicateModels

/-- A graph isomorphism induces an actual order isomorphism of all cliques.
The inverse is the literal preimage; its two inverse laws use bijectivity. -/
def cliqueGraphOrderIso {A : Type v} {B : Type w}
    (G : SimpleGraph A) (H : SimpleGraph B) (e : A ≃ B)
    (hAdj : ∀ a b, G.Adj a b ↔ H.Adj (e a) (e b)) :
    CliqueCarrier G ≃o CliqueCarrier H where
  toFun := CliqueStableMaps.imageMap G H e hAdj
  invFun := CliqueStableMaps.preimageMap G H e e.injective hAdj
  left_inv X := Subtype.ext (Set.preimage_image_eq X.val e.injective)
  right_inv Y := Subtype.ext (Set.image_preimage_eq Y.val e.surjective)
  map_rel_iff' := by
    intro X Y
    constructor
    · intro h a ha
      obtain ⟨b, hb, hba⟩ := h (show e a ∈ e '' X.val from ⟨a, ha, rfl⟩)
      exact e.injective hba ▸ hb
    · intro hXY
      exact CliqueStableMaps.image_monotone G H e hAdj hXY

abbrev CompactVertex : Type u :=
  ↥(CompactElements (Core HomogeneousCliqueModels.powersetObject.{u}))

/-- All vertices, not merely an infinite induced subset, are reindexed. -/
def compactVerticesEquiv : HomogeneousCliqueModels.Event.{u} ≃ CompactVertex.{u} := by
  letI : Countable CompactVertex.{u} :=
    HomogeneousCliqueModels.powersetObject.countableCompacts.to_subtype
  letI : Infinite (Core HomogeneousCliqueModels.powersetObject.{u}) :=
    HomogeneousCliqueModels.powerset_infinite
  letI : Infinite CompactVertex.{u} :=
    InfiniteCompactBasis.infinite_compacts HomogeneousCliqueModels.powersetObject
  exact Classical.choice (inferInstance :
    Nonempty (HomogeneousCliqueModels.Event.{u} ≃ CompactVertex.{u}))

/-- Every two compact subsets share the literal upper bound Nat itself. -/
theorem graph_not_adj (k l : CompactVertex.{u}) :
    ¬ (graph HomogeneousCliqueModels.powersetObject.{u}).Adj k l := by
  intro h
  exact h.2 (HomogeneousCliqueModels.powerset_compatible k.val l.val)

/-- The discrete countable graph is isomorphic to the whole powerset
compact-trigger graph, hence so are their whole clique domains. -/
def discreteCliqueOrderIso :
    CliqueCarrier HomogeneousCliqueModels.discrete.{u} ≃o
      CliqueCarrier (graph HomogeneousCliqueModels.powersetObject.{u}) :=
  cliqueGraphOrderIso HomogeneousCliqueModels.discrete
    (graph HomogeneousCliqueModels.powersetObject) compactVerticesEquiv
    (by
      intro a b
      exact iff_of_false (fun h => h)
        (graph_not_adj (compactVerticesEquiv a) (compactVerticesEquiv b)))

/-- Source-exact whole-predicate order isomorphism. StableHom's supplied
order is the native stable order, and its maps are not required to be strict. -/
def orderIso :
    StableHom (Core HomogeneousCliqueModels.powersetObject.{u})
      (Core FiniteOrderDomains.twoObject.{u}) ≃o FlatCarrier.{u} :=
  (PredicateCliqueIso.orderIso HomogeneousCliqueModels.powersetObject).trans
    (discreteCliqueOrderIso.symm.trans HomogeneousCliqueModels.flatOrderIso.symm)

/-- Exact local proof-step proposition for the manuscript's stronger claim. -/
def Goal : Prop :=
  Nonempty (StableHom (Core HomogeneousCliqueModels.powersetObject.{u})
    (Core FiniteOrderDomains.twoObject.{u}) ≃o FlatCarrier.{u})

/-- Public existence certificate supplied by the actual constructed isomorphism. -/
theorem certificate : Goal.{u} := ⟨orderIso⟩

end DIDomainClassification.PowersetPredicateIsomorphism
