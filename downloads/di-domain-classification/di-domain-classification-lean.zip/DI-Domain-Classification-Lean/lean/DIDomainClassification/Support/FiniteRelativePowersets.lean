import DIDomainClassification.Section04.FiniteGeneratorsStatement
import DIDomainClassification.Support.FiniteCausalConflictRetractions

/-! Literal relative proper powersets and their native lifted cube models.
No retraction or finite-generator conclusion is assumed by these bridges. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FiniteRelativePowersets

open Preliminaries EventStructures Section04.FiniteCategoryModels
open Section04.FiniteGeneratorModels

variable {A : Type u}

def cubeOrderIso (H : Set A) (k : ℕ) (hk : 2 ≤ k) (e : Fin k ≃ H) :
    CubeCarrier.{u} k hk ≃o ProperIn H where
  toFun S := ⟨(fun i => (e i).val) '' S.down.val, by
    refine ⟨?_, ?_⟩
    · rintro a ⟨i, _hi, rfl⟩
      exact (e i).property
    · intro hAll
      apply S.down.property
      apply Set.eq_univ_of_forall
      intro i
      obtain ⟨j, hj, hji⟩ := hAll (e i).property
      have heq : j = i := e.injective (Subtype.ext hji)
      simpa only [heq] using hj⟩
  invFun X := ⟨⟨{i | (e i).val ∈ X.val}, by
    intro hAll
    apply X.property.2
    intro a ha
    have hi : e.symm ⟨a, ha⟩ ∈ ({i | (e i).val ∈ X.val} : Set (Fin k)) :=
      hAll ▸ Set.mem_univ _
    simpa only [Set.mem_setOf_eq, e.apply_symm_apply] using hi⟩⟩
  left_inv S := by
    apply FiniteCubeRetractions.cube_ext
    ext i
    constructor
    · rintro ⟨j, hj, hji⟩
      have heq : j = i := e.injective (Subtype.ext hji)
      simpa only [heq] using hj
    · intro hi
      exact ⟨i, hi, rfl⟩
  right_inv X := by
    apply Subtype.ext
    ext a
    constructor
    · rintro ⟨i, hi, rfl⟩
      exact hi
    · intro ha
      refine ⟨e.symm ⟨a, X.property.1 ha⟩, ?_, ?_⟩
      · simpa only [Set.mem_setOf_eq, e.apply_symm_apply] using ha
      · exact congrArg Subtype.val (e.apply_symm_apply ⟨a, X.property.1 ha⟩)
  map_rel_iff' := by
    intro S T
    constructor
    · intro h i hi
      obtain ⟨j, hj, hji⟩ := h ⟨i, hi, rfl⟩
      have heq : j = i := e.injective (Subtype.ext hji)
      simpa only [heq] using hj
    · rintro h a ⟨i, hi, rfl⟩
      exact ⟨i, h hi, rfl⟩

def relativeDomain (H : Set A) (hH : H.Finite) (hTwo : 2 ≤ H.ncard) :
    IsDIDomain (ProperIn H) :=
  OrderIsoTransport.isDIDomain_map
    (cubeOrderIso H H.ncard hTwo (FiniteCausalConflictRetractions.enumeration H hH))
    (FiniteCubeRetractions.cubeCountablyBased.{u} H.ncard hTwo).1

def relativeCore (H : Set A) (h : IsDIDomain (ProperIn H)) : DIDomainObject.{u} :=
  DIDomainObject.ofType (ProperIn H) h

theorem relative_inf_values (H : Set A) (h : IsDIDomain (ProperIn H))
    (X Y : ProperIn H) :
    (h.toIsScottDomain.inf X Y).val = X.val ∩ Y.val := by
  let Z : ProperIn H := ⟨X.val ∩ Y.val, ⟨Set.inter_subset_left.trans X.property.1,
    fun hsub => X.property.2 (hsub.trans Set.inter_subset_left)⟩⟩
  have hZ : IsGLB ({X, Y} : Set (ProperIn H)) Z := by
    constructor
    · intro W hW
      rcases Set.mem_insert_iff.mp hW with rfl | hW
      · exact Set.inter_subset_left
      · rw [Set.mem_singleton_iff.mp hW]
        exact Set.inter_subset_right
    · intro W hW
      exact Set.subset_inter (hW (by simp)) (hW (by simp))
  exact congrArg Subtype.val ((h.toIsScottDomain.inf_isGLB X Y).unique hZ)

end DIDomainClassification.FiniteRelativePowersets
