import DIDomainClassification.Support.TreeEdgeMaps
import DIDomainClassification.Support.LeafClassSubtree

/-! The native child-rank choice and actual depth-recursive map used in the
well-founded part of tree comparison. Recursion is through the existing
well-founded finite-depth recursor, not a new partial recursive declaration. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TreeRankMaps

open Trees TreeEdgeMaps
variable {A B : Type u}

theorem child_with_rank (S : RootedPrefixTree B) (wfS : S.IsWellFounded)
    (w : S.Node) (η : Ordinal.{u}) (hη : η < S.nodeRank wfS w) :
    ∃ z : S.Node, S.IsChild w z ∧ η ≤ S.nodeRank wfS z := by
  classical
  by_contra hNo
  have hUpper : S.nodeRank wfS w ≤ η := by
    rw [S.nodeRank_eq wfS w]
    apply Ordinal.iSup_le
    intro z
    have hz : S.nodeRank wfS z.val < η :=
      lt_of_not_ge (fun h => hNo ⟨z.val, z.property, h⟩)
    simpa only [Order.succ_eq_add_one] using Order.succ_le_iff.mpr hz
  exact (not_le_of_gt hη) hUpper

def rankChild (S : RootedPrefixTree B) (wfS : S.IsWellFounded)
    (w : S.Node) (η : Ordinal.{u}) (hη : η < S.nodeRank wfS w) : S.Node :=
  Classical.choose (child_with_rank S wfS w η hη)

theorem rankChild_child (S : RootedPrefixTree B) (wfS : S.IsWellFounded)
    (w : S.Node) (η : Ordinal.{u}) (hη : η < S.nodeRank wfS w) :
    S.IsChild w (rankChild S wfS w η hη) :=
  (Classical.choose_spec (child_with_rank S wfS w η hη)).1

theorem rankChild_bound (S : RootedPrefixTree B) (wfS : S.IsWellFounded)
    (w : S.Node) (η : Ordinal.{u}) (hη : η < S.nodeRank wfS w) :
    η ≤ S.nodeRank wfS (rankChild S wfS w η hη) :=
  (Classical.choose_spec (child_with_rank S wfS w η hη)).2

theorem child_rank_lt (T : RootedPrefixTree A) (wfT : T.IsWellFounded)
    {x y : T.Node} (hxy : T.IsChild x y) : T.nodeRank wfT y < T.nodeRank wfT x := by
  have h := FiniteLeafColourPruning.nodeRank_add_one_le_of_child T wfT hxy
  exact (show T.nodeRank wfT y < T.nodeRank wfT y + 1 by
    simpa only [Order.succ_eq_add_one] using Order.lt_succ (T.nodeRank wfT y)).trans_le h

variable (T : RootedPrefixTree A) (S : RootedPrefixTree B)
    (wfT : T.IsWellFounded) (wfS : S.IsWellFounded)

abbrev RankedImage (w : T.Node) : Type u :=
  {z : S.Node // T.nodeRank wfT w ≤ S.nodeRank wfS z}

def rankedStep (hRanks : T.treeRank wfT ≤ S.treeRank wfS) (w : T.Node)
    (ih : ∀ z : T.Node, T.depth z < T.depth w → RankedImage T S wfT wfS z) :
    RankedImage T S wfT wfS w := by
  classical
  exact if hw : w = T.root then
    ⟨S.root, by
      rw [hw]
      exact hRanks⟩
  else by
    let p := ih (parent T w) (parent_depth_lt T w hw)
    have hlt : T.nodeRank wfT w < S.nodeRank wfS p.val :=
      (child_rank_lt T wfT (parent_child T w hw)).trans_le p.property
    exact ⟨rankChild S wfS p.val (T.nodeRank wfT w) hlt,
      rankChild_bound S wfS p.val (T.nodeRank wfT w) hlt⟩

def rankedNode (hRanks : T.treeRank wfT ≤ S.treeRank wfS) (w : T.Node) :
    RankedImage T S wfT wfS w :=
  (measure T.depth).wf.fix (rankedStep T S wfT wfS hRanks) w

theorem rankedNode_eq (hRanks : T.treeRank wfT ≤ S.treeRank wfS) (w : T.Node) :
    rankedNode T S wfT wfS hRanks w = rankedStep T S wfT wfS hRanks w
      (fun z _ => rankedNode T S wfT wfS hRanks z) :=
  WellFounded.fix_eq (measure T.depth).wf (rankedStep T S wfT wfS hRanks) w

def nodeMap (hRanks : T.treeRank wfT ≤ S.treeRank wfS) (w : T.Node) : S.Node :=
  (rankedNode T S wfT wfS hRanks w).val

theorem nodeMap_bound (hRanks : T.treeRank wfT ≤ S.treeRank wfS) (w : T.Node) :
    T.nodeRank wfT w ≤ S.nodeRank wfS (nodeMap T S wfT wfS hRanks w) :=
  (rankedNode T S wfT wfS hRanks w).property

theorem nodeMap_root (hRanks : T.treeRank wfT ≤ S.treeRank wfS) :
    nodeMap T S wfT wfS hRanks T.root = S.root := by
  unfold nodeMap
  rw [rankedNode_eq]
  simp [rankedStep]

theorem nodeMap_child (hRanks : T.treeRank wfT ≤ S.treeRank wfS)
    {x y : T.Node} (hxy : T.IsChild x y) :
    S.IsChild (nodeMap T S wfT wfS hRanks x) (nodeMap T S wfT wfS hRanks y) := by
  have hy : y ≠ T.root := by
    intro hRoot
    have hd := hxy.2
    rw [hRoot, T.depth_root] at hd
    omega
  have hlt : T.nodeRank wfT y <
      S.nodeRank wfS (rankedNode T S wfT wfS hRanks (parent T y)).val :=
    (child_rank_lt T wfT (parent_child T y hy)).trans_le
      (rankedNode T S wfT wfS hRanks (parent T y)).property
  have hc := rankChild_child S wfS
    (rankedNode T S wfT wfS hRanks (parent T y)).val (T.nodeRank wfT y) hlt
  change S.IsChild (rankedNode T S wfT wfS hRanks x).val
    (rankedNode T S wfT wfS hRanks y).val
  rw [rankedNode_eq T S wfT wfS hRanks y]
  simp only [rankedStep, dif_neg hy]
  have hp : parent T y = x := parent_eq_of_child T hxy
  subst x
  exact hc

theorem exists_rank_map (hRanks : T.treeRank wfT ≤ S.treeRank wfS) :
    ∃ f : T.Node → S.Node, f T.root = S.root ∧
      (∀ {x y : T.Node}, T.IsChild x y → S.IsChild (f x) (f y)) ∧
        ∀ w : T.Node, T.nodeRank wfT w ≤ S.nodeRank wfS (f w) :=
  ⟨nodeMap T S wfT wfS hRanks, nodeMap_root T S wfT wfS hRanks,
    nodeMap_child T S wfT wfS hRanks, nodeMap_bound T S wfT wfS hRanks⟩

end DIDomainClassification.TreeRankMaps
