import DIDomainClassification.Section05.ReflexiveClassificationStatements
import DIDomainClassification.Section04.SeparatedSum
import DIDomainClassification.Section02.TwoExponential
import DIDomainClassification.Section02.TwoRetract
import DIDomainClassification.Support.ComparisonOperations
import DIDomainClassification.Support.IntrinsicAmbientCore
import DIDomainClassification.Support.OrdinalCutWitnesses

/-! The source binary-product absorption argument. The separated sum of two
literal singleton domains is identified with the actual three-map stable
exponential of Two, never with its pointwise order. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ReflexiveProducts
open Preliminaries Section03.StableFunctionModels Section04.AdditionalSourceModels
open Section04 Section04.SeparatedSumModels
open Section02.TwoExponentialModels

abbrev U : CountablyBasedDIDomain.{u} := FlatPowerRetraction.unit
def family : BasicDomains.Two → CountablyBasedDIDomain.{u} := fun _ => U
abbrev SumCarrier := Carrier family.{u}

local instance sumNativeOrder : PartialOrder SumCarrier.{u} :=
  (SeparatedSumFunctions.sumCore family.{u}).partialOrder

local instance singletonUnit : Subsingleton (Section03.StableFunctionModels.Core U.{u}) := by
  change Subsingleton PUnit.{u+1}
  infer_instance
local instance singletonFamily (i : BasicDomains.Two) :
    Subsingleton (Section03.StableFunctionModels.Core (family.{u} i)) := singletonUnit

def toEnd : SumCarrier.{u} → Endomaps.{u}
  | none => zeroMap
  | some x => if x.1 = 0 then identityMap else oneMap

def fromEnd (f : Endomaps.{u}) : SumCarrier.{u} := by
  classical
  exact if f = zeroMap then none else if f = identityMap then some ⟨0, PUnit.unit⟩
    else some ⟨1, PUnit.unit⟩

theorem from_to (x : SumCarrier.{u}) : fromEnd (toEnd x) = x := by
  classical
  cases x with
  | none => simp [toEnd, fromEnd]
  | some x =>
    rcases x with ⟨i, a⟩
    have ha : a = PUnit.unit := Subsingleton.elim _ _
    subst a
    rcases BasicDomains.two_eq_zero_or_one i with rfl | rfl <;>
      simp [toEnd, fromEnd, TwoExponentialOrderIso.zero_ne_identity.symm,
        TwoExponentialOrderIso.zero_ne_oneMap.symm, TwoExponentialOrderIso.identity_ne_one.symm]

theorem to_from (f : Endomaps.{u}) : toEnd (fromEnd f) = f := by
  classical
  rcases TwoExponentialOrderIso.classify f with rfl | rfl | rfl <;>
    simp [toEnd, fromEnd, TwoExponentialOrderIso.zero_ne_identity.symm,
      TwoExponentialOrderIso.zero_ne_oneMap.symm, TwoExponentialOrderIso.identity_ne_one.symm]

theorem sum_order_iff (x y : SumCarrier.{u}) : x ≤ y ↔ x = none ∨ x = y := by
  constructor
  · intro h
    rcases SeparatedSumOrder.cases_sum family.{u} x with rfl | ⟨i, a, rfl⟩
    · exact Or.inl rfl
    · obtain ⟨b, rfl, _hab⟩ := SeparatedSumOrder.component_le_elim family.{u} h
      have hab : a = b := Subsingleton.elim _ _
      subst b
      exact Or.inr rfl
  · rintro (rfl | rfl)
    · exact bot_le
    · exact le_rfl

def sumEndOrderIso : SumCarrier.{u} ≃o Endomaps.{u} where
  toFun := toEnd
  invFun := fromEnd
  left_inv := from_to
  right_inv := to_from
  map_rel_iff' := by
    intro x y
    rw [TwoExponentialOrderIso.order_iff, sum_order_iff]
    constructor
    · rintro (h | h)
      · apply Or.inl
        simpa [fromEnd] using ((from_to x).symm.trans (congrArg fromEnd h))
      · exact Or.inr ((from_to x).symm.trans ((congrArg fromEnd h).trans (from_to y)))
    · rintro (rfl | rfl)
      · exact Or.inl rfl
      · exact Or.inr rfl

def pairOrderIso (E : CountablyBasedDIDomain.{u}) :
    SeparatedSumHomOperations.familyCore family.{u} E ≃o
      (Section03.StableFunctionModels.Core E × Section03.StableFunctionModels.Core E) where
  toFun f := (f 0 PUnit.unit, f 1 PUnit.unit)
  invFun p i := FlatPowerRetraction.constantHom E (if i = 0 then p.1 else p.2)
  left_inv f := by
    funext i
    apply StableHom.ext
    intro x
    have hx : x = PUnit.unit := Subsingleton.elim _ _
    subst x
    rcases BasicDomains.two_eq_zero_or_one i with rfl | rfl <;> rfl
  right_inv p := rfl
  map_rel_iff' := by
    intro f g
    constructor
    · intro h i x y _hxy
      have hx : x = PUnit.unit := Subsingleton.elim _ _
      have hy : y = PUnit.unit := Subsingleton.elim _ _
      subst x
      subst y
      rcases BasicDomains.two_eq_zero_or_one i with rfl | rfl
      · exact (inf_eq_left.mpr h.1).symm
      · exact (inf_eq_left.mpr h.2).symm
    · intro h
      exact ⟨(h 0 PUnit.unit PUnit.unit le_rfl).trans_le inf_le_right,
        (h 1 PUnit.unit PUnit.unit le_rfl).trans_le inf_le_right⟩

end DIDomainClassification.ReflexiveProducts

namespace DIDomainClassification.ReflexiveProducts
open Preliminaries Subcategories Section05 Section03.StableFunctionModels
open Section04.AdditionalSourceModels

theorem exponential_retract (D F A B : CountablyBasedDIDomain.{u})
    (hD : HasStableRetraction (Core D) (Core A))
    (hF : HasStableRetraction (Core F) (Core B)) :
    HasStableRetraction (Core (exponential D F)) (Core (exponential A B)) := by
  obtain ⟨sD, rD, hD⟩ := hD
  obtain ⟨sF, rF, hF⟩ := hF
  obtain ⟨hs, hr, hLeft⟩ := Section02.retractionExponential
    (Core D) (Core F) (Core A) (Core B) sD rD sF rF hD hF
  exact ⟨StableHom.ofFunction _ hs, StableHom.ofFunction _ hr, hLeft⟩

theorem twoEnd_retract (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) :
    HasStableRetraction (Core (exponential FiniteOrderDomains.twoObject.{u} FiniteOrderDomains.twoObject.{u}))
      (Core E) := by
  have hTwo := (Section02.twoRetract (Core E) hNon.exists_pair_ne).2
  exact ComparisonOperations.split_trans (exponential_retract _ _ E E hTwo hTwo) hRef

theorem cubeTwo_retract (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) :
    ∃ hCube : IsCountablyBasedDIDomain (Section04.FiniteCategoryModels.CubeCarrier.{u} 2 (by decide)),
      HasStableRetraction (Core (Section04.FiniteCategoryModels.cubeObject 2 (by decide) hCube)) (Core E) := by
  obtain ⟨hCube, _hc, _hzi, _hzo, _hio, _hz, _hp, _hno, ⟨q⟩⟩ := Section02.twoExponential.{u}
  exact ⟨hCube, ComparisonOperations.split_trans
    (ComparisonOperations.iso_split _ _ (IntrinsicAmbient.isoOrderIso q).symm)
    (twoEnd_retract E hNon hRef)⟩

theorem square_retract (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) :
    HasStableRetraction
      (Core (Section02.StableBackground.productObject trueClosure E E)) (Core E) := by
  obtain ⟨hCube, hCubeE⟩ := cubeTwo_retract E hNon hRef
  let S : CountablyBasedDIDomain.{u} := cbObject (Section04.SeparatedSumModels.Carrier family.{u})
    (SeparatedSumDomain.sum_countablyBased family.{u})
  have hSE : HasStableRetraction (Core S) (Core E) := ComparisonOperations.split_trans
    (ComparisonOperations.iso_split _ _ (sumEndOrderIso.trans TwoExponentialOrderIso.orderIso)) hCubeE
  obtain ⟨_hSum, hP, _hK, _hC, sectionMap, restrictionMap, _hs, _hr, hLeft⟩ :=
    Section04.separatedSumGeneral BasicDomains.Two family.{u} E
  have hSquare : HasStableRetraction
      (Core (Section02.StableBackground.productObject trueClosure E E))
      (Core (exponential S E)) := ComparisonOperations.split_trans
    (ComparisonOperations.iso_split _ _ (pairOrderIso E).symm) ⟨sectionMap, restrictionMap, hLeft⟩
  exact ComparisonOperations.split_trans hSquare
    (ComparisonOperations.split_trans
      (exponential_retract S E E E hSE (Section05.ReflexiveModels.retract_refl (Core E))) hRef)

end DIDomainClassification.ReflexiveProducts
