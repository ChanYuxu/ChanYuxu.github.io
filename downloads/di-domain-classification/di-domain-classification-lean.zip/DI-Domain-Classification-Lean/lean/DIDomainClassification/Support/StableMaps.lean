import Mathlib.Order.ScottContinuity
import Mathlib.Order.Lattice

/-!
# Provisional map interfaces for the dI-domain classification manuscript

These general semilattice interfaces record the equations in Definitions 2.1
and 2.3. Their specialization to the manuscript's countably based dI-domain
objects, and the independent source-interface review, are not yet complete.
They must not be cited as verification of the classification theorem.

Scott continuity below is Mathlib's preservation of suprema of nonempty
directed sets, not merely preservation of increasing sequences.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification

/-- Two elements are compatible when they have a common upper bound. -/
def Compatible {D : Type u} [Preorder D] (x y : D) : Prop :=
  ∃ z : D, x ≤ z ∧ y ≤ z

/-- A non-strict Scott-continuous map preserving compatible binary meets. -/
structure StableMap (D : Type u) (E : Type v)
    [SemilatticeInf D] [SemilatticeInf E] where
  toFun : D → E
  scottContinuous : ScottContinuous toFun
  map_inf_of_compatible : ∀ x y : D, Compatible x y →
    toFun (x ⊓ y) = toFun x ⊓ toFun y

instance {D : Type u} {E : Type v} [SemilatticeInf D] [SemilatticeInf E] :
    CoeFun (StableMap D E) (fun _ => D → E) :=
  ⟨StableMap.toFun⟩

/-- The manuscript's stable comparison, not pointwise comparison. -/
def StableLE {D : Type u} {E : Type v}
    [SemilatticeInf D] [SemilatticeInf E] (f g : StableMap D E) : Prop :=
  ∀ x y : D, x ≤ y → f x = f y ⊓ g x

/-- Pointwise comparison is recorded separately to prevent order confusion. -/
def PointwiseLE {D : Type u} {E : Type v}
    [SemilatticeInf D] [SemilatticeInf E] (f g : StableMap D E) : Prop :=
  ∀ x : D, f x ≤ g x

/-- A stable retraction does not assume an embedding-projection inequality. -/
structure StableRetraction (D : Type u) (E : Type v)
    [SemilatticeInf D] [SemilatticeInf E] where
  sectionMap : StableMap D E
  retractionMap : StableMap E D
  leftInverse : Function.LeftInverse retractionMap sectionMap

end DIDomainClassification
