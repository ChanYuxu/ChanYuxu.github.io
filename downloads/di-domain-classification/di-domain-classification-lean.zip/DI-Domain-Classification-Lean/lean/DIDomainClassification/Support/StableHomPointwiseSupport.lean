import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.StableFunctionSpaces

/-!
# Generic stable-order pointwise operations

Staged library support only, not a source Theorem 2.2 or CCC proof. The raw
source requires only a semilattice; the codomain requires its actual algebraic
dcpo property. Directed suprema and compatible meets are proved in the stable
comparison, never inferred merely from the pointwise function order.
No strictness, finiteness, countability or citation theorem is assumed.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.StableHomPointwiseSupport

open OrderCore

section Codomain

variable {E : Type v} [SemilatticeInf E]

theorem le_of_compactBelow (hE : IsAlgebraicDcpo E) {a b : E}
    (h : ∀ k : E, Compact k → k ≤ a → k ≤ b) : a ≤ b :=
  (hE.2 a).2.2 b (fun k hk => h k hk.1 hk.2)

/-- A fixed binary meet preserves every existing nonempty directed supremum. -/
theorem inf_isLUB_image (hE : IsAlgebraicDcpo E) (c : E)
    {A : Set E} {s : E} (hA : DirectedSet A) (hs : IsLUB A s) :
    IsLUB ((fun a : E => c ⊓ a) '' A) (c ⊓ s) := by
  constructor
  · rintro _ ⟨a, ha, rfl⟩
    exact inf_le_inf_left c (hs.1 ha)
  · intro z hz
    apply le_of_compactBelow hE
    intro k hk hkc
    obtain ⟨a, ha, hka⟩ := hk hA hs (hkc.trans inf_le_right)
    exact (le_inf (hkc.trans inf_le_left) hka).trans (hz ⟨a, ha, rfl⟩)

/-- Joint meet continuity follows from compact approximation and directedness.
No product algebraicity or global lattice/distributivity premise is used. -/
theorem inf_scottContinuous (hE : IsAlgebraicDcpo E) :
    ScottContinuous (fun p : E × E => p.1 ⊓ p.2) := by
  intro A hne hdir s hs
  let hA : DirectedSet A := ⟨hne, hdir⟩
  have hfst : IsLUB (Prod.fst '' A) s.1 :=
    scottContinuous_isSup ScottContinuous.fst hA hs
  have hsnd : IsLUB (Prod.snd '' A) s.2 :=
    scottContinuous_isSup ScottContinuous.snd hA hs
  constructor
  · rintro _ ⟨a, ha, rfl⟩
    exact inf_le_inf (hs.1 ha).1 (hs.1 ha).2
  · intro z hz
    apply le_of_compactBelow hE
    intro k hk hks
    obtain ⟨_, ⟨a, ha, rfl⟩, hka⟩ :=
      hk (hA.image (fun _ _ h => h.1)) hfst (hks.trans inf_le_left)
    obtain ⟨_, ⟨b, hb, rfl⟩, hkb⟩ :=
      hk (hA.image (fun _ _ h => h.2)) hsnd (hks.trans inf_le_right)
    obtain ⟨c, hc, hac, hbc⟩ := hdir a ha b hb
    exact (le_inf (hka.trans hac.1) (hkb.trans hbc.2)).trans (hz ⟨c, hc, rfl⟩)

end Codomain

section Raw

variable {D : Type u} {E : Type v} [SemilatticeInf D] [SemilatticeInf E]

theorem raw_ext {f g : StableMap D E} (h : ∀ x : D, f x = g x) : f = g := by
  rcases f with ⟨f, hf, hfm⟩
  rcases g with ⟨g, hg, hgm⟩
  have heq : f = g := funext h
  cases heq
  rfl

theorem stableLE_pointwise {f g : StableMap D E} (hfg : StableLE f g) (x : D) :
    f x ≤ g x := by
  calc
    f x = f x ⊓ g x := hfg x x le_rfl
    _ ≤ g x := inf_le_right

abbrev Values (A : Set (StableMap D E)) (x : D) : Set E :=
  (fun f : StableMap D E => f x) '' A

theorem values_directed (A : Set (StableMap D E)) (hne : A.Nonempty)
    (hdir : DirectedOn StableLE A) (x : D) : DirectedSet (Values A x) := by
  constructor
  · obtain ⟨f, hf⟩ := hne
    exact ⟨f x, ⟨f, hf, rfl⟩⟩
  · rintro _ ⟨f, hf, rfl⟩ _ ⟨g, hg, rfl⟩
    obtain ⟨h, hh, hfh, hgh⟩ := hdir f hf g hg
    exact ⟨h x, ⟨h, hh, rfl⟩, stableLE_pointwise hfh x, stableLE_pointwise hgh x⟩

noncomputable def pointwiseSup (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A)
    (x : D) : E :=
  Classical.choose (hE.1 (Values A x) (values_directed A hne hdir x))

theorem pointwiseSup_isLUB (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A) (x : D) :
    IsLUB (Values A x) (pointwiseSup hE A hne hdir x) :=
  Classical.choose_spec (hE.1 (Values A x) (values_directed A hne hdir x))

theorem member_le_pointwiseSup (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A)
    {f : StableMap D E} (hf : f ∈ A) (x : D) : f x ≤ pointwiseSup hE A hne hdir x :=
  (pointwiseSup_isLUB hE A hne hdir x).1 ⟨f, hf, rfl⟩

theorem pointwiseSup_monotone (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A) :
    Monotone (pointwiseSup hE A hne hdir) := by
  intro x y hxy
  apply (pointwiseSup_isLUB hE A hne hdir x).2
  rintro _ ⟨f, hf, rfl⟩
  exact (f.scottContinuous.monotone hxy).trans (member_le_pointwiseSup hE A hne hdir hf y)

theorem pointwiseSup_scottContinuous (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A) :
    ScottContinuous (pointwiseSup hE A hne hdir) := by
  intro B hBne hBdir b hb
  constructor
  · rintro _ ⟨x, hx, rfl⟩
    exact pointwiseSup_monotone hE A hne hdir (hb.1 hx)
  · intro z hz
    apply (pointwiseSup_isLUB hE A hne hdir b).2
    rintro _ ⟨f, hf, rfl⟩
    apply (f.scottContinuous hBne hBdir hb).2
    rintro _ ⟨x, hx, rfl⟩
    exact (member_le_pointwiseSup hE A hne hdir hf x).trans (hz ⟨x, hx, rfl⟩)

theorem pointwiseSup_map_inf (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A)
    (x y : D) (hxy : Compatible x y) :
    pointwiseSup hE A hne hdir (x ⊓ y) =
      pointwiseSup hE A hne hdir x ⊓ pointwiseSup hE A hne hdir y := by
  apply le_antisymm
  · exact le_inf (pointwiseSup_monotone hE A hne hdir inf_le_left)
      (pointwiseSup_monotone hE A hne hdir inf_le_right)
  · apply le_of_compactBelow hE
    intro k hk hkle
    obtain ⟨_, ⟨f, hf, rfl⟩, hkf⟩ := hk (values_directed A hne hdir x)
      (pointwiseSup_isLUB hE A hne hdir x) (hkle.trans inf_le_left)
    obtain ⟨_, ⟨g, hg, rfl⟩, hkg⟩ := hk (values_directed A hne hdir y)
      (pointwiseSup_isLUB hE A hne hdir y) (hkle.trans inf_le_right)
    obtain ⟨h, hh, hfh, hgh⟩ := hdir f hf g hg
    have hkh : k ≤ h (x ⊓ y) := by
      rw [h.map_inf_of_compatible x y hxy]
      exact le_inf (hkf.trans (stableLE_pointwise hfh x))
        (hkg.trans (stableLE_pointwise hgh y))
    exact hkh.trans (member_le_pointwiseSup hE A hne hdir hh (x ⊓ y))

noncomputable def directedSupMap (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A) :
    StableMap D E :=
  ⟨pointwiseSup hE A hne hdir, pointwiseSup_scottContinuous hE A hne hdir,
    pointwiseSup_map_inf hE A hne hdir⟩

theorem directedSupMap_apply (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A) (x : D) :
    directedSupMap hE A hne hdir x = pointwiseSup hE A hne hdir x := rfl

/-- Stable upper-bound law, stronger than the coordinate upper-bound law. -/
theorem member_stableLE_directedSupMap (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A)
    {f : StableMap D E} (hf : f ∈ A) : StableLE f (directedSupMap hE A hne hdir) := by
  intro x y hxy
  change f x = f y ⊓ pointwiseSup hE A hne hdir x
  apply le_antisymm
  · exact le_inf (f.scottContinuous.monotone hxy) (member_le_pointwiseSup hE A hne hdir hf x)
  · apply (inf_isLUB_image hE (f y) (values_directed A hne hdir x)
      (pointwiseSup_isLUB hE A hne hdir x)).2
    rintro _ ⟨_, ⟨g, hg, rfl⟩, rfl⟩
    obtain ⟨h, _hh, hfh, hgh⟩ := hdir f hf g hg
    calc
      f y ⊓ g x ≤ f y ⊓ h x := inf_le_inf_left _ (stableLE_pointwise hgh x)
      _ = f x := (hfh x y hxy).symm

/-- Leastness is in the stable comparison, not merely coordinatewise. -/
theorem directedSupMap_stableLE (hE : IsAlgebraicDcpo E)
    (A : Set (StableMap D E)) (hne : A.Nonempty) (hdir : DirectedOn StableLE A)
    (U : StableMap D E) (hU : ∀ f ∈ A, StableLE f U) :
    StableLE (directedSupMap hE A hne hdir) U := by
  intro x y hxy
  change pointwiseSup hE A hne hdir x = pointwiseSup hE A hne hdir y ⊓ U x
  apply le_antisymm
  · apply le_inf (pointwiseSup_monotone hE A hne hdir hxy)
    apply (pointwiseSup_isLUB hE A hne hdir x).2
    rintro _ ⟨f, hf, rfl⟩
    exact stableLE_pointwise (hU f hf) x
  · rw [inf_comm]
    apply (inf_isLUB_image hE (U x) (values_directed A hne hdir y)
      (pointwiseSup_isLUB hE A hne hdir y)).2
    rintro _ ⟨_, ⟨f, hf, rfl⟩, rfl⟩
    change U x ⊓ f y ≤ pointwiseSup hE A hne hdir x
    rw [inf_comm, ← hU f hf x y hxy]
    exact member_le_pointwiseSup hE A hne hdir hf x

/-- The pointwise infimum is stable even before a common stable upper is given. -/
def pointwiseInfMap (hE : IsAlgebraicDcpo E) (f g : StableMap D E) : StableMap D E where
  toFun x := f x ⊓ g x
  scottContinuous := (f.scottContinuous.prodMk g.scottContinuous).comp (inf_scottContinuous hE)
  map_inf_of_compatible := by
    intro x y hxy
    rw [f.map_inf_of_compatible x y hxy, g.map_inf_of_compatible x y hxy]
    exact inf_inf_inf_comm _ _ _ _

theorem pointwiseInfMap_apply (hE : IsAlgebraicDcpo E) (f g : StableMap D E) (x : D) :
    pointwiseInfMap hE f g x = f x ⊓ g x := rfl

theorem pointwiseInfMap_stableLE_left (hE : IsAlgebraicDcpo E)
    (f g U : StableMap D E) (hfU : StableLE f U) (hgU : StableLE g U) :
    StableLE (pointwiseInfMap hE f g) f := by
  intro x y hxy
  change f x ⊓ g x = (f y ⊓ g y) ⊓ f x
  apply le_antisymm
  · exact le_inf (inf_le_inf (f.scottContinuous.monotone hxy) (g.scottContinuous.monotone hxy))
      inf_le_left
  · apply le_inf inf_le_right
    calc
      (f y ⊓ g y) ⊓ f x ≤ g y ⊓ U x := le_inf
        (inf_le_left.trans inf_le_right) (inf_le_right.trans (stableLE_pointwise hfU x))
      _ = g x := (hgU x y hxy).symm

theorem pointwiseInfMap_stableLE_right (hE : IsAlgebraicDcpo E)
    (f g U : StableMap D E) (hfU : StableLE f U) (hgU : StableLE g U) :
    StableLE (pointwiseInfMap hE f g) g := by
  have heq : pointwiseInfMap hE f g = pointwiseInfMap hE g f :=
    raw_ext (fun x => inf_comm (f x) (g x))
  rw [heq]
  exact pointwiseInfMap_stableLE_left hE g f U hgU hfU

theorem stableLE_pointwiseInfMap (hE : IsAlgebraicDcpo E)
    (f g h : StableMap D E) (hhf : StableLE h f) (hhg : StableLE h g) :
    StableLE h (pointwiseInfMap hE f g) := by
  intro x y hxy
  change h x = h y ⊓ (f x ⊓ g x)
  apply le_antisymm
  · exact le_inf (h.scottContinuous.monotone hxy)
      (le_inf (stableLE_pointwise hhf x) (stableLE_pointwise hhg x))
  · calc
      h y ⊓ (f x ⊓ g x) ≤ h y ⊓ f x := inf_le_inf_left _ inf_le_left
      _ = h x := (hhf x y hxy).symm

end Raw

section Hom

variable {D : DIDomainObject.{u}} {E : DIDomainObject.{v}}

/-- Exact bridge to the accepted stable order; no pointwise-order substitution. -/
theorem hom_le_iff_raw (f g : StableHom D E) :
    f ≤ g ↔ StableLE f.toStableMap g.toStableMap := Iff.rfl

abbrev rawFamily (A : Set (StableHom D E)) : Set (StableMap D E) :=
  (fun f : StableHom D E => f.toStableMap) '' A

theorem rawFamily_nonempty (A : Set (StableHom D E)) (hne : A.Nonempty) :
    (rawFamily A).Nonempty := by
  obtain ⟨f, hf⟩ := hne
  exact ⟨f.toStableMap, ⟨f, hf, rfl⟩⟩

theorem rawFamily_directed (A : Set (StableHom D E)) (hA : DirectedSet A) :
    DirectedOn StableLE (rawFamily A) := by
  rintro _ ⟨f, hf, rfl⟩ _ ⟨g, hg, rfl⟩
  obtain ⟨h, hh, hfh, hgh⟩ := hA.2 hf hg
  exact ⟨h.toStableMap, ⟨h, hh, rfl⟩,
    (hom_le_iff_raw f h).mp hfh, (hom_le_iff_raw g h).mp hgh⟩

theorem rawFamily_values (A : Set (StableHom D E)) (x : D) :
    Values (rawFamily A) x = (fun f : StableHom D E => f x) '' A := by
  ext z
  constructor
  · rintro ⟨_, ⟨f, hf, rfl⟩, rfl⟩
    exact ⟨f, hf, rfl⟩
  · rintro ⟨f, hf, rfl⟩
    exact ⟨f.toStableMap, ⟨f, hf, rfl⟩, rfl⟩

noncomputable def homDirectedSup (A : Set (StableHom D E)) (hA : DirectedSet A) :
    StableHom D E :=
  ⟨directedSupMap E.isDIDomain.toIsScottDomain.algebraic (rawFamily A)
    (rawFamily_nonempty A hA.1) (rawFamily_directed A hA)⟩

theorem homDirectedSup_values (A : Set (StableHom D E)) (hA : DirectedSet A) (x : D) :
    IsLUB ((fun f : StableHom D E => f x) '' A) (homDirectedSup A hA x) := by
  have h := pointwiseSup_isLUB E.isDIDomain.toIsScottDomain.algebraic (rawFamily A)
    (rawFamily_nonempty A hA.1) (rawFamily_directed A hA) x
  simpa only [rawFamily_values] using h

/-- LUB in the ACTUAL stable Hom partial order. -/
theorem homDirectedSup_isLUB (A : Set (StableHom D E)) (hA : DirectedSet A) :
    IsLUB A (homDirectedSup A hA) := by
  constructor
  · intro f hf
    exact member_stableLE_directedSupMap E.isDIDomain.toIsScottDomain.algebraic
      (rawFamily A) (rawFamily_nonempty A hA.1) (rawFamily_directed A hA) ⟨f, hf, rfl⟩
  · intro U hU
    apply directedSupMap_stableLE E.isDIDomain.toIsScottDomain.algebraic
      (rawFamily A) (rawFamily_nonempty A hA.1) (rawFamily_directed A hA) U.toStableMap
    rintro _ ⟨f, hf, rfl⟩
    exact (hom_le_iff_raw f U).mp (hU hf)

theorem hom_isLUB_iff_values (A : Set (StableHom D E)) (hA : DirectedSet A)
    (f : StableHom D E) :
    IsLUB A f ↔ ∀ x : D, IsLUB ((fun g : StableHom D E => g x) '' A) (f x) := by
  constructor
  · intro hf
    have heq : f = homDirectedSup A hA := hf.unique (homDirectedSup_isLUB A hA)
    rw [heq]
    exact homDirectedSup_values A hA
  · intro hf
    have heq : f = homDirectedSup A hA :=
      StableHom.ext (fun x => (hf x).unique (homDirectedSup_values A hA x))
    rw [heq]
    exact homDirectedSup_isLUB A hA

theorem hom_isDcpo : IsDcpo (StableHom D E) := by
  intro A hA
  exact ⟨homDirectedSup A hA, homDirectedSup_isLUB A hA⟩

noncomputable def homPointwiseInf (f g : StableHom D E) : StableHom D E :=
  ⟨pointwiseInfMap E.isDIDomain.toIsScottDomain.algebraic f.toStableMap g.toStableMap⟩

theorem homPointwiseInf_apply (f g : StableHom D E) (x : D) :
    homPointwiseInf f g x = f x ⊓ g x := rfl

/-- The common upper is explicitly in the actual stable order. -/
theorem homPointwiseInf_isGLB (f g : StableHom D E) (hcomp : Compatible f g) :
    IsGLB ({f, g} : Set (StableHom D E)) (homPointwiseInf f g) := by
  obtain ⟨U, hfU, hgU⟩ := hcomp
  constructor
  · intro h hh
    rcases Set.mem_insert_iff.mp hh with hh | hh
    · subst h
      exact pointwiseInfMap_stableLE_left E.isDIDomain.toIsScottDomain.algebraic
        f.toStableMap g.toStableMap U.toStableMap
        ((hom_le_iff_raw f U).mp hfU) ((hom_le_iff_raw g U).mp hgU)
    · have heq : h = g := Set.mem_singleton_iff.mp hh
      subst h
      exact pointwiseInfMap_stableLE_right E.isDIDomain.toIsScottDomain.algebraic
        f.toStableMap g.toStableMap U.toStableMap
        ((hom_le_iff_raw f U).mp hfU) ((hom_le_iff_raw g U).mp hgU)
  · intro h hh
    exact stableLE_pointwiseInfMap E.isDIDomain.toIsScottDomain.algebraic
      f.toStableMap g.toStableMap h.toStableMap
      ((hom_le_iff_raw h f).mp (hh (by simp)))
      ((hom_le_iff_raw h g).mp (hh (by simp)))

theorem hom_isGLB_pair_iff_values (f g : StableHom D E) (hcomp : Compatible f g)
    (m : StableHom D E) :
    IsGLB ({f, g} : Set (StableHom D E)) m ↔ ∀ x : D, m x = f x ⊓ g x := by
  constructor
  · intro hm
    have heq : m = homPointwiseInf f g := hm.unique (homPointwiseInf_isGLB f g hcomp)
    intro x
    rw [heq]
    exact homPointwiseInf_apply f g x
  · intro hm
    have heq : m = homPointwiseInf f g := StableHom.ext
      (fun x => (hm x).trans (homPointwiseInf_apply f g x).symm)
    rw [heq]
    exact homPointwiseInf_isGLB f g hcomp

end Hom

end DIDomainClassification.StableHomPointwiseSupport
