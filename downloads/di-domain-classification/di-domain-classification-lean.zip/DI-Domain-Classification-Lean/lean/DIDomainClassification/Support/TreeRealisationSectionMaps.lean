import DIDomainClassification.Support.TreeRealisationConfigurations

/-! The literal section is monotone in the ACTUAL stable order, including
mixed finite/whole-branch comparisons, and respects the required unions/meets. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeRealisationSectionMaps

open Preliminaries EventStructures Trees OrderCore
open Section04.TreeRealisationModels Section04.AdditionalSourceModels
open TreeRealisationGeometry TreeRealisationConfigurations

variable {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A)
  {B : Type v} (T : RootedPrefixTree B) (L : T.Node → Set A)

theorem branchSection_mono_input {X Y : Set T.Node} (hXY : X ⊆ Y)
    (b : T.InfiniteBranch) : branchSection T L X b ⊆ branchSection T L Y b := by
  rintro a ⟨z, hz, ha⟩
  exact ⟨z, hz, nodeSection_mono_input T L hXY z ha⟩

theorem nodeSection_union (C : Set (TreeDomain T)) (hne : C.Nonempty) (z : T.Node) :
    nodeSection T L (treeUnion T C) z =
      {a | ∃ X ∈ C, a ∈ nodeSection T L X.val z} := by
  ext a
  constructor
  · rintro (haB | ⟨w, hwz, hwC, haw⟩)
    · obtain ⟨X, hX⟩ := hne
      exact ⟨X, hX, Or.inl haB⟩
    · obtain ⟨X, hX, hwX⟩ := hwC
      exact ⟨X, hX, Or.inr ⟨w, hwz, hwX, haw⟩⟩
  · rintro ⟨X, hX, haB | ⟨w, hwz, hwX, haw⟩⟩
    · exact Or.inl haB
    · exact Or.inr ⟨w, hwz, ⟨X, hX, hwX⟩, haw⟩

theorem branchSection_union (C : Set (TreeDomain T)) (hne : C.Nonempty)
    (b : T.InfiniteBranch) :
    branchSection T L (treeUnion T C) b =
      {a | ∃ X ∈ C, a ∈ branchSection T L X.val b} := by
  ext a
  constructor
  · rintro ⟨z, hz, ha⟩
    rw [nodeSection_union T L C hne z] at ha
    obtain ⟨X, hX, haX⟩ := ha
    exact ⟨X, hX, z, hz, haX⟩
  · rintro ⟨X, hX, z, hz, haX⟩
    refine ⟨z, hz, ?_⟩
    rw [nodeSection_union T L C hne z]
    exact ⟨X, hX, haX⟩

variable (hL : BlockCondition T E L) (hp : T.IsProper)
include hL hp

theorem branchSection_inter (X Y : Set T.Node) (b : T.InfiniteBranch) :
    branchSection T L (X ∩ Y) b = branchSection T L X b ∩ branchSection T L Y b := by
  ext a
  constructor
  · rintro ⟨z, hz, ha⟩
    rw [nodeSection_inter T L E hL hp X Y z] at ha
    exact ⟨⟨z, hz, ha.1⟩, ⟨z, hz, ha.2⟩⟩
  · rintro ⟨⟨x, ⟨m, rfl⟩, haX⟩, ⟨y, ⟨n, rfl⟩, haY⟩⟩
    refine ⟨b.node (max m n), ⟨max m n, rfl⟩, ?_⟩
    rw [nodeSection_inter T L E hL hp X Y _]
    exact ⟨nodeSection_mono_node T L X (b.monotone T (le_max_left _ _)) haX,
      nodeSection_mono_node T L Y (b.monotone T (le_max_right _ _)) haY⟩

theorem branch_cross_inter {X Y : Set T.Node} (hXY : X ⊆ Y)
    (b : T.InfiniteBranch) (x : T.Node) (hx : x ∈ Set.range b.node) :
    branchSection T L X b ∩ nodeSection T L Y x = nodeSection T L X x := by
  obtain ⟨m, rfl⟩ := hx
  ext a
  constructor
  · rintro ⟨⟨z, ⟨n, rfl⟩, haX⟩, haY⟩
    apply (finite_cross_inter T L E hL hp hXY (b.monotone T (le_max_right n m))).subset
    exact ⟨nodeSection_mono_node T L X (b.monotone T (le_max_left n m)) haX, haY⟩
  · intro ha
    exact ⟨⟨b.node m, ⟨m, rfl⟩, ha⟩, nodeSection_mono_input T L hXY _ ha⟩

theorem section_pointwise_mono {X Y : TreeDomain T} (hXY : X ≤ Y)
    (z : completionCore T hp) :
    (sectionFunction E T L hL hp X z).val ⊆
      (sectionFunction E T L hL hp Y z).val := by
  rcases z with z | b
  · simpa only [section_inl] using nodeSection_mono_input T L hXY z
  · simpa only [section_inr] using branchSection_mono_input T L hXY b

theorem section_monotone : Monotone (sectionFunction E T L hL hp) := by
  intro X Y hXY x y hxy
  apply Subtype.ext
  change (sectionFunction E T L hL hp X x).val =
    (sectionFunction E T L hL hp X y ⊓ sectionFunction E T L hL hp Y x :
      causalConfigurationCore E).val
  rw [CausalCoverSupport.configuration_inf_val]
  rcases x with x | b <;> rcases y with y | c
  · change x ≤ y at hxy
    simpa only [section_inl] using (finite_cross_inter T L E hL hp hXY hxy).symm
  · change x ∈ Set.range c.node at hxy
    simpa only [section_inl, section_inr] using
      (branch_cross_inter E T L hL hp hXY c x hxy).symm
  · exact False.elim hxy
  · change b = c at hxy
    subst c
    simpa only [section_inr] using
      (Set.inter_eq_left.mpr (branchSection_mono_input T L hXY b)).symm

theorem section_inter_values (hT : IsDIDomain (TreeDomain T))
    (X Y : TreeDomain T) (z : completionCore T hp) :
    (sectionFunction E T L hL hp (hT.toIsScottDomain.inf X Y) z).val =
      (sectionFunction E T L hL hp X z).val ∩ (sectionFunction E T L hL hp Y z).val := by
  rcases z with x | b
  · simp only [section_inl]
    exact (congrArg (fun V : Set T.Node => nodeSection T L V x)
      (tree_inf_values T hT X Y)).trans (nodeSection_inter T L E hL hp X.val Y.val x)
  · simp only [section_inr]
    exact (congrArg (fun V : Set T.Node => branchSection T L V b)
      (tree_inf_values T hT X Y)).trans (branchSection_inter E T L hL hp X.val Y.val b)

theorem section_union_values (C : Set (TreeDomain T)) (hne : C.Nonempty)
    (X : TreeDomain T) (hX : IsLUB C X) (z : completionCore T hp) :
    (sectionFunction E T L hL hp X z).val =
      {a | ∃ Y ∈ C, a ∈ (sectionFunction E T L hL hp Y z).val} := by
  rcases z with x | b
  · simp only [section_inl]
    rw [tree_isLUB_values T C X hX]
    exact nodeSection_union T L C hne x
  · simp only [section_inr]
    rw [tree_isLUB_values T C X hX]
    exact branchSection_union T L C hne b

end DIDomainClassification.TreeRealisationSectionMaps
