import DIDomainClassification.Support.ForestProductMaps

/-!
Source proof-only claim (manuscript.tex, lines 1887--1890): the compact
elements of the literal powerset of the natural numbers are exactly its
finite subsets. The historical carrier is ULift (Set Nat), not a substitute
domain. Both the unlifted characterization and the ULift bridge are proved.

This reuses the finite-configuration compactness theorem through the existing
empty-forbidden-family powerset order isomorphism; it assumes neither the
classification theorem nor the infinite-category generation conclusion.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PowersetCompactElements

open OrderCore Preliminaries Section04.AdditionalSourceModels

/-- Unlifted powerset compactness, for arbitrary event types. -/
theorem raw_compact_iff_finite {A : Type v} (X : Set A) :
    OrderCore.Compact X ↔ X.Finite := by
  let e := ForestProductMaps.powersetOrderIso A
  have hCompact := OrderIsoTransport.compact_iff e.symm X
  exact hCompact.symm.trans
    (ForbiddenFiniteDomains.compact_iff_finite ∅
      (ForestProductMaps.emptyAdmissible A) (e.symm X))

/-- The exact historical ULift carrier preserves intrinsic compactness. -/
theorem compact_iff_down_compact (X : NatPowersetCarrier.{u}) :
    OrderCore.Compact X ↔ OrderCore.Compact X.down :=
  (OrderIsoTransport.compact_iff (ForestProductMaps.liftOrderIso (Set ℕ)) X).symm

/-- Source-facing equality K(P(N)) = P_fin(N), stated pointwise on the
literal source carrier with its actual subset order. -/
theorem isCompactElement_iff_finite (X : NatPowersetCarrier.{u}) :
    IsCompactElement X ↔ X.down.Finite :=
  (compact_iff_down_compact X).trans (raw_compact_iff_finite X.down)

/-- Exact local proof-step proposition, not an assumed certificate field. -/
def Goal : Prop :=
  ∀ X : NatPowersetCarrier.{u}, IsCompactElement X ↔ X.down.Finite

/-- A public certificate for the source's compact-element identification. -/
theorem certificate : Goal.{u} := isCompactElement_iff_finite

end DIDomainClassification.PowersetCompactElements
