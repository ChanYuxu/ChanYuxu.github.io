import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.StableFunctionSpaces

/-!
# Literal fixed-point construction for stable continuous idempotents

Staged generic support, not a source-theorem acceptance or an interface change.
The carrier starts as the inherited-order subtype, with no domain properties
assumed of it. No strictness, EP inequality or arbitrary compact-image claim.
The directed-supremum proof adapts the actually inspected AJ continuous-image
argument to the accepted narrow predicates and the literal fixed-point subtype.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.StableIdempotentClosure

open OrderCore
open Preliminaries (IsScottDomain IsDIDomain CompactElements CompatibleJoinDistributive)

variable {D : Type u} [PartialOrder D]

abbrev Fixed (f : D → D) := {x : D // f x = x}

/-- The literal idempotence equation; no absent library alias is presumed. -/
def Idempotent (f : D → D) : Prop := ∀ x : D, f (f x) = f x

def project (f : D → D) (hid : Idempotent f) (x : D) : Fixed f :=
  ⟨f x, hid x⟩

omit [PartialOrder D] in
@[simp] theorem project_val (f : D → D) (hid : Idempotent f) (x : D) :
    (project f hid x : D) = f x := rfl

omit [PartialOrder D] in
@[simp] theorem project_fixed (f : D → D) (hid : Idempotent f) (x : Fixed f) :
    project f hid (x : D) = x := Subtype.ext x.property

theorem project_monotone {f : D → D} (hf : ScottContinuous f) (hid : Idempotent f) :
    Monotone (project f hid) := fun _ _ h => hf.monotone h

theorem fixed_isSup_of_ambient {f : D → D} {A : Set (Fixed f)} {s : Fixed f}
    (hs : IsSup (Subtype.val '' A) s.val) : IsSup A s := by
  constructor
  · intro x hx
    exact hs.1 ⟨x, hx, rfl⟩
  · intro y hy
    exact hs.2 y.val (by rintro _ ⟨x, hx, rfl⟩; exact hy hx)

/-- Directed suprema of fixed points are fixed in the ambient order. -/
theorem ambient_directed_sup_fixed {f : D → D} (hf : ScottContinuous f)
    {A : Set (Fixed f)} (hA : DirectedSet A) {s : D}
    (hs : IsSup (Subtype.val '' A) s) : f s = s := by
  have hdir : DirectedSet (Subtype.val '' A) := hA.image (fun _ _ h => h)
  have heq : f '' (Subtype.val '' A) = Subtype.val '' A := by
    ext x
    constructor
    · rintro ⟨_, ⟨a, ha, rfl⟩, rfl⟩
      exact ⟨a, ha, a.property.symm⟩
    · rintro ⟨a, ha, rfl⟩
      exact ⟨a.val, ⟨a, ha, rfl⟩, a.property⟩
  have hfsup : IsSup (Subtype.val '' A) (f s) := by
    simpa only [heq] using scottContinuous_isSup hf hdir hs
  exact le_antisymm (hfsup.2 s hs.1) (hs.2 (f s) hfsup.1)

theorem fixed_isDcpo {f : D → D} (hD : IsDcpo D) (hf : ScottContinuous f) :
    IsDcpo (Fixed f) := by
  intro A hA
  obtain ⟨s, hs⟩ := hD (Subtype.val '' A) (hA.image (fun _ _ h => h))
  exact ⟨⟨s, ambient_directed_sup_fixed hf hA hs⟩, fixed_isSup_of_ambient hs⟩

theorem ambient_isSup_of_fixed {f : D → D} (hD : IsDcpo D) (hf : ScottContinuous f)
    {A : Set (Fixed f)} (hA : DirectedSet A) {s : Fixed f} (hs : IsSup A s) :
    IsSup (Subtype.val '' A) s.val := by
  obtain ⟨t, ht⟩ := hD (Subtype.val '' A) (hA.image (fun _ _ h => h))
  let z : Fixed f := ⟨t, ambient_directed_sup_fixed hf hA ht⟩
  have hz : IsSup A z := fixed_isSup_of_ambient ht
  have heq : z = s := le_antisymm (hz.2 s hs.1) (hs.2 z hz.1)
  have hval : t = s.val := congrArg Subtype.val heq
  simpa only [hval] using ht

theorem inclusion_scottContinuous {f : D → D} (hD : IsDcpo D) (hf : ScottContinuous f) :
    ScottContinuous (Subtype.val : Fixed f → D) := by
  intro A hne hdir s hs
  exact ambient_isSup_of_fixed hD hf ⟨hne, hdir⟩ hs

theorem project_scottContinuous {f : D → D} (hf : ScottContinuous f)
    (hid : Idempotent f) : ScottContinuous (project f hid) := by
  intro A hne hdir s hs
  apply fixed_isSup_of_ambient
  simpa only [Set.image_image, project] using
    scottContinuous_isSup hf ⟨hne, hdir⟩ hs

theorem fixed_hasLeast {f : D → D} (hD : IsScottDomain D) (hf : ScottContinuous f)
    (hid : Idempotent f) : ∃ b : Fixed f, ∀ x, b ≤ x := by
  refine ⟨project f hid hD.bottom, ?_⟩
  intro x
  have h := hf.monotone (hD.bottom_le x.val)
  simpa only [project_val, x.property] using h

theorem fixed_boundedSuprema {f : D → D} (hD : IsScottDomain D) (hf : ScottContinuous f)
    (hid : Idempotent f) (A : Set (Fixed f)) (hA : BddAbove A) :
    ∃ s : Fixed f, IsLUB A s := by
  obtain ⟨b, hb⟩ := hA
  have hB : BddAbove (Subtype.val '' A) :=
    ⟨b.val, by rintro _ ⟨a, ha, rfl⟩; exact hb ha⟩
  obtain ⟨t, ht⟩ := hD.boundedSuprema (Subtype.val '' A) hB
  refine ⟨project f hid t, ?_, ?_⟩
  · intro a ha
    have h := hf.monotone (ht.1 ⟨a, ha, rfl⟩)
    simpa only [a.property, project_val] using h
  · intro z hz
    have htz : t ≤ z.val := ht.2 (by rintro _ ⟨a, ha, rfl⟩; exact hz ha)
    have h := hf.monotone htz
    simpa only [z.property, project_val] using h

theorem fixed_compatible_iff {f : D → D} (hf : ScottContinuous f)
    (hid : Idempotent f) (x y : Fixed f) :
    Compatible x y ↔ Compatible x.val y.val := by
  constructor
  · rintro ⟨z, hxz, hyz⟩
    exact ⟨z.val, hxz, hyz⟩
  · rintro ⟨z, hxz, hyz⟩
    refine ⟨project f hid z, ?_, ?_⟩
    · simpa only [x.property, project_val] using hf.monotone hxz
    · simpa only [y.property, project_val] using hf.monotone hyz

/-- Intrinsic meet preservation, later bridged to actual StableHom equations. -/
def PreservesCompatibleInfima (f : D → D) : Prop :=
  ∀ x y m : D, Compatible x y → IsGLB ({x, y} : Set D) m →
    IsGLB ({f x, f y} : Set D) (f m)

theorem map_inf {f : D → D} (hD : IsScottDomain D)
    (hstable : PreservesCompatibleInfima f) (x y : D) (hxy : Compatible x y) :
    f (hD.inf x y) = hD.inf (f x) (f y) :=
  (hstable x y (hD.inf x y) hxy (hD.inf_isGLB x y)).unique (hD.inf_isGLB (f x) (f y))

/-- This compact-image lemma has the essential postfixed-input premise. -/
theorem compact_project_of_postfixed {f : D → D} (hD : IsDcpo D)
    (hf : ScottContinuous f) (hid : Idempotent f) {a : D}
    (ha : Compact a) (hpost : a ≤ f a) : Compact (project f hid a) := by
  intro A s hA hs hfs
  have hamb := ambient_isSup_of_fixed hD hf hA hs
  obtain ⟨_, ⟨b, hb, rfl⟩, hab⟩ :=
    ha (hA.image (fun _ _ h => h)) hamb (hpost.trans hfs)
  refine ⟨b, hb, ?_⟩
  simpa only [b.property, project_val] using hf.monotone hab

/-- A compact input below a fixed point is adjusted to k ∧ f(k) before the
postfixed compact-image lemma is used. Arbitrary compact images are not used. -/
theorem compact_project_below_fixed {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) {k : D} (hk : Compact k)
    (y : Fixed f) (hky : k ≤ y.val) : Compact (project f hid k) := by
  let S := hD.toIsScottDomain
  have hcompat : Compatible k (f k) := by
    refine ⟨y.val, hky, ?_⟩
    simpa only [y.property] using hf.monotone hky
  have ha : Compact (S.inf k (f k)) :=
    compact_of_finite_principal_ideal S.algebraic
      (hD.finitePrincipalIdeals k hk) (S.inf_le_left k (f k))
  have hfa : f (S.inf k (f k)) = f k := by
    rw [map_inf S hstable k (f k) hcompat, hid k]
    exact le_antisymm (S.inf_le_left _ _) (S.le_inf le_rfl le_rfl)
  have hpost : S.inf k (f k) ≤ f (S.inf k (f k)) := by
    rw [hfa]
    exact S.inf_le_right k (f k)
  have hcompact := compact_project_of_postfixed S.algebraic.1 hf hid ha hpost
  have heq : project f hid (S.inf k (f k)) = project f hid k := Subtype.ext hfa
  simpa only [heq] using hcompact

def imageApproximants (f : D → D) (hid : Idempotent f) (y : Fixed f) : Set (Fixed f) :=
  project f hid '' CompactBelow y.val

theorem imageApproximants_directed {f : D → D} (hD : IsAlgebraicDcpo D)
    (hf : ScottContinuous f) (hid : Idempotent f) (y : Fixed f) :
    DirectedSet (imageApproximants f hid y) :=
  (hD.2 y.val).1.image (project_monotone hf hid)

theorem imageApproximants_isSup {f : D → D} (hD : IsAlgebraicDcpo D)
    (hf : ScottContinuous f) (hid : Idempotent f) (y : Fixed f) :
    IsSup (imageApproximants f hid y) y := by
  have h := scottContinuous_isSup (project_scottContinuous hf hid)
    (hD.2 y.val).1 (hD.2 y.val).2
  simpa only [project_fixed] using h

theorem imageApproximants_subset_compactBelow {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) (y : Fixed f) :
    imageApproximants f hid y ⊆ CompactBelow y := by
  rintro _ ⟨k, hk, rfl⟩
  refine ⟨compact_project_below_fixed hD hf hid hstable hk.1 y hk.2, ?_⟩
  simpa only [project_val, y.property] using hf.monotone hk.2

/-- The full actual compact-below set is directed and has the required sup;
the chosen image approximants are only an intermediate cofinal family. -/
theorem fixed_isAlgebraicDcpo {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) : IsAlgebraicDcpo (Fixed f) := by
  refine ⟨fixed_isDcpo hD.toIsScottDomain.algebraic.1 hf, ?_⟩
  intro y
  let B := imageApproximants f hid y
  have hBdir : DirectedSet B := imageApproximants_directed hD.toIsScottDomain.algebraic hf hid y
  have hBsup : IsSup B y := imageApproximants_isSup hD.toIsScottDomain.algebraic hf hid y
  have hBsub : B ⊆ CompactBelow y := imageApproximants_subset_compactBelow hD hf hid hstable y
  have hcofinal : ∀ c ∈ CompactBelow y, ∃ b ∈ B, c ≤ b := by
    intro c hc
    exact hc.1 hBdir hBsup hc.2
  constructor
  · constructor
    · obtain ⟨b, hb⟩ := hBdir.1
      exact ⟨b, hBsub hb⟩
    · intro c hc d hd
      obtain ⟨b, hb, hcb⟩ := hcofinal c hc
      obtain ⟨e, he, hde⟩ := hcofinal d hd
      obtain ⟨a, ha, hba, hea⟩ := hBdir.2 hb he
      exact ⟨a, hBsub ha, hcb.trans hba, hde.trans hea⟩
  · constructor
    · intro c hc
      exact hc.2
    · intro z hz
      exact hBsup.2 z (fun b hb => hz (hBsub hb))

theorem fixed_compact_iff {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) (c : Fixed f) :
    Compact c ↔ ∃ k : D, Compact k ∧ k ≤ c.val ∧ f k = c.val := by
  constructor
  · intro hc
    obtain ⟨_, ⟨k, hk, rfl⟩, hck⟩ := hc
      (imageApproximants_directed hD.toIsScottDomain.algebraic hf hid c)
      (imageApproximants_isSup hD.toIsScottDomain.algebraic hf hid c) le_rfl
    have hkc : f k ≤ c.val := by simpa only [c.property] using hf.monotone hk.2
    exact ⟨k, hk.1, hk.2, le_antisymm hkc hck⟩
  · rintro ⟨k, hk, hkc, hfk⟩
    have h := compact_project_below_fixed hD hf hid hstable hk c hkc
    have heq : project f hid k = c := Subtype.ext hfk
    simpa only [heq] using h

theorem fixed_isScottDomain {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) : IsScottDomain (Fixed f) where
  algebraic := fixed_isAlgebraicDcpo hD hf hid hstable
  hasLeast := fixed_hasLeast hD.toIsScottDomain hf hid
  boundedSuprema := fixed_boundedSuprema hD.toIsScottDomain hf hid

theorem fixed_finitePrincipalIdeals {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) (c : Fixed f) (hc : Compact c) :
    (Set.Iic c).Finite := by
  obtain ⟨k, hk, hkc, hfk⟩ := (fixed_compact_iff hD hf hid hstable c).mp hc
  let S := hD.toIsScottDomain
  let j : Fixed f → D := fun x => S.inf k x.val
  have recover : ∀ x ∈ Set.Iic c, f (j x) = x.val := by
    intro x hx
    have hcompat : Compatible k x.val := ⟨c.val, hkc, hx⟩
    change f (S.inf k x.val) = x.val
    rw [map_inf S hstable k x.val hcompat, hfk, x.property]
    exact le_antisymm (S.inf_le_right _ _) (S.le_inf hx le_rfl)
  apply Set.Finite.of_injOn (f := j) (s := Set.Iic c) (t := Set.Iic k)
    (fun x _ => S.inf_le_left k x.val) ?_ (hD.finitePrincipalIdeals k hk)
  intro x hx y hy hxy
  apply Subtype.ext
  have h := congrArg f hxy
  simpa only [recover x hx, recover y hy] using h

theorem fixed_compact_countable {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) (hK : (CompactElements D).Countable) :
    (CompactElements (Fixed f)).Countable := by
  apply (hK.image (project f hid)).mono
  intro c hc
  obtain ⟨k, hk, _hkc, hfk⟩ := (fixed_compact_iff hD hf hid hstable c).mp hc
  exact ⟨k, hk, Subtype.ext hfk⟩

theorem fixed_isLUB_project {f : D → D} (hf : ScottContinuous f) (hid : Idempotent f)
    {A : Set (Fixed f)} {t : D} (ht : IsLUB (Subtype.val '' A) t) :
    IsLUB A (project f hid t) := by
  constructor
  · intro a ha
    simpa only [a.property, project_val] using hf.monotone (ht.1 ⟨a, ha, rfl⟩)
  · intro z hz
    have htz : t ≤ z.val := ht.2 (by rintro _ ⟨a, ha, rfl⟩; exact hz ha)
    simpa only [z.property, project_val] using hf.monotone htz

theorem fixed_isGLB_of_ambient {f : D → D} {A : Set (Fixed f)} {s : Fixed f}
    (hs : IsGLB (Subtype.val '' A) s.val) : IsGLB A s := by
  constructor
  · intro x hx
    exact hs.1 ⟨x, hx, rfl⟩
  · intro y hy
    exact hs.2 (by rintro _ ⟨x, hx, rfl⟩; exact hy hx)

theorem compatible_ambient_inf_fixed {f : D → D} (hD : IsScottDomain D)
    (hstable : PreservesCompatibleInfima f) (x y : Fixed f) (hxy : Compatible x y) :
    f (hD.inf x.val y.val) = hD.inf x.val y.val := by
  obtain ⟨z, hxz, hyz⟩ := hxy
  rw [map_inf hD hstable x.val y.val ⟨z.val, hxz, hyz⟩, x.property, y.property]

/-- Ambient meets coincide with fixed-point meets only for compatible pairs. -/
theorem ambient_isGLB_of_compatible_fixed {f : D → D} (hD : IsScottDomain D)
    (hstable : PreservesCompatibleInfima f) {x y m : Fixed f}
    (hxy : Compatible x y) (hm : IsGLB ({x, y} : Set (Fixed f)) m) :
    IsGLB ({x.val, y.val} : Set D) m.val := by
  let a : Fixed f := ⟨hD.inf x.val y.val, compatible_ambient_inf_fixed hD hstable x y hxy⟩
  have ha : IsGLB ({x, y} : Set (Fixed f)) a := by
    apply fixed_isGLB_of_ambient
    simpa only [Set.image_insert_eq, Set.image_singleton] using hD.inf_isGLB x.val y.val
  have heq : a = m := ha.unique hm
  have hval : hD.inf x.val y.val = m.val := congrArg Subtype.val heq
  simpa only [hval] using hD.inf_isGLB x.val y.val

/-- The exact compatible-pair / arbitrary-third distributivity law.
Stability is used with t,w below q, never with possibly incompatible t,z. -/
theorem fixed_distributive {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) : CompatibleJoinDistributive (Fixed f) := by
  intro x y z joined meet left right hxy hj hm hl hr
  let S := hD.toIsScottDomain
  have hxyD : Compatible x.val y.val := (fixed_compatible_iff hf hid x y).mp hxy
  let t : D := S.join x.val y.val hxyD
  have ht : IsLUB ({x.val, y.val} : Set D) t := S.join_isLUB x.val y.val hxyD
  have hqt : IsLUB ({x, y} : Set (Fixed f)) (project f hid t) := by
    apply fixed_isLUB_project hf hid
    simpa only [Set.image_insert_eq, Set.image_singleton] using ht
  have hq : project f hid t = joined := hqt.unique hj
  have hft : f t = joined.val := congrArg Subtype.val hq
  have hxq : x ≤ joined := hj.1 (by simp)
  have hyq : y ≤ joined := hj.1 (by simp)
  have hwq : meet ≤ joined := hm.1 (by simp)
  have hwz : meet ≤ z := hm.1 (by simp)
  have htq : t ≤ joined.val := by
    apply ht.2
    intro a ha
    rcases Set.mem_insert_iff.mp ha with rfl | ha
    · exact hxq
    · simpa only [Set.mem_singleton_iff.mp ha] using hyq
  have htw : Compatible t meet.val := ⟨joined.val, htq, hwq⟩
  have hfm : f (S.inf t meet.val) = meet.val := by
    rw [map_inf S hstable t meet.val htw, hft, meet.property]
    exact le_antisymm (S.inf_le_right _ _) (S.le_inf hwq le_rfl)
  have hfixa : f (S.inf x.val meet.val) = S.inf x.val meet.val := by
    rw [map_inf S hstable x.val meet.val ⟨joined.val, hxq, hwq⟩,
      x.property, meet.property]
  have hfixb : f (S.inf y.val meet.val) = S.inf y.val meet.val := by
    rw [map_inf S hstable y.val meet.val ⟨joined.val, hyq, hwq⟩,
      y.property, meet.property]
  let a : Fixed f := ⟨S.inf x.val meet.val, hfixa⟩
  let b : Fixed f := ⟨S.inf y.val meet.val, hfixb⟩
  have hal : a ≤ left := by
    apply hl.2
    intro p hp
    rcases Set.mem_insert_iff.mp hp with rfl | hp
    · exact S.inf_le_left _ _
    · simpa only [Set.mem_singleton_iff.mp hp] using
        (S.inf_le_right x.val meet.val).trans hwz
  have hbr : b ≤ right := by
    apply hr.2
    intro p hp
    rcases Set.mem_insert_iff.mp hp with rfl | hp
    · exact S.inf_le_left _ _
    · simpa only [Set.mem_singleton_iff.mp hp] using
        (S.inf_le_right y.val meet.val).trans hwz
  have hd : IsLUB ({a.val, b.val} : Set D) (S.inf t meet.val) :=
    hD.distributive x.val y.val meet.val t (S.inf t meet.val) a.val b.val
      hxyD ht (S.inf_isGLB t meet.val) (S.inf_isGLB x.val meet.val)
      (S.inf_isGLB y.val meet.val)
  have hlw : left ≤ meet := by
    apply hm.2
    intro p hp
    rcases Set.mem_insert_iff.mp hp with rfl | hp
    · exact (hl.1 (by simp)).trans hxq
    · simpa only [Set.mem_singleton_iff.mp hp] using hl.1 (by simp)
  have hrw : right ≤ meet := by
    apply hm.2
    intro p hp
    rcases Set.mem_insert_iff.mp hp with rfl | hp
    · exact (hr.1 (by simp)).trans hyq
    · simpa only [Set.mem_singleton_iff.mp hp] using hr.1 (by simp)
  constructor
  · intro p hp
    rcases Set.mem_insert_iff.mp hp with rfl | hp
    · exact hlw
    · simpa only [Set.mem_singleton_iff.mp hp] using hrw
  · intro p hp
    have hmp : S.inf t meet.val ≤ p.val := by
      apply hd.2
      intro d hdab
      rcases Set.mem_insert_iff.mp hdab with rfl | hdab
      · exact hal.trans (hp (by simp))
      · simpa only [Set.mem_singleton_iff.mp hdab] using hbr.trans (hp (by simp))
    simpa only [hfm, p.property] using hf.monotone hmp

theorem fixed_isDIDomain {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) : IsDIDomain (Fixed f) where
  toIsScottDomain := fixed_isScottDomain hD hf hid hstable
  distributive := fixed_distributive hD hf hid hstable
  finitePrincipalIdeals := fixed_finitePrincipalIdeals hD hf hid hstable

/-- For arbitrary fixed pairs, including incompatible pairs, the image meet
is f of the ambient meet; it is not silently replaced by the ambient meet. -/
theorem fixed_inf_project_isGLB {f : D → D} (hD : IsScottDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (x y : Fixed f) :
    IsGLB ({x, y} : Set (Fixed f)) (project f hid (hD.inf x.val y.val)) := by
  constructor
  · intro z hz
    have hz' : z.val ∈ ({x.val, y.val} : Set D) := by
      have hmem : z.val ∈ Subtype.val '' ({x, y} : Set (Fixed f)) := ⟨z, hz, rfl⟩
      simpa only [Set.image_insert_eq, Set.image_singleton] using hmem
    simpa only [z.property, project_val] using hf.monotone ((hD.inf_isGLB x.val y.val).1 hz')
  · intro a ha
    have hle : a.val ≤ hD.inf x.val y.val := hD.le_inf (ha (by simp)) (ha (by simp))
    simpa only [a.property, project_val] using hf.monotone hle

theorem fixed_inf_val {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) (x y : Fixed f) :
    ((fixed_isScottDomain hD hf hid hstable).inf x y).val =
      f (hD.toIsScottDomain.inf x.val y.val) := by
  have heq := ((fixed_isScottDomain hD hf hid hstable).inf_isGLB x y).unique
    (fixed_inf_project_isGLB hD.toIsScottDomain hf hid x y)
  exact congrArg Subtype.val heq

theorem fixed_bottom_val {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) :
    ((fixed_isScottDomain hD hf hid hstable).bottom : D) = f hD.toIsScottDomain.bottom := by
  let b := project f hid hD.toIsScottDomain.bottom
  have hb : ∀ x : Fixed f, b ≤ x := by
    intro x
    simpa only [x.property, project_val] using hf.monotone (hD.toIsScottDomain.bottom_le x.val)
  have heq : (fixed_isScottDomain hD hf hid hstable).bottom = b :=
    le_antisymm ((fixed_isScottDomain hD hf hid hstable).bottom_le b) (hb _)
  exact congrArg Subtype.val heq

theorem fixed_isCountablyBasedDIDomain {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) (hK : (CompactElements D).Countable) :
    Preliminaries.IsCountablyBasedDIDomain (Fixed f) :=
  ⟨fixed_isDIDomain hD hf hid hstable, fixed_compact_countable hD hf hid hstable hK⟩

/-- Bridge from the actual accepted stable-map equations to intrinsic GLBs. -/
theorem stableHom_preservesCompatibleInfima (X : DIDomainObject.{u}) (f : StableHom X X) :
    PreservesCompatibleInfima (f : X → X) := by
  intro x y m hxy hm
  have heq := hm.unique (DIDomainObject.inf_isGLB X x y)
  rw [heq, (StableHom.isStable f).2 x y hxy]
  exact DIDomainObject.inf_isGLB X (f x) (f y)

theorem preservesCompatibleInfima_iff_map_inf {f : D → D} (hD : IsScottDomain D) :
    PreservesCompatibleInfima f ↔
      ∀ x y : D, Compatible x y → f (hD.inf x y) = hD.inf (f x) (f y) := by
  constructor
  · intro h x y hxy
    exact map_inf hD h x y hxy
  · intro h x y m hxy hm
    have heq := hm.unique (hD.inf_isGLB x y)
    rw [heq, h x y hxy]
    exact hD.inf_isGLB (f x) (f y)

theorem fixed_isDIDomain_of_stableHom (X : DIDomainObject.{u}) (f : StableHom X X)
    (hid : Idempotent (f : X → X)) : IsDIDomain (Fixed (f : X → X)) :=
  fixed_isDIDomain X.isDIDomain (StableHom.isStable f).1 hid
    (stableHom_preservesCompatibleInfima X f)

/-- The target object is bundled only after its full intrinsic dI proof. -/
noncomputable def fixedObject {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f)
    (hstable : PreservesCompatibleInfima f) : DIDomainObject.{u} :=
  DIDomainObject.ofType (Fixed f) (fixed_isDIDomain hD hf hid hstable)

theorem inclusion_isStable {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) :
    IsStable (fixedObject hD hf hid hstable) (DIDomainObject.ofType D hD)
      (fun x => x.val) := by
  constructor
  · exact inclusion_scottContinuous hD.toIsScottDomain.algebraic.1 hf
  · intro x y hxy
    exact (ambient_isGLB_of_compatible_fixed hD.toIsScottDomain hstable hxy
      (DIDomainObject.inf_isGLB (fixedObject hD hf hid hstable) x y)).unique
      (DIDomainObject.inf_isGLB (DIDomainObject.ofType D hD) x.val y.val)

theorem project_isStable {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) :
    IsStable (DIDomainObject.ofType D hD) (fixedObject hD hf hid hstable) (project f hid) := by
  constructor
  · exact project_scottContinuous hf hid
  · intro x y hxy
    have hpc : Compatible (project f hid x) (project f hid y) := by
      obtain ⟨z, hxz, hyz⟩ := hxy
      exact ⟨project f hid z, hf.monotone hxz, hf.monotone hyz⟩
    have htarget := ambient_isGLB_of_compatible_fixed hD.toIsScottDomain hstable hpc
      (DIDomainObject.inf_isGLB (fixedObject hD hf hid hstable) (project f hid x) (project f hid y))
    apply Subtype.ext
    exact (hstable x y _ hxy
      (DIDomainObject.inf_isGLB (DIDomainObject.ofType D hD) x y)).unique htarget

noncomputable def inclusionStableHom {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) :
    StableHom (fixedObject hD hf hid hstable) (DIDomainObject.ofType D hD) :=
  StableHom.ofFunction (fun x => x.val) (inclusion_isStable hD hf hid hstable)

noncomputable def projectStableHom {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) :
    StableHom (DIDomainObject.ofType D hD) (fixedObject hD hf hid hstable) :=
  StableHom.ofFunction (project f hid) (project_isStable hD hf hid hstable)

@[simp] theorem inclusionStableHom_apply {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f)
    (x : fixedObject hD hf hid hstable) : inclusionStableHom hD hf hid hstable x = x.val := rfl

@[simp] theorem projectStableHom_apply {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) (x : D) :
    projectStableHom hD hf hid hstable x = project f hid x := rfl

theorem stable_split_leftInverse {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) :
    Function.LeftInverse (projectStableHom hD hf hid hstable)
      (inclusionStableHom hD hf hid hstable) := by
  intro x
  exact project_fixed f hid x

theorem stable_split_composite {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) (x : D) :
    inclusionStableHom hD hf hid hstable (projectStableHom hD hf hid hstable x) = f x := rfl

noncomputable def stableRetraction {f : D → D} (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hid : Idempotent f) (hstable : PreservesCompatibleInfima f) :
    StableRetraction (fixedObject hD hf hid hstable) (DIDomainObject.ofType D hD) where
  sectionMap := (inclusionStableHom hD hf hid hstable).toStableMap
  retractionMap := (projectStableHom hD hf hid hstable).toStableMap
  leftInverse := stable_split_leftInverse hD hf hid hstable

end DIDomainClassification.StableIdempotentClosure
