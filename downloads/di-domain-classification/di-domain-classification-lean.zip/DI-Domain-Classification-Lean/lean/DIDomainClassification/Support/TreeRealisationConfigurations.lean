import DIDomainClassification.Support.TreeRealisationGeometry
import DIDomainClassification.Section04.BranchExtension
import DIDomainClassification.Section02.TreeDomainConstruction
import DIDomainClassification.Section04.CausalRetraction
import DIDomainClassification.Support.StableHomPointwiseSupport

/-! Actual union/meet computations and the public branch extension.
No countability hypothesis is imposed on the target event carrier. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeRealisationConfigurations

open Preliminaries EventStructures Trees OrderCore
open Section04 Section04.TreeRealisationModels Section04.AdditionalSourceModels
open TreeRealisationGeometry

variable {A : Type u} [PartialOrder A] (E : FinitaryPrimeEventStructure A)

def configUnion (C : Set (Configuration E)) : Set A :=
  {a | ∃ Y ∈ C, a ∈ Y.val}

theorem configuration_isLUB_values (C : Set (Configuration E)) (X : Configuration E)
    (hX : IsLUB C X) : X.val = configUnion E C := by
  have hsub : configUnion E C ⊆ X.val := by
    rintro a ⟨Y, hY, ha⟩
    exact hX.1 hY ha
  let U : Configuration E := ⟨configUnion E C, by
    constructor
    · rintro b a hab ⟨Y, hY, hb⟩
      exact ⟨Y, hY, Y.property.1 hab hb⟩
    · intro F hF hFU
      exact X.property.2 F hF (hFU.trans hsub)⟩
  have hXU : X ≤ U := hX.2 (fun Y hY a ha => ⟨Y, hY, ha⟩)
  exact Set.Subset.antisymm hXU hsub

theorem configuration_isLUB_of_values (C : Set (Configuration E)) (X : Configuration E)
    (hX : X.val = configUnion E C) : IsLUB C X := by
  constructor
  · intro Y hY a ha
    rw [hX]
    exact ⟨Y, hY, ha⟩
  · intro Y hY a ha
    rw [hX] at ha
    obtain ⟨Z, hZ, haZ⟩ := ha
    exact hY hZ haZ

/-- Use the actual public directed-configuration union theorem to compute a
supplied native LUB; this retains the original cited union route. -/
theorem configuration_directedLUB_values (C : Set (Configuration E))
    (hC : DirectedSet C) (X : Configuration E) (hX : IsLUB C X) :
    X.val = configUnion E C := by
  obtain ⟨Y, hY, hYLUB⟩ := configurationDirectedUnions A E C hC
  calc
    X.val = Y.val := congrArg Subtype.val (hX.unique hYLUB)
    _ = ⋃ Z ∈ C, Z.val := hY
    _ = configUnion E C := by
      ext a
      constructor
      · intro ha
        obtain ⟨Z, ha⟩ := Set.mem_iUnion.mp ha
        obtain ⟨hZ, haZ⟩ := Set.mem_iUnion.mp ha
        exact ⟨Z, hZ, haZ⟩
      · rintro ⟨Z, hZ, haZ⟩
        exact Set.mem_iUnion.mpr ⟨Z, Set.mem_iUnion.mpr ⟨hZ, haZ⟩⟩

variable {B : Type v} (T : RootedPrefixTree B)

def treeUnion (C : Set (TreeDomain T)) : Set T.Node :=
  {z | ∃ Y ∈ C, z ∈ Y.val}

theorem tree_isLUB_values (C : Set (TreeDomain T)) (X : TreeDomain T)
    (hX : IsLUB C X) : X.val = treeUnion T C := by
  have hsub : treeUnion T C ⊆ X.val := by
    rintro z ⟨Y, hY, hz⟩
    exact hX.1 hY hz
  let U : TreeDomain T := ⟨treeUnion T C,
    fun c hc hcu => X.property c hc (hcu.trans hsub)⟩
  have hXU : X ≤ U := hX.2 (fun Y hY z hz => ⟨Y, hY, hz⟩)
  exact Set.Subset.antisymm hXU hsub

theorem tree_inf_values (hT : IsDIDomain (TreeDomain T)) (X Y : TreeDomain T) :
    (hT.toIsScottDomain.inf X Y).val = X.val ∩ Y.val := by
  let Z : TreeDomain T := ⟨X.val ∩ Y.val,
    fun c hc hsub => X.property c hc (hsub.trans Set.inter_subset_left)⟩
  have hZ : IsGLB ({X, Y} : Set (TreeDomain T)) Z := by
    constructor
    · intro W hW
      rcases Set.mem_insert_iff.mp hW with rfl | hW
      · exact Set.inter_subset_left
      · rw [Set.mem_singleton_iff.mp hW]
        exact Set.inter_subset_right
    · intro W hW
      exact Set.subset_inter (hW (by simp)) (hW (by simp))
  exact congrArg Subtype.val ((hT.toIsScottDomain.inf_isGLB X Y).unique hZ)

def treeCountablyBased (hp : T.IsProper) : IsCountablyBasedDIDomain (TreeDomain T) :=
  (Section02.treeDomainConstruction.{v}).2.1 B T hp

def completionCountablyBased (hp : T.IsProper) :
    IsCountablyBasedDIDomain (BranchCompletion T hp) :=
  ⟨(branchCompletionProperties.{v,v} B T hp).choose,
    (branchCompletionProperties.{v,v} B T hp).choose_spec.1⟩

def completionCore (hp : T.IsProper) : DIDomainObject.{v} :=
  (completionCB T hp (completionCountablyBased T hp)).toDIDomainObject

variable (L : T.Node → Set A) (hL : BlockCondition T E L) (hp : T.IsProper)

include hL

def nodeConfiguration (X : TreeDomain T) (x : T.Node) : Configuration E :=
  ⟨nodeSection T L X.val x, nodeSection_configuration T L E hL hp X x⟩

theorem nodeConfiguration_prefix (X : TreeDomain T) :
    BranchCompletionModels.PrefixMonotone T (causalConfigurationCore E)
      (nodeConfiguration E T L hL hp X) := by
  intro x y hxy
  exact nodeSection_mono_node T L X.val hxy

theorem extensionWitness (X : TreeDomain T) :
    ∃ f : StableHom (completionCore T hp) (causalConfigurationCore E),
      (∀ z : T.Node, f (BranchCompletion.finite T hp z) =
        nodeConfiguration E T L hL hp X z) ∧
      (∀ b : T.InfiniteBranch,
        IsLUB ((nodeConfiguration E T L hL hp X) '' Set.range b.node)
          (f (BranchCompletion.infinite T hp b))) := by
  obtain ⟨_hH, hExtend⟩ := branchExtension.{v,u} B T hp
  exact hExtend (causalConfigurationCore E) (nodeConfiguration E T L hL hp X)
    (nodeConfiguration_prefix E T L hL hp X)

def sectionFunction (X : TreeDomain T) :
    StableHom (completionCore T hp) (causalConfigurationCore E) :=
  Classical.choose (extensionWitness E T L hL hp X)

theorem section_finite (X : TreeDomain T) (z : T.Node) :
    (sectionFunction E T L hL hp X (BranchCompletion.finite T hp z)).val =
      nodeSection T L X.val z :=
  congrArg Subtype.val ((Classical.choose_spec (extensionWitness E T L hL hp X)).1 z)

theorem section_infinite (X : TreeDomain T) (b : T.InfiniteBranch) :
    (sectionFunction E T L hL hp X (BranchCompletion.infinite T hp b)).val =
      branchSection T L X.val b := by
  have h := (Classical.choose_spec (extensionWitness E T L hL hp X)).2 b
  have hDirected : DirectedSet ((nodeConfiguration E T L hL hp X) '' Set.range b.node) :=
    BranchExtensionProof.branchValues_directed T (causalConfigurationCore E)
      (nodeConfiguration E T L hL hp X) (nodeConfiguration_prefix E T L hL hp X) b
  have hValues :
      (sectionFunction E T L hL hp X (BranchCompletion.infinite T hp b)).val =
      configUnion E ((nodeConfiguration E T L hL hp X) '' Set.range b.node) :=
    configuration_directedLUB_values E _ hDirected _ h
  rw [hValues]
  ext a
  constructor
  · rintro ⟨Y, ⟨z, hz, rfl⟩, ha⟩
    exact ⟨z, hz, ha⟩
  · rintro ⟨z, hz, ha⟩
    exact ⟨nodeConfiguration E T L hL hp X z, ⟨z, hz, rfl⟩, ha⟩

theorem section_inl (X : TreeDomain T) (z : T.Node) :
    (sectionFunction E T L hL hp X (Sum.inl z)).val = nodeSection T L X.val z :=
  section_finite E T L hL hp X z

theorem section_inr (X : TreeDomain T) (b : T.InfiniteBranch) :
    (sectionFunction E T L hL hp X (Sum.inr b)).val = branchSection T L X.val b :=
  section_infinite E T L hL hp X b

end DIDomainClassification.TreeRealisationConfigurations
