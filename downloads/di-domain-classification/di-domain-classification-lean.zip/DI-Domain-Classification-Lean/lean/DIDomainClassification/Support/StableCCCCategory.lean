import DIDomainClassification.Support.StableCCCOperations
import Mathlib.CategoryTheory.Limits.Constructions.FiniteProductsOfBinaryProducts

/-!
# Conditional actual categorical products and exponentials

All constructions are conditional on the arbitrary explicit DomainClosure C.
The category remains the actual accepted countably-based dI-domain category.
No closure inhabitant or public source theorem is supplied by this module.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.StableCCCCategory

open CategoryTheory CategoryTheory.Limits
open Section02.StableBackground

noncomputable section

abbrev app {X Y : Obj.{u}} (f : X ⟶ Y) (x : Core X) : Core Y :=
  CountablyBasedDIDomain.toStableHom f x

theorem app_comp {X Y Z : Obj.{u}} (f : X ⟶ Y) (g : Y ⟶ Z) (x : Core X) :
    app (f ≫ g) x = app g (app f x) := rfl

theorem app_id (X : Obj.{u}) (x : Core X) : app (𝟙 X) x = x := rfl

def terminalIsTerminal (C : DomainClosure.{u}) : IsTerminal (terminalObject C) :=
  IsTerminal.ofUniqueHom (StableCCCOperations.terminalArrow C)
    (StableCCCOperations.terminal_unique C)

def literalProductIsLimit (C : DomainClosure.{u}) (D E : Obj.{u}) :
    IsLimit (BinaryFan.mk (C := Obj.{u}) (X := D) (Y := E) (P := productObject C D E)
      (StableCCCOperations.fst C D E : productObject C D E ⟶ D)
      (StableCCCOperations.snd C D E : productObject C D E ⟶ E)) := by
  apply BinaryFan.isLimitMk
    (fun s => StableCCCOperations.pair C s.pt D E s.fst s.snd)
  · intro s
    exact StableCCCOperations.pair_fst C s.pt D E s.fst s.snd
  · intro s
    exact StableCCCOperations.pair_snd C s.pt D E s.fst s.snd
  · intro s m hfst hsnd
    have h1 : StableHom.comp (StableCCCOperations.fst C D E) m = s.fst := hfst
    have h2 : StableHom.comp (StableCCCOperations.snd C D E) m = s.snd := hsnd
    calc
      m = StableCCCOperations.pair C s.pt D E
          (StableHom.comp (StableCCCOperations.fst C D E) m)
          (StableHom.comp (StableCCCOperations.snd C D E) m) :=
        (StableCCCOperations.pair_unique C s.pt D E m).symm
      _ = StableCCCOperations.pair C s.pt D E s.fst s.snd := by rw [h1, h2]

theorem hasBinaryProducts (C : DomainClosure.{u}) : HasBinaryProducts Obj.{u} := by
  letI (D E : Obj.{u}) : HasLimit (Limits.pair D E) :=
    HasLimit.mk ⟨_, literalProductIsLimit C D E⟩
  exact hasBinaryProducts_of_hasLimit_pair Obj.{u}

theorem hasFiniteProducts (C : DomainClosure.{u}) : HasFiniteProducts Obj.{u} := by
  letI : HasBinaryProducts Obj.{u} := hasBinaryProducts C
  letI : HasTerminal Obj.{u} := (terminalIsTerminal C).hasTerminal
  exact CategoryTheory.hasFiniteProducts_of_has_binary_and_terminal

def swap (C : DomainClosure.{u}) (X D : Obj.{u}) :
    Hom (productObject C X D) (productObject C D X) :=
  StableCCCOperations.pair C (productObject C X D) D X
    (StableCCCOperations.snd C X D) (StableCCCOperations.fst C X D)

theorem swap_apply (C : DomainClosure.{u}) (X D : Obj.{u}) (p : Core X × Core D) :
    swap C X D p = (p.2, p.1) := rfl

/-- The left-product Hom equivalence, obtained from literal currying and swap. -/
def leftCurryEquiv (C : DomainClosure.{u}) (D X Y : Obj.{u}) :
    Hom (productObject C D X) Y ≃ Hom X (exponentialObject C D Y) where
  toFun f := StableCCCOperations.curried C X D Y (StableHom.comp f (swap C X D))
  invFun g := StableHom.comp (StableCCCOperations.uncurried C X D Y g) (swap C D X)
  left_inv _f := StableHom.ext (fun _ => rfl)
  right_inv _g := StableHom.ext (fun _ => StableHom.ext (fun _ => rfl))

theorem leftCurryEquiv_apply (C : DomainClosure.{u}) (D X Y : Obj.{u})
    (f : Hom (productObject C D X) Y) (x : Core X) (d : Core D) :
    leftCurryEquiv C D X Y f x d = f (d, x) := rfl

theorem leftCurryEquiv_symm_apply (C : DomainClosure.{u}) (D X Y : Obj.{u})
    (g : Hom X (exponentialObject C D Y)) (p : Core D × Core X) :
    (leftCurryEquiv C D X Y).symm g p = g p.2 p.1 := rfl

def postcompose (C : DomainClosure.{u}) (D : Obj.{u}) {E F : Obj.{u}} (h : E ⟶ F) :
    exponentialObject C D E ⟶ exponentialObject C D F :=
  StableCCCOperations.curried C (exponentialObject C D E) D F
    (StableHom.comp (CountablyBasedDIDomain.toStableHom h) (StableCCCOperations.evaluation C D E))

theorem postcompose_apply (C : DomainClosure.{u}) (D : Obj.{u}) {E F : Obj.{u}}
    (h : E ⟶ F) (f : Hom D E) (x : Core D) : app (postcompose C D h) f x = app h (f x) := rfl

@[reducible] def exponentialFunctor (C : DomainClosure.{u}) (D : Obj.{u}) : Obj.{u} ⥤ Obj.{u} where
  obj E := exponentialObject C D E
  map h := postcompose C D h
  map_id _ := StableHom.ext (fun _ => StableHom.ext (fun _ => rfl))
  map_comp _ _ := StableHom.ext (fun _ => StableHom.ext (fun _ => rfl))

section ChosenProducts

variable [HasFiniteProducts Obj.{u}]

/-- Explicit bridge FROM the category's chosen product TO the literal carrier. -/
def chosenToLiteral (C : DomainClosure.{u}) (D X : Obj.{u}) :
    D ⨯ X ⟶ productObject C D X :=
  StableCCCOperations.pair C (D ⨯ X) D X
    (CountablyBasedDIDomain.toStableHom prod.fst) (CountablyBasedDIDomain.toStableHom prod.snd)

/-- The inverse bridge is the actual categorical product lift. -/
def chosenFromLiteral (C : DomainClosure.{u}) (D X : Obj.{u}) :
    productObject C D X ⟶ D ⨯ X :=
  prod.lift (StableCCCOperations.fst C D X) (StableCCCOperations.snd C D X)

theorem chosenToLiteral_fst (C : DomainClosure.{u}) (D X : Obj.{u}) :
    chosenToLiteral C D X ≫ StableCCCOperations.fst C D X = (prod.fst : D ⨯ X ⟶ D) :=
  StableCCCOperations.pair_fst C (D ⨯ X) D X _ _

theorem chosenToLiteral_snd (C : DomainClosure.{u}) (D X : Obj.{u}) :
    chosenToLiteral C D X ≫ StableCCCOperations.snd C D X = (prod.snd : D ⨯ X ⟶ X) :=
  StableCCCOperations.pair_snd C (D ⨯ X) D X _ _

theorem chosenFromLiteral_fst (C : DomainClosure.{u}) (D X : Obj.{u}) :
    chosenFromLiteral C D X ≫ (prod.fst : D ⨯ X ⟶ D) = StableCCCOperations.fst C D X :=
  prod.lift_fst _ _

theorem chosenFromLiteral_snd (C : DomainClosure.{u}) (D X : Obj.{u}) :
    chosenFromLiteral C D X ≫ (prod.snd : D ⨯ X ⟶ X) = StableCCCOperations.snd C D X :=
  prod.lift_snd _ _

/-- The chosen product is not assumed definitionally equal to the literal product. -/
def chosenProductIso (C : DomainClosure.{u}) (D X : Obj.{u}) : D ⨯ X ≅ productObject C D X where
  hom := chosenToLiteral C D X
  inv := chosenFromLiteral C D X
  hom_inv_id := by
    apply prod.hom_ext
    · simp only [Category.assoc, chosenFromLiteral_fst, chosenToLiteral_fst, Category.id_comp]
    · simp only [Category.assoc, chosenFromLiteral_snd, chosenToLiteral_snd, Category.id_comp]
  inv_hom_id := by
    apply StableHom.ext
    intro p
    apply Prod.ext
    · have h := congrArg (fun k : productObject C D X ⟶ D => app k p)
        (chosenFromLiteral_fst C D X)
      exact h
    · have h := congrArg (fun k : productObject C D X ⟶ X => app k p)
        (chosenFromLiteral_snd C D X)
      exact h

def chosenHomEquiv (C : DomainClosure.{u}) (D X Y : Obj.{u}) :
    (D ⨯ X ⟶ Y) ≃ (productObject C D X ⟶ Y) where
  toFun f := (chosenProductIso C D X).inv ≫ f
  invFun f := (chosenProductIso C D X).hom ≫ f
  left_inv f := by simp only [← Category.assoc, Iso.hom_inv_id, Category.id_comp]
  right_inv f := by simp only [← Category.assoc, Iso.inv_hom_id, Category.id_comp]

def curryHomEquiv (C : DomainClosure.{u}) (D X Y : Obj.{u}) :
    (D ⨯ X ⟶ Y) ≃ (X ⟶ (exponentialFunctor C D).obj Y) :=
  (chosenHomEquiv C D X Y).trans (leftCurryEquiv C D X Y)

theorem curryHomEquiv_apply (C : DomainClosure.{u}) (D X Y : Obj.{u})
    (f : D ⨯ X ⟶ Y) (x : Core X) (d : Core D) :
    app (curryHomEquiv C D X Y f) x d = app f (app (chosenProductIso C D X).inv (d, x)) := rfl

theorem curryHomEquiv_symm_apply (C : DomainClosure.{u}) (D X Y : Obj.{u})
    (g : X ⟶ (exponentialFunctor C D).obj Y) (p : Core (D ⨯ X)) :
    app ((curryHomEquiv C D X Y).symm g) p =
      app g (app (prod.snd : D ⨯ X ⟶ X) p) (app (prod.fst : D ⨯ X ⟶ D) p) := rfl

theorem chosenProduct_map_fst (D : Obj.{u}) {X' X : Obj.{u}} (f : X' ⟶ X)
    (p : Core (D ⨯ X')) :
    app (prod.fst : D ⨯ X ⟶ D) (app ((prod.functor.obj D).map f) p) =
      app (prod.fst : D ⨯ X' ⟶ D) p := by
  change app (prod.fst : D ⨯ X ⟶ D) (app (prod.map (𝟙 D) f) p) = _
  have h := congrArg (fun k : D ⨯ X' ⟶ D => app k p) (prod.map_fst (𝟙 D) f)
  simpa only [app_comp, app_id] using h

theorem chosenProduct_map_snd (D : Obj.{u}) {X' X : Obj.{u}} (f : X' ⟶ X)
    (p : Core (D ⨯ X')) :
    app (prod.snd : D ⨯ X ⟶ X) (app ((prod.functor.obj D).map f) p) =
      app f (app (prod.snd : D ⨯ X' ⟶ X') p) := by
  change app (prod.snd : D ⨯ X ⟶ X) (app (prod.map (𝟙 D) f) p) = _
  have h := congrArg (fun k : D ⨯ X' ⟶ X => app k p) (prod.map_snd (𝟙 D) f)
  simpa only [app_comp] using h

theorem curryHomEquiv_naturality_left_symm (C : DomainClosure.{u}) (D : Obj.{u})
    {X' X Y : Obj.{u}} (f : X' ⟶ X) (g : X ⟶ (exponentialFunctor C D).obj Y) :
    (curryHomEquiv C D X' Y).symm (f ≫ g) =
      (prod.functor.obj D).map f ≫ (curryHomEquiv C D X Y).symm g := by
  apply StableHom.ext
  intro p
  change app g (app f (app (prod.snd : D ⨯ X' ⟶ X') p))
      (app (prod.fst : D ⨯ X' ⟶ D) p) =
    app g (app (prod.snd : D ⨯ X ⟶ X) (app ((prod.functor.obj D).map f) p))
      (app (prod.fst : D ⨯ X ⟶ D) (app ((prod.functor.obj D).map f) p))
  rw [chosenProduct_map_fst, chosenProduct_map_snd]

theorem curryHomEquiv_naturality_right (C : DomainClosure.{u}) (D : Obj.{u})
    {X Y Y' : Obj.{u}} (f : D ⨯ X ⟶ Y) (g : Y ⟶ Y') :
    curryHomEquiv C D X Y' (f ≫ g) =
      curryHomEquiv C D X Y f ≫ (exponentialFunctor C D).map g := by
  apply StableHom.ext
  intro x
  exact StableHom.ext (fun _ => rfl)

def productAdjunction (C : DomainClosure.{u}) (D : Obj.{u}) :
    prod.functor.obj D ⊣ exponentialFunctor C D :=
  Adjunction.mkOfHomEquiv {
    homEquiv := curryHomEquiv C D
    homEquiv_naturality_left_symm := curryHomEquiv_naturality_left_symm C D
    homEquiv_naturality_right := curryHomEquiv_naturality_right C D }

theorem productFunctor_isLeftAdjoint (C : DomainClosure.{u}) (D : Obj.{u}) :
    (prod.functor.obj D).IsLeftAdjoint :=
  ⟨⟨exponentialFunctor C D, ⟨productAdjunction C D⟩⟩⟩

end ChosenProducts

theorem ambientCartesianClosed (C : DomainClosure.{u}) : AmbientCartesianClosed.{u} := by
  refine ⟨hasFiniteProducts C, ?_⟩
  letI : HasFiniteProducts Obj.{u} := hasFiniteProducts C
  intro D
  exact productFunctor_isLeftAdjoint C D

/-- Actual requested operations and actual ambient CCC, conditional on C only. -/
def conditionalConstruction (C : DomainClosure.{u}) : CartesianClosedConstruction C where
  cartesianClosed := ambientCartesianClosed C
  terminalArrow := StableCCCOperations.terminalArrow C
  terminal_apply := StableCCCOperations.terminal_apply C
  terminal_unique := StableCCCOperations.terminal_unique C
  fst := StableCCCOperations.fst C
  snd := StableCCCOperations.snd C
  pair := StableCCCOperations.pair C
  fst_apply := StableCCCOperations.fst_apply C
  snd_apply := StableCCCOperations.snd_apply C
  pair_apply := StableCCCOperations.pair_apply C
  pair_fst := StableCCCOperations.pair_fst C
  pair_snd := StableCCCOperations.pair_snd C
  pair_unique := StableCCCOperations.pair_unique C
  evaluation := StableCCCOperations.evaluation C
  evaluation_apply := StableCCCOperations.evaluation_apply C
  composition := StableCCCOperations.composition C
  composition_apply := StableCCCOperations.composition_apply C
  curry := StableCCCOperations.curryOperator C
  curry_apply := StableCCCOperations.curryOperator_apply C
  uncurry := StableCCCOperations.uncurried C
  uncurry_apply := StableCCCOperations.uncurried_apply C
  uncurry_curry := StableCCCOperations.uncurried_curryOperator C
  curry_uncurry := StableCCCOperations.curryOperator_uncurried C

theorem domainClosure_implies_construction (C : DomainClosure.{u}) :
    Nonempty (CartesianClosedConstruction C) := ⟨conditionalConstruction C⟩

end

end DIDomainClassification.StableCCCCategory
