import DIDomainClassification.Support.ReflexiveRetractionClass
import DIDomainClassification.Section01.Classification
import DIDomainClassification.Section02.DegreeRealizability

/-! Apply the proved category classification, then sharpen the resulting
cut using actual degree realizability. No universality theorem is assumed. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ReflexiveDegreeCut
open Preliminaries CoherenceDegree Subcategories Section05
open Section03.StableFunctionModels Section04.CutModels ReflexiveRetractionClass

theorem retract_degree_le (D E : CountablyBasedDIDomain.{u})
    (h : HasStableRetraction (Core D) (Core E)) : objectDegree D ≤ objectDegree E := by
  obtain ⟨s, r, hLeft⟩ := h
  apply Section02.bps.1 (Core D) (Core E)
    (Core D).isDIDomain.toIsScottDomain (Core E).isDIDomain.toIsScottDomain
    D.countableCompacts E.countableCompacts
  exact ⟨s, r, (StableHom.isStable s).1, (StableHom.isStable r).1, hLeft⟩

theorem class_eq_cut (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) : objects E = DomainCut (objectDegree E + 1) := by
  have hClass := (Section01.classificationCharacterization (objects E)).mp
    (category_hypotheses E hNon hRef)
  have hDomain : DomainAlternative (objects E) := by
    rcases hClass with ⟨a, _ha, hEq⟩ | hDomain
    · have hFin : Finite E := by
        have hMem := self_mem E
        rw [hEq] at hMem
        exact hMem.2
      exact False.elim (not_finite E hNon hRef hFin)
    · exact hDomain
  obtain ⟨a, ha, hEq⟩ := hDomain
  have hE : objectDegree E < a := by
    have hMem := self_mem E
    rw [hEq] at hMem
    exact hMem
  have hLower : objectDegree E + 1 ≤ a := by
    simpa only [Order.succ_eq_add_one] using Order.succ_le_iff.mpr hE
  have hUpper : a ≤ objectDegree E + 1 := by
    by_contra h
    have hStrict : objectDegree E + 1 < a := lt_of_not_ge h
    have hTwo : 2 ≤ objectDegree E + 1 :=
      (two_le_degree E hNon hRef).trans (by
        simpa only [Order.succ_eq_add_one] using Order.le_succ (objectDegree E))
    have hBound : objectDegree E + 1 ≤ firstUncountableBound.{u} := by
      have hlt : objectDegree E + 1 < firstUncountableBound.{u} + 1 := hStrict.trans_le ha.2
      simpa only [Order.succ_eq_add_one] using Order.lt_succ_iff.mp hlt
    obtain ⟨D, hDdegree⟩ := Section02.degreeRealizability.1 (objectDegree E + 1)
      (Or.inr ⟨hTwo, hBound⟩)
    have hPD : objects E D := by
      rw [hEq]
      change objectDegree D < a
      rw [hDdegree]
      exact hStrict
    have hMono := retract_degree_le D E hPD
    rw [hDdegree] at hMono
    exact (not_le_of_gt (show objectDegree E < objectDegree E + 1 by
      simpa only [Order.succ_eq_add_one] using Order.lt_succ (objectDegree E))) hMono
  exact hEq.trans (congrArg DomainCut (le_antisymm hUpper hLower))

theorem retract_iff (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) (D : CountablyBasedDIDomain.{u}) :
    HasStableRetraction (Core D) (Core E) ↔ objectDegree D ≤ objectDegree E := by
  change objects E D ↔ _
  rw [class_eq_cut E hNon hRef]
  exact (show objectDegree D < objectDegree E + 1 ↔ objectDegree D ≤ objectDegree E by
    simpa only [Order.succ_eq_add_one] using Order.lt_succ_iff)

theorem universal (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E))
    (hRef : IsStableReflexive E) : IsStableUniversal (DomainCut (objectDegree E + 1)) E := by
  refine ⟨?_, ?_⟩
  · change objectDegree E < objectDegree E + 1
    simpa only [Order.succ_eq_add_one] using Order.lt_succ (objectDegree E)
  · intro D hD
    exact (retract_iff E hNon hRef D).mpr
      (by simpa only [DomainCut, Order.succ_eq_add_one] using Order.lt_succ_iff.mp hD)

end DIDomainClassification.ReflexiveDegreeCut
