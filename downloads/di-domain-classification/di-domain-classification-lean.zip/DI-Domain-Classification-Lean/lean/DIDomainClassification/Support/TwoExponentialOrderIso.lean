import DIDomainClassification.Section02.TwoExponentialStatement
import DIDomainClassification.Support.OrderIsoTransport

/-! Literal three-map stable order and its isomorphism with the proper-powerset
carrier T₂. This proves the shape rather than assuming a flat-domain proxy. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TwoExponentialOrderIso
open Preliminaries Section02.TwoExponentialModels Section04.FiniteCategoryModels
open FiniteOrderDomains

/-- Use the derived source meet, retaining its definitionally identical order. -/
local instance nativeTwoMeet : SemilatticeInf TwoCarrier.{u} :=
  DIDomainObject.instSemilatticeInf Core

local instance (priority := 2000) nativeTwoMin : Min TwoCarrier.{u} :=
  nativeTwoMeet.toMin

theorem endpoint_ext (f g : Endomaps.{u}) (h0 : f zero = g zero) (h1 : f one = g one) :
    f = g := by
  apply StableHom.ext
  intro x
  rcases eq_zero_or_one x with rfl | rfl
  · exact h0
  · exact h1

theorem classify (f : Endomaps.{u}) : f = zeroMap ∨ f = identityMap ∨ f = oneMap := by
  rcases eq_zero_or_one (f zero) with h0 | h0
  · rcases eq_zero_or_one (f one) with h1 | h1
    · exact Or.inl (endpoint_ext f zeroMap h0 h1)
    · exact Or.inr (Or.inl (endpoint_ext f identityMap h0 h1))
  · have hmon : f zero ≤ f one :=
      (StableHom.isStable f).1.monotone (zero_le.{u} one.{u})
    have h1 : f one = one := le_antisymm (le_one _) (h0 ▸ hmon)
    exact Or.inr (Or.inr (endpoint_ext f oneMap h0 h1))

theorem zero_ne_identity : zeroMap.{u} ≠ identityMap := by
  intro h
  exact zero_ne_one (congrArg (fun f : Endomaps.{u} => f one) h)

theorem zero_ne_oneMap : zeroMap.{u} ≠ oneMap := by
  intro h
  exact zero_ne_one (congrArg (fun f : Endomaps.{u} => f zero) h)

theorem identity_ne_one : identityMap.{u} ≠ oneMap := by
  intro h
  exact zero_ne_one (congrArg (fun f : Endomaps.{u} => f zero) h)

theorem zeroMap_le (f : Endomaps.{u}) : zeroMap ≤ f := by
  intro x y _hxy
  change zero = zero ⊓ f x
  exact (inf_eq_left.mpr (zero_le _)).symm

theorem identity_pointwise_one (x : Core.{u}) : identityMap x ≤ oneMap x := le_one x

theorem no_common_upper : ¬ Compatible identityMap.{u} oneMap := by
  rintro ⟨g, hidg, honeg⟩
  have h1 : one ≤ g zero := by
    calc
      one = one ⊓ g zero := honeg zero zero le_rfl
      _ ≤ g zero := inf_le_right
  have hg0 : g zero = one := le_antisymm (le_one _) h1
  have h := hidg zero one (zero_le.{u} one.{u})
  change zero = one ⊓ g zero at h
  rw [hg0, inf_idem] at h
  exact zero_ne_one h

theorem nonzero_not_le_zero (f : Endomaps.{u}) (hf : f ≠ zeroMap) : ¬ f ≤ zeroMap := by
  intro h
  have heq : f = zeroMap := le_antisymm h (zeroMap_le f)
  exact hf heq

theorem order_iff (f g : Endomaps.{u}) : f ≤ g ↔ f = zeroMap ∨ f = g := by
  constructor
  · intro h
    rcases classify f with rfl | rfl | rfl
    · exact Or.inl rfl
    · rcases classify g with rfl | rfl | rfl
      · exact False.elim (nonzero_not_le_zero identityMap zero_ne_identity.symm h)
      · exact Or.inr rfl
      · exact False.elim (no_common_upper ⟨oneMap, h, le_rfl⟩)
    · rcases classify g with rfl | rfl | rfl
      · exact False.elim (nonzero_not_le_zero oneMap zero_ne_oneMap.symm h)
      · exact False.elim (no_common_upper ⟨identityMap, le_rfl, h⟩)
      · exact Or.inr rfl
  · rintro (rfl | rfl)
    · exact zeroMap_le _
    · exact le_rfl

abbrev Cube := CubeCarrier.{u} 2 (by decide)

def emptyCube : Cube.{u} := ⟨⟨∅, Set.empty_ne_univ⟩⟩

def atomZeroCube : Cube.{u} := ⟨⟨{0}, by
  intro h
  have hmem : (1 : Fin 2) ∈ ({0} : Set (Fin 2)) := by rw [h]; exact Set.mem_univ _
  exact (by decide : (1 : Fin 2) ≠ 0) (Set.mem_singleton_iff.mp hmem)⟩⟩

def atomOneCube : Cube.{u} := ⟨⟨{1}, by
  intro h
  have hmem : (0 : Fin 2) ∈ ({1} : Set (Fin 2)) := by rw [h]; exact Set.mem_univ _
  exact (by decide : (0 : Fin 2) ≠ 1) (Set.mem_singleton_iff.mp hmem)⟩⟩

theorem empty_ne_atomZero : emptyCube.{u} ≠ atomZeroCube := by
  intro h
  have heq := congrArg (fun S : Cube.{u} => (0 : Fin 2) ∈ S.down.val) h
  simp [emptyCube, atomZeroCube] at heq

theorem empty_ne_atomOne : emptyCube.{u} ≠ atomOneCube := by
  intro h
  have heq := congrArg (fun S : Cube.{u} => (1 : Fin 2) ∈ S.down.val) h
  simp [emptyCube, atomOneCube] at heq

theorem atomZero_ne_atomOne : atomZeroCube.{u} ≠ atomOneCube := by
  intro h
  have heq := congrArg (fun S : Cube.{u} => (0 : Fin 2) ∈ S.down.val) h
  have h01 : (0 : Fin 2) ≠ 1 := by decide
  simp [atomZeroCube, atomOneCube, h01] at heq

theorem cube_cases (S : Cube.{u}) :
    S = emptyCube ∨ S = atomZeroCube ∨ S = atomOneCube := by
  classical
  by_cases h0 : (0 : Fin 2) ∈ S.down.val
  · by_cases h1 : (1 : Fin 2) ∈ S.down.val
    · exfalso
      apply S.down.property
      apply Set.eq_univ_of_forall
      intro i
      rcases BasicDomains.two_eq_zero_or_one i with rfl | rfl
      · exact h0
      · exact h1
    · apply Or.inr
      apply Or.inl
      apply ULift.ext
      apply Subtype.ext
      ext i
      rcases BasicDomains.two_eq_zero_or_one i with rfl | rfl <;>
        simp [atomZeroCube, h0, h1]
  · by_cases h1 : (1 : Fin 2) ∈ S.down.val
    · apply Or.inr
      apply Or.inr
      apply ULift.ext
      apply Subtype.ext
      ext i
      rcases BasicDomains.two_eq_zero_or_one i with rfl | rfl <;>
        simp [atomOneCube, h0, h1]
    · apply Or.inl
      apply ULift.ext
      apply Subtype.ext
      ext i
      rcases BasicDomains.two_eq_zero_or_one i with rfl | rfl <;>
        simp [emptyCube, h0, h1]

theorem cube_le_iff (S T : Cube.{u}) : S ≤ T ↔ S.down.val ⊆ T.down.val := Iff.rfl

theorem cube_order_iff (S T : Cube.{u}) : S ≤ T ↔ S = emptyCube ∨ S = T := by
  rcases cube_cases S with rfl | rfl | rfl <;>
    rcases cube_cases T with rfl | rfl | rfl <;>
    simp [emptyCube, atomZeroCube, atomOneCube]

def toCube (f : Endomaps.{u}) : Cube.{u} := by
  classical
  exact if f = zeroMap then emptyCube else if f = identityMap then atomZeroCube else atomOneCube

def fromCube (S : Cube.{u}) : Endomaps.{u} := by
  classical
  exact if S = emptyCube then zeroMap else if S = atomZeroCube then identityMap else oneMap

theorem to_from_left (f : Endomaps.{u}) : fromCube (toCube f) = f := by
  classical
  rcases classify f with rfl | rfl | rfl <;>
    simp [toCube, fromCube,
      Ne.symm zero_ne_identity, Ne.symm zero_ne_oneMap, Ne.symm identity_ne_one,
      Ne.symm empty_ne_atomZero, Ne.symm empty_ne_atomOne, Ne.symm atomZero_ne_atomOne]

theorem from_to_right (S : Cube.{u}) : toCube (fromCube S) = S := by
  classical
  rcases cube_cases S with rfl | rfl | rfl <;>
    simp [toCube, fromCube,
      Ne.symm zero_ne_identity, Ne.symm zero_ne_oneMap, Ne.symm identity_ne_one,
      Ne.symm empty_ne_atomZero, Ne.symm empty_ne_atomOne, Ne.symm atomZero_ne_atomOne]

def cubeEquiv : Endomaps.{u} ≃ Cube.{u} where
  toFun := toCube
  invFun := fromCube
  left_inv := to_from_left
  right_inv := from_to_right

theorem toCube_zero : toCube zeroMap.{u} = emptyCube := by
  classical
  simp [toCube]

def orderIso : Endomaps.{u} ≃o Cube.{u} where
  toEquiv := cubeEquiv
  map_rel_iff' := by
    intro f g
    change toCube f ≤ toCube g ↔ f ≤ g
    rw [cube_order_iff, order_iff]
    constructor
    · rintro (hzero | heq)
      · left
        apply cubeEquiv.injective
        exact hzero.trans toCube_zero.symm
      · exact Or.inr (cubeEquiv.injective heq)
    · rintro (rfl | rfl)
      · exact Or.inl toCube_zero
      · exact Or.inr rfl

def cubeCountablyBased : IsCountablyBasedDIDomain Cube.{u} :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff orderIso).mp
    ⟨Exponential.toDIDomainObject.isDIDomain, Exponential.countableCompacts⟩

def stableIso : Exponential.{u} ≅ cubeObject 2 (by decide) cubeCountablyBased where
  hom := OrderIsoTransport.stableHom Exponential.toDIDomainObject
    (cubeObject 2 (by decide) cubeCountablyBased).toDIDomainObject orderIso
  inv := OrderIsoTransport.stableHom (cubeObject 2 (by decide) cubeCountablyBased).toDIDomainObject
    Exponential.toDIDomainObject orderIso.symm
  hom_inv_id := StableHom.ext orderIso.symm_apply_apply
  inv_hom_id := StableHom.ext orderIso.apply_symm_apply

end DIDomainClassification.TwoExponentialOrderIso
