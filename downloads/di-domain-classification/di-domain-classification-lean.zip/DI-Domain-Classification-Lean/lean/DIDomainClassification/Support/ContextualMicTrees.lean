import DIDomainClassification.Support.FiniteJoinMICReplacement
import DIDomainClassification.Support.FiniteLeafColourPruning

/-!
Contextual MIC-tree support for the genuine finite-join-basis refinement.
No properness or nontriviality is imposed on contextual trees: the one-root
tree is necessary at induction leaves. The source's incomplete-branch
consistency follows below from WF, path injectivity, and leaf MIC minimality.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open Preliminaries CoherenceDegree Trees FiniteLeafColourPruning

variable {D : Type u} [PartialOrder D] (hD : IsScottDomain D)
  {Index : Type v} (T : RootedPrefixTree Index)

/-- Contexts are finite sets of distinct compact values; the compactness clause
is kept explicit. All tree labels are actual compact elements. -/
def IsContextualMicTree (W : Set D) (label : T.Node → ↥(CompactElements D)) : Prop :=
  W.Finite ∧ W ⊆ CompactElements D ∧
    (∀ x, (label x : D) ∉ W) ∧
    (∀ x, Set.InjOn label (T.pathTo x)) ∧
    ∀ x, T.IsLeaf x → IsMinimallyInconsistent hD (W ∪ labelImage T label (T.pathTo x))

theorem contextual_internal_consistent {W : Set D}
    {label : T.Node → ↥(CompactElements D)} (hT : T.IsWellFounded)
    (hC : IsContextualMicTree hD T W label) (x : T.Node) (hx : ¬ T.IsLeaf x) :
    Consistent (W ∪ labelImage T label (T.pathTo x)) := by
  obtain ⟨leaf, hleaf, hxl⟩ := exists_leaf_extension T hT x
  have hne : leaf ≠ x := by
    intro heq
    exact hx (heq ▸ hleaf)
  have hsub : W ∪ labelImage T label (T.pathTo x) ⊆
      W ∪ labelImage T label (T.pathTo leaf) := by
    apply Set.union_subset_union (Set.Subset.refl W)
    apply Set.image_mono
    intro y hy
    exact (show y.val <+: x.val from hy).trans hxl
  apply (hC.2.2.2.2 leaf hleaf).2.2 _
  refine ⟨hsub, ?_⟩
  intro hback
  have hmem := hback (Or.inr ⟨leaf, show leaf ≤ leaf from le_rfl, rfl⟩)
  rcases hmem with hw | ⟨y, hy, heq⟩
  · exact hC.2.2.1 leaf hw
  · have hyl : y ≤ leaf := hy.trans hxl
    have hylEq : y = leaf := hC.2.2.2.1 leaf hyl (List.prefix_refl _) (Subtype.ext heq)
    have hlx : leaf ≤ x := hylEq ▸ hy
    exact hne (le_antisymm hlx hxl)

/-- The actual accepted WF MIC tree is contextual with the empty context. -/
theorem contextual_of_micTree (M : MicTree D hD Index) (hM : M.tree.IsWellFounded) :
    IsContextualMicTree hD M.tree ∅ M.label := by
  refine ⟨Set.finite_empty, Set.empty_subset _, by simp, ?_, ?_⟩
  · intro x
    obtain ⟨leaf, hleaf, hxl⟩ := exists_leaf_extension M.tree hM x
    have hbranch := M.tree.pathTo_isBranch hleaf
    intro y hy z hz heq
    exact M.isMicTree.branchInjective hbranch
      ((show y.val <+: x.val from hy).trans hxl)
      ((show z.val <+: x.val from hz).trans hxl) heq
  · intro leaf hleaf
    simpa only [Set.empty_union] using
      M.isMicTree.finiteBranch_mic ⟨leaf, hleaf, rfl⟩

theorem contextual_isMicTree {label : T.Node → ↥(CompactElements D)}
    (hC : IsContextualMicTree hD T ∅ label) (proper : T.IsProper) :
    IsMicTree hD T proper label := by
  apply (isMicTree_iff hD T proper label).2
  constructor
  · intro c hc x hx y hy hxy
    rcases hc.1.total hx hy with h | h
    · exact hC.2.2.2.1 y h (List.prefix_refl _) hxy
    · exact hC.2.2.2.1 x (List.prefix_refl _) h hxy
  · rintro c ⟨leaf, hleaf, rfl⟩
    simpa only [Set.empty_union] using hC.2.2.2.2 leaf hleaf

/-- A WF empty-context MIC tree is automatically proper. This is proved from
the actual singleton consistency and leaf-extension laws, not assumed. -/
theorem contextual_empty_isProper {label : T.Node → ↥(CompactElements D)}
    (hT : T.IsWellFounded) (hC : IsContextualMicTree hD T ∅ label) : T.IsProper := by
  have hroot : ¬ T.IsLeaf T.root := by
    intro hr
    apply (hC.2.2.2.2 T.root hr).2.1
    refine ⟨(label T.root : D), ?_⟩
    rintro a (ha | ⟨x, _hx, rfl⟩)
    · cases ha
    · have hxr := hr x (T.root_le x)
      simpa only [hxr] using (le_rfl : (label T.root : D) ≤ (label T.root : D))
  have hchild : ∃ x : T.Node, T.IsChild T.root x := by
    by_contra hn
    exact hroot ((T.isLeaf_iff_no_child T.root).2 hn)
  obtain ⟨x, hx⟩ := hchild
  have hne : x ≠ T.root := by
    intro heq
    exact T.isChild_irrefl T.root (heq ▸ hx)
  apply T.isProper_iff.mpr
  exact ⟨⟨⟨x, T.root, hne⟩⟩, fun y => exists_leaf_extension T hT y⟩

/-- Restriction to a same-root ancestor-closed subtree with no new leaves
preserves the full contextual invariant on its literal retained paths. -/
theorem contextual_pruned {W : Set D} {label : T.Node → ↥(CompactElements D)}
    (hC : IsContextualMicTree hD T W label)
    (S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
    (hroot : S.rootList = T.rootList)
    (hleaf : ∀ x : S.Node, S.IsLeaf x → T.IsLeaf (inclusionNodeMap T S hsub x)) :
    IsContextualMicTree hD S W (fun x => label (inclusionNodeMap T S hsub x)) := by
  refine ⟨hC.1, hC.2.1, fun x => hC.2.2.1 _, ?_, ?_⟩
  · intro x y hy z hz heq
    have h := hC.2.2.2.1 (inclusionNodeMap T S hsub x) hy hz heq
    exact Subtype.ext (congrArg (fun y : T.Node => y.val) h)
  · intro x hx
    have hpath := inclusionNodeMap_pathTo T S hsub hroot x
    have himage : labelImage S (fun x => label (inclusionNodeMap T S hsub x))
        (S.pathTo x) = labelImage T label (T.pathTo (inclusionNodeMap T S hsub x)) := by
      change (fun y => (label (inclusionNodeMap T S hsub y) : D)) '' S.pathTo x = _
      rw [← hpath, labelImage, Set.image_image]
    rw [himage]
    exact hC.2.2.2.2 _ (hleaf x hx)

def tailLabelImage (label : T.Node → ↥(CompactElements D)) (x : T.Node) : Set D :=
  labelImage T label (T.pathTo x \ {T.root})

theorem contextual_leaf_split {W : Set D} {label : T.Node → ↥(CompactElements D)}
    (leaf : T.Node) :
    W ∪ labelImage T label (T.pathTo leaf) =
      (W ∪ tailLabelImage T label leaf) ∪ {(label T.root : D)} := by
  classical
  ext a
  constructor
  · intro h
    rcases h with hw | ⟨x, hx, rfl⟩
    · exact Or.inl (Or.inl hw)
    · by_cases hxr : x = T.root
      · exact Or.inr (by simp only [hxr, Set.mem_singleton_iff])
      · exact Or.inl (Or.inr ⟨x, ⟨hx, by simpa only [Set.mem_singleton_iff] using hxr⟩, rfl⟩)
  · intro h
    rcases h with (hw | ⟨x, hx, rfl⟩) | ha
    · exact Or.inl hw
    · exact Or.inr ⟨x, hx.1, rfl⟩
    · exact Or.inr ⟨T.root, T.root_le leaf, (Set.mem_singleton_iff.mp ha).symm⟩

theorem contextual_root_avoids_tail {W : Set D}
    {label : T.Node → ↥(CompactElements D)}
    (hC : IsContextualMicTree hD T W label) (leaf : T.Node) :
    (label T.root : D) ∉ W ∪ tailLabelImage T label leaf := by
  intro h
  rcases h with hw | ⟨x, hx, heq⟩
  · exact hC.2.2.1 T.root hw
  · have hxr := hC.2.2.2.1 leaf hx.1 (T.root_le leaf) (Subtype.ext heq)
    exact hx.2 (by simpa only [hxr] using Set.mem_singleton T.root)

/-- The combinatorial finite-colour step of the actual join-basis refinement.
It constructs a same-root, same-rank WF pruning and ONE nonempty subset of the
finite root decomposition that works on ALL of its complete branches.
Neither a pruning/rank equality nor a uniform root subset is an input.
-/
theorem contextual_uniform_root_replacement {W : Set D}
    {label : T.Node → ↥(CompactElements D)} (hT : T.IsWellFounded)
    (hC : IsContextualMicTree hD T W label) (F : Set D) (hF : F.Finite)
    (hFlub : IsLUB F (label T.root : D)) :
    ∃ (B : Set D) (S : RootedPrefixTree Index) (hsub : S.nodes ⊆ T.nodes)
      (hS : S.IsWellFounded),
      B.Finite ∧ B ⊆ F ∧ B.Nonempty ∧ S.rootList = T.rootList ∧
      S.treeRank hS = T.treeRank hT ∧
      ∀ leaf : S.Node, S.IsLeaf leaf →
        T.IsLeaf (inclusionNodeMap T S hsub leaf) ∧
        Disjoint (W ∪ tailLabelImage T label (inclusionNodeMap T S hsub leaf)) B ∧
        IsMinimallyInconsistent hD
          ((W ∪ tailLabelImage T label (inclusionNodeMap T S hsub leaf)) ∪ B) := by
  classical
  let Colour := {B : Set D // B ⊆ F}
  letI : Finite Colour := hF.powerset.to_subtype
  let L : Colour → Set T.Node := fun B => {leaf |
    B.val.Nonempty ∧ Disjoint (W ∪ tailLabelImage T label leaf) B.val ∧
      IsMinimallyInconsistent hD ((W ∪ tailLabelImage T label leaf) ∪ B.val)}
  have hcover : ∀ leaf : T.Node, T.IsLeaf leaf → ∃ i : Colour, leaf ∈ L i := by
    intro leaf hleaf
    have hmic : IsMinimallyInconsistent hD
        ((W ∪ tailLabelImage T label leaf) ∪ {(label T.root : D)}) := by
      rw [← contextual_leaf_split T leaf]
      exact hC.2.2.2.2 leaf hleaf
    obtain ⟨B, _hBfin, hBF, hBne, hBdis, hBmic⟩ :=
      finite_join_mic_replacement hD _ F _
        (contextual_root_avoids_tail hD T hC leaf) hmic hF hFlub
    exact ⟨⟨B, hBF⟩, hBne, hBdis, hBmic⟩
  obtain ⟨B, S, hsub, hS, hroot, hrank, hleaves, _hproper⟩ :=
    finite_leaf_class_pruning T hT L hcover
  obtain ⟨leaf, hleaf, _hrootleaf⟩ := exists_leaf_extension S hS S.root
  have hBne := (hleaves leaf hleaf).2.1
  refine ⟨B.val, S, hsub, hS, hF.subset B.property, B.property, hBne,
    hroot, hrank, ?_⟩
  intro leaf hleaf
  have h := hleaves leaf hleaf
  exact ⟨h.1, h.2.2.1, h.2.2.2⟩

end DIDomainClassification.PointwiseFunctionSupport
