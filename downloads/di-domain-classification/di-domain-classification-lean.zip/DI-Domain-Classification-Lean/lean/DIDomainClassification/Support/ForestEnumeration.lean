import DIDomainClassification.Section04.ForestStatement
import DIDomainClassification.Support.QualitativeConfigurationMIC
import Mathlib.Logic.Denumerable

/-! The source enumeration is derived from countability of actual compact
configurations. No countability of the entire dcpo carrier is assumed. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ForestEnumeration
open Preliminaries EventStructures Section04.ForestModels FiniteCausalConflicts

variable {A : Type u} [PartialOrder A]

instance rootsCountable (E : FinitaryPrimeEventStructure A) (e : A → ℕ) :
    Countable (Roots E e) := by
  dsimp [Roots]
  infer_instance

theorem events_countable (E : FinitaryPrimeEventStructure A)
    (hE : IsCountablyBasedDIDomain (Configuration E)) : Countable A := by
  letI : Countable (CompactElements (Configuration E)) := hE.2.to_subtype
  let f : A → CompactElements (Configuration E) := fun a =>
    ⟨ConfigurationDomain.principal E a,
      ConfigurationDomain.compact_of_finite E _ (E.finite_principalIdeal a)⟩
  have hf : Function.Injective f := by
    intro a b hab
    exact QualitativeConfigurationMIC.principal_injective E
      (congrArg Subtype.val hab)
  exact hf.countable

omit [PartialOrder A] in
theorem exists_initial_enumeration [Countable A] :
    ∃ e : A → ℕ, IsInitialEnumeration e := by
  classical
  cases finite_or_infinite A with
  | inl h =>
      letI : Finite A := h
      obtain ⟨N, ⟨q⟩⟩ := Finite.exists_equiv_fin A
      refine ⟨fun a => (q a).val, ?_, Or.inr ⟨N, ?_⟩⟩
      · intro a b hab
        exact q.injective (Fin.val_injective hab)
      · ext n
        constructor
        · rintro ⟨a, rfl⟩
          exact (q a).isLt
        · intro hn
          exact ⟨q.symm ⟨n, hn⟩, congrArg Fin.val (q.apply_symm_apply ⟨n, hn⟩)⟩
  | inr h =>
      letI : Infinite A := h
      let q : A ≃ ℕ := Classical.choice nonempty_equiv_of_countable
      exact ⟨q, q.injective, Or.inl (Set.range_eq_univ.mpr q.surjective)⟩

theorem mem_sorted (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (H : Set A) (hH : H ∈ causalConflictFamily E) (n : ℕ) :
    n ∈ sortedIndices E e H hH ↔ ∃ a ∈ H, e a = n := by
  classical
  simp only [sortedIndices, Finset.mem_sort, Finset.mem_image, Set.Finite.mem_toFinset]

theorem sorted_strict (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (H : Set A) (hH : H ∈ causalConflictFamily E) :
    (sortedIndices E e H hH).Pairwise (· < ·) := by
  classical
  exact (Finset.sortedLT_sort _).pairwise

theorem sorted_nonempty (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (H : Set A) (hH : H ∈ causalConflictFamily E) : sortedIndices E e H hH ≠ [] := by
  obtain ⟨a, ha⟩ := conflict_member_nonempty E hH
  have hm := (mem_sorted E e H hH (e a)).mpr ⟨a, ha, rfl⟩
  intro heq
  simpa only [heq, List.not_mem_nil] using hm

theorem indexHead_cons (n : ℕ) (l : List ℕ) : indexHead (n :: l) = some n := rfl

theorem singleton_prefix_of_head {l : List ℕ} {n : ℕ}
    (h : indexHead l = some n) : [n] <+: l := by
  cases l with
  | nil => cases h
  | cons a l =>
      have ha : a = n := Option.some.inj h
      subst a
      exact List.cons_prefix_cons.mpr ⟨rfl, List.nil_prefix⟩

theorem indexHead_of_nonempty_prefix {v w : List ℕ} {i : ℕ}
    (hne : v ≠ []) (hvw : v <+: w) (hw : indexHead w = some i) :
    indexHead v = some i := by
  cases v with
  | nil => exact (hne rfl).elim
  | cons a v =>
      cases w with
      | nil => cases List.prefix_nil.mp hvw
      | cons b w =>
          obtain ⟨hab, _⟩ := List.cons_prefix_cons.mp hvw
          simpa only [indexHead, hab] using hw

theorem sorted_head_of_minimum (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (H : Set A) (hH : H ∈ causalConflictFamily E) (i : ℕ)
    (hmin : ∃ a ∈ H, e a = i ∧ ∀ b ∈ H, i ≤ e b) :
    indexHead (sortedIndices E e H hH) = some i := by
  obtain ⟨a, ha, hai, hmin⟩ := hmin
  have hi := (mem_sorted E e H hH i).mpr ⟨a, ha, hai⟩
  have hsort := sorted_strict E e H hH
  generalize hs : sortedIndices E e H hH = l at hi hsort ⊢
  cases l with
  | nil => cases hi
  | cons n l =>
      have hn : ∃ b ∈ H, e b = n :=
        (mem_sorted E e H hH n).mp (by rw [hs]; exact List.mem_cons_self)
      obtain ⟨b, hb, hbn⟩ := hn
      have hin : i ≤ n := hbn ▸ hmin b hb
      have hni : n ≤ i := by
        rcases List.mem_cons.mp hi with h | h
        · exact le_of_eq h.symm
        · exact le_of_lt ((List.pairwise_cons.mp hsort).1 _ h)
      simpa only [indexHead, le_antisymm hni hin]

end DIDomainClassification.ForestEnumeration
