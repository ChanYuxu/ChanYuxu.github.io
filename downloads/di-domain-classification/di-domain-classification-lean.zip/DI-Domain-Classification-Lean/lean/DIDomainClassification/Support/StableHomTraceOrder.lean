import DIDomainClassification.Support.FiniteTraceApproximations

/-! Generic staged trace-order, algebraicity and compact-ideal support.
No function-space algebraicity or dI closure is an input. -/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.StableExponentialClosure

open Preliminaries EventStructures MinimalInputTraces FiniteTraceApproximations

variable {D : Type u} {A : Type v} [PartialOrder D] [PartialOrder A]
  {E : FinitaryPrimeEventStructure A}

def homTrace (hD : IsDIDomain D) (g : Hom hD E) : Set (D × A) :=
  trace (fun x : D => g x)

theorem hom_preserves_meets (hD : IsDIDomain D) (g : Hom hD E) :
    PreservesCompatibleMeets hD.toIsScottDomain (fun x : D => g x) := by
  apply (preservesCompatibleMeets_iff_intersection hD.toIsScottDomain).mpr
  intro x y hxy
  have h := congrArg (fun X : configurationObject E => X.val)
    (g.toStableMap.map_inf_of_compatible x y hxy)
  rw [source_inf_eq] at h
  exact h.trans (target_inf_val _ _)

theorem hom_le_val_eq (hD : IsDIDomain D) {g h : Hom hD E} (hgh : g ≤ h)
    (x y : D) (hxy : x ≤ y) : (g x).val = (g y).val ∩ (h x).val :=
  (congrArg (fun X : configurationObject E => X.val) (hgh x y hxy)).trans
    (target_inf_val _ _)

theorem homTrace_mono (hD : IsDIDomain D) {g h : Hom hD E} (hgh : g ≤ h) :
    homTrace hD g ⊆ homTrace hD h := by
  rintro ⟨k, a⟩ hk
  have hak : a ∈ (h k).val :=
    (Configuration.le_iff_subset _ _).mp (hom_le_pointwise hD hgh k) hk.2.1
  obtain ⟨l, hlk, hl⟩ := exists_trace_below hD (StableHom.isStable h).1 hak
  have hal : a ∈ (g l).val := by
    rw [hom_le_val_eq hD hgh l k hlk]
    exact ⟨hk.2.1, hl.2.1⟩
  have hl_eq : l = k := trace_input_eq_of_le hk hlk hal
  simpa only [hl_eq] using hl

theorem hom_le_of_trace_subset (hD : IsDIDomain D) {g h : Hom hD E}
    (hTrace : homTrace hD g ⊆ homTrace hD h) : g ≤ h := by
  intro x y hxy
  apply Subtype.ext
  rw [target_inf_val]
  ext a
  constructor
  · intro ha
    obtain ⟨k, hkx, hk⟩ := exists_trace_below hD (StableHom.isStable g).1 ha
    exact ⟨(Configuration.le_iff_subset _ _).mp ((StableHom.isStable g).1.monotone hxy) ha,
      (Configuration.le_iff_subset _ _).mp ((StableHom.isStable h).1.monotone hkx)
        (hTrace hk).2.1⟩
  · rintro ⟨hay, hax⟩
    obtain ⟨k, hky, hk⟩ := exists_trace_below hD (StableHom.isStable g).1 hay
    obtain ⟨l, hlx, hl⟩ := exists_trace_below hD (StableHom.isStable h).1 hax
    have hkl := trace_unique_below hD.toIsScottDomain (hom_preserves_meets hD h)
      (hTrace hk) hl hky (hlx.trans hxy)
    exact (Configuration.le_iff_subset _ _).mp
      ((StableHom.isStable g).1.monotone (hkl ▸ hlx)) hk.2.1

theorem hom_le_iff_trace_subset (hD : IsDIDomain D) (g h : Hom hD E) :
    g ≤ h ↔ homTrace hD g ⊆ homTrace hD h :=
  ⟨homTrace_mono hD, hom_le_of_trace_subset hD⟩

theorem homTrace_injective (hD : IsDIDomain D) :
    Function.Injective (homTrace hD (E := E)) := by
  intro g h hgh
  apply le_antisymm
  · apply hom_le_of_trace_subset hD
    rw [hgh]
  · apply hom_le_of_trace_subset hD
    rw [hgh]

theorem homTrace_approximation (hD : IsDIDomain D) {f : D → Configuration E}
    (hf : ScottContinuous f) (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    (S : FiniteSupport f) :
    homTrace hD (approximationHom hD hf hm S) = S.carrier := by
  ext p
  rcases p with ⟨k, a⟩
  constructor
  · intro hk
    obtain ⟨l, hl, hlk⟩ := hk.2.1
    have hal : a ∈ (approximationHom hD hf hm S l).val := ⟨l, hl, le_rfl⟩
    have hl_eq : l = k := trace_input_eq_of_le hk hlk hal
    simpa only [hl_eq] using hl
  · intro hk
    refine ⟨(S.subtrace hk).1, ⟨k, hk, le_rfl⟩, ?_⟩
    rintro y hy ⟨l, hl, hly⟩
    exact (S.subtrace hk).2.2 l (lt_of_le_of_lt hly hy) (S.subtrace hl).2.1

theorem baseHom_eq (hD : IsDIDomain D) (g : Hom hD E) :
    baseHom hD (StableHom.isStable g).1 (hom_preserves_meets hD g) = g :=
  StableHom.ext (fun _ => rfl)

theorem hom_approximation_isLUB (hD : IsDIDomain D) (g : Hom hD E) :
    IsLUB (approximants hD (StableHom.isStable g).1 (hom_preserves_meets hD g)) g := by
  simpa only [baseHom_eq] using
    approximants_isLUB hD (StableHom.isStable g).1 (hom_preserves_meets hD g)

theorem hom_isDcpo (hD : IsDIDomain D) : IsDcpo (Hom hD E) :=
  StableHomPointwiseSupport.hom_isDcpo

/-- FULL compact-below algebraicity, derived from the proved finite compact approximants. -/
theorem hom_isAlgebraicDcpo (hD : IsDIDomain D) : IsAlgebraicDcpo (Hom hD E) := by
  have hBasis : OrderCore.IsBasis (CompactElements (Hom hD E)) := by
    apply OrderCore.isBasis_of_directed_approximants
    intro g
    refine ⟨approximants hD (StableHom.isStable g).1 (hom_preserves_meets hD g), ?_,
      approximants_directed hD (StableHom.isStable g).1 (hom_preserves_meets hD g),
      hom_approximation_isLUB hD g⟩
    rintro _ ⟨S, rfl⟩
    have hCompact := approximationHom_compact hD (StableHom.isStable g).1
      (hom_preserves_meets hD g) S
    refine ⟨hCompact, (OrderCore.wayBelow_iff_le_of_compact hCompact).mpr ?_⟩
    exact (hom_approximation_isLUB hD g).1 ⟨S, rfl⟩
  refine ⟨hom_isDcpo hD, ?_⟩
  intro g
  rw [OrderCore.compactBelow_eq_approximants]
  exact hBasis g

theorem compact_eq_approximation (hD : IsDIDomain D) (g : Hom hD E)
    (hg : IsCompactElement g) :
    ∃ S : FiniteSupport (fun x : D => g x),
      approximationHom hD (StableHom.isStable g).1 (hom_preserves_meets hD g) S = g := by
  have hLUB := hom_approximation_isLUB hD g
  obtain ⟨_, ⟨S, rfl⟩, hgS⟩ := hg
    (approximants_directed hD (StableHom.isStable g).1 (hom_preserves_meets hD g))
    hLUB le_rfl
  exact ⟨S, le_antisymm (hLUB.1 ⟨S, rfl⟩) hgS⟩

theorem compact_homTrace_finite (hD : IsDIDomain D) (g : Hom hD E)
    (hg : IsCompactElement g) : (homTrace hD g).Finite := by
  obtain ⟨S, hS⟩ := compact_eq_approximation hD g hg
  have heq : homTrace hD g = S.carrier :=
    (congrArg (homTrace hD) hS).symm.trans
      (homTrace_approximation hD (StableHom.isStable g).1 (hom_preserves_meets hD g) S)
  rw [heq]
  exact S.finite

/-- Every point of Iic g is encoded, not only compact predecessors. -/
theorem finite_entire_compact_ideal (hD : IsDIDomain D) (g : Hom hD E)
    (hg : IsCompactElement g) : (Set.Iic g).Finite := by
  apply Set.Finite.of_injOn (f := homTrace hD) (t := (homTrace hD g).powerset)
  · intro h hh
    exact homTrace_mono hD hh
  · exact (homTrace_injective hD).injOn
  · exact (compact_homTrace_finite hD g hg).powerset

theorem hom_compactElements_countable (hD : IsDIDomain D)
    (hK : (CompactElements D).Countable) [Countable A] :
    (CompactElements (Hom hD E)).Countable := by
  have hPairs : ((CompactElements D) ×ˢ (Set.univ : Set A)).Countable :=
    hK.prod Set.countable_univ
  have hFiniteSets := Set.countable_setOf_finite_subset hPairs
  have hPreimage := hFiniteSets.preimage (homTrace_injective hD (E := E))
  apply hPreimage.mono
  intro g hg
  refine ⟨compact_homTrace_finite hD g hg, ?_⟩
  intro p hp
  exact ⟨hp.1, Set.mem_univ _⟩

end DIDomainClassification.StableExponentialClosure
