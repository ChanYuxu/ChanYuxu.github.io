import DIDomainClassification.Support.InfiniteBranchCuts
import DIDomainClassification.Support.ForbiddenFamilyUnions
import DIDomainClassification.Support.TreeSingletonBasis
import DIDomainClassification.Section02.Comb

/-!
Genuine nonempty finite-block MIC labels for the literal comb N∞ in a proper
tree with an actual infinite branch. Selected finite complete branches are
partitioned by actual disjoint spine intervals plus a nonempty off-spine side.
No comb MIC existence or coherence-degree conclusion is an input.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TreeDomainDegree

open Preliminaries CoherenceDegree Trees
open Section02.TreeDomainConstruction

variable {Index : Type u} (T : RootedPrefixTree Index) (hp : T.IsProper) (b : T.InfiniteBranch)

def sideBlock (n : ℕ) : Set T.Node := sideSet T b (cutLeaf T b hp (cutIndex T b hp n))

theorem sideBlock_finite (n : ℕ) : (sideBlock T hp b n).Finite := sideSet_finite T b _

theorem sideBlock_nonempty (n : ℕ) : (sideBlock T hp b n).Nonempty :=
  sideSet_nonempty T b _ (cutLeaf_isLeaf T b hp _)

def spinePoint (n : ℕ) : TreeDomain T := by
  refine ⟨spineBlock T b hp n, ?_⟩
  rintro c ⟨leaf, hleaf, rfl⟩ hsub
  exact leaf_not_on_spine T b leaf hleaf
    (spineBlock_subset_spine T b hp n (hsub (List.prefix_refl _)))

def sidePoint (n : ℕ) : TreeDomain T := by
  refine ⟨sideBlock T hp b n, ?_⟩
  intro c hc hsub
  have hroot : T.root ∈ sideBlock T hp b n := hsub (hc.root_mem T)
  exact hroot.2 ⟨0, b.root_eq⟩

def spineCompact (n : ℕ) : ↥(CompactElements (TreeDomain T)) :=
  ⟨spinePoint T hp b n, (compact_iff_finite T hp _).2 (spineBlock_finite T b hp n)⟩

def sideCompact (n : ℕ) : ↥(CompactElements (TreeDomain T)) :=
  ⟨sidePoint T hp b n, (compact_iff_finite T hp _).2 (sideBlock_finite T hp b n)⟩

def combBlockLabel : Comb.Vertex → ↥(CompactElements (TreeDomain T))
  | Comb.Vertex.spine n => spineCompact T hp b n
  | Comb.Vertex.leaf n => sideCompact T hp b n

theorem combBlockLabel_nodes_nonempty (v : Comb.Vertex) :
    (combBlockLabel T hp b v).val.val.Nonempty := by
  cases v with
  | spine n => exact spineBlock_nonempty T b hp n
  | leaf n => exact sideBlock_nonempty T hp b n

theorem combBlockLabel_disjoint_on_branch (n : ℕ) {v w : Comb.Vertex}
    (hv : v ∈ Comb.Vertex.finiteBranch n) (hw : w ∈ Comb.Vertex.finiteBranch n) (hne : v ≠ w) :
    Disjoint (combBlockLabel T hp b v).val.val (combBlockLabel T hp b w).val.val := by
  cases v with
  | spine i =>
      cases w with
      | spine j =>
          exact spineBlock_disjoint T b hp (fun hij => hne (congrArg Comb.Vertex.spine hij))
      | leaf j =>
          apply Set.disjoint_left.mpr
          intro x hx hy
          exact hy.2 (spineBlock_subset_spine T b hp i hx)
  | leaf i =>
      cases w with
      | spine j =>
          apply Set.disjoint_left.mpr
          intro x hx hy
          exact hx.2 (spineBlock_subset_spine T b hp j hy)
      | leaf j =>
          have hi : i = n := (Comb.Vertex.leaf_mem_finiteBranch i n).1 hv
          have hj : j = n := (Comb.Vertex.leaf_mem_finiteBranch j n).1 hw
          exact (hne (congrArg Comb.Vertex.leaf (hi.trans hj.symm))).elim

theorem combBlockLabel_injOn_branch (n : ℕ) :
    Set.InjOn (combBlockLabel T hp b) (Comb.Vertex.finiteBranch n) := by
  intro v hv w hw hEq
  by_contra hne
  obtain ⟨x, hx⟩ := combBlockLabel_nodes_nonempty T hp b v
  have hSets := congrArg (fun X : ↥(CompactElements (TreeDomain T)) => X.val.val) hEq
  exact Set.disjoint_left.mp (combBlockLabel_disjoint_on_branch T hp b n hv hw hne)
    hx ((Set.ext_iff.mp hSets x).mp hx)

theorem comb_finiteBranch_finite (n : ℕ) : (Comb.Vertex.finiteBranch n).Finite := by
  have himage : (Comb.node [] '' Comb.Vertex.finiteBranch n).Finite := by
    rw [Comb.finiteBranch_image]
    exact (Comb.tree []).pathTo_finite _
  exact himage.of_finite_image (Comb.node_injective []).injOn

/-- The actual union of every comb finite-branch label is the ENTIRE selected
finite complete branch of T, with no omitted endpoint or assumed completion.
-/
theorem combBlock_union (n : ℕ) :
    ForbiddenUnionSupport.unionValues (H := forbiddenBranches T)
      ((fun v => (combBlockLabel T hp b v).val) '' Comb.Vertex.finiteBranch n) =
      T.pathTo (cutLeaf T b hp (cutIndex T b hp n)) := by
  rw [path_split_at_cut T b hp (cutIndex T b hp n)]
  change _ = b.node '' Set.Iio (cutIndex T b hp (n + 1)) ∪ sideBlock T hp b n
  ext x
  constructor
  · rintro ⟨X, ⟨v, hv, rfl⟩, hx⟩
    cases v with
    | spine j =>
        have hj : j ≤ n := (Comb.Vertex.spine_mem_finiteBranch j n).1 hv
        obtain ⟨k, hk, rfl⟩ := hx
        exact Or.inl ⟨k, (index_interval_cover T b hp n k).2 ⟨j, hj, hk.1, hk.2⟩, rfl⟩
    | leaf j =>
        have hj : j = n := (Comb.Vertex.leaf_mem_finiteBranch j n).1 hv
        simpa only [hj] using (Or.inr hx)
  · rintro (⟨k, hk, rfl⟩ | hx)
    · obtain ⟨j, hj, hjk, hkj⟩ := (index_interval_cover T b hp n k).1 hk
      refine ⟨(combBlockLabel T hp b (Comb.Vertex.spine j)).val,
        ⟨Comb.Vertex.spine j, (Comb.Vertex.spine_mem_finiteBranch j n).2 hj, rfl⟩, ?_⟩
      exact ⟨k, ⟨hjk, hkj⟩, rfl⟩
    · exact ⟨(combBlockLabel T hp b (Comb.Vertex.leaf n)).val,
        ⟨Comb.Vertex.leaf n, (Comb.Vertex.leaf_mem_finiteBranch n n).2 rfl, rfl⟩, hx⟩

theorem combBlock_family_mic (n : ℕ) :
    IsMinimallyInconsistent (treeScottDomain T hp)
      ((fun v => (combBlockLabel T hp b v).val) '' Comb.Vertex.finiteBranch n) := by
  classical
  let F : Set (TreeDomain T) :=
    (fun v => (combBlockLabel T hp b v).val) '' Comb.Vertex.finiteBranch n
  apply ForbiddenUnionSupport.disjoint_partition_mic (forbiddenBranches T) (admissible T hp)
    (forbiddenBranches_antichain T) F ((comb_finiteBranch_finite n).image _)
  · rintro X ⟨v, _hv, rfl⟩
    exact combBlockLabel_nodes_nonempty T hp b v
  · rintro X ⟨v, hv, rfl⟩ Y ⟨w, hw, rfl⟩ hne
    apply combBlockLabel_disjoint_on_branch T hp b n hv hw
    intro hEq
    exact hne (congrArg (fun v => (combBlockLabel T hp b v).val) hEq)
  · change ForbiddenUnionSupport.unionValues (H := forbiddenBranches T)
      ((fun v => (combBlockLabel T hp b v).val) '' Comb.Vertex.finiteBranch n) ∈ forbiddenBranches T
    rw [combBlock_union T hp b n]
    exact ⟨cutLeaf T b hp (cutIndex T b hp n), cutLeaf_isLeaf T b hp _, rfl⟩

end DIDomainClassification.TreeDomainDegree

