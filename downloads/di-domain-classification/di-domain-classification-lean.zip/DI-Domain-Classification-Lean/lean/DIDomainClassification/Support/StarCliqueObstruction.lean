import DIDomainClassification.Support.CliqueStableMaps
import DIDomainClassification.Section02.EventRepresentation
import DIDomainClassification.Section02.CoherenceCharacterization
import DIDomainClassification.Section04.AdditionalSourceModels

/-!
The countable star-conflict clique domain: p is incompatible with every q_n,
while all q_n have a common upper bound and distinct q_n meet at the empty
configuration. It is the graph form of the provided thesis Example3.4.3(ii).
The actual countably based dI and 2-coherence clauses are proved here.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.StarCliqueObstruction

open OrderCore Preliminaries CoherenceDegree EventStructures
open Section02 Section02.BinaryCliqueModels Section03.StableFunctionModels
open Section04.AdditionalSourceModels

theorem bounded_iff_union_clique {A : Type u} (G : SimpleGraph A)
    (F : Set (CliqueCarrier G)) :
    BddAbove F ↔ G.IsClique (CliqueStableMaps.unionValues F) := by
  constructor
  · rintro ⟨Z, hZ⟩ a ⟨X, hX, ha⟩ b ⟨Y, hY, hb⟩ hab
    exact Z.property (hZ hX ha) (hZ hY hb) hab
  · intro hF
    refine ⟨⟨CliqueStableMaps.unionValues F, hF⟩, ?_⟩
    intro X hX a ha
    exact ⟨X, hX, ha⟩

theorem clique_twoCoherent {A : Type u} (G : SimpleGraph A)
    (hD : IsScottDomain (CliqueCarrier G)) : IsNCoherent hD 2 (by decide) := by
  apply (coherenceCharacterization (CliqueCarrier G) hD 2 (by decide)).mpr
  intro F hSmall
  apply (bounded_iff_union_clique G F).mpr
  rintro a ⟨X, hX, ha⟩ b ⟨Y, hY, hb⟩ hab
  have hPairSub : ({X,Y} : Set (CliqueCarrier G)) ⊆ F := Set.pair_subset hX hY
  have hPairCard : ({X,Y} : Set (CliqueCarrier G)).ncard ≤ 2 := by
    by_cases hXY : X = Y
    · subst Y
      simp
    · rw [Set.ncard_pair hXY]
  obtain ⟨Z, hZ⟩ := hSmall {X,Y} hPairSub ((Set.finite_singleton Y).insert X) hPairCard
  exact Z.property (hZ (by simp) ha) (hZ (by simp) hb) hab

def cliqueCertificate {A : Type u} [Countable A] (G : SimpleGraph A) :
    IsCountablyBasedDIDomain (CliqueCarrier G) := by
  letI : PartialOrder A := equalityOrder A
  let E := BinaryCliqueSupport.graphEventStructure G
  let e := BinaryCliqueSupport.configurationCliqueOrderIso E G
    (BinaryCliqueSupport.graph_configuration_iff G)
  exact (OrderIsoTransport.isCountablyBasedDIDomain_iff e).mp (configurationDomain A E)

def singleton {A : Type u} (G : SimpleGraph A) (a : A) : CliqueCarrier G :=
  ⟨{a}, SimpleGraph.isClique_singleton a⟩

theorem singleton_compact {A : Type u} (G : SimpleGraph A) (a : A) :
    IsCompactElement (singleton G a) := by
  intro F X hF hX hle
  have ha : a ∈ X.val := hle (by simp [singleton])
  rw [CliqueStableMaps.isLUB_val G F hF.2 X hX] at ha
  obtain ⟨Y, hY, haY⟩ := ha
  refine ⟨Y, hY, ?_⟩
  exact Set.singleton_subset_iff.mpr haY

abbrev Event : Type u := ULift.{u} (Option ℕ)

def pEvent : Event.{u} := ⟨none⟩
def qEvent (n : ℕ) : Event.{u} := ⟨some n⟩

theorem qEvent_ne_p (n : ℕ) : qEvent.{u} n ≠ pEvent := by
  intro h
  have hdown := congrArg ULift.down h
  cases hdown

theorem qEvent_injective : Function.Injective qEvent.{u} := by
  intro n m h
  exact Option.some.inj (congrArg ULift.down h)

def graph : SimpleGraph Event.{u} where
  Adj a b := a ≠ b ∧ a ≠ pEvent ∧ b ≠ pEvent
  symm := by intro a b h; exact ⟨Ne.symm h.1, h.2.2, h.2.1⟩
  loopless := ⟨fun _ h => h.1 rfl⟩

def certificate : IsCountablyBasedDIDomain (CliqueCarrier graph.{u}) :=
  cliqueCertificate graph

def starObject : CountablyBasedDIDomain.{u} := cbObject (CliqueCarrier graph) certificate
abbrev starCore : DIDomainObject.{u} := Core starObject.{u}

def pPoint : starCore.{u} := singleton graph pEvent
def qPoint (n : ℕ) : starCore.{u} := singleton graph (qEvent n)
def emptyPoint : starCore.{u} := ⟨∅, SimpleGraph.isClique_empty⟩

def allQ : starCore.{u} :=
  ⟨Set.range qEvent, by
    rintro _ ⟨n, rfl⟩ _ ⟨m, rfl⟩ hnm
    exact ⟨hnm, qEvent_ne_p n, qEvent_ne_p m⟩⟩

theorem q_le_allQ (n : ℕ) : qPoint.{u} n ≤ allQ := by
  intro a ha
  have heq : a = qEvent n := ha
  subst a
  exact ⟨n, rfl⟩

theorem q_compatible (n m : ℕ) : Compatible (qPoint.{u} n) (qPoint m) :=
  ⟨allQ, q_le_allQ n, q_le_allQ m⟩

theorem q_inf (n m : ℕ) (hnm : n ≠ m) :
    (qPoint.{u} n ⊓ qPoint m : starCore.{u}) = emptyPoint := by
  apply Subtype.ext
  have hInf : (qPoint.{u} n ⊓ qPoint m : starCore.{u}).val =
      (qPoint n).val ∩ (qPoint m).val :=
    congrArg Subtype.val ((DIDomainObject.inf_isGLB starCore (qPoint n) (qPoint m)).unique
      (CliqueStableMaps.intersection_isGLB graph (qPoint n) (qPoint m)))
  rw [hInf]
  ext a
  constructor
  · rintro ⟨ha, hb⟩
    have ha' : a = qEvent n := ha
    have hb' : a = qEvent m := hb
    exact False.elim (hnm (qEvent_injective (ha'.symm.trans hb')))
  · intro ha
    exact False.elim ha

theorem p_incompatible_q (n : ℕ) : ¬ Compatible pPoint.{u} (qPoint n) := by
  rintro ⟨Z, hp, hq⟩
  have hadj := Z.property (hp (by simp [pPoint, singleton]))
    (hq (by simp [qPoint, singleton])) (Ne.symm (qEvent_ne_p n))
  exact hadj.2.1 rfl

theorem p_compact : IsCompactElement pPoint.{u} := singleton_compact graph pEvent

theorem empty_le_p : emptyPoint.{u} ≤ pPoint := Set.empty_subset _

theorem twoCoherent : IsNCoherent starCore.{u}.isDIDomain.toIsScottDomain 2 (by decide) :=
  clique_twoCoherent graph certificate.1.toIsScottDomain

end DIDomainClassification.StarCliqueObstruction
