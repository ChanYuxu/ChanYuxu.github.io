import DIDomainClassification.Support.ConfigurationDomain
import DIDomainClassification.Section02.CompactPredecessors
import DIDomainClassification.Section02.ScottOperations
import Mathlib.Order.Preorder.Finite

/-!
# Generic compact minimal-input and causal-support theory

Raw intrinsic dI-domain D and actual Configuration E, in arbitrary universes.
No countability, strictness, event representation premise on D, trace theorem,
map compactness or function-space closure is assumed. This staged support is
not a source-facing finite-trace-approximation wrapper or an accepted proof job.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.MinimalInputTraces

open DIDomainClassification.Preliminaries
open DIDomainClassification.EventStructures

variable {D : Type u} {A : Type v} [PartialOrder D] [PartialOrder A]
  {E : FinitaryPrimeEventStructure A} {f : D → Configuration E}

/-- Literal compact-input trace; minimality tests every point y, not only compacts. -/
def trace (f : D → Configuration E) : Set (D × A) :=
  {p | p.1 ∈ CompactElements D ∧ p.2 ∈ (f p.1).val ∧
    ∀ y : D, y < p.1 → p.2 ∉ (f y).val}

theorem mem_trace_iff (k : D) (a : A) :
    (k, a) ∈ trace f ↔ IsCompactElement k ∧ a ∈ (f k).val ∧
      ∀ y : D, y < k → a ∉ (f y).val := Iff.rfl

/-- Exactly preservation of the chosen intrinsic compatible binary infima. -/
def PreservesCompatibleMeets (hD : IsScottDomain D)
    (f : D → Configuration E) : Prop :=
  ∀ x y : D, Compatible x y →
    f (hD.inf x y) = (ConfigurationDomain.scottDomain E).inf (f x) (f y)

/-- The chosen configuration infimum equals the separately proved intersection GLB.
This is a uniqueness proof, not a claimed definitional equality.
-/
theorem configuration_inf_eq_intersection (X Y : Configuration E) :
    (ConfigurationDomain.scottDomain E).inf X Y =
      ConfigurationDomain.intersection E X Y :=
  ((ConfigurationDomain.scottDomain E).inf_isGLB X Y).unique
    (ConfigurationDomain.intersection_isGLB E X Y)

theorem compatible_meet_val (hD : IsScottDomain D)
    (hm : PreservesCompatibleMeets hD f) (x y : D) (hxy : Compatible x y) :
    (f (hD.inf x y)).val = (f x).val ∩ (f y).val := by
  rw [hm x y hxy, configuration_inf_eq_intersection]
  rfl

/-- Both presentations of compatible-meet preservation use the same infimum. -/
theorem preservesCompatibleMeets_iff_intersection (hD : IsScottDomain D) :
    PreservesCompatibleMeets hD f ↔
      ∀ x y : D, Compatible x y →
        (f (hD.inf x y)).val = (f x).val ∩ (f y).val := by
  constructor
  · exact fun hm x y hxy => compatible_meet_val hD hm x y hxy
  · intro hm x y hxy
    rw [configuration_inf_eq_intersection]
    exact Subtype.ext (hm x y hxy)

theorem principal_le_iff (E : FinitaryPrimeEventStructure A)
    (a : A) (X : Configuration E) :
    ConfigurationDomain.principal E a ≤ X ↔ a ∈ X.val := by
  constructor
  · intro h
    exact (Configuration.le_iff_subset _ _).mp h le_rfl
  · intro ha
    apply (Configuration.le_iff_subset _ _).mpr
    intro b hb
    exact X.property.1 hb ha

theorem principal_compact (E : FinitaryPrimeEventStructure A) (a : A) :
    IsCompactElement (ConfigurationDomain.principal E a) :=
  ConfigurationDomain.compact_of_finite E _ (E.finite_principalIdeal a)

/-- An event observation already occurs at some actual compact approximation.
Only algebraicity and Scott continuity are needed for this first step.
-/
theorem exists_compact_below_event (hD : IsAlgebraicDcpo D)
    (hf : ScottContinuous f) {x : D} {a : A} (ha : a ∈ (f x).val) :
    ∃ c : D, IsCompactElement c ∧ c ≤ x ∧ a ∈ (f c).val := by
  have hK := hD.2 x
  have hImageDirected := hK.1.image hf.monotone
  have hImageSup := OrderCore.scottContinuous_isSup hf hK.1 hK.2
  obtain ⟨Y, ⟨c, hc, rfl⟩, hprincipal⟩ :=
    (principal_compact E a) hImageDirected hImageSup
      ((principal_le_iff E a (f x)).mpr ha)
  exact ⟨c, hc.1, hc.2, (principal_le_iff E a (f c)).mp hprincipal⟩

/-- Finite whole lower ideals produce a globally minimal compact trace input.
Every y<k is in the same finite Iic c; no compact-only minimality is substituted.
-/
theorem exists_trace_below (hD : IsDIDomain D) (hf : ScottContinuous f)
    {x : D} {a : A} (ha : a ∈ (f x).val) :
    ∃ k : D, k ≤ x ∧ (k, a) ∈ trace f := by
  obtain ⟨c, hc, hcx, hac⟩ := exists_compact_below_event hD.toIsScottDomain.algebraic hf ha
  let S : Set D := {y | y ≤ c ∧ a ∈ (f y).val}
  have hS : S.Finite := (hD.finitePrincipalIdeals c hc).subset (fun _ hy => hy.1)
  obtain ⟨k, hk⟩ := hS.exists_minimal ⟨c, le_rfl, hac⟩
  refine ⟨k, hk.1.1.trans hcx, ?_⟩
  refine ⟨Section02.compactBelowCompact D hD k c hk.1.1 hc, hk.1.2, ?_⟩
  intro y hy hay
  have hky : k ≤ y := hk.2 ⟨hy.le.trans hk.1.1, hay⟩ hy.le
  exact (not_le_of_gt hy) hky

/-- Minimal trace inputs compare with every event-producing smaller point. -/
theorem trace_input_eq_of_le {k y : D} {a : A}
    (hk : (k, a) ∈ trace f) (hyk : y ≤ k) (ha : a ∈ (f y).val) : y = k := by
  by_contra hne
  exact hk.2.2 y (lt_of_le_of_ne hyk hne) ha

/-- Same-event trace inputs below a common upper bound are equal.
The meet is formed only for the compatible pair witnessed by that upper bound.
-/
theorem trace_unique_below (hD : IsScottDomain D)
    (hm : PreservesCompatibleMeets hD f) {k l x : D} {a : A}
    (hk : (k, a) ∈ trace f) (hl : (l, a) ∈ trace f)
    (hkx : k ≤ x) (hlx : l ≤ x) : k = l := by
  have ha : a ∈ (f (hD.inf k l)).val := by
    rw [compatible_meet_val hD hm k l ⟨x, hkx, hlx⟩]
    exact ⟨hk.2.1, hl.2.1⟩
  have hmk : hD.inf k l = k :=
    trace_input_eq_of_le hk (hD.inf_le_left k l) ha
  have hml : hD.inf k l = l :=
    trace_input_eq_of_le hl (hD.inf_le_right k l) ha
  exact hmk.symm.trans hml

theorem trace_unique_and_meet (hD : IsScottDomain D)
    (hm : PreservesCompatibleMeets hD f) {k l x : D} {a : A}
    (hk : (k, a) ∈ trace f) (hl : (l, a) ∈ trace f)
    (hkx : k ≤ x) (hlx : l ≤ x) :
    k = l ∧ hD.inf k l = k ∧ hD.inf k l = l := by
  have hkl := trace_unique_below hD hm hk hl hkx hlx
  subst l
  have hkk : hD.inf k k = k :=
    le_antisymm (hD.inf_le_left k k) (hD.le_inf le_rfl le_rfl)
  exact ⟨rfl, hkk, hkk⟩

theorem existsUnique_trace_below (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    {x : D} {a : A} (ha : a ∈ (f x).val) :
    ∃! k : D, k ≤ x ∧ (k, a) ∈ trace f := by
  obtain ⟨k, hkx, hk⟩ := exists_trace_below hD hf ha
  exact ⟨k, ⟨hkx, hk⟩, fun l hl =>
    trace_unique_below hD.toIsScottDomain hm hl.2 hk hl.1 hkx⟩

/-- Relational, choice-free form of the family of minimal predecessor supports.
The b-indexed representation and unique predecessor existence are proved below.
-/
def predecessorSupport (f : D → Configuration E) (k : D) (a : A) : Set (D × A) :=
  {p | p ∈ trace f ∧ p.1 ≤ k ∧ p.2 ≤ a}

theorem predecessorSupport_subset_trace (k : D) (a : A) :
    predecessorSupport f k a ⊆ trace f := fun _ hp => hp.1

theorem self_mem_predecessorSupport {k : D} {a : A} (hk : (k, a) ∈ trace f) :
    (k, a) ∈ predecessorSupport f k a := ⟨hk, le_rfl, le_rfl⟩

/-- Every event predecessor has exactly one minimal supporting input below k. -/
theorem existsUnique_predecessorInput (hD : IsDIDomain D)
    (hf : ScottContinuous f) (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    {k : D} {a b : A} (hk : (k, a) ∈ trace f) (hba : b ≤ a) :
    ∃! l : D, (l, b) ∈ predecessorSupport f k a := by
  have hb : b ∈ (f k).val := (f k).property.1 hba hk.2.1
  obtain ⟨l, hlk, hl⟩ := exists_trace_below hD hf hb
  refine ⟨l, ⟨hl, hlk, hba⟩, ?_⟩
  intro m hmemb
  exact trace_unique_below hD.toIsScottDomain hm hmemb.1 hl hmemb.2.1 hlk

/-- Event projection is injective on a predecessor-support family. -/
theorem predecessorSupport_snd_injOn (hD : IsScottDomain D)
    (hm : PreservesCompatibleMeets hD f) (k : D) (a : A) :
    Set.InjOn Prod.snd (predecessorSupport f k a) := by
  rintro ⟨p, b⟩ hp ⟨q, c⟩ hq hbc
  change b = c at hbc
  subst c
  exact Prod.ext (trace_unique_below hD hm hp.1 hq.1 hp.2.1 hq.2.1) rfl

/-- Finiteness comes from the finite ENTIRE causal ideal Iic a and uniqueness.
It is not a countability premise or a restriction to a chosen finite subfamily.
-/
theorem predecessorSupport_finite (hD : IsScottDomain D)
    (hm : PreservesCompatibleMeets hD f) (k : D) (a : A) :
    (predecessorSupport f k a).Finite :=
  Set.Finite.of_injOn (fun _ hp => hp.2.2)
    (predecessorSupport_snd_injOn hD hm k a) (E.finite_principalIdeal a)

/-- One actual chosen input for each point of the full predecessor ideal. -/
def predecessorInput (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    {k : D} {a : A} (hk : (k, a) ∈ trace f) (b : Set.Iic a) : D :=
  Classical.choose (existsUnique_predecessorInput hD hf hm hk b.property)

theorem predecessorInput_mem (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    {k : D} {a : A} (hk : (k, a) ∈ trace f) (b : Set.Iic a) :
    (predecessorInput hD hf hm hk b, b.val) ∈ predecessorSupport f k a :=
  (Classical.choose_spec (existsUnique_predecessorInput hD hf hm hk b.property)).1

/-- Exact bridge to the source's b-indexed family C(k,a)={(k_b,b):b<=a}. -/
theorem predecessorSupport_eq_range (hD : IsDIDomain D) (hf : ScottContinuous f)
    (hm : PreservesCompatibleMeets hD.toIsScottDomain f)
    {k : D} {a : A} (hk : (k, a) ∈ trace f) :
    predecessorSupport f k a = Set.range (fun b : Set.Iic a =>
      (predecessorInput hD hf hm hk b, b.val)) := by
  apply Set.Subset.antisymm
  · rintro ⟨l, b⟩ hl
    let b' : Set.Iic a := ⟨b, hl.2.2⟩
    have hc := predecessorInput_mem hD hf hm hk b'
    exact ⟨b', Prod.ext
      (trace_unique_below hD.toIsScottDomain hm hc.1 hl.1 hc.2.1 hl.2.1) rfl⟩
  · rintro _ ⟨b, rfl⟩
    exact predecessorInput_mem hD hf hm hk b

/-- Causal nesting of supports, with both input and event comparisons transitive. -/
theorem predecessorSupport_nested {k l : D} {a b : A}
    (hl : (l, b) ∈ predecessorSupport f k a) :
    predecessorSupport f l b ⊆ predecessorSupport f k a := by
  intro p hp
  exact ⟨hp.1, hp.2.1.trans hl.2.1, hp.2.2.trans hl.2.2⟩

def IsPredecessorClosed (f : D → Configuration E) (F : Set (D × A)) : Prop :=
  ∀ p ∈ F, predecessorSupport f p.1 p.2 ⊆ F

theorem predecessorSupport_closed (k : D) (a : A) :
    IsPredecessorClosed f (predecessorSupport f k a) := by
  intro p hp
  exact predecessorSupport_nested hp

end DIDomainClassification.MinimalInputTraces
