import DIDomainClassification.Support.ComparisonForestProduct
import DIDomainClassification.Support.CountablePowersetRetraction

/-! The manuscript's forest argument for actual event-configuration domains.
Forest data, the literal stable splits and both degree equalities are obtained
from the proved source proposition, not fields supplied by a caller. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonEventCore
open Preliminaries EventStructures Trees CoherenceDegree Section04 AdditionalSourceModels
open Section03.StableFunctionModels ForestModels ComparisonForestTrees

theorem powerset_comparison (A : Type u) (e : A → ℕ) (he : Function.Injective e)
    (E : CountablyBasedDIDomain.{u}) (hNon : Nontrivial (Core E)) :
    StableComparison (CountablePowersetRetraction.sourceObject A e he) E := by
  obtain ⟨hNat, hComp⟩ := comparisonPowerset E hNon
  exact ComparisonOperations.split_comparison
    (CountablePowersetRetraction.stableRetract A e he) hComp

theorem configurations {A B : Type u} [PartialOrder A] [PartialOrder B]
    [Countable A] [Countable B]
    (D : FinitaryPrimeEventStructure A) (E : FinitaryPrimeEventStructure B)
    (hD : IsCountablyBasedDIDomain (Configuration D))
    (hE : IsCountablyBasedDIDomain (Configuration E))
    (hNon : Nontrivial (Configuration E))
    (hLe : coherenceDegree hD.1.toIsScottDomain ≤ coherenceDegree hE.1.toIsScottDomain) :
    StableComparison (configurationCB D hD) (configurationCB E hE) := by
  classical
  obtain ⟨FD, heD, _hnodesD, _hlabelsD, _hoccD, hpD, hTD, hHD,
    CD, hPD, hCausalD, hMapsD, _hRealD, hDegreeD, hSupD⟩ := forest A D hD
  have hPow : StableComparison
      (cbObject (Set A) (ForestProductMaps.powerset_countablyBased A))
      (configurationCB E hE) := powerset_comparison A FD.enumerate heD.1 _ hNon
  by_cases hZero : coherenceDegree hE.1.toIsScottDomain = 0
  · have hDzero : coherenceDegree hD.1.toIsScottDomain = 0 :=
      le_antisymm (hLe.trans_eq hZero) (zero_le _)
    have hEmpty : causalConflictFamily D = ∅ := by
      ext H
      constructor
      · intro hH
        have hTwo := ForestDegree.two_le_of_nonempty D hD ⟨H, hH⟩
        exact (not_le_of_gt (zero_lt_two : (0 : Ordinal.{u+1}) < 2)) (hTwo.trans_eq hDzero)
      · intro hH
        cases hH
    have hPowSplit : HasStableRetraction (causalConfigurationCore D)
        (Core (cbObject (Set A) (ForestProductMaps.powerset_countablyBased A))) :=
      ComparisonOperations.split_trans hCausalD
        (ComparisonOperations.iso_split _ _ (ForestDegree.emptyCoverIso D hEmpty))
    exact ComparisonOperations.split_comparison hPowSplit hPow
  · obtain ⟨FE, _heE, _hnodesE, _hlabelsE, _hoccE, hpE, hTE, hHE,
      _CE, _hPE, _hCausalE, _hMapsE, hRealE, hDegreeE, hSupE⟩ := forest B E hE
    have hDsup : coherenceDegree hD.1.toIsScottDomain =
        ⨆ j, contribution.{u} (FD.trees j) (hTD j).1.toIsScottDomain :=
      hDegreeD.trans hSupD
    have hEsup : coherenceDegree hE.1.toIsScottDomain =
        ⨆ i, contribution.{u} (FE.trees i) (hTE i).1.toIsScottDomain :=
      hDegreeE.trans hSupE
    have hDfactor (j : Roots D FD.enumerate) :
        contribution.{u} (FD.trees j) (hTD j).1.toIsScottDomain ≤
          coherenceDegree hD.1.toIsScottDomain :=
      (Ordinal.le_iSup (fun j => contribution.{u} (FD.trees j) (hTD j).1.toIsScottDomain) j).trans_eq
        hDsup.symm
    have hEfactor (i : Roots E FE.enumerate) :
        contribution.{u} (FE.trees i) (hTE i).1.toIsScottDomain ≤
          coherenceDegree hE.1.toIsScottDomain :=
      (Ordinal.le_iSup (fun i => contribution.{u} (FE.trees i) (hTE i).1.toIsScottDomain) i).trans_eq
        hEsup.symm
    have hEreal (i : Roots E FE.enumerate) :
        StableComparison (liftedObject.{u} (FE.trees i) (hpE i)) (configurationCB E hE) :=
      lifted_realisation (FE.trees i) (hpE i) (hTE i) (hHE i) _ (hRealE i)
    have hEach : ∀ j : Roots D FD.enumerate,
        StableComparison (liftedObject.{u} (FD.trees j) (hpD j)) (configurationCB E hE) := by
      by_cases hLt : coherenceDegree hE.1.toIsScottDomain < Subcategories.firstUncountableBound.{u}
      · have wfE : ∀ i, (FE.trees i).IsWellFounded := fun i =>
          wellFounded_of_contribution_lt (FE.trees i) (hpE i) (hTE i).1.toIsScottDomain
            ((hEfactor i).trans_lt hLt)
        intro j
        have wfD : (FD.trees j).IsWellFounded :=
          wellFounded_of_contribution_lt (FD.trees j) (hpD j) (hTD j).1.toIsScottDomain
            (((hDfactor j).trans hLe).trans_lt hLt)
        have hBound : Ordinal.lift.{u+1} ((FD.trees j).treeRank wfD + 1) ≤
            ⨆ i, Ordinal.lift.{u+1} ((FE.trees i).treeRank (wfE i) + 1) := by
          calc
            _ = contribution.{u} (FD.trees j) (hTD j).1.toIsScottDomain :=
              (contribution_wellFounded (FD.trees j) (hpD j) _ wfD).symm
            _ ≤ coherenceDegree hD.1.toIsScottDomain := hDfactor j
            _ ≤ coherenceDegree hE.1.toIsScottDomain := hLe
            _ = ⨆ i, contribution.{u} (FE.trees i) (hTE i).1.toIsScottDomain := hEsup
            _ = _ := congrArg (fun f : Roots E FE.enumerate → Ordinal.{u+1} => ⨆ i, f i)
              (funext (fun i => contribution_wellFounded (FE.trees i) (hpE i) _ (wfE i)))
        obtain ⟨i, hRank⟩ := exists_rank_ge (FD.trees j) FE.trees wfD wfE hBound
        exact comparisonTransitivity _ _ _
          (lifted_wellFounded_comparison (FD.trees j) (FE.trees i) (hpD j) (hpE i) wfD (wfE i) hRank)
          (hEreal i)
      · have hTop : coherenceDegree hE.1.toIsScottDomain =
            Subcategories.firstUncountableBound.{u} :=
          le_antisymm (coherenceDegree_le_firstUncountable hE.1.toIsScottDomain) (le_of_not_gt hLt)
        obtain ⟨i, hInf⟩ := exists_infinite_of_sup_eq FE.trees hpE
          (fun i => (hTE i).1.toIsScottDomain) (hEsup.symm.trans hTop)
        intro j
        exact comparisonTransitivity _ _ _
          (lifted_infinite_comparison (FD.trees j) (FE.trees i) (hpD j) (hpE i) hInf)
          (hEreal i)
    have hProdComp := ComparisonForestProduct.literal_product_comparison D FD hpD hTD hPD
      (configurationCB E hE) hPow hEach
    obtain ⟨s, r, _hsPow, _hsTrees, _hr, hLeft⟩ := hMapsD
    exact ComparisonOperations.split_comparison
      (ComparisonOperations.split_trans hCausalD ⟨s, r, hLeft⟩) hProdComp

end DIDomainClassification.ComparisonEventCore
