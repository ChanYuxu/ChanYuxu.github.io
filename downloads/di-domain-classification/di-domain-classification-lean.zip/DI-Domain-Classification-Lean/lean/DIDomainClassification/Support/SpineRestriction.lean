import DIDomainClassification.Support.BranchSetCore

/-! Actual target restriction to the ancestor/descendant spine through a node.
Every complete restricted branch contains that node and the original root,
so their transposition preserves branch SETS, not the order or edge relation.
-/

set_option autoImplicit false

universe v

noncomputable section

namespace DIDomainClassification.BranchRankComparison

open Trees

variable {B : Type v}

def spineTree (T : RootedPrefixTree B) (v : T.Node) : RootedPrefixTree B where
  nodes := {l | l ∈ T.nodes ∧ (l <+: v.val ∨ v.val <+: l)}
  rootList := T.rootList
  root_mem := ⟨T.root_mem, Or.inl (T.root_prefix v.property)⟩
  root_prefix := fun h => T.root_prefix h.1
  prefix_closed := by
    intro l m hlroot hlm hm
    refine ⟨T.prefix_closed hlroot hlm hm.1, ?_⟩
    rcases hm.2 with hmv | hvm
    · exact Or.inl (hlm.trans hmv)
    · exact List.prefix_or_prefix_of_prefix hlm hvm
  countable_nodes := T.countable_nodes.mono (fun _ h => h.1)

def spineMap (T : RootedPrefixTree B) (v : T.Node) (x : (spineTree T v).Node) : T.Node :=
  ⟨x.val, x.property.1⟩

def spinePivot (T : RootedPrefixTree B) (v : T.Node) : (spineTree T v).Node :=
  ⟨v.val, v.property, Or.inl (List.prefix_refl _)⟩

theorem spineMap_val (T : RootedPrefixTree B) (v : T.Node) (x : (spineTree T v).Node) :
    (spineMap T v x).val = x.val := rfl

theorem spineMap_root (T : RootedPrefixTree B) (v : T.Node) :
    spineMap T v (spineTree T v).root = T.root := rfl

theorem spineMap_pivot (T : RootedPrefixTree B) (v : T.Node) :
    spineMap T v (spinePivot T v) = v := rfl

theorem spineMap_injective (T : RootedPrefixTree B) (v : T.Node) :
    Function.Injective (spineMap T v) := by
  intro x y hxy
  exact Subtype.ext (congrArg (fun z : T.Node => z.val) hxy)

theorem spineMap_isChild_iff (T : RootedPrefixTree B) (v : T.Node)
    (x y : (spineTree T v).Node) :
    T.IsChild (spineMap T v x) (spineMap T v y) ↔ (spineTree T v).IsChild x y := Iff.rfl

theorem spineTree_isWellFounded (T : RootedPrefixTree B) (v : T.Node)
    (hT : T.IsWellFounded) : (spineTree T v).IsWellFounded := by
  apply (spineTree T v).isWellFounded_iff_wellFounded_reverseChildRelation.mpr
  have h := (T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT).onFun
    (f := spineMap T v)
  exact h.mono (fun _ _ hxy => (spineMap_isChild_iff T v _ _).mpr hxy)

theorem spineTree_treeRank_le (T : RootedPrefixTree B) (v : T.Node)
    (hT : T.IsWellFounded) :
    (spineTree T v).treeRank (spineTree_isWellFounded T v hT) ≤ T.treeRank hT :=
  FiniteLeafColourPruning.nodeRank_le_of_childMap (spineTree T v) T
    (spineTree_isWellFounded T v hT) hT (spineMap T v)
    (fun hxy => (spineMap_isChild_iff T v _ _).mpr hxy) (spineTree T v).root

theorem spine_original_leaf_isLeaf (T : RootedPrefixTree B) (v : T.Node)
    (x : (spineTree T v).Node) (hx : T.IsLeaf (spineMap T v x)) :
    (spineTree T v).IsLeaf x := by
  intro y hxy
  apply spineMap_injective T v
  exact hx _ hxy

theorem spine_leaf_original (T : RootedPrefixTree B) (v : T.Node)
    (x : (spineTree T v).Node) (hx : (spineTree T v).IsLeaf x) :
    T.IsLeaf (spineMap T v x) ∧ v.val <+: x.val := by
  have hvx : v.val <+: x.val := by
    rcases x.property.2 with hxv | hvx
    · have heq := hx (spinePivot T v) hxv
      have hval : v.val = x.val := congrArg (fun z : (spineTree T v).Node => z.val) heq
      rw [← hval]
    · exact hvx
  refine ⟨?_, hvx⟩
  intro y hxy
  let y' : (spineTree T v).Node := ⟨y.val, y.property, Or.inr (hvx.trans hxy)⟩
  have heq := hx y' hxy
  exact Subtype.ext (congrArg (fun z : (spineTree T v).Node => z.val) heq)

theorem spinePivot_mem_completeBranch (T : RootedPrefixTree B) (v : T.Node)
    (c : Set (spineTree T v).Node) (hc : (spineTree T v).IsFiniteCompleteBranch c) :
    spinePivot T v ∈ c := by
  obtain ⟨leaf, hleaf, rfl⟩ := hc
  exact (spine_leaf_original T v leaf hleaf).2

def spineSwap (T : RootedPrefixTree B) (v : T.Node) :
    (spineTree T v).Node ≃ (spineTree T v).Node := by
  classical
  exact Equiv.swap (spineTree T v).root (spinePivot T v)

theorem spineSwap_pivot (T : RootedPrefixTree B) (v : T.Node) :
    spineSwap T v (spinePivot T v) = (spineTree T v).root := by
  classical
  exact Equiv.swap_apply_right _ _

theorem spineSwap_image_completeBranch (T : RootedPrefixTree B) (v : T.Node)
    (c : Set (spineTree T v).Node) (hc : (spineTree T v).IsFiniteCompleteBranch c) :
    spineSwap T v '' c = c := by
  classical
  apply swap_image_eq_of_mem
  · obtain ⟨leaf, hleaf, rfl⟩ := hc
    exact (spineTree T v).root_prefix leaf.property
  · exact spinePivot_mem_completeBranch T v c hc

end DIDomainClassification.BranchRankComparison

