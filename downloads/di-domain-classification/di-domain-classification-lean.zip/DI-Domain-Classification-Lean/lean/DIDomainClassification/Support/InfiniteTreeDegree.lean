import DIDomainClassification.Support.InfiniteCombBlocks
import DIDomainClassification.Support.CombMicPullback
import DIDomainClassification.Support.CountableRankCofinality
import DIDomainClassification.Support.CoherenceDegreeBounds

/-!
Literal proper infinite-branch TreeDomain degree. Nonempty finite comb blocks
are actually constructed from T, then pulled back to every proper source
tree. Actual countable-rank realization and cross-universe cofinality give
the lower bound; the independently proved universal degree bound gives the
upper bound. No κ=ω₁ or rank-realization premise is supplied by the caller.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeDomainDegree

open Preliminaries CoherenceDegree Trees

variable {Index : Type u} (T : RootedPrefixTree Index) (hp : T.IsProper)

/-- A genuine MIC tree on the ORIGINAL arbitrary proper source tree S.
Its rank is inherited literally, not stored as a desired conclusion.
-/
def infiniteBranchMicTree (b : T.InfiniteBranch) {J : Type v}
    (S : RootedPrefixTree J) (hS : S.IsProper) :
    MicTree (TreeDomain T) (treeScottDomain T hp) J :=
  CombMicPullback.micTree S (treeScottDomain T hp) (combBlockLabel T hp b)
    (combBlockLabel_injOn_branch T hp b) (combBlock_family_mic T hp b) hS

theorem infiniteBranchMicTree_tree (b : T.InfiniteBranch) {J : Type v}
    (S : RootedPrefixTree J) (hS : S.IsProper) :
    (infiniteBranchMicTree T hp b S hS).tree = S := rfl

/-- Every actual positive countable rank contributes its lifted successor.
The source proper trees are constructed, not assumed as a realization axiom.
-/
theorem countable_rank_contribution_le (b : T.InfiniteBranch)
    (α : Ordinal.{u}) (hα : α.card ≤ Cardinal.aleph0) (hpos : 0 < α) :
    Ordinal.lift.{u+1} (α + 1) ≤ coherenceDegree (treeScottDomain T hp) := by
  let S := CountableTreeRankRealization.tree α hα
  have hS := CountableTreeRankRealization.tree_wellFounded α hα
  have hpS := CountableTreeRankRealization.tree_proper_of_pos α hα hpos
  have h : Ordinal.lift.{u+1} (S.treeRank hS + 1) ≤
      coherenceDegree (treeScottDomain T hp) :=
    treeRank_add_one_le_coherenceDegree (treeScottDomain T hp)
      (infiniteBranchMicTree T hp b S hpS) hS
  simpa only [S, CountableTreeRankRealization.tree_rank] using h

theorem infiniteBranch_degree_lower (b : T.InfiniteBranch) :
    (Order.succ Cardinal.aleph0.{u+1}).ord ≤ coherenceDegree (treeScottDomain T hp) :=
  CountableTreeRankRealization.firstUncountable_le_of_pos_countable_successor_lifts
    (coherenceDegree (treeScottDomain T hp))
    (countable_rank_contribution_le T hp b)

theorem infiniteBranch_treeDomain_degree_eq (hInf : T.HasInfiniteBranch) :
    coherenceDegree (treeScottDomain T hp) = (Order.succ Cardinal.aleph0.{u+1}).ord := by
  obtain ⟨b⟩ := hInf
  exact le_antisymm (coherenceDegree_le_firstUncountable (treeScottDomain T hp))
    (infiniteBranch_degree_lower T hp b)

end DIDomainClassification.TreeDomainDegree

