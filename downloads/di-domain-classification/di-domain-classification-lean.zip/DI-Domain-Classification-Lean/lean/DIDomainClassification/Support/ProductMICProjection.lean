import DIDomainClassification.Support.ProductScottSupport
import DIDomainClassification.Section02.MicCoherence

/-!
Actual MIC projections in dependent products. An unbounded coordinate image
is proved MIC, and projection on the WHOLE MIC set is proved injective.
These conclusions, and membership of every such coordinate in the support of
each MIC member, are derived from minimality rather than assumed leaf data.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.BPSProductDegree

open OrderCore Preliminaries CoherenceDegree

theorem bottom_not_mem_mic {P : Type u} [PartialOrder P] (hP : IsScottDomain P)
    {M : Set P} (hM : IsMinimallyInconsistent hP M) : hP.bottom ∉ M := by
  classical
  intro hbot
  let N : Set P := M \ {hP.bottom}
  have hproper : N ⊂ M := by
    refine ⟨fun _ hx => hx.1, ?_⟩
    intro hback
    exact (hback hbot).2 (Set.mem_singleton _)
  obtain ⟨z, hz⟩ := hM.2.2 N hproper
  apply hM.2.1
  refine ⟨z, ?_⟩
  intro x hx
  by_cases hxb : x = hP.bottom
  · simpa only [hxb] using hP.bottom_le z
  · exact hz ⟨hx, by simpa only [Set.mem_singleton_iff] using hxb⟩

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]

theorem exists_bad_coordinate (hD : ∀ i, IsScottDomain (D i))
    {M : Set (∀ i, D i)} (hM : IsMinimallyInconsistent (productScottDomain hD) M) :
    ∃ i : I, ¬ Consistent (Function.eval i '' M) := by
  classical
  by_contra h
  apply hM.2.1
  apply bddAbove_pi.mpr
  intro i
  by_contra hi
  exact h ⟨i, hi⟩

theorem project_mic (hD : ∀ i, IsScottDomain (D i))
    {M : Set (∀ i, D i)} (hM : IsMinimallyInconsistent (productScottDomain hD) M)
    (i : I) (hbad : ¬ Consistent (Function.eval i '' M)) :
    IsMinimallyInconsistent (hD i) (Function.eval i '' M) := by
  classical
  refine ⟨hM.1.image _, hbad, ?_⟩
  intro N hN
  let P : Set (∀ i, D i) := M ∩ Function.eval i ⁻¹' N
  have hproper : P ⊂ M := by
    refine ⟨fun _ hx => hx.1, ?_⟩
    intro hback
    apply hN.2
    rintro _ ⟨x, hx, rfl⟩
    exact (hback hx).2
  obtain ⟨z, hz⟩ := hM.2.2 P hproper
  refine ⟨z i, ?_⟩
  intro b hb
  obtain ⟨x, hx, rfl⟩ := hN.1 hb
  exact hz ⟨hx, hb⟩ i

theorem project_injective_on_mic (hD : ∀ i, IsScottDomain (D i))
    {M : Set (∀ i, D i)} (hM : IsMinimallyInconsistent (productScottDomain hD) M)
    (i : I) (hbad : ¬ Consistent (Function.eval i '' M)) :
    Set.InjOn (Function.eval i) M := by
  classical
  intro x hx y hy hxy
  by_contra hne
  let P : Set (∀ i, D i) := M \ {y}
  have hproper : P ⊂ M := by
    refine ⟨fun _ hp => hp.1, ?_⟩
    intro hback
    exact (hback hy).2 (Set.mem_singleton y)
  obtain ⟨z, hz⟩ := hM.2.2 P hproper
  apply hbad
  refine ⟨z i, ?_⟩
  rintro _ ⟨w, hw, rfl⟩
  by_cases hwy : w = y
  · have hxi := hz ⟨hx, by simpa only [Set.mem_singleton_iff] using hne⟩ i
    simpa only [hwy, hxy] using hxi
  · exact hz ⟨hw, by simpa only [Set.mem_singleton_iff] using hwy⟩ i

theorem bad_coordinate_mem_support (hD : ∀ i, IsScottDomain (D i))
    {M : Set (∀ i, D i)} (hM : IsMinimallyInconsistent (productScottDomain hD) M)
    {k : ∀ i, D i} (hk : k ∈ M) (i : I)
    (hbad : ¬ Consistent (Function.eval i '' M)) : i ∈ rootSupport hD k := by
  intro hki
  apply bottom_not_mem_mic (hD i) (project_mic hD hM i hbad)
  exact ⟨k, hk, hki⟩

theorem mic_coordinate_witness (hD : ∀ i, IsScottDomain (D i))
    {M : Set (∀ i, D i)} (hM : IsMinimallyInconsistent (productScottDomain hD) M)
    {k : ∀ i, D i} (hk : k ∈ M) :
    ∃ i : I, i ∈ rootSupport hD k ∧ ¬ Consistent (Function.eval i '' M) ∧
      IsMinimallyInconsistent (hD i) (Function.eval i '' M) ∧
      Set.InjOn (Function.eval i) M := by
  obtain ⟨i, hi⟩ := exists_bad_coordinate hD hM
  exact ⟨i, bad_coordinate_mem_support hD hM hk i hi, hi,
    project_mic hD hM i hi, project_injective_on_mic hD hM i hi⟩

end DIDomainClassification.BPSProductDegree
