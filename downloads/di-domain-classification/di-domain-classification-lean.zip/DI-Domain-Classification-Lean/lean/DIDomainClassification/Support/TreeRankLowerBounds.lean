import DIDomainClassification.Section02.RankDegree

/-!
Supporting lower bounds for the literal well-founded mic-tree rank model.
These prove facts about the actual accepted definitions, not the whole BPS
theorem or classification. There is no branching/cardinality bound added.
-/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Trees.RootedPrefixTree

theorem root_not_leaf_of_proper {Index : Type v} (T :
    DIDomainClassification.Trees.RootedPrefixTree Index) (hT : T.IsProper) :
    ¬ T.IsLeaf T.root := by
  letI : Nontrivial T.Node := hT.1
  obtain ⟨x, hx⟩ := exists_ne T.root
  intro hleaf
  exact hx (hleaf x (T.root_le x))

theorem one_le_treeRank_of_proper {Index : Type v} (T :
    DIDomainClassification.Trees.RootedPrefixTree Index)
    (hp : T.IsProper) (hT : T.IsWellFounded) :
    1 ≤ T.treeRank hT := by
  have hchild : ∃ x : T.Node, T.IsChild T.root x := by
    by_contra h
    exact T.root_not_leaf_of_proper hp ((T.isLeaf_iff_no_child T.root).mpr h)
  obtain ⟨x, hx⟩ := hchild
  rw [treeRank, nodeRank_eq]
  exact (show 1 ≤ T.nodeRank hT x + 1 from le_add_self).trans
    (Ordinal.le_iSup (fun y : {y : T.Node // T.IsChild T.root y} =>
      T.nodeRank hT y.val + 1) ⟨x, hx⟩)

end DIDomainClassification.Trees.RootedPrefixTree

namespace DIDomainClassification.CoherenceDegree

open Preliminaries

theorem WellFoundedMicTree.two_le_rankContribution {D : Type u}
    [PartialOrder D] {hD : IsScottDomain D} (M : WellFoundedMicTree D hD) :
    2 ≤ M.rankContribution := by
  have h : (2 : Ordinal.{u}) ≤ M.micTree.tree.treeRank M.wellFounded + 1 := by
    simpa only [one_add_one_eq_two] using
      (add_le_add
        (M.micTree.tree.one_le_treeRank_of_proper M.micTree.proper M.wellFounded)
        (le_rfl : (1 : Ordinal.{u}) ≤ 1))
  simpa [WellFoundedMicTree.rankContribution] using
    (Ordinal.lift_le.{u+1}.mpr h)

theorem coherenceDegree_eq_zero_or_two_le {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) : coherenceDegree hD = 0 ∨ 2 ≤ coherenceDegree hD := by
  by_cases h : Nonempty (WellFoundedMicTree D hD)
  · obtain ⟨M⟩ := h
    right
    exact M.two_le_rankContribution.trans
      ((coherenceDegree_isLUB hD).1 ⟨M, rfl⟩)
  · exact Or.inl (coherenceDegree_eq_zero_of_no_trees hD h)

theorem coherenceDegree_ne_one {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) : coherenceDegree hD ≠ 1 := by
  rcases coherenceDegree_eq_zero_or_two_le hD with h | h
  · rw [h]
    exact zero_ne_one
  · intro h1
    rw [h1] at h
    have h12 : (1 : Ordinal.{u+1}) < 2 := by
      simpa only [Order.succ_eq_add_one, one_add_one_eq_two] using
        (Order.lt_succ (1 : Ordinal.{u+1}))
    exact (not_le_of_gt h12) h

end DIDomainClassification.CoherenceDegree
