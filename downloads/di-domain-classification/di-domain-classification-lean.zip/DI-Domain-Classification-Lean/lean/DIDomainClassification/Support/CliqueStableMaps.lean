import DIDomainClassification.Section02.BinaryForbiddenClique
import DIDomainClassification.Section02.Retractions
import DIDomainClassification.Section02.StableCategory

/-! Actual image/preimage stable retractions of clique domains along an
induced graph embedding. Every continuity and meet law is proved on the
literal arbitrary-set clique carriers with their native inclusion orders. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.CliqueStableMaps

open Preliminaries Section02.BinaryCliqueModels

variable {A : Type u} {B : Type v}

def core (G : SimpleGraph A) (hG : IsDIDomain (CliqueCarrier G)) : DIDomainObject.{u} :=
  DIDomainObject.ofType (CliqueCarrier G) hG

def unionValues {G : SimpleGraph A} (F : Set (CliqueCarrier G)) : Set A :=
  {a | ∃ X ∈ F, a ∈ X.val}

def directedUnion (G : SimpleGraph A) (F : Set (CliqueCarrier G))
    (hF : DirectedOn (· ≤ ·) F) : CliqueCarrier G :=
  ⟨unionValues F, by
    rintro a ⟨X, hX, haX⟩ b ⟨Y, hY, hbY⟩ hab
    obtain ⟨Z, hZ, hXZ, hYZ⟩ := hF X hX Y hY
    exact Z.property (hXZ haX) (hYZ hbY) hab⟩

theorem directedUnion_isLUB (G : SimpleGraph A) (F : Set (CliqueCarrier G))
    (hF : DirectedOn (· ≤ ·) F) : IsLUB F (directedUnion G F hF) := by
  constructor
  · intro X hX a haX
    exact ⟨X, hX, haX⟩
  · intro Y hY a ha
    obtain ⟨X, hX, haX⟩ := ha
    exact hY hX haX

theorem isLUB_val (G : SimpleGraph A) (F : Set (CliqueCarrier G))
    (hF : DirectedOn (· ≤ ·) F) (X : CliqueCarrier G) (hX : IsLUB F X) :
    X.val = unionValues F :=
  congrArg Subtype.val (hX.unique (directedUnion_isLUB G F hF))

def intersection (G : SimpleGraph A) (X Y : CliqueCarrier G) : CliqueCarrier G :=
  ⟨X.val ∩ Y.val, X.property.subset Set.inter_subset_left⟩

theorem intersection_isGLB (G : SimpleGraph A) (X Y : CliqueCarrier G) :
    IsGLB ({X,Y} : Set (CliqueCarrier G)) (intersection G X Y) := by
  constructor
  · intro Z hZ
    rcases hZ with rfl | rfl
    · exact Set.inter_subset_left
    · exact Set.inter_subset_right
  · intro Z hZ
    exact Set.subset_inter (hZ (by simp)) (hZ (by simp))

theorem inf_val (G : SimpleGraph A) (hG : IsDIDomain (CliqueCarrier G))
    (X Y : core G hG) : (X ⊓ Y : core G hG).val = X.val ∩ Y.val :=
  congrArg Subtype.val ((DIDomainObject.inf_isGLB (core G hG) X Y).unique
    (intersection_isGLB G X Y))

variable (G : SimpleGraph A) (H : SimpleGraph B) (i : A → B)
  (hi : Function.Injective i) (hAdj : ∀ a b, G.Adj a b ↔ H.Adj (i a) (i b))

def imageMap (X : CliqueCarrier G) : CliqueCarrier H :=
  ⟨i '' X.val, by
    rintro _ ⟨a, ha, rfl⟩ _ ⟨b, hb, rfl⟩ hab
    exact (hAdj a b).mp (X.property ha hb (fun heq => hab (congrArg i heq)))⟩

def preimageMap (X : CliqueCarrier H) : CliqueCarrier G :=
  ⟨i ⁻¹' X.val, by
    intro a ha b hb hab
    exact (hAdj a b).mpr (X.property ha hb (fun heq => hab (hi heq)))⟩

theorem image_monotone : Monotone (imageMap G H i hAdj) := by
  rintro X Y hXY b ⟨a, ha, rfl⟩
  exact ⟨a, hXY ha, rfl⟩

theorem preimage_monotone : Monotone (preimageMap G H i hi hAdj) := by
  intro X Y hXY a ha
  exact hXY ha

theorem image_continuous : ScottContinuous (imageMap G H i hAdj) := by
  intro F _hne hdir X hX
  constructor
  · rintro _ ⟨Y, hY, rfl⟩
    exact image_monotone G H i hAdj (hX.1 hY)
  · intro Y hY b hb
    obtain ⟨a, ha, rfl⟩ := hb
    rw [isLUB_val G F hdir X hX] at ha
    obtain ⟨Z, hZ, haZ⟩ := ha
    exact hY ⟨Z, hZ, rfl⟩ ⟨a, haZ, rfl⟩

theorem preimage_continuous : ScottContinuous (preimageMap G H i hi hAdj) := by
  intro F _hne hdir X hX
  constructor
  · rintro _ ⟨Y, hY, rfl⟩
    exact preimage_monotone G H i hi hAdj (hX.1 hY)
  · intro Y hY a ha
    change i a ∈ X.val at ha
    rw [isLUB_val H F hdir X hX] at ha
    obtain ⟨Z, hZ, haZ⟩ := ha
    exact hY ⟨Z, hZ, rfl⟩ haZ

variable (hG : IsDIDomain (CliqueCarrier G)) (hH : IsDIDomain (CliqueCarrier H))

include hi in
theorem image_stable : IsStable (core G hG) (core H hH) (imageMap G H i hAdj) := by
  refine ⟨image_continuous G H i hAdj, ?_⟩
  intro X Y _hXY
  apply Subtype.ext
  change i '' (X ⊓ Y : core G hG).val =
    (imageMap G H i hAdj X ⊓ imageMap G H i hAdj Y : core H hH).val
  rw [inf_val G hG, inf_val H hH]
  exact Set.image_inter hi

theorem preimage_stable :
    IsStable (core H hH) (core G hG) (preimageMap G H i hi hAdj) := by
  refine ⟨preimage_continuous G H i hi hAdj, ?_⟩
  intro X Y _hXY
  apply Subtype.ext
  change i ⁻¹' (X ⊓ Y : core H hH).val =
    (preimageMap G H i hi hAdj X ⊓ preimageMap G H i hi hAdj Y : core G hG).val
  rw [inf_val H hH, inf_val G hG]
  rfl

def sectionMap : StableHom (core G hG) (core H hH) :=
  StableHom.ofFunction (imageMap G H i hAdj) (image_stable G H i hi hAdj hG hH)

def retraction : StableHom (core H hH) (core G hG) :=
  StableHom.ofFunction (preimageMap G H i hi hAdj) (preimage_stable G H i hi hAdj hG hH)

theorem leftInverse : Function.LeftInverse
    (retraction G H i hi hAdj hG hH : core H hH → core G hG)
    (sectionMap G H i hi hAdj hG hH : core G hG → core H hH) := by
  intro X
  apply Subtype.ext
  change i ⁻¹' (i '' X.val) = X.val
  exact Set.preimage_image_eq X.val hi

include i hi hAdj in
theorem hasRetraction : HasStableRetraction (core G hG) (core H hH) :=
  ⟨sectionMap G H i hi hAdj hG hH, retraction G H i hi hAdj hG hH,
    leftInverse G H i hi hAdj hG hH⟩

end DIDomainClassification.CliqueStableMaps
