import DIDomainClassification.Section02.BPSStatement
import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.ScottOperations
import Mathlib.Data.Set.Countable

/-!
Generic all-Scott function-space support. The carrier and order below are the
literal accepted raw Scott-function subtype and its native pointwise order.
No dI, stability, strictness, or countability of either whole carrier is used.
This is not a proof of the source BPS statement or its rank-refinement lemma.
-/

set_option autoImplicit false

universe u v w

noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open OrderCore Preliminaries

abbrev Space (D : Type u) (E : Type v) [PartialOrder D] [PartialOrder E] :=
  Section02.BPS.PointwiseScottSpace D E

variable {D : Type u} {E : Type v} [PartialOrder D] [PartialOrder E]

theorem space_le_iff (f g : Space D E) : f ≤ g ↔ ∀ x, f.val x ≤ g.val x := Iff.rfl

theorem space_ext {f g : Space D E} (h : ∀ x, f.val x = g.val x) : f = g :=
  Subtype.ext (funext h)

def values (A : Set (Space D E)) (x : D) : Set E := (fun f => f.val x) '' A

theorem values_directed {A : Set (Space D E)} (hA : DirectedSet A) (x : D) :
    DirectedSet (values A x) := hA.image (fun _ _ h => h x)

/-- Any existing pointwise supremum of Scott maps is again Scott continuous.
The indexing family need not be directed, nonempty, or bounded. -/
theorem scottContinuous_of_pointwise_isLUB {A : Set (Space D E)} {F : D → E}
    (hF : ∀ x, IsLUB (values A x) (F x)) : ScottContinuous F := by
  have hmono : Monotone F := by
    intro x y hxy
    apply (hF x).2
    rintro z ⟨f, hf, rfl⟩
    exact (f.property.monotone hxy).trans ((hF y).1 ⟨f, hf, rfl⟩)
  intro B hB hdir b hb
  refine ⟨?_, ?_⟩
  · rintro z ⟨x, hx, rfl⟩
    exact hmono (hb.1 hx)
  · intro z hz
    apply (hF b).2
    rintro q ⟨f, hf, rfl⟩
    apply (f.property hB hdir hb).2
    rintro q ⟨x, hx, rfl⟩
    exact ((hF x).1 ⟨f, hf, rfl⟩).trans (hz ⟨x, hx, rfl⟩)

def ofPointwiseIsLUB {A : Set (Space D E)} (F : D → E)
    (hF : ∀ x, IsLUB (values A x) (F x)) : Space D E :=
  ⟨F, scottContinuous_of_pointwise_isLUB hF⟩

theorem ofPointwiseIsLUB_isLUB {A : Set (Space D E)} (F : D → E)
    (hF : ∀ x, IsLUB (values A x) (F x)) :
    IsLUB A (ofPointwiseIsLUB F hF) := by
  constructor
  · intro f hf x
    exact (hF x).1 ⟨f, hf, rfl⟩
  · intro g hg x
    apply (hF x).2
    rintro z ⟨f, hf, rfl⟩
    exact hg hf x

theorem exists_directed_isLUB (hE : OrderCore.IsDcpo E)
    (A : Set (Space D E)) (hA : DirectedSet A) :
    ∃ f : Space D E, IsLUB A f ∧ ∀ x, IsLUB (values A x) (f.val x) := by
  choose F hF using fun x => hE (values A x) (values_directed hA x)
  exact ⟨ofPointwiseIsLUB F hF, ofPointwiseIsLUB_isLUB F hF, hF⟩

theorem space_isDcpo (hE : OrderCore.IsDcpo E) : OrderCore.IsDcpo (Space D E) := by
  intro A hA
  obtain ⟨f, hf, _⟩ := exists_directed_isLUB hE A hA
  exact ⟨f, hf⟩

/-- The reverse implication uses the constructed Scott-continuous supremum;
it is not inferred merely from the ambient Pi order. -/
theorem directed_isLUB_iff_values (hE : OrderCore.IsDcpo E)
    {A : Set (Space D E)} (hA : DirectedSet A) (f : Space D E) :
    IsLUB A f ↔ ∀ x, IsLUB (values A x) (f.val x) := by
  constructor
  · intro hf
    obtain ⟨g, hg, hvalues⟩ := exists_directed_isLUB hE A hA
    have hfg : f = g := hf.unique hg
    simpa only [hfg] using hvalues
  · intro hf
    exact ofPointwiseIsLUB_isLUB f.val hf

theorem space_boundedSuprema (hE : IsScottDomain E)
    (A : Set (Space D E)) (hA : BddAbove A) : ∃ f : Space D E, IsLUB A f := by
  obtain ⟨g, hg⟩ := hA
  have hb (x : D) : BddAbove (values A x) := by
    refine ⟨g.val x, ?_⟩
    rintro z ⟨f, hf, rfl⟩
    exact hg hf x
  choose F hF using fun x => hE.boundedSuprema (values A x) (hb x)
  exact ⟨ofPointwiseIsLUB F hF, ofPointwiseIsLUB_isLUB F hF⟩

def const (e : E) : Space D E := ⟨fun _ => e, ScottContinuous.const e⟩

theorem space_hasLeast (hE : IsScottDomain E) :
    ∃ f : Space D E, ∀ g, f ≤ g :=
  ⟨const hE.bottom, fun g x => hE.bottom_le (g.val x)⟩

/-- Compact-input step map, with arbitrary output value. -/
def step (hE : IsScottDomain E) (k : D) (hk : Compact k) (b : E) : Space D E := by
  classical
  let F : D → E := fun x => if k ≤ x then b else hE.bottom
  have hmono : Monotone F := by
    intro x y hxy
    dsimp [F]
    split_ifs with hx hy
    · exact le_rfl
    · exact False.elim (hy (hx.trans hxy))
    · exact hE.bottom_le b
    · exact le_rfl
  refine ⟨F, ?_⟩
  intro A hA hdir s hs
  refine ⟨?_, ?_⟩
  · rintro z ⟨x, hx, rfl⟩
    exact hmono (hs.1 hx)
  · intro z hz
    by_cases hks : k ≤ s
    · obtain ⟨a, ha, hka⟩ := hk ⟨hA, hdir⟩ hs hks
      have h := hz ⟨a, ha, rfl⟩
      simpa only [F, if_pos hka, if_pos hks] using h
    · simpa only [F, if_neg hks] using hE.bottom_le z

theorem step_apply (hE : IsScottDomain E) (k : D) (hk : Compact k) (b : E) (x : D) :
    (step hE k hk b).val x =
      @ite E (k ≤ x) (Classical.propDecidable _) b hE.bottom := by
  classical
  rfl

theorem step_le_iff (hE : IsScottDomain E) (k : D) (hk : Compact k) (b : E)
    (f : Space D E) : step hE k hk b ≤ f ↔ b ≤ f.val k := by
  classical
  constructor
  · intro h
    simpa only [step_apply, if_pos le_rfl] using h k
  · intro h x
    rw [step_apply]
    split_ifs with hkx
    · exact h.trans (f.property.monotone hkx)
    · exact hE.bottom_le _

theorem step_compact (hE : IsScottDomain E) (k : D) (hk : Compact k)
    (b : E) (hb : Compact b) : Compact (step hE k hk b) := by
  intro A s hA hs hstep
  have hsval := (directed_isLUB_iff_values hE.algebraic.1 hA s).1 hs k
  obtain ⟨_, ⟨f, hf, rfl⟩, hbf⟩ := hb (values_directed hA k) hsval
    ((step_le_iff hE k hk b s).1 hstep)
  exact ⟨f, hf, (step_le_iff hE k hk b f).2 hbf⟩

/-- A finite supremum of compact elements is compact, including the empty one.
Existence of this supremum is a conclusion's witness, not a lattice premise. -/
theorem compact_of_finite_isLUB {P : Type w} [PartialOrder P]
    {F : Set P} (hF : F.Finite) (hcompact : ∀ a ∈ F, Compact a)
    {q : P} (hq : IsLUB F q) : Compact q := by
  classical
  intro A s hA hs hqs
  have hw : ∀ a : F, ∃ z ∈ A, a.val ≤ z := by
    intro a
    exact hcompact a.val a.property hA hs ((hq.1 a.property).trans hqs)
  choose z hz haz using hw
  letI : Finite F := hF.to_subtype
  have hfin : (Set.range z).Finite := Set.finite_range z
  obtain ⟨a, ha, hza⟩ := hA.exists_upper_finite hfin (by
    rintro _ ⟨b, rfl⟩
    exact hz b)
  refine ⟨a, ha, ?_⟩
  apply hq.2
  intro b hb
  exact (haz ⟨b, hb⟩).trans (hza (z ⟨b, hb⟩) ⟨⟨b, hb⟩, rfl⟩)

/-- The step labels are actual compact elements, not enumerated domain points. -/
abbrev StepIndex (D : Type u) (E : Type v) [PartialOrder D] [PartialOrder E] :=
  {k : D // Compact k} × {b : E // Compact b}

def stepOf (hE : IsScottDomain E) (i : StepIndex D E) : Space D E :=
  step hE i.1.val i.1.property i.2.val

theorem stepOf_compact (hE : IsScottDomain E) (i : StepIndex D E) :
    Compact (stepOf hE i) := step_compact hE _ _ _ i.2.property

/-- Finite bounded families of actual step maps; boundedness is checked in the
literal function order. Nothing is assumed about other finite families. -/
abbrev Presentation (hE : IsScottDomain E) :=
  {S : Set (StepIndex D E) // S.Finite ∧ BddAbove (stepOf hE '' S)}

def finiteJoin (hE : IsScottDomain E) (S : Presentation (D := D) hE) : Space D E :=
  Classical.choose (space_boundedSuprema hE (stepOf hE '' S.val) S.property.2)

theorem finiteJoin_isLUB (hE : IsScottDomain E) (S : Presentation (D := D) hE) :
    IsLUB (stepOf hE '' S.val) (finiteJoin hE S) :=
  Classical.choose_spec (space_boundedSuprema hE (stepOf hE '' S.val) S.property.2)

theorem finiteJoin_compact (hE : IsScottDomain E) (S : Presentation (D := D) hE) :
    Compact (finiteJoin hE S) := by
  apply compact_of_finite_isLUB (S.property.1.image _) _ (finiteJoin_isLUB hE S)
  rintro f ⟨i, _hi, rfl⟩
  exact stepOf_compact hE i

theorem finiteJoin_le (hE : IsScottDomain E) (S : Presentation (D := D) hE)
    (f : Space D E) (h : ∀ i ∈ S.val, stepOf hE i ≤ f) : finiteJoin hE S ≤ f := by
  apply (finiteJoin_isLUB hE S).2
  rintro g ⟨i, hi, rfl⟩
  exact h i hi

def finiteApproximants (hE : IsScottDomain E) (f : Space D E) : Set (Space D E) :=
  finiteJoin hE '' {S : Presentation (D := D) hE | ∀ i ∈ S.val, stepOf hE i ≤ f}

theorem finiteApproximants_le (hE : IsScottDomain E) (f : Space D E)
    {g : Space D E} (hg : g ∈ finiteApproximants hE f) : g ≤ f := by
  obtain ⟨S, hS, rfl⟩ := hg
  exact finiteJoin_le hE S f hS

theorem finiteApproximants_compact (hE : IsScottDomain E) (f : Space D E)
    {g : Space D E} (hg : g ∈ finiteApproximants hE f) : Compact g := by
  obtain ⟨S, _hS, rfl⟩ := hg
  exact finiteJoin_compact hE S

theorem finiteApproximants_directed (hE : IsScottDomain E) (f : Space D E) :
    DirectedSet (finiteApproximants hE f) := by
  classical
  have hempty : BddAbove (stepOf hE '' (∅ : Set (StepIndex D E))) := by
    exact ⟨f, by simp⟩
  let S0 : Presentation (D := D) hE := ⟨∅, Set.finite_empty, hempty⟩
  refine ⟨⟨finiteJoin hE S0, ⟨S0, by simp [S0], rfl⟩⟩, ?_⟩
  rintro g ⟨S, hS, rfl⟩ q ⟨T, hT, rfl⟩
  have hU : BddAbove (stepOf hE '' (S.val ∪ T.val)) := by
    refine ⟨f, ?_⟩
    rintro g ⟨i, hi, rfl⟩
    exact hi.elim (hS i) (hT i)
  let U : Presentation (D := D) hE :=
    ⟨S.val ∪ T.val, S.property.1.union T.property.1, hU⟩
  refine ⟨finiteJoin hE U, ⟨U, ?_, rfl⟩, ?_, ?_⟩
  · intro i hi
    exact hi.elim (hS i) (hT i)
  · apply finiteJoin_le hE S
    intro i hi
    exact (finiteJoin_isLUB hE U).1 ⟨i, Or.inl hi, rfl⟩
  · apply finiteJoin_le hE T
    intro i hi
    exact (finiteJoin_isLUB hE U).1 ⟨i, Or.inr hi, rfl⟩

theorem finiteApproximants_isLUB (hD : IsScottDomain D) (hE : IsScottDomain E)
    (f : Space D E) : IsLUB (finiteApproximants hE f) f := by
  classical
  refine ⟨fun _ hg => finiteApproximants_le hE f hg, ?_⟩
  intro g hg x
  have hf := f.property (hD.algebraic.2 x).1.1 (hD.algebraic.2 x).1.2
    (hD.algebraic.2 x).2
  apply hf.2
  rintro y ⟨k, hk, rfl⟩
  apply (hE.algebraic.2 (f.val k)).2.2 (g.val x)
  intro b hb
  let i : StepIndex D E := (⟨k, hk.1⟩, ⟨b, hb.1⟩)
  have hif : stepOf hE i ≤ f := (step_le_iff hE k hk.1 b f).2 hb.2
  have hibdd : BddAbove (stepOf hE '' ({i} : Set (StepIndex D E))) := by
    refine ⟨f, ?_⟩
    rintro q ⟨j, hj, rfl⟩
    simpa only [Set.mem_singleton_iff.mp hj] using hif
  let S : Presentation (D := D) hE := ⟨{i}, Set.finite_singleton i, hibdd⟩
  have hS : finiteJoin hE S ∈ finiteApproximants hE f := by
    refine ⟨S, ?_, rfl⟩
    intro j hj
    simpa only [Set.mem_singleton_iff.mp hj] using hif
  have hbjoin : stepOf hE i ≤ finiteJoin hE S :=
    (finiteJoin_isLUB hE S).1 ⟨i, by simp [S], rfl⟩
  have hval := (hbjoin.trans (hg hS)) x
  simpa only [stepOf, i, step_apply, if_pos hk.2] using hval

theorem space_isAlgebraic (hD : IsScottDomain D) (hE : IsScottDomain E) :
    OrderCore.IsAlgebraicDcpo (Space D E) := by
  refine ⟨space_isDcpo hE.algebraic.1, ?_⟩
  have hB : IsBasis (CompactSet (Space D E)) := by
    apply isBasis_of_directed_approximants
    intro f
    refine ⟨finiteApproximants hE f, ?_, finiteApproximants_directed hE f,
      finiteApproximants_isLUB hD hE f⟩
    intro g hg
    have hc := finiteApproximants_compact hE f hg
    exact ⟨hc, (wayBelow_iff_le_of_compact hc).2 (finiteApproximants_le hE f hg)⟩
  intro f
  rw [compactBelow_eq_approximants f]
  exact hB f

theorem space_isScottDomain (hD : IsScottDomain D) (hE : IsScottDomain E) :
    IsScottDomain (Space D E) :=
  ⟨space_isAlgebraic hD hE, space_hasLeast hE, space_boundedSuprema hE⟩

/-- Exact finite-step-join description of ALL compact Scott maps. -/
theorem compact_iff_finiteJoin (hD : IsScottDomain D) (hE : IsScottDomain E)
    (f : Space D E) : Compact f ↔ ∃ S : Presentation (D := D) hE, f = finiteJoin hE S := by
  constructor
  · intro hf
    obtain ⟨g, hg, hfg⟩ := hf (finiteApproximants_directed hE f)
      (finiteApproximants_isLUB hD hE f) le_rfl
    obtain ⟨S, hS, rfl⟩ := hg
    exact ⟨S, le_antisymm hfg (finiteJoin_le hE S f hS)⟩
  · rintro ⟨S, rfl⟩
    exact finiteJoin_compact hE S

theorem space_compactSet_countable (hD : IsScottDomain D) (hE : IsScottDomain E)
    (hKD : (CompactSet D).Countable) (hKE : (CompactSet E).Countable) :
    (CompactSet (Space D E)).Countable := by
  classical
  letI : Countable {k : D // Compact k} := hKD.to_subtype
  letI : Countable {b : E // Compact b} := hKE.to_subtype
  have hfin : {S : Set (StepIndex D E) | S.Finite}.Countable :=
    Set.Countable.setOf_finite
  have hp : {S : Set (StepIndex D E) |
      S.Finite ∧ BddAbove (stepOf hE '' S)}.Countable := hfin.mono (fun _ h => h.1)
  letI : Countable (Presentation (D := D) hE) := hp.to_subtype
  apply (Set.countable_range (finiteJoin (D := D) hE)).mono
  intro f hf
  obtain ⟨S, hS⟩ := (compact_iff_finiteJoin hD hE f).1 hf
  exact ⟨S, hS.symm⟩

end DIDomainClassification.PointwiseFunctionSupport
