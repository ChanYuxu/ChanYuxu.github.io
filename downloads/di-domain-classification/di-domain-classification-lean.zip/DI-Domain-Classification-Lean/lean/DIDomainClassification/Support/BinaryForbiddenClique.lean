import DIDomainClassification.Section02.BinaryForbiddenCliqueStatement
import Mathlib.Data.Nat.Find

/-!
Finite forbidden subsets and the literal graph-clique event presentation.
The event carrier and configuration subsets are arbitrary; only each forbidden
member is finite. In particular the forbidden family need not be an antichain.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.BinaryCliqueSupport

open EventStructures Section02.BinaryCliqueModels

variable {A : Type u}

/-- A finite forbidden member contains an inclusion-minimal forbidden member,
even if the family as a whole is infinite and not an antichain. -/
theorem minimal_forbidden_below (F : Set (Set A))
    (hFinite : ∀ U ∈ F, U.Finite) {U : Set A} (hU : U ∈ F) :
    ∃ V ∈ F, V ⊆ U ∧ ∀ W ∈ F, ¬ W ⊂ V := by
  classical
  let P : ℕ → Prop := fun n => ∃ V ∈ F, V ⊆ U ∧ V.ncard = n
  have hExists : ∃ n, P n := ⟨U.ncard, U, hU, Set.Subset.refl U, rfl⟩
  obtain ⟨V, hV, hVU, hCard⟩ := Nat.find_spec hExists
  refine ⟨V, hV, hVU, ?_⟩
  intro W hW hWV
  have hMin : Nat.find hExists ≤ W.ncard :=
    Nat.find_min' hExists ⟨W, hW, hWV.1.trans hVU, rfl⟩
  have hLt := Set.ncard_lt_ncard hWV (hFinite V hV)
  rw [hCard] at hLt
  exact (not_lt_of_ge hMin) hLt

variable [PartialOrder A]

theorem consistent_isConfiguration (E : FinitaryPrimeEventStructure A)
    (hQual : IsQualitativePresentation E) {X : Set A} (hX : X ∈ E.Con) :
    IsConfiguration E X := by
  refine ⟨?_, fun F _hF hFX => E.hereditary hFX hX⟩
  intro a b hab ha
  have hba : b = a := (hQual b a).mp hab
  simpa only [hba] using ha

theorem configuration_isClique (E : FinitaryPrimeEventStructure A)
    {X : Set A} (hX : IsConfiguration E X) : (compatibilityGraph E).IsClique X := by
  intro a ha b hb hab
  exact ⟨hab, hX.2 {a, b} ((Set.finite_singleton b).insert a) (by
    intro c hc
    rcases hc with rfl | rfl
    · exact ha
    · exact hb)⟩

theorem configuration_iff_clique (E : FinitaryPrimeEventStructure A)
    (F : Set (Set A)) (hQual : IsQualitativePresentation E)
    (hF : IsForbiddenFamilyPresentation E F) (hBinary : HasBinaryMinimalMembers F)
    (X : Set A) : IsConfiguration E X ↔ (compatibilityGraph E).IsClique X := by
  constructor
  · exact configuration_isClique E
  · intro hClique
    apply (hF.2 X).mpr
    intro U hU hUX
    obtain ⟨V, hV, hVU, hMin⟩ :=
      minimal_forbidden_below F (fun W hW => (hF.1 W hW).2) hU
    obtain ⟨a, b, hab, hPair⟩ := Set.ncard_eq_two.mp (hBinary V hV hMin)
    have ha : a ∈ X := hUX (hVU (hPair.symm ▸ Set.mem_insert a {b}))
    have hb : b ∈ X := hUX (hVU (hPair.symm ▸ (by simp : b ∈ ({a, b} : Set A))))
    have hCon : V ∈ E.Con := hPair.symm ▸ (hClique ha hb hab).2
    exact (hF.2 V).mp (consistent_isConfiguration E hQual hCon) V hV (Set.Subset.refl V)

/-- The equivalence is identity on event subsets and on the inclusion order. -/
def configurationCliqueOrderIso (E : FinitaryPrimeEventStructure A)
    (G : SimpleGraph A) (h : ∀ X : Set A, IsConfiguration E X ↔ G.IsClique X) :
    Configuration E ≃o CliqueCarrier G where
  toFun X := ⟨X.val, (h X.val).mp X.property⟩
  invFun X := ⟨X.val, (h X.val).mpr X.property⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := by intro X Y; exact Iff.rfl

end DIDomainClassification.BinaryCliqueSupport

namespace DIDomainClassification.BinaryCliqueSupport

open EventStructures Section02.BinaryCliqueModels

variable {A : Type u}

/-- The graph's exact equality-order presentation; consistency means finite
clique, not a separately assumed representation theorem. -/
def graphEventStructure (G : SimpleGraph A) :
    @FinitaryPrimeEventStructure A (equalityOrder A) := by
  letI : PartialOrder A := equalityOrder A
  refine {
    Con := graphCon G
    finite_principalIdeal := ?_
    finite_of_mem_Con := fun hF => hF.1
    empty_mem_Con := ⟨Set.finite_empty, SimpleGraph.isClique_empty⟩
    singleton_mem_Con := fun a => ⟨Set.finite_singleton a, SimpleGraph.isClique_singleton a⟩
    hereditary := fun hFG hG => ⟨hG.1.subset hFG, hG.2.subset hFG⟩
    causal_closure := ?_ }
  · intro a
    exact Set.finite_singleton a
  · intro F a b hF hab hb
    change a = b at hab
    subst a
    simpa only [Set.union_singleton, Set.insert_eq_of_mem hb] using hF

theorem graph_configuration_iff (G : SimpleGraph A) (X : Set A) :
    letI : PartialOrder A := equalityOrder A
    IsConfiguration (graphEventStructure G) X ↔ G.IsClique X := by
  letI : PartialOrder A := equalityOrder A
  constructor
  · intro hX a ha b hb hab
    have hPair := hX.2 {a, b} ((Set.finite_singleton b).insert a) (by
      intro c hc
      rcases hc with rfl | rfl
      · exact ha
      · exact hb)
    exact SimpleGraph.isClique_pair.mp hPair.2 hab
  · intro hX
    refine ⟨?_, fun F hF hFX => ⟨hF, hX.subset hFX⟩⟩
    intro a b hab ha
    change b = a at hab
    subst b
    exact ha

theorem graph_forbidden_presentation (G : SimpleGraph A) :
    letI : PartialOrder A := equalityOrder A
    IsForbiddenFamilyPresentation (graphEventStructure G) (graphForbidden G) := by
  letI : PartialOrder A := equalityOrder A
  constructor
  · rintro U ⟨a, b, _hab, _hnadj, rfl⟩
    exact ⟨⟨a, by simp⟩, (Set.finite_singleton b).insert a⟩
  · intro X
    rw [graph_configuration_iff]
    constructor
    · intro hX U hU hUX
      obtain ⟨a, b, hab, hnadj, rfl⟩ := hU
      exact hnadj (hX (hUX (by simp)) (hUX (by simp)) hab)
    · intro hX a ha b hb hab
      by_contra hnadj
      apply hX {a, b} ⟨a, b, hab, hnadj, rfl⟩
      intro c hc
      rcases hc with rfl | rfl
      · exact ha
      · exact hb

theorem graph_forbidden_binary (G : SimpleGraph A) :
    HasBinaryMinimalMembers (graphForbidden G) := by
  rintro U ⟨a, b, hab, _hnadj, rfl⟩ _hMin
  exact Set.ncard_eq_two.mpr ⟨a, b, hab, rfl⟩

end DIDomainClassification.BinaryCliqueSupport
