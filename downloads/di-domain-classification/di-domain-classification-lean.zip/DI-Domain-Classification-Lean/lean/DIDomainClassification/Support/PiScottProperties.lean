import DIDomainClassification.Support.PiAlgebraic
import DIDomainClassification.Section02.ScottOperations
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Set.Finite.Lemmas

/-!
# Bounded completeness, compatible distributivity and finite compact ideals

Only compatible joins are used. The third element in the distributivity law
is arbitrary. Finiteness below a compact tuple is proved for the whole lower
ideal via restriction to its finite support, not merely for compact points.
-/

set_option autoImplicit false

universe u v

namespace DIDomainClassification.PiTheory

open OrderCore Preliminaries

variable {I : Type v} {D : I → Type u} [∀ i, PartialOrder (D i)]

theorem pi_boundedSuprema (hD : ∀ i, IsScottDomain (D i))
    (A : Set (∀ i, D i)) (hA : BddAbove A) : ∃ s, IsLUB A s := by
  choose s hs using fun i => (hD i).boundedSuprema (Function.eval i '' A)
    (bddAbove_pi.mp hA i)
  exact ⟨s, isLUB_pi.mpr hs⟩

theorem pi_distributive (hD : ∀ i, IsDIDomain (D i)) :
    CompatibleJoinDistributive (∀ i, D i) := by
  intro x y z joined meet left right hxy hj hm hl hr
  apply isLUB_pi.mpr
  intro i
  obtain ⟨u, hxu, hyu⟩ := hxy
  have hci : DIDomainClassification.Compatible (x i) (y i) := ⟨u i, hxu i, hyu i⟩
  have hj' : IsLUB ({x i, y i} : Set (D i)) (joined i) := by
    simpa only [Set.image_insert_eq, Set.image_singleton] using isLUB_pi.mp hj i
  have hm' : IsGLB ({joined i, z i} : Set (D i)) (meet i) := by
    simpa only [Set.image_insert_eq, Set.image_singleton] using isGLB_pi.mp hm i
  have hl' : IsGLB ({x i, z i} : Set (D i)) (left i) := by
    simpa only [Set.image_insert_eq, Set.image_singleton] using isGLB_pi.mp hl i
  have hr' : IsGLB ({y i, z i} : Set (D i)) (right i) := by
    simpa only [Set.image_insert_eq, Set.image_singleton] using isGLB_pi.mp hr i
  simpa only [Set.image_insert_eq, Set.image_singleton] using
    (hD i).distributive (x i) (y i) (z i) (joined i) (meet i) (left i) (right i)
      hci hj' hm' hl' hr'

section Bottom

variable [∀ i, OrderBot (D i)]

theorem finite_Iic_of_finite_support (x : ∀ i, D i)
    (hsupport : (support x).Finite) (hfinite : ∀ i, (Set.Iic (x i)).Finite) :
    (Set.Iic x).Finite := by
  classical
  let F : Finset I := hsupport.toFinset
  let restriction : (∀ i, D i) → ((i : F) → D i) := fun y i => y i
  have htarget : (Set.Iic (fun i : F => x i)).Finite := by
    change {a : (i : F) → D i | ∀ i, a i ≤ x i}.Finite
    exact Set.Finite.pi' (fun i : F => hfinite i)
  apply Set.Finite.of_injOn (f := restriction) (s := Set.Iic x)
    (t := Set.Iic (fun i : F => x i))
    (fun y hy i => hy i) ?_ htarget
  intro y hy z hz heq
  funext i
  by_cases hi : i ∈ F
  · exact congrFun heq ⟨i, hi⟩
  · have hinot : i ∉ support x := by
      simpa only [F, Set.Finite.mem_toFinset] using hi
    have hxi : x i = ⊥ := (not_mem_support x i).mp hinot
    have hyi : y i = ⊥ := le_antisymm (by simpa only [hxi] using hy i) bot_le
    have hzi : z i = ⊥ := le_antisymm (by simpa only [hxi] using hz i) bot_le
    exact hyi.trans hzi.symm

theorem pi_isScottDomain (hD : ∀ i, IsScottDomain (D i)) :
    IsScottDomain (∀ i, D i) where
  algebraic := pi_isAlgebraicDcpo (fun i => (hD i).algebraic)
  hasLeast := ⟨⊥, fun _ => bot_le⟩
  boundedSuprema := pi_boundedSuprema hD

theorem pi_isDIDomain (hD : ∀ i, IsDIDomain (D i)) : IsDIDomain (∀ i, D i) where
  toIsScottDomain := pi_isScottDomain (fun i => (hD i).toIsScottDomain)
  distributive := pi_distributive hD
  finitePrincipalIdeals := by
    intro x hx
    exact finite_Iic_of_finite_support x (compact_finite_support hx)
      (fun i => (hD i).finitePrincipalIdeals (x i) (compact_coordinate hx i))

end Bottom

end DIDomainClassification.PiTheory
