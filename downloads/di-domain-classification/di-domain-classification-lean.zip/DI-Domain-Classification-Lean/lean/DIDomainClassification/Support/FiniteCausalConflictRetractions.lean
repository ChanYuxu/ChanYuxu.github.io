import DIDomainClassification.Support.FiniteCubeRetractions
import DIDomainClassification.Section04.CausalAntichains
import Mathlib.Data.Fintype.EquivFin

/-! Actual fixed-background stable splittings for arbitrary event carriers.
Only the minimal lower conflict is finite; the ambient event structure need
not be finite or countably based. Every native cube certificate is an output. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FiniteCausalConflictRetractions

open Preliminaries EventStructures FiniteCausalConflicts Section04
open Section04.FiniteCategoryModels Section04.PartitionRetractionModels

variable {A : Type u} [PartialOrder A] {n : ℕ}

omit [PartialOrder A] in
theorem event_injective {H : Set A} (e : Fin n ≃ H) :
    Function.Injective (fun i => (e i).val) :=
  Subtype.val_injective.comp e.injective

def enumeration (H : Set A) (hH : H.Finite) : Fin H.ncard ≃ H := by
  letI : Fintype H := hH.fintype
  apply (Fintype.equivFinOfCardEq (α := H) ?_).symm
  rw [← Nat.card_eq_fintype_card, Nat.card_coe_set_eq]

def sectionValues (U H : Set A) (e : Fin n ≃ H) (S : Set (Fin n)) : Set A :=
  (U \ H) ∪ (fun i => (e i).val) '' S

def retractionValues {H : Set A} (e : Fin n ≃ H) (X : Set A) : Set (Fin n) :=
  {i | (e i).val ∈ X}

theorem section_subset (U H : Set A) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (S : Set (Fin n)) : sectionValues U H e S ⊆ U := by
  rintro a (ha | ⟨i, _hi, rfl⟩)
  · exact ha.1
  · exact maximalEvents_subset U (hH ▸ (e i).property)

theorem section_lower (U H : Set A) (hLower : IsLowerSet U)
    (hH : H = maximalEvents U) (e : Fin n ≃ H) (S : Set (Fin n)) :
    IsLowerSet (sectionValues U H e S) := by
  intro b a hab hb
  have hbU := section_subset U H hH e S hb
  have haU : a ∈ U := hLower hab hbU
  by_cases haH : a ∈ H
  · have hmax : a ∈ maximalEvents U := hH ▸ haH
    have hba : b = a := hmax.2 b hbU hab
    simpa only [hba] using hb
  · exact Or.inl ⟨haU, haH⟩

theorem section_proper (U H : Set A) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (S : Set (Fin n)) (hS : S ≠ Set.univ) :
    sectionValues U H e S ⊂ U := by
  refine ⟨section_subset U H hH e S, ?_⟩
  intro hback
  apply hS
  apply Set.eq_univ_of_forall
  intro i
  have hiU : (e i).val ∈ U := maximalEvents_subset U (hH ▸ (e i).property)
  rcases hback hiU with hiB | ⟨j, hj, hji⟩
  · exact False.elim (hiB.2 (e i).property)
  · exact (event_injective e hji) ▸ hj

def sectionMap (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n)
    (S : CubeCarrier.{u} n hm) : Configuration E := by
  have hLower := section_lower U H hU.2.1 hH e S.down.val
  have hProper := section_proper U H hH e S.down.val S.down.property
  have hCon := hU.2.2.2 _ hProper hLower
  exact ⟨sectionValues U H e S.down.val,
    hLower, fun F _hF hsub => E.hereditary hsub hCon⟩

def retractionMap (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n)
    (X : Configuration E) : CubeCarrier.{u} n hm := by
  refine ⟨⟨retractionValues e X.val, ?_⟩⟩
  intro hall
  apply hU.2.2.1
  apply X.property.2 U hU.1
  intro a ha
  have hDown : a ∈ downClosure H := by
    rw [hH, ← finite_lower_eq_down_maximalEvents hU.1 hU.2.1]
    exact ha
  obtain ⟨b, hbH, hab⟩ := hDown
  obtain ⟨i, hi⟩ := e.surjective ⟨b, hbH⟩
  have himem : i ∈ retractionValues e X.val := by
    rw [hall]
    exact Set.mem_univ i
  have hbX : b ∈ X.val := by
    change (e i).val ∈ X.val at himem
    simpa only [hi] using himem
  exact X.property.1 hab hbX

theorem section_monotone (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n) :
    Monotone (sectionMap E U H hU hH e hm) := by
  intro S T hST a ha
  rcases ha with ha | ⟨i, hi, rfl⟩
  · exact Or.inl ha
  · exact Or.inr ⟨i, hST hi, rfl⟩

theorem retraction_monotone (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n) :
    Monotone (retractionMap E U H hU hH e hm) := by
  intro X Y hXY i hi
  exact hXY hi

omit [PartialOrder A] in
theorem section_intersection (U H : Set A) (e : Fin n ≃ H)
    (S T : Set (Fin n)) :
    sectionValues U H e (S ∩ T) =
      sectionValues U H e S ∩ sectionValues U H e T := by
  ext a
  constructor
  · rintro (ha | ⟨i, hi, rfl⟩)
    · exact ⟨Or.inl ha, Or.inl ha⟩
    · exact ⟨Or.inr ⟨i, hi.1, rfl⟩, Or.inr ⟨i, hi.2, rfl⟩⟩
  · rintro ⟨(ha | ⟨i, hi, hia⟩), (hb | ⟨j, hj, hja⟩)⟩
    · exact Or.inl ha
    · exact Or.inl ha
    · exact Or.inl hb
    · have hij : i = j := event_injective e (hia.trans hja.symm)
      exact Or.inr ⟨i, ⟨hi, hij.symm ▸ hj⟩, hia⟩

theorem configuration_isLUB_values (E : FinitaryPrimeEventStructure A)
    (C : Set (Configuration E)) (hC : OrderCore.DirectedSet C)
    (X : Configuration E) (hX : IsLUB C X) : X.val = ⋃ Y ∈ C, Y.val := by
  obtain ⟨Z, hZ, hZlub⟩ := configurationDirectedUnions A E C hC
  exact (congrArg Subtype.val (hX.unique hZlub)).trans hZ

theorem configuration_inf_values (E : FinitaryPrimeEventStructure A)
    (X Y : configurationCore E) : (X ⊓ Y).val = X.val ∩ Y.val := by
  have h := (DIDomainObject.inf_isGLB (configurationCore E) X Y).unique
    (ConfigurationDomain.intersection_isGLB E X Y)
  exact congrArg Subtype.val h

theorem retraction_scottContinuous (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n) :
    ScottContinuous (retractionMap E U H hU hH e hm) := by
  intro C hne hdir X hX
  constructor
  · rintro _ ⟨Y, hY, rfl⟩
    exact retraction_monotone E U H hU hH e hm (hX.1 hY)
  · intro Z hZ i hi
    change (e i).val ∈ X.val at hi
    rw [configuration_isLUB_values E C ⟨hne, hdir⟩ X hX] at hi
    obtain ⟨Y, hi⟩ := Set.mem_iUnion.mp hi
    obtain ⟨hY, hi⟩ := Set.mem_iUnion.mp hi
    exact hZ ⟨Y, hY, rfl⟩ hi

def stableSection (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n)
    (hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hm)) :
    StableHom (cubeCore n hm hCube.1) (configurationCore E) :=
  StableHom.ofFunction (sectionMap E U H hU hH e hm) ⟨
    FiniteOrderDomains.scottContinuous_of_monotone_finite
      (section_monotone E U H hU hH e hm), by
    intro S T _hST
    apply Subtype.ext
    change sectionValues U H e (hCube.1.toIsScottDomain.inf S T).down.val = _
    rw [FiniteCubeRetractions.cube_inf_values n hm hCube.1]
    rw [configuration_inf_values]
    exact section_intersection U H e S.down.val T.down.val⟩

def stableRetraction (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n)
    (hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hm)) :
    StableHom (configurationCore E) (cubeCore n hm hCube.1) :=
  StableHom.ofFunction (retractionMap E U H hU hH e hm) ⟨
    retraction_scottContinuous E U H hU hH e hm, by
    intro X Y _hXY
    apply FiniteCubeRetractions.cube_ext
    change retractionValues e (X ⊓ Y).val =
      (hCube.1.toIsScottDomain.inf (retractionMap E U H hU hH e hm X)
        (retractionMap E U H hU hH e hm Y)).down.val
    rw [FiniteCubeRetractions.cube_inf_values n hm hCube.1]
    rw [configuration_inf_values]
    rfl⟩

theorem leftInverse (E : FinitaryPrimeEventStructure A) (U H : Set A)
    (hU : IsMinimallyInconsistentFiniteLowerSet E U) (hH : H = maximalEvents U)
    (e : Fin n ≃ H) (hm : 2 ≤ n) :
    Function.LeftInverse (retractionMap E U H hU hH e hm) (sectionMap E U H hU hH e hm) := by
  intro S
  apply FiniteCubeRetractions.cube_ext
  ext i
  constructor
  · rintro (hi | ⟨j, hj, hji⟩)
    · exact False.elim (hi.2 (e i).property)
    · exact (event_injective e hji) ▸ hj
  · intro hi
    exact Or.inr ⟨i, hi, rfl⟩

theorem conflictRetraction : TruncatedConflictRetractionStatement.{u} := by
  intro A _ E H hH
  obtain ⟨U, hU, hHU⟩ := hH
  obtain ⟨hFin, _hAnti, _hDown, hCard⟩ := (causalAntichains A E).2.1 U hU
  have hm : 2 ≤ H.ncard := hHU ▸ hCard
  have hHfin : H.Finite := hHU ▸ hFin
  let e := enumeration H hHfin
  let hCube := FiniteCubeRetractions.cubeCountablyBased.{u} H.ncard hm
  exact ⟨hm, U, hU, e, hCube, stableSection E U H hU hHU e hm hCube,
    stableRetraction E U H hU hHU e hm hCube, hHU, (fun _ => rfl), (fun _ => rfl),
    leftInverse E U H hU hHU e hm⟩

end DIDomainClassification.FiniteCausalConflictRetractions
