import DIDomainClassification.Support.IntrinsicAmbientCore
import DIDomainClassification.Section02.CountableProducts
import DIDomainClassification.Section04.AdditionalSourceModels
import DIDomainClassification.Section02.Inherited
import DIDomainClassification.Section02.BPSFiniteDegree

/-! A generic finite-product closure lemma. This is not a source classification
theorem: a caller must independently establish the stated unit, binary-product
and repleteness hypotheses for its object class. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FinitePowerMembership
open Preliminaries Subcategories Section03.StableFunctionModels
open Section04.AdditionalSourceModels
open Section04.CutModels

def powerCertificate (D : CountablyBasedDIDomain.{u}) (n : ℕ) :
    IsCountablyBasedDIDomain (Fin n → Core D) :=
  (Section02.countableProducts (Fin n) (fun _ => Core D)
    (fun _ => ⟨(Core D).isDIDomain,D.countableCompacts⟩)).1

def power (D : CountablyBasedDIDomain.{u}) (n : ℕ) : CountablyBasedDIDomain.{u} :=
  cbObject (Fin n → Core D) (powerCertificate D n)

abbrev unit : CountablyBasedDIDomain.{u} :=
  Section02.StableBackground.terminalObject trueClosure

abbrev product (D E : CountablyBasedDIDomain.{u}) : CountablyBasedDIDomain.{u} :=
  Section02.StableBackground.productObject trueClosure D E

def zeroOrderIso (D : CountablyBasedDIDomain.{u}) :
    Core (power D 0) ≃o Core unit.{u} where
  toFun _ := PUnit.unit
  invFun _ := Fin.elim0
  left_inv f := by funext i; exact Fin.elim0 i
  right_inv x := by cases x; rfl
  map_rel_iff' := by
    intro f g
    constructor
    · intro _ i; exact Fin.elim0 i
    · intro _; exact le_rfl

def succOrderIso (D : CountablyBasedDIDomain.{u}) (n : ℕ) :
    Core (power D (n+1)) ≃o Core (product D (power D n)) where
  toFun f := (f 0,fun i => f i.succ)
  invFun p := Fin.cases p.1 p.2
  left_inv f := by
    funext i
    refine Fin.cases ?_ (fun j => ?_) i <;> rfl
  right_inv p := by
    apply Prod.ext
    · rfl
    · funext i; rfl
  map_rel_iff' := by
    intro f g
    change (f 0 ≤ g 0 ∧ ∀ i : Fin n, f i.succ ≤ g i.succ) ↔ ∀ i, f i ≤ g i
    constructor
    · rintro ⟨h0,hs⟩ i
      exact Fin.cases h0 hs i
    · intro h
      exact ⟨h 0,fun i => h i.succ⟩

theorem transport_membership (P : ObjectClass.{u}) (hP : IsReplete P)
    {D E : CountablyBasedDIDomain.{u}} (e : Core D ≃o Core E) (hD : P D) : P E :=
  hP.of_iso (IntrinsicAmbient.orderIsoIso e) hD

theorem finitePower_mem (P : ObjectClass.{u}) (hR : IsReplete P) (hUnit : P unit)
    (hProduct : ∀ D E, P D → P E → P (product D E))
    (D : CountablyBasedDIDomain.{u}) (hD : P D) (n : ℕ) : P (power D n) := by
  induction n with
  | zero =>
      exact transport_membership P hR (zeroOrderIso D).symm hUnit
  | succ n ih =>
      exact transport_membership P hR (succOrderIso D n).symm
        (hProduct D (power D n) hD ih)

theorem finitePower_mem_certificate (P : ObjectClass.{u}) (hR : IsReplete P)
    (hUnit : P unit) (hProduct : ∀ D E, P D → P E → P (product D E))
    (D : CountablyBasedDIDomain.{u}) (hD : P D) (n : ℕ)
    (h : IsCountablyBasedDIDomain (Fin n → Core D)) :
    P (cbObject (Fin n → Core D) h) :=
  finitePower_mem P hR hUnit hProduct D hD n

theorem unit_mem (P : ObjectClass.{u}) (hP : CategoryHypotheses P) : P unit.{u} := by
  obtain ⟨D,hD,_hxy⟩ := hP.1
  apply hP.2.2.2 unit D hD
  refine ⟨IntrinsicAmbient.constant unit D (Core D).isDIDomain.toIsScottDomain.bottom,
    IntrinsicAmbient.constant D unit PUnit.unit, ?_⟩
  intro x
  exact Subsingleton.elim _ _

theorem product_mem (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (D E : CountablyBasedDIDomain.{u}) (hD : P D) (hE : P E) : P (product D E) := by
  obtain ⟨hProducts,_hAdj⟩ := hP.2.2.1
  letI : CategoryTheory.Limits.HasFiniteProducts (FullStableSubcategory P) := hProducts
  let X : FullStableSubcategory P := ⟨D,hD⟩
  let Y : FullStableSubcategory P := ⟨E,hE⟩
  obtain ⟨e⟩ := (Section02.inherited P hP.2.1 hP.1 hP.2.2.2 hP.2.2.1
    hProducts X Y).1
  exact hP.2.1.of_iso e (CategoryTheory.Limits.prod X Y).property

theorem finitePower_mem_of_category (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (D : CountablyBasedDIDomain.{u}) (hD : P D) (n : ℕ)
    (h : IsCountablyBasedDIDomain (Fin n → Core D)) :
    P (cbObject (Fin n → Core D) h) :=
  finitePower_mem_certificate P hP.2.1 (unit_mem P hP) (product_mem P hP) D hD n h

theorem finite_degree_lt_omega (D : CountablyBasedDIDomain.{u}) [Finite (Core D)] :
    objectDegree D < Ordinal.omega0 := by
  let n := max 2 (Nat.card (Core D))
  have hn : 2 ≤ n := le_max_left _ _
  have hN : CoherenceDegree.IsNCoherent (Core D).isDIDomain.toIsScottDomain n hn := by
    intro M _hM
    exact (Set.ncard_le_card M).trans (le_max_right _ _)
  have hκ := (CoherenceDegree.finite_degree_iff_nCoherent
    (Core D).isDIDomain.toIsScottDomain n hn).mpr hN
  exact hκ.trans_lt (Ordinal.natCast_lt_omega0 n)

theorem nontrivial_of_two_le_degree (D : CountablyBasedDIDomain.{u})
    (h : 2 ≤ objectDegree D) : Nontrivial (Core D) := by
  classical
  by_contra hN
  have hs : Subsingleton (Core D) := ⟨fun x y => by
    by_contra hxy
    exact hN ⟨⟨x,y,hxy⟩⟩⟩
  let b : Core D := (Core D).isDIDomain.toIsScottDomain.bottom
  have hc : ∀ A : Set (Core D), (∃ s, IsLUB A s) ∧ ∃ s, IsGLB A s := by
    intro A
    exact ⟨⟨b,fun x _ => (hs.elim x b).le,fun x _ => (hs.elim b x).le⟩,
      ⟨b,fun x _ => (hs.elim b x).le,fun x _ => (hs.elim x b).le⟩⟩
  have hz := Section02.BPSProof.degree_zero_of_complete
    (Core D).isDIDomain.toIsScottDomain hc
  change CoherenceDegree.coherenceDegree (Core D).isDIDomain.toIsScottDomain = 0 at hz
  change 2 ≤ CoherenceDegree.coherenceDegree (Core D).isDIDomain.toIsScottDomain at h
  rw [hz] at h
  exact (not_le_of_gt (zero_lt_two : (0 : Ordinal.{u+1}) < 2)) h

end DIDomainClassification.FinitePowerMembership
