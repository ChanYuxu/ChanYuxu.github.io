import DIDomainClassification.Support.ForestUniverseTransport
import DIDomainClassification.Support.OrdinalCutWitnesses

/-! Generic mixed-universe transport of an explicit native stable split.
The enlarged level is explicitly max u v. Only the source of the native
stable function space is lifted. Countable basis and two-coherence are proved
from the actual lift order isomorphism; no degree equation or paper theorem
is a premise or conclusion. No strictness or EP inequality is imposed. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.StableSplitUniverseLift

open Preliminaries CoherenceDegree Section04.AdditionalSourceModels

def liftedCertificate (H : CountablyBasedDIDomain.{v}) :
    IsCountablyBasedDIDomain (ULift.{u} H.toDIDomainObject) :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff
    (ForestProductMaps.liftOrderIso H.toDIDomainObject)).mpr
      ⟨H.toDIDomainObject.isDIDomain, H.countableCompacts⟩

def liftedObject (H : CountablyBasedDIDomain.{v}) : CountablyBasedDIDomain.{max u v} :=
  cbObject (ULift.{u} H.toDIDomainObject) (liftedCertificate.{u} H)

theorem liftedTwoCoherent (H : CountablyBasedDIDomain.{v})
    (hH : IsNCoherent H.toDIDomainObject.isDIDomain.toIsScottDomain 2 (by decide)) :
    IsNCoherent (liftedObject.{u} H).toDIDomainObject.isDIDomain.toIsScottDomain
      2 (by decide) :=
  OrdinalCutWitnesses.nCoherent_orderIso
    (ForestProductMaps.liftOrderIso H.toDIDomainObject)
    (liftedCertificate.{u} H).1.toIsScottDomain
    H.toDIDomainObject.isDIDomain.toIsScottDomain 2 (by decide) hH

/-- This is the native stable order, not pointwise comparison of functions. -/
def functionOrderIso (H : CountablyBasedDIDomain.{v}) (E : DIDomainObject.{max u v}) :
    functionCore H.toDIDomainObject E ≃o
      functionCore (liftedObject.{u} H).toDIDomainObject E :=
  ForestUniverseTransport.inputOrderIso H.toDIDomainObject
    (liftedObject.{u} H).toDIDomainObject E
    (ForestProductMaps.liftOrderIso H.toDIDomainObject)

def sectionMap (X : DIDomainObject.{v}) (H : CountablyBasedDIDomain.{v})
    (E X' : DIDomainObject.{max u v}) (qX : X' ≃o X)
    (s : StableHom X (functionCore H.toDIDomainObject E)) :
    StableHom X' (functionCore (liftedObject.{u} H).toDIDomainObject E) :=
  StableHom.comp (OrderIsoTransport.stableHom _ _ (functionOrderIso H E))
    (StableHom.comp s (OrderIsoTransport.stableHom X' X qX))

def retractionMap (X : DIDomainObject.{v}) (H : CountablyBasedDIDomain.{v})
    (E X' : DIDomainObject.{max u v}) (qX : X' ≃o X)
    (r : StableHom (functionCore H.toDIDomainObject E) X) :
    StableHom (functionCore (liftedObject.{u} H).toDIDomainObject E) X' :=
  StableHom.comp (OrderIsoTransport.stableHom X X' qX.symm)
    (StableHom.comp r (OrderIsoTransport.stableHom _ _ (functionOrderIso H E).symm))

theorem split (X : DIDomainObject.{v}) (H : CountablyBasedDIDomain.{v})
    (E X' : DIDomainObject.{max u v}) (qX : X' ≃o X)
    (s : StableHom X (functionCore H.toDIDomainObject E))
    (r : StableHom (functionCore H.toDIDomainObject E) X)
    (hLeft : Function.LeftInverse (r : functionCore H.toDIDomainObject E → X)
      (s : X → functionCore H.toDIDomainObject E)) :
    Function.LeftInverse (retractionMap X H E X' qX r)
      (sectionMap X H E X' qX s) := by
  intro x
  change qX.symm (r ((functionOrderIso H E).symm
    ((functionOrderIso H E) (s (qX x))))) = x
  rw [(functionOrderIso H E).symm_apply_apply, hLeft, qX.symm_apply_apply]

/-- Raw domain certificates and an actual stable split, with no comparison
conclusion and no assumed property of the lifted domain. -/
theorem transport (X : DIDomainObject.{v}) (H : CountablyBasedDIDomain.{v})
    (E X' : DIDomainObject.{max u v}) (qX : X' ≃o X)
    (hH : IsNCoherent H.toDIDomainObject.isDIDomain.toIsScottDomain 2 (by decide))
    (hRet : HasStableRetraction X (functionCore H.toDIDomainObject E)) :
    ∃ hL : IsCountablyBasedDIDomain (ULift.{u} H.toDIDomainObject),
      IsNCoherent hL.1.toIsScottDomain 2 (by decide) ∧
      HasStableRetraction X'
        (functionCore (cbObject (ULift.{u} H.toDIDomainObject) hL).toDIDomainObject E) := by
  obtain ⟨s, r, hLeft⟩ := hRet
  exact ⟨liftedCertificate.{u} H, liftedTwoCoherent H hH,
    sectionMap X H E X' qX s, retractionMap X H E X' qX r, split X H E X' qX s r hLeft⟩

end DIDomainClassification.StableSplitUniverseLift
