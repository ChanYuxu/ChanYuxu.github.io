import DIDomainClassification.Support.RelativeSubtree
import Mathlib.Logic.Equiv.Basic

/-! Literal complete-branch image conditions and set-preserving swaps.
No order preservation, rank bound or refinement/morphism conclusion is an
input. RootedPrefixTree uses its accepted prefix predicates throughout. -/

set_option autoImplicit false

universe u v w

noncomputable section

namespace DIDomainClassification.BranchRankComparison

open Trees

def MapsFiniteCompleteBranches {A : Type u} {B : Type v}
    (S : RootedPrefixTree A) (T : RootedPrefixTree B) (f : S.Node → T.Node) : Prop :=
  ∀ c : Set S.Node, S.IsFiniteCompleteBranch c → T.IsFiniteCompleteBranch (f '' c)

def InjectiveOnBranches {A : Type u} {B : Type v}
    (S : RootedPrefixTree A) (T : RootedPrefixTree B) (f : S.Node → T.Node) : Prop :=
  ∀ c : Set S.Node, S.IsFiniteCompleteBranch c → Set.InjOn f c

theorem mapsFiniteCompleteBranches_iff_leaves {A : Type u} {B : Type v}
    (S : RootedPrefixTree A) (T : RootedPrefixTree B) (f : S.Node → T.Node) :
    MapsFiniteCompleteBranches S T f ↔
      ∀ leaf : S.Node, S.IsLeaf leaf →
        ∃ target : T.Node, T.IsLeaf target ∧ f '' S.pathTo leaf = T.pathTo target := by
  constructor
  · intro h leaf hleaf
    exact h (S.pathTo leaf) ⟨leaf, hleaf, rfl⟩
  · rintro h c ⟨leaf, hleaf, rfl⟩
    exact h leaf hleaf

theorem injectiveOnBranches_path {A : Type u} {B : Type v}
    (S : RootedPrefixTree A) (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : InjectiveOnBranches S T f) (leaf : S.Node) (hleaf : S.IsLeaf leaf) :
    Set.InjOn f (S.pathTo leaf) := hf _ ⟨leaf, hleaf, rfl⟩

theorem swap_image_eq_of_mem {α : Type w} [DecidableEq α] (c : Set α) (a b : α)
    (ha : a ∈ c) (hb : b ∈ c) : (Equiv.swap a b) '' c = c := by
  have hclosed : ∀ x ∈ c, Equiv.swap a b x ∈ c := by
    intro x hx
    by_cases hxa : x = a
    · subst x
      simpa only [Equiv.swap_apply_left] using hb
    · by_cases hxb : x = b
      · subst x
        simpa only [Equiv.swap_apply_right] using ha
      · simpa only [Equiv.swap_apply_of_ne_of_ne hxa hxb] using hx
  apply Set.Subset.antisymm
  · rintro _ ⟨x, hx, rfl⟩
    exact hclosed x hx
  · intro x hx
    exact ⟨Equiv.swap a b x, hclosed x hx, Equiv.swap_apply_self a b x⟩

end DIDomainClassification.BranchRankComparison

