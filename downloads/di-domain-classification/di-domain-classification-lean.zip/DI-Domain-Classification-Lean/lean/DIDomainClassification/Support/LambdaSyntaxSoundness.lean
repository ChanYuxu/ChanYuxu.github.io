import DIDomainClassification.Support.LambdaInterpretation

/-! Renaming and capture-avoiding substitution are proved on the literal
finite-context syntax. The split equation proves beta; congruence and the
actual equivalence closure then give beta soundness. No eta rule is used. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.LambdaSyntaxSoundness

open Section03.StableFunctionModels Section05 Section05.LambdaBetaModels
open LambdaInterpretation

variable {E : CountablyBasedDIDomain.{u}} (p : StableReflexivePair E)

theorem extend_renaming {n m : ℕ} (r : Fin n → Fin m)
    (env : Fin m → Core E) (x : Core E) :
    (fun i => extend x env (liftRenaming r i)) = extend x (fun i => env (r i)) := by
  funext i
  exact Fin.cases rfl (fun _ => rfl) i

theorem eval_rename {n m : ℕ} (t : Term n) (r : Fin n → Fin m)
    (env : Fin m → Core E) :
    eval p (rename r t) env = eval p t (fun i => env (r i)) := by
  induction t generalizing m with
  | var i => rfl
  | app f x hf hx =>
      change p.application (eval p (rename r f) env) (eval p (rename r x) env) =
        p.application (eval p f (fun i => env (r i))) (eval p x (fun i => env (r i)))
      rw [hf, hx]
  | lam t ht =>
      change eval p (.lam (rename (liftRenaming r) t)) env =
        eval p (.lam t) (fun i => env (r i))
      apply lam_congr
      intro x
      rw [ht]
      exact congrArg (eval p t) (extend_renaming r env x)

theorem liftSubstitution_eval {n m : ℕ} (s : Fin n → Term m)
    (env : Fin m → Core E) (x : Core E) :
    (fun i => eval p (liftSubstitution s i) (extend x env)) =
      extend x (fun i => eval p (s i) env) := by
  funext i
  refine Fin.cases ?_ (fun j => ?_) i
  · rfl
  · change eval p (rename Fin.succ (s j)) (extend x env) = eval p (s j) env
    rw [eval_rename]
    rfl

theorem eval_subst {n m : ℕ} (t : Term n) (s : Fin n → Term m)
    (env : Fin m → Core E) :
    eval p (subst s t) env = eval p t (fun i => eval p (s i) env) := by
  induction t generalizing m with
  | var i => rfl
  | app f x hf hx =>
      change p.application (eval p (subst s f) env) (eval p (subst s x) env) =
        p.application (eval p f (fun i => eval p (s i) env))
          (eval p x (fun i => eval p (s i) env))
      rw [hf, hx]
  | lam t ht =>
      change eval p (.lam (subst (liftSubstitution s) t)) env =
        eval p (.lam t) (fun i => eval p (s i) env)
      apply lam_congr
      intro x
      rw [ht]
      exact congrArg (eval p t) (liftSubstitution_eval p s env x)

theorem substitutionSound : SubstitutionSound (interpretation p) :=
  fun _n _m s t env => eval_subst p t s env

theorem topSubstitution_eval {n : ℕ} (x : Term n) (env : Fin n → Core E) :
    (fun i => eval p (topSubstitution x i) env) = extend (eval p x env) env := by
  funext i
  exact Fin.cases rfl (fun _ => rfl) i

theorem beta_redex {n : ℕ} (t : Term (n+1)) (x : Term n) (env : Fin n → Core E) :
    eval p (.app (.lam t) x) env = eval p (subst (topSubstitution x) t) env := by
  rw [eval_app, apply_lam, eval_subst, topSubstitution_eval]

theorem betaStep_sound {n : ℕ} {t s : Term n} (h : BetaStep t s) :
    ∀ env : Fin n → Core E, eval p t env = eval p s env := by
  induction h with
  | beta t x =>
      intro env
      exact beta_redex p t x env
  | appLeft x _ ih =>
      intro env
      rw [eval_app, eval_app, ih env]
  | appRight f _ ih =>
      intro env
      rw [eval_app, eval_app, ih env]
  | lam _ ih =>
      intro env
      apply lam_congr
      intro x
      exact ih (extend x env)

theorem betaSound : BetaSound (interpretation p) := by
  intro n t s h
  induction h with
  | rel a b hab => exact betaStep_sound p hab
  | refl a => intro env; rfl
  | symm a b _ ih => intro env; exact (ih env).symm
  | trans a b c _ _ ih₁ ih₂ => intro env; exact (ih₁ env).trans (ih₂ env)

end DIDomainClassification.LambdaSyntaxSoundness
