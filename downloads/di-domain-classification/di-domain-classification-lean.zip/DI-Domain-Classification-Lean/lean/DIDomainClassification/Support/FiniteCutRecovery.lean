import DIDomainClassification.Support.FinitePowerMembership
import DIDomainClassification.Support.OrdinalObjectCut
import DIDomainClassification.Support.InfiniteCategoryGeneration
import DIDomainClassification.Support.FiniteGeneratorProofs
import DIDomainClassification.Support.UniversalDegreeModels
import Mathlib.Tactic.NormNum

/-! Recovering the finite ordinal cut from the actual category hypotheses.
A uniform supremum replaces the source's bounded/unbounded cardinality split.
No classification or downward-closure assumption is supplied as input. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.CutRecoveryProof
open Preliminaries Subcategories CoherenceDegree
open Section03.StableFunctionModels Section04 Section04.CutModels
open Section04.FiniteCategoryModels Section04.FiniteGeneratorModels

def parameter (P : ObjectClass.{u}) : Ordinal.{u+1} :=
  OrdinalObjectCut.cutOrdinal objectDegree P

theorem member_below_parameter (P : ObjectClass.{u})
    (D : CountablyBasedDIDomain.{u}) (hD : P D) : objectDegree D < parameter P :=
  OrdinalObjectCut.member_below_cut objectDegree P hD

theorem parameter_ge_three (P : ObjectClass.{u}) (hP : CategoryHypotheses P) :
    3 ≤ parameter P := by
  let C := cubeObject 2 (by decide) TwoExponentialOrderIso.cubeCountablyBased.{u}
  have hC : P C := InfiniteCategoryGeneration.cube_mem P hP
  have h := OrdinalObjectCut.succ_le_cut objectDegree P hC
  change objectDegree C + 1 ≤ parameter P at h
  have hDegree : objectDegree C = 2 := UniversalDegreeModels.cube_degree
  rw [hDegree] at h
  have hTwo : (2 : Ordinal.{u+1}) + 1 = 3 := by norm_num
  simpa only [hTwo] using h

theorem parameter_le_bound (P : ObjectClass.{u}) :
    parameter P ≤ firstUncountableBound.{u} + 1 := by
  exact OrdinalObjectCut.cut_le objectDegree P (firstUncountableBound.{u} + 1)
    (fun D _ => (objectDegree_le_firstUncountableBound D).trans_lt
      (Order.lt_succ firstUncountableBound.{u}))

theorem finite_mem_of_cube (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (n : ℕ) (hn : 2 ≤ n)
    (hCube : IsCountablyBasedDIDomain (CubeCarrier.{u} n hn))
    (hMem : P (cubeObject n hn hCube))
    (D : CountablyBasedDIDomain.{u}) [Finite (Core D)]
    (hDegree : objectDegree D ≤ (n : Ordinal.{u+1})) : P D := by
  have hN : IsNCoherent (Core D).isDIDomain.toIsScottDomain n hn :=
    (finite_degree_iff_nCoherent (Core D).isDIDomain.toIsScottDomain n hn).mp hDegree
  obtain ⟨m, _hOtherCube, hPower, hSplit⟩ :=
    FiniteGeneratorProofs.intoFinitePower n hn (Core D) hN
  have hPowerMem := FinitePowerMembership.finitePower_mem_of_category P hP
    (cubeObject n hn hCube) hMem m hPower
  exact hP.2.2.2 D _ hPowerMem hSplit

theorem finite_degree_downward (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (D E : CountablyBasedDIDomain.{u}) [Finite (Core D)] [Finite (Core E)]
    (hDE : objectDegree D ≤ objectDegree E) (hE : P E) : P D := by
  by_cases hSmall : objectDegree E < 2
  · exact finite_mem_of_cube P hP 2 (by decide)
      TwoExponentialOrderIso.cubeCountablyBased
      (InfiniteCategoryGeneration.cube_mem P hP) D (hDE.trans hSmall.le)
  · have hTwo : (2 : Ordinal.{u+1}) ≤ objectDegree E := le_of_not_gt hSmall
    obtain ⟨n, hDegree⟩ := Ordinal.lt_omega0.mp
      (FinitePowerMembership.finite_degree_lt_omega E)
    have hn : 2 ≤ n := by
      rw [hDegree] at hTwo
      exact_mod_cast hTwo
    obtain ⟨hCube, hSplit⟩ := FiniteGeneratorProofs.containsDegreeCube
      n hn (Core E) hDegree
    have hCubeMem : P (cubeObject n hn hCube) := hP.2.2.2 _ E hE hSplit
    exact finite_mem_of_cube P hP n hn hCube hCubeMem D
      (by simpa only [hDegree] using hDE)

theorem finite_parameter_le_omega (P : ObjectClass.{u}) (hFinite : AllFinite P) :
    parameter P ≤ Ordinal.omega0 := by
  apply OrdinalObjectCut.cut_le objectDegree P Ordinal.omega0
  intro D hD
  letI : Finite (Core D) := hFinite D hD
  exact FinitePowerMembership.finite_degree_lt_omega D

theorem finite_class_eq (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (hFinite : AllFinite P) : P = FiniteDomainCut (parameter P) := by
  funext D
  apply propext
  have hDown : ∀ D E : CountablyBasedDIDomain.{u},
      Finite D → objectDegree D ≤ objectDegree E → P E → P D := by
    intro A B hA hAB hB
    letI : Finite (Core A) := hA
    letI : Finite (Core B) := hFinite B hB
    exact finite_degree_downward P hP A B hAB hB
  have h := OrdinalObjectCut.mem_cut_iff objectDegree P
    (fun E : CountablyBasedDIDomain.{u} => Finite E) hFinite hDown D
  change P D ↔ objectDegree D < parameter P ∧ Finite D
  exact h.trans and_comm

theorem finite_alternative (P : ObjectClass.{u}) (hP : CategoryHypotheses P)
    (hFinite : AllFinite P) : FiniteAlternative P :=
  ⟨parameter P, ⟨parameter_ge_three P hP, finite_parameter_le_omega P hFinite⟩,
    finite_class_eq P hP hFinite⟩

end DIDomainClassification.CutRecoveryProof
