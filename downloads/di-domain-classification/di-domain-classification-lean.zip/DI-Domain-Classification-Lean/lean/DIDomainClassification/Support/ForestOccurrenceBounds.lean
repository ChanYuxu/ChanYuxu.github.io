import DIDomainClassification.Support.ForestPrefixTrees
import Mathlib.Order.Interval.Set.Nat
import Mathlib.Data.Set.Finite.Powerset

/-! Every occurrence of a_m is coded by the subset of smaller indices
preceding m. This proves the printed 2^m bound, not just bare finiteness. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ForestOccurrenceBounds
open EventStructures Section04.ForestModels ForestPrefixTrees

variable {A : Type u} [PartialOrder A]

def code (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (x : Σ i : Roots E e, (tree E e i).Node) : Set ℕ :=
  {n | n ∈ x.2.val.dropLast}

theorem occurrence_last (E : FinitaryPrimeEventStructure A) (e : A → ℕ)
    (a : A) (i : Roots E e) (v : (tree E e i).Node)
    (hv : label E e i v = a) : v.val.getLast v.property.1 = e a := by
  exact (indexLast_eq_getLast i.val v.val v.property.1).symm.trans
    ((enumerate_label E e i v).symm.trans (congrArg e hv))

theorem code_subset (E : FinitaryPrimeEventStructure A) (e : A → ℕ) (a : A) :
    Set.MapsTo (code E e) (occurrences E (data E e) a) (𝒫 Set.Iio (e a)) := by
  rintro ⟨i, v⟩ hv n hn
  have hlt := (node_strict E e i v).rel_dropLast_getLast hn
  rw [occurrence_last E e a i v hv] at hlt
  exact hlt

theorem code_injective (E : FinitaryPrimeEventStructure A) (e : A → ℕ) (a : A) :
    Set.InjOn (code E e) (occurrences E (data E e) a) := by
  rintro ⟨i, v⟩ hv ⟨j, w⟩ hw hc
  have hdrop : v.val.dropLast = w.val.dropLast := by
    apply List.Pairwise.eq_of_mem_iff
      (List.Pairwise.sublist (List.dropLast_sublist _) (node_strict E e i v))
      (List.Pairwise.sublist (List.dropLast_sublist _) (node_strict E e j w))
    intro n
    change n ∈ code E e ⟨i, v⟩ ↔ n ∈ code E e ⟨j, w⟩
    rw [hc]
  have hlist : v.val = w.val := by
    rw [← List.dropLast_append_getLast v.property.1,
      ← List.dropLast_append_getLast w.property.1,
      hdrop, occurrence_last E e a i v hv, occurrence_last E e a j w hw]
  have hij : i = j := by
    apply Subtype.ext
    exact Option.some.inj ((node_head E e i v).symm.trans
      ((congrArg indexHead hlist).trans (node_head E e j w)))
  subst j
  have hvw : v = w := Subtype.ext hlist
  subst w
  rfl

theorem finite_and_bound (E : FinitaryPrimeEventStructure A) (e : A → ℕ) (a : A) :
    (occurrences E (data E e) a).Finite ∧
      (occurrences E (data E e) a).ncard ≤ 2 ^ e a := by
  have hfinite : (Set.Iio (e a)).Finite := Set.finite_Iio _
  refine ⟨Set.Finite.of_injOn (code_subset E e a) (code_injective E e a)
    hfinite.powerset, ?_⟩
  calc
    (occurrences E (data E e) a).ncard ≤ (𝒫 Set.Iio (e a)).ncard :=
      Set.ncard_le_ncard_of_injOn (code E e) (code_subset E e a)
        (code_injective E e a) hfinite.powerset
    _ = 2 ^ e a := by rw [Set.ncard_powerset _ hfinite, Set.ncard_Iio_nat]

end DIDomainClassification.ForestOccurrenceBounds
