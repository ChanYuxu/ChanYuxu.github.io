import DIDomainClassification.Section02.BPSStatement

/-! Actual relative-prefix path cardinality and finite-coherence rank bounds. -/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.Trees.RootedPrefixTree

variable {Index : Type v} (T : RootedPrefixTree Index)

def pathEquivFin (v : T.Node) : ↥(T.pathTo v) ≃ Fin (T.depth v + 1) where
  toFun x := ⟨T.depth x.val, Nat.lt_succ_iff.mpr (T.depth_mono x.property)⟩
  invFun i := ⟨T.prefixAt v i.val, T.prefixAt_le v i.val⟩
  left_inv x := by
    apply Subtype.ext
    have hle := T.le_prefixAt x.property (le_refl (T.depth x.val))
    have hdepth : T.depth x.val = T.depth (T.prefixAt v (T.depth x.val)) := by
      rw [T.depth_prefixAt v (T.depth_mono x.property)]
    exact (T.eq_of_le_of_depth_eq hle hdepth).symm
  right_inv i := by
    apply Fin.ext
    exact T.depth_prefixAt v (Nat.le_of_lt_succ i.isLt)

theorem pathTo_ncard (v : T.Node) : (T.pathTo v).ncard = T.depth v + 1 := by
  simpa only [Nat.card_coe_set_eq, Nat.card_fin] using Nat.card_congr (T.pathEquivFin v)

theorem nodeRank_le_of_depth_bound (hT : T.IsWellFounded) (N : ℕ)
    (hdepth : ∀ v : T.Node, T.depth v ≤ N) (v : T.Node) :
    T.nodeRank hT v ≤ ((N - T.depth v : ℕ) : Ordinal.{v}) := by
  have hwf := T.isWellFounded_iff_wellFounded_reverseChildRelation.mp hT
  exact hwf.induction
    (C := fun x : T.Node => T.nodeRank hT x ≤ ((N - T.depth x : ℕ) : Ordinal.{v}))
    v (fun x ih => by
    change T.nodeRank hT x ≤ ((N - T.depth x : ℕ) : Ordinal.{v})
    rw [T.nodeRank_eq]
    apply Ordinal.iSup_le
    intro y
    have hy : T.nodeRank hT y.val ≤ ((N - T.depth y.val : ℕ) : Ordinal.{v}) :=
      ih y.val y.property
    have hnat : N - T.depth y.val + 1 = N - T.depth x := by
      have hxy := y.property.2
      have hyn := hdepth y.val
      omega
    calc
      T.nodeRank hT y.val + 1 ≤ ((N - T.depth y.val : ℕ) : Ordinal.{v}) + 1 :=
        add_le_add hy le_rfl
      _ = ((N - T.depth y.val + 1 : ℕ) : Ordinal.{v}) := by
        simp only [Nat.cast_add, Nat.cast_one]
      _ = ((N - T.depth x : ℕ) : Ordinal.{v}) :=
        congrArg (fun n : ℕ => (n : Ordinal.{v})) hnat)

theorem treeRank_le_of_depth_bound (hT : T.IsWellFounded) (N : ℕ)
    (hdepth : ∀ v : T.Node, T.depth v ≤ N) : T.treeRank hT ≤ (N : Ordinal.{v}) := by
  simpa only [treeRank, T.depth_root, Nat.sub_zero] using
    T.nodeRank_le_of_depth_bound hT N hdepth T.root

end DIDomainClassification.Trees.RootedPrefixTree

namespace DIDomainClassification.CoherenceDegree

open Preliminaries Trees

theorem MicTree.depth_bound_of_nCoherent {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (n : ℕ) (hn : 2 ≤ n) (hcoh : IsNCoherent hD n hn)
    {Index : Type v} (M : MicTree D hD Index) (v : M.tree.Node) :
    M.tree.depth v ≤ n - 1 := by
  obtain ⟨w, hw, hvw⟩ := (M.tree.isProper_iff.mp M.proper).2 v
  have hc : M.tree.IsFiniteCompleteBranch (M.tree.pathTo w) := ⟨w, hw, rfl⟩
  have hmic := M.isMicTree.finiteBranch_mic hc
  have hinj : Set.InjOn (fun x : M.tree.Node => (M.label x : D)) (M.tree.pathTo w) :=
    (label_injOn_iff_underlying M.tree M.label (M.tree.pathTo w)).mp
      (M.isMicTree.branchInjective (hc.isBranch M.tree))
  have hcard : (labelImage M.tree M.label (M.tree.pathTo w)).ncard =
      (M.tree.pathTo w).ncard := hinj.ncard_image
  have hlen : M.tree.depth w + 1 ≤ n := by
    have hb := hcoh (labelImage M.tree M.label (M.tree.pathTo w)) hmic
    rw [hcard, M.tree.pathTo_ncard] at hb
    exact hb
  have hmono := M.tree.depth_mono hvw
  omega

theorem coherenceDegree_le_of_nCoherent {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) (n : ℕ) (hn : 2 ≤ n) (hcoh : IsNCoherent hD n hn) :
    coherenceDegree hD ≤ (n : Ordinal.{u+1}) := by
  apply (coherenceDegree_le_iff hD (n : Ordinal.{u+1})).mpr
  intro Index M hM
  have hr := M.tree.treeRank_le_of_depth_bound hM (n - 1)
    (M.depth_bound_of_nCoherent hD n hn hcoh)
  have hnat : n - 1 + 1 = n := by omega
  have hcast : ((n - 1 : ℕ) : Ordinal.{u}) + 1 = (n : Ordinal.{u}) := by
    calc
      ((n - 1 : ℕ) : Ordinal.{u}) + 1 = ((n - 1 + 1 : ℕ) : Ordinal.{u}) := by
        simp only [Nat.cast_add, Nat.cast_one]
      _ = (n : Ordinal.{u}) := congrArg (fun k : ℕ => (k : Ordinal.{u})) hnat
  have hbound : M.tree.treeRank hM + 1 ≤ (n : Ordinal.{u}) := by
    rw [← hcast]
    exact add_le_add hr le_rfl
  simpa only [Ordinal.lift_natCast] using (Ordinal.lift_le.{u+1}.mpr hbound)

end DIDomainClassification.CoherenceDegree
