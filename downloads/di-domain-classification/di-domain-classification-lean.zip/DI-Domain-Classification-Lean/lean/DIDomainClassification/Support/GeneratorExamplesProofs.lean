import DIDomainClassification.Section04.SingleGenerators
import DIDomainClassification.Section02.CountableProducts
import DIDomainClassification.Support.OrdinalCutWitnesses
import DIDomainClassification.Support.FlatPowerRetraction

/-! Literal generators in Example 4.24, including the source's dependent
product of all proper-subset cubes with dimensions at least two. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.GeneratorExamplesProof
open Preliminaries Subcategories CoherenceDegree
open Section03.StableFunctionModels
open Section04 Section04.CutModels Section04.AdditionalSourceModels
open Section04.FiniteCategoryModels

theorem two_nontrivial : Nontrivial (Core FiniteOrderDomains.twoObject.{u}) :=
  ⟨⟨FiniteOrderDomains.zero, FiniteOrderDomains.one, FiniteOrderDomains.zero_ne_one⟩⟩

theorem two_generated :
    GeneratedClass FiniteOrderDomains.twoObject.{u} = FiniteDomainCut 3 := by
  have h := SingleGeneratorProof.finite_generated FiniteOrderDomains.twoObject.{u}
    two_nontrivial CandidateCutClosure.two_finite
  simpa only [SingleGeneratorProof.parameter,
    max_eq_left CandidateCutClosure.two_degree_le, show (2 : Ordinal.{u+1})+1 = 3 by norm_num] using h

theorem cube_generated (n : ℕ) (hn : 2 ≤ n) :
    GeneratedClass (OrdinalCutWitnesses.finiteCube.{u} n hn) =
      FiniteDomainCut ((n : Ordinal.{u+1}) + 1) := by
  have htwo : (2 : Ordinal.{u+1}) ≤ (n : Ordinal.{u+1}) := by exact_mod_cast hn
  have hnon : Nontrivial (Core (OrdinalCutWitnesses.finiteCube.{u} n hn)) :=
    FinitePowerMembership.nontrivial_of_two_le_degree _ (by
      rw [OrdinalCutWitnesses.finiteCube_degree]; exact htwo)
  have h := SingleGeneratorProof.finite_generated
    (OrdinalCutWitnesses.finiteCube.{u} n hn) hnon (OrdinalCutWitnesses.finiteCube_finite n hn)
  simpa only [SingleGeneratorProof.parameter, OrdinalCutWitnesses.finiteCube_degree,
    max_eq_right htwo] using h

def flat : CountablyBasedDIDomain.{u} :=
  flatObject FlatPowerRetraction.flat_countablyBased

theorem flat_infinite : Infinite flat.{u} := by
  apply Infinite.of_injective (fun n : ℕ => (⟨BasicDomains.FlatNat.nat n⟩ : FlatCarrier.{u}))
  intro n m h
  have heq := congrArg ULift.down h
  exact BasicDomains.FlatNat.nat.inj heq

theorem flat_degree_le : objectDegree flat.{u} ≤ 2 := by
  exact (finite_degree_iff_nCoherent
    FlatPowerRetraction.flat_countablyBased.{u}.1.toIsScottDomain 2 (by decide)).mpr
      FlatPowerRetraction.flat_two_coherent

theorem flat_generated : GeneratedClass flat.{u} = DomainCut 3 := by
  letI : Infinite flat.{u} := flat_infinite
  have h := SingleGeneratorProof.infinite_generated flat.{u} inferInstance flat_infinite
  simpa only [SingleGeneratorProof.parameter, max_eq_left flat_degree_le,
    show (2 : Ordinal.{u+1})+1 = 3 by norm_num] using h

def sequenceCertificate : IsCountablyBasedDIDomain CubeSequenceCarrier.{u} :=
  (Section02.countableProducts CubeIndex (fun n => CubeCarrier.{u} n.val n.property)
    (fun n => FiniteCubeRetractions.cubeCountablyBased n.val n.property)).1

def sequenceObject : CountablyBasedDIDomain.{u} := cubeSequenceObject sequenceCertificate

/-- The ULift reindexing changes no coordinate, order or carrier in the final
statement; both directions are the explicit pointwise order isomorphism. -/
theorem sequence_degree :
    objectDegree sequenceObject.{u} = Ordinal.omega0 := by
  let D : CubeIndex → Type u := fun n => CubeCarrier.{u} n.val n.property
  let hD : ∀ n, IsScottDomain (D n) :=
    fun n => (FiniteCubeRetractions.cubeCountablyBased n.val n.property).1.toIsScottDomain
  let Q := ∀ i : ULift.{u} CubeIndex, D i.down
  let hQ : IsScottDomain Q := BPSProductDegree.productScottDomain
    (fun i : ULift.{u} CubeIndex => hD i.down)
  let e : CubeSequenceCarrier.{u} ≃o Q := {
    toFun := fun x i => x i.down
    invFun := fun y n => y ⟨n⟩
    left_inv := by intro x; rfl
    right_inv := by intro y; funext i; cases i; rfl
    map_rel_iff' := by
      intro x y
      constructor
      · intro h n; exact h ⟨n⟩
      · intro h i; exact h i.down }
  have he := OrderIsoTransport.scottContinuous e
  have hei := OrderIsoTransport.scottContinuous e.symm
  have hprod :
      objectDegree sequenceObject.{u} = ⨆ n : CubeIndex, (n.val : Ordinal.{u+1}) := by
    calc
      objectDegree sequenceObject.{u} = coherenceDegree hQ := le_antisymm
        (coherenceDegree_mono_of_scott_split
          sequenceCertificate.1.toIsScottDomain hQ he hei (fun x => e.symm_apply_apply x))
        (coherenceDegree_mono_of_scott_split
          hQ sequenceCertificate.1.toIsScottDomain hei he (fun x => e.apply_symm_apply x))
      _ = ⨆ i : ULift.{u} CubeIndex, coherenceDegree (hD i.down) :=
        BPSProductDegree.product_coherenceDegree_eq (fun i : ULift.{u} CubeIndex => hD i.down)
      _ = ⨆ n : CubeIndex, coherenceDegree (hD n) := iSup_ulift _
      _ = ⨆ n : CubeIndex, (n.val : Ordinal.{u+1}) := by
        congr 1
        funext n
        exact OrdinalCutWitnesses.cube_degree n.val n.property
  rw [hprod]
  apply le_antisymm
  · exact Ordinal.iSup_le fun n => (Ordinal.natCast_lt_omega0 n.val).le
  · apply Ordinal.omega0_le.mpr
    intro m
    let n : CubeIndex := ⟨max 2 m, le_max_left _ _⟩
    have hm : (m : Ordinal.{u+1}) ≤ (n.val : Ordinal.{u+1}) := by
      exact_mod_cast le_max_right 2 m
    exact hm.trans (Ordinal.le_iSup (fun n : CubeIndex => (n.val : Ordinal.{u+1})) n)

theorem sequence_infinite : Infinite sequenceObject.{u} := by
  apply not_finite_iff_infinite.mp
  intro h
  letI : Finite (Core sequenceObject.{u}) := h
  have hlt := FinitePowerMembership.finite_degree_lt_omega sequenceObject.{u}
  rw [sequence_degree] at hlt
  exact (lt_irrefl _) hlt

theorem two_le_omega : (2 : Ordinal.{u+1}) ≤ Ordinal.omega0 :=
  (Ordinal.natCast_lt_omega0 2).le

theorem sequence_generated :
    GeneratedClass sequenceObject.{u} = DomainCut (Ordinal.omega0+1) := by
  have hN : Nontrivial (Core sequenceObject.{u}) :=
    FinitePowerMembership.nontrivial_of_two_le_degree _ (by rw [sequence_degree]; exact two_le_omega)
  have h := SingleGeneratorProof.infinite_generated sequenceObject.{u} hN sequence_infinite
  simpa only [SingleGeneratorProof.parameter, sequence_degree, max_eq_right two_le_omega] using h

theorem sequence_not_below_omega : ¬ DomainCut Ordinal.omega0 sequenceObject.{u} := by
  change ¬ objectDegree sequenceObject.{u} < Ordinal.omega0
  rw [sequence_degree]
  exact lt_irrefl _

theorem cube_below_omega (n : ℕ) (hn : 2 ≤ n) :
    DomainCut Ordinal.omega0 (OrdinalCutWitnesses.finiteCube.{u} n hn) := by
  change objectDegree (OrdinalCutWitnesses.finiteCube.{u} n hn) < Ordinal.omega0
  rw [OrdinalCutWitnesses.finiteCube_degree]
  exact Ordinal.natCast_lt_omega0 n

end DIDomainClassification.GeneratorExamplesProof

