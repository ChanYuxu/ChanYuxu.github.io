import DIDomainClassification.Section02.QualitativeDomains
import DIDomainClassification.Support.ConfigurationDomain
import DIDomainClassification.Support.OrderIsoTransport

/-!
# Finite-forbidden-set domains on the literal powerset carrier

Generic support only, not a source tree-domain construction theorem. The
event carrier is the arbitrary supplied type A with an explicit equality
partial order. Its finite consistency sets are exactly those avoiding H.
No countability or antichain condition is imposed on H. The resulting domain
carrier is the literal subtype of arbitrary event subsets avoiding H, ordered
by actual subset inclusion, not by equality or Boolean adjacency.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.ForbiddenFiniteDomains

open EventStructures
open Preliminaries (IsScottDomain IsDIDomain IsCountablyBasedDIDomain
  CompactElements IsCompactElement)

variable {A : Type u}

/-- Exact permitted input family, without any domain conclusion as a field. -/
structure Admissible (H : Set (Set A)) : Prop where
  finite : ∀ U ∈ H, U.Finite
  nonempty : ∀ U ∈ H, U.Nonempty
  no_subset_singleton : ∀ a : A, ∀ U ∈ H, ¬ U ⊆ ({a} : Set A)

/-- Avoid every forbidden set by literal subset containment. -/
def Avoids (H : Set (Set A)) (X : Set A) : Prop := ∀ U ∈ H, ¬ U ⊆ X

/-- Arbitrary avoiding subsets, without a finiteness or lower-set condition. -/
abbrev AvoidanceDomain (H : Set (Set A)) : Type u := {X : Set A // Avoids H X}

theorem avoidance_le_iff (H : Set (Set A)) (X Y : AvoidanceDomain H) :
    X ≤ Y ↔ X.val ⊆ Y.val := Iff.rfl

/-- An actual partial order on A, not an additional property of a given order. -/
@[reducible] def equalityOrder (A : Type u) : PartialOrder A where
  le := Eq
  le_refl _ := rfl
  le_trans _ _ _ := Eq.trans
  le_antisymm _ _ hxy _hyx := hxy

theorem equalityOrder_le_iff (a b : A) :
    letI : PartialOrder A := equalityOrder A
    a ≤ b ↔ a = b := Iff.rfl

theorem equalityOrder_Iic (a : A) :
    letI : PartialOrder A := equalityOrder A
    Set.Iic a = ({a} : Set A) := rfl

theorem equalityOrder_every_set_lower (X : Set A) :
    letI : PartialOrder A := equalityOrder A
    IsLowerSet X := by
  intro a b hab hb
  change b = a at hab
  subst b
  exact hb

/-- Actual equality-order finitary prime event structure, with literal Con. -/
def eventStructure (H : Set (Set A)) (hH : Admissible H) :
    @FinitaryPrimeEventStructure A (equalityOrder A) := by
  letI : PartialOrder A := equalityOrder A
  refine {
    Con := {F : Set A | F.Finite ∧ Avoids H F}
    finite_principalIdeal := ?_
    finite_of_mem_Con := fun hF => hF.1
    empty_mem_Con := ?_
    singleton_mem_Con := ?_
    hereditary := ?_
    causal_closure := ?_ }
  · intro a
    simpa only [equalityOrder_Iic] using Set.finite_singleton a
  · refine ⟨Set.finite_empty, ?_⟩
    intro U hU hsub
    obtain ⟨a, ha⟩ := hH.nonempty U hU
    exact hsub ha
  · intro a
    exact ⟨Set.finite_singleton a, hH.no_subset_singleton a⟩
  · intro F G hsub hG
    exact ⟨hG.1.subset hsub, fun U hU hUF => hG.2 U hU (hUF.trans hsub)⟩
  · intro F a b hF hab hb
    change a = b at hab
    subst a
    simpa only [Set.union_singleton, Set.insert_eq_of_mem hb] using hF

theorem mem_Con_iff (H : Set (Set A)) (hH : Admissible H) (F : Set A) :
    letI : PartialOrder A := equalityOrder A
    F ∈ (eventStructure H hH).Con ↔ F.Finite ∧ ∀ U ∈ H, ¬ U ⊆ F := Iff.rfl

theorem isQualitativePresentation (H : Set (Set A)) (hH : Admissible H) :
    @IsQualitativePresentation A (equalityOrder A) (eventStructure H hH) := by
  intro a b
  exact Iff.rfl

theorem isConfiguration_iff (H : Set (Set A)) (hH : Admissible H) (X : Set A) :
    @IsConfiguration A (equalityOrder A) (eventStructure H hH) X ↔
      ∀ U ∈ H, ¬ U ⊆ X := by
  letI : PartialOrder A := equalityOrder A
  constructor
  · intro hX U hU hsub
    have hCon := hX.2 U (hH.finite U hU) hsub
    exact hCon.2 U hU (Set.Subset.refl U)
  · intro hX
    refine ⟨equalityOrder_every_set_lower X, ?_⟩
    intro F hF hsub
    exact ⟨hF, fun U hU hUF => hX U hU (hUF.trans hsub)⟩

theorem isForbiddenFamilyPresentation (H : Set (Set A)) (hH : Admissible H) :
    @IsForbiddenFamilyPresentation A (equalityOrder A) (eventStructure H hH) H :=
  ⟨fun U hU => ⟨hH.nonempty U hU, hH.finite U hU⟩, isConfiguration_iff H hH⟩

abbrev ConfigurationModel (H : Set (Set A)) (hH : Admissible H) : Type u :=
  @Configuration A (equalityOrder A) (eventStructure H hH)

/-- Identity on the underlying sets, in both directions and both orders. -/
def configurationOrderIso (H : Set (Set A)) (hH : Admissible H) :
    ConfigurationModel H hH ≃o AvoidanceDomain H where
  toFun X := ⟨X.val, (isConfiguration_iff H hH X.val).mp X.property⟩
  invFun X := ⟨X.val, (isConfiguration_iff H hH X.val).mpr X.property⟩
  left_inv _X := rfl
  right_inv _X := rfl
  map_rel_iff' := by intro _X _Y; exact Iff.rfl

theorem configurationOrderIso_val (H : Set (Set A)) (hH : Admissible H)
    (X : ConfigurationModel H hH) : (configurationOrderIso H hH X).val = X.val := rfl

theorem configurationOrderIso_symm_val (H : Set (Set A)) (hH : Admissible H)
    (X : AvoidanceDomain H) : ((configurationOrderIso H hH).symm X).val = X.val := rfl

/-- Scott structure is derived, without any countability premise. -/
theorem isScottDomain (H : Set (Set A)) (hH : Admissible H) :
    IsScottDomain (AvoidanceDomain H) := by
  letI : PartialOrder A := equalityOrder A
  exact OrderIsoTransport.isScottDomain_map (configurationOrderIso H hH)
    (ConfigurationDomain.scottDomain (eventStructure H hH))

/-- All intrinsic dI clauses are derived on the literal avoiding-set carrier. -/
theorem isDIDomain (H : Set (Set A)) (hH : Admissible H) :
    IsDIDomain (AvoidanceDomain H) := by
  letI : PartialOrder A := equalityOrder A
  exact OrderIsoTransport.isDIDomain_map (configurationOrderIso H hH)
    (ConfigurationDomain.dIDomain (eventStructure H hH))

theorem compact_iff_finite (H : Set (Set A)) (hH : Admissible H)
    (X : AvoidanceDomain H) : IsCompactElement X ↔ X.val.Finite := by
  letI : PartialOrder A := equalityOrder A
  exact (OrderIsoTransport.compact_iff (configurationOrderIso H hH).symm X).symm.trans
    (ConfigurationDomain.compact_iff_finite (eventStructure H hH)
      ((configurationOrderIso H hH).symm X))

theorem compactElements_countable [Countable A] (H : Set (Set A))
    (hH : Admissible H) : (CompactElements (AvoidanceDomain H)).Countable := by
  letI : PartialOrder A := equalityOrder A
  exact OrderIsoTransport.compactElements_countable_map (configurationOrderIso H hH)
    (ConfigurationDomain.compactElements_countable (eventStructure H hH))

theorem isCountablyBasedDIDomain [Countable A] (H : Set (Set A))
    (hH : Admissible H) : IsCountablyBasedDIDomain (AvoidanceDomain H) :=
  ⟨isDIDomain H hH, compactElements_countable H hH⟩

end DIDomainClassification.ForbiddenFiniteDomains
