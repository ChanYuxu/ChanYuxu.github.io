import DIDomainClassification.Support.CompactMicApproximation
import DIDomainClassification.Support.FiniteChainTrees
import DIDomainClassification.Support.BoundedMicTreeRanks
import Mathlib.Data.Finite.Card

/-! Actual one-branch mic trees and the finite-degree equivalence. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.FiniteChainTrees

open Trees CoherenceDegree

def nodeEquivFin (n : ℕ) : (tree.{u} n).Node ≃ Fin (n + 1) where
  toFun v := ⟨v.val.length, Nat.lt_succ_iff.mpr v.property⟩
  invFun i := node n i.val (Nat.le_of_lt_succ i.isLt)
  left_inv v := node_eq_of_length_eq n _ v (by simp only [List.length_replicate])
  right_inv i := Fin.ext (by simp only [List.length_replicate])

theorem finiteCompleteBranch_eq_univ (n : ℕ) {c : Set (tree.{u} n).Node}
    (hc : (tree n).IsFiniteCompleteBranch c) : c = Set.univ := by
  obtain ⟨v, hv, rfl⟩ := hc
  have heq : node n n le_rfl = v := hv _ (le_leaf n v)
  rw [← heq]
  exact pathTo_leaf_eq_univ n

end DIDomainClassification.FiniteChainTrees

namespace DIDomainClassification.CoherenceDegree

open Preliminaries Trees FiniteChainTrees

variable {D : Type u} [PartialOrder D] (hD : IsScottDomain D)

/-- A compact mic set gives an actual proper finite chain with one node per
member, globally injective compact labels, and exactly its cardinality as the
successor root-rank contribution. -/
theorem compact_mic_ncard_le_degree {M : Set D}
    (hM : IsMinimallyInconsistent hD M) (hK : M ⊆ CompactElements D) :
    (M.ncard : Ordinal.{u+1}) ≤ coherenceDegree hD := by
  classical
  let n := M.ncard - 1
  have htwo := mic_ncard_ge_two hD hM
  have hn : 0 < n := by dsimp only [n]; omega
  have hsize : n + 1 = M.ncard := by dsimp only [n]; omega
  letI : Finite M := hM.1.to_subtype
  let eM : M ≃ Fin (n + 1) := Finite.equivFinOfCardEq (by
    simpa only [Nat.card_coe_set_eq] using hsize.symm)
  let e : (tree.{u} n).Node ≃ M := (nodeEquivFin n).trans eM.symm
  let label : (tree.{u} n).Node → ↥(CompactElements D) :=
    fun x => ⟨(e x).val, hK (e x).property⟩
  have hlabel : Function.Injective label := by
    intro x y hxy
    apply e.injective
    apply Subtype.ext
    exact congrArg (fun k : ↥(CompactElements D) => k.val) hxy
  have himage : labelImage (tree n) label Set.univ = M := by
    ext d
    constructor
    · rintro ⟨x, _hx, rfl⟩
      exact (e x).property
    · intro hd
      obtain ⟨x, hx⟩ := e.surjective ⟨d, hd⟩
      exact ⟨x, Set.mem_univ _, congrArg Subtype.val hx⟩
  have hmic : IsMicTree hD (tree n) (proper n hn) label := by
    apply (isMicTree_iff hD (tree n) (proper n hn) label).mpr
    constructor
    · intro c _hc
      exact hlabel.injOn
    · intro c hc
      rw [finiteCompleteBranch_eq_univ n hc, himage]
      exact hM
  let N : MicTree D hD PUnit.{u+1} := ⟨tree n, proper n hn, label, hmic⟩
  have hbound := treeRank_add_one_le_coherenceDegree hD N (wellFounded n)
  have hcast : (n : Ordinal.{u}) + 1 = (M.ncard : Ordinal.{u}) := by
    calc
      (n : Ordinal.{u}) + 1 = ((n + 1 : ℕ) : Ordinal.{u}) := by
        simp only [Nat.cast_add, Nat.cast_one]
      _ = (M.ncard : Ordinal.{u}) := congrArg (fun k : ℕ => (k : Ordinal.{u})) hsize
  change Ordinal.lift.{u+1} ((tree n).treeRank (wellFounded n) + 1) ≤ _ at hbound
  simpa only [treeRank_eq, hcast, Ordinal.lift_natCast] using hbound

/-- The source mic sets contain arbitrary points. Compact approximation above
proves the same bound for them without silently changing that definition. -/
theorem mic_ncard_le_degree {M : Set D} (hM : IsMinimallyInconsistent hD M) :
    (M.ncard : Ordinal.{u+1}) ≤ coherenceDegree hD := by
  obtain ⟨N, hN, hNK, hcard⟩ := exists_compact_mic_approximation hD hM
  rw [← hcard]
  exact compact_mic_ncard_le_degree hD hN hNK

theorem nCoherent_of_coherenceDegree_le (n : ℕ) (hn : 2 ≤ n)
    (hdegree : coherenceDegree hD ≤ (n : Ordinal.{u+1})) : IsNCoherent hD n hn := by
  intro M hM
  have h := (mic_ncard_le_degree hD hM).trans hdegree
  exact_mod_cast h

theorem finite_degree_iff_nCoherent (n : ℕ) (hn : 2 ≤ n) :
    coherenceDegree hD ≤ (n : Ordinal.{u+1}) ↔ IsNCoherent hD n hn :=
  ⟨nCoherent_of_coherenceDegree_le hD n hn,
    coherenceDegree_le_of_nCoherent hD n hn⟩

end DIDomainClassification.CoherenceDegree
