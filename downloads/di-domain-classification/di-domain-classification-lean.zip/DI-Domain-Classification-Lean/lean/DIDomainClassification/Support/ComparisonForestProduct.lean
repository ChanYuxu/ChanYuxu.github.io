import DIDomainClassification.Support.ComparisonForestTrees
import DIDomainClassification.Section04.ComparisonClosure

/-! The actual literal powerset-times-forest product is isomorphic to a
countable native Pi product. All universe changes use explicit order isos. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonForestProduct
open Preliminaries EventStructures Trees Section04 AdditionalSourceModels
open Section03.StableFunctionModels
open ForestModels ComparisonForestTrees

variable {A : Type u} [PartialOrder A] (D : FinitaryPrimeEventStructure A)
  (F : ForestModels.Data D)

abbrev Index := PUnit.{u+1} ⊕ ULift.{u} (Roots D F.enumerate)

instance indexCountable : Countable (Index D F) := by
  dsimp [Index]
  infer_instance

def Factor : Index D F → Type u
  | .inl _ => Set A
  | .inr i => ULift.{u} (TreeDomain (F.trees i.down))

instance factorOrder (i : Index D F) : PartialOrder (Factor D F i) := by
  cases i with
  | inl _ => exact inferInstanceAs (PartialOrder (Set A))
  | inr i => exact inferInstanceAs (PartialOrder (ULift.{u} (TreeDomain (F.trees i.down))))

def factorCertificate [Countable A]
    (hT : ∀ i, IsCountablyBasedDIDomain (TreeDomain (F.trees i)))
    (i : Index D F) : IsCountablyBasedDIDomain (Factor D F i) := by
  cases i with
  | inl _ => exact ForestProductMaps.powerset_countablyBased A
  | inr i =>
      exact (OrderIsoTransport.isCountablyBasedDIDomain_iff
        (ForestProductMaps.liftOrderIso (TreeDomain (F.trees i.down)))).mpr (hT i.down)

def factorObject [Countable A]
    (hT : ∀ i, IsCountablyBasedDIDomain (TreeDomain (F.trees i)))
    (i : Index D F) : CountablyBasedDIDomain.{u} :=
  cbObject (Factor D F i) (factorCertificate D F hT i)

def productIso : (∀ i : Index D F, Factor D F i) ≃o ProductCarrier D F where
  toFun f := (f (.inl PUnit.unit), fun i => (f (.inr ⟨i⟩)).down)
  invFun P := fun i => match i with
    | .inl _ => P.1
    | .inr j => ⟨P.2 j.down⟩
  left_inv f := by
    funext i
    cases i with
    | inl x => cases x; rfl
    | inr j => cases j; rfl
  right_inv _ := rfl
  map_rel_iff' := by
    intro f g
    constructor
    · intro h i
      cases i with
      | inl x => cases x; exact h.1
      | inr j => exact h.2 j.down
    · intro h
      exact ⟨h (.inl PUnit.unit), fun i => h (.inr ⟨i⟩)⟩

theorem literal_product_comparison [Countable A]
    (hp : ∀ i, (F.trees i).IsProper)
    (hT : ∀ i, IsCountablyBasedDIDomain (TreeDomain (F.trees i)))
    (hP : IsCountablyBasedDIDomain (ProductCarrier D F))
    (E : CountablyBasedDIDomain.{u})
    (hPow : StableComparison (cbObject (Set A) (ForestProductMaps.powerset_countablyBased A)) E)
    (hTrees : ∀ i, StableComparison (liftedObject.{u} (F.trees i) (hp i)) E) :
    StableComparison (cbObject (ProductCarrier D F) hP) E := by
  have hFactors : ∀ i, StableComparison (factorObject D F hT i) E := by
    intro i
    cases i with
    | inl x => exact hPow
    | inr j =>
        apply ComparisonOperations.split_comparison
          (ComparisonOperations.iso_split _ _ (ForestUniverseTransport.liftDomainOrderIso (F.trees j.down)))
          (hTrees j.down)
  obtain ⟨hPi, hPiComp⟩ := comparisonCountableProduct (Index D F)
    (factorObject D F hT) E hFactors
  exact ComparisonOperations.split_comparison
    (ComparisonOperations.iso_split (Core (cbObject (ProductCarrier D F) hP))
      (Core (cbObject (∀ i, Core (factorObject D F hT i)) hPi)) (productIso D F).symm)
    hPiComp

end DIDomainClassification.ComparisonForestProduct
