import DIDomainClassification.Section05.NoUniversalStatements
import DIDomainClassification.Section02.BPS
import DIDomainClassification.Section02.DegreeRealizability
import DIDomainClassification.Support.FiniteOrderDomains
import Mathlib.Logic.Function.Basic

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.NoUniversalObjects

open Preliminaries CoherenceDegree Subcategories

abbrev Core (D : CountablyBasedDIDomain.{u}) : DIDomainObject.{u} := D.toDIDomainObject

theorem two_lt_of_three_le {α : Ordinal.{u+1}} (hα : 3 ≤ α) : 2 < α := by
  have h23 : (2 : Ordinal.{u+1}) < 3 := by
    simpa only [Order.succ_eq_add_one, OfNat.ofNat] using Order.lt_succ (2 : Ordinal.{u+1})
  exact h23.trans_le hα

theorem zero_lt_of_three_le {α : Ordinal.{u+1}} (hα : 3 ≤ α) : 0 < α := by
  have h01 : (0 : Ordinal.{u+1}) < 1 := by
    simpa only [Order.succ_eq_add_one, zero_add] using Order.lt_succ (0 : Ordinal.{u+1})
  have h12 : (1 : Ordinal.{u+1}) < 2 := by
    simpa only [Order.succ_eq_add_one, one_add_one_eq_two] using Order.lt_succ (1 : Ordinal.{u+1})
  exact (h01.trans h12).trans (two_lt_of_three_le hα)

/-- The literal powerset of the proposed finite universal object's carrier. -/
def finitePowersetObject (U : CountablyBasedDIDomain.{u}) (hU : Finite U) :
    CountablyBasedDIDomain.{u} := by
  letI : Finite U := hU
  let h := FiniteOrderDomains.finiteCompleteDistribLattice_isCountablyBased (Set (Core U))
  exact CountablyBasedDIDomain.ofType (Set (Core U)) h.1 h.2

theorem finitePowerset_degree (U : CountablyBasedDIDomain.{u}) (hU : Finite U) :
    objectDegree (finitePowersetObject U hU) = 0 := by
  apply (Section02.bps.2.2.2.2.2.1 _ _ (finitePowersetObject U hU).countableCompacts).mpr
  change Section02.BPS.IsCompleteLatticeOrder (Set (Core U))
  intro X
  exact ⟨⟨sSup X, isLUB_sSup X⟩, ⟨sInf X, isGLB_sInf X⟩⟩

theorem no_finite_universal (α : Ordinal.{u+1}) (hα : 3 ≤ α) :
    ¬ ∃ U : CountablyBasedDIDomain.{u}, IsStableUniversal (FiniteDomainCut α) U := by
  rintro ⟨U, hU⟩
  letI : Finite U := hU.1.2
  let C := finitePowersetObject U hU.1.2
  have hC : FiniteDomainCut α C := by
    constructor
    · change objectDegree C < α
      rw [finitePowerset_degree]
      exact zero_lt_of_three_le hα
    · change Finite (Set (Core U))
      infer_instance
  obtain ⟨s, _r, hleft⟩ := hU.2 C hC
  exact Function.cantor_injective (s : Set (Core U) → Core U) hleft.injective

theorem no_limit_universal (lam : Ordinal.{u+1}) (h3 : 3 ≤ lam)
    (hbound : lam ≤ firstUncountableBound.{u}) (hlim : Order.IsSuccLimit lam) :
    ¬ ∃ U : CountablyBasedDIDomain.{u}, IsStableUniversal (DomainCut lam) U := by
  rintro ⟨U, hU⟩
  let γ := objectDegree U
  let δ := max (2 : Ordinal.{u+1}) (γ+1)
  have hγ : γ < lam := hU.1
  have hδlt : δ < lam := by
    apply max_lt (two_lt_of_three_le h3)
    simpa only [Order.succ_eq_add_one] using hlim.succ_lt hγ
  have hδrange : Section02.DegreeRealizationModels.IsAllowedDegree δ :=
    Or.inr ⟨le_max_left _ _, hδlt.le.trans hbound⟩
  obtain ⟨D, hD⟩ := Section02.degreeRealizability.1 δ hδrange
  have hDmem : DomainCut lam D := by
    change objectDegree D < lam
    rw [hD]
    exact hδlt
  obtain ⟨s, r, hleft⟩ := hU.2 D hDmem
  have hmono : objectDegree D ≤ γ := by
    apply Section02.bps.1 (Core D) (Core U)
      (Core D).isDIDomain.toIsScottDomain (Core U).isDIDomain.toIsScottDomain
      D.countableCompacts U.countableCompacts
    exact ⟨s, r, (StableHom.isStable s).1, (StableHom.isStable r).1, hleft⟩
  rw [hD] at hmono
  have hstrict : γ < δ := by
    apply (show γ < γ+1 from by
      simpa only [Order.succ_eq_add_one] using Order.lt_succ γ).trans_le
    exact le_max_right _ _
  exact (not_le_of_gt hstrict) hmono

end DIDomainClassification.NoUniversalObjects
