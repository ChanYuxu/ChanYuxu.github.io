import DIDomainClassification.Section02.DegreeRealizabilityStatement
import DIDomainClassification.Section02.TreeDomainConstruction
import DIDomainClassification.Support.InfiniteTreeDegree
import DIDomainClassification.Support.OrderIsoTransport

/-! The literal source comb in every carrier universe. Its domain is only
ULift of the original forbidden-subset carrier. Countable-rank MIC trees are
transported along the actual order isomorphism, not a degree equality axiom. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.LiftedCombRealization

open Preliminaries Trees CoherenceDegree Section02.DegreeRealizationModels

def domain : IsCountablyBasedDIDomain CombCarrier.{u} :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff combOrderIso).mpr
    (Section02.treeDomainConstruction.2.1 Bool (Comb.tree []) (Comb.isProper []))

theorem countable_rank_contribution (α : Ordinal.{u})
    (hα : α.card ≤ Cardinal.aleph0) (hpos : 0 < α) :
    Ordinal.lift.{u+1} (α + 1) ≤ coherenceDegree domain.{u}.1.toIsScottDomain := by
  let S := CountableTreeRankRealization.tree α hα
  have hS := CountableTreeRankRealization.tree_wellFounded α hα
  have hpS := CountableTreeRankRealization.tree_proper_of_pos α hα hpos
  let hRaw := TreeDomainDegree.treeScottDomain (Comb.tree []) (Comb.isProper [])
  let M := TreeDomainDegree.infiniteBranchMicTree (Comb.tree []) (Comb.isProper [])
    (Comb.infiniteSpine []) S hpS
  let hE : IsScottDomain CombCarrier.{u} := domain.1.toIsScottDomain
  let N : MicTree CombCarrier.{u} hE (ULift.{u} ℕ) :=
    CompactRetractLift.liftMicTree hE.algebraic
      (OrderIsoTransport.scottContinuous combOrderIso.{u}.symm)
      (OrderIsoTransport.scottContinuous combOrderIso.{u})
      (fun x => combOrderIso.{u}.apply_symm_apply x) hRaw hE M
  have h := treeRank_add_one_le_coherenceDegree hE N hS
  change Ordinal.lift.{u+1} (S.treeRank hS + 1) ≤ _ at h
  simpa only [S, CountableTreeRankRealization.tree_rank] using h

theorem degree :
    coherenceDegree domain.{u}.1.toIsScottDomain = firstUncountable.{u} := by
  apply le_antisymm (coherenceDegree_le_firstUncountable _)
  exact CountableTreeRankRealization.firstUncountable_le_of_pos_countable_successor_lifts
    (coherenceDegree domain.1.toIsScottDomain) countable_rank_contribution

end DIDomainClassification.LiftedCombRealization
