import DIDomainClassification.Support.OrderCoreLemmas
import DIDomainClassification.Section02.ScottOperations
import Mathlib.Order.Irreducible
import Mathlib.Data.Fintype.Card
import DIDomainClassification.Section02.Configurations
import DIDomainClassification.Support.FiniteConsistency
import Mathlib.Order.Hom.Basic

/-!
# Complete-prime decomposition in an intrinsic dI-domain

Narrow support for the source prime-event representation theorem. Actual
Mathlib irreducible decomposition is used only inside a finite principal
ideal. Global complete primality is proved from the intrinsic dI axioms.
Completely-prime testing includes the empty bounded family. No global lattice
or countable/nontrivial/finite domain carrier is assumed. This is a locally
adapted proof route, not a claim of source-proof acceptance.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.FinitePrimeDecomposition

open OrderCore
open Preliminaries (IsScottDomain IsDIDomain)

variable {D : Type u} [PartialOrder D]

def IsCompletePrime (p : D) : Prop :=
  ∀ X : Set D, BddAbove X → ∀ s : D, IsLUB X s → p ≤ s → ∃ x ∈ X, p ≤ x

theorem isCompletePrime_iff_lub (p : D) :
    IsCompletePrime p ↔
      ∀ (X : Set D) (s : D), IsLUB X s → p ≤ s → ∃ x ∈ X, p ≤ x := by
  constructor
  · intro hp X s hs hps
    exact hp X ⟨s, hs.1⟩ s hs hps
  · intro hp X _hX s hs hps
    exact hp X s hs hps

theorem completePrime_isCompact {p : D} (hp : IsCompletePrime p) : Compact p := by
  intro A s _hA hs hps
  exact hp A ⟨s, hs.1⟩ s hs hps

theorem not_completePrime_bottom (hD : IsScottDomain D) :
    ¬ IsCompletePrime hD.bottom := by
  intro hp
  have hs : IsLUB (∅ : Set D) hD.bottom := by
    constructor
    · intro x hx
      exact False.elim hx
    · intro y _
      exact hD.bottom_le y
  have hB : BddAbove (∅ : Set D) := by
    refine ⟨hD.bottom, ?_⟩
    intro x hx
    exact False.elim hx
  obtain ⟨x, hx, _⟩ := hp ∅ hB hD.bottom hs le_rfl
  exact hx

/-- Adapted from the actual narrow book finite-subset-supremum argument;
only the accepted Scott-domain order properties are needed. -/
def FiniteSubsetSuprema (X : Set D) : Set D :=
  {s | ∃ F : Finset D, (F : Set D) ⊆ X ∧ IsLUB (F : Set D) s}

theorem finiteSubsetSuprema_directed (hD : IsScottDomain D) {X : Set D}
    (hX : BddAbove X) : DirectedSet (FiniteSubsetSuprema X) := by
  classical
  obtain ⟨b, hb⟩ := hX
  constructor
  · have hempty : IsLUB (∅ : Set D) hD.bottom := by
      constructor
      · intro x hx
        exact False.elim hx
      · intro y _
        exact hD.bottom_le y
    exact ⟨hD.bottom, ∅, by simp, by simpa using hempty⟩
  · rintro a ⟨F, hFX, hF⟩ c ⟨G, hGX, hG⟩
    have hU : ((F ∪ G : Finset D) : Set D) ⊆ X := by
      intro x hx
      rcases Finset.mem_union.mp hx with hx | hx
      · exact hFX hx
      · exact hGX hx
    obtain ⟨z, hz⟩ := hD.boundedSuprema ((F ∪ G : Finset D) : Set D)
      ⟨b, fun _ hx => hb (hU hx)⟩
    refine ⟨z, ⟨F ∪ G, hU, hz⟩, ?_, ?_⟩
    · exact hF.2 (fun x hx => hz.1 (Finset.mem_union_left G hx))
    · exact hG.2 (fun x hx => hz.1 (Finset.mem_union_right F hx))

theorem finiteSubsetSuprema_isLUB {X : Set D} {s : D} (hs : IsLUB X s) :
    IsLUB (FiniteSubsetSuprema X) s := by
  classical
  constructor
  · rintro t ⟨F, hFX, hF⟩
    exact hF.2 (fun x hx => hs.1 (hFX hx))
  · intro z hz
    apply hs.2
    intro x hx
    have hsingle : x ∈ FiniteSubsetSuprema X :=
      ⟨{x}, by simpa only [Finset.coe_singleton, Set.singleton_subset_iff] using hx,
        by simpa only [Finset.coe_singleton] using (isLUB_singleton : IsLUB ({x} : Set D) x)⟩
    exact hz hsingle

/-- Binary primality is required only for a pair that actually has a LUB. -/
def IsBinaryPrime (p : D) : Prop :=
  ∀ a b s : D, IsLUB ({a, b} : Set D) s → p ≤ s → p ≤ a ∨ p ≤ b

theorem binaryPrime_finite_witness (hD : IsScottDomain D) {p : D}
    (hpbot : p ≠ hD.bottom) (hp : IsBinaryPrime p) :
    ∀ (F : Finset D) (s : D), IsLUB (F : Set D) s → p ≤ s → ∃ x ∈ F, p ≤ x := by
  classical
  intro F
  induction F using Finset.induction_on with
  | empty =>
    intro s hs hps
    have hsbot : s ≤ hD.bottom := hs.2 (by
      intro x hx
      simp at hx)
    exact False.elim (hpbot (le_antisymm (hps.trans hsbot) (hD.bottom_le p)))
  | @insert a F ha ih =>
    intro s hs hps
    have hFbound : ∀ x ∈ F, x ≤ s := fun x hx => hs.1 (by simp [hx])
    obtain ⟨t, ht⟩ := hD.boundedSuprema (F : Set D) ⟨s, hFbound⟩
    have hpair : IsLUB ({a, t} : Set D) s := by
      constructor
      · intro x hx
        rcases Set.mem_insert_iff.mp hx with rfl | hx
        · exact hs.1 (by simp)
        · simpa only [Set.mem_singleton_iff.mp hx] using ht.2 hFbound
      · intro z hz
        apply hs.2
        intro x hx
        rcases Finset.mem_insert.mp hx with rfl | hx
        · exact hz (by simp)
        · exact (ht.1 hx).trans (hz (by simp))
    rcases hp a t s hpair hps with hpa | hpt
    · exact ⟨a, Finset.mem_insert_self a F, hpa⟩
    · obtain ⟨x, hx, hpx⟩ := ih t ht hpt
      exact ⟨x, Finset.mem_insert_of_mem hx, hpx⟩

theorem completePrime_of_compact_binaryPrime (hD : IsScottDomain D) {p : D}
    (hpcompact : Compact p) (hpbot : p ≠ hD.bottom) (hpbinary : IsBinaryPrime p) :
    IsCompletePrime p := by
  intro X hX s hs hps
  obtain ⟨_, ⟨F, hFX, hF⟩, hpt⟩ := hpcompact
    (finiteSubsetSuprema_directed hD hX) (finiteSubsetSuprema_isLUB hs) hps
  obtain ⟨x, hx, hpx⟩ := binaryPrime_finite_witness hD hpbot hpbinary F _ hF hpt
  exact ⟨x, hFX hx, hpx⟩

/-- Only the bounded principal ideal gets a total join operation. -/
noncomputable def intervalSup (hD : IsScottDomain D) (k : D)
    (a b : Set.Iic k) : Set.Iic k :=
  ⟨hD.join a.val b.val ⟨k, a.property, b.property⟩,
    (hD.join_isLUB a.val b.val ⟨k, a.property, b.property⟩).2 (by
      intro x hx
      rcases Set.mem_insert_iff.mp hx with rfl | hx
      · exact a.property
      · simpa only [Set.mem_singleton_iff.mp hx] using b.property)⟩

theorem intervalSup_val_isLUB (hD : IsScottDomain D) (k : D) (a b : Set.Iic k) :
    IsLUB ({a.val, b.val} : Set D) (intervalSup hD k a b).val :=
  hD.join_isLUB a.val b.val ⟨k, a.property, b.property⟩

@[reducible] noncomputable def intervalSemilatticeSup (hD : IsScottDomain D) (k : D) :
    SemilatticeSup (Set.Iic k) where
  toPartialOrder := inferInstance
  sup := intervalSup hD k
  le_sup_left a b := (intervalSup_val_isLUB hD k a b).1 (by simp)
  le_sup_right a b := (intervalSup_val_isLUB hD k a b).1 (by simp)
  sup_le a b c hac hbc := (intervalSup_val_isLUB hD k a b).2 (by
    intro x hx
    rcases Set.mem_insert_iff.mp hx with rfl | hx
    · exact hac
    · simpa only [Set.mem_singleton_iff.mp hx] using hbc)

/-- The interval operation structure retains exactly the original subtype order. -/
theorem intervalSemilatticeSup_order (hD : IsScottDomain D) (k : D) :
    (intervalSemilatticeSup hD k).toPartialOrder =
      (inferInstance : PartialOrder (Set.Iic k)) := rfl

@[reducible] noncomputable def intervalOrderBot (hD : IsScottDomain D) (k : D) : OrderBot (Set.Iic k) where
  bot := ⟨hD.bottom, hD.bottom_le k⟩
  bot_le := fun a => hD.bottom_le a.val

/-- Interval sup-irreducibility implies global complete primality; the meet
with the source point transfers an arbitrary bounded binary join into Iic k. -/
theorem interval_supIrred_isCompletePrime (hD : IsDIDomain D) (k : D) (hk : Compact k)
    (p : Set.Iic k) :
    @SupIrred (Set.Iic k) (intervalSemilatticeSup hD.toIsScottDomain k) p →
      IsCompletePrime p.val := by
  let S := hD.toIsScottDomain
  letI : SemilatticeSup (Set.Iic k) := intervalSemilatticeSup S k
  intro hp
  have hpcompact : Compact p.val :=
    compact_of_finite_principal_ideal S.algebraic (hD.finitePrincipalIdeals k hk) p.property
  have hpbot : p.val ≠ S.bottom := by
    intro heq
    apply hp.1
    intro a _ha
    change p.val ≤ a.val
    rw [heq]
    exact S.bottom_le a.val
  apply completePrime_of_compact_binaryPrime S hpcompact hpbot
  intro left right s hs hps
  have hxy : Compatible left right := ⟨s, hs.1 (by simp), hs.1 (by simp)⟩
  let a : Set.Iic k := ⟨S.inf left p.val, (S.inf_le_right left p.val).trans p.property⟩
  let b : Set.Iic k := ⟨S.inf right p.val, (S.inf_le_right right p.val).trans p.property⟩
  have hm : IsGLB ({s, p.val} : Set D) p.val := by
    constructor
    · intro x hx
      rcases Set.mem_insert_iff.mp hx with rfl | hx
      · exact hps
      · simpa only [Set.mem_singleton_iff.mp hx] using (le_rfl : p.val ≤ p.val)
    · intro x hx
      exact hx (by simp)
  have hjoin : IsLUB ({a.val, b.val} : Set D) p.val :=
    hD.distributive left right p.val s p.val a.val b.val hxy hs hm
      (S.inf_isGLB left p.val) (S.inf_isGLB right p.val)
  have hlocal : IsLUB ({a.val, b.val} : Set D) ((a ⊔ b : Set.Iic k) : D) :=
    intervalSup_val_isLUB S k a b
  have hab : a ⊔ b = p := Subtype.ext (hlocal.unique hjoin)
  rcases hp.2 hab with hpa | hpb
  · exact Or.inl ((congrArg Subtype.val hpa).symm.le.trans (S.inf_le_left left p.val))
  · exact Or.inr ((congrArg Subtype.val hpb).symm.le.trans (S.inf_le_left right p.val))

/-- A genuine finite prime decomposition, obtained in the finite principal
ideal from Mathlib's proved irreducible decomposition, not from representation. -/
theorem exists_finite_prime_decomposition (hD : IsDIDomain D) (k : D) (hk : Compact k) :
    ∃ P : Set D, P.Finite ∧ (∀ p ∈ P, IsCompletePrime p ∧ p ≤ k) ∧ IsLUB P k := by
  classical
  let S := hD.toIsScottDomain
  letI : SemilatticeSup (Set.Iic k) := intervalSemilatticeSup S k
  letI : OrderBot (Set.Iic k) := intervalOrderBot S k
  letI : Fintype (Set.Iic k) := (hD.finitePrincipalIdeals k hk).fintype
  obtain ⟨F, hFsup, hFirr⟩ := exists_supIrred_decomposition (⟨k, le_rfl⟩ : Set.Iic k)
  refine ⟨Subtype.val '' (F : Set (Set.Iic k)), F.finite_toSet.image Subtype.val, ?_, ?_⟩
  · rintro _ ⟨p, hp, rfl⟩
    exact ⟨interval_supIrred_isCompletePrime hD k hk p (hFirr hp), p.property⟩
  · constructor
    · rintro _ ⟨p, _hp, rfl⟩
      exact p.property
    · intro z hz
      let q : Set.Iic k := ⟨S.inf k z, S.inf_le_left k z⟩
      have hupper : F.sup id ≤ q := by
        apply Finset.sup_le
        intro p hp
        exact S.le_inf p.property (hz ⟨p, hp, rfl⟩)
      have hkq : k ≤ q.val := by
        simpa only [hFsup] using hupper
      exact hkq.trans (S.inf_le_right k z)

theorem primes_below_compact_finite (hD : IsDIDomain D) (k : D) (hk : Compact k) :
    {p : D | IsCompletePrime p ∧ p ≤ k}.Finite :=
  (hD.finitePrincipalIdeals k hk).subset (fun _ hp => hp.2)

theorem compact_isLUB_primes_below (hD : IsDIDomain D) (k : D) (hk : Compact k) :
    IsLUB {p : D | IsCompletePrime p ∧ p ≤ k} k := by
  obtain ⟨P, _hfinite, hPprime, hPlub⟩ := exists_finite_prime_decomposition hD k hk
  constructor
  · intro p hp
    exact hp.2
  · intro z hz
    exact hPlub.2 (fun p hp => hz (hPprime p hp))

theorem point_isLUB_primes_below (hD : IsDIDomain D) (x : D) :
    IsLUB {p : D | IsCompletePrime p ∧ p ≤ x} x := by
  constructor
  · intro p hp
    exact hp.2
  · intro z hz
    apply (hD.toIsScottDomain.algebraic.2 x).2.2 z
    intro k hk
    apply (compact_isLUB_primes_below hD k hk.1).2
    intro p hp
    exact hz ⟨hp.1, hp.2.trans hk.2⟩

end DIDomainClassification.FinitePrimeDecomposition

/-!
# Generic complete-prime event presentation

Support on the accepted source models. The predicate P and its compactness,
arbitrary-lub primeness and prime-algebraicity proofs are explicit intermediate
inputs. The source wrapper discharges them using the local decomposition
above; none remains as an added source hypothesis. No book module or event
representation conclusion is imported, stored or assumed.
-/

namespace DIDomainClassification.EventStructures.PrimeEventPresentation

open DIDomainClassification.Preliminaries

variable {D : Type u} [PartialOrder D]

abbrev Carrier (P : D → Prop) : Type u := {p : D // P p}

def eventStructure (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p) :
    FinitaryPrimeEventStructure (Carrier P) where
  Con := {F | F.Finite ∧ ∃ upper : D, ∀ p ∈ F, p.val ≤ upper}
  finite_principalIdeal := by
    intro p
    have hpreimage :
        (Subtype.val ⁻¹' Set.Iic p.val : Set (Carrier P)).Finite :=
      (hD.finitePrincipalIdeals p.val (hCompact p.val p.property)).preimage
        Subtype.val_injective.injOn
    exact hpreimage
  finite_of_mem_Con := fun h => h.1
  empty_mem_Con := ⟨Set.finite_empty, hD.toIsScottDomain.bottom, by simp⟩
  singleton_mem_Con := by
    intro p
    refine ⟨Set.finite_singleton p, p.val, ?_⟩
    intro q hq
    have heq : q = p := Set.mem_singleton_iff.mp hq
    simpa only [heq] using (le_rfl : p.val ≤ p.val)
  hereditary := by
    intro F G hFG hG
    obtain ⟨hGfinite, upper, hupper⟩ := hG
    exact ⟨hGfinite.subset hFG, upper, fun p hp => hupper p (hFG hp)⟩
  causal_closure := by
    intro F a b hF hab hb
    obtain ⟨hFfinite, upper, hupper⟩ := hF
    refine ⟨hFfinite.union (Set.finite_singleton a), upper, ?_⟩
    intro p hp
    rcases hp with hp | hp
    · exact hupper p hp
    · have heq : p = a := Set.mem_singleton_iff.mp hp
      subst p
      exact (show a.val ≤ b.val from hab).trans (hupper b hb)

theorem carrier_countable (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (hK : (Preliminaries.CompactElements D).Countable) : Countable (Carrier P) := by
  have hP : ({p : D | P p} : Set D).Countable :=
    hK.mono (fun p hp => hCompact p hp)
  exact hP.to_subtype

def belowConfiguration (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p) (x : D) :
    Configuration (eventStructure hD P hCompact) :=
  ⟨{p | p.val ≤ x}, by
    constructor
    · intro p q hpq hq
      exact (show q.val ≤ p.val from hpq).trans hq
    · intro F hF hsub
      exact ⟨hF, x, fun p hp => hsub hp⟩⟩

def values (P : D → Prop) (X : Set (Carrier P)) : Set D :=
  Subtype.val '' X

theorem values_bounded (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (X : Configuration (eventStructure hD P hCompact)) : BddAbove (values P X.val) := by
  apply CoherenceDegree.consistent_of_finite_subsets_consistent hD.toIsScottDomain
  intro F hF hsub
  let tagged : Set (Carrier P) := Subtype.val ⁻¹' F ∩ X.val
  have htagged : tagged.Finite :=
    (hF.preimage Subtype.val_injective.injOn).subset (fun p hp => hp.1)
  have hConsistent := X.property.2 tagged htagged (fun p hp => hp.2)
  obtain ⟨upper, hupper⟩ := hConsistent.2
  refine ⟨upper, ?_⟩
  intro point hpoint
  obtain ⟨p, hpX, rfl⟩ := hsub hpoint
  exact hupper p ⟨hpoint, hpX⟩

noncomputable def configurationSup (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (X : Configuration (eventStructure hD P hCompact)) : D :=
  Classical.choose (hD.toIsScottDomain.boundedSuprema (values P X.val)
    (values_bounded hD P hCompact X))

theorem configurationSup_isLUB (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (X : Configuration (eventStructure hD P hCompact)) :
    IsLUB (values P X.val) (configurationSup hD P hCompact X) :=
  Classical.choose_spec (hD.toIsScottDomain.boundedSuprema (values P X.val)
    (values_bounded hD P hCompact X))

theorem belowConfiguration_values_isLUB (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (hAlgebraic : ∀ x : D, IsLUB {p | P p ∧ p ≤ x} x) (x : D) :
    IsLUB (values P (belowConfiguration hD P hCompact x).val) x := by
  constructor
  · rintro point ⟨p, hp, rfl⟩
    exact hp
  · intro upper hupper
    apply (hAlgebraic x).2
    intro p hp
    exact hupper ⟨⟨p, hp.1⟩, hp.2, rfl⟩

theorem configurationSup_belowConfiguration (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (hAlgebraic : ∀ x : D, IsLUB {p | P p ∧ p ≤ x} x) (x : D) :
    configurationSup hD P hCompact (belowConfiguration hD P hCompact x) = x :=
  (configurationSup_isLUB hD P hCompact _).unique
    (belowConfiguration_values_isLUB hD P hCompact hAlgebraic x)

theorem belowConfiguration_configurationSup (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (hPrime : ∀ p : D, P p → ∀ (S : Set D) (s : D),
      IsLUB S s → p ≤ s → ∃ x ∈ S, p ≤ x)
    (X : Configuration (eventStructure hD P hCompact)) :
    belowConfiguration hD P hCompact (configurationSup hD P hCompact X) = X := by
  apply Subtype.ext
  apply Set.Subset.antisymm
  · intro p hp
    obtain ⟨point, hpoint, hpPoint⟩ := hPrime p.val p.property
      (values P X.val) (configurationSup hD P hCompact X)
      (configurationSup_isLUB hD P hCompact X) hp
    obtain ⟨q, hqX, rfl⟩ := hpoint
    exact X.property.1 (show p ≤ q from hpPoint) hqX
  · intro p hp
    exact (configurationSup_isLUB hD P hCompact X).1 ⟨p, hp, rfl⟩

theorem belowConfiguration_le_iff (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (hAlgebraic : ∀ x : D, IsLUB {p | P p ∧ p ≤ x} x) (x y : D) :
    belowConfiguration hD P hCompact x ≤ belowConfiguration hD P hCompact y ↔ x ≤ y := by
  constructor
  · intro hxy
    apply (hAlgebraic x).2
    intro p hp
    let tagged : Carrier P := ⟨p, hp.1⟩
    exact (Configuration.le_iff_subset _ _).mp hxy
      (show tagged ∈ (belowConfiguration hD P hCompact x).val from hp.2)
  · intro hxy
    apply (Configuration.le_iff_subset _ _).mpr
    intro p hp
    exact hp.trans hxy

noncomputable def representationOrderIso (hD : IsDIDomain D) (P : D → Prop)
    (hCompact : ∀ p : D, P p → OrderCore.Compact p)
    (hPrime : ∀ p : D, P p → ∀ (S : Set D) (s : D),
      IsLUB S s → p ≤ s → ∃ x ∈ S, p ≤ x)
    (hAlgebraic : ∀ x : D, IsLUB {p | P p ∧ p ≤ x} x) :
    D ≃o Configuration (eventStructure hD P hCompact) where
  toFun := belowConfiguration hD P hCompact
  invFun := configurationSup hD P hCompact
  left_inv := configurationSup_belowConfiguration hD P hCompact hAlgebraic
  right_inv := belowConfiguration_configurationSup hD P hCompact hPrime
  map_rel_iff' := by
    intro x y
    exact belowConfiguration_le_iff hD P hCompact hAlgebraic x y

end DIDomainClassification.EventStructures.PrimeEventPresentation
