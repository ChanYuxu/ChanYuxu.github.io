import DIDomainClassification.Section02.ConfigurationOrderStatements

/-!
# The selected configuration order structures

These definitional bridges explicitly certify the relations used through
the inferred Preorder and PartialOrder, not merely through a bare LE class.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.EventStructures.Configuration

theorem selectedPreorder_le_iff {A : Type u} [PartialOrder A]
    {E : FinitaryPrimeEventStructure A} (X Y : Configuration E) :
    @LE.le (Configuration E)
      (inferInstance : Preorder (Configuration E)).toLE X Y ↔ X.val ⊆ Y.val :=
  Iff.rfl

theorem selectedPartialOrder_le_iff {A : Type u} [PartialOrder A]
    {E : FinitaryPrimeEventStructure A} (X Y : Configuration E) :
    @LE.le (Configuration E)
      (inferInstance : PartialOrder (Configuration E)).toLE X Y ↔ X.val ⊆ Y.val :=
  Iff.rfl

end DIDomainClassification.EventStructures.Configuration
