import DIDomainClassification.Section04.TreeRealisationStatements
import DIDomainClassification.Section04.CausalAntichains

/-! Literal finite-node label/background geometry. Every conflict here is
the actual maximal-event set of a finite minimal inconsistent lower set. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeRealisationGeometry

open Preliminaries EventStructures Trees FiniteCausalConflicts
open Section04.TreeRealisationModels

variable {A : Type u} [PartialOrder A] {B : Type v}
  (T : RootedPrefixTree B) (L : T.Node → Set A)

def branchLabels (c : Set T.Node) : Set A := ⋃ z ∈ c, L z

theorem label_subset_branchLabels {c : Set T.Node} {z : T.Node} (hz : z ∈ c) :
    L z ⊆ branchLabels T L c := by
  intro a ha
  exact Set.mem_iUnion.mpr ⟨z, Set.mem_iUnion.mpr ⟨hz, ha⟩⟩

theorem prefix_mem_branch {c : Set T.Node} (hc : T.IsFiniteCompleteBranch c)
    {z w : T.Node} (hzw : z ≤ w) (hw : w ∈ c) : z ∈ c := by
  obtain ⟨leaf, _hLeaf, rfl⟩ := hc
  exact hzw.trans hw

theorem background_mono {x y : T.Node} (hxy : x ≤ y) :
    background T L x ⊆ background T L y := by
  rintro a ⟨z, hzx, b, hb, hab, hne⟩
  exact ⟨z, hzx.trans hxy, b, hb, hab, hne⟩

theorem nodeSection_mono_node (X : Set T.Node) {x y : T.Node} (hxy : x ≤ y) :
    nodeSection T L X x ⊆ nodeSection T L X y := by
  rintro a (ha | ⟨z, hzx, hzX, haz⟩)
  · exact Or.inl (background_mono T L hxy ha)
  · exact Or.inr ⟨z, hzx.trans hxy, hzX, haz⟩

theorem nodeSection_mono_input {X Y : Set T.Node} (hXY : X ⊆ Y) (x : T.Node) :
    nodeSection T L X x ⊆ nodeSection T L Y x := by
  rintro a (ha | ⟨z, hzx, hzX, haz⟩)
  · exact Or.inl ha
  · exact Or.inr ⟨z, hzx, hXY hzX, haz⟩

theorem background_isLower (x : T.Node) : IsLowerSet (background T L x) := by
  rintro b a hab ⟨z, hzx, c, hc, hbc, hne⟩
  refine ⟨z, hzx, c, hc, hab.trans hbc, ?_⟩
  intro hac
  exact hne (le_antisymm hbc (hac ▸ hab))

theorem nodeSection_isLower (X : Set T.Node) (x : T.Node) :
    IsLowerSet (nodeSection T L X x) := by
  intro b a hab hb
  rcases hb with hb | ⟨z, hzx, hzX, hbz⟩
  · exact Or.inl (background_isLower T L x hab hb)
  · by_cases heq : a = b
    · exact heq ▸ Or.inr ⟨z, hzx, hzX, hbz⟩
    · exact Or.inl ⟨z, hzx, b, hbz, hab, heq⟩

variable (E : FinitaryPrimeEventStructure A)
  (hL : BlockCondition T E L)

include hL

theorem label_eq_on_branch {c : Set T.Node} (hc : T.IsFiniteCompleteBranch c)
    {x y : T.Node} (hx : x ∈ c) (hy : y ∈ c) {a : A}
    (hax : a ∈ L x) (hay : a ∈ L y) : x = y := by
  by_contra hne
  exact Set.disjoint_left.mp ((hL.2 c hc).1 hx hy hne) hax hay

theorem background_disjoint_branch {c : Set T.Node} (hc : T.IsFiniteCompleteBranch c)
    {x : T.Node} (hx : x ∈ c) :
    Disjoint (background T L x) (branchLabels T L c) := by
  apply Set.disjoint_left.mpr
  rintro a ⟨z, hzx, b, hbz, hab, hne⟩ haH
  have hz : z ∈ c := prefix_mem_branch T hc hzx hx
  have hbH := label_subset_branchLabels T L hz hbz
  have hAnti : IsAntichain (· ≤ ·) (branchLabels T L c) := by
    obtain ⟨U, hU, hEq⟩ := (hL.2 c hc).2
    change IsAntichain (· ≤ ·) (⋃ z ∈ c, L z)
    rw [hEq]
    exact ((Section04.causalAntichains A E).2.1 U hU).2.1
  exact hAnti haH hbH hne hab

omit hL in
theorem nodeSection_subset_down_branch {c : Set T.Node}
    (hc : T.IsFiniteCompleteBranch c) {x : T.Node} (hx : x ∈ c)
    (X : Set T.Node) :
    nodeSection T L X x ⊆ downClosure (branchLabels T L c) := by
  rintro a (⟨z, hzx, b, hb, hab, _hne⟩ | ⟨z, hzx, _hzX, ha⟩)
  · exact ⟨b, label_subset_branchLabels T L (prefix_mem_branch T hc hzx hx) hb, hab⟩
  · exact ⟨a, label_subset_branchLabels T L (prefix_mem_branch T hc hzx hx) ha, le_rfl⟩

theorem missing_block_disjoint {c : Set T.Node} (hc : T.IsFiniteCompleteBranch c)
    {x w : T.Node} (hx : x ∈ c) (hw : w ∈ c) {X : Set T.Node} (hwX : w ∉ X) :
    Disjoint (L w) (nodeSection T L X x) := by
  apply Set.disjoint_left.mpr
  intro a haw haS
  rcases haS with haB | ⟨z, hzx, hzX, haz⟩
  · exact Set.disjoint_left.mp (background_disjoint_branch T L E hL hc hx) haB
      (label_subset_branchLabels T L hw haw)
  · have hwz := label_eq_on_branch T L E hL hc hw
      (prefix_mem_branch T hc hzx hx) haw haz
    exact hwX (hwz ▸ hzX)

theorem nodeSection_configuration (hp : T.IsProper) (X : TreeDomain T) (x : T.Node) :
    IsConfiguration E (nodeSection T L X.val x) := by
  obtain ⟨c, hc, hx⟩ := hp.2 x
  have hH : branchLabels T L c ∈ causalConflictFamily E := (hL.2 c hc).2
  obtain ⟨U, hU, hEq⟩ := hH
  have hDown : U = downClosure (branchLabels T L c) := by
    rw [hEq]
    exact ((Section04.causalAntichains A E).2.1 U hU).2.2.1
  have hsub : nodeSection T L X.val x ⊆ U :=
    (nodeSection_subset_down_branch T L hc hx X.val).trans hDown.symm.subset
  obtain ⟨w, hw, hwX⟩ := Set.not_subset.mp (X.property c hc)
  obtain ⟨a, ha⟩ := (hL.1 w).2
  have haU : a ∈ U := hDown.symm.subset
    (subset_downClosure _ (label_subset_branchLabels T L hw ha))
  have hproper : nodeSection T L X.val x ⊂ U := by
    refine ⟨hsub, ?_⟩
    intro hUS
    exact Set.disjoint_left.mp (missing_block_disjoint T L E hL hc hx hw hwX)
      ha (hUS haU)
  have hCon := hU.2.2.2 (nodeSection T L X.val x) hproper (nodeSection_isLower T L X.val x)
  exact ⟨nodeSection_isLower T L X.val x, fun _ _ hF => E.hereditary hF hCon⟩

theorem nodeSection_inter (hp : T.IsProper) (X Y : Set T.Node) (x : T.Node) :
    nodeSection T L (X ∩ Y) x = nodeSection T L X x ∩ nodeSection T L Y x := by
  obtain ⟨c, hc, hx⟩ := hp.2 x
  ext a
  constructor
  · intro ha
    exact ⟨nodeSection_mono_input T L Set.inter_subset_left x ha,
      nodeSection_mono_input T L Set.inter_subset_right x ha⟩
  · rintro ⟨haX, haY⟩
    rcases haX with haB | ⟨z, hzx, hzX, haz⟩
    · exact Or.inl haB
    · rcases haY with haB | ⟨w, hwx, hwY, haw⟩
      · exact Or.inl haB
      · have hzw := label_eq_on_branch T L E hL hc
          (prefix_mem_branch T hc hzx hx) (prefix_mem_branch T hc hwx hx) haz haw
        exact Or.inr ⟨z, hzx, ⟨hzX, hzw.symm ▸ hwY⟩, haz⟩

theorem finite_cross_inter (hp : T.IsProper) {X Y : Set T.Node} (hXY : X ⊆ Y)
    {x y : T.Node} (hxy : x ≤ y) :
    nodeSection T L X y ∩ nodeSection T L Y x = nodeSection T L X x := by
  obtain ⟨c, hc, hy⟩ := hp.2 y
  have hx := prefix_mem_branch T hc hxy hy
  ext a
  constructor
  · rintro ⟨haX, haY⟩
    rcases haY with haB | ⟨z, hzx, _hzY, haz⟩
    · exact Or.inl haB
    · rcases haX with haB | ⟨w, hwy, hwX, haw⟩
      · exact False.elim (Set.disjoint_left.mp
          (background_disjoint_branch T L E hL hc hy) haB
          (label_subset_branchLabels T L (prefix_mem_branch T hc hzx hx) haz))
      · have hwz := label_eq_on_branch T L E hL hc
          (prefix_mem_branch T hc hwy hy) (prefix_mem_branch T hc hzx hx) haw haz
        exact Or.inr ⟨z, hzx, hwz ▸ hwX, haz⟩
  · intro ha
    exact ⟨nodeSection_mono_node T L X hxy ha, nodeSection_mono_input T L hXY x ha⟩

theorem label_subset_section_iff (hp : T.IsProper) (X : Set T.Node) (x : T.Node) :
    L x ⊆ nodeSection T L X x ↔ x ∈ X := by
  constructor
  · intro hsub
    by_contra hxX
    obtain ⟨c, hc, hx⟩ := hp.2 x
    obtain ⟨a, ha⟩ := (hL.1 x).2
    exact Set.disjoint_left.mp (missing_block_disjoint T L E hL hc hx hx hxX) ha (hsub ha)
  · intro hx a ha
    exact Or.inr ⟨x, List.prefix_refl _, hx, ha⟩

end DIDomainClassification.TreeRealisationGeometry
