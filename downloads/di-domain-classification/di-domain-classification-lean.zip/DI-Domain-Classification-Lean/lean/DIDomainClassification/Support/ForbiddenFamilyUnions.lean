import DIDomainClassification.Support.SingletonForbiddenDomains
/-! Actual boundedness of arbitrary families in a forbidden-subset domain,
and a proved MIC criterion for finite nonempty disjoint partitions of a
forbidden set. No degree/comb/block existence is assumed.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ForbiddenUnionSupport

open Preliminaries CoherenceDegree ForbiddenFiniteDomains
open SingletonForbiddenDomains (ForbiddenAntichain)

variable {A : Type u}

def unionValues {H : Set (Set A)} (F : Set (AvoidanceDomain H)) : Set A :=
  {a | ∃ X ∈ F, a ∈ X.val}

theorem family_bddAbove_iff (H : Set (Set A)) (F : Set (AvoidanceDomain H)) :
    BddAbove F ↔ Avoids H (unionValues F) := by
  constructor
  · rintro ⟨Y, hY⟩ U hU hUF
    apply Y.property U hU
    intro a ha
    obtain ⟨X, hXF, haX⟩ := hUF ha
    exact hY hXF haX
  · intro hF
    refine ⟨⟨unionValues F, hF⟩, ?_⟩
    intro X hXF a haX
    exact ⟨X, hXF, haX⟩

theorem unionValues_mono {H : Set (Set A)} {F G : Set (AvoidanceDomain H)}
    (hFG : F ⊆ G) : unionValues F ⊆ unionValues G := by
  rintro a ⟨X, hX, ha⟩
  exact ⟨X, hFG hX, ha⟩

/-- A finite family partitioning one actual forbidden set is MIC. Every
piece is genuinely nonempty, and pairwise disjointness is proved in uses.
-/
theorem disjoint_partition_mic (H : Set (Set A)) (hH : Admissible H)
    (hAnti : ForbiddenAntichain H) (F : Set (AvoidanceDomain H)) (hFin : F.Finite)
    (hNonempty : ∀ X ∈ F, X.val.Nonempty)
    (hDisjoint : ∀ X ∈ F, ∀ Y ∈ F, X ≠ Y → Disjoint X.val Y.val)
    (hForbidden : unionValues F ∈ H) : IsMinimallyInconsistent (isScottDomain H hH) F := by
  classical
  refine ⟨hFin, ?_, ?_⟩
  · intro hFbdd
    exact ((family_bddAbove_iff H F).1 hFbdd) (unionValues F) hForbidden (Set.Subset.refl _)
  · intro N hN
    apply (family_bddAbove_iff H N).2
    intro U hUH hUN
    have hUF : U ⊆ unionValues F := hUN.trans (unionValues_mono hN.1)
    have hEq : U = unionValues F := hAnti U hUH _ hForbidden hUF
    have hFull : unionValues F ⊆ unionValues N := hEq ▸ hUN
    apply hN.2
    intro X hXF
    obtain ⟨a, haX⟩ := hNonempty X hXF
    obtain ⟨Y, hYN, haY⟩ := hFull ⟨X, hXF, haX⟩
    by_cases hXY : X = Y
    · simpa only [hXY] using hYN
    · exact (Set.disjoint_left.mp (hDisjoint X hXF Y (hN.1 hYN) hXY) haX haY).elim

end DIDomainClassification.ForbiddenUnionSupport

