import DIDomainClassification.Section02.RetractionCalculusStatement
import DIDomainClassification.Support.PiScottProperties
import DIDomainClassification.Support.OrderIsoTransport
import DIDomainClassification.Support.StableHomPointwiseSupport

/-! Raw stable products and higher-order operators. No compact-countability
hypothesis occurs; every carrier keeps its native supplied order. -/
set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.RawStableFunctionOperators
open OrderCore Preliminaries Section02.RetractionCalculusModels

def piDomain {I : Type v} (D : I → DIDomainObject.{u}) : IsDIDomain (∀ i, D i) := by
  letI : ∀ i, OrderBot (D i) := fun i =>
    { bot := (D i).isDIDomain.toIsScottDomain.bottom
      bot_le := (D i).isDIDomain.toIsScottDomain.bottom_le }
  exact PiTheory.pi_isDIDomain (fun i => (D i).isDIDomain)

def binaryFamily (D E : DIDomainObject.{u}) : Bool → DIDomainObject.{u}
  | false => D
  | true => E

def binaryPiOrderIso (D E : DIDomainObject.{u}) :
    (∀ b, binaryFamily D E b) ≃o (D × E) where
  toFun f := (f false, f true)
  invFun p := fun b => match b with | false => p.1 | true => p.2
  left_inv f := by funext b; cases b <;> rfl
  right_inv _ := rfl
  map_rel_iff' := by
    intro f g
    constructor
    · intro h b
      cases b
      · exact h.1
      · exact h.2
    · intro h
      exact ⟨h false, h true⟩

def productDomain (D E : DIDomainObject.{u}) : IsDIDomain (D × E) :=
  OrderIsoTransport.isDIDomain_map (binaryPiOrderIso D E) (piDomain (binaryFamily D E))

theorem product_inf (D E : DIDomainObject.{u}) (h : IsDIDomain (D × E)) (p q : D × E) :
    (p ⊓ q : productCore D E h) = (p.1 ⊓ q.1, p.2 ⊓ q.2) := by
  apply (DIDomainObject.inf_isGLB (productCore D E h) p q).unique
  constructor
  · intro z hz
    rcases Set.mem_insert_iff.mp hz with rfl | hz
    · exact ⟨inf_le_left, inf_le_left⟩
    · have heq : z = q := Set.mem_singleton_iff.mp hz
      subst z
      exact ⟨inf_le_right, inf_le_right⟩
  · intro z hz
    exact ⟨le_inf (hz (by simp)).1 (hz (by simp)).1,
      le_inf (hz (by simp)).2 (hz (by simp)).2⟩

theorem pi_inf_apply {I : Type v} (D : I → DIDomainObject.{u})
    (h : IsDIDomain (∀ i, D i)) (x y : ∀ i, D i) (i : I) :
    (x ⊓ y : piCore D h) i = x i ⊓ y i := by
  have heq : (x ⊓ y : piCore D h) = (fun j => x j ⊓ y j) := by
    apply (DIDomainObject.inf_isGLB (piCore D h) x y).unique
    constructor
    · intro z hz
      rcases Set.mem_insert_iff.mp hz with rfl | hz
      · exact fun j => inf_le_left
      · have heq : z = y := Set.mem_singleton_iff.mp hz
        subst z
        exact fun j => inf_le_right
    · intro z hz j
      exact le_inf (hz (by simp) j) (hz (by simp) j)
  exact congrFun heq i

theorem productMap_stable (D E A B : DIDomainObject.{u})
    (hDE : IsDIDomain (D × E)) (hAB : IsDIDomain (A × B))
    (sD : StableHom D A) (sE : StableHom E B) :
    IsStable (productCore D E hDE) (productCore A B hAB) (productMap sD sE) := by
  refine ⟨?_, ?_⟩
  · exact ((ScottContinuous.fst : ScottContinuous (Prod.fst : D × E → D)).comp
      (StableHom.isStable sD).1).prodMk
      ((ScottContinuous.snd : ScottContinuous (Prod.snd : D × E → E)).comp
        (StableHom.isStable sE).1)
  · intro p q hpq
    obtain ⟨z, hpz, hqz⟩ := hpq
    rw [product_inf, product_inf]
    apply Prod.ext
    · exact (StableHom.isStable sD).2 p.1 q.1 ⟨z.1, hpz.1, hqz.1⟩
    · exact (StableHom.isStable sE).2 p.2 q.2 ⟨z.2, hpz.2, hqz.2⟩

theorem piMap_stable {I : Type v} (D A : I → DIDomainObject.{u})
    (hD : IsDIDomain (∀ i, D i)) (hA : IsDIDomain (∀ i, A i))
    (s : ∀ i, StableHom (D i) (A i)) :
    IsStable (piCore D hD) (piCore A hA) (piMap s) := by
  refine ⟨?_, ?_⟩
  · intro C hne hdir x hx
    constructor
    · rintro _ ⟨y, hy, rfl⟩ i
      exact (StableHom.isStable (s i)).1.monotone (hx.1 hy i)
    · intro z hz i
      have hC : DirectedSet C := ⟨hne, hdir⟩
      have hi : DirectedSet (Function.eval i '' C) := hC.image (fun _ _ h => h i)
      apply ((StableHom.isStable (s i)).1 hi.1 hi.2 (isLUB_pi.mp hx i)).2
      rintro _ ⟨_, ⟨y, hy, rfl⟩, rfl⟩
      exact hz ⟨y, hy, rfl⟩ i
  · intro x y hxy
    obtain ⟨z, hxz, hyz⟩ := hxy
    funext i
    change s i ((x ⊓ y : piCore D hD) i) =
      (piMap s x ⊓ piMap s y : piCore A hA) i
    rw [pi_inf_apply, pi_inf_apply]
    exact (StableHom.isStable (s i)).2 (x i) (y i) ⟨z i, hxz i, hyz i⟩

theorem hom_pointwise {D E : DIDomainObject.{u}} {f g : StableHom D E}
    (h : f ≤ g) (x : D) : f x ≤ g x :=
  StableHomPointwiseSupport.stableLE_pointwise h x

theorem compatible_map {X : Type u} {Y : Type v} [Preorder X] [Preorder Y]
    {f : X → Y} (hf : Monotone f) {x y : X} (hxy : Compatible x y) :
    Compatible (f x) (f y) := by
  obtain ⟨z, hxz, hyz⟩ := hxy
  exact ⟨f z, hf hxz, hf hyz⟩

/-- Definitional identity; makes the native Hom carrier explicit to elaboration. -/
def asHom (D E : DIDomainObject.{u}) (f : exponentialCore D E) : StableHom D E := f

theorem exponential_inf_apply (D E : DIDomainObject.{u}) (f g : StableHom D E)
    (hcomp : Compatible f g) (x : D) :
    asHom D E (f ⊓ g : exponentialCore D E) x = f x ⊓ g x :=
  (StableHomPointwiseSupport.hom_isGLB_pair_iff_values f g hcomp _).mp
    (DIDomainObject.inf_isGLB (exponentialCore D E) f g) x

theorem precompose_monotone (A D E : DIDomainObject.{u}) (r : StableHom A D) :
    Monotone (fun f : StableHom D E => StableHom.comp f r) := by
  intro f g hfg x y hxy
  exact hfg (r x) (r y) ((StableHom.isStable r).1.monotone hxy)

theorem postcompose_monotone (D E F : DIDomainObject.{u}) (g : StableHom E F) :
    Monotone (fun f : StableHom D E => StableHom.comp g f) := by
  intro f h hfh x y hxy
  change g (f x) = g (f y) ⊓ g (h x)
  rw [hfh x y hxy]
  exact (StableHom.isStable g).2 (f y) (h x)
    ⟨h y, hom_pointwise hfh y, (StableHom.isStable h).1.monotone hxy⟩

def precompose (A D E : DIDomainObject.{u}) (r : StableHom A D) :
    StableHom (exponentialCore D E) (exponentialCore A E) := by
  refine StableHom.ofFunction (fun f => StableHom.comp f r) ⟨?_, ?_⟩
  · intro C hne hdir f hf
    let hC : DirectedSet C := ⟨hne, hdir⟩
    have hImages : DirectedSet ((fun h : StableHom D E => StableHom.comp h r) '' C) :=
      hC.image (precompose_monotone A D E r)
    apply (StableHomPointwiseSupport.hom_isLUB_iff_values _ hImages _).mpr
    intro x
    have h := (StableHomPointwiseSupport.hom_isLUB_iff_values C hC f).mp hf (r x)
    simpa only [Set.image_image, StableHom.comp_apply, Function.comp_def] using h
  · intro f g hcomp
    apply StableHom.ext
    intro x
    have hImages := compatible_map (precompose_monotone A D E r) hcomp
    change asHom D E (f ⊓ g : exponentialCore D E) (r x) =
      asHom A E (StableHom.comp f r ⊓ StableHom.comp g r : exponentialCore A E) x
    rw [exponential_inf_apply D E f g hcomp,
      exponential_inf_apply A E _ _ hImages]
    rfl

def postcompose (D E F : DIDomainObject.{u}) (g : StableHom E F) :
    StableHom (exponentialCore D E) (exponentialCore D F) := by
  refine StableHom.ofFunction (fun f => StableHom.comp g f) ⟨?_, ?_⟩
  · intro C hne hdir f hf
    let hC : DirectedSet C := ⟨hne, hdir⟩
    have hImages : DirectedSet ((fun h : StableHom D E => StableHom.comp g h) '' C) :=
      hC.image (postcompose_monotone D E F g)
    apply (StableHomPointwiseSupport.hom_isLUB_iff_values _ hImages _).mpr
    intro x
    have hv := (StableHomPointwiseSupport.hom_isLUB_iff_values C hC f).mp hf x
    have hValues : DirectedSet ((fun h : StableHom D E => h x) '' C) :=
      hC.image (fun _ _ h => hom_pointwise h x)
    have h := (StableHom.isStable g).1 hValues.1 hValues.2 hv
    simpa only [Set.image_image, StableHom.comp_apply, Function.comp_def] using h
  · intro f h hcomp
    apply StableHom.ext
    intro x
    have hImages := compatible_map (postcompose_monotone D E F g) hcomp
    change g (asHom D E (f ⊓ h : exponentialCore D E) x) =
      asHom D F (StableHom.comp g f ⊓ StableHom.comp g h : exponentialCore D F) x
    rw [exponential_inf_apply D E f h hcomp,
      exponential_inf_apply D F _ _ hImages]
    obtain ⟨U, hfU, hhU⟩ := hcomp
    exact (StableHom.isStable g).2 (asHom D E f x) (asHom D E h x)
      ⟨asHom D E U x, hom_pointwise hfU x, hom_pointwise hhU x⟩

theorem precompose_apply (A D E : DIDomainObject.{u}) (r : StableHom A D)
    (f : StableHom D E) (x : A) : asHom A E (precompose A D E r f) x = f (r x) := rfl

theorem postcompose_apply (D E F : DIDomainObject.{u}) (g : StableHom E F)
    (f : StableHom D E) (x : D) : asHom D F (postcompose D E F g f) x = g (f x) := rfl

end DIDomainClassification.RawStableFunctionOperators
