import DIDomainClassification.Support.TerminalProductClosure
import DIDomainClassification.Support.StableHomGeneralClosure
import DIDomainClassification.Support.StableCCCCategory

/-!
# The literal domain-closure witness and its categorical construction

All closure fields below are proved from the intrinsic domain laws. The
cartesian-closed operations and adjunctions are then supplied by the separately
proved generic construction. This is supporting mathematics; source-facing
Theorem2.2 registration, citation review and whole-paper acceptance are separate.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.StableClosureWitness

open Section02.StableBackground

def domainClosure : DomainClosure.{u} where
  terminal := TerminalProductClosure.unit_isCountablyBasedDIDomain
  product := TerminalProductClosure.product_isCountablyBasedDIDomain
  exponential := StableExponentialClosure.stableHom_isCountablyBasedDIDomain

theorem construction : Nonempty (CartesianClosedConstruction domainClosure.{u}) :=
  StableCCCCategory.domainClosure_implies_construction domainClosure

theorem ambientCartesianClosed : AmbientCartesianClosed.{u} := by
  obtain ⟨K⟩ := construction.{u}
  exact K.cartesianClosed

theorem directedSupremaPointwise : DirectedSupremaPointwise.{u} := by
  intro D E A hA
  exact ⟨⟨StableHomPointwiseSupport.homDirectedSup A hA,
      StableHomPointwiseSupport.homDirectedSup_isLUB A hA,
      StableHomPointwiseSupport.homDirectedSup_values A hA⟩,
    StableHomPointwiseSupport.hom_isLUB_iff_values A hA⟩

theorem compatibleMeetsPointwise : CompatibleMeetsPointwise.{u} := by
  intro D E f g hfg
  exact ⟨⟨StableHomPointwiseSupport.homPointwiseInf f g,
      StableHomPointwiseSupport.homPointwiseInf_isGLB f g hfg,
      StableHomPointwiseSupport.homPointwiseInf_apply f g⟩,
    StableHomPointwiseSupport.hom_isGLB_pair_iff_values f g hfg⟩

end DIDomainClassification.StableClosureWitness
