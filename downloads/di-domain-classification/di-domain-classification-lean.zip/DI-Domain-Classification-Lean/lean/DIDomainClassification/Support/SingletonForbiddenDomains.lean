import DIDomainClassification.Support.ForbiddenFiniteDomains
import DIDomainClassification.Support.PointwiseScottMIC

/-!
Singletons in the literal arbitrary-subset forbidden-family domain. No lower
closure of subsets, countability of points, or antichain property is hidden in
the model. Antichain is explicit ONLY where identifying MIC sets with H.
-/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.SingletonForbiddenDomains

open Preliminaries CoherenceDegree ForbiddenFiniteDomains
open PointwiseFunctionSupport (IsFiniteJoinBasis)

variable {A : Type u}

def singletonPoint (H : Set (Set A)) (hH : Admissible H) (a : A) : AvoidanceDomain H :=
  ⟨{a}, fun U hU => hH.no_subset_singleton a U hU⟩

theorem singletonPoint_val (H : Set (Set A)) (hH : Admissible H) (a : A) :
    (singletonPoint H hH a).val = {a} := rfl

theorem singletonPoint_injective (H : Set (Set A)) (hH : Admissible H) :
    Function.Injective (singletonPoint H hH) := by
  intro a b hab
  have hset : ({a} : Set A) = {b} := congrArg Subtype.val hab
  exact Set.mem_singleton_iff.mp (hset ▸ Set.mem_singleton a)

theorem singletonPoint_compact (H : Set (Set A)) (hH : Admissible H) (a : A) :
    IsCompactElement (singletonPoint H hH a) :=
  (compact_iff_finite H hH _).2 (Set.finite_singleton a)

theorem singletonPoint_le_iff (H : Set (Set A)) (hH : Admissible H)
    (a : A) (X : AvoidanceDomain H) : singletonPoint H hH a ≤ X ↔ a ∈ X.val :=
  Set.singleton_subset_iff

/-- Every arbitrary singleton family is bounded exactly when its underlying
arbitrary node set avoids H. This is not limited to finite/lower subsets. -/
theorem singleton_image_bddAbove_iff (H : Set (Set A)) (hH : Admissible H) (X : Set A) :
    BddAbove (singletonPoint H hH '' X) ↔ Avoids H X := by
  constructor
  · rintro ⟨Y, hY⟩ U hU hUX
    apply Y.property U hU
    intro a ha
    exact (singletonPoint_le_iff H hH a Y).1 (hY ⟨a, hUX ha, rfl⟩)
  · intro hX
    refine ⟨⟨X, hX⟩, ?_⟩
    rintro _ ⟨a, ha, rfl⟩
    exact (singletonPoint_le_iff H hH a ⟨X, hX⟩).2 ha

def singletonBasis (H : Set (Set A)) (hH : Admissible H) : Set (AvoidanceDomain H) :=
  Set.range (singletonPoint H hH)

theorem singleton_isFiniteJoinBasis (H : Set (Set A)) (hH : Admissible H) :
    IsFiniteJoinBasis (singletonBasis H hH) := by
  constructor
  · rintro X ⟨a, rfl⟩
    exact singletonPoint_compact H hH a
  · intro X hX
    have hfin : X.val.Finite := (compact_iff_finite H hH X).1 hX
    refine ⟨singletonPoint H hH '' X.val, hfin.image _, ?_, ?_⟩
    · rintro _ ⟨a, _ha, rfl⟩
      exact ⟨a, rfl⟩
    · constructor
      · rintro _ ⟨a, ha, rfl⟩
        exact (singletonPoint_le_iff H hH a X).2 ha
      · intro Y hY a ha
        exact (singletonPoint_le_iff H hH a Y).1 (hY ⟨a, ha, rfl⟩)

def ForbiddenAntichain (H : Set (Set A)) : Prop :=
  ∀ U ∈ H, ∀ V ∈ H, U ⊆ V → U = V

/-- Exact MIC characterization for singleton SETS under a proved forbidden
antichain. Arbitrary subsets X are quantified; finiteness is an output of H.
-/
theorem singleton_image_mic_iff (H : Set (Set A)) (hH : Admissible H)
    (hAntichain : ForbiddenAntichain H) (X : Set A) :
    IsMinimallyInconsistent (isScottDomain H hH) (singletonPoint H hH '' X) ↔ X ∈ H := by
  classical
  let f := singletonPoint H hH
  have hf : Function.Injective f := singletonPoint_injective H hH
  constructor
  · intro hM
    have hbad : ¬ Avoids H X := fun hX =>
      hM.2.1 ((singleton_image_bddAbove_iff H hH X).2 hX)
    change ¬ ∀ U : Set A, U ∈ H → ¬ U ⊆ X at hbad
    push Not at hbad
    obtain ⟨U, hUH, hUX⟩ := hbad
    have hUbad : ¬ BddAbove (f '' U) := by
      intro hUbdd
      exact ((singleton_image_bddAbove_iff H hH U).1 hUbdd) U hUH (Set.Subset.refl U)
    have hImage : f '' U = f '' X := by
      apply Set.Subset.antisymm (Set.image_mono hUX)
      by_contra hback
      exact hUbad (hM.2.2 _ ⟨Set.image_mono hUX, hback⟩)
    have hXU : X ⊆ U := by
      intro a ha
      obtain ⟨b, hb, hba⟩ := hImage.symm.subset ⟨a, ha, rfl⟩
      simpa only [hf hba] using hb
    simpa only [Set.Subset.antisymm hUX hXU] using hUH
  · intro hXH
    refine ⟨(hH.finite X hXH).image _, ?_, ?_⟩
    · intro hXbdd
      exact ((singleton_image_bddAbove_iff H hH X).1 hXbdd) X hXH (Set.Subset.refl X)
    · intro N hN
      let Y : Set A := X ∩ f ⁻¹' N
      have hYproper : Y ⊂ X := by
        refine ⟨fun _ hy => hy.1, ?_⟩
        intro hback
        apply hN.2
        rintro _ ⟨a, ha, rfl⟩
        exact (hback ha).2
      have hImage : f '' Y = N := by
        ext p
        constructor
        · rintro ⟨a, ha, rfl⟩
          exact ha.2
        · intro hp
          obtain ⟨a, ha, rfl⟩ := hN.1 hp
          exact ⟨a, ⟨ha, hp⟩, rfl⟩
      have hYavoid : Avoids H Y := by
        intro U hUH hUY
        have hUX : U ⊆ X := hUY.trans hYproper.1
        have hUXeq : U = X := hAntichain U hUH X hXH hUX
        exact hYproper.2 (hUXeq ▸ hUY)
      have hYbdd := (singleton_image_bddAbove_iff H hH Y).2 hYavoid
      change BddAbove (f '' Y) at hYbdd
      rw [hImage] at hYbdd
      exact hYbdd

end DIDomainClassification.SingletonForbiddenDomains
