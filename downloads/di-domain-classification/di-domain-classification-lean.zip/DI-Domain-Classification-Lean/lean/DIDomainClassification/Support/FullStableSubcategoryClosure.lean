import DIDomainClassification.Section02.SubcategoryConventions
import DIDomainClassification.Support.StableClosureWitness
import Mathlib.CategoryTheory.Adjunction.Restrict
import Mathlib.CategoryTheory.Limits.Preserves.Shapes.BinaryProducts

/-!
# Intrinsic cartesian closedness from actual native closure

This generic support theorem assumes only membership of the literal unit and
closure under the already proved native binary products and stable function
spaces. It constructs the actual terminal object, internal product cones and
right adjoints to the actual internally chosen product functors. In particular,
no repleteness assumption and no assumed intrinsic cartesian closedness enter.
It is not a claim that any manuscript candidate satisfies these hypotheses.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.FullStableSubcategoryClosure

open CategoryTheory CategoryTheory.Limits
open Subcategories Section02.StableBackground

abbrev closure : DomainClosure.{u} := StableClosureWitness.domainClosure.{u}

variable (P : ObjectClass.{u})

/-- The literal unit belongs to the full subcategory by the explicit hypothesis. -/
def unitObject (hUnit : P (terminalObject closure)) : FullStableSubcategory P :=
  ⟨terminalObject closure, hUnit⟩

/-- Terminality uses all actual ambient stable maps, without any strictness. -/
def unitIsTerminal (hUnit : P (terminalObject closure)) :
    IsTerminal (unitObject P hUnit) :=
  IsTerminal.ofUniqueHom
    (fun D => ObjectProperty.homMk (StableCCCOperations.terminalArrow closure D.obj))
    (fun D f => ObjectProperty.hom_ext P
      (StableCCCOperations.terminal_unique closure D.obj f.hom))

variable
  (hProd : ∀ D E, P D → P E → P
    (Section02.StableBackground.productObject closure D E))

include hProd

/-- The internal native binary product, not an assumed chosen-product equality. -/
def productObject (D E : FullStableSubcategory P) : FullStableSubcategory P :=
  ⟨Section02.StableBackground.productObject closure D.obj E.obj,
    hProd D.obj E.obj D.property E.property⟩

def fst (D E : FullStableSubcategory P) : productObject P hProd D E ⟶ D :=
  ObjectProperty.homMk (StableCCCOperations.fst closure D.obj E.obj)

def snd (D E : FullStableSubcategory P) : productObject P hProd D E ⟶ E :=
  ObjectProperty.homMk (StableCCCOperations.snd closure D.obj E.obj)

/-- The native pairing laws give the actual limiting cone in the full category. -/
def productIsLimit (D E : FullStableSubcategory P) :
    IsLimit (BinaryFan.mk (C := FullStableSubcategory P)
      (fst P hProd D E) (snd P hProd D E)) := by
  apply BinaryFan.isLimitMk
    (fun s => ObjectProperty.homMk
      (StableCCCOperations.pair closure s.pt.obj D.obj E.obj s.fst.hom s.snd.hom))
  · intro s
    apply ObjectProperty.hom_ext P
    exact StableCCCOperations.pair_fst closure s.pt.obj D.obj E.obj s.fst.hom s.snd.hom
  · intro s
    apply ObjectProperty.hom_ext P
    exact StableCCCOperations.pair_snd closure s.pt.obj D.obj E.obj s.fst.hom s.snd.hom
  · intro s m hfst hsnd
    apply ObjectProperty.hom_ext P
    have h1 : StableHom.comp (StableCCCOperations.fst closure D.obj E.obj) m.hom =
        s.fst.hom := congrArg InducedCategory.Hom.hom hfst
    have h2 : StableHom.comp (StableCCCOperations.snd closure D.obj E.obj) m.hom =
        s.snd.hom := congrArg InducedCategory.Hom.hom hsnd
    calc
      m.hom = StableCCCOperations.pair closure s.pt.obj D.obj E.obj
          (StableHom.comp (StableCCCOperations.fst closure D.obj E.obj) m.hom)
          (StableHom.comp (StableCCCOperations.snd closure D.obj E.obj) m.hom) :=
        (StableCCCOperations.pair_unique closure s.pt.obj D.obj E.obj m.hom).symm
      _ = StableCCCOperations.pair closure s.pt.obj D.obj E.obj s.fst.hom s.snd.hom := by
        rw [h1, h2]

theorem hasBinaryProducts : HasBinaryProducts (FullStableSubcategory P) := by
  letI (D E : FullStableSubcategory P) : HasLimit (Limits.pair D E) :=
    HasLimit.mk ⟨_, productIsLimit P hProd D E⟩
  exact hasBinaryProducts_of_hasLimit_pair (FullStableSubcategory P)

theorem hasFiniteProducts (hUnit : P (terminalObject closure)) :
    HasFiniteProducts (FullStableSubcategory P) := by
  letI : HasBinaryProducts (FullStableSubcategory P) := hasBinaryProducts P hProd
  letI : HasTerminal (FullStableSubcategory P) := (unitIsTerminal P hUnit).hasTerminal
  exact CategoryTheory.hasFiniteProducts_of_has_binary_and_terminal

/-- The inclusion preserves these products because their mapped native cones
are the independently proved limiting cones in the actual ambient category. -/
theorem inclusionPreservesPair (D E : FullStableSubcategory P) :
    PreservesLimit (Limits.pair D E) P.ι := by
  apply preservesLimit_of_preserves_limit_cone (productIsLimit P hProd D E)
  exact (isLimitMapConeBinaryFanEquiv P.ι (fst P hProd D E) (snd P hProd D E)).symm
    (StableCCCCategory.literalProductIsLimit closure D.obj E.obj)

variable
  (hExp : ∀ D E, P D → P E → P (exponentialObject closure D E))

include hExp

/-- The right adjoint acts on all actual stable maps by actual postcomposition. -/
def exponentialFunctor (D : FullStableSubcategory P) :
    FullStableSubcategory P ⥤ FullStableSubcategory P :=
  P.lift (P.ι ⋙ StableCCCCategory.exponentialFunctor closure D.obj)
    (fun E => hExp D.obj E.obj D.property E.property)

section ChosenInternalProducts

variable [HasFiniteProducts (FullStableSubcategory P)]

/-- The product comparison is a proved natural isomorphism, so no equality of
internal and ambient choices, or extra closure under isomorphisms, is assumed. -/
def inclusionProductIso (D : FullStableSubcategory P) :
    letI : HasFiniteProducts Obj.{u} := StableCCCCategory.hasFiniteProducts closure
    prod.functor.obj D ⋙ P.ι ≅ P.ι ⋙ prod.functor.obj D.obj := by
  letI : HasFiniteProducts Obj.{u} := StableCCCCategory.hasFiniteProducts closure
  letI (E : FullStableSubcategory P) : PreservesLimit (Limits.pair D E) P.ι :=
    inclusionPreservesPair P hProd D E
  exact prodComparisonNatIso P.ι D

/-- Restriction of the actual ambient stable-exponential adjunction along the
fully faithful inclusion, with the actual intrinsic product functor on the left. -/
def productAdjunction (D : FullStableSubcategory P) :
    prod.functor.obj D ⊣ exponentialFunctor P hExp D := by
  letI : HasFiniteProducts Obj.{u} := StableCCCCategory.hasFiniteProducts closure
  exact (StableCCCCategory.productAdjunction closure D.obj).restrictFullyFaithful
    P.fullyFaithfulι P.fullyFaithfulι (inclusionProductIso P hProd D).symm (Iso.refl _)

theorem productFunctorIsLeftAdjoint (D : FullStableSubcategory P) :
    (prod.functor.obj D).IsLeftAdjoint :=
  ⟨⟨exponentialFunctor P hExp D, ⟨productAdjunction P hProd hExp D⟩⟩⟩

end ChosenInternalProducts

/-- Generic native closure is sufficient for intrinsic cartesian closedness.
Applications must prove each of the three displayed membership hypotheses. -/
theorem intrinsicallyCartesianClosed (hUnit : P (terminalObject closure)) :
    IsIntrinsicallyCartesianClosed P := by
  refine ⟨hasFiniteProducts P hProd hUnit, ?_⟩
  letI : HasFiniteProducts (FullStableSubcategory P) := hasFiniteProducts P hProd hUnit
  intro D
  exact productFunctorIsLeftAdjoint P hProd hExp D

end DIDomainClassification.FullStableSubcategoryClosure
