import DIDomainClassification.Section04.PointwiseNotStableStatement
import DIDomainClassification.Section04.CausalRetraction
import DIDomainClassification.Support.FiniteOrderDomains
import DIDomainClassification.Support.OrderIsoTransport

/-! The literal two-event causal chain and its lower-interior split. All maps
below are stable for the native domain structures. The last lemma distinguishes
pointwise deflation from comparison in the native stable function order. -/

set_option autoImplicit false
noncomputable section

namespace DIDomainClassification.PointwiseChainInterior

open Preliminaries EventStructures FiniteCausalConflicts
open Section04.AdditionalSourceModels Section04.PointwiseNotStableModels

theorem conflicts_empty : causalConflictFamily chainEvents = ∅ := by
  ext H
  simp only [Set.mem_empty_iff_false, iff_false]
  rintro ⟨U, hU, _⟩
  exact hU.2.2.1 (Set.mem_univ U)

def closure : QualitativeCoverClosure chainEvents := CausalCoverSupport.closure chainEvents

def powersetCB : IsCountablyBasedDIDomain (Set (Fin 2)) :=
  FiniteOrderDomains.finiteCompleteDistribLattice_isCountablyBased _

abbrev powersetCore : DIDomainObject := (cbObject (Set (Fin 2)) powersetCB).toDIDomainObject
abbrev coverCore : DIDomainObject := qualitativeCoverCore chainEvents closure
abbrev configurationCore : DIDomainObject := causalConfigurationCore chainEvents

def orderIso : QualitativeCover chainEvents ≃o Set (Fin 2) where
  toFun Y := Y.val
  invFun Y := ⟨Y, by
    intro H hH
    rw [conflicts_empty] at hH
    exact False.elim hH⟩
  left_inv _ := rfl
  right_inv _ := rfl
  map_rel_iff' := Iff.rfl

theorem pair_eq_univ : ({0, 1} : Set (Fin 2)) = Set.univ := by
  ext a
  rcases BasicDomains.two_eq_zero_or_one a with rfl | rfl <;> simp

theorem configuration_iff_lower (X : Set (Fin 2)) :
    IsConfiguration chainEvents X ↔ IsLowerSet X :=
  ⟨And.left, fun h => ⟨h, fun _ _ _ => Set.mem_univ _⟩⟩

theorem configurations (X : Set (Fin 2)) : IsConfiguration chainEvents X ↔
    X = ∅ ∨ X = {0} ∨ X = {0, 1} := by
  rw [configuration_iff_lower]
  constructor
  · intro hX
    by_cases h1 : (1 : Fin 2) ∈ X
    · right; right
      have h0 : (0 : Fin 2) ∈ X := hX (by decide : (0 : Fin 2) ≤ 1) h1
      ext a
      rcases BasicDomains.two_eq_zero_or_one a with rfl | rfl <;> simp [h0, h1]
    · by_cases h0 : (0 : Fin 2) ∈ X
      · right; left
        ext a
        rcases BasicDomains.two_eq_zero_or_one a with rfl | rfl <;> simp [h0, h1]
      · left
        ext a
        rcases BasicDomains.two_eq_zero_or_one a with rfl | rfl <;> simp [h0, h1]
  · rintro (rfl | rfl | rfl)
    · intro a b _ hb
      exact False.elim hb
    · intro a b hab hb
      have ha0 : a = 0 := Set.mem_singleton_iff.mp hb
      subst a
      exact Set.mem_singleton_iff.mpr (le_antisymm hab (Fin.zero_le b))
    · rw [pair_eq_univ]
      exact isLowerSet_univ

def sectionMap : StableHom configurationCore coverCore :=
  StableHom.ofFunction (CausalCoverSupport.sectionMap chainEvents)
    (CausalCoverSupport.section_stable chainEvents closure)

def retractionMap : StableHom coverCore configurationCore :=
  StableHom.ofFunction (CausalCoverSupport.retractionMap chainEvents)
    (CausalCoverSupport.retraction_stable chainEvents closure)

def composite : StableHom powersetCore powersetCore :=
  StableHom.comp (OrderIsoTransport.stableHom coverCore powersetCore orderIso)
    (StableHom.comp sectionMap
      (StableHom.comp retractionMap
        (OrderIsoTransport.stableHom powersetCore coverCore orderIso.symm)))

theorem composite_apply (Y : Set (Fin 2)) : composite Y = lowerInterior Y := rfl

theorem composite_subset (Y : Set (Fin 2)) : Set.Subset (composite Y) Y :=
  lowerInterior_subset Y

theorem composite_singleton_one : composite ({1} : Set (Fin 2)) = (∅ : Set (Fin 2)) := by
  change lowerInterior ({1} : Set (Fin 2)) = ∅
  ext a
  simp only [Set.mem_empty_iff_false, iff_false]
  intro ha
  have h0 : (0 : Fin 2) ∈ ({1} : Set (Fin 2)) := ha (Fin.zero_le a)
  exact (by decide : (0 : Fin 2) ≠ 1) (Set.mem_singleton_iff.mp h0)

theorem composite_pair : composite ({0, 1} : Set (Fin 2)) = ({0, 1} : Set (Fin 2)) := by
  rw [composite_apply, pair_eq_univ, lowerInterior_univ]

theorem powerset_inf (X Y : powersetCore) :
    (X ⊓ Y : powersetCore) = (X ∩ Y : Set (Fin 2)) := by
  have hI : IsGLB ({X, Y} : Set powersetCore) (X ∩ Y : Set (Fin 2)) := by
    constructor
    · intro Z hZ
      rcases Set.mem_insert_iff.mp hZ with rfl | hZ
      · exact Set.inter_subset_left
      · have heq : Z = Y := Set.mem_singleton_iff.mp hZ
        subst Z
        exact Set.inter_subset_right
    · intro Z hZ
      exact Set.subset_inter (hZ (by simp)) (hZ (by simp))
  exact (DIDomainObject.inf_isGLB powersetCore X Y).unique hI

theorem composite_not_stableLE_identity : ¬ composite ≤ StableHom.id powersetCore := by
  intro h
  have hsub : ({1} : Set (Fin 2)) ⊆ {0, 1} := by simp
  have hEq := h ({1} : Set (Fin 2)) ({0, 1} : Set (Fin 2)) hsub
  change composite ({1} : Set (Fin 2)) =
    (composite ({0, 1} : Set (Fin 2)) ⊓ ({1} : Set (Fin 2)) : powersetCore) at hEq
  rw [composite_singleton_one, powerset_inf, composite_pair] at hEq
  have hOne : (1 : Fin 2) ∈ (∅ : Set (Fin 2)) := hEq ▸ (by simp)
  exact hOne

end DIDomainClassification.PointwiseChainInterior
