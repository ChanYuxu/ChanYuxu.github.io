import DIDomainClassification.Support.CompactRetractLift
import DIDomainClassification.Support.CountableAccRank
import DIDomainClassification.Section02.RankDegree

/-!
# Supporting coherence-degree inequalities

These are proved supporting results for the current actual rank model, not
an accepted whole-source BPS theorem. No library coherence-degree theorem,
classification result or mathematical axiom is assumed. Source-facing wrappers,
independent proof review and complete BPS coverage remain separate obligations.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.OrdinalSupport

theorem card_acc_rank_add_one_le_aleph0 {A : Type u} [Countable A]
    {r : A → A → Prop} {a : A} (ha : Acc r a) :
    (ha.rank + 1).card ≤ Cardinal.aleph0 := by
  rw [Ordinal.card_add_one]
  calc
    ha.rank.card + 1 ≤ Cardinal.aleph0 + 1 :=
      add_le_add (card_acc_rank_le_aleph0 ha) le_rfl
    _ = Cardinal.aleph0 := Cardinal.add_one_of_aleph0_le le_rfl

end DIDomainClassification.OrdinalSupport

namespace DIDomainClassification.CoherenceDegree

open Preliminaries

/-- Relabel the same source trees by proved compact lifts along the split. -/
theorem coherenceDegree_mono_of_scott_split {D E : Type u}
    [PartialOrder D] [PartialOrder E] (hD : IsScottDomain D) (hE : IsScottDomain E)
    {s : D → E} {r : E → D} (hs : ScottContinuous s) (hr : ScottContinuous r)
    (hleft : Function.LeftInverse r s) :
    coherenceDegree hD ≤ coherenceDegree hE := by
  apply (coherenceDegree_le_iff hD (coherenceDegree hE)).mpr
  intro Index M hM
  let N : MicTree E hE Index :=
    CompactRetractLift.liftMicTree hE.algebraic hs hr hleft hD hE M
  have hN : N.tree.IsWellFounded := hM
  exact treeRank_add_one_le_coherenceDegree hE N hN

/-- Every countable source tree has a countable rank, before the universe lift. -/
theorem coherenceDegree_le_firstUncountable {D : Type u} [PartialOrder D]
    (hD : IsScottDomain D) :
    coherenceDegree hD ≤ (Order.succ Cardinal.aleph0.{u+1}).ord := by
  apply (coherenceDegree_le_iff hD _).mpr
  intro Index M hM
  have hc : (M.tree.treeRank hM + 1).card ≤ Cardinal.aleph0 := by
    exact OrdinalSupport.card_acc_rank_add_one_le_aleph0
      ((M.tree.isWellFounded_iff_wellFounded_reverseChildRelation.mp hM).apply M.tree.root)
  have hl : (Ordinal.lift.{u+1} (M.tree.treeRank hM + 1)).card ≤ Cardinal.aleph0 := by
    rw [← Ordinal.lift_card]
    exact Cardinal.lift_le_aleph0.mpr hc
  exact (Cardinal.card_le_iff.mp hl).le

end DIDomainClassification.CoherenceDegree
