import DIDomainClassification.Support.TreeEdgeMaps

/-! Actual finite blocks from a native root/child-preserving map. At a source
leaf the block is the finite path from its image to a genuine target leaf.
The branch partition laws are proved outputs, not hypotheses. -/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.TreeEdgeBlocks

open Trees TreeEdgeMaps
variable {A : Type u} {B : Type v}

def leafAbove (S : RootedPrefixTree B) (hp : S.IsProper) (w : S.Node) : S.Node :=
  Classical.choose (((S.isProper_iff).mp hp).2 w)

theorem leafAbove_isLeaf (S : RootedPrefixTree B) (hp : S.IsProper) (w : S.Node) :
    S.IsLeaf (leafAbove S hp w) :=
  (Classical.choose_spec (((S.isProper_iff).mp hp).2 w)).1

theorem le_leafAbove (S : RootedPrefixTree B) (hp : S.IsProper) (w : S.Node) :
    w ≤ leafAbove S hp w :=
  (Classical.choose_spec (((S.isProper_iff).mp hp).2 w)).2

def blocks (T : RootedPrefixTree A) (S : RootedPrefixTree B) (hp : S.IsProper)
    (f : T.Node → S.Node) (x : T.Node) : Set S.Node := by
  classical
  exact if T.IsLeaf x then {z | f x ≤ z ∧ z ≤ leafAbove S hp (f x)} else {f x}

variable (T : RootedPrefixTree A) (S : RootedPrefixTree B) (hp : S.IsProper)
    (f : T.Node → S.Node)

theorem block_contains (x : T.Node) : f x ∈ blocks T S hp f x := by
  classical
  by_cases hx : T.IsLeaf x
  · simpa only [blocks, if_pos hx, Set.mem_setOf_eq] using
      (show f x ≤ f x ∧ f x ≤ leafAbove S hp (f x) from ⟨le_rfl, le_leafAbove S hp _⟩)
  · simp only [blocks, if_neg hx, Set.mem_singleton_iff]

theorem block_finite (x : T.Node) : (blocks T S hp f x).Finite := by
  classical
  by_cases hx : T.IsLeaf x
  · simp only [blocks, if_pos hx]
    exact (S.pathTo_finite (leafAbove S hp (f x))).subset (fun _ hz => hz.2)
  · simp only [blocks, if_neg hx]
    exact Set.finite_singleton _

theorem block_nonempty (x : T.Node) : (blocks T S hp f x).Nonempty :=
  ⟨f x, block_contains T S hp f x⟩

variable (hroot : f T.root = S.root)
    (hchild : ∀ {x y : T.Node}, T.IsChild x y → S.IsChild (f x) (f y))
include hroot hchild

theorem disjoint_on_path (a : T.Node) :
    (T.pathTo a).Pairwise (fun x y => Disjoint (blocks T S hp f x) (blocks T S hp f y)) := by
  classical
  intro x hx y hy hxy
  apply Set.disjoint_left.mpr
  intro z hxz hyz
  by_cases hxl : T.IsLeaf x
  · have hxa : x = a := (hxl a hx).symm
    by_cases hyl : T.IsLeaf y
    · have hya : y = a := (hyl a hy).symm
      exact hxy (hxa.trans hya.symm)
    · have hzy : z = f y := by
        simpa only [blocks, if_neg hyl, Set.mem_singleton_iff] using hyz
      have hfxz : f x ≤ z := by
        have h : f x ≤ z ∧ z ≤ leafAbove S hp (f x) := by
          simpa only [blocks, if_pos hxl, Set.mem_setOf_eq] using hxz
        exact h.1
      have hyx : y ≤ x := by simpa only [hxa] using hy
      have hEq : f x = f y := le_antisymm
        (by simpa only [hzy] using hfxz) (prefix_monotone T S f hchild hyx)
      exact hxy (injective_on_path T S f hroot hchild a hx hy hEq)
  · have hzx : z = f x := by
      simpa only [blocks, if_neg hxl, Set.mem_singleton_iff] using hxz
    by_cases hyl : T.IsLeaf y
    · have hya : y = a := (hyl a hy).symm
      have hfyz : f y ≤ z := by
        have h : f y ≤ z ∧ z ≤ leafAbove S hp (f y) := by
          simpa only [blocks, if_pos hyl, Set.mem_setOf_eq] using hyz
        exact h.1
      have hxy' : x ≤ y := by simpa only [hya] using hx
      have hEq : f x = f y := le_antisymm (prefix_monotone T S f hchild hxy')
        (by simpa only [hzx] using hfyz)
      exact hxy (injective_on_path T S f hroot hchild a hx hy hEq)
    · have hzy : z = f y := by
        simpa only [blocks, if_neg hyl, Set.mem_singleton_iff] using hyz
      exact hxy (injective_on_path T S f hroot hchild a hx hy (hzx.symm.trans hzy))

theorem union_path (a : T.Node) (ha : T.IsLeaf a) :
    (⋃ x ∈ T.pathTo a, blocks T S hp f x) = S.pathTo (leafAbove S hp (f a)) := by
  classical
  ext z
  constructor
  · intro hz
    obtain ⟨x, hz⟩ := Set.mem_iUnion.mp hz
    obtain ⟨hx, hxz⟩ := Set.mem_iUnion.mp hz
    by_cases hxl : T.IsLeaf x
    · have hxa : x = a := (hxl a hx).symm
      subst x
      have h : f a ≤ z ∧ z ≤ leafAbove S hp (f a) := by
        simpa only [blocks, if_pos ha, Set.mem_setOf_eq] using hxz
      exact h.2
    · have hzx : z = f x := by
        simpa only [blocks, if_neg hxl, Set.mem_singleton_iff] using hxz
      rw [hzx]
      exact (prefix_monotone T S f hchild hx).trans (le_leafAbove S hp _)
  · intro hz
    rcases List.prefix_or_prefix_of_prefix hz (le_leafAbove S hp (f a)) with hzf | hfz
    · have hImage : z ∈ f '' T.pathTo a := by
        rw [image_path T S f hroot hchild a]
        exact hzf
      obtain ⟨x, hx, hxz⟩ := hImage
      refine Set.mem_iUnion.mpr ⟨x, Set.mem_iUnion.mpr ⟨hx, ?_⟩⟩
      rw [← hxz]
      exact block_contains T S hp f x
    · refine Set.mem_iUnion.mpr ⟨a, Set.mem_iUnion.mpr
        ⟨(show a ∈ T.pathTo a from List.prefix_refl a.val), ?_⟩⟩
      simpa only [blocks, if_pos ha, Set.mem_setOf_eq] using
        (show f a ≤ z ∧ z ≤ leafAbove S hp (f a) from ⟨hfz, hz⟩)

theorem conditions :
    (∀ x, (blocks T S hp f x).Finite ∧ (blocks T S hp f x).Nonempty) ∧
    (∀ c : Set T.Node, T.IsFiniteCompleteBranch c →
      c.Pairwise (fun x y => Disjoint (blocks T S hp f x) (blocks T S hp f y)) ∧
        S.IsFiniteCompleteBranch (⋃ x ∈ c, blocks T S hp f x)) := by
  refine ⟨fun x => ⟨block_finite T S hp f x, block_nonempty T S hp f x⟩, ?_⟩
  intro c hc
  obtain ⟨a, ha, rfl⟩ := hc
  refine ⟨disjoint_on_path T S hp f hroot hchild a, ?_⟩
  exact ⟨leafAbove S hp (f a), leafAbove_isLeaf S hp _, union_path T S hp f hroot hchild a ha⟩

end DIDomainClassification.TreeEdgeBlocks
