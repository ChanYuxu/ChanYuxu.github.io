import DIDomainClassification.Section04.ComparisonStatements
import DIDomainClassification.Section02.RetractionCalculus
import DIDomainClassification.Support.FunctionDegreeHelpers
import DIDomainClassification.Support.FlatPowerRetraction

/-! Actual stable splits and the elementary comparison operations. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.ComparisonOperations
open Preliminaries Section03.StableFunctionModels
open Section04 AdditionalSourceModels

theorem split_trans {D E F : DIDomainObject.{u}}
    (hDE : HasStableRetraction D E) (hEF : HasStableRetraction E F) :
    HasStableRetraction D F := by
  obtain ⟨s,r,h⟩ := hDE
  obtain ⟨t,q,k⟩ := hEF
  exact (Section02.retractionComposition D E F s r t q h k).2

theorem iso_split (D E : DIDomainObject.{u}) (e : D ≃o E) :
    HasStableRetraction D E := by
  refine ⟨OrderIsoTransport.stableHom D E e,
    OrderIsoTransport.stableHom E D e.symm, ?_⟩
  intro x
  exact e.symm_apply_apply x

theorem exponential_split (H E F : CountablyBasedDIDomain.{u})
    (hEF : HasStableRetraction (Core E) (Core F)) :
    HasStableRetraction (Core (exponential H E)) (Core (exponential H F)) := by
  obtain ⟨s,r,h⟩ := hEF
  have hmaps := Section02.retractionExponential (Core H) (Core E) (Core H) (Core F)
    (StableHom.id _) (StableHom.id _) s r (fun _ => rfl) h
  exact ⟨StableHom.ofFunction _ hmaps.1,
    StableHom.ofFunction _ hmaps.2.1, hmaps.2.2⟩

theorem retraction_comparison : ComparisonRetractionStatement.{u} := by
  intro D E h
  let H : CountablyBasedDIDomain.{u} := FlatPowerRetraction.unit
  refine ⟨H, FlatPowerRetraction.unit_two_coherent, split_trans h ?_⟩
  exact ⟨FunctionDegreeHelpers.constantEmbedding H E,
    FunctionDegreeHelpers.evaluationAt H E FlatPowerRetraction.star, fun _ => rfl⟩

theorem split_comparison {D E F : CountablyBasedDIDomain.{u}}
    (hDE : HasStableRetraction (Core D) (Core E))
    (hEF : StableComparison E F) : StableComparison D F := by
  obtain ⟨H,hH,h⟩ := hEF
  exact ⟨H,hH,split_trans hDE h⟩

end DIDomainClassification.ComparisonOperations
