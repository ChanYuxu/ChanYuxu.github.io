import DIDomainClassification.Support.SpineRestriction

/-! Root-normalizing a literal branch-set map without the false inference
that the original function must preserve roots. The restricted target and
its rank bound are genuinely constructed OUTPUTS. -/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.BranchRankComparison

open Trees

variable {A : Type u} {B : Type v}

theorem values_comparable_root (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (x : S.Node) :
    (f x).val <+: (f S.root).val ∨ (f S.root).val <+: (f x).val := by
  obtain ⟨leaf, hleaf, hxleaf⟩ := FiniteLeafColourPruning.exists_leaf_extension S hS x
  obtain ⟨target, htarget, himage⟩ :=
    (mapsFiniteCompleteBranches_iff_leaves S T f).mp hf leaf hleaf
  have hx : f x ∈ T.pathTo target := by
    rw [← himage]
    exact ⟨x, hxleaf, rfl⟩
  have hr : f S.root ∈ T.pathTo target := by
    rw [← himage]
    exact ⟨S.root, S.root_prefix leaf.property, rfl⟩
  exact List.prefix_or_prefix_of_prefix hx hr

def liftedMap (S : RootedPrefixTree A) (hS : S.IsWellFounded) (T : RootedPrefixTree B)
    (f : S.Node → T.Node) (hf : MapsFiniteCompleteBranches S T f) (x : S.Node) :
    (spineTree T (f S.root)).Node :=
  ⟨(f x).val, (f x).property, values_comparable_root S hS T f hf x⟩

theorem liftedMap_val (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (x : S.Node) :
    (liftedMap S hS T f hf x).val = (f x).val := rfl

theorem spineMap_liftedMap (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (x : S.Node) :
    spineMap T (f S.root) (liftedMap S hS T f hf x) = f x := rfl

theorem liftedMap_root (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) :
    liftedMap S hS T f hf S.root = spinePivot T (f S.root) := rfl

theorem liftedMap_maps_branches (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) :
    MapsFiniteCompleteBranches S (spineTree T (f S.root)) (liftedMap S hS T f hf) := by
  rintro c ⟨leaf, hleaf, rfl⟩
  obtain ⟨target, htarget, himage⟩ :=
    (mapsFiniteCompleteBranches_iff_leaves S T f).mp hf leaf hleaf
  have hroot : (f S.root).val <+: target.val := by
    have hmem : f S.root ∈ T.pathTo target := by
      rw [← himage]
      exact ⟨S.root, S.root_prefix leaf.property, rfl⟩
    exact hmem
  let target' : (spineTree T (f S.root)).Node := ⟨target.val, target.property, Or.inr hroot⟩
  refine ⟨target', spine_original_leaf_isLeaf T (f S.root) target' htarget, ?_⟩
  ext x
  constructor
  · rintro ⟨s, hs, rfl⟩
    have hmem : f s ∈ T.pathTo target := by
      rw [← himage]
      exact ⟨s, hs, rfl⟩
    exact hmem
  · intro hx
    have hmem : spineMap T (f S.root) x ∈ T.pathTo target := hx
    rw [← himage] at hmem
    obtain ⟨s, hs, heq⟩ := hmem
    exact ⟨s, hs, Subtype.ext (congrArg (fun z : T.Node => z.val) heq)⟩

theorem liftedMap_injective_branches (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f) :
    InjectiveOnBranches S (spineTree T (f S.root)) (liftedMap S hS T f hf) := by
  intro c hc x hx y hy heq
  exact hinj c hc hx hy (congrArg (spineMap T (f S.root)) heq)

def normalizedRootMap (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (x : S.Node) :
    (spineTree T (f S.root)).Node :=
  spineSwap T (f S.root) (liftedMap S hS T f hf x)

theorem normalizedRootMap_root (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) :
    normalizedRootMap S hS T f hf S.root = (spineTree T (f S.root)).root := by
  exact spineSwap_pivot T (f S.root)

theorem normalizedRootMap_maps_branches (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) :
    MapsFiniteCompleteBranches S (spineTree T (f S.root)) (normalizedRootMap S hS T f hf) := by
  intro c hc
  have hbranch := liftedMap_maps_branches S hS T f hf c hc
  change (spineTree T (f S.root)).IsFiniteCompleteBranch
    ((spineSwap T (f S.root) ∘ liftedMap S hS T f hf) '' c)
  have himage : (spineSwap T (f S.root) ∘ liftedMap S hS T f hf) '' c =
      spineSwap T (f S.root) '' (liftedMap S hS T f hf '' c) :=
    (Set.image_image (spineSwap T (f S.root)) (liftedMap S hS T f hf) c).symm
  rw [himage, spineSwap_image_completeBranch T (f S.root) _ hbranch]
  exact hbranch

theorem normalizedRootMap_injective_branches (S : RootedPrefixTree A)
    (hS : S.IsWellFounded) (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f) :
    InjectiveOnBranches S (spineTree T (f S.root)) (normalizedRootMap S hS T f hf) := by
  intro c hc x hx y hy heq
  exact liftedMap_injective_branches S hS T f hf hinj c hc hx hy
    ((spineSwap T (f S.root)).injective heq)

/-- Root preservation and a rank-monotone target refinement are OUTPUTS.
Neither the old map's root preservation nor the desired source rank bound
is assumed, and singleton source/target trees are allowed. -/
theorem root_normalization (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (hT : T.IsWellFounded) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f) :
    ∃ (Q : RootedPrefixTree B) (hQ : Q.IsWellFounded) (g : S.Node → Q.Node),
      g S.root = Q.root ∧ MapsFiniteCompleteBranches S Q g ∧ InjectiveOnBranches S Q g ∧
      Q.treeRank hQ ≤ T.treeRank hT :=
  ⟨spineTree T (f S.root), spineTree_isWellFounded T (f S.root) hT,
    normalizedRootMap S hS T f hf, normalizedRootMap_root S hS T f hf,
    normalizedRootMap_maps_branches S hS T f hf,
    normalizedRootMap_injective_branches S hS T f hf hinj,
    spineTree_treeRank_le T (f S.root) hT⟩

end DIDomainClassification.BranchRankComparison

