import DIDomainClassification.Support.RootNormalization

/-! Geometry of root-normalized branch-SET maps. The image of a source child
need NOT itself be a target child: select the first target child on its path.
No order preservation, target WF or source properness is assumed here. -/

set_option autoImplicit false

universe u v

noncomputable section

namespace DIDomainClassification.BranchRankComparison

open Trees

variable {A : Type u} {B : Type v}

theorem child_ne_root (S : RootedPrefixTree A) {c : S.Node}
    (hc : S.IsChild S.root c) : c ≠ S.root := by
  intro heq
  exact S.isChild_irrefl S.root (heq ▸ hc)

theorem one_le_depth_of_ne_root (T : RootedPrefixTree B) (x : T.Node)
    (hx : x ≠ T.root) : 1 ≤ T.depth x := by
  have hn : T.depth x ≠ 0 := fun h => hx ((T.depth_eq_zero_iff x).mp h)
  omega

def firstChild (T : RootedPrefixTree B) (x : T.Node) : T.Node := T.prefixAt x 1

theorem firstChild_le (T : RootedPrefixTree B) (x : T.Node) :
    (firstChild T x).val <+: x.val := T.prefixAt_le x 1

theorem firstChild_isChild (T : RootedPrefixTree B) (x : T.Node) (hx : x ≠ T.root) :
    T.IsChild T.root (firstChild T x) := by
  refine ⟨T.root_prefix (firstChild T x).property, ?_⟩
  have h := T.depth_prefixAt x (n := 1) (one_le_depth_of_ne_root T x hx)
  simpa only [firstChild, T.depth_root, zero_add] using h

theorem root_children_eq_of_common_extension (T : RootedPrefixTree B)
    {c d z : T.Node} (hc : T.IsChild T.root c) (hd : T.IsChild T.root d)
    (hcz : c.val <+: z.val) (hdz : d.val <+: z.val) : c = d := by
  have hdc : T.depth c = 1 := by simpa only [T.depth_root, zero_add] using hc.2
  have hdd : T.depth d = 1 := by simpa only [T.depth_root, zero_add] using hd.2
  rcases List.prefix_or_prefix_of_prefix hcz hdz with hcd | hdc'
  · exact T.eq_of_le_of_depth_eq hcd (hdc.trans hdd.symm)
  · exact (T.eq_of_le_of_depth_eq hdc' (hdd.trans hdc.symm)).symm

theorem above_rootChild_ne_root (S : RootedPrefixTree A) {c : S.Node}
    (hc : S.IsChild S.root c) (x : (TreeGrafting.above S c).Node) :
    TreeGrafting.aboveNodeMap S c x ≠ S.root := by
  intro heq
  have hdc : S.depth c = 1 := by simpa only [S.depth_root, zero_add] using hc.2
  have hle := S.depth_mono (show c.val <+: (TreeGrafting.aboveNodeMap S c x).val from x.property.2)
  rw [heq, S.depth_root] at hle
  omega

theorem map_ne_root (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hinj : InjectiveOnBranches S T f) (hroot : f S.root = T.root)
    (x : S.Node) (hx : x ≠ S.root) : f x ≠ T.root := by
  intro hfx
  obtain ⟨leaf, hleaf, hxleaf⟩ := FiniteLeafColourPruning.exists_leaf_extension S hS x
  have hinj' := injectiveOnBranches_path S T f hinj leaf hleaf
  exact hx (hinj' hxleaf (S.root_prefix leaf.property) (hfx.trans hroot.symm))

theorem images_common_leaf (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (x y : S.Node) (hxy : x.val <+: y.val) :
    ∃ leaf : T.Node, T.IsLeaf leaf ∧ (f x).val <+: leaf.val ∧ (f y).val <+: leaf.val := by
  obtain ⟨sourceLeaf, hleaf, hyleaf⟩ := FiniteLeafColourPruning.exists_leaf_extension S hS y
  obtain ⟨target, htarget, himage⟩ :=
    (mapsFiniteCompleteBranches_iff_leaves S T f).mp hf sourceLeaf hleaf
  have hx : f x ∈ T.pathTo target := by
    rw [← himage]
    exact ⟨x, hxy.trans hyleaf, rfl⟩
  have hy : f y ∈ T.pathTo target := by
    rw [← himage]
    exact ⟨y, hyleaf, rfl⟩
  exact ⟨target, htarget, hx, hy⟩

theorem firstChild_prefix_image_of_descendant (S : RootedPrefixTree A)
    (hS : S.IsWellFounded) (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f)
    (hroot : f S.root = T.root) {c : S.Node} (hc : S.IsChild S.root c)
    (x : (TreeGrafting.above S c).Node) :
    (firstChild T (f c)).val <+: (f (TreeGrafting.aboveNodeMap S c x)).val := by
  let w := TreeGrafting.aboveNodeMap S c x
  have hfc := map_ne_root S hS T f hinj hroot c (child_ne_root S hc)
  have hfw := map_ne_root S hS T f hinj hroot w (above_rootChild_ne_root S hc x)
  obtain ⟨leaf, hleaf, hcleaf, hwleaf⟩ := images_common_leaf S hS T f hf c w x.property.2
  have heq : firstChild T (f c) = firstChild T (f w) :=
    root_children_eq_of_common_extension T (firstChild_isChild T (f c) hfc)
      (firstChild_isChild T (f w) hfw)
      ((firstChild_le T (f c)).trans hcleaf) ((firstChild_le T (f w)).trans hwleaf)
  rw [heq]
  exact firstChild_le T (f w)

def childMap (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f)
    (hroot : f S.root = T.root) (c : S.Node) (hc : S.IsChild S.root c)
    (x : (TreeGrafting.above S c).Node) : (TreeGrafting.above T (firstChild T (f c))).Node :=
  ⟨(f (TreeGrafting.aboveNodeMap S c x)).val,
    (f (TreeGrafting.aboveNodeMap S c x)).property,
    firstChild_prefix_image_of_descendant S hS T f hf hinj hroot hc x⟩

theorem childMap_formula (S : RootedPrefixTree A) (hS : S.IsWellFounded)
    (T : RootedPrefixTree B) (f : S.Node → T.Node)
    (hf : MapsFiniteCompleteBranches S T f) (hinj : InjectiveOnBranches S T f)
    (hroot : f S.root = T.root) (c : S.Node) (hc : S.IsChild S.root c)
    (x : (TreeGrafting.above S c).Node) :
    TreeGrafting.aboveNodeMap T (firstChild T (f c)) (childMap S hS T f hf hinj hroot c hc x) =
      f (TreeGrafting.aboveNodeMap S c x) := rfl

end DIDomainClassification.BranchRankComparison

