import DIDomainClassification.Section02.RankDegree
import Mathlib.Data.List.Basic

/-! Finite single-branch trees, with the actual prefix order and rank. -/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.FiniteChainTrees

open Trees CoherenceDegree

def tree (n : ℕ) : RootedPrefixTree PUnit.{u + 1} where
  nodes := {l | l.length ≤ n}
  rootList := []
  root_mem := Nat.zero_le n
  root_prefix _ := List.nil_prefix
  prefix_closed _ hvw hw := hvw.length_le.trans hw
  countable_nodes := Set.to_countable _

abbrev node (n i : ℕ) (hi : i ≤ n) : (tree.{u} n).Node :=
  ⟨List.replicate i PUnit.unit, by
    change (List.replicate i PUnit.unit).length ≤ n
    simpa using hi⟩

theorem node_length (n i : ℕ) (hi : i ≤ n) :
    (node.{u} n i hi).val.length = i := List.length_replicate

theorem node_val_eq (n : ℕ) (v : (tree.{u} n).Node) :
    v.val = List.replicate v.val.length PUnit.unit :=
  List.eq_replicate_length.mpr (fun _ _ => Subsingleton.elim _ _)

theorem node_eq_of_length_eq (n : ℕ) (v w : (tree.{u} n).Node)
    (h : v.val.length = w.val.length) : v = w :=
  Subtype.ext (List.length_injective h)

theorem prefix_iff_length_le (n : ℕ) (v w : (tree.{u} n).Node) :
    v.val <+: w.val ↔ v.val.length ≤ w.val.length := by
  constructor
  · exact List.IsPrefix.length_le
  · intro h
    have heq : w.val.take v.val.length = v.val :=
      List.length_injective (by simp only [List.length_take, Nat.min_eq_left h])
    rw [← heq]
    exact List.take_prefix _ _

theorem node_le_iff (n : ℕ) (v w : (tree.{u} n).Node) :
    @LE.le (tree.{u} n).Node (prefixNodeOrder (tree n)).toLE v w ↔
      v.val.length ≤ w.val.length := prefix_iff_length_le n v w

theorem leaf (n : ℕ) : (tree.{u} n).IsLeaf (node n n le_rfl) := by
  intro w hw
  apply node_eq_of_length_eq n
  have hwn : w.val.length ≤ n := w.property
  have hnw : n ≤ w.val.length := by simpa only [node, List.length_replicate] using hw.length_le
  simpa only [node, List.length_replicate] using Nat.le_antisymm hwn hnw

theorem le_leaf (n : ℕ) (v : (tree.{u} n).Node) :
    @LE.le (tree.{u} n).Node (prefixNodeOrder (tree n)).toLE v (node n n le_rfl) := by
  apply (node_le_iff n _ _).mpr
  have hv : v.val.length ≤ n := v.property
  simpa only [node, List.length_replicate] using hv

theorem proper (n : ℕ) (hn : 0 < n) : (tree.{u} n).IsProper := by
  apply (tree n).isProper_iff.mpr
  refine ⟨⟨⟨node n 0 (Nat.zero_le n), node n n le_rfl, ?_⟩⟩, ?_⟩
  · intro h
    have hlen := congrArg (fun v : (tree.{u} n).Node => v.val.length) h
    simp only [node, List.length_replicate] at hlen
    omega
  · intro v
    exact ⟨node n n le_rfl, leaf n, le_leaf n v⟩

theorem depth_eq_length (n : ℕ) (v : (tree.{u} n).Node) :
    (tree n).depth v = v.val.length := by
  simp [RootedPrefixTree.depth, tree]

theorem wellFounded (n : ℕ) : (tree.{u} n).IsWellFounded := by
  rintro ⟨b⟩
  have hle : (b.node (n + 1)).val.length ≤ n := (b.node (n + 1)).property
  rw [← depth_eq_length, b.depth_eq] at hle
  omega

theorem pathTo_leaf_eq_univ (n : ℕ) :
    (tree.{u} n).pathTo (node n n le_rfl) = Set.univ := by
  ext v
  exact iff_true_intro ((tree n).mem_pathTo _ _ |>.mpr (le_leaf n v))

theorem rank_at_node (n : ℕ) (v : (tree.{u} n).Node) :
    (tree n).nodeRank (wellFounded n) v = ((n - v.val.length : ℕ) : Ordinal.{u}) := by
  generalize hm : n - v.val.length = m
  induction m using Nat.strong_induction_on generalizing v with
  | h m ih =>
    by_cases hv : v.val.length = n
    · have hleaf : (tree n).IsLeaf v := by
        intro w hw
        apply node_eq_of_length_eq n
        have hwn : w.val.length ≤ n := w.property
        exact Nat.le_antisymm (by omega) hw.length_le
      rw [(tree n).nodeRank_leaf (wellFounded n) v hleaf]
      have hm0 : m = 0 := by omega
      simp only [hm0, Nat.cast_zero]
    · have hvn : v.val.length < n := lt_of_le_of_ne v.property hv
      have hvalues (y : {y : (tree.{u} n).Node // (tree n).IsChild v y}) :
          (tree n).nodeRank (wellFounded n) y.val + 1 = (m : Ordinal.{u}) := by
        have hlen : y.val.val.length = v.val.length + 1 := by
          simpa only [depth_eq_length] using y.property.2
        have hlt : n - y.val.val.length < m := by omega
        rw [ih (n - y.val.val.length) hlt y.val rfl]
        have heq : n - y.val.val.length + 1 = m := by omega
        calc
          ((n - y.val.val.length : ℕ) : Ordinal.{u}) + 1 =
              ((n - y.val.val.length + 1 : ℕ) : Ordinal.{u}) := by
                simp only [Nat.cast_add, Nat.cast_one]
          _ = (m : Ordinal.{u}) := congrArg (fun k : ℕ => (k : Ordinal.{u})) heq
      let w := node.{u} n (v.val.length + 1) hvn
      have hchild : (tree n).IsChild v w := by
        constructor
        · apply (node_le_iff n _ _).mpr
          simp only [w, node, List.length_replicate]
          exact Nat.le_succ _
        · simp only [depth_eq_length, w, node, List.length_replicate]
      rw [(tree n).nodeRank_eq]
      apply le_antisymm
      · exact Ordinal.iSup_le (fun y => (hvalues y).le)
      · exact (hvalues ⟨w, hchild⟩).symm.le.trans
          (Ordinal.le_iSup (fun y : {y : (tree.{u} n).Node // (tree n).IsChild v y} =>
            (tree n).nodeRank (wellFounded n) y.val + 1) ⟨w, hchild⟩)

theorem treeRank_eq (n : ℕ) :
    (tree.{u} n).treeRank (wellFounded n) = (n : Ordinal.{u}) := by
  simpa only [RootedPrefixTree.treeRank, RootedPrefixTree.root, tree,
    List.length_nil, Nat.sub_zero] using rank_at_node n (tree n).root

end DIDomainClassification.FiniteChainTrees
