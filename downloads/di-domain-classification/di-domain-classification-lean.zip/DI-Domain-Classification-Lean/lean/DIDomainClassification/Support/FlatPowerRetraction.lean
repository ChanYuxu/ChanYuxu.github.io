import DIDomainClassification.Support.SeparatedSumHomOperations
import DIDomainClassification.Support.OrderIsoTransport

/-! The literal flat natural-number specialization of the separated sum. -/
set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.FlatPowerRetraction
open OrderCore Preliminaries CoherenceDegree
open Section03.StableFunctionModels Section04.AdditionalSourceModels
open Section04.SeparatedSumModels SeparatedSumOrder SeparatedSumDomain
open SeparatedSumFunctions SeparatedSumHomOperations

def unit : CountablyBasedDIDomain.{u} :=
  Section02.StableBackground.terminalObject trueClosure

def star : Core unit.{u} := PUnit.unit
def unitFamily : ℕ → CountablyBasedDIDomain.{u} := fun _ => unit

local instance unitSubsingleton : Subsingleton (Core unit.{u}) := by
  change Subsingleton PUnit.{u + 1}
  infer_instance

local instance unitFamilySubsingleton (n : ℕ) :
    Subsingleton (Core (unitFamily.{u} n)) := unitSubsingleton

def toFlat : Carrier unitFamily.{u} → FlatCarrier.{u}
  | none => ⟨BasicDomains.FlatNat.bot⟩
  | some x => ⟨BasicDomains.FlatNat.nat x.1⟩

def fromFlat (x : FlatCarrier.{u}) : Carrier unitFamily.{u} :=
  match x.down with
  | BasicDomains.FlatNat.bot => none
  | BasicDomains.FlatNat.nat n => some ⟨n, star⟩

def flatOrderIso : Carrier unitFamily.{u} ≃o FlatCarrier.{u} where
  toFun := toFlat
  invFun := fromFlat
  left_inv x := by
    cases x with
    | none => rfl
    | some q =>
      rcases q with ⟨n, p⟩
      have hp : p = star := Subsingleton.elim _ _
      cases hp
      rfl
  right_inv x := by
    rcases x with ⟨x⟩
    cases x <;> rfl
  map_rel_iff' := by
    intro x y
    cases x with
    | none =>
      constructor
      · intro _; exact bot_le
      · intro _; exact Or.inl rfl
    | some p =>
      rcases p with ⟨n, a⟩
      cases y with
      | none =>
        exact iff_of_false (BasicDomains.FlatNat.nat_not_le_bot n)
          (WithBot.not_coe_le_bot _)
      | some q =>
        rcases q with ⟨m, b⟩
        change BasicDomains.FlatNat.nat n ≤ BasicDomains.FlatNat.nat m ↔
          ((⟨n,a⟩ : Σ i, Core (unitFamily.{u} i)) :
            WithBot (Σ i, Core (unitFamily.{u} i))) ≤
          ((⟨m,b⟩ : Σ i, Core (unitFamily.{u} i)) :
            WithBot (Σ i, Core (unitFamily.{u} i)))
        rw [WithBot.coe_le_coe, BasicDomains.FlatNat.nat_le_nat_iff, Sigma.le_def]
        constructor
        · intro h
          subst m
          exact ⟨rfl, (Subsingleton.elim _ _).le⟩
        · rintro ⟨h, _⟩
          exact h

def flat_countablyBased : IsCountablyBasedDIDomain FlatCarrier.{u} :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff flatOrderIso).mp
    (sum_countablyBased unitFamily.{u})

def flatCore : DIDomainObject.{u} :=
  (flatObject flat_countablyBased).toDIDomainObject

theorem coherent_map {D F : Type u} [PartialOrder D] [PartialOrder F]
    (e : D ≃o F) (hD : IsScottDomain D) (hF : IsScottDomain F)
    (hC : IsNCoherent hD 2 (by decide)) : IsNCoherent hF 2 (by decide) := by
  apply (coherenceCharacterization F hF 2 (by decide)).mpr
  intro X hX
  have hB : BddAbove (e.symm '' X) := by
    apply (coherenceCharacterization D hD 2 (by decide)).mp hC
    intro A hAX hA hcard
    have hsub : e '' A ⊆ X := by
      rintro _ ⟨a, ha, rfl⟩
      obtain ⟨x, hx, hxa⟩ := hAX ha
      simpa only [← hxa, e.apply_symm_apply] using hx
    have hc : (e '' A).ncard = A.ncard := Set.ncard_image_of_injective A e.injective
    have hbound := hX (e '' A) hsub (hA.image e) (hc.le.trans hcard)
    exact (OrderIsoTransport.bddAbove_image_iff e A).mp hbound
  exact (OrderIsoTransport.bddAbove_image_iff e.symm X).mp hB

theorem unit_two_coherent :
    IsNCoherent (Core unit.{u}).isDIDomain.toIsScottDomain 2 (by decide) := by
  intro M hM
  exact False.elim (hM.2.1 ⟨star, fun x _ => (Subsingleton.elim x star).le⟩)

theorem flat_two_coherent :
    IsNCoherent flat_countablyBased.{u}.1.toIsScottDomain 2 (by decide) :=
  coherent_map flatOrderIso (scott unitFamily.{u}) flat_countablyBased.1.toIsScottDomain
    (sum_two_coherent unitFamily.{u} (fun _ => unit_two_coherent))

def constantHom (E : CountablyBasedDIDomain.{u}) (x : Core E) :
    StableHom (Core unit) (Core E) :=
  StableHom.ofFunction (fun _ => x) ⟨ScottContinuous.const x, fun _ _ _ => (inf_idem _).symm⟩

def powerOrderIso (E : CountablyBasedDIDomain.{u}) :
    familyCore unitFamily.{u} E ≃o (ℕ → Core E) where
  toFun f n := f n star
  invFun f n := constantHom E (f n)
  left_inv f := by
    funext n
    apply StableHom.ext
    intro x
    have hx : x = star := Subsingleton.elim _ _
    cases hx
    rfl
  right_inv f := by funext n; rfl
  map_rel_iff' := by
    intro f g
    change (∀ n, f n star ≤ g n star) ↔ (∀ n, f n ≤ g n)
    constructor
    · intro h n x y _hxy
      have hx : x = star := Subsingleton.elim _ _
      have hy : y = star := Subsingleton.elim _ _
      cases hx
      cases hy
      exact (inf_eq_left.mpr (h n)).symm
    · intro h n
      exact (h n star star le_rfl).trans_le inf_le_right

def power_countablyBased (E : CountablyBasedDIDomain.{u}) :
    IsCountablyBasedDIDomain (ℕ → Core E) :=
  (OrderIsoTransport.isCountablyBasedDIDomain_iff (powerOrderIso E)).mp
    (family_countablyBased unitFamily.{u} E)

def powerCore (E : CountablyBasedDIDomain.{u}) : DIDomainObject.{u} :=
  (cbObject (ℕ → Core E) (power_countablyBased E)).toDIDomainObject

def inputOrderIso (D F G : DIDomainObject.{u}) (e : D ≃o F) :
    StableHom D G ≃o StableHom F G where
  toFun f := StableHom.comp f (OrderIsoTransport.stableHom F D e.symm)
  invFun f := StableHom.comp f (OrderIsoTransport.stableHom D F e)
  left_inv f := StableHom.ext (fun x => congrArg f (e.symm_apply_apply x))
  right_inv f := StableHom.ext (fun x => congrArg f (e.apply_symm_apply x))
  map_rel_iff' := by
    intro f g
    change (StableHom.comp f (OrderIsoTransport.stableHom F D e.symm) ≤
      StableHom.comp g (OrderIsoTransport.stableHom F D e.symm)) ↔ f ≤ g
    constructor
    · intro h x y hxy
      have hh := h (e x) (e y) (e.monotone hxy)
      change f (e.symm (e x)) = f (e.symm (e y)) ⊓ g (e.symm (e x)) at hh
      simpa only [e.symm_apply_apply] using hh
    · intro h x y hxy
      change f (e.symm x) = f (e.symm y) ⊓ g (e.symm x)
      exact h (e.symm x) (e.symm y) (e.symm.monotone hxy)

def reindexOrderIso (E : CountablyBasedDIDomain.{u}) :
    targetCore unitFamily.{u} E ≃o functionCore flatCore (Core E) :=
  inputOrderIso (sumCore unitFamily.{u}) flatCore (Core E) flatOrderIso

def powerSection (E : CountablyBasedDIDomain.{u}) :
    StableHom (powerCore E) (functionCore flatCore (Core E)) :=
  StableHom.comp
    (OrderIsoTransport.stableHom (targetCore unitFamily.{u} E)
      (functionCore flatCore (Core E)) (reindexOrderIso E))
    (StableHom.comp (sectionMap unitFamily.{u} E)
      (OrderIsoTransport.stableHom (powerCore E) (familyCore unitFamily.{u} E)
        (powerOrderIso E).symm))

def retraction (E : CountablyBasedDIDomain.{u}) :
    StableHom (functionCore flatCore (Core E)) (powerCore E) :=
  StableHom.comp
    (OrderIsoTransport.stableHom (familyCore unitFamily.{u} E) (powerCore E)
      (powerOrderIso E))
    (StableHom.comp (restrictionMap unitFamily.{u} E)
      (OrderIsoTransport.stableHom (functionCore flatCore (Core E))
        (targetCore unitFamily.{u} E) (reindexOrderIso E).symm))

theorem section_apply (E : CountablyBasedDIDomain.{u}) (f : ℕ → Core E)
    (x : FlatCarrier.{u}) :
    functionValue flatCore (Core E) (powerSection E f) x = flatSectionValues E f x := by
  rcases x with ⟨x⟩
  cases x <;> rfl

theorem retraction_apply (E : CountablyBasedDIDomain.{u})
    (g : functionCore flatCore (Core E)) (n : ℕ) :
    retraction E g n = functionValue flatCore (Core E) g
      (ULift.up (BasicDomains.FlatNat.nat n)) := rfl

theorem leftInverse (E : CountablyBasedDIDomain.{u}) :
    Function.LeftInverse (retraction E : functionCore flatCore (Core E) → powerCore E)
      (powerSection E : powerCore E → functionCore flatCore (Core E)) := by
  intro f
  funext n
  rw [retraction_apply, section_apply]
  rfl

end DIDomainClassification.FlatPowerRetraction
