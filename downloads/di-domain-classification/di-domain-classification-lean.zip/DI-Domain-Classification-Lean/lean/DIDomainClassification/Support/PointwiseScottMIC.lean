import DIDomainClassification.Support.PointwiseScottClosure
import DIDomainClassification.Support.FiniteConsistency

/-!
Raw Scott-function supporting mathematics. In particular, the finite-set
auxiliary iff printed in BPS Proposition 4.5 requires care when output labels
repeat. We prove the forward MIC criterion INCLUDING output injectivity; no
false converse for repeated output labels is asserted.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.PointwiseFunctionSupport

open OrderCore Preliminaries CoherenceDegree

variable {D : Type u} {E : Type v} [PartialOrder D] [PartialOrder E]

theorem const_scottContinuous : ScottContinuous (const : E → Space D E) := by
  intro A _hA _hdir s hs
  constructor
  · rintro _ ⟨a, ha, rfl⟩ x
    exact hs.1 ha
  · intro f hf x
    apply hs.2
    intro a ha
    exact hf ⟨a, ha, rfl⟩ x

theorem eval_scottContinuous (hE : OrderCore.IsDcpo E) (x : D) :
    ScottContinuous (fun f : Space D E => f.val x) := by
  intro A hA hdir f hf
  exact (directed_isLUB_iff_values hE ⟨hA, hdir⟩ f).1 hf x

/-- Lower degree bound by the actual constant/evaluation Scott split. This
uses the proved generic compact-lift construction, not a source BPS premise. -/
theorem codomain_coherenceDegree_le {D E : Type u} [PartialOrder D] [PartialOrder E]
    [Nonempty D] (hD : IsScottDomain D)
    (hE : IsScottDomain E) :
    coherenceDegree hE ≤ coherenceDegree (space_isScottDomain hD hE) := by
  let x : D := Classical.choice inferInstance
  exact coherenceDegree_mono_of_scott_split hE (space_isScottDomain hD hE)
    const_scottContinuous (eval_scottContinuous hE.algebraic.1 x) (fun _ => rfl)

def inputs (S : Set (StepIndex D E)) : Set D := (fun i => i.1.val) '' S

def outputs (S : Set (StepIndex D E)) : Set E := (fun i => i.2.val) '' S

/-- At a common upper input, a bound for the actual step functions bounds all
their output labels. This direction needs no finiteness or injectivity. -/
theorem outputs_bddAbove_of_steps (hE : IsScottDomain E)
    {S : Set (StepIndex D E)} (hinput : BddAbove (inputs S))
    (hsteps : BddAbove (stepOf hE '' S)) : BddAbove (outputs S) := by
  classical
  obtain ⟨x, hx⟩ := hinput
  obtain ⟨f, hf⟩ := hsteps
  refine ⟨f.val x, ?_⟩
  rintro _ ⟨i, hi, rfl⟩
  have hix : i.1.val ≤ x := hx ⟨i, hi, rfl⟩
  have h := hf ⟨i, hi, rfl⟩ x
  simpa only [stepOf, step_apply, if_pos hix] using h

/-- Full step-family boundedness criterion, valid even for infinite families.
It quantifies all subfamilies with a common upper input. -/
theorem steps_bddAbove_iff (hE : IsScottDomain E) (S : Set (StepIndex D E)) :
    BddAbove (stepOf hE '' S) ↔
      ∀ J : Set (StepIndex D E), J ⊆ S →
        BddAbove (inputs J) → BddAbove (outputs J) := by
  classical
  constructor
  · intro h J hJ hinputs
    exact outputs_bddAbove_of_steps hE hinputs (h.mono (Set.image_mono hJ))
  · intro h
    have hvals (x : D) : BddAbove (values (stepOf hE '' S) x) := by
      let J : Set (StepIndex D E) := {i | i ∈ S ∧ i.1.val ≤ x}
      have hJinput : BddAbove (inputs J) := by
        refine ⟨x, ?_⟩
        rintro _ ⟨i, hi, rfl⟩
        exact hi.2
      obtain ⟨z, hz⟩ := h J (fun _ hi => hi.1) hJinput
      refine ⟨z, ?_⟩
      rintro y ⟨_, ⟨i, hi, rfl⟩, rfl⟩
      change (stepOf hE i).val x ≤ z
      rw [stepOf, step_apply]
      split_ifs with hix
      · exact hz ⟨i, ⟨hi, hix⟩, rfl⟩
      · exact hE.bottom_le z
    choose F hF using fun x => hE.boundedSuprema _ (hvals x)
    exact ⟨ofPointwiseIsLUB F hF, (ofPointwiseIsLUB_isLUB F hF).1⟩

theorem steps_unbounded_witness (hE : IsScottDomain E) (S : Set (StepIndex D E))
    (hbad : ¬ BddAbove (stepOf hE '' S)) :
    ∃ J : Set (StepIndex D E), J ⊆ S ∧
      BddAbove (inputs J) ∧ ¬ BddAbove (outputs J) := by
  classical
  have h : ¬ ∀ J : Set (StepIndex D E), J ⊆ S →
      BddAbove (inputs J) → BddAbove (outputs J) :=
    fun h => hbad ((steps_bddAbove_iff hE S).2 h)
  push Not at h
  exact h

/-- The usable forward direction of the printed step MIC criterion. Injective
step presentations represent a SET of distinct functions, not a multiset. -/
theorem step_mic_inputs_outputs (hD : IsScottDomain D) (hE : IsScottDomain E)
    (S : Set (StepIndex D E)) (hfin : S.Finite)
    (hinj : Set.InjOn (stepOf hE) S)
    (hM : IsMinimallyInconsistent (space_isScottDomain hD hE) (stepOf hE '' S)) :
    BddAbove (inputs S) ∧ IsMinimallyInconsistent hE (outputs S) := by
  classical
  obtain ⟨J, hJS, hJinput, hJbad⟩ := steps_unbounded_witness hE S hM.2.1
  have hJstepsbad : ¬ BddAbove (stepOf hE '' J) :=
    fun h => hJbad (outputs_bddAbove_of_steps hE hJinput h)
  have hImages : stepOf hE '' J = stepOf hE '' S := by
    apply Set.Subset.antisymm (Set.image_mono hJS)
    by_contra hnot
    exact hJstepsbad (hM.2.2 _ ⟨Set.image_mono hJS, hnot⟩)
  have hSJ : S ⊆ J := by
    intro i hi
    obtain ⟨j, hj, heq⟩ := hImages.symm.subset ⟨i, hi, rfl⟩
    have hji : j = i := hinj (hJS hj) hi heq
    simpa only [hji] using hj
  have hJS_eq : J = S := Set.Subset.antisymm hJS hSJ
  subst J
  refine ⟨hJinput, hfin.image _, hJbad, ?_⟩
  intro N hN
  let P : Set (StepIndex D E) := {i | i ∈ S ∧ i.2.val ∈ N}
  have hPS : P ⊆ S := fun _ hi => hi.1
  have houtP : outputs P = N := by
    ext b
    constructor
    · rintro ⟨i, hi, rfl⟩
      exact hi.2
    · intro hb
      obtain ⟨i, hi, rfl⟩ := hN.1 hb
      exact ⟨i, ⟨hi, hb⟩, rfl⟩
  have hPproper : stepOf hE '' P ⊂ stepOf hE '' S := by
    refine ⟨Set.image_mono hPS, ?_⟩
    intro hback
    apply hN.2
    rintro b ⟨i, hi, rfl⟩
    obtain ⟨j, hj, heq⟩ := hback ⟨i, hi, rfl⟩
    have hji : j = i := hinj hj.1 hi heq
    simpa only [hji] using hj.2
  have hinputP : BddAbove (inputs P) := hJinput.mono (Set.image_mono hPS)
  simpa only [houtP] using outputs_bddAbove_of_steps hE hinputP (hM.2.2 _ hPproper)

/-- MIC minimality forces distinct output labels. This extra conclusion is
what makes same-tree relabelling into the codomain branch-injective. -/
theorem step_mic_outputs_injective (hD : IsScottDomain D) (hE : IsScottDomain E)
    (S : Set (StepIndex D E)) (hfin : S.Finite)
    (hinj : Set.InjOn (stepOf hE) S)
    (hM : IsMinimallyInconsistent (space_isScottDomain hD hE) (stepOf hE '' S)) :
    Set.InjOn (fun i : StepIndex D E => i.2.val) S := by
  classical
  obtain ⟨hinput, houtput⟩ := step_mic_inputs_outputs hD hE S hfin hinj hM
  intro i hi j hj hij
  by_contra hne
  let P : Set (StepIndex D E) := S \ {j}
  have hPS : P ⊆ S := fun _ hp => hp.1
  have hproper : stepOf hE '' P ⊂ stepOf hE '' S := by
    refine ⟨Set.image_mono hPS, ?_⟩
    intro hback
    obtain ⟨k, hk, heq⟩ := hback ⟨j, hj, rfl⟩
    have hkj : k = j := hinj hk.1 hj heq
    exact hk.2 (by simpa only [hkj] using Set.mem_singleton j)
  have hout : outputs S ⊆ outputs P := by
    rintro b ⟨k, hk, rfl⟩
    by_cases hkj : k = j
    · refine ⟨i, ⟨hi, ?_⟩, ?_⟩
      · simpa only [Set.mem_singleton_iff] using hne
      · simpa only [hkj] using hij
    · exact ⟨k, ⟨hk, by simpa only [Set.mem_singleton_iff] using hkj⟩, rfl⟩
  exact houtput.2.1 ((outputs_bddAbove_of_steps hE
    (hinput.mono (Set.image_mono hPS)) (hM.2.2 _ hproper)).mono hout)

def stepBasis (hE : IsScottDomain E) : Set (Space D E) := Set.range (stepOf hE)

/-- A finite join basis is formulated with genuine finite subsets and actual
suprema; the finite-join generation is a theorem, not stored in domain data. -/
def IsFiniteJoinBasis {P : Type u} [PartialOrder P] (B : Set P) : Prop :=
  B ⊆ CompactSet P ∧ ∀ k : P, Compact k →
    ∃ F : Set P, F.Finite ∧ F ⊆ B ∧ IsLUB F k

theorem stepBasis_isFiniteJoinBasis (hD : IsScottDomain D) (hE : IsScottDomain E) :
    IsFiniteJoinBasis (stepBasis (D := D) hE) := by
  constructor
  · rintro f ⟨i, rfl⟩
    exact stepOf_compact hE i
  · intro f hf
    obtain ⟨S, rfl⟩ := (compact_iff_finiteJoin hD hE f).1 hf
    exact ⟨stepOf hE '' S.val, S.property.1.image _,
      by rintro g ⟨i, _hi, rfl⟩; exact ⟨i, rfl⟩, finiteJoin_isLUB hE S⟩

/-- A representation for a MIC SET of basis functions. The representative map
is injective because its step functions are precisely the original functions.
The output map is injective by MIC minimality, not by choice of representatives.
-/
theorem stepBasis_mic_representation (hD : IsScottDomain D) (hE : IsScottDomain E)
    (M : Set (Space D E)) (hMB : M ⊆ stepBasis hE)
    (hM : IsMinimallyInconsistent (space_isScottDomain hD hE) M) :
    ∃ ρ : M → StepIndex D E,
      (∀ f : M, stepOf hE (ρ f) = f.val) ∧
      BddAbove (inputs (Set.range ρ)) ∧
      IsMinimallyInconsistent hE (outputs (Set.range ρ)) ∧
      Function.Injective (fun f : M => (ρ f).2.val) := by
  classical
  choose ρ hρ using fun f : M => hMB f.property
  let S : Set (StepIndex D E) := Set.range ρ
  have hfin : S.Finite := by
    letI : Finite M := hM.1.to_subtype
    exact Set.finite_range ρ
  have hstep : stepOf hE '' S = M := by
    ext f
    constructor
    · rintro ⟨_, ⟨g, rfl⟩, rfl⟩
      simpa only [hρ g] using g.property
    · intro hf
      exact ⟨ρ ⟨f, hf⟩, ⟨⟨f, hf⟩, rfl⟩, hρ ⟨f, hf⟩⟩
  have hinj : Set.InjOn (stepOf hE) S := by
    rintro _ ⟨f, rfl⟩ _ ⟨g, rfl⟩ hfg
    have hval : f.val = g.val := (hρ f).symm.trans (hfg.trans (hρ g))
    exact congrArg ρ (Subtype.ext hval)
  have hmic : IsMinimallyInconsistent (space_isScottDomain hD hE)
      (stepOf hE '' S) := by simpa only [hstep] using hM
  obtain ⟨hinput, houtput⟩ := step_mic_inputs_outputs hD hE S hfin hinj hmic
  have houtinj := step_mic_outputs_injective hD hE S hfin hinj hmic
  refine ⟨ρ, hρ, hinput, houtput, ?_⟩
  intro f g hfg
  have heq := houtinj (Set.mem_range_self f) (Set.mem_range_self g) hfg
  apply Subtype.ext
  exact (hρ f).symm.trans ((congrArg (stepOf hE) heq).trans (hρ g))

end DIDomainClassification.PointwiseFunctionSupport
