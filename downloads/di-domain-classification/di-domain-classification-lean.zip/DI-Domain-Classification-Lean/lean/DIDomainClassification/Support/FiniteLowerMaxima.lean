import DIDomainClassification.Section04.CausalConflicts
import Mathlib.Order.Preorder.Finite
import Mathlib.Order.UpperLower.Closure
import Mathlib.Data.Set.Finite.Lattice
import Mathlib.Data.Set.Finite.Powerset
import Mathlib.Data.Set.Card

/-!
Generic finite lower-set order support. The actual accepted event maximal-set
definition is bridged to Mathlib's Maximal predicate; downClosure is literal
lowerClosure, not the lower INTERIOR operation introduced in a separate file.
No source-facing CausalAntichainsStatement or causal retraction is proved here.
-/

set_option autoImplicit false

universe u

namespace DIDomainClassification.FiniteCausalConflicts

open EventStructures

variable {A : Type u} [PartialOrder A]

def downClosure (S : Set A) : Set A := lowerClosure S

theorem mem_downClosure {S : Set A} {a : A} :
    a ∈ downClosure S ↔ ∃ b ∈ S, a ≤ b := Iff.rfl

theorem subset_downClosure (S : Set A) : S ⊆ downClosure S :=
  fun a ha => ⟨a, ha, le_rfl⟩

theorem downClosure_isLower (S : Set A) : IsLowerSet (downClosure S) := by
  rintro a b hab ⟨c, hc, hbc⟩
  exact ⟨c, hc, hab.trans hbc⟩

theorem downClosure_mono {S T : Set A} (hST : S ⊆ T) :
    downClosure S ⊆ downClosure T := by
  rintro a ⟨b, hb, hab⟩
  exact ⟨b, hST hb, hab⟩

theorem downClosure_eq_of_lower {S : Set A} (hS : IsLowerSet S) :
    downClosure S = S := by
  apply Set.Subset.antisymm
  · rintro a ⟨b, hb, hab⟩
    exact hS hab hb
  · exact subset_downClosure S

theorem downClosure_eq_iUnion (S : Set A) :
    downClosure S = ⋃ a ∈ S, Set.Iic a := coe_lowerClosure S

theorem downClosure_finite {S : Set A} (hS : S.Finite)
    (hIic : ∀ a ∈ S, (Set.Iic a).Finite) : (downClosure S).Finite := by
  rw [downClosure_eq_iUnion]
  exact hS.biUnion hIic

theorem maximalEvents_iff_maximal {U : Set A} {a : A} :
    a ∈ maximalEvents U ↔ Maximal (· ∈ U) a := by
  constructor
  · rintro ⟨ha, hmax⟩
    refine ⟨ha, ?_⟩
    intro b hb hab
    exact (hmax b hb hab).le
  · rintro ⟨ha, hmax⟩
    refine ⟨ha, ?_⟩
    intro b hb hab
    exact le_antisymm (hmax hb hab) hab

theorem maximalEvents_subset (U : Set A) : maximalEvents U ⊆ U :=
  fun _ ha => ha.1

theorem maximalEvents_finite {U : Set A} (hU : U.Finite) :
    (maximalEvents U).Finite := hU.subset (maximalEvents_subset U)

theorem maximalEvents_isAntichain (U : Set A) :
    IsAntichain (· ≤ ·) (maximalEvents U) := by
  have heq : maximalEvents U = {a | Maximal (· ∈ U) a} :=
    Set.ext fun _ => maximalEvents_iff_maximal
  rw [heq]
  exact setOf_maximal_antichain (· ∈ U)

theorem finite_lower_eq_down_maximalEvents {U : Set A} (hU : U.Finite)
    (hLower : IsLowerSet U) : U = downClosure (maximalEvents U) := by
  apply Set.Subset.antisymm
  · intro a ha
    obtain ⟨b, hab, hb⟩ := hU.exists_le_maximal ha
    exact ⟨b, maximalEvents_iff_maximal.mpr hb, hab⟩
  · rintro a ⟨b, hb, hab⟩
    exact hLower hab hb.1

theorem maximalEvents_downClosure {S : Set A} (hS : IsAntichain (· ≤ ·) S) :
    maximalEvents (downClosure S) = S := by
  ext a
  rw [maximalEvents_iff_maximal]
  exact hS.maximal_mem_lowerClosure_iff_mem

theorem downClosure_injective_on_antichains {S T : Set A}
    (hS : IsAntichain (· ≤ ·) S) (hT : IsAntichain (· ≤ ·) T)
    (hST : downClosure S = downClosure T) : S = T := by
  calc
    S = maximalEvents (downClosure S) := (maximalEvents_downClosure hS).symm
    _ = maximalEvents (downClosure T) := congrArg maximalEvents hST
    _ = T := maximalEvents_downClosure hT

theorem downClosure_ssubset_of_ssubset_antichains {S T : Set A}
    (hS : IsAntichain (· ≤ ·) S) (hT : IsAntichain (· ≤ ·) T)
    (hST : S ⊂ T) : downClosure S ⊂ downClosure T := by
  apply Set.ssubset_iff_subset_ne.mpr
  exact ⟨downClosure_mono hST.1, fun heq =>
    hST.ne (downClosure_injective_on_antichains hS hT heq)⟩

end DIDomainClassification.FiniteCausalConflicts





