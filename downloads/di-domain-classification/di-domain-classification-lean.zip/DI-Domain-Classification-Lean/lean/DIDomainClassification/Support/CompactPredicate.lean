import DIDomainClassification.Support.FiniteOrderDomains

/-! Generic compact threshold predicates into the literal lifted two-point chain.
The directed-supremum argument uses the actual OrderCore compactness predicate.
No countability, strictness, or function-space closure is assumed.
-/

set_option autoImplicit false
universe u v
noncomputable section

namespace DIDomainClassification.CompactPredicate

open OrderCore FiniteOrderDomains

def threshold {D : Type u} [Preorder D] (a x : D) : TwoCarrier.{v} := by
  classical
  exact if a ≤ x then one else zero

theorem threshold_of_le {D : Type u} [Preorder D] {a x : D} (h : a ≤ x) :
    threshold.{u,v} a x = one := by
  classical
  exact if_pos h

theorem threshold_of_not_le {D : Type u} [Preorder D] {a x : D} (h : ¬ a ≤ x) :
    threshold.{u,v} a x = zero := by
  classical
  exact if_neg h

theorem threshold_monotone {D : Type u} [Preorder D] (a : D) :
    Monotone (threshold.{u,v} a) := by
  intro x y hxy
  by_cases hax : a ≤ x
  · rw [threshold_of_le hax, threshold_of_le (hax.trans hxy)]
  · rw [threshold_of_not_le hax]
    exact zero_le _

theorem threshold_scottContinuous {D : Type u} [Preorder D] {a : D}
    (ha : Compact a) : ScottContinuous (threshold.{u,v} a) := by
  intro X hne hdir s hs
  constructor
  · rintro _ ⟨x, hx, rfl⟩
    exact threshold_monotone a (hs.1 hx)
  · intro z hz
    by_cases has : a ≤ s
    · obtain ⟨x, hx, hax⟩ := ha ⟨hne, hdir⟩ hs has
      calc
        threshold a s = one := threshold_of_le has
        _ = threshold a x := (threshold_of_le hax).symm
        _ ≤ z := hz ⟨x, hx, rfl⟩
    · rw [threshold_of_not_le has]
      exact zero_le _

theorem threshold_stable (D : DIDomainObject.{u}) {a : D}
    (ha : Compact a) :
    IsStable D twoObject.{v}.toDIDomainObject (threshold.{u,v} a) := by
  refine ⟨threshold_scottContinuous ha, ?_⟩
  intro x y _hxy
  by_cases hax : a ≤ x
  · by_cases hay : a ≤ y
    · have hmeet : a ≤ x ⊓ y := le_inf hax hay
      rw [threshold_of_le hmeet, threshold_of_le hax,
        threshold_of_le hay, inf_idem]
    · have hmiss : ¬ a ≤ x ⊓ y := fun h => hay (h.trans inf_le_right)
      rw [threshold_of_not_le hmiss, threshold_of_le hax,
        threshold_of_not_le hay]
      symm
      apply inf_eq_right.mpr
      exact zero_le.{v} one.{v}
  · have hmiss : ¬ a ≤ x ⊓ y := fun h => hax (h.trans inf_le_left)
    rw [threshold_of_not_le hmiss, threshold_of_not_le hax]
    symm
    apply inf_eq_left.mpr
    exact zero_le _

theorem exists_compact_ne_least {D : Type u} [PartialOrder D]
    (hD : IsAlgebraicDcpo D) (b : D) (hb : ∀ x : D, b ≤ x)
    (hne : ∃ x y : D, x ≠ y) : ∃ a : D, Compact a ∧ a ≠ b := by
  classical
  by_contra hnone
  have hcompact : ∀ a : D, Compact a → a = b := by
    intro a ha
    by_contra hab
    exact hnone ⟨a, ha, hab⟩
  have hall : ∀ x : D, x = b := by
    intro x
    apply le_antisymm
    · exact (hD.2 x).2.2 b (fun k hk => le_of_eq (hcompact k hk.1))
    · exact hb x
  obtain ⟨x, y, hxy⟩ := hne
  exact hxy ((hall x).trans (hall y).symm)

end DIDomainClassification.CompactPredicate
