import DIDomainClassification.Section04.TreeRealisation
import DIDomainClassification.Support.TreeSingletonBasis

/-! For an equality-order forbidden-family presentation, actual minimal
causal conflicts are exactly its actual inclusion-minimal forbidden sets.
The equality max(U)=U is used ONLY in this equality-order specialization. -/

set_option autoImplicit false
universe u
noncomputable section

namespace DIDomainClassification.TreeBlocksCausalPresentation

open Preliminaries EventStructures Trees ForbiddenFiniteDomains
open Section02.TreeDomainConstruction SingletonForbiddenDomains

variable {A : Type u}

theorem maximalEvents_equality (U : Set A) :
    letI : PartialOrder A := equalityOrder A
    maximalEvents U = U := by
  letI : PartialOrder A := equalityOrder A
  ext a
  constructor
  · exact fun ha => ha.1
  · intro ha
    refine ⟨ha, ?_⟩
    intro b _hb hab
    change a = b at hab
    exact hab.symm

theorem conflictFamily_eq (F : Set (Set A)) (hF : Admissible F)
    (hAnti : ForbiddenAntichain F) :
    letI : PartialOrder A := equalityOrder A
    causalConflictFamily (eventStructure F hF) = F := by
  classical
  letI : PartialOrder A := equalityOrder A
  ext H
  constructor
  · rintro ⟨U, hU, rfl⟩
    have hbad : ¬ Avoids F U := fun h => hU.2.2.1 ⟨hU.1, h⟩
    change ¬ ∀ J : Set A, J ∈ F → ¬ J ⊆ U at hbad
    push Not at hbad
    obtain ⟨J, hJ, hJU⟩ := hbad
    have hUJ : U ⊆ J := by
      by_contra hnot
      have hCon := hU.2.2.2 J ⟨hJU, hnot⟩ (equalityOrder_every_set_lower J)
      exact hCon.2 J hJ Set.Subset.rfl
    have hMax : maximalEvents U = U := maximalEvents_equality U
    rw [hMax, Set.Subset.antisymm hUJ hJU]
    exact hJ
  · intro hH
    refine ⟨H, ⟨hF.finite H hH, equalityOrder_every_set_lower H, ?_, ?_⟩,
      (maximalEvents_equality H).symm⟩
    · intro hCon
      exact hCon.2 H hH Set.Subset.rfl
    · intro V hVH _hLower
      refine ⟨(hF.finite H hH).subset hVH.1, ?_⟩
      intro J hJ hJV
      have hJH := hAnti J hJ H hH (hJV.trans hVH.1)
      have hHV : H ⊆ V := by simpa only [hJH] using hJV
      exact hVH.2 hHV

def treeEvents {B : Type u} (S : RootedPrefixTree B) (hq : S.IsProper) :
    @FinitaryPrimeEventStructure S.Node (equalityOrder S.Node) :=
  eventStructure (forbiddenBranches S) (admissible S hq)

theorem tree_conflictFamily {B : Type u} (S : RootedPrefixTree B) (hq : S.IsProper) :
    letI : PartialOrder S.Node := equalityOrder S.Node
    causalConflictFamily (treeEvents S hq) = forbiddenBranches S :=
  conflictFamily_eq (forbiddenBranches S) (admissible S hq)
    (TreeDomainDegree.forbiddenBranches_antichain S)

def treeOrderIso {B : Type u} (S : RootedPrefixTree B) (hq : S.IsProper) :
    letI : PartialOrder S.Node := equalityOrder S.Node
    Configuration (treeEvents S hq) ≃o TreeDomain S :=
  configurationOrderIso (forbiddenBranches S) (admissible S hq)

theorem treeOrderIso_values {B : Type u} (S : RootedPrefixTree B) (hq : S.IsProper) :
    letI : PartialOrder S.Node := equalityOrder S.Node
    ∀ X : Configuration (treeEvents S hq), (treeOrderIso S hq X).val = X.val := fun _ => rfl

theorem treeOrderIso_symm_values {B : Type u} (S : RootedPrefixTree B) (hq : S.IsProper) :
    letI : PartialOrder S.Node := equalityOrder S.Node
    ∀ X : TreeDomain S, ((treeOrderIso S hq).symm X).val = X.val := fun _ => rfl

end DIDomainClassification.TreeBlocksCausalPresentation
