import DIDomainClassification.Section02.SubcategoryConventions
import DIDomainClassification.Support.FiniteOrderDomains
import DIDomainClassification.Support.StableClosureWitness

/-!
Generic reconstruction of native ambient objects from intrinsic full-subcategory
products and adjoints. This is supporting mathematics, not a named manuscript
lemma or a source-facing proof receipt. Every carrier/order/map is native.
-/

set_option autoImplicit false

universe u

noncomputable section

namespace DIDomainClassification.IntrinsicAmbient

open CategoryTheory CategoryTheory.Limits
open Subcategories Section02.StableBackground

abbrev closure : DomainClosure.{u} := StableClosureWitness.domainClosure.{u}
abbrev unit : Obj.{u} := terminalObject closure
abbrev two : Obj.{u} := FiniteOrderDomains.twoObject.{u}
abbrev product (D E : Obj.{u}) : Obj.{u} := productObject closure D E
abbrev exponential (D E : Obj.{u}) : Obj.{u} := exponentialObject closure D E

abbrev app {D E : Obj.{u}} (f : D ⟶ E) (x : Core D) : Core E :=
  CountablyBasedDIDomain.toStableHom f x

def constant (D E : Obj.{u}) (y : Core E) : D ⟶ E :=
  StableHom.ofFunction (fun _ => y)
    ⟨ScottContinuous.const y, fun _ _ _ => (inf_idem y).symm⟩

theorem constant_apply (D E : Obj.{u}) (y : Core E) (x : Core D) :
    app (constant D E y) x = y := rfl

/-- The actual non-strict stable maps from literal unit are precisely points. -/
def unitPointsEquiv (D : Obj.{u}) : (unit ⟶ D) ≃ Core D where
  toFun f := app f PUnit.unit
  invFun x := constant unit D x
  left_inv f := by
    apply StableHom.ext
    intro x
    have hx : x = PUnit.unit := Subsingleton.elim _ _
    cases hx
    rfl
  right_inv _ := rfl

/-- All order intervals are represented by actual stable maps out of literal Two. -/
def twoProbe (D : Obj.{u}) (x y : Core D) (hxy : x ≤ y) : two ⟶ D := by
  classical
  letI : Finite (Core two.{u}) := inferInstanceAs (Finite FiniteOrderDomains.TwoCarrier.{u})
  let f : Core two.{u} → Core D := fun t => if t = FiniteOrderDomains.zero.{u} then x else y
  apply StableHom.ofFunction f
  apply FiniteOrderDomains.stable_of_monotone_finite_total
  · intro a b
    change a.down ≤ b.down ∨ b.down ≤ a.down
    exact le_total a.down b.down
  · intro a b hab
    rcases FiniteOrderDomains.eq_zero_or_one.{u} a with rfl | rfl <;>
      rcases FiniteOrderDomains.eq_zero_or_one.{u} b with rfl | rfl
    · exact le_rfl
    · dsimp only [f]
      rw [if_pos rfl]
      split
      · exact le_rfl
      · exact hxy
    · exact False.elim (FiniteOrderDomains.zero_ne_one.{u}
        (le_antisymm (FiniteOrderDomains.zero_le.{u} _) hab))
    · exact le_rfl

theorem twoProbe_zero (D : Obj.{u}) (x y : Core D) (hxy : x ≤ y) :
    app (twoProbe D x y hxy) FiniteOrderDomains.zero = x := by
  dsimp only [twoProbe, app, CountablyBasedDIDomain.toStableHom, StableHom.ofFunction]
  split
  · rfl
  · rename_i h
    exact False.elim (h rfl)

theorem twoProbe_one (D : Obj.{u}) (x y : Core D) (hxy : x ≤ y) :
    app (twoProbe D x y hxy) FiniteOrderDomains.one = y := by
  dsimp only [twoProbe, app, CountablyBasedDIDomain.toStableHom, StableHom.ofFunction]
  split
  · rename_i h
    exact False.elim (FiniteOrderDomains.zero_ne_one.{u} h.symm)
  · rfl

theorem le_iff_twoProbe (D : Obj.{u}) (x y : Core D) :
    x ≤ y ↔ ∃ f : two ⟶ D,
      app f FiniteOrderDomains.zero = x ∧ app f FiniteOrderDomains.one = y := by
  constructor
  · intro hxy
    exact ⟨twoProbe D x y hxy, twoProbe_zero D x y hxy, twoProbe_one D x y hxy⟩
  · rintro ⟨f, hx, hy⟩
    rw [← hx, ← hy]
    exact (StableHom.isStable f).1.monotone (FiniteOrderDomains.zero_le _)

def isoOrderIso {D E : Obj.{u}} (e : D ≅ E) : Core D ≃o Core E where
  toFun := app e.hom
  invFun := app e.inv
  left_inv x := congrArg (fun f : D ⟶ D => app f x) e.hom_inv_id
  right_inv x := congrArg (fun f : E ⟶ E => app f x) e.inv_hom_id
  map_rel_iff' := by
    intro x y
    change app e.hom x ≤ app e.hom y ↔ x ≤ y
    constructor
    · intro hxy
      have h := (StableHom.isStable e.inv).1.monotone hxy
      change app e.inv (app e.hom x) ≤ app e.inv (app e.hom y) at h
      rw [show app e.inv (app e.hom x) = x from
        congrArg (fun f : D ⟶ D => app f x) e.hom_inv_id,
        show app e.inv (app e.hom y) = y from
        congrArg (fun f : D ⟶ D => app f y) e.hom_inv_id] at h
      exact h
    · intro hxy
      exact (StableHom.isStable e.hom).1.monotone hxy

def orderIsoIso {D E : Obj.{u}} (e : Core D ≃o Core E) : D ≅ E where
  hom := OrderIsoTransport.stableHom (Core D) (Core E) e
  inv := OrderIsoTransport.stableHom (Core E) (Core D) e.symm
  hom_inv_id := StableHom.ext e.symm_apply_apply
  inv_hom_id := StableHom.ext e.apply_symm_apply

theorem nonempty_iso_iff_orderIso (D E : Obj.{u}) :
    Nonempty (D ≅ E) ↔ Nonempty (Core D ≃o Core E) :=
  ⟨fun ⟨e⟩ => ⟨isoOrderIso e⟩, fun ⟨e⟩ => ⟨orderIsoIso e⟩⟩

section Full

variable (P : ObjectClass.{u})

abbrev FObj := FullStableSubcategory P
abbrev FCore (D : FObj P) := D.obj.toDIDomainObject

abbrev fapp {D E : FObj P} (f : D ⟶ E) (x : FCore P D) : FCore P E :=
  app f.hom x

def fconstant (D E : FObj P) (y : FCore P E) : D ⟶ E :=
  ObjectProperty.homMk (constant D.obj E.obj y)

theorem fapp_comp {D E F : FObj P} (f : D ⟶ E) (g : E ⟶ F) (x : FCore P D) :
    fapp P (f ≫ g) x = fapp P g (fapp P f x) := rfl

theorem fapp_id (D : FObj P) (x : FCore P D) : fapp P (𝟙 D) x = x := rfl

theorem full_hom_ext {D E : FObj P} {f g : D ⟶ E}
    (h : ∀ x : FCore P D, fapp P f x = fapp P g x) : f = g :=
  ObjectProperty.hom_ext P (StableHom.ext h)

abbrev U (hU : P unit) : FObj P := ⟨unit, hU⟩
abbrev T (hT : P two) : FObj P := ⟨two, hT⟩

def fullUnitPointsEquiv (hU : P unit) (D : FObj P) :
    (U P hU ⟶ D) ≃ FCore P D :=
  (homEquiv P _ _).trans (unitPointsEquiv D.obj)

theorem fullUnitPointsEquiv_apply (hU : P unit) (D : FObj P) (f : U P hU ⟶ D) :
    fullUnitPointsEquiv P hU D f = fapp P f PUnit.unit := rfl

theorem fullUnitPointsEquiv_symm_apply (hU : P unit) (D : FObj P) (x : FCore P D) :
    (fullUnitPointsEquiv P hU D).symm x = fconstant P (U P hU) D x := rfl

section Products

variable [HasFiniteProducts (FObj P)]

def productToPair (D E : FObj P) (p : FCore P (D ⨯ E)) : FCore P D × FCore P E :=
  (fapp P (prod.fst : D ⨯ E ⟶ D) p, fapp P (prod.snd : D ⨯ E ⟶ E) p)

theorem fapp_lift_fst {X D E : FObj P} (f : X ⟶ D) (g : X ⟶ E) (x : FCore P X) :
    fapp P (prod.fst : D ⨯ E ⟶ D) (fapp P (prod.lift f g) x) = fapp P f x :=
  congrArg (fun k : X ⟶ D => fapp P k x) (prod.lift_fst f g)

theorem fapp_lift_snd {X D E : FObj P} (f : X ⟶ D) (g : X ⟶ E) (x : FCore P X) :
    fapp P (prod.snd : D ⨯ E ⟶ E) (fapp P (prod.lift f g) x) = fapp P g x :=
  congrArg (fun k : X ⟶ E => fapp P k x) (prod.lift_snd f g)

theorem productToPair_lift {X D E : FObj P} (f : X ⟶ D) (g : X ⟶ E)
    (x : FCore P X) :
    productToPair P D E (fapp P (prod.lift f g) x) = (fapp P f x, fapp P g x) :=
  Prod.ext (fapp_lift_fst P f g x) (fapp_lift_snd P f g x)

/-- Unit tests establish injectivity without using an ambient product object. -/
theorem productToPair_injective (hU : P unit) (D E : FObj P) :
    Function.Injective (productToPair P D E) := by
  intro p q hpq
  have hmap : fconstant P (U P hU) (D ⨯ E) p =
      fconstant P (U P hU) (D ⨯ E) q := by
    apply prod.hom_ext
    · apply full_hom_ext P
      intro _
      exact congrArg Prod.fst hpq
    · apply full_hom_ext P
      intro _
      exact congrArg Prod.snd hpq
  exact congrArg (fun k : U P hU ⟶ D ⨯ E => fapp P k PUnit.unit) hmap

def pairToProduct (hU : P unit) (D E : FObj P) (p : FCore P D × FCore P E) :
    FCore P (D ⨯ E) :=
  fapp P (prod.lift (fconstant P (U P hU) D p.1) (fconstant P (U P hU) E p.2)) PUnit.unit

theorem productToPair_pairToProduct (hU : P unit) (D E : FObj P)
    (p : FCore P D × FCore P E) :
    productToPair P D E (pairToProduct P hU D E p) = p := by
  apply Prod.ext
  · exact fapp_lift_fst P (fconstant P (U P hU) D p.1)
      (fconstant P (U P hU) E p.2) PUnit.unit
  · exact fapp_lift_snd P (fconstant P (U P hU) D p.1)
      (fconstant P (U P hU) E p.2) PUnit.unit

def productPairEquiv (hU : P unit) (D E : FObj P) :
    FCore P (D ⨯ E) ≃ (FCore P D × FCore P E) where
  toFun := productToPair P D E
  invFun := pairToProduct P hU D E
  left_inv p := productToPair_injective P hU D E
    (productToPair_pairToProduct P hU D E (productToPair P D E p))
  right_inv := productToPair_pairToProduct P hU D E

/-- Two tests recover the original coordinatewise order, not a chosen order. -/
theorem productToPair_le_iff (hU : P unit) (hT : P two) (D E : FObj P)
    (p q : FCore P (D ⨯ E)) :
    productToPair P D E p ≤ productToPair P D E q ↔ p ≤ q := by
  constructor
  · intro hpq
    let f : T P hT ⟶ D := ObjectProperty.homMk
      (twoProbe D.obj (productToPair P D E p).1 (productToPair P D E q).1 hpq.1)
    let g : T P hT ⟶ E := ObjectProperty.homMk
      (twoProbe E.obj (productToPair P D E p).2 (productToPair P D E q).2 hpq.2)
    let k : T P hT ⟶ D ⨯ E := prod.lift f g
    have hk0 : fapp P k FiniteOrderDomains.zero = p := by
      apply productToPair_injective P hU D E
      rw [productToPair_lift]
      exact Prod.ext (twoProbe_zero D.obj _ _ hpq.1) (twoProbe_zero E.obj _ _ hpq.2)
    have hk1 : fapp P k FiniteOrderDomains.one = q := by
      apply productToPair_injective P hU D E
      rw [productToPair_lift]
      exact Prod.ext (twoProbe_one D.obj _ _ hpq.1) (twoProbe_one E.obj _ _ hpq.2)
    rw [← hk0, ← hk1]
    exact (StableHom.isStable (homEquiv P _ _ k)).1.monotone
      (FiniteOrderDomains.zero_le _)
  · intro hpq
    exact ⟨(StableHom.isStable (homEquiv P _ _ (prod.fst : D ⨯ E ⟶ D))).1.monotone hpq,
      (StableHom.isStable (homEquiv P _ _ (prod.snd : D ⨯ E ⟶ E))).1.monotone hpq⟩

def productOrderIso (hU : P unit) (hT : P two) (D E : FObj P) :
    FCore P (D ⨯ E) ≃o (FCore P D × FCore P E) where
  toEquiv := productPairEquiv P hU D E
  map_rel_iff' := fun {p q} => productToPair_le_iff P hU hT D E p q

/-- The actual intrinsic product is stably isomorphic to the literal product.
No literal-product membership in P is an input. -/
def productIso (hU : P unit) (hT : P two) (D E : FObj P) :
    (D ⨯ E).obj ≅ product D.obj E.obj :=
  orderIsoIso (productOrderIso P hU hT D E)

theorem productIso_hom_apply (hU : P unit) (hT : P two) (D E : FObj P)
    (p : FCore P (D ⨯ E)) :
    app (productIso P hU hT D E).hom p = productToPair P D E p := rfl

theorem replete_product_mem (hU : P unit) (hT : P two) (hP : IsReplete P)
    (D E : FObj P) : P (product D.obj E.obj) :=
  (replete_iff P).mp hP (productIso P hU hT D E) (D ⨯ E).property

theorem productIso_inv_apply (hU : P unit) (hT : P two) (D E : FObj P)
    (p : FCore P D × FCore P E) :
    app (productIso P hU hT D E).inv p = pairToProduct P hU D E p := rfl

theorem fapp_prod_map_fst {D X Y : FObj P} (f : X ⟶ Y) (p : FCore P (D ⨯ X)) :
    fapp P (prod.fst : D ⨯ Y ⟶ D) (fapp P ((prod.functor.obj D).map f) p) =
      fapp P (prod.fst : D ⨯ X ⟶ D) p := by
  change fapp P (prod.fst : D ⨯ Y ⟶ D) (fapp P (prod.map (𝟙 D) f) p) = _
  have h := congrArg (fun k : D ⨯ X ⟶ D => fapp P k p) (prod.map_fst (𝟙 D) f)
  exact h

theorem fapp_prod_map_snd {D X Y : FObj P} (f : X ⟶ Y) (p : FCore P (D ⨯ X)) :
    fapp P (prod.snd : D ⨯ Y ⟶ Y) (fapp P ((prod.functor.obj D).map f) p) =
      fapp P f (fapp P (prod.snd : D ⨯ X ⟶ X) p) := by
  change fapp P (prod.snd : D ⨯ Y ⟶ Y) (fapp P (prod.map (𝟙 D) f) p) = _
  exact congrArg (fun k : D ⨯ X ⟶ Y => fapp P k p) (prod.map_snd (𝟙 D) f)

theorem productToPair_prod_map {D X Y : FObj P} (f : X ⟶ Y)
    (p : FCore P (D ⨯ X)) :
    productToPair P D Y (fapp P ((prod.functor.obj D).map f) p) =
      ((productToPair P D X p).1, fapp P f (productToPair P D X p).2) :=
  Prod.ext (fapp_prod_map_fst P f p) (fapp_prod_map_snd P f p)

theorem prod_map_pairToProduct (hU : P unit) {D X Y : FObj P} (f : X ⟶ Y)
    (p : FCore P D × FCore P X) :
    fapp P ((prod.functor.obj D).map f) (pairToProduct P hU D X p) =
      pairToProduct P hU D Y (p.1, fapp P f p.2) := by
  apply productToPair_injective P hU D Y
  rw [productToPair_prod_map, productToPair_pairToProduct, productToPair_pairToProduct]

/-- Precomposition transports actual native stable maps along an actual iso. -/
def precomposeIsoEquiv {A B E : Obj.{u}} (e : A ≅ B) : (A ⟶ E) ≃ (B ⟶ E) where
  toFun f := e.inv ≫ f
  invFun f := e.hom ≫ f
  left_inv f := by simp only [← Category.assoc, e.hom_inv_id, Category.id_comp]
  right_inv f := by simp only [← Category.assoc, e.inv_hom_id, Category.id_comp]

/-- Actual intrinsic-product arrows correspond to actual stable maps into the
native stable-ordered exponential. No object-membership assertion is used. -/
def nativeCurryEquiv (hU : P unit) (hT : P two) (D X E : FObj P) :
    (D ⨯ X ⟶ E) ≃ (X.obj ⟶ exponential D.obj E.obj) :=
  (homEquiv P (D ⨯ X) E).trans
    ((precomposeIsoEquiv (productIso P hU hT D X)).trans
      (StableCCCCategory.leftCurryEquiv closure D.obj X.obj E.obj))

theorem nativeCurryEquiv_apply (hU : P unit) (hT : P two) (D X E : FObj P)
    (f : D ⨯ X ⟶ E) (x : FCore P X) (d : FCore P D) :
    app (nativeCurryEquiv P hU hT D X E f) x d =
      fapp P f (pairToProduct P hU D X (d, x)) := rfl

section Exponentials

variable (hU : P unit) (hT : P two) (D E : FObj P)
variable {R : FObj P ⥤ FObj P} (A : (prod.functor.obj D) ⊣ R)

def exponentialComparison (X : FObj P) :
    (X ⟶ R.obj E) ≃ (X.obj ⟶ exponential D.obj E.obj) :=
  (A.homEquiv X E).symm.trans (nativeCurryEquiv P hU hT D X E)

def exponentialPointsEquiv : FCore P (R.obj E) ≃ Hom D.obj E.obj :=
  ((fullUnitPointsEquiv P hU (R.obj E)).symm.trans
    (exponentialComparison P hU hT D E A (U P hU))).trans
      (unitPointsEquiv (exponential D.obj E.obj))

/-- The point comparison is forced by actual adjunction naturality. -/
theorem exponentialComparison_points (X : FObj P) (k : X ⟶ R.obj E)
    (x : FCore P X) :
    app (exponentialComparison P hU hT D E A X k) x =
      exponentialPointsEquiv P hU hT D E A (fapp P k x) := by
  apply StableHom.ext
  intro d
  change app (nativeCurryEquiv P hU hT D X E ((A.homEquiv X E).symm k)) x d =
    app (nativeCurryEquiv P hU hT D (U P hU) E
      ((A.homEquiv (U P hU) E).symm (fconstant P (U P hU) (R.obj E) (fapp P k x))))
      PUnit.unit d
  rw [nativeCurryEquiv_apply, nativeCurryEquiv_apply]
  have hc : fconstant P (U P hU) (R.obj E) (fapp P k x) =
      fconstant P (U P hU) X x ≫ k := by
    apply full_hom_ext P
    intro _
    rfl
  rw [hc, A.homEquiv_naturality_left_symm, fapp_comp,
    prod_map_pairToProduct]
  rfl

theorem exponentialPointsEquiv_le_iff (p q : FCore P (R.obj E)) :
    exponentialPointsEquiv P hU hT D E A p ≤ exponentialPointsEquiv P hU hT D E A q ↔
      p ≤ q := by
  constructor
  · intro hpq
    let g : two ⟶ exponential D.obj E.obj :=
      twoProbe (exponential D.obj E.obj)
        (exponentialPointsEquiv P hU hT D E A p)
        (exponentialPointsEquiv P hU hT D E A q) hpq
    let k : T P hT ⟶ R.obj E :=
      (exponentialComparison P hU hT D E A (T P hT)).symm g
    have hkg : exponentialComparison P hU hT D E A (T P hT) k = g :=
      (exponentialComparison P hU hT D E A (T P hT)).apply_symm_apply g
    have hk0 : fapp P k FiniteOrderDomains.zero = p := by
      apply (exponentialPointsEquiv P hU hT D E A).injective
      rw [← exponentialComparison_points, hkg]
      exact twoProbe_zero _ _ _ hpq
    have hk1 : fapp P k FiniteOrderDomains.one = q := by
      apply (exponentialPointsEquiv P hU hT D E A).injective
      rw [← exponentialComparison_points, hkg]
      exact twoProbe_one _ _ _ hpq
    rw [← hk0, ← hk1]
    exact (StableHom.isStable (homEquiv P _ _ k)).1.monotone
      (FiniteOrderDomains.zero_le _)
  · intro hpq
    let k : T P hT ⟶ R.obj E :=
      ObjectProperty.homMk (twoProbe (R.obj E).obj p q hpq)
    have hk0 : fapp P k FiniteOrderDomains.zero = p := twoProbe_zero _ _ _ hpq
    have hk1 : fapp P k FiniteOrderDomains.one = q := twoProbe_one _ _ _ hpq
    have hmono := (StableHom.isStable
      (CountablyBasedDIDomain.toStableHom
        (exponentialComparison P hU hT D E A (T P hT) k))).1.monotone
        (FiniteOrderDomains.zero_le FiniteOrderDomains.one)
    change app (exponentialComparison P hU hT D E A (T P hT) k) FiniteOrderDomains.zero ≤
      app (exponentialComparison P hU hT D E A (T P hT) k) FiniteOrderDomains.one at hmono
    rw [exponentialComparison_points, exponentialComparison_points, hk0, hk1] at hmono
    exact hmono

/-- Any actual right adjoint yields the native STABLE order, not pointwise order. -/
def exponentialOrderIso : FCore P (R.obj E) ≃o Hom D.obj E.obj where
  toEquiv := exponentialPointsEquiv P hU hT D E A
  map_rel_iff' := fun {p q} => exponentialPointsEquiv_le_iff P hU hT D E A p q

def exponentialIso : (R.obj E).obj ≅ exponential D.obj E.obj :=
  orderIsoIso (exponentialOrderIso P hU hT D E A)

theorem exponentialIso_hom_apply (p : FCore P (R.obj E)) :
    app (exponentialIso P hU hT D E A).hom p =
      exponentialPointsEquiv P hU hT D E A p := rfl

include hU hT A in
theorem replete_exponential_mem (hP : IsReplete P) : P (exponential D.obj E.obj) :=
  (replete_iff P).mp hP (exponentialIso P hU hT D E A) (R.obj E).property

end Exponentials

end Products

end Full

end DIDomainClassification.IntrinsicAmbient
