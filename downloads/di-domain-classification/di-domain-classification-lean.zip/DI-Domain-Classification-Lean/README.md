# Stable categories of dI-domains — Lean project

The paper's standalone Lean 4 formalization. A separate self-contained HTML provides an offline source reader.

With Elan and Git installed, run sh Check.command on macOS/Unix, Check.cmd on Windows, or lake build inside lean/. The first build may download the pinned dependencies; caches are not bundled.

Lean: leanprover/lean4:v4.30.0-rc2. Mathlib: 5450b53e5ddc75d46418fabb605edbf36bd0beb6. All 315 local modules are built by default.

Corollary 4.23 uses the revised bound 3 <= lambda <= omega_1. The earlier unbounded statement and its counterexample remain historical supporting code, not claims of the revised paper.

Human mathematical review is pending. Packaging and compilation do not certify mathematical novelty or every cited result. SHA256SUMS records the archive contents.
