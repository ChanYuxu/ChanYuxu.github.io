#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")/lean"
if command -v lake >/dev/null 2>&1; then
    exec lake build
fi
if [ -n "${HOME:-}" ] && [ -x "$HOME/.elan/bin/lake" ]; then
    exec "$HOME/.elan/bin/lake" build
fi
printf '%s
' 'Lake was not found. Install the pinned Lean version using Elan; see README.md.' >&2
exit 127
