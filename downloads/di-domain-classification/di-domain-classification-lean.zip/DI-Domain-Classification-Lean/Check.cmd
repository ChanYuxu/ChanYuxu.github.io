@echo off
setlocal
cd /d "%~dp0lean"
if errorlevel 1 goto unavailable
where lake >nul 2>nul
if errorlevel 1 goto elan
call lake build
set "PROOF_BUILD_STATUS=%errorlevel%"
goto done
:elan
if not exist "%USERPROFILE%\.elan\bin\lake.exe" goto unavailable
call "%USERPROFILE%\.elan\bin\lake.exe" build
set "PROOF_BUILD_STATUS=%errorlevel%"
goto done
:unavailable
echo Could not start Lake. Check the lean folder and install the pinned Lean with Elan.
pause
exit /b 127
:done
echo Lake exit code: %PROOF_BUILD_STATUS%
pause
exit /b %PROOF_BUILD_STATUS%
