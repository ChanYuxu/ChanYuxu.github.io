@echo off
setlocal
pushd "%~dp0lean" || exit /b 1
call lake build %*
set "check_exit=%errorlevel%"
popd
exit /b %check_exit%
