import CoherentContinuousAlgebraicRetracts
import CoherentContinuousAlgebraicRetracts.InternalCoherence
import CoherentContinuousAlgebraicRetracts.InternalLawson
import CoherentContinuousAlgebraicRetractsApplications
import Lean.Util.CollectAxioms
import Lean.Util.FoldConsts

#print axioms CoherentContinuousAlgebraicRetracts.finite_common_approximations
#print axioms CoherentContinuousAlgebraicRetracts.algebraic_coherent_of_compact_principal_intersections_internal
#print axioms CoherentContinuousAlgebraicRetracts.lawsonCompact_of_scottCompact_and_coherent_internal
#print axioms CoherentContinuousAlgebraicRetracts.scottCompact_of_lawsonCompact_internal
#print axioms CoherentContinuousAlgebraicRetracts.idealCompletion_lawsonCompact_iff_propertyM_internal
#print axioms CoherentContinuousAlgebraicRetracts.compactIdealElements_lowerFinite
#print axioms CoherentContinuousAlgebraicRetracts.FiniteSystemPresentation.exact_refinement_decomposition
#print axioms CoherentContinuousAlgebraicRetracts.FiniteCoverRestriction.propertyM
#print axioms CoherentContinuousAlgebraicRetracts.thm_coherent_retract
#print axioms CoherentContinuousAlgebraicRetracts.cor_countable
#print axioms CoherentContinuousAlgebraicRetracts.thm_continuous_function_spaces
#print axioms CoherentContinuousAlgebraicRetracts.cor_coherent_function_space
#print axioms CoherentContinuousAlgebraicRetracts.cor_pointed_function_space
#print axioms CoherentContinuousAlgebraicRetracts.jiaJungLi_3_1
#print axioms CoherentContinuousAlgebraicRetracts.jiaJungLi_3_4
#print axioms CoherentContinuousAlgebraicRetracts.lem_continuous_coherence_criterion
#print axioms CoherentContinuousAlgebraicRetracts.continuous_lawsonCompact_iff_scottCompact_and_coherent_proved
#print axioms CoherentContinuousAlgebraicRetracts.algebraic_lawsonCompact_iff_compactBasis_propertyM_proved
#print axioms CoherentContinuousAlgebraicRetracts.FactorableApproximation.continuous_coherent_iff_scottOpenIntersectionWayBelow
#print axioms AbramskyJung.Chapter4.scottOpenWayBelow_iff_compactCarrier
#print axioms CoherentContinuousAlgebraicRetracts.luanLi_3_5
#print axioms CoherentContinuousAlgebraicRetracts.luanLi_5_6
#print axioms CoherentContinuousAlgebraicRetracts.thm_algebraic_function_spaces
#print axioms CoherentContinuousAlgebraicRetracts.thm_prefinite_algebraic
#print axioms CoherentContinuousAlgebraicRetracts.FactorableApproximation.lem_factorable_transfer
#print axioms CoherentContinuousAlgebraicRetracts.thm_prefinite_continuous
#print axioms CoherentContinuousAlgebraicRetracts.thm_prefinite_continuous_countable

open Lean Elab Command in
/- Fail closed on any unsafe declaration, custom axiom, or transitive
nonstandard axiom in any project module, including private and unused
declarations. The JSON lines record actual (type and value) dependency edges
and type expressions for the source ledger, rather than regex-derived edges. -/
set_option maxHeartbeats 0 in
run_cmd do
  let env ← getEnv
  unless env.header.trustLevel == 0 do
    throwError "Run the audit with lean --trust=0"
  let modules := env.allImportedModuleNames
  let localModule (nm : Name) := nm.toString == "CoherentContinuousAlgebraicRetracts" ||
    nm.toString.startsWith "CoherentContinuousAlgebraicRetracts." ||
    nm.toString == "CoherentContinuousAlgebraicRetractsApplications"
  let origin (nm : Name) := match env.getModuleIdxFor? nm with
    | some i => modules[i.toNat]!
    | none => env.mainModule
  let checkedReuse : List Name := [
    ``AbramskyJung.Chapter4.scottOpenWayBelow_iff_compactCarrier,
    ``AbramskyJung.Chapter4.exists_finiteUpperClosure_between,
    ``AbramskyJung.Chapter7.prop_7_2_27_continuous_domains_sober,
    ``AbramskyJung.Chapter7.theorem_7_2_9_hofmann_mislove_sober,
    ``AbramskyJung.Chapter7.cor_7_2_11_filtered_intersections_compact_saturated,
    ``AbramskyJung.Chapter3.KernelOperator.image_wayBelow_iff]
  let allowed : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut count := 0
  let mut bad : Array String := #[]
  for (nm, c) in env.constants.toList do
    let owner := origin nm
    if localModule owner || owner == env.mainModule || checkedReuse.contains nm then
      let deps ← collectAxioms nm
      let unexpected := deps.filter (fun n ↦ !allowed.contains n)
      let kind := match c with
        | .axiomInfo _ => "axiom"
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "definition"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient"
      if c.isUnsafe || kind == "axiom" || !unexpected.isEmpty then
        bad := bad.push s!"{owner}: {nm} ({kind}; unsafe={c.isUnsafe}; unexpected={unexpected})"
      count := count + 1
      liftIO <| IO.println <| "AUDIT_DECL " ++ (Json.mkObj [
        ("name", toJson nm.toString),
        ("module", toJson owner.toString),
        ("kind", toJson kind),
        ("private", toJson (nm.toString.startsWith "_private.")),
        ("unsafe", toJson c.isUnsafe),
        ("axioms", toJson (deps.toList.map Name.toString)),
        ("typeExpression", toJson (reprStr c.type)),
        ("directDependencies", toJson (c.getUsedConstantsAsSet.toList.map Name.toString))]).compress
  unless bad.isEmpty do
    throwError "Strict axiom audit failed:\n{String.intercalate "\n" bad.toList}"
  let localModules := (modules.filter localModule).toList.map Name.toString
  unless count > checkedReuse.length && !localModules.isEmpty do
    throwError "Strict axiom audit loaded no project declarations"
  liftIO <| IO.println <| "AUDIT_SCOPE " ++ (Json.mkObj [
    ("declaredAxiomAllowlist", toJson (allowed.map Name.toString)),
    ("trustLevel", toJson env.header.trustLevel.toNat),
    ("projectModules", toJson localModules),
    ("checkedDeclarations", toJson count)]).compress
  logInfo m!"STRICT_AXIOM_AUDIT_PASS: {count} declarations"

