import CoherentContinuousAlgebraicRetracts.AlgebraicFunctionSpaces
import CoherentContinuousAlgebraicRetracts.OpenSubdcpo
import CoherentContinuousAlgebraicRetracts.Lifting
import CoherentContinuousAlgebraicRetracts.ContinuousCoherence

/-!
# Function-space applications

This file transfers the algebraic function-space results to continuous
retracts and proves the coherent and pointed corollaries of the manuscript.
-/

set_option autoImplicit false

universe u v w

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

/-! ## Transfer to continuous and RB domains -/

/-- Source item `thm:continuous-function-spaces`. -/
theorem thm_continuous_function_spaces
    {D R : Type u} [PartialOrder D] [PartialOrder R]
    [Nonempty D] [Nonempty R]
    (hDdcpo : IsDcpo D)
    (hDcontinuous : AbramskyJung.Chapter3.IsContinuousDomain D)
    (hDlawson :
      AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain D))
    (hR : IsRBDomain R) :
    (AbramskyJung.Chapter4.IsLawsonCompact
        (asOrderedDomain (FunctionSpace R D)) ∧
      IsDcpo (FunctionSpace R D) ∧
      AbramskyJung.Chapter3.IsContinuousDomain (FunctionSpace R D)) ∧
      IsRBDomain (FunctionSpace D R) := by
  have hDcoherent : IsCoherent D :=
    ((continuous_lawsonCompact_iff_scottCompact_and_coherent_proved
      hDdcpo hDcontinuous).1 hDlawson).2
  let WD := lawsonRetractWitness
    hDdcpo hDcontinuous hDcoherent hDlawson
  letI : PartialOrder (IdealCompletion WD.P) :=
    idealCompletionPartialOrder WD.P
  letI : Nonempty (IdealCompletion WD.P) :=
    ⟨principalIdeal WD.P (Classical.choice (inferInstance : Nonempty WD.P))⟩
  rcases hR with ⟨WR⟩
  have hRdcpo : IsDcpo R :=
    (AbramskyJung.Chapter3.theorem_3_1_4_retract_continuous_domain_with_dcpo
      WR.pair WR.bifinite.dcpo
      ⟨CompactSet, WR.bifinite.algebraic⟩).1
  let srLeft := FunctionSpace.continuousRetract
    hDdcpo (idealCompletion_isDcpo WD.P) WR.pair WD.pair
  let srRight := FunctionSpace.continuousRetract
    hRdcpo WR.bifinite.dcpo WD.pair WR.pair
  have hAlgFS := thm_algebraic_function_spaces
    (A := IdealCompletion WD.P) (B := WR.B)
    { dcpo := idealCompletion_isDcpo WD.P
      algebraic := prop_2_2_4_1 WD.algebraic
      lawsonCompact := WD.lawsonCompact }
    WR.bifinite
  have hAmbientCoherent :
      IsCoherent (FunctionSpace WR.B (IdealCompletion WD.P)) :=
    algebraic_coherent_of_compact_principal_intersections_internal
      hAlgFS.1.dcpo (basis_to_raw hAlgFS.1.algebraic)
        (fun x y _hx _hy ↦
        principalUpper_inter_scottCompact_of_lawsonCompact_internal
          hAlgFS.1.lawsonCompact x y)
  have hLeftCore := coherent_continuous_dcpo_of_continuous_retract
    srLeft hAlgFS.1.dcpo ⟨CompactSet, hAlgFS.1.algebraic⟩
      hAmbientCoherent
  have hAmbientScott :
      IsScottCompactSpace
        (FunctionSpace WR.B (IdealCompletion WD.P)) :=
    scottCompact_of_lawsonCompact_internal hAlgFS.1.lawsonCompact
  have hLeftScott : IsScottCompactSpace (FunctionSpace R D) := by
    apply scottCompactSpace_of_surjective_scottContinuous
      hAmbientScott srLeft.continuous_r
    intro f
    exact ⟨srLeft.s f, srLeft.retract f⟩
  have hLeftLawson :
      AbramskyJung.Chapter4.IsLawsonCompact
        (asOrderedDomain (FunctionSpace R D)) :=
    lawsonCompact_of_scottCompact_and_coherent_internal
      hLeftCore.2.1 hLeftCore.2.2 hLeftScott hLeftCore.1
  refine ⟨⟨hLeftLawson, hLeftCore.2.1, hLeftCore.2.2⟩, ?_⟩
  exact ⟨
    { B := FunctionSpace (IdealCompletion WD.P) WR.B
      orderB := inferInstance
      nonemptyB := inferInstance
      bifinite := hAlgFS.2
      pair := srRight }⟩

/-! ## Open function spaces -/

namespace FunctionSpace

variable {X : Type u} {E : Type v}
variable [PartialOrder X] [PartialOrder E]

/-- Continuous functions whose entire image lies in a specified subset. -/
def mapsInto (U : Set E) : Set (FunctionSpace X E) :=
  {f | ∀ x, f x ∈ U}

/-- Equation `eq:open-function-space`: if the source is Scott compact and
`U` is Scott open, then the maps whose image lies in `U` form a Scott-open
subset of the ambient function space. -/
theorem mapsInto_scottOpen
    (hX : IsScottCompactSpace X) (hE : IsDcpo E)
    {U : Set E} (hU : ScottOpen U) :
    ScottOpen (mapsInto (X := X) U) := by
  apply scottOpen_of_upper_and_inaccessible
  · intro f g hf hfg x
    exact scottOpen_upper hU (hf x) (hfg x)
  · intro G s hG hs hsU
    let preimageOpen : FunctionSpace X E → Set X :=
      fun f ↦ (fun x ↦ f x) ⁻¹' U
    let cover : Set (Set X) := preimageOpen '' G
    have hCoverOpen : ∀ V ∈ cover, ScottOpen V := by
      intro V hV
      rcases hV with ⟨f, hfG, rfl⟩
      exact scottOpen_preimage_of_scottContinuous
        f.toContFun.continuous hU
    have hCover : (Set.univ : Set X) ⊆ Set.sUnion cover := by
      intro x _hx
      have hEvalSup := isSup_apply hE hG hs x
      have hEvalDir :
          DirectedSet ((fun f : FunctionSpace X E ↦ f x) '' G) :=
        DirectedSet.image
          (fun (f g : FunctionSpace X E) (h : f ≤ g) ↦ h x) hG
      rcases scottOpen_meets_directed hU hEvalDir hEvalSup (hsU x) with
        ⟨y, ⟨f, hfG, rfl⟩, hfxU⟩
      exact Set.mem_sUnion_of_mem hfxU ⟨f, hfG, rfl⟩
    rcases hX cover hCoverOpen hCover with
      ⟨finiteOpen, hFiniteSub, hFinite, hFiniteCovers⟩
    rcases exists_finite_preimage_cover hFinite hFiniteSub with
      ⟨F, hFfinite, hFsub, hFiniteImage⟩
    rcases hG.exists_upper_finite hFfinite hFsub with
      ⟨f₀, hf₀G, hf₀Upper⟩
    refine ⟨f₀, hf₀G, ?_⟩
    intro x
    rcases Set.mem_sUnion.mp (hFiniteCovers (Set.mem_univ x)) with
      ⟨V, hVfinite, hxV⟩
    rcases hFiniteImage hVfinite with ⟨f, hfF, hfV⟩
    have hfxU : f x ∈ U := by
      change x ∈ preimageOpen f
      rw [hfV]
      exact hxV
    exact scottOpen_upper hU hfxU (hf₀Upper f hfF x)

/-- Regard a function into an open subtype as an ambient function whose image
lies in the open set. -/
def openCodomainEmbed
    (hE : IsDcpo E) {U : Set E} (hU : ScottOpen U)
    (f : FunctionSpace X U) :
    mapsInto (X := X) U := by
  let inclusion : AbramskyJung.Chapter3.ContFun U E :=
    { toFun := ((↑) : U → E)
      continuous := scottOpenSubtype_inclusion_scottContinuous hE hU }
  refine ⟨⟨AbramskyJung.Chapter3.ContFun.comp inclusion f.toContFun⟩, ?_⟩
  intro x
  exact (f x).2

/-- Corestrict an ambient function satisfying the image condition to the
open subtype. -/
def openCodomainProject
    {U : Set E} (g : mapsInto (X := X) U) : FunctionSpace X U :=
  ⟨{ toFun := fun x ↦ ⟨g.1 x, g.2 x⟩
     continuous := by
       constructor
       · intro x y hxy
         exact g.1.toContFun.continuous.1 hxy
       · intro A s hA hs
         have hAmbient := g.1.toContFun.continuous.2 hA hs
         constructor
         · rintro _ ⟨x, hxA, rfl⟩
           exact hAmbient.1 ⟨x, hxA, rfl⟩
         · intro q hq
           exact hAmbient.2 q.1 (by
             rintro _ ⟨x, hxA, rfl⟩
             exact hq ⟨x, hxA, rfl⟩) }⟩

@[simp]
theorem openCodomainProject_embed
    (hE : IsDcpo E) {U : Set E} (hU : ScottOpen U)
    (f : FunctionSpace X U) :
    openCodomainProject (openCodomainEmbed hE hU f) = f := by
  apply FunctionSpace.ext
  intro x
  exact Subtype.ext rfl

/-- The identification of `[X → U]` with the open subspace of `[X → E]`
is a continuous section--retraction pair. -/
def openCodomainRetract
    (hE : IsDcpo E) {U : Set E} (hU : ScottOpen U) :
    AbramskyJung.Chapter3.ContinuousSectionRetractionPair
      (FunctionSpace X U) (mapsInto (X := X) U) where
  s := openCodomainEmbed hE hU
  r := openCodomainProject
  monotone_s := by
    intro f g hfg x
    exact hfg x
  monotone_r := by
    intro f g hfg x
    exact hfg x
  retract := openCodomainProject_embed hE hU
  continuous_s := by
    constructor
    · intro f g hfg x
      exact hfg x
    · intro G s hG hs
      constructor
      · rintro _ ⟨f, hfG, rfl⟩
        intro x
        exact hs.1 hfG x
      · intro q hq
        let q' : FunctionSpace X U := openCodomainProject q
        have hsle : s ≤ q' := hs.2 q' (by
          intro f hfG x
          exact hq ⟨f, hfG, rfl⟩ x)
        intro x
        exact hsle x
  continuous_r := by
    constructor
    · intro f g hfg x
      exact hfg x
    · intro G s hG hs
      constructor
      · rintro _ ⟨f, hfG, rfl⟩
        intro x
        exact hs.1 hfG x
      · intro q hq
        let q' : mapsInto (X := X) U := openCodomainEmbed hE hU q
        have hsle : s ≤ q' := hs.2 q' (by
          intro f hfG x
          exact hq ⟨f, hfG, rfl⟩ x)
        intro x
        exact hsle x

/-- Continuity and coherence pass to a function space with nonempty Scott-open
codomain. -/
theorem openCodomain_coherent_continuous
    (hX : IsScottCompactSpace X)
    (hE : IsDcpo E)
    (hAmbientContinuous :
      AbramskyJung.Chapter3.IsContinuousDomain (FunctionSpace X E))
    (hAmbientCoherent : IsCoherent (FunctionSpace X E))
    {U : Set E} (hU : ScottOpen U) (hUNonempty : U.Nonempty) :
    IsCoherent (FunctionSpace X U) ∧
      IsDcpo (FunctionSpace X U) ∧
      AbramskyJung.Chapter3.IsContinuousDomain (FunctionSpace X U) := by
  have hAmbientDcpo : IsDcpo (FunctionSpace X E) :=
    isDcpo_of_codomain hE
  have hMapsOpen : ScottOpen (mapsInto (X := X) U) :=
    mapsInto_scottOpen hX hE hU
  have hMapsNonempty : (mapsInto (X := X) U).Nonempty := by
    rcases hUNonempty with ⟨u, huU⟩
    exact ⟨FunctionSpace.const u, fun _ ↦ huU⟩
  have hMapsDcpo := scottOpenSubtype_isDcpo
    hAmbientDcpo hMapsOpen hMapsNonempty
  have hMapsContinuous := scottOpenSubtype_isContinuous
    hAmbientDcpo hAmbientContinuous hMapsOpen hMapsNonempty
  have hMapsCoherent := scottOpenSubtype_isCoherent
    hAmbientDcpo hAmbientCoherent hMapsOpen hMapsNonempty
  have hPair := openCodomainRetract (X := X) hE hU
  have hCore := coherent_continuous_dcpo_of_continuous_retract
    hPair hMapsDcpo hMapsContinuous hMapsCoherent
  exact hCore

end FunctionSpace

/-- Source item `cor:coherent-function-space`. -/
theorem cor_coherent_function_space
    {R D : Type u} [PartialOrder R] [PartialOrder D]
    [Nonempty R] [Nonempty D]
    (hR : IsRBDomain R)
    (hDdcpo : IsDcpo D)
    (hDcontinuous : AbramskyJung.Chapter3.IsContinuousDomain D)
    (hDcoherent : IsCoherent D) :
    IsCoherent (FunctionSpace R D) ∧
      IsDcpo (FunctionSpace R D) ∧
      AbramskyJung.Chapter3.IsContinuousDomain (FunctionSpace R D) := by
  have hLiftDcpo : IsDcpo (Lifting D) := lifting_isDcpo hDdcpo
  have hLiftContinuous :
      AbramskyJung.Chapter3.IsContinuousDomain (Lifting D) :=
    lifting_isContinuous hDcontinuous
  have hLiftLawson :
      AbramskyJung.Chapter4.IsLawsonCompact
        (asOrderedDomain (Lifting D)) :=
    lifting_isLawsonCompact hDdcpo hDcontinuous hDcoherent
  have hAmbient := (thm_continuous_function_spaces
    (D := Lifting D) (R := R)
    hLiftDcpo hLiftContinuous hLiftLawson hR).1
  have hAmbientCoherent : IsCoherent (FunctionSpace R (Lifting D)) :=
    ((continuous_lawsonCompact_iff_scottCompact_and_coherent_proved
      hAmbient.2.1 hAmbient.2.2).1 hAmbient.1).2
  have hOpenResult := FunctionSpace.openCodomain_coherent_continuous
    (X := R) (E := Lifting D)
    (rbDomain_scottCompact hR) hLiftDcpo
    hAmbient.2.2 hAmbientCoherent
    (U := liftingNonbot D) liftingNonbot_scottOpen (by
      let d : D := Classical.choice (inferInstance : Nonempty D)
      exact ⟨(d : Lifting D), WithBot.coe_ne_bot⟩)
  have hNonbotDcpo : IsDcpo (liftingNonbot D) :=
    scottOpenSubtype_isDcpo hLiftDcpo liftingNonbot_scottOpen (by
      let d : D := Classical.choice (inferInstance : Nonempty D)
      exact ⟨(d : Lifting D), WithBot.coe_ne_bot⟩)
  let sr := FunctionSpace.continuousRetract
    (D := R) (A := R) (E := D) (B := liftingNonbot D)
    hDdcpo hNonbotDcpo (FunctionSpace.identityRetract R)
      (baseLiftingNonbotRetract hDdcpo)
  exact coherent_continuous_dcpo_of_continuous_retract
    sr hOpenResult.2.1 hOpenResult.2.2 hOpenResult.1

/-! ## Pointed extension and restriction -/

namespace FunctionSpace

variable {D R : Type u} [PartialOrder D] [PartialOrder R] [OrderBot R]

/-- Extend a continuous map to the lifting by sending the fresh bottom to the
least point of the codomain. -/
def bottomExtend (f : FunctionSpace D R) : FunctionSpace (Lifting D) R :=
  ⟨{ toFun := fun x ↦
       match x with
       | ⊥ => ⊥
       | (x : D) => f x
     continuous := by
       constructor
       · intro x y hxy
         cases x using WithBot.recBotCoe with
         | bot => exact bot_le
         | coe x =>
             cases y using WithBot.recBotCoe with
             | bot => exact (WithBot.not_coe_le_bot x hxy).elim
             | coe y =>
                 exact f.toContFun.continuous.1
                   (WithBot.coe_le_coe.mp hxy)
       · intro A s hA hs
         cases s using WithBot.recBotCoe with
         | bot =>
             have hAllBot : ∀ x ∈ A, x = (⊥ : Lifting D) := by
               intro x hxA
               exact le_antisymm (hs.1 hxA) bot_le
             constructor
             · rintro _ ⟨x, hxA, rfl⟩
               rw [hAllBot x hxA]
             · intro q _hq
               exact bot_le
         | coe s =>
             have hBase := liftingBasePart_directed_isSup hA hs
             have hfSup := f.toContFun.continuous.2 hBase.1 hBase.2
             constructor
             · rintro _ ⟨x, hxA, rfl⟩
               cases x using WithBot.recBotCoe with
               | bot => exact bot_le
               | coe x => exact hfSup.1 ⟨x, hxA, rfl⟩
             · intro q hq
               exact hfSup.2 q (by
                 rintro _ ⟨x, hxBase, rfl⟩
                 exact hq ⟨(x : Lifting D), hxBase, rfl⟩) }⟩

/-- Restriction along the canonical inclusion `D → D⊥`. -/
def bottomRestrict (g : FunctionSpace (Lifting D) R) :
    FunctionSpace D R :=
  FunctionSpace.comp g
    ⟨{ toFun := fun x : D ↦ (x : Lifting D)
       continuous := lifting_up_scottContinuous }⟩

@[simp]
theorem bottomRestrict_extend (f : FunctionSpace D R) :
    bottomRestrict (bottomExtend f) = f := by
  apply FunctionSpace.ext
  intro x
  rfl

theorem bottomExtend_scottContinuous
    (hR : IsDcpo R) :
    Chapter2.ScottContinuous
      (bottomExtend : FunctionSpace D R → FunctionSpace (Lifting D) R) := by
  constructor
  · intro f g hfg x
    cases x using WithBot.recBotCoe with
    | bot => exact le_rfl
    | coe x => exact hfg x
  · intro G s hG hs
    constructor
    · rintro _ ⟨f, hfG, rfl⟩
      intro x
      cases x using WithBot.recBotCoe with
      | bot => exact le_rfl
      | coe x => exact hs.1 hfG x
    · intro q hq
      let qRes : FunctionSpace D R := bottomRestrict q
      have hsle : s ≤ qRes := hs.2 qRes (by
        intro f hfG x
        exact hq ⟨f, hfG, rfl⟩ (x : Lifting D))
      intro x
      cases x using WithBot.recBotCoe with
      | bot => exact bot_le
      | coe x => exact hsle x

theorem bottomRestrict_scottContinuous
    (hR : IsDcpo R) :
    Chapter2.ScottContinuous
      (bottomRestrict : FunctionSpace (Lifting D) R → FunctionSpace D R) :=
  precompose_scottContinuous (F := R) hR
    ⟨{ toFun := fun x : D ↦ (x : Lifting D)
       continuous := lifting_up_scottContinuous }⟩

/-- Extension and restriction form the retraction used in
`cor:pointed-function-space`. -/
def bottomFunctionRetract
    (hR : IsDcpo R) :
    AbramskyJung.Chapter3.ContinuousSectionRetractionPair
      (FunctionSpace D R) (FunctionSpace (Lifting D) R) where
  s := bottomExtend
  r := bottomRestrict
  monotone_s := (bottomExtend_scottContinuous hR).1
  monotone_r := (bottomRestrict_scottContinuous hR).1
  retract := bottomRestrict_extend
  continuous_s := bottomExtend_scottContinuous hR
  continuous_r := bottomRestrict_scottContinuous hR

end FunctionSpace

/-- Source item `cor:pointed-function-space`. -/
theorem cor_pointed_function_space
    {D R : Type u} [PartialOrder D] [PartialOrder R]
    [Nonempty D] [Nonempty R] [OrderBot R]
    (hDdcpo : IsDcpo D)
    (hDcontinuous : AbramskyJung.Chapter3.IsContinuousDomain D)
    (hDcoherent : IsCoherent D)
    (hR : IsRBDomain R) :
    IsRBDomain (FunctionSpace D R) := by
  have hLiftDcpo : IsDcpo (Lifting D) := lifting_isDcpo hDdcpo
  have hLiftContinuous :
      AbramskyJung.Chapter3.IsContinuousDomain (Lifting D) :=
    lifting_isContinuous hDcontinuous
  have hLiftLawson :
      AbramskyJung.Chapter4.IsLawsonCompact
        (asOrderedDomain (Lifting D)) :=
    lifting_isLawsonCompact hDdcpo hDcontinuous hDcoherent
  have hAmbientRB := (thm_continuous_function_spaces
    (D := Lifting D) (R := R)
    hLiftDcpo hLiftContinuous hLiftLawson hR).2
  have hRdcpo := (rbDomain_dcpo_continuous hR).1
  exact rbDomain_of_continuous_retract
    (FunctionSpace.bottomFunctionRetract (D := D) hRdcpo) hAmbientRB

end

end CoherentContinuousAlgebraicRetracts
