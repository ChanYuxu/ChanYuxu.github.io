import Mathlib.Data.Set.Card
import CoherentContinuousAlgebraicRetracts.FunctionSpaceCore
import CoherentContinuousAlgebraicRetracts.KernelApproximations

/-!
# Finite-image kernels for a finite, possibly unpointed codomain

We specialize the labelled-step refinement method to compact principal
opens. A pair with incomparable output labels is resolved at a compact MUB
of the input labels. Every new output label is strictly above its parents,
so iteration stops uniformly by the height of the finite output poset.
-/

set_option autoImplicit false
set_option linter.unnecessarySimpa false
set_option maxHeartbeats 1800000

universe u

namespace CoherentContinuousAlgebraicRetracts
namespace FiniteCodomain

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

variable {A B : Type u} [PartialOrder A] [PartialOrder B] [Finite B]

abbrev Step (A B : Type u) [PartialOrder A] := CompactBasis A × B

def liftPair (p q : Step A B) : Set (Step A B) :=
  {r | r.1 ∈ MinimalUpperBounds ({p.1, q.1} : Set (CompactBasis A)) ∧
    p.2 < r.2 ∧ q.2 < r.2}

def grow (S : Set (Step A B)) : Set (Step A B) :=
  S ∪ ⋃ p ∈ S, ⋃ q ∈ S, liftPair p q

theorem grow_mono {S T : Set (Step A B)} (h : S ⊆ T) : grow S ⊆ grow T := by
  intro r hr
  rcases hr with hr | hr
  · exact Or.inl (h hr)
  · simp only [Set.mem_iUnion] at hr
    obtain ⟨p, hp, q, hq, hr⟩ := hr
    apply Or.inr
    simp only [Set.mem_iUnion]
    exact ⟨p, h hp, q, h hq, hr⟩

theorem grow_finite
    (hM : HasPropertyM (CompactBasis A)) {S : Set (Step A B)} (hS : S.Finite) :
    (grow S).Finite := by
  apply hS.union
  apply hS.biUnion
  intro p _
  apply hS.biUnion
  intro q _
  exact ((hM.2 _ (by simp)).prod (Set.finite_univ (α := B))).subset
    (fun r hr ↦ ⟨hr.1, Set.mem_univ r.2⟩)

def iterate (S : Set (Step A B)) : Nat → Set (Step A B)
  | 0 => S
  | n + 1 => grow (iterate S n)

theorem iterate_increasing (S : Set (Step A B)) : Monotone (iterate S) :=
  monotone_nat_of_le_succ (fun _ ↦ Set.subset_union_left)

theorem iterate_seed_mono {S T : Set (Step A B)} (h : S ⊆ T) (n : Nat) :
    iterate S n ⊆ iterate T n := by
  induction n with
  | zero => exact h
  | succ n ih => exact grow_mono ih

def labelRank (b : B) : Nat := (Set.Iic b).ncard

theorem labelRank_lt {a b : B} (h : a < b) : labelRank a < labelRank b := by
  apply Set.ncard_lt_ncard (ht := Set.toFinite _)
  refine Set.ssubset_iff_subset_ne.2 ⟨fun x hx ↦ le_trans hx h.le, ?_⟩
  intro hEq
  have : b ∈ Set.Iic a := hEq.symm ▸ (show b ∈ Set.Iic b from le_rfl)
  exact h.not_ge this

theorem labelRank_le (b : B) : labelRank b ≤ (Set.univ : Set B).ncard :=
  Set.ncard_mono (Set.subset_univ _)

theorem mem_iterate_at_labelRank (S : Set (Step A B)) {r : Step A B}
    {n : Nat} (hr : r ∈ iterate S n) : r ∈ iterate S (labelRank r.2) := by
  induction n generalizing r with
  | zero => exact iterate_increasing S (Nat.zero_le _) hr
  | succ n ih =>
    change r ∈ grow (iterate S n) at hr
    rcases hr with hr | hr
    · exact ih hr
    · simp only [Set.mem_iUnion] at hr
      obtain ⟨p, hp, q, hq, hLift⟩ := hr
      let m := max (labelRank p.2) (labelRank q.2)
      have hm : m + 1 ≤ labelRank r.2 :=
        Nat.succ_le_of_lt (max_lt (labelRank_lt hLift.2.1) (labelRank_lt hLift.2.2))
      apply iterate_increasing S hm
      apply Or.inr
      simp only [Set.mem_iUnion]
      exact ⟨p, iterate_increasing S (Nat.le_max_left _ _) (ih hp),
        q, iterate_increasing S (Nat.le_max_right _ _) (ih hq), hLift⟩

/-- Closure of a seed set under strict output lifts. -/
def closedPalette (S : Set (Step A B)) : Set (Step A B) :=
  iterate S (Set.univ : Set B).ncard

theorem closedPalette_finite (hM : HasPropertyM (CompactBasis A))
    {S : Set (Step A B)} (hS : S.Finite) : (closedPalette S).Finite := by
  have hIter : ∀ n, (iterate S n).Finite := by
    intro n
    induction n with
    | zero => exact hS
    | succ n ih => exact grow_finite hM ih
  exact hIter _

theorem closedPalette_lift {S : Set (Step A B)} {p q r : Step A B}
    (hp : p ∈ closedPalette S) (hq : q ∈ closedPalette S) (hr : r ∈ liftPair p q) :
    r ∈ closedPalette S := by
  have hNext : r ∈ iterate S ((Set.univ : Set B).ncard + 1) := Or.inr (by
    simp only [Set.mem_iUnion]
    exact ⟨p, hp, q, hq, hr⟩)
  exact iterate_increasing S (labelRank_le r.2) (mem_iterate_at_labelRank S hNext)

theorem subset_closedPalette (S : Set (Step A B)) : S ⊆ closedPalette S :=
  iterate_increasing S (Nat.zero_le _)

/-- Include every label at every compact minimal element; this ensures
nonempty active values without assuming an output bottom. -/
def baseSteps (A B : Type u) [PartialOrder A] : Set (Step A B) :=
  MinimalUpperBounds (∅ : Set (CompactBasis A)) ×ˢ (Set.univ : Set B)

def palette (S : Set (Step A B)) := closedPalette (baseSteps A B ∪ S)

theorem palette_mono {S T : Set (Step A B)} (h : S ⊆ T) : palette S ⊆ palette T :=
  iterate_seed_mono (Set.union_subset_union_right _ h) _

theorem seed_mem_palette {S : Set (Step A B)} {p : Step A B} (hp : p ∈ S) :
    p ∈ palette S :=
  subset_closedPalette _ (Or.inr hp)

def values (C : Set (Step A B)) (f : FunctionSpace A B) (x : A) : Set B :=
  {b | ∃ p ∈ C, p.1.1 ≤ x ∧ p.2 ≤ f p.1.1 ∧ p.2 = b}

theorem values_directed (hAlg : Chapter3.IsAlgebraicDomain A)
    (hM : HasPropertyM (CompactBasis A)) (S : Set (Step A B))
    (f : FunctionSpace A B) (x : A) : DirectedSet (values (palette S) f x) := by
  constructor
  · obtain ⟨m, hm, hmx⟩ := exists_compact_mub_le hAlg Set.finite_empty
      (hM.1 ∅ Set.finite_empty) (x := x) (by simp)
    exact ⟨f m.1, (m, f m.1), subset_closedPalette _ (Or.inl ⟨hm, Set.mem_univ _⟩),
      hmx, le_rfl, rfl⟩
  · rintro _ ⟨p, hp, hpx, hpf, rfl⟩ _ ⟨q, hq, hqx, hqf, rfl⟩
    by_cases hpq : p.2 ≤ q.2
    · exact ⟨q.2, ⟨q, hq, hqx, hqf, rfl⟩, hpq, le_rfl⟩
    by_cases hqp : q.2 ≤ p.2
    · exact ⟨p.2, ⟨p, hp, hpx, hpf, rfl⟩, le_rfl, hqp⟩
    let H : Set (CompactBasis A) := {p.1, q.1}
    have hH : H.Finite := by simp [H]
    obtain ⟨a, ha, hax⟩ := exists_compact_mub_le hAlg hH (hM.1 H hH) (x := x) (by
      intro k hk
      rcases Set.mem_insert_iff.mp hk with rfl | hk
      · exact hpx
      · have heq : k = q.1 := by simpa using hk
        exact heq ▸ hqx)
    have hpfa : p.2 ≤ f a.1 :=
      le_trans hpf (f.toContFun.continuous.1 (show p.1.1 ≤ a.1 from ha.1 (by simp [H])))
    have hqfa : q.2 ≤ f a.1 :=
      le_trans hqf (f.toContFun.continuous.1 (show q.1.1 ≤ a.1 from ha.1 (by simp [H])))
    have hpStrict : p.2 < f a.1 := lt_of_le_not_ge hpfa (fun h ↦ hqp (le_trans hqfa h))
    have hqStrict : q.2 < f a.1 := lt_of_le_not_ge hqfa (fun h ↦ hpq (le_trans hpfa h))
    exact ⟨f a.1, ⟨(a, f a.1), closedPalette_lift hp hq ⟨ha, hpStrict, hqStrict⟩,
      hax, le_rfl, rfl⟩, hpfa, hqfa⟩

variable (hAlg : Chapter3.IsAlgebraicDomain A) (hM : HasPropertyM (CompactBasis A))

def approximateValue (S : Set (Step A B)) (f : FunctionSpace A B) (x : A) : B :=
  Classical.choose (exists_greatest_of_finite_directed (Set.toFinite _)
    (values_directed hAlg hM S f x))

theorem approximateValue_spec (S : Set (Step A B)) (f : FunctionSpace A B) (x : A) :
    approximateValue hAlg hM S f x ∈ values (palette S) f x ∧
      ∀ y ∈ values (palette S) f x, y ≤ approximateValue hAlg hM S f x :=
  Classical.choose_spec (exists_greatest_of_finite_directed (Set.toFinite _)
    (values_directed hAlg hM S f x))

theorem approximateValue_le (S : Set (Step A B)) (f : FunctionSpace A B) (x : A) :
    approximateValue hAlg hM S f x ≤ f x := by
  obtain ⟨p, hp, hpx, hpf, heq⟩ := (approximateValue_spec hAlg hM S f x).1
  exact heq ▸ le_trans hpf (f.toContFun.continuous.1 hpx)

theorem approximateValue_le_of_subset {S T : Set (Step A B)} {f g : FunctionSpace A B}
    {x y : A} (hST : S ⊆ T) (hfg : f ≤ g) (hxy : x ≤ y) :
    approximateValue hAlg hM S f x ≤ approximateValue hAlg hM T g y := by
  obtain ⟨p, hp, hpx, hpf, heq⟩ := (approximateValue_spec hAlg hM S f x).1
  exact (approximateValue_spec hAlg hM T g y).2 _
    ⟨p, palette_mono hST hp, le_trans hpx hxy, le_trans hpf (hfg _), heq⟩

/-- Largest value of all applicable active labels. Scott continuity in the
input uses compactness of the input label. -/
def truncate (S : Set (Step A B)) (f : FunctionSpace A B) : FunctionSpace A B :=
  ⟨⟨approximateValue hAlg hM S f, by
    have hMono : Monotone (approximateValue hAlg hM S f) :=
      fun _ _ hxy ↦ approximateValue_le_of_subset hAlg hM
        Set.Subset.rfl le_rfl hxy
    refine ⟨hMono, ?_⟩
    intro G s hG hs
    constructor
    · rintro _ ⟨x, hx, rfl⟩
      exact hMono (hs.1 hx)
    · intro y hy
      obtain ⟨p, hp, hps, hpf, heq⟩ := (approximateValue_spec hAlg hM S f s).1
      obtain ⟨x, hx, hpx⟩ := p.1.2 hG hs hps
      exact le_trans ((approximateValue_spec hAlg hM S f x).2 _
        ⟨p, hp, hpx, hpf, heq⟩) (hy ⟨x, hx, rfl⟩)⟩⟩

@[simp] theorem truncate_apply (S : Set (Step A B)) (f : FunctionSpace A B) (x : A) :
    truncate hAlg hM S f x = approximateValue hAlg hM S f x := rfl

theorem truncate_below (S : Set (Step A B)) (f : FunctionSpace A B) :
    truncate hAlg hM S f ≤ f :=
  approximateValue_le hAlg hM S f

theorem active_retained {S : Set (Step A B)} (f : FunctionSpace A B)
    {p : Step A B} (hp : p ∈ palette S) (hpf : p.2 ≤ f p.1.1) :
    p.2 ≤ truncate hAlg hM S f p.1.1 :=
  (approximateValue_spec hAlg hM S f p.1.1).2 _ ⟨p, hp, le_rfl, hpf, rfl⟩

/-- Scott continuity in the function argument uses compactness of every
output label in the finite codomain. -/
theorem truncate_scottContinuous (S : Set (Step A B)) :
    Chapter2.ScottContinuous (truncate hAlg hM S) := by
  have hMono : Monotone (truncate hAlg hM S) :=
    fun _ _ hfg x ↦ approximateValue_le_of_subset hAlg hM Set.Subset.rfl hfg le_rfl
  refine ⟨hMono, ?_⟩
  intro G s hG hs
  constructor
  · rintro _ ⟨f, hf, rfl⟩
    exact hMono (hs.1 hf)
  · intro g hg x
    obtain ⟨p, hp, hpx, hps, heq⟩ := (approximateValue_spec hAlg hM S s x).1
    have hEvalDir : DirectedSet ((fun f : FunctionSpace A B ↦ f p.1.1) '' G) :=
      DirectedSet.image (fun f g h ↦ (show f ≤ g from h) p.1.1) hG
    obtain ⟨_, ⟨f, hf, rfl⟩, hpf⟩ := (finite_poset_compact p.2) hEvalDir
      (FunctionSpace.isSup_apply finite_poset_isDcpo hG hs p.1.1) hps
    exact le_trans ((approximateValue_spec hAlg hM S f x).2 _
      ⟨p, hp, hpx, hpf, heq⟩) (hg ⟨f, hf, rfl⟩ x)

def kernel (S : Set (Step A B)) : Chapter3.KernelOperator (FunctionSpace A B) where
  k := truncate hAlg hM S
  continuous := truncate_scottContinuous hAlg hM S
  idem := fun f ↦ by
    apply le_antisymm (truncate_below hAlg hM S _)
    intro x
    obtain ⟨p, hp, hpx, hpf, heq⟩ := (approximateValue_spec hAlg hM S f x).1
    exact (approximateValue_spec hAlg hM S (truncate hAlg hM S f) x).2 _
      ⟨p, hp, hpx, active_retained hAlg hM f hp hpf, heq⟩
  below := truncate_below hAlg hM S

theorem kernel_finite_range {S : Set (Step A B)} (hS : S.Finite) :
    (Set.range (kernel hAlg hM S).k).Finite := by
  let k := kernel hAlg hM S
  let C := palette S
  let active (f : FunctionSpace A B) : Set (Step A B) :=
    {p | p ∈ C ∧ p.2 ≤ f p.1.1}
  have hCf := closedPalette_finite hM ((hM.2 ∅ Set.finite_empty).prod
    (Set.finite_univ (α := B)) |>.union hS)
  apply Set.Finite.of_finite_image (f := active)
  · apply hCf.finite_subsets.subset
    rintro _ ⟨f, _, rfl⟩ p hp
    exact hp.1
  · intro f hf g hg hfg
    have hEq : k.k f = k.k g := by
      apply FunctionSpace.ext
      intro x
      apply le_antisymm
      · obtain ⟨p, hp, hpx, hpf, heq⟩ := (approximateValue_spec hAlg hM S f x).1
        have hpG : p ∈ active g := hfg ▸ (show p ∈ active f from ⟨hp, hpf⟩)
        exact (approximateValue_spec hAlg hM S g x).2 _ ⟨p, hp, hpx, hpG.2, heq⟩
      · obtain ⟨p, hp, hpx, hpg, heq⟩ := (approximateValue_spec hAlg hM S g x).1
        have hpF : p ∈ active f := hfg.symm ▸ (show p ∈ active g from ⟨hp, hpg⟩)
        exact (approximateValue_spec hAlg hM S f x).2 _ ⟨p, hp, hpx, hpF.2, heq⟩
    rw [(k.mem_range_iff_fixed).1 hf, (k.mem_range_iff_fixed).1 hg] at hEq
    exact hEq

/-- A finite codomain gives bifiniteness without a pointedness hypothesis. -/
def functionSpace_bifinite : UnpointedBifinite (FunctionSpace A B) := by
  let I := {S : Set (Step A B) // S.Finite}
  let proj (s : I) := kernel hAlg hM s.1
  have hLe {s t : I} (hst : s.1 ⊆ t.1) : proj s ≤ proj t :=
    fun f x ↦ approximateValue_le_of_subset hAlg hM hst le_rfl le_rfl
  letI : Nonempty I := ⟨⟨∅, Set.finite_empty⟩⟩
  let F : KernelApproximation (FunctionSpace A B) :=
    KernelApproximation.ofIndexed proj (by
      intro s t
      exact ⟨⟨s.1 ∪ t.1, s.2.union t.2⟩, hLe Set.subset_union_left,
        hLe Set.subset_union_right⟩) (by
      intro f
      constructor
      · rintro _ ⟨s, rfl⟩
        exact (proj s).below f
      · intro g hg x
        have hBasis := hAlg x
        have hFinite : Compact (f x) := finite_poset_compact (f x)
        have hSup := f.toContFun.continuous.2 hBasis.1 hBasis.2
        have hDir := DirectedSet.image f.toContFun.continuous.1 hBasis.1
        obtain ⟨_, ⟨a, ha, rfl⟩, hfa⟩ := hFinite hDir hSup le_rfl
        let p : Step A B := (⟨a, ha.1⟩, f a)
        let s : I := ⟨{p}, Set.finite_singleton p⟩
        exact le_trans hfa (le_trans ((approximateValue_spec hAlg hM s.1 f x).2 _
          ⟨p, seed_mem_palette (Set.mem_singleton p), prop_2_2_2_1 ha.2, le_rfl, rfl⟩)
          (hg ⟨s, rfl⟩ x)))
  have hFin : ∀ k ∈ F.operators, (Set.range k.k).Finite := by
    rintro _ ⟨s, rfl⟩
    exact kernel_finite_range hAlg hM s.2
  refine
    { dcpo := FunctionSpace.isDcpo_of_codomain finite_poset_isDcpo
      algebraic := F.algebraic (fun k hk ↦ finiteKernel_image_algebraic k (hFin k hk))
      operators := F.operators
      operators_nonempty := F.directed.1
      finite_image := hFin
      directed := ?_
      approximates := ?_ }
  · intro p hp q hq
    obtain ⟨r, hr, hpr, hqr⟩ := F.directed.2 hp hq
    exact ⟨r, hr, fun x ↦ ⟨hpr x, hqr x⟩⟩
  · intro f
    have hEq : {g : FunctionSpace A B | ∃ k ∈ F.operators, g = k.k f} =
        (fun k : Chapter3.KernelOperator (FunctionSpace A B) ↦ k.k f) '' F.operators := by
      ext g
      simp only [Set.mem_setOf_eq, Set.mem_image]
      exact exists_congr (fun _ ↦ and_congr_right (fun _ ↦ eq_comm))
    rw [hEq]
    exact F.supremum f

end

end FiniteCodomain
end CoherentContinuousAlgebraicRetracts
