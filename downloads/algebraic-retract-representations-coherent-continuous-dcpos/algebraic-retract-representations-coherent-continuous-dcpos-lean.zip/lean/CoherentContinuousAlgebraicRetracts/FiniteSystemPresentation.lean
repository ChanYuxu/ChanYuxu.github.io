import CoherentContinuousAlgebraicRetracts.FiniteSystems
import Practice.DomainTheory.Papers.CoherentContinuousRetracts.RefinementInterface
import Practice.DomainTheory.Papers.CoherentContinuousRetracts.FiniteMUB

/-!
# The finite-system presentation

This file implements the construction from `def:approximating-poset` through
`prop:constructed-retraction` in source SHA-256
`e6af94a9b81f5546fd03a5553bcb16f8958f9daa62bbba1dc6d1984a74f6ac6a`.
-/

set_option autoImplicit false
set_option maxHeartbeats 1200000

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

variable {D : Type u} [PartialOrder D]
variable {B : Set D}

local instance : DecidableEq (BasisPair B) := Classical.decEq _

/-! ## Fixed finite choices -/

/-- The fixed finite family `Φ(E)` and the two properties used by the finite
system construction. -/
structure CommonChoiceData (B : Set D) where
  Φ : Finset (BasisPair B) → Finset (BasisPair B)
  first_le : ∀ (E : Finset (BasisPair B)), E.Nonempty →
    ∀ q ∈ E, ∀ e ∈ Φ E, q.first.1 ≤ e.first.1
  covers : ∀ (E : Finset (BasisPair B)), E.Nonempty →
    commonPairOpen E ⊆
      Set.sUnion (BasisPair.openSet '' (Φ E : Set (BasisPair B)) : Set (Set D))
  singleton : ∀ e : BasisPair B, Φ {e} = {e}

private structure ChoiceWitness
    (E : Finset (BasisPair B)) where
  F : Finset (BasisPair B)
  first_le : E.Nonempty →
    ∀ q ∈ E, ∀ e ∈ F, q.first.1 ≤ e.first.1
  covers : E.Nonempty →
    commonPairOpen E ⊆
      Set.sUnion (BasisPair.openSet '' (F : Set (BasisPair B)) : Set (Set D))

private noncomputable def rawChoiceWitness
    (hB : IsBasis B) (hCoherent : IsCoherent D)
    (E : Finset (BasisPair B)) : ChoiceWitness E := by
  by_cases hE : E.Nonempty
  · let F : Set (BasisPair B) :=
      Classical.choose (finite_common_approximations hB hCoherent E hE)
    have hSpec :=
      Classical.choose_spec (finite_common_approximations hB hCoherent E hE)
    have hFfinite : F.Finite := hSpec.1
    have hFirst := hSpec.2.1
    have hCover := hSpec.2.2
    exact
      { F := hFfinite.toFinset
        first_le := by
          intro _ q hq e he
          apply hFirst q hq e
          exact (Set.Finite.mem_toFinset hFfinite).1 he
        covers := by
          intro _ x hx
          rcases Set.mem_sUnion.mp (hCover hx) with ⟨U, hU, hxU⟩
          rcases hU with ⟨e, heF, rfl⟩
          apply Set.mem_sUnion_of_mem hxU
          refine ⟨e, ?_, rfl⟩
          exact (Set.Finite.mem_toFinset hFfinite).2 heF }
  · exact
      { F := ∅
        first_le := fun h ↦ (hE h).elim
        covers := fun h ↦ (hE h).elim }

/-- Fix all finite output families simultaneously.  Singleton inputs use the
source's prescribed choice `{e}`. -/
def commonChoiceData
    (hB : IsBasis B) (hCoherent : IsCoherent D) :
    CommonChoiceData B where
  Φ E := if E.card = 1 then E else (rawChoiceWitness hB hCoherent E).F
  first_le E hE q hq e he := by
    by_cases hcard : E.card = 1
    · rcases Finset.card_eq_one.mp hcard with ⟨z, hz⟩
      subst E
      simp only [Finset.card_singleton, if_true] at he
      have hqz : q = z := by simpa using hq
      have hez : e = z := by simpa using he
      subst q
      subst e
      exact le_rfl
    · simp only [hcard, if_false] at he
      exact (rawChoiceWitness hB hCoherent E).first_le hE q hq e he
  covers E hE := by
    by_cases hcard : E.card = 1
    · rcases Finset.card_eq_one.mp hcard with ⟨e, rfl⟩
      intro x hx
      apply Set.mem_sUnion_of_mem (hx e (by simp))
      exact ⟨e, by simp, rfl⟩
    · simpa only [hcard, if_false] using
        (rawChoiceWitness hB hCoherent E).covers hE
  singleton e := by simp

namespace FiniteSystemPresentation

variable (C : CommonChoiceData B)

open FiniteSystems
open FiniteSystems.System

abbrev P := FiniteSystems.System C.Φ

/-! ## Source components `a_p` and `U_p` -/

/-- The full index subset `[n]`. -/
def fullIndex (p : P C) : Finset (Fin p.arity) := Finset.univ

/-- The source component `a_p`, the first coordinate at the full index set. -/
def approximant (p : P C) : D :=
  (p.label (fullIndex C p)).first.1

/-- The source open `U_p`, intersecting the opens of every nonempty
component of the system. -/
def validity (p : P C) : Set D :=
  {x | ∀ J : Finset (Fin p.arity), J.Nonempty →
    x ∈ (p.label J).openSet}

/-- `U_p` is Scott open: it is a finite intersection of component opens. -/
theorem validity_scottOpen (hB : IsBasis B) (p : P C) :
    ScottOpen (validity C p) := by
  letI : TopologicalSpace D := Chapter2.scottTopologicalSpace
  let I := {J : Finset (Fin p.arity) // J.Nonempty}
  have hOpen : IsOpen (⋂ J : I, (p.label J.1).openSet) :=
    isOpen_iInter_of_finite (fun J : I ↦
      BasisPair.openSet_scottOpen hB (p.label J.1))
  have hEq : validity C p = ⋂ J : I, (p.label J.1).openSet := by
    ext x
    simp only [validity, Set.mem_setOf_eq, Set.mem_iInter]
    constructor
    · intro hx J
      exact hx J.1 J.2
    · intro hx J hJ
      exact hx ⟨J, hJ⟩
  rw [hEq]
  exact hOpen

/-- The open `U_p` is contained in `WayUp a_p`. -/
theorem approximant_wayBelow_of_mem_validity
    (p : P C) {x : D} (hx : x ∈ validity C p) :
    approximant C p ≪ x := by
  have hFull : (fullIndex C p).Nonempty := by
    refine ⟨⟨0, p.positive⟩, Finset.mem_univ _⟩
  have hSecond : (p.label (fullIndex C p)).second.1 ≪ x :=
    hx (fullIndex C p) hFull
  exact prop_2_2_2_2 le_rfl
    (p.label (fullIndex C p)).first_wayBelow_second
    (prop_2_2_2_1 hSecond)

private theorem child_mem_children
    (p : P C) (J : Finset (Fin p.arity)) (j : Fin p.arity)
    (hj : j ∈ J) :
    p.label (J.erase j) ∈ children p.label J := by
  apply Finset.mem_image.mpr
  exact ⟨⟨j, hj⟩, Finset.mem_attach _ _, rfl⟩

/-- First coordinates increase with the subset index. -/
theorem component_first_mono
    (p : P C) {K J : Finset (Fin p.arity)}
    (hK : K.Nonempty) (hKJ : K ⊆ J) :
    (p.label K).first.1 ≤ (p.label J).first.1 := by
  classical
  by_cases hEq : K = J
  · subst K
    exact le_rfl
  · have hStrict : K ⊂ J :=
      Finset.ssubset_iff_subset_ne.mpr ⟨hKJ, hEq⟩
    rcases Finset.ssubset_iff_exists_subset_erase.mp hStrict with
      ⟨j, hjJ, hKErase⟩
    have hEraseNonempty : (J.erase j).Nonempty := hK.mono hKErase
    have hCardJ : 2 ≤ J.card := by
      have hCardErasePos : 0 < (J.erase j).card :=
        Finset.card_pos.mpr hEraseNonempty
      have hCardErase := Finset.card_erase_of_mem hjJ
      omega
    have hChildrenNonempty : (children p.label J).Nonempty :=
      ⟨p.label (J.erase j), child_mem_children C p J j hjJ⟩
    exact le_trans
      (component_first_mono p hK hKErase)
      (C.first_le (children p.label J) hChildrenNonempty
        (p.label (J.erase j)) (child_mem_children C p J j hjJ)
        (p.label J) (p.valid J hCardJ))
termination_by J.card
decreasing_by
  exact Finset.card_lt_card (Finset.erase_ssubset hjJ)

/-- The source monotonicity `p ≤ q → a_p ≤ a_q`. -/
theorem approximant_monotone : Monotone (approximant C) := by
  intro p q hpq
  rcases hpq with ⟨f, hf⟩
  let K : Finset (Fin q.arity) :=
    mapSubset f.toEmbedding (fullIndex C p)
  have hKNonempty : K.Nonempty := by
    exact @Finset.Nonempty.map _ _ f.toEmbedding _
      ⟨⟨0, p.positive⟩, Finset.mem_univ _⟩
  have hKFull : K ⊆ fullIndex C q := Finset.subset_univ K
  calc
    approximant C p = (q.label K).first.1 := by
      exact congrArg (fun e : BasisPair B ↦ e.first.1)
        (hf (fullIndex C p)
          ⟨⟨0, p.positive⟩, Finset.mem_univ _⟩)
    _ ≤ (q.label (fullIndex C q)).first.1 :=
      component_first_mono C q hKNonempty hKFull
    _ = approximant C q := rfl

/-- The source antitonicity `p ≤ q → U_q ⊆ U_p`. -/
theorem validity_antitone {p q : P C} (hpq : p ≤ q) :
    validity C q ⊆ validity C p := by
  rcases hpq with ⟨f, hf⟩
  intro x hx J hJ
  have hMapNonempty : (mapSubset f.toEmbedding J).Nonempty :=
    @Finset.Nonempty.map _ _ f.toEmbedding J hJ
  rw [hf J hJ]
  exact hx (mapSubset f.toEmbedding J) hMapNonempty

/-! ## Lower finiteness -/

private theorem eq_reindex_of_labels
    (p q : P C) (f : Fin p.arity ↪o Fin q.arity)
    (hf : ∀ J : Finset (Fin p.arity), J.Nonempty →
      p.label J = q.label (mapSubset f.toEmbedding J)) :
    p = q.reindex p.positive f := by
  refine FiniteSystems.System.ext (p := p)
    (q := q.reindex p.positive f) rfl ?_
  apply heq_of_eq
  funext J
  change Finset (Fin p.arity) at J
  by_cases hJ : J.Nonempty
  · exact (hf J hJ).trans
      (FiniteSystems.System.reindex_label q p.positive f J hJ).symm
  · have hEmpty : J = ∅ := Finset.not_nonempty_iff_eq_empty.mp hJ
    subst J
    calc
      p.label ∅ = p.label {⟨0, p.positive⟩} := p.empty_normalized
      _ = q.label (mapSubset f.toEmbedding {⟨0, p.positive⟩}) :=
        hf {⟨0, p.positive⟩} (by simp)
      _ = (q.reindex p.positive f).label {⟨0, p.positive⟩} :=
        (FiniteSystems.System.reindex_label q p.positive f _ (by simp)).symm
      _ = (q.reindex p.positive f).label ∅ :=
        (q.reindex p.positive f).empty_normalized.symm

/-- A finite code for a nonempty increasing embedding into `Fin n`. -/
structure RestrictionIndex (n : ℕ) where
  source : Fin (n + 1)
  positive : 0 < source.1
  embedding : Fin source.1 ↪o Fin n
deriving Fintype

/-- Every predecessor is the restriction to a nonempty subset of the finite
index set, so the system poset is lower finite. -/
theorem lower_finite : IsLowerFinite (P C) := by
  intro p
  let restriction : RestrictionIndex p.arity → P C :=
    fun i ↦ p.reindex i.positive i.embedding
  refine (Set.finite_range restriction).subset ?_
  intro q hq
  rcases hq with ⟨p', hp', hqp'⟩
  have hp'Eq : p' = p := by simpa using hp'
  subst p'
  rcases hqp' with ⟨f, hf⟩
  have hArityLe : q.arity ≤ p.arity := by
    simpa using Fintype.card_le_of_injective f f.injective
  let i : RestrictionIndex p.arity :=
    { source := ⟨q.arity, by omega⟩
      positive := q.positive
      embedding := f }
  apply Set.mem_range.mpr
  refine ⟨i, ?_⟩
  change p.reindex q.positive f = q
  have hq : q = p.reindex q.positive f :=
    eq_reindex_of_labels C q p f hf
  exact hq.symm

/-! ## Finiteness of bounded systems -/

/-- The finite set of possible labels at a fixed subset cardinality. -/
def labelLevel (S : Finset (BasisPair B)) : ℕ → Finset (BasisPair B)
  | 0 => ∅
  | 1 => S
  | n + 2 => (labelLevel S (n + 1)).powerset.biUnion C.Φ

/-- Every nonempty component belongs to the recursively generated finite
level determined by its cardinality. -/
theorem label_mem_level
    (p : P C) (S : Finset (BasisPair B))
    (hSingleton : ∀ i : Fin p.arity, p.label {i} ∈ S)
    (J : Finset (Fin p.arity)) (hJ : J.Nonempty) :
    p.label J ∈ labelLevel C S J.card := by
  classical
  by_cases hOne : J.card = 1
  · rcases Finset.card_eq_one.mp hOne with ⟨i, rfl⟩
    simpa [labelLevel] using hSingleton i
  · have hTwo : 2 ≤ J.card := by
      have hPos : 0 < J.card := Finset.card_pos.mpr hJ
      omega
    obtain ⟨n, hn⟩ : ∃ n, J.card = n + 2 := by
      exact ⟨J.card - 2, by omega⟩
    rw [hn, labelLevel]
    apply Finset.mem_biUnion.mpr
    refine ⟨children p.label J, ?_, p.valid J hTwo⟩
    rw [Finset.mem_powerset]
    intro e he
    rcases Finset.mem_image.mp he with ⟨j, _hjAttach, rfl⟩
    have hjJ : j.1 ∈ J := j.2
    have hEraseNonempty : (J.erase j.1).Nonempty := by
      rw [Finset.nonempty_iff_ne_empty]
      intro hEmpty
      have hEraseCard : (J.erase j.1).card = 0 := by simp [hEmpty]
      have hCard := Finset.card_erase_of_mem hjJ
      omega
    have hrec := label_mem_level p S hSingleton
      (J.erase j.1) hEraseNonempty
    have hCardErase := Finset.card_erase_of_mem hjJ
    rw [hCardErase, hn] at hrec
    simpa using hrec
termination_by J.card
decreasing_by
  exact Finset.card_lt_card (Finset.erase_ssubset j.2)

/-- All levels up to `N`, a single finite set containing every component of a
bounded system. -/
def labelsUpTo (S : Finset (BasisPair B)) (N : ℕ) :
    Finset (BasisPair B) :=
  (Finset.range (N + 1)).biUnion (labelLevel C S)

theorem label_mem_labelsUpTo
    (p : P C) (S : Finset (BasisPair B)) (N : ℕ)
    (hN : p.arity ≤ N)
    (hSingleton : ∀ i : Fin p.arity, p.label {i} ∈ S)
    (J : Finset (Fin p.arity)) :
    p.label J ∈ labelsUpTo C S N := by
  classical
  by_cases hJ : J.Nonempty
  · apply Finset.mem_biUnion.mpr
    refine ⟨J.card, ?_, label_mem_level C p S hSingleton J hJ⟩
    rw [Finset.mem_range]
    have hCard : J.card ≤ p.arity := by
      simpa using Finset.card_le_card (Finset.subset_univ J)
    omega
  · have hEmpty : J = ∅ := Finset.not_nonempty_iff_eq_empty.mp hJ
    subst J
    rw [p.empty_normalized]
    apply Finset.mem_biUnion.mpr
    refine ⟨1, ?_, ?_⟩
    · rw [Finset.mem_range]
      exact Nat.succ_lt_succ (lt_of_lt_of_le p.positive hN)
    · simpa [labelLevel] using hSingleton ⟨0, p.positive⟩

/-- A finite ambient code for systems whose arity and labels are bounded. -/
structure BoundedSystemCode
    (N : ℕ) (A : Finset (BasisPair B)) where
  arity : Fin (N + 1)
  labels : Finset (Fin N) → Option {e : BasisPair B // e ∈ A}

noncomputable instance (N : ℕ) (A : Finset (BasisPair B)) :
    Fintype (BoundedSystemCode (B := B) N A) := by
  letI : Fintype {e : BasisPair B // e ∈ A} :=
    Fintype.ofFinset A (by simp)
  let encodeCode : BoundedSystemCode (B := B) N A →
      Fin (N + 1) ×
        (Finset (Fin N) → Option {e : BasisPair B // e ∈ A}) :=
    fun c ↦ (c.arity, c.labels)
  exact Fintype.ofInjective encodeCode (by
    intro c d h
    cases c
    cases d
    cases h
    rfl)

/-- Pad the labels of a bounded system to subsets of `Fin N`. -/
def paddedLabels
    (p : P C) (S : Finset (BasisPair B)) (N : ℕ)
    (hN : p.arity ≤ N)
    (hSingleton : ∀ i : Fin p.arity, p.label {i} ∈ S) :
    Finset (Fin N) →
      Option {e : BasisPair B // e ∈ labelsUpTo C S N} :=
  fun K ↦
    if h : ∃ J : Finset (Fin p.arity),
        mapSubset (Fin.castLEOrderEmb hN).toEmbedding J = K then
      let J := Classical.choose h
      some ⟨p.label J,
        label_mem_labelsUpTo C p S N hN hSingleton J⟩
    else
      none

theorem paddedLabels_map
    (p : P C) (S : Finset (BasisPair B)) (N : ℕ)
    (hN : p.arity ≤ N)
    (hSingleton : ∀ i : Fin p.arity, p.label {i} ∈ S)
    (J : Finset (Fin p.arity)) :
    paddedLabels C p S N hN hSingleton
        (mapSubset (Fin.castLEOrderEmb hN).toEmbedding J) =
      some ⟨p.label J,
        label_mem_labelsUpTo C p S N hN hSingleton J⟩ := by
  classical
  rw [paddedLabels, dif_pos ⟨J, rfl⟩]
  apply congrArg some
  apply Subtype.ext
  have hChosen := Classical.choose_spec
    (show ∃ K : Finset (Fin p.arity),
        mapSubset (Fin.castLEOrderEmb hN).toEmbedding K =
          mapSubset (Fin.castLEOrderEmb hN).toEmbedding J from ⟨J, rfl⟩)
  have hK : Classical.choose
      (show ∃ K : Finset (Fin p.arity),
          mapSubset (Fin.castLEOrderEmb hN).toEmbedding K =
            mapSubset (Fin.castLEOrderEmb hN).toEmbedding J from ⟨J, rfl⟩) = J := by
    exact (Finset.map_injective
      (Fin.castLEOrderEmb hN).toEmbedding) hChosen
  exact congrArg p.label hK

private theorem map_castLE_cast
    {a b N : ℕ} (h : a = b) (ha : a ≤ N) (hb : b ≤ N)
    (J : Finset (Fin a)) :
    mapSubset (Fin.castLEOrderEmb ha).toEmbedding J =
      mapSubset (Fin.castLEOrderEmb hb).toEmbedding
        (J.map (Fin.castOrderIso h).toEmbedding) := by
  subst b
  have hProof : hb = ha := Subsingleton.elim _ _
  subst hb
  have hMap : J.map (Fin.castOrderIso (Eq.refl a)).toEmbedding = J := by
    ext x
    constructor
    · intro hx
      rcases Finset.mem_map.mp hx with ⟨y, hy, hxy⟩
      have : x = y := by simpa using hxy.symm
      simpa [this] using hy
    · intro hx
      exact Finset.mem_map.mpr ⟨x, hx, by simp⟩
  rw [hMap]

/-- Systems with bounded arity and prescribed singleton labels form a finite
set.  This is the finiteness argument used in `lem:finite-upper-bounds`. -/
theorem bounded_systems_finite
    (S : Finset (BasisPair B)) (N : ℕ) :
    ({p : P C | p.arity ≤ N ∧
      ∀ i : Fin p.arity, p.label {i} ∈ S} : Set (P C)).Finite := by
  let A := labelsUpTo C S N
  let encode :
      {p : P C // p.arity ≤ N ∧
        ∀ i : Fin p.arity, p.label {i} ∈ S} →
        BoundedSystemCode (B := B) N A :=
    fun p ↦
      { arity := ⟨p.1.arity, by omega⟩
        labels := paddedLabels C p.1 S N p.2.1 p.2.2 }
  have hInjective : Function.Injective encode := by
    intro p q hCode
    apply Subtype.ext
    have hArity : p.1.arity = q.1.arity := by
      exact congrArg (fun z ↦ z.arity.1) hCode
    apply FiniteSystems.System.ext_cast hArity
    intro J
    let Jq : Finset (Fin q.1.arity) :=
      J.map (Fin.castOrderIso hArity).toEmbedding
    have hLabels : (encode p).labels = (encode q).labels :=
      congrArg BoundedSystemCode.labels hCode
    have hEval := congrFun hLabels
      (mapSubset (Fin.castLEOrderEmb p.2.1).toEmbedding J)
    rw [show (encode p).labels = paddedLabels C p.1 S N p.2.1 p.2.2 from rfl,
      paddedLabels_map] at hEval
    have hMap := map_castLE_cast hArity p.2.1 q.2.1 J
    rw [hMap,
      show (encode q).labels = paddedLabels C q.1 S N q.2.1 q.2.2 from rfl,
      paddedLabels_map] at hEval
    exact congrArg Subtype.val (Option.some.inj hEval)
  apply Set.finite_coe_iff.mp
  exact Finite.of_injective encode hInjective

/-! ## Finite lower-cofinal common refinements -/

def singletonLabels (p : P C) : Finset (BasisPair B) :=
  Finset.univ.image (fun i : Fin p.arity ↦ p.label {i})

/-- The finite candidate family `R(p,q)` from the source. -/
def refinements (p q : P C) : Set (P C) :=
  {w | p ≤ w ∧ q ≤ w ∧ w.arity ≤ p.arity + q.arity ∧
    ∀ i : Fin w.arity,
      w.label {i} ∈ singletonLabels C p ∪ singletonLabels C q}

theorem refinements_finite (p q : P C) :
    (refinements C p q).Finite := by
  refine (bounded_systems_finite C
    (singletonLabels C p ∪ singletonLabels C q)
    (p.arity + q.arity)).subset ?_
  intro w hw
  exact ⟨hw.2.2.1, hw.2.2.2⟩

theorem refinements_upper (p q : P C) :
    refinements C p q ⊆ Chapter2.upperBounds ({p, q} : Set (P C)) := by
  intro w hw z hz
  rcases hz with (rfl | hz)
  · exact hw.1
  · have : z = q := by simpa using hz
    subst z
    exact hw.2.1

private def rangeFinset {n m : ℕ} (f : Fin n ↪o Fin m) : Finset (Fin m) :=
  Finset.univ.map f.toEmbedding

private theorem mem_rangeFinset {n m : ℕ} (f : Fin n ↪o Fin m) (i : Fin n) :
    f i ∈ rangeFinset f := by
  exact Finset.mem_map.mpr ⟨i, Finset.mem_univ _, rfl⟩

private def embeddingIntoUnionLeft
    {p q v : P C} (f : Fin p.arity ↪o Fin v.arity)
    (g : Fin q.arity ↪o Fin v.arity) :
    Fin p.arity ↪o Fin (rangeFinset f ∪ rangeFinset g).card :=
  let K := rangeFinset f ∪ rangeFinset g
  let fSub : Fin p.arity ↪o {x : Fin v.arity // x ∈ K} :=
    { toFun := fun i ↦ ⟨f i, Finset.mem_union_left _ (mem_rangeFinset f i)⟩
      inj' := fun i j h ↦ f.injective (congrArg Subtype.val h)
      map_rel_iff' := fun {_ _} ↦ f.le_iff_le }
  fSub.trans (K.orderIsoOfFin rfl).symm.toOrderEmbedding

private def embeddingIntoUnionRight
    {p q v : P C} (f : Fin p.arity ↪o Fin v.arity)
    (g : Fin q.arity ↪o Fin v.arity) :
    Fin q.arity ↪o Fin (rangeFinset f ∪ rangeFinset g).card :=
  let K := rangeFinset f ∪ rangeFinset g
  let gSub : Fin q.arity ↪o {x : Fin v.arity // x ∈ K} :=
    { toFun := fun i ↦ ⟨g i, Finset.mem_union_right _ (mem_rangeFinset g i)⟩
      inj' := fun i j h ↦ g.injective (congrArg Subtype.val h)
      map_rel_iff' := fun {_ _} ↦ g.le_iff_le }
  gSub.trans (K.orderIsoOfFin rfl).symm.toOrderEmbedding

private theorem unionEmbedding_left
    {p q v : P C} (f : Fin p.arity ↪o Fin v.arity)
    (g : Fin q.arity ↪o Fin v.arity) (i : Fin p.arity) :
    (rangeFinset f ∪ rangeFinset g).orderEmbOfFin rfl
        (embeddingIntoUnionLeft C f g i) = f i := by
  let K := rangeFinset f ∪ rangeFinset g
  change (((K.orderIsoOfFin rfl)
      ((K.orderIsoOfFin rfl).symm
        ⟨f i, Finset.mem_union_left _ (mem_rangeFinset f i)⟩) : K) :
      Fin v.arity) = f i
  simp

private theorem unionEmbedding_right
    {p q v : P C} (f : Fin p.arity ↪o Fin v.arity)
    (g : Fin q.arity ↪o Fin v.arity) (i : Fin q.arity) :
    (rangeFinset f ∪ rangeFinset g).orderEmbOfFin rfl
        (embeddingIntoUnionRight C f g i) = g i := by
  let K := rangeFinset f ∪ rangeFinset g
  change (((K.orderIsoOfFin rfl)
      ((K.orderIsoOfFin rfl).symm
        ⟨g i, Finset.mem_union_right _ (mem_rangeFinset g i)⟩) : K) :
      Fin v.arity) = g i
  simp

/-- Restrict any common upper bound to the union of the two witnessing index
sets.  The result has at most `p.arity + q.arity` indices and only singleton
labels already occurring in `p` or `q`. -/
theorem exists_reduced_common_upper
    (p q v : P C) (hpv : p ≤ v) (hqv : q ≤ v) :
    ∃ w ∈ refinements C p q, w ≤ v := by
  rcases hpv with ⟨f, hf⟩
  rcases hqv with ⟨g, hg⟩
  let K : Finset (Fin v.arity) := rangeFinset f ∪ rangeFinset g
  have hKnonempty : K.Nonempty := by
    exact ⟨f ⟨0, p.positive⟩,
      Finset.mem_union_left _ (mem_rangeFinset f ⟨0, p.positive⟩)⟩
  let eK : Fin K.card ↪o Fin v.arity := K.orderEmbOfFin rfl
  let w : P C := v.reindex (Finset.card_pos.mpr hKnonempty) eK
  have hpw : p ≤ w := by
    let fp : Fin p.arity ↪o Fin K.card := embeddingIntoUnionLeft C f g
    refine ⟨fp, ?_⟩
    intro J hJ
    rw [FiniteSystems.System.reindex_label]
    · rw [hf J hJ]
      apply congrArg v.label
      have hEmb : fp.trans eK = f := by
        apply RelEmbedding.ext
        intro i
        exact unionEmbedding_left C f g i
      calc
        mapSubset f.toEmbedding J =
            mapSubset (fp.trans eK).toEmbedding J := by rw [hEmb]
        _ = mapSubset eK.toEmbedding (mapSubset fp.toEmbedding J) :=
          (mapSubset_comp fp eK J).symm
    · exact @Finset.Nonempty.map _ _ fp.toEmbedding J hJ
  have hqw : q ≤ w := by
    let fq : Fin q.arity ↪o Fin K.card := embeddingIntoUnionRight C f g
    refine ⟨fq, ?_⟩
    intro J hJ
    rw [FiniteSystems.System.reindex_label]
    · rw [hg J hJ]
      apply congrArg v.label
      have hEmb : fq.trans eK = g := by
        apply RelEmbedding.ext
        intro i
        exact unionEmbedding_right C f g i
      calc
        mapSubset g.toEmbedding J =
            mapSubset (fq.trans eK).toEmbedding J := by rw [hEmb]
        _ = mapSubset eK.toEmbedding (mapSubset fq.toEmbedding J) :=
          (mapSubset_comp fq eK J).symm
    · exact @Finset.Nonempty.map _ _ fq.toEmbedding J hJ
  have hwv : w ≤ v := by
    refine ⟨eK, ?_⟩
    intro J hJ
    exact FiniteSystems.System.reindex_label v
      (Finset.card_pos.mpr hKnonempty) eK J hJ
  refine ⟨w, ?_, hwv⟩
  refine ⟨hpw, hqw, ?_, ?_⟩
  · change K.card ≤ p.arity + q.arity
    change (rangeFinset f ∪ rangeFinset g).card ≤ p.arity + q.arity
    calc
      (rangeFinset f ∪ rangeFinset g).card ≤
          (rangeFinset f).card + (rangeFinset g).card :=
        Finset.card_union_le _ _
      _ = p.arity + q.arity := by simp [rangeFinset]
  · intro i
    have hiK : eK i ∈ K := Finset.orderEmbOfFin_mem K rfl i
    rw [Finset.mem_union] at hiK
    change (v.reindex (Finset.card_pos.mpr hKnonempty) eK).label {i} ∈ _
    rw [FiniteSystems.System.reindex_label]
    · rcases hiK with hiF | hiG
      · rcases Finset.mem_map.mp hiF with ⟨j, _hj, hfj⟩
        apply Finset.mem_union_left
        apply Finset.mem_image.mpr
        refine ⟨j, Finset.mem_univ _, ?_⟩
        have hfj' : f j = eK i := hfj
        have hp := hf ({j} : Finset (Fin p.arity)) (by simp)
        simpa [mapSubset, hfj'] using hp
      · rcases Finset.mem_map.mp hiG with ⟨j, _hj, hgj⟩
        apply Finset.mem_union_right
        apply Finset.mem_image.mpr
        refine ⟨j, Finset.mem_univ _, ?_⟩
        have hgj' : g j = eK i := hgj
        have hq := hg ({j} : Finset (Fin q.arity)) (by simp)
        simpa [mapSubset, hgj'] using hq
    · exact ⟨i, Finset.mem_singleton_self i⟩

/-- Source equation `ub {p,q} = ↑R(p,q)`. -/
theorem refinements_lowerCofinal (p q : P C) :
    Chapter2.upperBounds ({p, q} : Set (P C)) =
      Chapter2.upperClosure (refinements C p q) := by
  apply Set.Subset.antisymm
  · intro v hv
    have hpv : p ≤ v := hv (by simp)
    have hqv : q ≤ v := hv (by simp)
    rcases exists_reduced_common_upper C p q v hpv hqv with
      ⟨w, hwR, hwv⟩
    exact ⟨w, hwR, hwv⟩
  · rintro v ⟨w, hwR, hwv⟩ z hz
    rcases hz with (rfl | hz)
    · exact le_trans hwR.1 hwv
    · have : z = q := by simpa using hz
      subst z
      exact le_trans hwR.2.1 hwv

/-! ## Pointwise amalgamation of two systems -/

private def leftEmb (n m : ℕ) : Fin n ↪o Fin (n + m) :=
  Fin.castAddOrderEmb m

private def rightEmb (n m : ℕ) : Fin m ↪o Fin (n + m) :=
  Fin.natAddOrderEmb n

private def leftIndices (n m : ℕ) : Finset (Fin (n + m)) :=
  rangeFinset (leftEmb n m)

private def rightIndices (n m : ℕ) : Finset (Fin (n + m)) :=
  rangeFinset (rightEmb n m)

private def leftPreimage {n m : ℕ} (J : Finset (Fin (n + m))) :
    Finset (Fin n) :=
  J.preimage (leftEmb n m).toEmbedding (leftEmb n m).injective.injOn

private def rightPreimage {n m : ℕ} (J : Finset (Fin (n + m))) :
    Finset (Fin m) :=
  J.preimage (rightEmb n m).toEmbedding (rightEmb n m).injective.injOn

private theorem map_leftPreimage_eq
    {n m : ℕ} {J : Finset (Fin (n + m))}
    (hJ : J ⊆ leftIndices n m) :
    mapSubset (leftEmb n m).toEmbedding (leftPreimage J) = J := by
  classical
  ext z
  constructor
  · intro hz
    rcases Finset.mem_map.mp hz with ⟨i, hi, rfl⟩
    exact Finset.mem_preimage.mp hi
  · intro hz
    rcases Finset.mem_map.mp (hJ hz) with ⟨i, _hi, hiz⟩
    apply Finset.mem_map.mpr
    refine ⟨i, ?_, hiz⟩
    exact Finset.mem_preimage.mpr (hiz ▸ hz)

private theorem map_rightPreimage_eq
    {n m : ℕ} {J : Finset (Fin (n + m))}
    (hJ : J ⊆ rightIndices n m) :
    mapSubset (rightEmb n m).toEmbedding (rightPreimage J) = J := by
  classical
  ext z
  constructor
  · intro hz
    rcases Finset.mem_map.mp hz with ⟨i, hi, rfl⟩
    exact Finset.mem_preimage.mp hi
  · intro hz
    rcases Finset.mem_map.mp (hJ hz) with ⟨i, _hi, hiz⟩
    apply Finset.mem_map.mpr
    refine ⟨i, ?_, hiz⟩
    exact Finset.mem_preimage.mpr (hiz ▸ hz)

private theorem leftPreimage_map {n m : ℕ} (J : Finset (Fin n)) :
    leftPreimage (mapSubset (leftEmb n m).toEmbedding J) = J := by
  exact Finset.preimage_map _ _

private theorem rightPreimage_map {n m : ℕ} (J : Finset (Fin m)) :
    rightPreimage (mapSubset (rightEmb n m).toEmbedding J) = J := by
  exact Finset.preimage_map _ _

private theorem leftPreimage_erase {n m : ℕ}
    (J : Finset (Fin (n + m))) (i : Fin n) :
    leftPreimage (J.erase (leftEmb n m i)) = (leftPreimage J).erase i := by
  classical
  ext z
  simp [leftPreimage]

private theorem rightPreimage_erase {n m : ℕ}
    (J : Finset (Fin (n + m))) (i : Fin m) :
    rightPreimage (J.erase (rightEmb n m i)) = (rightPreimage J).erase i := by
  classical
  ext z
  simp [rightPreimage]

private theorem index_left_or_right {n m : ℕ} (z : Fin (n + m)) :
    z ∈ leftIndices n m ∨ z ∈ rightIndices n m := by
  exact Fin.addCases
    (fun i ↦ Or.inl (mem_rangeFinset (leftEmb n m) i))
    (fun j ↦ Or.inr (mem_rangeFinset (rightEmb n m) j)) z

private structure CoveredChoice
    (C : CommonChoiceData B) (E : Finset (BasisPair B)) (x : D) where
  pair : BasisPair B
  mem_choice : pair ∈ C.Φ E
  mem_open : x ∈ pair.openSet

private noncomputable def coveredChoice
    (C : CommonChoiceData B) (E : Finset (BasisPair B))
    (hE : E.Nonempty) (x : D) (hx : x ∈ commonPairOpen E) :
    CoveredChoice C E x := by
  have hxUnion := C.covers E hE hx
  have hExists : ∃ e : BasisPair B, e ∈ C.Φ E ∧ x ∈ e.openSet := by
    rcases Set.mem_sUnion.mp hxUnion with ⟨U, hU, hxU⟩
    rcases hU with ⟨e, he, rfl⟩
    exact ⟨e, he, hxU⟩
  let e := Classical.choose hExists
  have he := Classical.choose_spec hExists
  exact ⟨e, he.1, he.2⟩

/-- A pair together with the fact that its open contains `x`. -/
abbrev OpenPair (x : D) := {e : BasisPair B // x ∈ e.openSet}

/-- Recursively amalgamate two systems at a point in both validity opens.
Pure-left and pure-right subsets retain the old components; a mixed subset is
filled from `Φ` using the cover property at `x`. -/
noncomputable def amalgamComponent
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    (J : Finset (Fin (p.arity + q.arity))) : OpenPair (B := B) x := by
  classical
  by_cases hEmpty : J = ∅
  · exact ⟨p.label {⟨0, p.positive⟩},
      hxp _ ⟨⟨0, p.positive⟩, Finset.mem_singleton_self _⟩⟩
  · have hJ : J.Nonempty := Finset.nonempty_iff_ne_empty.mpr hEmpty
    by_cases hLeft : J ⊆ leftIndices p.arity q.arity
    · have hPre : (leftPreimage J).Nonempty := by
        rcases hJ with ⟨z, hz⟩
        rcases Finset.mem_map.mp (hLeft hz) with ⟨i, _hi, hiz⟩
        refine ⟨i, Finset.mem_preimage.mpr ?_⟩
        exact hiz ▸ hz
      exact ⟨p.label (leftPreimage J), hxp _ hPre⟩
    · by_cases hRight : J ⊆ rightIndices p.arity q.arity
      · have hPre : (rightPreimage J).Nonempty := by
          rcases hJ with ⟨z, hz⟩
          rcases Finset.mem_map.mp (hRight hz) with ⟨i, _hi, hiz⟩
          refine ⟨i, Finset.mem_preimage.mpr ?_⟩
          exact hiz ▸ hz
        exact ⟨q.label (rightPreimage J), hxq _ hPre⟩
      · have hCard : 2 ≤ J.card := by
          have hPos : 0 < J.card := Finset.card_pos.mpr hJ
          have hNotOne : J.card ≠ 1 := by
            intro hOne
            rcases Finset.card_eq_one.mp hOne with ⟨z, rfl⟩
            rcases index_left_or_right z with hz | hz
            · apply hLeft
              intro y hy
              have hyz : y = z := by simpa using hy
              simpa [hyz] using hz
            · apply hRight
              intro y hy
              have hyz : y = z := by simpa using hy
              simpa [hyz] using hz
          omega
        let E : Finset (BasisPair B) :=
          J.attach.image (fun j ↦
            (amalgamComponent C p q x hxp hxq (J.erase j.1)).1)
        have hE : E.Nonempty := by
          rcases hJ with ⟨j, hj⟩
          refine ⟨(amalgamComponent C p q x hxp hxq (J.erase j)).1, ?_⟩
          apply Finset.mem_image.mpr
          exact ⟨⟨j, hj⟩, Finset.mem_attach _ _, rfl⟩
        have hxE : x ∈ commonPairOpen E := by
          intro e he
          rcases Finset.mem_image.mp he with ⟨j, _hj, rfl⟩
          exact (amalgamComponent C p q x hxp hxq (J.erase j.1)).2
        let out := coveredChoice C E hE x hxE
        exact ⟨out.pair, out.mem_open⟩
termination_by J.card
decreasing_by
  all_goals
    apply Finset.card_erase_lt_of_mem
    aesop

theorem amalgamComponent_open
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    (J : Finset (Fin (p.arity + q.arity))) :
    x ∈ (amalgamComponent C p q x hxp hxq J).1.openSet :=
  (amalgamComponent C p q x hxp hxq J).2

private theorem amalgamComponent_left
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    {J : Finset (Fin (p.arity + q.arity))} (hJ : J.Nonempty)
    (hLeft : J ⊆ leftIndices p.arity q.arity) :
    (amalgamComponent C p q x hxp hxq J).1 =
      p.label (leftPreimage J) := by
  rw [amalgamComponent]
  simp only [Finset.nonempty_iff_ne_empty.mp hJ, ↓reduceDIte, hLeft]

private theorem amalgamComponent_right
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    {J : Finset (Fin (p.arity + q.arity))} (hJ : J.Nonempty)
    (hNotLeft : ¬J ⊆ leftIndices p.arity q.arity)
    (hRight : J ⊆ rightIndices p.arity q.arity) :
    (amalgamComponent C p q x hxp hxq J).1 =
      q.label (rightPreimage J) := by
  rw [amalgamComponent]
  simp only [Finset.nonempty_iff_ne_empty.mp hJ, ↓reduceDIte,
    hNotLeft, hRight]

private theorem amalgamComponent_mixed_mem
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    {J : Finset (Fin (p.arity + q.arity))} (hJ : J.Nonempty)
    (hNotLeft : ¬J ⊆ leftIndices p.arity q.arity)
    (hNotRight : ¬J ⊆ rightIndices p.arity q.arity) :
    (amalgamComponent C p q x hxp hxq J).1 ∈
      C.Φ (J.attach.image (fun j ↦
        (amalgamComponent C p q x hxp hxq (J.erase j.1)).1)) := by
  rw [amalgamComponent]
  simp only [Finset.nonempty_iff_ne_empty.mp hJ, ↓reduceDIte,
    hNotLeft, hNotRight]
  exact (coveredChoice C _ _ x _).mem_choice

private theorem left_right_disjoint (n m : ℕ) :
    Disjoint (leftIndices n m) (rightIndices n m) := by
  classical
  rw [Finset.disjoint_left]
  intro z hzLeft hzRight
  rcases Finset.mem_map.mp hzLeft with ⟨i, _hi, hiz⟩
  rcases Finset.mem_map.mp hzRight with ⟨j, _hj, hjz⟩
  have hij : leftEmb n m i = rightEmb n m j := hiz.trans hjz.symm
  have hval := congrArg Fin.val hij
  simp [leftEmb, rightEmb] at hval
  omega

private theorem nonempty_not_left_of_right
    {n m : ℕ} {J : Finset (Fin (n + m))}
    (hJ : J.Nonempty) (hRight : J ⊆ rightIndices n m) :
    ¬J ⊆ leftIndices n m := by
  intro hLeft
  rcases hJ with ⟨z, hz⟩
  exact Finset.disjoint_left.mp (left_right_disjoint n m) (hLeft hz) (hRight hz)

/-- Total label function used by the amalgamated system.  The empty label is
normalized to the first singleton; every nonempty label is the recursively
constructed component. -/
noncomputable def amalgamLabel
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    (J : Finset (Fin (p.arity + q.arity))) : BasisPair B :=
  if hJ : J.Nonempty then
    (amalgamComponent C p q x hxp hxq J).1
  else
    (amalgamComponent C p q x hxp hxq
      ({⟨0, Nat.add_pos_left p.positive q.arity⟩} :
        Finset (Fin (p.arity + q.arity)))).1

@[simp] theorem amalgamLabel_of_nonempty
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    (J : Finset (Fin (p.arity + q.arity))) (hJ : J.Nonempty) :
    amalgamLabel C p q x hxp hxq J =
      (amalgamComponent C p q x hxp hxq J).1 := by
  simp [amalgamLabel, hJ]

private theorem erase_nonempty_of_two
    {n : ℕ} {J : Finset (Fin n)} (hCard : 2 ≤ J.card)
    {j : Fin n} (hj : j ∈ J) :
    (J.erase j).Nonempty := by
  rw [Finset.nonempty_iff_ne_empty]
  intro hEmpty
  have hZero : (J.erase j).card = 0 := by simp [hEmpty]
  have hErase := Finset.card_erase_of_mem hj
  omega

private theorem amalgam_children_eq_components
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    (J : Finset (Fin (p.arity + q.arity))) (hCard : 2 ≤ J.card) :
    children (amalgamLabel C p q x hxp hxq) J =
      J.attach.image (fun j ↦
        (amalgamComponent C p q x hxp hxq (J.erase j.1)).1) := by
  classical
  unfold children
  apply Finset.image_congr
  intro j hj
  apply amalgamLabel_of_nonempty
  exact erase_nonempty_of_two hCard j.2

private theorem amalgam_children_left
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    (J : Finset (Fin (p.arity + q.arity))) (hCard : 2 ≤ J.card)
    (hLeft : J ⊆ leftIndices p.arity q.arity) :
    children (amalgamLabel C p q x hxp hxq) J =
      children p.label (leftPreimage J) := by
  classical
  ext e
  constructor
  · intro he
    rcases Finset.mem_image.mp he with ⟨z, _hzAttach, rfl⟩
    have hErase : (J.erase z.1).Nonempty :=
      erase_nonempty_of_two hCard z.2
    have hEraseLeft : J.erase z.1 ⊆ leftIndices p.arity q.arity := by
      intro y hy
      exact hLeft (Finset.mem_of_mem_erase hy)
    rw [amalgamLabel_of_nonempty C p q x hxp hxq _ hErase,
      amalgamComponent_left C p q x hxp hxq hErase hEraseLeft]
    rcases Finset.mem_map.mp (hLeft z.2) with ⟨i, _hi, hiz⟩
    rw [show z.1 = leftEmb p.arity q.arity i from hiz.symm,
      leftPreimage_erase]
    apply Finset.mem_image.mpr
    refine ⟨⟨i, ?_⟩, Finset.mem_attach _ _, rfl⟩
    exact Finset.mem_preimage.mpr (hiz ▸ z.2)
  · intro he
    rcases Finset.mem_image.mp he with ⟨i, _hiAttach, rfl⟩
    have hiJ : leftEmb p.arity q.arity i.1 ∈ J :=
      Finset.mem_preimage.mp i.2
    apply Finset.mem_image.mpr
    refine ⟨⟨leftEmb p.arity q.arity i.1, hiJ⟩,
      Finset.mem_attach _ _, ?_⟩
    have hErase :
        (J.erase (leftEmb p.arity q.arity i.1)).Nonempty :=
      erase_nonempty_of_two hCard hiJ
    have hEraseLeft :
        J.erase (leftEmb p.arity q.arity i.1) ⊆
          leftIndices p.arity q.arity := by
      intro y hy
      exact hLeft (Finset.mem_of_mem_erase hy)
    rw [amalgamLabel_of_nonempty C p q x hxp hxq _ hErase,
      amalgamComponent_left C p q x hxp hxq hErase hEraseLeft,
      leftPreimage_erase]

private theorem amalgam_children_right
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q)
    (J : Finset (Fin (p.arity + q.arity))) (hCard : 2 ≤ J.card)
    (hRight : J ⊆ rightIndices p.arity q.arity) :
    children (amalgamLabel C p q x hxp hxq) J =
      children q.label (rightPreimage J) := by
  classical
  ext e
  constructor
  · intro he
    rcases Finset.mem_image.mp he with ⟨z, _hzAttach, rfl⟩
    have hErase : (J.erase z.1).Nonempty :=
      erase_nonempty_of_two hCard z.2
    have hEraseRight : J.erase z.1 ⊆ rightIndices p.arity q.arity := by
      intro y hy
      exact hRight (Finset.mem_of_mem_erase hy)
    have hEraseNotLeft := nonempty_not_left_of_right hErase hEraseRight
    rw [amalgamLabel_of_nonempty C p q x hxp hxq _ hErase,
      amalgamComponent_right C p q x hxp hxq hErase hEraseNotLeft hEraseRight]
    rcases Finset.mem_map.mp (hRight z.2) with ⟨i, _hi, hiz⟩
    rw [show z.1 = rightEmb p.arity q.arity i from hiz.symm,
      rightPreimage_erase]
    apply Finset.mem_image.mpr
    refine ⟨⟨i, ?_⟩, Finset.mem_attach _ _, rfl⟩
    exact Finset.mem_preimage.mpr (hiz ▸ z.2)
  · intro he
    rcases Finset.mem_image.mp he with ⟨i, _hiAttach, rfl⟩
    have hiJ : rightEmb p.arity q.arity i.1 ∈ J :=
      Finset.mem_preimage.mp i.2
    apply Finset.mem_image.mpr
    refine ⟨⟨rightEmb p.arity q.arity i.1, hiJ⟩,
      Finset.mem_attach _ _, ?_⟩
    have hErase :
        (J.erase (rightEmb p.arity q.arity i.1)).Nonempty :=
      erase_nonempty_of_two hCard hiJ
    have hEraseRight :
        J.erase (rightEmb p.arity q.arity i.1) ⊆
          rightIndices p.arity q.arity := by
      intro y hy
      exact hRight (Finset.mem_of_mem_erase hy)
    have hEraseNotLeft := nonempty_not_left_of_right hErase hEraseRight
    rw [amalgamLabel_of_nonempty C p q x hxp hxq _ hErase,
      amalgamComponent_right C p q x hxp hxq hErase hEraseNotLeft hEraseRight,
      rightPreimage_erase]

/-- The pointwise amalgamation is a genuine finite system. -/
noncomputable def amalgamSystem
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q) : P C where
  arity := p.arity + q.arity
  positive := Nat.add_pos_left p.positive q.arity
  label := amalgamLabel C p q x hxp hxq
  empty_normalized := by
    simp only [amalgamLabel]
    rw [dif_neg (by simp), dif_pos (by simp)]
  valid J hCard := by
    have hJ : J.Nonempty := Finset.card_pos.mp (by omega)
    rw [amalgamLabel_of_nonempty C p q x hxp hxq J hJ]
    by_cases hLeft : J ⊆ leftIndices p.arity q.arity
    · rw [amalgamComponent_left C p q x hxp hxq hJ hLeft,
        amalgam_children_left C p q x hxp hxq J hCard hLeft]
      have hPreCard : 2 ≤ (leftPreimage J).card := by
        rw [← mapSubset_card (leftEmb p.arity q.arity).toEmbedding,
          map_leftPreimage_eq hLeft]
        exact hCard
      exact p.valid (leftPreimage J) hPreCard
    · by_cases hRight : J ⊆ rightIndices p.arity q.arity
      · rw [amalgamComponent_right C p q x hxp hxq hJ hLeft hRight,
          amalgam_children_right C p q x hxp hxq J hCard hRight]
        have hPreCard : 2 ≤ (rightPreimage J).card := by
          rw [← mapSubset_card (rightEmb p.arity q.arity).toEmbedding,
            map_rightPreimage_eq hRight]
          exact hCard
        exact q.valid (rightPreimage J) hPreCard
      · rw [amalgam_children_eq_components C p q x hxp hxq J hCard]
        exact amalgamComponent_mixed_mem C p q x hxp hxq hJ hLeft hRight

theorem left_le_amalgamSystem
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q) :
    p ≤ amalgamSystem C p q x hxp hxq := by
  refine ⟨leftEmb p.arity q.arity, ?_⟩
  intro J hJ
  have hMapNonempty :
      (mapSubset (leftEmb p.arity q.arity).toEmbedding J).Nonempty :=
    @Finset.Nonempty.map _ _
      (leftEmb p.arity q.arity).toEmbedding J hJ
  change p.label J =
    amalgamLabel C p q x hxp hxq
      (mapSubset (leftEmb p.arity q.arity).toEmbedding J)
  rw [amalgamLabel_of_nonempty C p q x hxp hxq _ hMapNonempty]
  have hLeft :
      mapSubset (leftEmb p.arity q.arity).toEmbedding J ⊆
        leftIndices p.arity q.arity := by
    intro z hz
    rcases Finset.mem_map.mp hz with ⟨i, _hi, rfl⟩
    exact mem_rangeFinset (leftEmb p.arity q.arity) i
  rw [amalgamComponent_left C p q x hxp hxq hMapNonempty hLeft,
    leftPreimage_map]

theorem right_le_amalgamSystem
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q) :
    q ≤ amalgamSystem C p q x hxp hxq := by
  refine ⟨rightEmb p.arity q.arity, ?_⟩
  intro J hJ
  have hMapNonempty :
      (mapSubset (rightEmb p.arity q.arity).toEmbedding J).Nonempty :=
    @Finset.Nonempty.map _ _
      (rightEmb p.arity q.arity).toEmbedding J hJ
  change q.label J =
    amalgamLabel C p q x hxp hxq
      (mapSubset (rightEmb p.arity q.arity).toEmbedding J)
  rw [amalgamLabel_of_nonempty C p q x hxp hxq _ hMapNonempty]
  have hRight :
      mapSubset (rightEmb p.arity q.arity).toEmbedding J ⊆
        rightIndices p.arity q.arity := by
    intro z hz
    rcases Finset.mem_map.mp hz with ⟨i, _hi, rfl⟩
    exact mem_rangeFinset (rightEmb p.arity q.arity) i
  have hNotLeft := nonempty_not_left_of_right hMapNonempty hRight
  rw [amalgamComponent_right C p q x hxp hxq
    hMapNonempty hNotLeft hRight, rightPreimage_map]

theorem mem_validity_amalgamSystem
    (C : CommonChoiceData B) (p q : P C) (x : D)
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q) :
    x ∈ validity C (amalgamSystem C p q x hxp hxq) := by
  intro J hJ
  change x ∈ (amalgamLabel C p q x hxp hxq J).openSet
  rw [amalgamLabel_of_nonempty C p q x hxp hxq J hJ]
  exact amalgamComponent_open C p q x hxp hxq J

/-- Every point in `U_p ∩ U_q` is contained in the validity open of a
concrete common extension. -/
theorem exists_common_extension_at_point
    (C : CommonChoiceData B) (p q : P C) {x : D}
    (hxp : x ∈ validity C p) (hxq : x ∈ validity C q) :
    ∃ w : P C, p ≤ w ∧ q ≤ w ∧ x ∈ validity C w := by
  exact ⟨amalgamSystem C p q x hxp hxq,
    left_le_amalgamSystem C p q x hxp hxq,
    right_le_amalgamSystem C p q x hxp hxq,
    mem_validity_amalgamSystem C p q x hxp hxq⟩

/-- The exact open decomposition over the finite reduced refinement family. -/
theorem exact_refinement_decomposition (p q : P C) :
    validity C p ∩ validity C q =
      Set.sUnion (validity C '' refinements C p q : Set (Set D)) := by
  apply Set.Subset.antisymm
  · rintro x ⟨hxp, hxq⟩
    rcases exists_common_extension_at_point C p q hxp hxq with
      ⟨v, hpv, hqv, hxv⟩
    rcases exists_reduced_common_upper C p q v hpv hqv with
      ⟨w, hwR, hwv⟩
    exact Set.mem_sUnion_of_mem (validity_antitone C hwv hxv)
      ⟨w, hwR, rfl⟩
  · intro x hx
    rcases Set.mem_sUnion.mp hx with ⟨U, hU, hxU⟩
    rcases hU with ⟨w, hwR, rfl⟩
    exact ⟨validity_antitone C hwR.1 hxU,
      validity_antitone C hwR.2.1 hxU⟩

/-- The finite-system construction packaged as the exact binary refinement
interface consumed by the ideal-completion theorem. -/
noncomputable def binaryCore :
    FiniteBinaryRefinementCore (D := D) (P := P C) where
  V := validity C
  validity_antitone := validity_antitone C
  refinements := refinements C
  refinements_finite := refinements_finite C
  refinements_upper := refinements_upper C
  refinements_lowerCofinal := refinements_lowerCofinal C
  exact_refinement_decomposition := exact_refinement_decomposition C

/-! ## Covering and local cofinality -/

private theorem exists_covering_pair
    (hB : IsBasis B) (x : D) :
    ∃ e : BasisPair B, x ∈ e.openSet := by
  rcases (hB x).1.1 with ⟨b, hbB, hbx⟩
  rcases (hB b).1.1 with ⟨a, haB, hab⟩
  exact ⟨
    { first := ⟨a, haB⟩
      second := ⟨b, hbB⟩
      first_wayBelow_second := hab },
    hbx⟩

private theorem exists_cofinal_pair
    (hB : IsBasis B) {d x : D} (hdx : d ≪ x) :
    ∃ e : BasisPair B, x ∈ e.openSet ∧ d ≤ e.first.1 := by
  have hSingletonFinite : ({d} : Set D).Finite := Set.finite_singleton d
  have hSingletonBelow : ∀ z ∈ ({d} : Set D), z ≪ x := by
    intro z hz
    have hzd : z = d := by simpa using hz
    simpa [hzd] using hdx
  rcases lemma_2_2_15_interpolation_basis hB hSingletonFinite
      hSingletonBelow with ⟨b, hbB, hdb, hbx⟩
  have hdb' : d ≪ b := hdb d (by simp)
  rcases finite_wayBelow_basis_upper hB hSingletonFinite
      (y := b) (by
        intro z hz
        have hzd : z = d := by simpa using hz
        simpa [hzd] using hdb') with ⟨a, haApprox, hda⟩
  exact ⟨
    { first := ⟨a, haApprox.1⟩
      second := ⟨b, hbB⟩
      first_wayBelow_second := haApprox.2 },
    hbx,
    hda d (by simp)⟩

theorem singleton_mem_validity
    (e : BasisPair B) {x : D} (hx : x ∈ e.openSet) :
    x ∈ validity C (FiniteSystems.System.singleton e) := by
  intro J hJ
  exact hx

@[simp] theorem singleton_approximant (e : BasisPair B) :
    approximant C (FiniteSystems.System.singleton e) = e.first.1 := rfl

theorem validity_cover (hB : IsBasis B) (x : D) :
    ∃ p : P C, x ∈ validity C p := by
  rcases exists_covering_pair hB x with ⟨e, hxe⟩
  exact ⟨FiniteSystems.System.singleton e,
    singleton_mem_validity C e hxe⟩

theorem locally_cofinal
    (hB : IsBasis B) {d x : D} (hdx : d ≪ x) :
    ∃ p : P C, x ∈ validity C p ∧ d ≤ approximant C p := by
  rcases exists_cofinal_pair hB hdx with ⟨e, hxe, hde⟩
  exact ⟨FiniteSystems.System.singleton e,
    singleton_mem_validity C e hxe, by simpa using hde⟩

/-- The complete finite-system presentation data. -/
noncomputable def presentationData
    [Nonempty D] (hB : IsBasis B) :
    RefinementPresentationData D where
  P := P C
  orderP := inferInstance
  nonemptyP := by
    let x : D := Classical.choice ‹Nonempty D›
    let e : BasisPair B := Classical.choose (exists_covering_pair hB x)
    exact ⟨FiniteSystems.System.singleton e⟩
  binary := binaryCore C
  V_scottOpen := validity_scottOpen C hB
  h := approximant C
  h_monotone := approximant_monotone C
  locally_approximating := by
    intro x p hxp
    exact approximant_wayBelow_of_mem_validity C p hxp
  validity_cover := validity_cover C hB
  locally_cofinal := locally_cofinal C hB
  lower_finite := lower_finite C

/-! ## The empty-family clause and property `m` -/

/-- The first singleton restriction of a system. -/
def rootSystem (p : P C) : P C :=
  FiniteSystems.System.singleton
    (p.label ({⟨0, p.positive⟩} : Finset (Fin p.arity)))

theorem rootSystem_le (p : P C) : rootSystem C p ≤ p := by
  let f : Fin 1 ↪o Fin p.arity := Fin.castLEOrderEmb p.positive
  refine ⟨f, ?_⟩
  intro J hJ
  change Finset (Fin 1) at J
  change J.Nonempty at hJ
  have hJone : J = ({0} : Finset (Fin 1)) := by
    apply Finset.Subset.antisymm
    · intro i hi
      simp [Fin.eq_zero i]
    · rw [Finset.singleton_subset_iff]
      rcases hJ with ⟨i, hi⟩
      have hi0 : i = 0 := Fin.eq_zero i
      simpa [hi0] using hi
  subst J
  change p.label {⟨0, p.positive⟩} =
    p.label (mapSubset f.toEmbedding {0})
  have hzero : f 0 = ⟨0, p.positive⟩ := by
    apply Fin.ext
    rfl
  simp [mapSubset, hzero]

private theorem rootSystem_minimal (p : P C) :
    IsMinimalUpperBound (∅ : Set (P C)) (rootSystem C p) := by
  constructor
  · intro z hz
    exact hz.elim
  · intro q _hqUpper hq
    rcases hq with ⟨f, hf⟩
    have hArityLeRaw : q.arity ≤ (rootSystem C p).arity := by
      simpa using Fintype.card_le_of_injective f f.injective
    have hArityLe : q.arity ≤ 1 := by
      simpa [rootSystem] using hArityLeRaw
    have hArity : q.arity = 1 := by
      have := q.positive
      omega
    let g : Fin 1 ↪o Fin q.arity :=
      (Fin.castOrderIso hArity).symm.toOrderEmbedding
    refine ⟨g, ?_⟩
    intro J hJ
    have hMapNonempty : (mapSubset g.toEmbedding J).Nonempty :=
      @Finset.Nonempty.map _ _ g.toEmbedding J hJ
    have hqLabel := hf (mapSubset g.toEmbedding J) hMapNonempty
    change (rootSystem C p).label J =
      q.label (mapSubset g.toEmbedding J)
    exact hqLabel.symm

/-- Every system lies above a minimal singleton system, so the empty family
has a complete set of minimal upper bounds. -/
theorem empty_complete :
    CompleteMUBSet (∅ : Set (P C)) := by
  apply Set.Subset.antisymm
  · intro p hp
    exact ⟨rootSystem C p, rootSystem_minimal C p,
      rootSystem_le C p⟩
  · rintro p ⟨m, hm, hmp⟩ z hz
    exact hz.elim

theorem propertym : HasPropertym (P C) :=
  hasPropertym_of_binary_of_empty_complete
    (FiniteBinaryRefinementCore.hasFiniteCompleteBinaryMUBs (binaryCore C))
    (empty_complete C)

theorem nonempty_finite_mubs : HasNonemptyFinitePropertyM (P C) :=
  hasNonemptyFinitePropertyM_of_binary
    (FiniteBinaryRefinementCore.hasFiniteCompleteBinaryMUBs (binaryCore C))

end FiniteSystemPresentation

end


end CoherentContinuousAlgebraicRetracts
