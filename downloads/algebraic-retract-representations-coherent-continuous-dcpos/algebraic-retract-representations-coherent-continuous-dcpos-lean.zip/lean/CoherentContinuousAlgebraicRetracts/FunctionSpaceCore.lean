import CoherentContinuousAlgebraicRetracts
import Practice.DomainTheory.Chapter03.NumberedItems.Section33_FunctionSpaces

/-!
# Scott-continuous function spaces and unpointed bifinite domains

The definition carries the actual pointwise order. The compositional API
and retraction interfaces are shared by the paper's application proofs.
-/

set_option autoImplicit false

universe u v w

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

/-! ## A partial-order carrier for continuous maps -/

/-- Scott-continuous maps with the pointwise partial order.  The textbook's
`ContFun` carrier is intentionally only a preorder; this wrapper installs
antisymmetry when the codomain is a partial order. -/
structure FunctionSpace
    (D : Type u) (E : Type v) [Preorder D] [PartialOrder E] where
  toContFun : AbramskyJung.Chapter3.ContFun D E

namespace FunctionSpace

section Basic

variable {D : Type u} {E : Type v} {F : Type w}
variable [Preorder D] [PartialOrder E] [PartialOrder F]

instance : CoeFun (FunctionSpace D E) (fun _ ↦ D → E) where
  coe f := f.toContFun.toFun

@[ext]
theorem ext {f g : FunctionSpace D E} (h : ∀ x, f x = g x) : f = g := by
  cases f with
  | mk f =>
      cases g with
      | mk g =>
          congr
          exact AbramskyJung.Chapter3.ContFun.ext_apply h

instance : PartialOrder (FunctionSpace D E) where
  le f g := ∀ x, f x ≤ g x
  le_refl f x := le_rfl
  le_trans f g h hfg hgh x := le_trans (hfg x) (hgh x)
  le_antisymm f g hfg hgf := by
    apply FunctionSpace.ext
    intro x
    exact le_antisymm (hfg x) (hgf x)

def ofContFun (f : AbramskyJung.Chapter3.ContFun D E) :
    FunctionSpace D E := ⟨f⟩

def toFunMap (f : FunctionSpace D E) :
    AbramskyJung.Chapter3.ContFun D E := f.toContFun

def const (e : E) : FunctionSpace D E :=
  ⟨{ toFun := fun _ ↦ e
     continuous := AbramskyJung.Chapter3.const_scottContinuous e }⟩

instance [Nonempty E] : Nonempty (FunctionSpace D E) :=
  ⟨const (Classical.choice ‹Nonempty E›)⟩

/-- Composition of continuous maps. -/
def comp (g : FunctionSpace E F) (f : FunctionSpace D E) :
    FunctionSpace D F :=
  ⟨AbramskyJung.Chapter3.ContFun.comp g.toContFun f.toContFun⟩

@[simp]
theorem comp_apply (g : FunctionSpace E F) (f : FunctionSpace D E) (x : D) :
    comp g f x = g (f x) := rfl

/-- Continuous maps into a dcpo form a dcpo under the pointwise order. -/
theorem isDcpo_of_codomain (hE : IsDcpo E) :
    IsDcpo (FunctionSpace D E) := by
  intro G hG
  let unwrap : FunctionSpace D E →
      AbramskyJung.Chapter3.ContFun D E := fun f ↦ f.toContFun
  have hUnwrapDir : DirectedSet (unwrap '' G) := by
    exact DirectedSet.image (fun _ _ h ↦ h) hG
  obtain ⟨s, hs⟩ :=
    AbramskyJung.Chapter3.ContFun.isDcpo_of_codomain hE
      (unwrap '' G) hUnwrapDir
  refine ⟨⟨s⟩, ?_⟩
  constructor
  · intro f hf
    exact hs.1 ⟨f, hf, rfl⟩
  · intro q hq
    exact hs.2 q.toContFun (by
      intro f hf
      rcases hf with ⟨g, hg, rfl⟩
      exact hq hg)

/-- Directed suprema of continuous functions are evaluated pointwise. -/
theorem isSup_apply
    (hE : IsDcpo E) {G : Set (FunctionSpace D E)}
    {s : FunctionSpace D E} (hG : DirectedSet G) (hs : IsSup G s)
    (x : D) :
    IsSup ((fun f : FunctionSpace D E ↦ f x) '' G) (s x) := by
  let unwrap : FunctionSpace D E →
      AbramskyJung.Chapter3.ContFun D E := fun f ↦ f.toContFun
  have hUnwrapDir : DirectedSet (unwrap '' G) :=
    DirectedSet.image (fun _ _ h ↦ h) hG
  have hUnwrapSup : IsSup (unwrap '' G) s.toContFun := by
    constructor
    · rintro g ⟨g₀, hg₀, rfl⟩
      exact hs.1 hg₀
    · intro t ht
      exact hs.2 ⟨t⟩ (by
        intro g hg z
        exact (ht ⟨g, hg, rfl⟩) z)
  have hEval :=
    (AbramskyJung.Chapter3.ContFun.eval_scottContinuous hE x).2
      hUnwrapDir hUnwrapSup
  have hImageEq :
      ((fun f : AbramskyJung.Chapter3.ContFun D E ↦ f x) ''
          (unwrap '' G)) =
        ((fun f : FunctionSpace D E ↦ f x) '' G) := by
    ext y
    constructor
    · rintro ⟨_, ⟨f, hfG, rfl⟩, rfl⟩
      exact ⟨f, hfG, rfl⟩
    · rintro ⟨f, hfG, rfl⟩
      exact ⟨f.toContFun, ⟨f, hfG, rfl⟩, rfl⟩
  rwa [hImageEq] at hEval

/-! ## Precomposition, postcomposition, and the two-sided retract -/

def precompose (k : FunctionSpace D E) :
    FunctionSpace E F → FunctionSpace D F :=
  fun g ↦ comp g k

def postcompose (k : FunctionSpace E F) :
    FunctionSpace D E → FunctionSpace D F :=
  fun g ↦ comp k g

theorem precompose_scottContinuous
    (hF : IsDcpo F) (k : FunctionSpace D E) :
    Chapter2.ScottContinuous (precompose (F := F) k) := by
  constructor
  · intro f g hfg x
    exact hfg (k x)
  · intro G s hG hs
    constructor
    · intro y hy
      rcases hy with ⟨g, hg, rfl⟩
      intro x
      exact hs.1 hg (k x)
    · intro q hq x
      let unwrap : FunctionSpace E F →
          AbramskyJung.Chapter3.ContFun E F := fun g ↦ g.toContFun
      have hUnwrapDir : DirectedSet (unwrap '' G) :=
        DirectedSet.image (fun _ _ h ↦ h) hG
      have hUnwrapSup : IsSup (unwrap '' G) s.toContFun := by
        constructor
        · rintro g ⟨g₀, hg₀, rfl⟩
          exact hs.1 hg₀
        · intro t ht
          exact hs.2 ⟨t⟩ (by
            intro g hg z
            exact (ht ⟨g, hg, rfl⟩) z)
      have hEvalSup :=
        (AbramskyJung.Chapter3.ContFun.eval_scottContinuous hF (k x)).2
          hUnwrapDir hUnwrapSup
      apply hEvalSup.2 (q x)
      intro y hy
      rcases hy with ⟨g, hg, rfl⟩
      rcases hg with ⟨g₀, hg₀, rfl⟩
      exact hq ⟨g₀, hg₀, rfl⟩ x

theorem postcompose_scottContinuous
    (hE : IsDcpo E) (k : FunctionSpace E F) :
    Chapter2.ScottContinuous (postcompose (D := D) k) := by
  constructor
  · intro f g hfg x
    exact k.toContFun.continuous.1 (hfg x)
  · intro G s hG hs
    constructor
    · intro y hy
      rcases hy with ⟨g, hg, rfl⟩
      intro x
      exact k.toContFun.continuous.1 (hs.1 hg x)
    · intro q hq x
      let unwrap : FunctionSpace D E →
          AbramskyJung.Chapter3.ContFun D E := fun g ↦ g.toContFun
      have hUnwrapDir : DirectedSet (unwrap '' G) :=
        DirectedSet.image (fun _ _ h ↦ h) hG
      have hUnwrapSup : IsSup (unwrap '' G) s.toContFun := by
        constructor
        · rintro g ⟨g₀, hg₀, rfl⟩
          exact hs.1 hg₀
        · intro t ht
          exact hs.2 ⟨t⟩ (by
            intro g hg z
            exact (ht ⟨g, hg, rfl⟩) z)
      have hEvalSup :=
        (AbramskyJung.Chapter3.ContFun.eval_scottContinuous hE x).2
          hUnwrapDir hUnwrapSup
      have hEvalDir :=
        AbramskyJung.Chapter3.ContFun.eval_directed hUnwrapDir x
      have hPostSup :=
        k.toContFun.continuous.2 hEvalDir hEvalSup
      apply hPostSup.2 (q x)
      intro y hy
      rcases hy with ⟨z, hz, rfl⟩
      rcases hz with ⟨g, hg, rfl⟩
      rcases hg with ⟨g₀, hg₀, rfl⟩
      exact hq ⟨g₀, hg₀, rfl⟩ x

end Basic

private def sectionMap
    {X : Type u} {Y : Type v} [Preorder X] [PartialOrder Y]
    (sr : AbramskyJung.Chapter3.ContinuousSectionRetractionPair X Y) :
    FunctionSpace X Y :=
  ⟨{ toFun := sr.s, continuous := sr.continuous_s }⟩

private def retractionMap
    {X : Type u} {Y : Type v} [PartialOrder X] [Preorder Y]
    (sr : AbramskyJung.Chapter3.ContinuousSectionRetractionPair X Y) :
    FunctionSpace Y X :=
  ⟨{ toFun := sr.r, continuous := sr.continuous_r }⟩

/-- The identity continuous section--retraction pair. -/
def identityRetract (X : Type u) [PartialOrder X] :
    AbramskyJung.Chapter3.ContinuousSectionRetractionPair X X where
  s := id
  r := id
  monotone_s := fun _ _ h ↦ h
  monotone_r := fun _ _ h ↦ h
  retract := fun _ ↦ rfl
  continuous_s := scottContinuous_id
  continuous_r := scottContinuous_id

/-- The source map `S(f) = s_E o f o r_D`. -/
def liftAlongRetractions
    {D A : Type u} {E B : Type v}
    [PartialOrder D] [PartialOrder E] [PartialOrder A] [PartialOrder B]
    (srD : AbramskyJung.Chapter3.ContinuousSectionRetractionPair D A)
    (srE : AbramskyJung.Chapter3.ContinuousSectionRetractionPair E B) :
    FunctionSpace D E → FunctionSpace A B :=
  fun f ↦ comp (sectionMap (X := E) (Y := B) srE)
    (comp f (retractionMap (X := D) (Y := A) srD))

/-- The source map `R(g) = r_E o g o s_D`. -/
def lowerAlongRetractions
    {D A : Type u} {E B : Type v}
    [PartialOrder D] [PartialOrder E] [PartialOrder A] [PartialOrder B]
    (srD : AbramskyJung.Chapter3.ContinuousSectionRetractionPair D A)
    (srE : AbramskyJung.Chapter3.ContinuousSectionRetractionPair E B) :
    FunctionSpace A B → FunctionSpace D E :=
  fun g ↦ comp (retractionMap (X := E) (Y := B) srE)
    (comp g (sectionMap (X := D) (Y := A) srD))

/-- Equation `eq:function-retract-consequence`: two continuous retractions
induce a continuous retraction between the corresponding function spaces. -/
def continuousRetract
    {D A : Type u} {E B : Type v}
    [PartialOrder D] [PartialOrder E] [PartialOrder A] [PartialOrder B]
    (hE : IsDcpo E) (hB : IsDcpo B)
    (srD : AbramskyJung.Chapter3.ContinuousSectionRetractionPair D A)
    (srE : AbramskyJung.Chapter3.ContinuousSectionRetractionPair E B) :
    AbramskyJung.Chapter3.ContinuousSectionRetractionPair
      (FunctionSpace D E) (FunctionSpace A B) where
  s := liftAlongRetractions srD srE
  r := lowerAlongRetractions srD srE
  monotone_s := by
    exact ((postcompose_scottContinuous hE
      (sectionMap (X := E) (Y := B) srE)).comp
      (precompose_scottContinuous (F := E) hE
        (retractionMap (X := D) (Y := A) srD))).1
  monotone_r := by
    exact ((postcompose_scottContinuous hB
      (retractionMap (X := E) (Y := B) srE)).comp
      (precompose_scottContinuous (F := B) hB
        (sectionMap (X := D) (Y := A) srD))).1
  retract := by
    intro f
    apply FunctionSpace.ext
    intro x
    simp only [lowerAlongRetractions, liftAlongRetractions, comp_apply]
    change srE.r (srE.s (f (srD.r (srD.s x)))) = f x
    rw [srD.retract, srE.retract]
  continuous_s :=
    (postcompose_scottContinuous hE
      (sectionMap (X := E) (Y := B) srE)).comp
      (precompose_scottContinuous (F := E) hE
        (retractionMap (X := D) (Y := A) srD))
  continuous_r :=
    (postcompose_scottContinuous hB
      (retractionMap (X := E) (Y := B) srE)).comp
      (precompose_scottContinuous (F := B) hB
        (sectionMap (X := D) (Y := A) srD))

end FunctionSpace

/-! The reused ideal-completion implementation deliberately exposes only a
preorder instance and proves antisymmetry separately.  Function spaces in this
file need a genuine partial-order codomain, so we install that proved order
locally when using an ideal completion. -/
@[reducible] def idealCompletionPartialOrder
    (P : Type u) [PartialOrder P] : PartialOrder (IdealCompletion P) where
  toPreorder := inferInstance
  le_antisymm I J hIJ hJI := by
    apply Subtype.ext
    exact Set.Subset.antisymm hIJ hJI

/-! ## Unpointed bifinite and RB-domain interfaces -/

/-- The unpointed definition of bifiniteness used in the source: an
algebraic dcpo with a directed approximate identity of finite-image kernel
operators. -/
structure UnpointedBifinite
    (B : Type u) [PartialOrder B] where
  dcpo : IsDcpo B
  algebraic : AbramskyJung.Chapter3.IsAlgebraicDomain B
  operators : Set (AbramskyJung.Chapter3.KernelOperator B)
  operators_nonempty : operators.Nonempty
  finite_image : ∀ k ∈ operators, (Set.range k.k).Finite
  directed : ∀ p ∈ operators, ∀ q ∈ operators,
    ∃ r ∈ operators, ∀ x : B, p.k x ≤ r.k x ∧ q.k x ≤ r.k x
  approximates : ∀ x : B,
    IsSup ({y : B | ∃ k ∈ operators, y = k.k x}) x

/-- Every finite subset is Scott compact. -/
theorem scottCompact_of_finite
    {D : Type u} [Preorder D] {K : Set D} (hK : K.Finite) :
    ScottCompact K := by
  induction K, hK using Set.Finite.induction_on with
  | empty => exact ScottCompact.empty
  | @insert x K hxK _ ih =>
      have hxCompact : ScottCompact ({x} : Set D) := by
        intro cover hOpen hCover
        have hxCovered : x ∈ Set.sUnion cover := hCover (by simp)
        rcases Set.mem_sUnion.mp hxCovered with ⟨U, hUcover, hxU⟩
        exact ⟨{U}, by simpa, Set.finite_singleton U, by
          intro y hy
          have hyx : y = x := by simpa using hy
          subst y
          exact Set.mem_sUnion_of_mem hxU (by simp)⟩
      rw [Set.insert_eq]
      exact hxCompact.union ih

/-- A bifinite domain is Scott compact.  One finite-image kernel already
generates the whole carrier by upward closure. -/
theorem UnpointedBifinite.scottCompactSpace
    {B : Type u} [PartialOrder B] (hB : UnpointedBifinite B) :
    IsScottCompactSpace B := by
  rcases hB.operators_nonempty with ⟨k, hk⟩
  have hRangeCompact : ScottCompact (Set.range k.k) :=
    scottCompact_of_finite (hB.finite_image k hk)
  have hUpperEq : Chapter2.upperClosure (Set.range k.k) = Set.univ := by
    apply Set.eq_univ_of_forall
    intro x
    exact ⟨k.k x, ⟨x, rfl⟩, k.below x⟩
  change ScottCompact (Set.univ : Set B)
  rw [← hUpperEq]
  exact hRangeCompact.upperClosure

/-- A source-facing RB-domain witness. -/
structure RBDomainWitness
    (R : Type u) [PartialOrder R] where
  B : Type u
  [orderB : PartialOrder B]
  [nonemptyB : Nonempty B]
  bifinite : UnpointedBifinite B
  pair : AbramskyJung.Chapter3.ContinuousSectionRetractionPair R B

attribute [instance]
  RBDomainWitness.orderB
  RBDomainWitness.nonemptyB

def IsRBDomain (R : Type u) [PartialOrder R] : Prop :=
  Nonempty (RBDomainWitness R)

/-- The dcpo and continuity inherited by an RB-domain from its bifinite
ambient domain. -/
theorem rbDomain_dcpo_continuous
    {R : Type u} [PartialOrder R] (hR : IsRBDomain R) :
    IsDcpo R ∧ AbramskyJung.Chapter3.IsContinuousDomain R := by
  rcases hR with ⟨W⟩
  exact AbramskyJung.Chapter3.theorem_3_1_4_retract_continuous_domain_with_dcpo
    W.pair W.bifinite.dcpo ⟨CompactSet, W.bifinite.algebraic⟩

/-- Scott compactness passes from the bifinite ambient domain through the
surjective retraction. -/
theorem rbDomain_scottCompact
    {R : Type u} [PartialOrder R] (hR : IsRBDomain R) :
    IsScottCompactSpace R := by
  rcases hR with ⟨W⟩
  apply scottCompactSpace_of_surjective_scottContinuous
    W.bifinite.scottCompactSpace W.pair.continuous_r
  intro x
  exact ⟨W.pair.s x, W.pair.retract x⟩

/-- Compose two continuous section--retraction pairs. -/
def composeRetractions
    {X Y Z : Type u} [PartialOrder X] [PartialOrder Y] [PartialOrder Z]
    (xy : AbramskyJung.Chapter3.ContinuousSectionRetractionPair X Y)
    (yz : AbramskyJung.Chapter3.ContinuousSectionRetractionPair Y Z) :
    AbramskyJung.Chapter3.ContinuousSectionRetractionPair X Z where
  s := fun x ↦ yz.s (xy.s x)
  r := fun z ↦ xy.r (yz.r z)
  monotone_s := yz.monotone_s.comp xy.monotone_s
  monotone_r := xy.monotone_r.comp yz.monotone_r
  retract := by intro x; rw [yz.retract, xy.retract]
  continuous_s := yz.continuous_s.comp xy.continuous_s
  continuous_r := xy.continuous_r.comp yz.continuous_r

/-- RB-domains are closed under continuous retracts, by composing the two
retractions. -/
theorem rbDomain_of_continuous_retract
    {X R : Type u} [PartialOrder X] [PartialOrder R]
    (sr : AbramskyJung.Chapter3.ContinuousSectionRetractionPair X R)
    (hR : IsRBDomain R) : IsRBDomain X := by
  rcases hR with ⟨W⟩
  exact ⟨
    { B := W.B
      orderB := inferInstance
      nonemptyB := inferInstance
      bifinite := W.bifinite
      pair := composeRetractions sr W.pair }⟩

/-- Lawson-compact algebraic dcpo data used by the cited algebraic theorem. -/
structure LawsonAlgebraic
    (A : Type u) [PartialOrder A] : Type u where
  dcpo : IsDcpo A
  algebraic : AbramskyJung.Chapter3.IsAlgebraicDomain A
  lawsonCompact :
    AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain A)

end

end CoherentContinuousAlgebraicRetracts
