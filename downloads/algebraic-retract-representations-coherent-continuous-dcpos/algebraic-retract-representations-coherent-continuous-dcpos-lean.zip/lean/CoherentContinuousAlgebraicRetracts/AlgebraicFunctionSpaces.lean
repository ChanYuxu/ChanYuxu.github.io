import CoherentContinuousAlgebraicRetracts.BifiniteKernels
import CoherentContinuousAlgebraicRetracts.FiniteDomainFunctions
import CoherentContinuousAlgebraicRetracts.FiniteCodomainKernels

/-!
# Luan–Li's algebraic function-space results

Both proofs use the bifinite domain's actual finite kernel images.
Precomposition makes the source finite (Theorem 3.5); postcomposition
makes the target finite (Theorem 5.6).
-/

set_option autoImplicit false
set_option maxHeartbeats 1800000

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

attribute [local instance] kernelImagePartialOrder

variable {A B : Type u} [PartialOrder A] [PartialOrder B]

private def prePair (hA : IsDcpo A) (k : Chapter3.KernelOperator B) :
    Chapter3.ContinuousSectionRetractionPair
      (FunctionSpace k.ImageCarrier A) (FunctionSpace B A) :=
  FunctionSpace.continuousRetract hA hA (kernelImagePair k) (FunctionSpace.identityRetract A)

private theorem prePair_below (hA : IsDcpo A) (k : Chapter3.KernelOperator B)
    (f : FunctionSpace B A) :
    (prePair hA k).s ((prePair hA k).r f) ≤ f :=
  fun x ↦ f.toContFun.continuous.1 (k.below x)

private def postPair (hB : IsDcpo B) (k : Chapter3.KernelOperator B) :
    Chapter3.ContinuousSectionRetractionPair
      (FunctionSpace A k.ImageCarrier) (FunctionSpace A B) :=
  FunctionSpace.continuousRetract (kernelImage_isDcpo k hB) hB
    (FunctionSpace.identityRetract A) (kernelImagePair k)

private theorem postPair_below (hB : IsDcpo B) (k : Chapter3.KernelOperator B)
    (f : FunctionSpace A B) :
    (postPair hB k).s ((postPair hB k).r f) ≤ f :=
  fun x ↦ k.below (f x)

/-- Luan–Li (2025), Theorem 3.5: Lawson compactness and algebraicity of
the Scott-continuous function space out of a bifinite source. -/
def luanLi_3_5 (hA : LawsonAlgebraic A) (hB : UnpointedBifinite B) :
    LawsonAlgebraic (FunctionSpace B A) := by
  let K := hB.toKernelApproximation
  let I := K.operators
  letI : Nonempty I := K.directed.1.to_subtype
  let p (i : I) : Chapter3.KernelOperator (FunctionSpace B A) :=
    kernelOfPair (prePair hA.dcpo i.1) (prePair_below hA.dcpo i.1)
  let F := KernelApproximation.ofIndexed p (by
    intro i j
    obtain ⟨k, hk, hik, hjk⟩ := K.directed.2 i.2 j.2
    exact ⟨⟨k, hk⟩, fun f x ↦ f.toContFun.continuous.1 (hik x),
      fun f x ↦ f.toContFun.continuous.1 (hjk x)⟩) (by
    intro f
    constructor
    · rintro _ ⟨i, rfl⟩
      exact (p i).below f
    · intro g hg x
      have hSup := f.toContFun.continuous.2 (K.values_directed x) (K.supremum x)
      apply hSup.2 (g x)
      rintro _ ⟨_, ⟨k, hk, rfl⟩, rfl⟩
      exact hg ⟨⟨k, hk⟩, rfl⟩ x)
  let stage (i : I) : LawsonAlgebraic (p i).ImageCarrier := by
    letI : Finite i.1.ImageCarrier := hB.finite_image i.1 i.2
    exact lawsonAlgebraic_orderIso
      (pairImageIso (prePair hA.dcpo i.1) (prePair_below hA.dcpo i.1))
      (FiniteDomain.lawsonAlgebraic hA)
  have hAlg : ∀ k ∈ F.operators, Chapter3.IsAlgebraicDomain k.ImageCarrier := by
    rintro _ ⟨i, rfl⟩
    exact (stage i).algebraic
  have hFdcpo : IsDcpo (FunctionSpace B A) := FunctionSpace.isDcpo_of_codomain hA.dcpo
  exact ⟨hFdcpo, F.algebraic hAlg,
    F.lawsonCompact hFdcpo hAlg (by
      rintro _ ⟨i, rfl⟩
      exact (stage i).lawsonCompact)⟩

/-- Luan–Li (2025), Theorem 5.6: maps into a bifinite codomain form a
bifinite domain. Neither the source nor the codomain is assumed pointed. -/
def luanLi_5_6 (hA : LawsonAlgebraic A) (hB : UnpointedBifinite B) :
    UnpointedBifinite (FunctionSpace A B) := by
  let K := hB.toKernelApproximation
  let I := K.operators
  letI : Nonempty I := K.directed.1.to_subtype
  let p (i : I) : Chapter3.KernelOperator (FunctionSpace A B) :=
    kernelOfPair (postPair hB.dcpo i.1) (postPair_below hB.dcpo i.1)
  let F := KernelApproximation.ofIndexed p (by
    intro i j
    obtain ⟨k, hk, hik, hjk⟩ := K.directed.2 i.2 j.2
    exact ⟨⟨k, hk⟩, fun f x ↦ hik (f x), fun f x ↦ hjk (f x)⟩) (by
    intro f
    constructor
    · rintro _ ⟨i, rfl⟩
      exact (p i).below f
    · intro g hg x
      apply (K.supremum (f x)).2 (g x)
      rintro _ ⟨k, hk, rfl⟩
      exact hg ⟨⟨k, hk⟩, rfl⟩ x)
  have hM := (algebraic_lawsonCompact_iff_compactBasis_propertyM_proved A hA.dcpo
    (basis_to_raw hA.algebraic)).1 hA.lawsonCompact
  let stage (i : I) : UnpointedBifinite (p i).ImageCarrier := by
    letI : Finite i.1.ImageCarrier := hB.finite_image i.1 i.2
    exact bifinite_orderIso
      (pairImageIso (postPair hB.dcpo i.1) (postPair_below hB.dcpo i.1))
      (FiniteCodomain.functionSpace_bifinite hA.algebraic hM)
  apply F.bifinite (FunctionSpace.isDcpo_of_codomain hB.dcpo)
  intro k hk
  let i : I := Classical.choose (show k ∈ Set.range p from hk)
  have hi : p i = k := Classical.choose_spec (show k ∈ Set.range p from hk)
  exact hi ▸ stage i

/-- Source item `thm:algebraic-function-spaces`. Both conclusions of
Luan–Li (2025), Theorems 3.5 and 5.6, are accompanied by Lean proofs. -/
def thm_algebraic_function_spaces
    {A B : Type u} [PartialOrder A] [PartialOrder B]
    [Nonempty A] [Nonempty B]
    (hA : LawsonAlgebraic A) (hB : UnpointedBifinite B) :
    LawsonAlgebraic (FunctionSpace B A) ×
      UnpointedBifinite (FunctionSpace A B) :=
  ⟨luanLi_3_5 hA hB, luanLi_5_6 hA hB⟩

end

end CoherentContinuousAlgebraicRetracts
