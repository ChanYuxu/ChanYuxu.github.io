import CoherentContinuousAlgebraicRetracts.FiniteSystemPresentation
import Practice.DomainTheory.Papers.CoherentContinuousRetracts.FiniteMUB

/-!
# Restriction to a finite validity cover

This file formalizes the finite-open restriction used in
`lem:compact-open-restriction`.  Given a finite family of presentation
indices whose validity opens cover the source, we restrict the index poset to
their upward closure.  The restricted presentation still reconstructs the
source and its index poset has property `M`.
-/

set_option autoImplicit false
set_option maxHeartbeats 1200000

universe u v

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

variable {D : Type u} [PartialOrder D]

namespace FiniteCoverRestriction

variable (R : RefinementPresentationData.{u, v} D)

/-- Indices lying above at least one member of the finite cover. -/
abbrev RestrictedIndex (K : Set R.P) :=
  {p : R.P // p ∈ Chapter2.upperClosure K}

def restrictedValidity (K : Set R.P) (p : RestrictedIndex R K) : Set D :=
  R.binary.V p.1

def restrictedApproximant (K : Set R.P) (p : RestrictedIndex R K) : D :=
  R.h p.1

def restrictedRefinements
    (K : Set R.P) (p q : RestrictedIndex R K) :
    Set (RestrictedIndex R K) :=
  {w | w.1 ∈ R.binary.refinements p.1 q.1}

private theorem restricted_of_le_left
    {K : Set R.P} {p : RestrictedIndex R K} {w : R.P}
    (hpw : p.1 ≤ w) : w ∈ Chapter2.upperClosure K := by
  rcases p.2 with ⟨k, hkK, hkp⟩
  exact ⟨k, hkK, le_trans hkp hpw⟩

theorem restrictedRefinements_finite
    (K : Set R.P) (p q : RestrictedIndex R K) :
    (restrictedRefinements R K p q).Finite := by
  change (Subtype.val ⁻¹' R.binary.refinements p.1 q.1).Finite
  have hinj : Function.Injective
      (fun z : RestrictedIndex R K ↦ z.1) := Subtype.val_injective
  exact (R.binary.refinements_finite p.1 q.1).preimage hinj.injOn

theorem restrictedRefinements_upper
    (K : Set R.P) (p q : RestrictedIndex R K) :
    restrictedRefinements R K p q ⊆
      Chapter2.upperBounds ({p, q} : Set (RestrictedIndex R K)) := by
  intro w hw z hz
  have hwUpper := R.binary.refinements_upper p.1 q.1 hw
  rcases hz with rfl | hz
  · exact hwUpper (by simp)
  · have hzq : z = q := by simpa using hz
    subst z
    exact hwUpper (by simp)

theorem restrictedRefinements_lowerCofinal
    (K : Set R.P) (p q : RestrictedIndex R K) :
    Chapter2.upperBounds ({p, q} : Set (RestrictedIndex R K)) =
      Chapter2.upperClosure (restrictedRefinements R K p q) := by
  apply Set.Subset.antisymm
  · intro v hv
    have hpv : p.1 ≤ v.1 := hv (by simp)
    have hqv : q.1 ≤ v.1 := hv (by simp)
    have hvAmbient : v.1 ∈ Chapter2.upperBounds ({p.1, q.1} : Set R.P) := by
      intro z hz
      rcases hz with rfl | hz
      · exact hpv
      · have hzq : z = q.1 := by simpa using hz
        subst z
        exact hqv
    rw [R.binary.refinements_lowerCofinal p.1 q.1] at hvAmbient
    rcases hvAmbient with ⟨w, hwR, hwv⟩
    have hpw := R.binary.refinements_upper p.1 q.1 hwR
      (show p.1 ∈ ({p.1, q.1} : Set R.P) by simp)
    let w' : RestrictedIndex R K :=
      ⟨w, restricted_of_le_left R hpw⟩
    exact ⟨w', hwR, hwv⟩
  · rintro v ⟨w, hwR, hwv⟩ z hz
    have hwUpper := restrictedRefinements_upper R K p q hwR
    exact le_trans (hwUpper hz) hwv

private theorem refinement_member_restricted
    {K : Set R.P} {p q : RestrictedIndex R K} {w : R.P}
    (hw : w ∈ R.binary.refinements p.1 q.1) :
    w ∈ Chapter2.upperClosure K := by
  have hpw := R.binary.refinements_upper p.1 q.1 hw
    (show p.1 ∈ ({p.1, q.1} : Set R.P) by simp)
  exact restricted_of_le_left R hpw

theorem exact_restricted_decomposition
    (K : Set R.P) (p q : RestrictedIndex R K) :
    restrictedValidity R K p ∩ restrictedValidity R K q =
      Set.sUnion
        (restrictedValidity R K '' restrictedRefinements R K p q :
          Set (Set D)) := by
  apply Set.Subset.antisymm
  · intro x hx
    have hxAmbient : x ∈ R.binary.V p.1 ∩ R.binary.V q.1 := hx
    rw [R.binary.exact_refinement_decomposition p.1 q.1] at hxAmbient
    rcases Set.mem_sUnion.mp hxAmbient with ⟨U, hU, hxU⟩
    rcases hU with ⟨w, hwR, rfl⟩
    let w' : RestrictedIndex R K :=
      ⟨w, refinement_member_restricted R hwR⟩
    exact Set.mem_sUnion_of_mem hxU ⟨w', hwR, rfl⟩
  · intro x hx
    rcases Set.mem_sUnion.mp hx with ⟨U, hU, hxU⟩
    rcases hU with ⟨w, hwR, rfl⟩
    have hpw := R.binary.refinements_upper p.1 q.1 hwR
      (show p.1 ∈ ({p.1, q.1} : Set R.P) by simp)
    have hqw := R.binary.refinements_upper p.1 q.1 hwR
      (show q.1 ∈ ({p.1, q.1} : Set R.P) by simp)
    exact ⟨R.binary.validity_antitone hpw hxU,
      R.binary.validity_antitone hqw hxU⟩

noncomputable def restrictedBinaryCore (K : Set R.P) :
    FiniteBinaryRefinementCore
      (D := D) (P := RestrictedIndex R K) where
  V := restrictedValidity R K
  validity_antitone := by
    intro p q hpq
    exact R.binary.validity_antitone hpq
  refinements := restrictedRefinements R K
  refinements_finite := restrictedRefinements_finite R K
  refinements_upper := restrictedRefinements_upper R K
  refinements_lowerCofinal := restrictedRefinements_lowerCofinal R K
  exact_refinement_decomposition := exact_restricted_decomposition R K

private theorem choose_cover_index
    {K : Set R.P}
    (hCover : (Set.univ : Set D) ⊆
      Set.sUnion (R.binary.V '' K : Set (Set D)))
    (x : D) :
    ∃ k ∈ K, x ∈ R.binary.V k := by
  rcases Set.mem_sUnion.mp (hCover (Set.mem_univ x)) with ⟨U, hU, hxU⟩
  rcases hU with ⟨k, hkK, rfl⟩
  exact ⟨k, hkK, hxU⟩

theorem restricted_validity_cover
    {K : Set R.P}
    (hCover : (Set.univ : Set D) ⊆
      Set.sUnion (R.binary.V '' K : Set (Set D)))
    (x : D) :
    ∃ p : RestrictedIndex R K, x ∈ restrictedValidity R K p := by
  rcases choose_cover_index R hCover x with ⟨k, hkK, hxk⟩
  exact ⟨⟨k, ⟨k, hkK, le_rfl⟩⟩, hxk⟩

theorem restricted_locally_cofinal
    {K : Set R.P}
    (hCover : (Set.univ : Set D) ⊆
      Set.sUnion (R.binary.V '' K : Set (Set D)))
    {d x : D} (hdx : d ≪ x) :
    ∃ p : RestrictedIndex R K,
      x ∈ restrictedValidity R K p ∧
        d ≤ restrictedApproximant R K p := by
  rcases R.locally_cofinal hdx with ⟨p, hxp, hdhp⟩
  rcases choose_cover_index R hCover x with ⟨k, hkK, hxk⟩
  have hxInter : x ∈ R.binary.V p ∩ R.binary.V k := ⟨hxp, hxk⟩
  rw [R.binary.exact_refinement_decomposition p k] at hxInter
  rcases Set.mem_sUnion.mp hxInter with ⟨U, hU, hxU⟩
  rcases hU with ⟨w, hwR, rfl⟩
  have hpw := R.binary.refinements_upper p k hwR
    (show p ∈ ({p, k} : Set R.P) by simp)
  have hkw := R.binary.refinements_upper p k hwR
    (show k ∈ ({p, k} : Set R.P) by simp)
  let w' : RestrictedIndex R K := ⟨w, ⟨k, hkK, hkw⟩⟩
  exact ⟨w', hxU, le_trans hdhp (R.h_monotone hpw)⟩

theorem restricted_lower_finite
    (K : Set R.P) : IsLowerFinite (RestrictedIndex R K) := by
  intro p
  apply Set.Finite.of_finite_image
  · apply (R.lower_finite p.1).subset
    intro z hz
    rcases hz with ⟨q, hq, rfl⟩
    rcases hq with ⟨z, hz, hqz⟩
    have hzp : z = p := by simpa using hz
    subst z
    exact ⟨p.1, by simp, hqz⟩
  · exact Set.injOn_of_injective Subtype.val_injective

/-- Restrict a presentation to the upward closure of a covering family. -/
noncomputable def restrictedData
    [Nonempty D] {K : Set R.P} (hK : K.Nonempty)
    (hCover : (Set.univ : Set D) ⊆
      Set.sUnion (R.binary.V '' K : Set (Set D))) :
    RefinementPresentationData D where
  P := RestrictedIndex R K
  orderP := inferInstance
  nonemptyP := by
    rcases hK with ⟨k, hkK⟩
    exact ⟨⟨k, ⟨k, hkK, le_rfl⟩⟩⟩
  binary := restrictedBinaryCore R K
  V_scottOpen := fun p ↦ R.V_scottOpen p.1
  h := restrictedApproximant R K
  h_monotone := by
    intro p q hpq
    exact R.h_monotone hpq
  locally_approximating := by
    intro x p hxp
    exact R.locally_approximating hxp
  validity_cover := restricted_validity_cover R hCover
  locally_cofinal := restricted_locally_cofinal R hCover
  lower_finite := restricted_lower_finite R K

/-! ## Finite roots and property `M` -/

def roots (K : Set R.P) : Set (RestrictedIndex R K) :=
  {p | p.1 ∈ K}

theorem roots_finite {K : Set R.P} (hK : K.Finite) :
    (roots R K).Finite := by
  change (Subtype.val ⁻¹' K).Finite
  have hinj : Function.Injective
      (fun z : RestrictedIndex R K ↦ z.1) := Subtype.val_injective
  exact hK.preimage hinj.injOn

theorem roots_upper (K : Set R.P) :
    roots R K ⊆
      Chapter2.upperBounds (∅ : Set (RestrictedIndex R K)) := by
  intro p hp z hz
  exact hz.elim

theorem roots_lowerCofinal (K : Set R.P) :
    Chapter2.upperBounds (∅ : Set (RestrictedIndex R K)) =
      Chapter2.upperClosure (roots R K) := by
  apply Set.Subset.antisymm
  · intro p hp
    rcases p.2 with ⟨k, hkK, hkp⟩
    let k' : RestrictedIndex R K := ⟨k, ⟨k, hkK, le_rfl⟩⟩
    exact ⟨k', hkK, hkp⟩
  · rintro p ⟨k, hk, hkp⟩ z hz
    exact hz.elim

theorem empty_complete {K : Set R.P} (hK : K.Finite) :
    CompleteMUBSet (∅ : Set (RestrictedIndex R K)) :=
  completeMUBSet_of_finite_lowerCofinal
    (roots_finite R hK) (roots_upper R K) (roots_lowerCofinal R K)

theorem empty_finite {K : Set R.P} (hK : K.Finite) :
    (MinimalUpperBounds (∅ : Set (RestrictedIndex R K))).Finite :=
  minimalUpperBounds_finite_of_finite_lowerCofinal
    (roots_finite R hK) (roots_upper R K) (roots_lowerCofinal R K)

theorem propertyM {K : Set R.P} (hK : K.Finite) :
    HasPropertyM (RestrictedIndex R K) :=
  hasPropertyM_of_binary_of_empty_finite_complete
    (FiniteBinaryRefinementCore.hasFiniteCompleteBinaryMUBs
      (restrictedBinaryCore R K))
    (empty_complete R hK) (empty_finite R hK)

/-! ## Extracting a finite cover from Scott compactness -/

theorem exists_finite_validity_cover
    [Nonempty D] (hScott : IsScottCompactSpace D) :
    ∃ K : Set R.P, K.Finite ∧ K.Nonempty ∧
      (Set.univ : Set D) ⊆
        Set.sUnion (R.binary.V '' K : Set (Set D)) := by
  let cover : Set (Set D) := R.binary.V '' (Set.univ : Set R.P)
  have hOpen : ∀ U ∈ cover, ScottOpen U := by
    intro U hU
    rcases hU with ⟨p, _hp, rfl⟩
    exact R.V_scottOpen p
  have hCovered : (Set.univ : Set D) ⊆ Set.sUnion cover := by
    intro x _hx
    rcases R.validity_cover x with ⟨p, hxp⟩
    exact Set.mem_sUnion_of_mem hxp ⟨p, Set.mem_univ p, rfl⟩
  rcases hScott cover hOpen hCovered with
    ⟨finiteCover, hFiniteSub, hFinite, hFiniteCovers⟩
  rcases exists_finite_preimage_cover hFinite hFiniteSub with
    ⟨K, hKfinite, _hKuniv, hFiniteImage⟩
  have hKCovers : (Set.univ : Set D) ⊆
      Set.sUnion (R.binary.V '' K : Set (Set D)) := by
    intro x hx
    rcases Set.mem_sUnion.mp (hFiniteCovers hx) with ⟨U, hUfinite, hxU⟩
    rcases hFiniteImage hUfinite with ⟨p, hpK, hUp⟩
    subst U
    exact Set.mem_sUnion_of_mem hxU ⟨p, hpK, rfl⟩
  have hKnonempty : K.Nonempty := by
    let x : D := Classical.choice ‹Nonempty D›
    rcases choose_cover_index R hKCovers x with ⟨k, hkK, _hxk⟩
    exact ⟨k, hkK⟩
  exact ⟨K, hKfinite, hKnonempty, hKCovers⟩

end FiniteCoverRestriction

end

end CoherentContinuousAlgebraicRetracts
