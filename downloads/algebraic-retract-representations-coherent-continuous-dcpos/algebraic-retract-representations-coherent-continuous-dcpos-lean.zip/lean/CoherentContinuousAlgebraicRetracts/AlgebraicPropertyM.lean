import CoherentContinuousAlgebraicRetracts.ContinuousCoherence

/-! # Jung's property-M criterion for algebraic dcpos -/

set_option autoImplicit false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

variable {A : Type u} [PartialOrder A]

/-- A finite collection of compact elements with an upper bound has a
compact upper bound below it. This includes the empty family. -/
theorem exists_compact_upper_le
    (hAlg : Chapter3.IsAlgebraicDomain A)
    {F : Set (CompactBasis A)} (hF : F.Finite)
    {x : A} (hx : ∀ a ∈ F, a.1 ≤ x) :
    ∃ b : CompactBasis A, b.1 ≤ x ∧ b ∈ Chapter2.upperBounds F := by
  have hVals : (Subtype.val '' F : Set A).Finite := hF.image _
  obtain ⟨b, hb, hUpper⟩ := finite_wayBelow_basis_upper hAlg hVals (by
    rintro _ ⟨a, ha, rfl⟩
    exact prop_2_2_2_2 le_rfl a.2 (hx a ha))
  exact ⟨⟨b, hb.1⟩, prop_2_2_2_1 hb.2,
    fun a ha ↦ hUpper a.1 ⟨a, ha, rfl⟩⟩

/-- Complete MUBs of finite compact families are cofinal below any ambient
upper bound, not just below a compact upper bound. -/
theorem exists_compact_mub_le
    (hAlg : Chapter3.IsAlgebraicDomain A)
    {F : Set (CompactBasis A)} (hF : F.Finite) (hMub : CompleteMUBSet F)
    {x : A} (hx : ∀ a ∈ F, a.1 ≤ x) :
    ∃ m ∈ MinimalUpperBounds F, m.1 ≤ x := by
  obtain ⟨b, hbx, hb⟩ := exists_compact_upper_le hAlg hF hx
  rw [hMub] at hb
  obtain ⟨m, hm, hmb⟩ := hb
  exact ⟨m, hm, le_trans hmb hbx⟩

/-- Jung (1989), Corollary 4.19, on the actual compact basis of the dcpo.
The empty-family case yields Scott compactness, while the binary-family
case yields coherence. -/
theorem algebraic_lawsonCompact_iff_compactBasis_propertyM_proved
    (A : Type u) [PartialOrder A] (hA : IsDcpo A)
    (hAlg : Chapter2.IsAlgebraicDomain A) :
    Chapter4.IsLawsonCompact (asOrderedDomain A) ↔
      HasPropertyM (CompactBasis A) := by
  have hBasis := prop_2_2_4_1 hAlg
  have hCont : Chapter3.IsContinuousDomain A := ⟨CompactSet, hBasis⟩
  constructor
  · intro hL
    obtain ⟨hScott, hCoh⟩ :=
      (continuous_lawsonCompact_iff_scottCompact_and_coherent_proved hA hCont).1 hL
    have hBinary := compactBasis_hasFiniteCompleteBinaryMUBs A hAlg hCoh
    obtain ⟨F, hF, hAll, _⟩ := exists_finiteCompactUpper_between
      hAlg ⟨hScott, fun _ _ _ _ ↦ Set.mem_univ _⟩
      scottOpen_univ (Set.subset_univ (Set.univ : Set A))
    have hSub : F ⊆ Chapter2.upperBounds (∅ : Set (CompactBasis A)) := by
      intro _ _ a ha
      exact False.elim (Set.notMem_empty a ha)
    have hCover : Chapter2.upperBounds (∅ : Set (CompactBasis A)) =
        Chapter2.upperClosure F := by
      apply Set.Subset.antisymm
      · intro k _
        obtain ⟨U, ⟨p, hp, rfl⟩, hpK⟩ :=
          Set.mem_sUnion.mp (hAll (Set.mem_univ k.1))
        obtain ⟨q, hq, hqK⟩ := hpK
        have hEq : q = p.1 := by simpa using hq
        refine ⟨p, hp, ?_⟩
        change p.1 ≤ k.1
        simpa only [hEq] using hqK
      · exact fun _ _ a ha ↦ False.elim (Set.notMem_empty a ha)
    exact hasPropertyM_of_binary_of_empty_finite_complete hBinary
      (completeMUBSet_of_finite_lowerCofinal hF hSub hCover)
      (minimalUpperBounds_finite_of_finite_lowerCofinal hF hSub hCover)
  · intro hM
    have hFin : ∀ {F : Set (CompactBasis A)}, F.Finite →
        ScottCompact {x : A | ∀ a ∈ F, a.1 ≤ x} := by
      intro F hF
      have heq : {x : A | ∀ a ∈ F, a.1 ≤ x} =
          finiteCompactUpper (MinimalUpperBounds F) := by
        ext x
        constructor
        · intro hx
          obtain ⟨m, hm, hmx⟩ := exists_compact_mub_le hBasis hF (hM.1 F hF) hx
          have hxP : x ∈ compactPrincipalUpper A m := ⟨m.1, by simp, hmx⟩
          exact Set.mem_sUnion_of_mem hxP ⟨m, hm, rfl⟩
        · intro hx a ha
          obtain ⟨U, ⟨m, hm, rfl⟩, hmx⟩ := Set.mem_sUnion.mp hx
          obtain ⟨z, hz, hzx⟩ := hmx
          have heq : z = m.1 := by simpa using hz
          exact le_trans (show a.1 ≤ m.1 from hm.1 ha) (heq ▸ hzx)
      rw [heq]
      exact (finiteCompactUpper_compactSaturated (hM.2 F hF)).1
    have hScott : IsScottCompactSpace A := by
      simpa only [Set.mem_empty_iff_false, false_implies, implies_true, Set.setOf_true]
        using hFin (F := ∅) Set.finite_empty
    have hCoh : IsCoherent A := by
      apply algebraic_coherent_of_compact_principal_intersections_internal hA hAlg
      intro p q hp hq
      have heq : Chapter2.upperClosure ({p} : Set A) ∩
          Chapter2.upperClosure ({q} : Set A) =
          {x : A | ∀ a ∈ ({⟨p, hp⟩, ⟨q, hq⟩} : Set (CompactBasis A)), a.1 ≤ x} := by
        ext x
        simp [Chapter2.upperClosure]
      rw [heq]
      exact hFin (by simp)
    exact (continuous_lawsonCompact_iff_scottCompact_and_coherent_proved hA hCont).2
      ⟨hScott, hCoh⟩

end CoherentContinuousAlgebraicRetracts
