import CoherentContinuousAlgebraicRetracts.InternalLawson

/-!
# Two coherence criteria for continuous dcpos

Here we prove the manuscript's Lawson criterion (Jia–Jung–Li, Lemma 3.1
and Theorem 3.4, specialized to continuous dcpos), and the Scott-open
lattice criterion (Abramsky–Jung, Proposition 4.2.16).
-/

set_option autoImplicit false
set_option linter.unnecessarySimpa false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

variable {D : Type u} [PartialOrder D]

/-- The generated Lawson topology contains every Scott-open set. -/
theorem isOpen_lawson_of_scottOpen {U : Set D} (hU : ScottOpen U) :
    @IsOpen D (lawsonGeneratedTopologicalSpace D) U :=
  (lawsonTopology_iff_generatedOpen U).1
    (Chapter4.lawsonSubbasis_subset_topology (asOrderedDomain D) (Or.inl hU))

theorem isClosed_lawson_principalUpper (x : D) :
    @IsClosed D (lawsonGeneratedTopologicalSpace D)
      (Chapter2.upperClosure ({x} : Set D)) := by
  letI : TopologicalSpace D := lawsonGeneratedTopologicalSpace D
  exact ⟨(lawsonTopology_iff_generatedOpen _).1
    (Chapter4.lawsonSubbasis_subset_topology (asOrderedDomain D)
      (Or.inr ⟨x, rfl⟩))⟩

/-- Bridge between the cover definition and mathlib compactness for the
same generated topology, without changing compactness or its carrier. -/
theorem lawsonCompact_iff_isCompact_univ :
    Chapter4.IsLawsonCompact (asOrderedDomain D) ↔
      @IsCompact D (lawsonGeneratedTopologicalSpace D) Set.univ := by
  classical
  letI : TopologicalSpace D := lawsonGeneratedTopologicalSpace D
  constructor
  · intro hL
    apply isCompact_of_finite_subcover
    intro I U hU hCover
    obtain ⟨C, hCsub, hCfin, hCcov⟩ := hL (Set.range U) (by
      rintro _ ⟨i, rfl⟩
      exact (lawsonTopology_iff_generatedOpen _).2 (hU i)) (by
      intro x hx
      obtain ⟨i, hi⟩ := Set.mem_iUnion.mp (hCover hx)
      exact Set.mem_sUnion_of_mem hi ⟨i, rfl⟩)
    let pick (W : C) : I := Classical.choose (hCsub W.2)
    have hPick (W : C) : U (pick W) = W.1 :=
      Classical.choose_spec (hCsub W.2)
    letI : Fintype C := hCfin.fintype
    refine ⟨Finset.univ.image pick, ?_⟩
    intro x hx
    obtain ⟨W, hW, hxW⟩ := Set.mem_sUnion.mp (hCcov hx)
    let w : C := ⟨W, hW⟩
    exact Set.mem_iUnion_of_mem (pick w) (Set.mem_iUnion_of_mem
      (Finset.mem_image.mpr ⟨w, Finset.mem_univ _, rfl⟩) (hPick w ▸ hxW))
  · intro h C hO hC
    have hc : IsCompact (Set.univ : Set D) := h
    obtain ⟨t, ht⟩ := hc.elim_finite_subcover (fun U : C ↦ U.1)
      (fun U ↦ (lawsonTopology_iff_generatedOpen _).1 (hO U.2)) (by
        intro x hx
        obtain ⟨U, hU, hxU⟩ := Set.mem_sUnion.mp (hC hx)
        exact Set.mem_iUnion_of_mem ⟨U, hU⟩ hxU)
    refine ⟨Subtype.val '' (t : Set C), ?_, t.finite_toSet.image _, ?_⟩
    · rintro _ ⟨c, _, rfl⟩
      exact c.2
    · intro x hx
      obtain ⟨U, hU⟩ := Set.mem_iUnion.mp (ht hx)
      obtain ⟨hUt, hxU⟩ := Set.mem_iUnion.mp hU
      exact Set.mem_sUnion_of_mem hxU ⟨U, hUt, rfl⟩

theorem isClosed_lawson_finiteUpper {F : Set D} (hF : F.Finite) :
    @IsClosed D (lawsonGeneratedTopologicalSpace D) (Chapter2.upperClosure F) := by
  letI : TopologicalSpace D := lawsonGeneratedTopologicalSpace D
  have hEq : Chapter2.upperClosure F =
      ⋃ x ∈ F, Chapter2.upperClosure ({x} : Set D) := by
    ext y
    simp [Chapter2.upperClosure]
  rw [hEq]
  exact hF.isClosed_biUnion (fun x _ ↦ isClosed_lawson_principalUpper x)

/-- A compact saturated set is Lawson closed: approximate it from above by
finitely generated upper sets inside each Scott-open neighborhood. -/
theorem isClosed_lawson_of_compactSaturated
    (hD : Chapter3.IsContinuousDomain D) {K : Set D} (hK : CompactSaturated K) :
    @IsClosed D (lawsonGeneratedTopologicalSpace D) K := by
  letI : TopologicalSpace D := lawsonGeneratedTopologicalSpace D
  constructor
  apply isOpen_iff_mem_nhds.2
  intro x hx
  let O : Set D := (Chapter2.lowerClosure ({x} : Set D))ᶜ
  have hO : ScottOpen O := by
    simpa [O, ScottOpen] using scottClosed_principal_ideal x
  have hKO : K ⊆ O := by
    intro y hy
    rintro ⟨z, hz, hyz⟩
    have hzx : z = x := by simpa using hz
    exact hx (hK.2 hy (hzx ▸ hyz))
  obtain ⟨F, hF, _, _, hKV, hVF, hFO⟩ :=
    Chapter4.exists_finiteUpperClosure_between (asOrderedDomain D) hD hK hO hKO
  let G : Set D := F
  let V : Set D := Chapter2.upperClosure G
  have hClosed : IsClosed V := isClosed_lawson_finiteUpper (D := D) (F := G) hF
  have hxV : x ∈ Vᶜ := fun h ↦ hFO h ⟨x, by simp, le_rfl⟩
  exact Filter.mem_of_superset (hClosed.isOpen_compl.mem_nhds hxV)
    (show Vᶜ ⊆ Kᶜ from fun _ hy hyK ↦ hy (hVF (hKV hyK)))

/-- A Lawson-closed subset of a Lawson-compact carrier is Scott compact.
The complement is added to a Scott-open cover and removed after selecting
a finite subcover. -/
theorem scottCompact_of_lawsonClosed
    (hLawson : Chapter4.IsLawsonCompact (asOrderedDomain D))
    {K : Set D} (hK : @IsClosed D (lawsonGeneratedTopologicalSpace D) K) :
    ScottCompact K := by
  classical
  letI : TopologicalSpace D := lawsonGeneratedTopologicalSpace D
  change IsClosed K at hK
  intro cover hOpen hCover
  rcases hLawson (insert Kᶜ cover) (by
      intro U hU
      rcases Set.mem_insert_iff.mp hU with rfl | hU
      · exact (lawsonTopology_iff_generatedOpen _).2 hK.isOpen_compl
      · exact Chapter4.lawsonSubbasis_subset_topology (asOrderedDomain D)
          (Or.inl (hOpen U hU))) (by
      intro x _
      by_cases hx : x ∈ K
      · rcases Set.mem_sUnion.mp (hCover hx) with ⟨U, hU, hxU⟩
        exact Set.mem_sUnion_of_mem hxU (Set.mem_insert_of_mem _ hU)
      · exact Set.mem_sUnion_of_mem hx (Set.mem_insert _ _)) with
    ⟨C, hCsub, hCfin, hCCover⟩
  refine ⟨C ∩ cover, Set.inter_subset_right, hCfin.subset Set.inter_subset_left, ?_⟩
  intro x hx
  rcases Set.mem_sUnion.mp (hCCover (Set.mem_univ x)) with ⟨U, hU, hxU⟩
  rcases Set.mem_insert_iff.mp (hCsub hU) with rfl | hUc
  · exact False.elim (hxU hx)
  · exact Set.mem_sUnion_of_mem hxU ⟨hU, hUc⟩

/-- The exact continuous-dcpo specialization cited by the manuscript. -/
theorem continuous_lawsonCompact_iff_scottCompact_and_coherent_proved
    (hD : IsDcpo D) (hContinuous : Chapter3.IsContinuousDomain D) :
    Chapter4.IsLawsonCompact (asOrderedDomain D) ↔
      IsScottCompactSpace D ∧ IsCoherent D := by
  letI : TopologicalSpace D := lawsonGeneratedTopologicalSpace D
  constructor
  · intro hL
    refine ⟨scottCompact_of_lawsonCompact_internal hL, ?_⟩
    intro K M hK hM
    have hKc : IsClosed K := isClosed_lawson_of_compactSaturated hContinuous hK
    have hMc : IsClosed M := isClosed_lawson_of_compactSaturated hContinuous hM
    exact ⟨scottCompact_of_lawsonClosed hL (hKc.inter hMc),
      saturated_inter hK.2 hM.2⟩
  · rintro ⟨hScott, hCoh⟩
    exact lawsonCompact_of_scottCompact_and_coherent_internal
      hD hContinuous hScott hCoh

open Chapter4 in
/-- Abramsky–Jung, Proposition 4.2.16. For the reverse implication, the
filter generated by the neighborhoods of the two compact saturated sets is
Scott open by multiplicativity. Hofmann–Mislove represents it by their
intersection. -/
theorem continuous_coherent_iff_scottOpenIntersectionWayBelow_proved
    (hD : IsDcpo D) (hCont : Chapter3.IsContinuousDomain D) :
    IsCoherent D ↔ ScottOpenIntersectionWayBelowProperty (asOrderedDomain D) := by
  let E := asOrderedDomain D
  have hWay := scottOpenWayBelow_iff_compactCarrier E hCont
  constructor
  · intro hC O U V hOU hOV
    rcases (hWay _ _).1 hOU with ⟨K, hK, hOK, hKU⟩
    rcases (hWay _ _).1 hOV with ⟨M, hM, hOM, hMV⟩
    exact (hWay _ _).2 ⟨K ∩ M, hC K M hK hM,
      fun _ hx ↦ ⟨hOK hx, hOM hx⟩, fun _ hx ↦ ⟨hKU hx.1, hMV hx.2⟩⟩
  · intro hMult K M hK hM
    let X := Chapter7.ScottTopologySpace D
    let N (K : Set D) := Chapter7.OpenNeighborhoodsOf X K
    let F : Set (Set D) :=
      {W | ScottOpen W ∧ ∃ U ∈ N K, ∃ V ∈ N M, U ∩ V ⊆ W}
    have hShrink (K : Set D) (hK : CompactSaturated K)
        (U : ScottOpenCarrier E) (hKU : K ⊆ U.carrierSet) :
        ∃ U' : ScottOpenCarrier E, K ⊆ U'.carrierSet ∧ ScottOpenWayBelow E U' U := by
      rcases exists_finiteUpperClosure_between E hCont hK U.scott_open hKU with
        ⟨G, hGfin, _, hVopen, hKV, hVG, hGU⟩
      exact ⟨⟨_, hVopen⟩, hKV,
        (hWay _ _).2 ⟨_, finiteUpperClosure_isCompactSaturated E hGfin, hVG, hGU⟩⟩
    have hFilter : Chapter7.IsScottOpenFilterOfOpens X F := by
      refine ⟨fun _ hU ↦ hU.1, ?_, ?_, ?_, ?_⟩
      · exact ⟨scottOpen_univ, Set.univ, ⟨scottOpen_univ, Set.subset_univ _⟩,
          Set.univ, ⟨scottOpen_univ, Set.subset_univ _⟩, Set.subset_univ _⟩
      · rintro U V ⟨_, A, hA, B, hB, hAB⟩ hUV hV
        exact ⟨hV, A, hA, B, hB, hAB.trans hUV⟩
      · rintro U V ⟨hU, A, hA, B, hB, hAB⟩ ⟨hV, C, hC, G, hG, hCG⟩
        exact ⟨scottOpen_inter hU hV,
          A ∩ C, ⟨scottOpen_inter hA.1 hC.1, fun _ hx ↦ ⟨hA.2 hx, hC.2 hx⟩⟩,
          B ∩ G, ⟨scottOpen_inter hB.1 hG.1, fun _ hx ↦ ⟨hB.2 hx, hG.2 hx⟩⟩,
          fun _ hx ↦ ⟨hAB ⟨hx.1.1, hx.2.1⟩, hCG ⟨hx.1.2, hx.2.2⟩⟩⟩
      · intro A hAopen hAdir hUnion
        rcases hUnion with ⟨hOpen, U, hU, V, hV, hUV⟩
        let Uo : ScottOpenCarrier E := ⟨U, hU.1⟩
        let Vo : ScottOpenCarrier E := ⟨V, hV.1⟩
        obtain ⟨U', hKU', hWU⟩ := hShrink K hK Uo hU.2
        obtain ⟨V', hMV', hWV⟩ := hShrink M hM Vo hV.2
        let O := ScottOpenCarrier.inter E U' V'
        let S := ScottOpenCarrier.inter E Uo Vo
        have hOS : ScottOpenWayBelow E O S :=
          hMult O Uo Vo (prop_2_2_2_2 (fun _ hx ↦ hx.1) hWU le_rfl)
            (prop_2_2_2_2 (fun _ hx ↦ hx.2) hWV le_rfl)
        let liftOpen : A → ScottOpenCarrier E := fun W ↦ ⟨W.1, hAopen _ W.2⟩
        have hDir : DirectedSet (Set.range liftOpen) := by
          constructor
          · rcases hAdir.1 with ⟨W, hW⟩
            exact ⟨liftOpen ⟨W, hW⟩, ⟨⟨W, hW⟩, rfl⟩⟩
          · rintro _ ⟨a, rfl⟩ _ ⟨b, rfl⟩
            rcases hAdir.2 a.2 b.2 with ⟨c, hc, hac, hbc⟩
            exact ⟨liftOpen ⟨c, hc⟩, ⟨⟨c, hc⟩, rfl⟩, hac, hbc⟩
        let W : ScottOpenCarrier E := ⟨⋃₀ A, hOpen⟩
        have hSup : IsSup (Set.range liftOpen) W := by
          constructor
          · rintro _ ⟨a, rfl⟩ x hx
            exact Set.mem_sUnion_of_mem hx a.2
          · intro B hB x hx
            rcases Set.mem_sUnion.mp hx with ⟨a, ha, hxa⟩
            exact hB (⟨⟨a, ha⟩, rfl⟩ : liftOpen ⟨a, ha⟩ ∈ Set.range liftOpen) hxa
        rcases hOS hDir hSup hUV with ⟨_, ⟨a, rfl⟩, hOa⟩
        exact ⟨a.1, a.2, hAopen _ a.2, U'.carrierSet, ⟨U'.scott_open, hKU'⟩,
          V'.carrierSet, ⟨V'.scott_open, hMV'⟩, hOa⟩
    have hSober := Chapter7.prop_7_2_27_continuous_domains_sober D hD
      (show Chapter2.IsContinuousDomain D from by
        rcases hCont with ⟨B, hB⟩
        exact ⟨B, basis_to_raw hB⟩)
    have hCompact : Chapter7.IsCompactSubset X (⋂₀ F) :=
      ((Chapter7.theorem_7_2_9_hofmann_mislove_sober X hSober).intersection_candidate
        F hFilter).1.1
    have hUpper {L : Set D} (hL : Saturated L) : Chapter7.IsSaturated X L := by
      intro x y hx hxy
      exact hL hx (prop_2_3_2_open_to_order (fun U hU hxU ↦ hxy U hU hxU))
    have hEq : ⋂₀ F = K ∩ M := by
      apply Set.Subset.antisymm
      · intro x hx
        constructor
        · rw [← Chapter7.saturated_eq_sInter_openNeighborhoods (hUpper hK.2)]
          intro U hU
          exact hx U ⟨hU.1, U, hU, Set.univ, ⟨scottOpen_univ, Set.subset_univ _⟩,
            Set.inter_subset_left⟩
        · rw [← Chapter7.saturated_eq_sInter_openNeighborhoods (hUpper hM.2)]
          intro V hV
          exact hx V ⟨hV.1, Set.univ, ⟨scottOpen_univ, Set.subset_univ _⟩,
            V, hV, Set.inter_subset_right⟩
      · rintro x ⟨hxK, hxM⟩ W ⟨_, U, hU, V, hV, hUV⟩
        exact hUV ⟨hU.2 hxK, hV.2 hxM⟩
    exact ⟨hEq ▸ hCompact, saturated_inter hK.2 hM.2⟩

end CoherentContinuousAlgebraicRetracts
