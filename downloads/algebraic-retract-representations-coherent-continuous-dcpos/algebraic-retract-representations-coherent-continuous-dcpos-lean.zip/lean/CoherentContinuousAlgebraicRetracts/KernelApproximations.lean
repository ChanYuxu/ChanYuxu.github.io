import CoherentContinuousAlgebraicRetracts.AlgebraicPropertyM

/-!
# Compact bases of directed kernel approximations

The image is the actual range with the inherited order. Its compact elements
are precisely the ambient compact elements fixed by the kernel operator.
-/

set_option autoImplicit false
set_option linter.unnecessarySimpa false
set_option maxHeartbeats 1200000

universe u v

namespace CoherentContinuousAlgebraicRetracts

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

variable {A : Type u} [PartialOrder A]

/-- The textbook kernel-image preorder, with antisymmetry made explicit. -/
@[reducible] def kernelImagePartialOrder (K : Chapter3.KernelOperator A) :
    PartialOrder K.ImageCarrier where
  toPreorder := Chapter3.KernelOperator.imageCarrierPreorder K
  le_antisymm _ _ hab hba := Subtype.ext (le_antisymm hab hba)

attribute [local instance] kernelImagePartialOrder

/-- Kernel images are closed under ambient directed suprema. -/
theorem kernelImage_isDcpo (K : Chapter3.KernelOperator A) (hA : IsDcpo A) :
    IsDcpo K.ImageCarrier := by
  intro S hS
  obtain ⟨x, hx⟩ := hA (K.inclusion '' S) (DirectedSet.image K.inclusion_monotone hS)
  have hxIm := K.isSup_mem_range (A := K.inclusion '' S) (by
    rintro _ ⟨y, _, rfl⟩
    exact y.2) hx
  refine ⟨⟨x, hxIm⟩, fun _ hy ↦ hx.1 ⟨_, hy, rfl⟩, ?_⟩
  intro y hy
  apply hx.2 y.1
  rintro _ ⟨z, hz, rfl⟩
  exact hy hz

theorem kernelImage_compact_iff (K : Chapter3.KernelOperator A) (x : K.ImageCarrier) :
    Compact x ↔ Compact x.1 :=
  K.image_wayBelow_iff

def kernelImageCompactInclusion (K : Chapter3.KernelOperator A) :
    CompactBasis K.ImageCarrier ↪ CompactBasis A where
  toFun a := ⟨a.1.1, (kernelImage_compact_iff K a.1).1 a.2⟩
  inj' := fun _ _ h ↦ Subtype.ext (Subtype.ext
    (congrArg (fun c : CompactBasis A ↦ c.1) h))

theorem exists_imageCompact_of_fixed (K : Chapter3.KernelOperator A)
    (a : CompactBasis A) (ha : K.k a.1 = a.1) :
    ∃ b : CompactBasis K.ImageCarrier, kernelImageCompactInclusion K b = a :=
  let a' : K.ImageCarrier := ⟨a.1, (K.mem_range_iff_fixed).2 ha⟩
  ⟨⟨a', (kernelImage_compact_iff K a').2 a.2⟩, Subtype.ext rfl⟩

theorem kernel_fixes_of_le {K L : Chapter3.KernelOperator A}
    (hKL : K ≤ L) {a : A} (ha : K.k a = a) : L.k a = a := by
  apply le_antisymm (L.below a)
  exact le_trans ha.symm.le (hKL a)

/-- A finite directed set has a greatest member. -/
theorem exists_greatest_of_finite_directed
    {S : Set A} (hS : S.Finite) (hDir : DirectedSet S) :
    ∃ x ∈ S, ∀ y ∈ S, y ≤ x :=
  hDir.exists_upper_finite hS (Set.Subset.rfl)

theorem finite_poset_compact [Finite A] (a : A) : Compact a := by
  intro S s hS hs ha
  obtain ⟨x, hx, hUpper⟩ := exists_greatest_of_finite_directed S.toFinite hS
  exact ⟨x, hx, le_trans ha (hs.2 x hUpper)⟩

theorem finite_poset_isDcpo [Finite A] : IsDcpo A := by
  intro S hS
  obtain ⟨x, hx, hUpper⟩ := exists_greatest_of_finite_directed S.toFinite hS
  exact ⟨x, hUpper, fun _ h ↦ h hx⟩

theorem finite_poset_algebraic [Finite A] : Chapter3.IsAlgebraicDomain A := by
  intro a
  have hself : a ∈ Approximants (CompactSet : Set A) a :=
    ⟨finite_poset_compact a, finite_poset_compact a⟩
  exact ⟨⟨⟨a, hself⟩, fun _ ha _ hb ↦
    ⟨a, hself, prop_2_2_2_1 ha.2, prop_2_2_2_1 hb.2⟩⟩,
    ⟨fun _ hx ↦ prop_2_2_2_1 hx.2, fun _ hx ↦ hx hself⟩⟩

theorem monotone_scottContinuous_of_finite [Finite A] {B : Type v} [Preorder B]
    {f : A → B} (hf : Monotone f) : Chapter2.ScottContinuous f := by
  refine ⟨hf, ?_⟩
  intro T t hT ht
  obtain ⟨z, hz, hGreatest⟩ := exists_greatest_of_finite_directed T.toFinite hT
  have hzEq : z = t := le_antisymm (ht.1 hz) (ht.2 z hGreatest)
  subst z
  exact ⟨by rintro _ ⟨z, hZ, rfl⟩; exact hf (ht.1 hZ),
    fun _ hy ↦ hy ⟨t, hz, rfl⟩⟩

theorem finiteKernel_image_algebraic (K : Chapter3.KernelOperator A)
    (hK : (Set.range K.k).Finite) : Chapter3.IsAlgebraicDomain K.ImageCarrier := by
  letI : Finite K.ImageCarrier := hK
  exact finite_poset_algebraic

theorem finiteKernel_value_compact (K : Chapter3.KernelOperator A)
    (hK : (Set.range K.k).Finite) (x : A) : Compact (K.k x) := by
  letI : Finite K.ImageCarrier := hK
  exact (kernelImage_compact_iff K (K.projection x)).1
    (finite_poset_compact (K.projection x))

/-- A nonempty directed family of Scott-continuous kernels with pointwise
supremum the identity. -/
structure KernelApproximation (A : Type u) [PartialOrder A] where
  operators : Set (Chapter3.KernelOperator A)
  directed : DirectedSet operators
  supremum : ∀ x : A, IsSup ((fun k : Chapter3.KernelOperator A ↦ k.k x) '' operators) x

namespace KernelApproximation

/-- Pass from an indexed presentation to the set of its actual operators. -/
def ofIndexed {I : Type v} [Nonempty I]
    (p : I → Chapter3.KernelOperator A)
    (hDir : ∀ i j, ∃ k, p i ≤ p k ∧ p j ≤ p k)
    (hsup : ∀ x : A, IsSup (Set.range (fun i ↦ (p i).k x)) x) :
    KernelApproximation A where
  operators := Set.range p
  directed := by
    constructor
    · let i : I := Classical.choice inferInstance
      exact ⟨p i, ⟨i, rfl⟩⟩
    · rintro _ ⟨i, rfl⟩ _ ⟨j, rfl⟩
      obtain ⟨k, hik, hjk⟩ := hDir i j
      exact ⟨p k, ⟨k, rfl⟩, hik, hjk⟩
  supremum := fun x ↦ by
    rw [← Set.range_comp]
    exact hsup x

theorem values_directed (F : KernelApproximation A) (x : A) :
    DirectedSet ((fun k : Chapter3.KernelOperator A ↦ k.k x) '' F.operators) := by
  apply DirectedSet.image _ F.directed
  intro p q hpq
  exact (show ∀ y, p.k y ≤ q.k y from hpq) x

theorem exists_fix_compact (F : KernelApproximation A) {x : A} (hx : Compact x) :
    ∃ k ∈ F.operators, k.k x = x := by
  rcases hx (F.values_directed x) (F.supremum x) le_rfl with ⟨_, ⟨k, hk, rfl⟩, hxk⟩
  exact ⟨k, hk, le_antisymm (k.below x) hxk⟩

theorem exists_fix_finite (F : KernelApproximation A) {C : Set A} (hC : C.Finite)
    (hCompact : ∀ x ∈ C, Compact x) :
    ∃ k ∈ F.operators, ∀ x ∈ C, k.k x = x := by
  induction C, hC using Set.Finite.induction_on with
  | empty =>
    obtain ⟨k, hk⟩ := F.directed.1
    exact ⟨k, hk, by simp⟩
  | @insert x C hx hC ih =>
    obtain ⟨p, hp, hpX⟩ := F.exists_fix_compact (hCompact x (Set.mem_insert _ _))
    obtain ⟨q, hq, hqC⟩ := ih (fun z hz ↦ hCompact z (Set.mem_insert_of_mem _ hz))
    obtain ⟨k, hk, hpk, hqk⟩ := F.directed.2 hp hq
    refine ⟨k, hk, ?_⟩
    intro y hy
    rcases Set.mem_insert_iff.mp hy with rfl | hy
    · exact kernel_fixes_of_le hpk hpX
    · exact kernel_fixes_of_le hqk (hqC y hy)

/-- Algebraicity is transported by kernels with algebraic images. -/
theorem algebraic (F : KernelApproximation A)
    (hAlg : ∀ k ∈ F.operators, Chapter3.IsAlgebraicDomain k.ImageCarrier) :
    Chapter3.IsAlgebraicDomain A := by
  intro a
  have hLift (k : Chapter3.KernelOperator A) {b : k.ImageCarrier}
      (hb : b ∈ Approximants CompactSet (k.projection a)) :
      b.1 ∈ Approximants CompactSet a := by
    have hB := (kernelImage_compact_iff k b).1 hb.1
    have hbk : b ≤ k.projection a := prop_2_2_2_1 hb.2
    exact ⟨hB, prop_2_2_2_2 le_rfl hB (le_trans hbk (k.below a))⟩
  constructor
  · constructor
    · obtain ⟨k, hk⟩ := F.directed.1
      obtain ⟨b, hb⟩ := (hAlg k hk (k.projection a)).1.1
      exact ⟨b.1, hLift k hb⟩
    · intro b hb c hc
      obtain ⟨k, hk, hFixed⟩ := F.exists_fix_finite (C := {b, c}) (by simp) (by
        intro y hy
        rcases Set.mem_insert_iff.mp hy with rfl | hy
        · exact hb.1
        · have heq : y = c := by simpa using hy
          exact heq ▸ hc.1)
      let b' : k.ImageCarrier := ⟨b, (k.mem_range_iff_fixed).2 (hFixed b (by simp))⟩
      let c' : k.ImageCarrier := ⟨c, (k.mem_range_iff_fixed).2 (hFixed c (by simp))⟩
      have hb' : b' ∈ Approximants CompactSet (k.projection a) := by
        have hcb := (kernelImage_compact_iff k b').2 hb.1
        have hle : b' ≤ k.projection a :=
          k.le_kernel_of_mem_range_le b'.2 (prop_2_2_2_1 hb.2)
        exact ⟨hcb, prop_2_2_2_2 le_rfl hcb hle⟩
      have hc' : c' ∈ Approximants CompactSet (k.projection a) := by
        have hcc := (kernelImage_compact_iff k c').2 hc.1
        have hle : c' ≤ k.projection a :=
          k.le_kernel_of_mem_range_le c'.2 (prop_2_2_2_1 hc.2)
        exact ⟨hcc, prop_2_2_2_2 le_rfl hcc hle⟩
      obtain ⟨d, hd, hbd, hcd⟩ := (hAlg k hk (k.projection a)).1.2 hb' hc'
      exact ⟨d.1, hLift k hd, hbd, hcd⟩
  · refine ⟨fun _ hb ↦ prop_2_2_2_1 hb.2, ?_⟩
    intro y hy
    apply (F.supremum a).2 y
    rintro _ ⟨k, hk, rfl⟩
    have hSpec := hAlg k hk (k.projection a)
    exact (k.inclusion_scottContinuous.2 hSpec.1 hSpec.2).2 y (by
      rintro _ ⟨b, hb, rfl⟩
      exact hy (hLift k hb))

/-- If each kernel image is Lawson compact and algebraic, then so is the
carrier. A finite family of ambient compacts is fixed at a single stage;
the stage's finite compact MUB family is lower cofinal in all ambient
compact upper bounds. -/
theorem lawsonCompact (F : KernelApproximation A) (hA : IsDcpo A)
    (hAlg : ∀ k ∈ F.operators, Chapter3.IsAlgebraicDomain k.ImageCarrier)
    (hL : ∀ k ∈ F.operators,
      Chapter4.IsLawsonCompact (asOrderedDomain k.ImageCarrier)) :
    Chapter4.IsLawsonCompact (asOrderedDomain A) := by
  apply (algebraic_lawsonCompact_iff_compactBasis_propertyM_proved A hA
    (basis_to_raw (F.algebraic hAlg))).2
  have hFinite (C : Set (CompactBasis A)) (hC : C.Finite) :
      ∃ R : Set (CompactBasis A), R.Finite ∧ R ⊆ Chapter2.upperBounds C ∧
        Chapter2.upperBounds C = Chapter2.upperClosure R := by
    obtain ⟨k, hk, hFixed⟩ := F.exists_fix_finite (C := Subtype.val '' C)
      (hC.image _) (by rintro _ ⟨c, _, rfl⟩; exact c.2)
    let e := kernelImageCompactInclusion k
    let S : Set (CompactBasis k.ImageCarrier) := e ⁻¹' C
    have hS : S.Finite := hC.preimage e.injective.injOn
    have hEC : e '' S = C := by
      apply Set.Subset.antisymm (Set.image_preimage_subset _ _)
      intro c hc
      obtain ⟨b, hb⟩ := exists_imageCompact_of_fixed k c (hFixed c.1 ⟨c, hc, rfl⟩)
      exact ⟨b, show e b ∈ C from hb ▸ hc, hb⟩
    have hM := (algebraic_lawsonCompact_iff_compactBasis_propertyM_proved
      k.ImageCarrier (kernelImage_isDcpo k hA) (basis_to_raw (hAlg k hk))).1 (hL k hk)
    let R := e '' MinimalUpperBounds S
    have hR : R ⊆ Chapter2.upperBounds C := by
      rintro _ ⟨m, hm, rfl⟩ c hc
      rw [← hEC] at hc
      obtain ⟨c', hc', rfl⟩ := hc
      exact hm.1 hc'
    refine ⟨R, (hM.2 S hS).image _, hR, ?_⟩
    apply Set.Subset.antisymm
    · intro z hz
      have hProj : ∀ c ∈ S, c.1 ≤ k.projection z.1 := by
        intro c hc
        exact k.le_kernel_of_mem_range_le c.1.2 (hz hc)
      obtain ⟨m, hm, hmz⟩ := exists_compact_mub_le (hAlg k hk) hS (hM.1 S hS) hProj
      exact ⟨e m, ⟨m, hm, rfl⟩, show m.1.1 ≤ z.1 from le_trans hmz (k.below z.1)⟩
    · rintro _ ⟨r, hr, hrz⟩ c hc
      exact le_trans (hR hr hc) hrz
  exact ⟨fun C hC ↦ by
      obtain ⟨R, hRfin, hRsub, hEq⟩ := hFinite C hC
      exact completeMUBSet_of_finite_lowerCofinal hRfin hRsub hEq,
    fun C hC ↦ by
      obtain ⟨R, hRfin, hRsub, hEq⟩ := hFinite C hC
      exact minimalUpperBounds_finite_of_finite_lowerCofinal hRfin hRsub hEq⟩

end KernelApproximation
end CoherentContinuousAlgebraicRetracts
