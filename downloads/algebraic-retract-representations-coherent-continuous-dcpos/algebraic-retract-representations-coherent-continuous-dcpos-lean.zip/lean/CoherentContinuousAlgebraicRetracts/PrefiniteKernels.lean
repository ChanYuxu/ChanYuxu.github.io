import CoherentContinuousAlgebraicRetracts.KernelApproximations

/-!
# Prefinite images and MUB-generated kernels

The finite-stage construction is carried out in the compact basis. No
finiteness of the entire closure (or of the kernel image) is assumed.
-/

set_option autoImplicit false
set_option maxHeartbeats 1800000
set_option linter.unnecessarySimpa false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

/-! ## Iterated minimal-upper-bound closure and prefinite domains -/

variable {P : Type u} [PartialOrder P]

/-- One stage of closure under minimal upper bounds of finite subsets. -/
def mubClosureStep (S : Set P) : Set P :=
  Set.sUnion
    (MinimalUpperBounds '' {F : Set P | F.Finite ∧ F ⊆ S})

/-- The finite-stage closure from the source: `mcl^0(F)=F` and
`mcl^(n+1)(F)` adjoins all minimal upper bounds of finite subsets of the
preceding stage. -/
def iteratedMubClosure (F : Set P) : Nat → Set P
  | 0 => F
  | n + 1 => mubClosureStep (iteratedMubClosure F n)

/-- The union of all finite MUB-closure stages. -/
def omegaMubClosure (F : Set P) : Set P :=
  ⋃ n : Nat, iteratedMubClosure F n

/-- The source's notion of a prefinite algebraic dcpo. -/
structure PrefiniteAlgebraic
    (A : Type u) [PartialOrder A] : Type u where
  dcpo : IsDcpo A
  algebraic : AbramskyJung.Chapter3.IsAlgebraicDomain A
  propertyM : HasPropertyM (CompactBasis A)
  generators : Set (CompactBasis A)
  generators_finite : generators.Finite
  generated : omegaMubClosure generators = Set.univ

/-- The exact operator-side datum in Luan--Li's characterization: a directed
approximate identity of kernel operators with prefinite algebraic images. -/
structure PrefiniteKernelApproximation
    (A : Type u) [PartialOrder A] : Type (u + 1) where
  dcpo : IsDcpo A
  nonemptyA : Nonempty A
  I : Type u
  [orderI : Preorder I]
  [nonemptyI : Nonempty I]
  upper : ∀ i j : I, ∃ k : I, i ≤ k ∧ j ≤ k
  operator : I → AbramskyJung.Chapter3.KernelOperator A
  monotone : ∀ {i j : I}, i ≤ j → ∀ x : A,
    (operator i).k x ≤ (operator j).k x
  supremum : ∀ x : A,
    IsSup (Set.range (fun i : I ↦ (operator i).k x)) x
  prefinite : ∀ i : I,
    @PrefiniteAlgebraic (operator i).ImageCarrier
      (kernelImagePartialOrder (operator i))

attribute [instance]
  PrefiniteKernelApproximation.orderI
  PrefiniteKernelApproximation.nonemptyI

section Closure

variable {Q : Type u} [PartialOrder Q]

theorem mem_mubClosureStep {S : Set Q} {x : Q} :
    x ∈ mubClosureStep S ↔
      ∃ G : Set Q, G.Finite ∧ G ⊆ S ∧ x ∈ MinimalUpperBounds G := by
  constructor
  · rintro ⟨V, ⟨G, ⟨hG, hGS⟩, rfl⟩, hx⟩
    exact ⟨G, hG, hGS, hx⟩
  · rintro ⟨G, hG, hGS, hx⟩
    exact ⟨MinimalUpperBounds G, ⟨G, ⟨hG, hGS⟩, rfl⟩, hx⟩

theorem mubClosureStep_mono {S T : Set Q} (h : S ⊆ T) :
    mubClosureStep S ⊆ mubClosureStep T := by
  intro x hx
  obtain ⟨G, hG, hGS, hM⟩ := mem_mubClosureStep.1 hx
  exact mem_mubClosureStep.2 ⟨G, hG, hGS.trans h, hM⟩

theorem subset_mubClosureStep (S : Set Q) : S ⊆ mubClosureStep S := by
  intro x hx
  refine mem_mubClosureStep.2 ⟨{x}, Set.finite_singleton _, ?_, ?_⟩
  · simpa
  · refine ⟨?_, ?_⟩
    · intro y hy
      have e : y = x := by simpa using hy
      rw [e]
    · intro y hy _
      exact hy (Set.mem_singleton x)

theorem iteratedMubClosure_increasing (F : Set Q) :
    Monotone (iteratedMubClosure F) :=
  monotone_nat_of_le_succ (fun n ↦ subset_mubClosureStep (iteratedMubClosure F n))

theorem iteratedMubClosure_mono {F G : Set Q} (h : F ⊆ G) (n : Nat) :
    iteratedMubClosure F n ⊆ iteratedMubClosure G n := by
  induction n with
  | zero => exact h
  | succ n ih => exact mubClosureStep_mono ih

theorem omegaMubClosure_mono {F G : Set Q} (h : F ⊆ G) :
    omegaMubClosure F ⊆ omegaMubClosure G :=
  Set.iUnion_mono (iteratedMubClosure_mono h)

theorem subset_omegaMubClosure (F : Set Q) : F ⊆ omegaMubClosure F :=
  Set.subset_iUnion (iteratedMubClosure F) 0

theorem omegaMubClosure_closed (F : Set Q)
    {G : Set Q} (hG : G.Finite) (hSub : G ⊆ omegaMubClosure F) :
    MinimalUpperBounds G ⊆ omegaMubClosure F := by
  have hStage : ∃ n : Nat, G ⊆ iteratedMubClosure F n := by
    induction G, hG using Set.Finite.induction_on with
    | empty => exact ⟨0, Set.empty_subset _⟩
    | @insert a G ha hG ih =>
      obtain ⟨n, hn⟩ := ih (fun _ hx ↦ hSub (Set.mem_insert_of_mem _ hx))
      obtain ⟨m, hm⟩ := Set.mem_iUnion.mp (hSub (Set.mem_insert a G))
      refine ⟨max n m, ?_⟩
      intro x hx
      rcases Set.mem_insert_iff.mp hx with rfl | hx
      · exact iteratedMubClosure_increasing F (Nat.le_max_right _ _) hm
      · exact iteratedMubClosure_increasing F (Nat.le_max_left _ _) (hn hx)
  obtain ⟨n, hn⟩ := hStage
  intro x hx
  exact Set.mem_iUnion_of_mem (n + 1) (mem_mubClosureStep.2 ⟨G, hG, hn, hx⟩)

end Closure

attribute [local instance] kernelImagePartialOrder

section GeneratedKernels

variable {A : Type u} [PartialOrder A]

/-- The candidate compact values for the kernel generated by a compact set. -/
def kernelApproximants (C : Set (CompactBasis A)) (x : A) : Set A :=
  {b | ∃ k ∈ C, k.1 = b ∧ b ≤ x}

theorem kernelApproximants_directed
    (hAlg : Chapter3.IsAlgebraicDomain A) (hM : HasPropertyM (CompactBasis A))
    {C : Set (CompactBasis A)}
    (hClosed : ∀ {G : Set (CompactBasis A)}, G.Finite → G ⊆ C → MinimalUpperBounds G ⊆ C)
    (x : A) : DirectedSet (kernelApproximants C x) := by
  constructor
  · obtain ⟨m, hm, hmx⟩ := exists_compact_mub_le hAlg Set.finite_empty
      (hM.1 ∅ Set.finite_empty) (x := x) (by simp)
    exact ⟨m.1, m, hClosed Set.finite_empty (Set.empty_subset _) hm, rfl, hmx⟩
  · rintro a ⟨a', ha', rfl, hax⟩ b ⟨b', hb', rfl, hbx⟩
    let G : Set (CompactBasis A) := {a', b'}
    have hG : G.Finite := by simp [G]
    obtain ⟨m, hm, hmx⟩ := exists_compact_mub_le hAlg hG (hM.1 G hG) (x := x) (by
      intro z hz
      rcases Set.mem_insert_iff.mp hz with rfl | hz
      · exact hax
      · have heq : z = b' := by simpa using hz
        exact heq ▸ hbx)
    have hGC : G ⊆ C := by
      intro z hz
      rcases Set.mem_insert_iff.mp hz with rfl | hz
      · exact ha'
      · have heq : z = b' := by simpa using hz
        exact heq ▸ hb'
    exact ⟨m.1, ⟨m, hClosed hG hGC hm, rfl, hmx⟩,
      hm.1 (by simp [G]), hm.1 (by simp [G])⟩

structure GeneratedKernel (A : Type u) [PartialOrder A] (C : Set (CompactBasis A)) where
  operator : Chapter3.KernelOperator A
  isSup : ∀ x, IsSup (kernelApproximants C x) (operator.k x)

/-- The generated kernel is exactly the supremum of the retained compact
elements below the argument (Abramsky–Jung, Proposition 4.2.5 formula). -/
def generatedKernel (hA : IsDcpo A)
    (hAlg : Chapter3.IsAlgebraicDomain A) (hM : HasPropertyM (CompactBasis A))
    (C : Set (CompactBasis A))
    (hClosed : ∀ {G : Set (CompactBasis A)}, G.Finite → G ⊆ C → MinimalUpperBounds G ⊆ C) :
    GeneratedKernel A C := by
  let hExists (x : A) := hA (kernelApproximants C x) (kernelApproximants_directed hAlg hM hClosed x)
  let k (x : A) := Classical.choose (hExists x)
  have hK (x : A) : IsSup (kernelApproximants C x) (k x) :=
    Classical.choose_spec (hExists x)
  have hBelow (x : A) : k x ≤ x := (hK x).2 x (by
    rintro _ ⟨_, _, _, hx⟩
    exact hx)
  have hMono : Monotone k := by
    intro x y hxy
    apply (hK x).2 (k y)
    rintro b ⟨c, hc, hcb, hbx⟩
    exact (hK y).1 ⟨c, hc, hcb, le_trans hbx hxy⟩
  refine ⟨⟨k, ⟨hMono, ?_⟩, ?_, hBelow⟩, hK⟩
  · intro S x hS hx
    refine ⟨?_, ?_⟩
    · rintro _ ⟨s, hs, rfl⟩
      exact hMono (hx.1 hs)
    · intro y hy
      apply (hK x).2 y
      rintro _ ⟨c, hc, rfl, hcx⟩
      obtain ⟨s, hs, hcs⟩ := c.2 hS hx hcx
      exact le_trans ((hK s).1 ⟨c, hc, rfl, hcs⟩) (hy ⟨s, hs, rfl⟩)
  · intro x
    apply le_antisymm (hBelow (k x))
    apply (hK x).2 (k (k x))
    rintro b ⟨c, hc, hcb, hbx⟩
    exact (hK (k x)).1 ⟨c, hc, hcb, (hK x).1 ⟨c, hc, hcb, hbx⟩⟩

namespace GeneratedKernel

variable {C : Set (CompactBasis A)} (K : GeneratedKernel A C)

theorem compact_fixed_iff (b : CompactBasis A)
    (hD : DirectedSet (kernelApproximants C b.1)) :
    K.operator.k b.1 = b.1 ↔ b ∈ C := by
  constructor
  · intro hFix
    have hB : b.1 ≤ K.operator.k b.1 := hFix.symm.le
    obtain ⟨_, ⟨c, hc, rfl, hcb⟩, hbc⟩ := b.2 hD (K.isSup b.1) hB
    have heq : b = c := Subtype.ext (le_antisymm hbc hcb)
    exact heq ▸ hc
  · intro hb
    exact le_antisymm (K.operator.below b.1) ((K.isSup b.1).1 ⟨b, hb, rfl, le_rfl⟩)

theorem image_algebraic (hD : ∀ x, DirectedSet (kernelApproximants C x)) :
    Chapter3.IsAlgebraicDomain K.operator.ImageCarrier := by
  apply prop_2_2_4_1
  intro a
  let k := K.operator
  let S := kernelApproximants C a.1
  have hFixed : k.projection a.1 = a := k.projection_inclusion_eq a
  have hSup : IsSup (k.projection '' S) (k.projection (k.k a.1)) :=
    k.projection_scottContinuous.2 (hD a.1) (K.isSup a.1)
  have hka : k.k a.1 = a.1 := (k.mem_range_iff_fixed).1 a.2
  refine ⟨k.projection '' S, ?_,
    DirectedSet.image k.projection_monotone (hD a.1), ?_⟩
  · rintro _ ⟨_, ⟨c, hc, rfl, hca⟩, rfl⟩
    have hFix := (K.compact_fixed_iff c (hD c.1)).2 hc
    have hComp : Compact (k.projection c.1) :=
      (kernelImage_compact_iff k _).2 (show Compact (k.k c.1) by rw [hFix]; exact c.2)
    refine ⟨hComp, prop_2_2_2_2 le_rfl hComp ?_⟩
    rw [← hFixed]
    exact k.projection_monotone hca
  · rwa [hka, hFixed] at hSup

theorem range_compactInclusion (hD : ∀ x, DirectedSet (kernelApproximants C x)) :
    Set.range (kernelImageCompactInclusion K.operator) = C := by
  ext c
  constructor
  · rintro ⟨b, rfl⟩
    exact (K.compact_fixed_iff _ (hD _)).1 ((K.operator.mem_range_iff_fixed).1 b.1.2)
  · intro hc
    exact exists_imageCompact_of_fixed K.operator c ((K.compact_fixed_iff c (hD _)).2 hc)

end GeneratedKernel
end GeneratedKernels

section ClosedOrderEmbedding

variable {X Q : Type u} [PartialOrder X] [PartialOrder Q]

/-- MUBs of finite subsets are transported by an order embedding with
MUB-closed range into a poset with property M. -/
theorem image_mubs_of_closedRange (e : X ↪o Q) (hM : HasPropertyM Q)
    (hClosed : ∀ {G : Set Q}, G.Finite → G ⊆ Set.range e →
      MinimalUpperBounds G ⊆ Set.range e)
    {F : Set X} (hF : F.Finite) :
    e '' MinimalUpperBounds F = MinimalUpperBounds (e '' F) := by
  have hFin : (e '' F).Finite := hF.image _
  ext z
  constructor
  · rintro ⟨a, ha, rfl⟩
    refine ⟨by rintro _ ⟨b, hb, rfl⟩; exact e.monotone (ha.1 hb), ?_⟩
    intro w hw hwa
    change w ∈ Chapter2.upperBounds (e '' F) at hw
    rw [hM.1 _ hFin] at hw
    obtain ⟨m, hm, hmw⟩ := hw
    obtain ⟨b, rfl⟩ := hClosed hFin (Set.image_subset_range _ _) hm
    apply le_trans (e.monotone (ha.2 ?_ (e.le_iff_le.1 (le_trans hmw hwa)))) hmw
    intro c hc
    exact e.le_iff_le.1 (hm.1 ⟨c, hc, rfl⟩)
  · intro hz
    obtain ⟨a, rfl⟩ := hClosed hFin (Set.image_subset_range _ _) hz
    refine ⟨a, ⟨?_, ?_⟩, rfl⟩
    · intro b hb
      exact e.le_iff_le.1 (hz.1 ⟨b, hb, rfl⟩)
    · intro b hb hba
      apply e.le_iff_le.1 (hz.2 ?_ (e.monotone hba))
      rintro _ ⟨c, hc, rfl⟩
      exact e.monotone (hb hc)

theorem propertyM_of_closedRange (e : X ↪o Q) (hM : HasPropertyM Q)
    (hClosed : ∀ {G : Set Q}, G.Finite → G ⊆ Set.range e →
      MinimalUpperBounds G ⊆ Set.range e) : HasPropertyM X := by
  have hPre (F : Set X) (hF : F.Finite) :
      e ⁻¹' MinimalUpperBounds (e '' F) = MinimalUpperBounds F := by
    rw [← image_mubs_of_closedRange e hM hClosed hF,
      Set.preimage_image_eq _ e.injective]
  constructor
  · intro F hF
    apply Set.Subset.antisymm
    · intro x hx
      have hEx : e x ∈ Chapter2.upperBounds (e '' F) := by
        rintro _ ⟨a, ha, rfl⟩
        exact e.monotone (hx ha)
      rw [hM.1 _ (hF.image _), ← image_mubs_of_closedRange e hM hClosed hF] at hEx
      obtain ⟨_, ⟨m, hm, rfl⟩, hmx⟩ := hEx
      exact ⟨m, hm, e.le_iff_le.1 hmx⟩
    · rintro x ⟨m, hm, hmx⟩ a ha
      exact le_trans (hm.1 ha) hmx
  · intro F hF
    rw [← hPre F hF]
    exact (hM.2 _ (hF.image _)).preimage e.injective.injOn

theorem image_omegaMubClosure_of_closedRange (e : X ↪o Q) (hM : HasPropertyM Q)
    (hClosed : ∀ {G : Set Q}, G.Finite → G ⊆ Set.range e →
      MinimalUpperBounds G ⊆ Set.range e) (F : Set X) :
    e '' omegaMubClosure F = omegaMubClosure (e '' F) := by
  have hStage : ∀ n, e '' iteratedMubClosure F n = iteratedMubClosure (e '' F) n := by
    intro n
    induction n with
    | zero => rfl
    | succ n ih =>
      ext x
      constructor
      · rintro ⟨y, hy, rfl⟩
        obtain ⟨G, hG, hSub, hm⟩ := mem_mubClosureStep.1 hy
        apply mem_mubClosureStep.2
        refine ⟨e '' G, hG.image _, ?_, ?_⟩
        · rw [← ih]
          exact Set.image_mono hSub
        · rw [← image_mubs_of_closedRange e hM hClosed hG]
          exact ⟨y, hm, rfl⟩
      · intro hx
        obtain ⟨J, hJ, hSub, hm⟩ := mem_mubClosureStep.1 hx
        rw [← ih] at hSub
        let G := e ⁻¹' J
        have hG : G.Finite := hJ.preimage e.injective.injOn
        have hGsub : G ⊆ iteratedMubClosure F n := by
          intro a ha
          obtain ⟨b, hb, hba⟩ := hSub (show e a ∈ J from ha)
          exact e.injective hba ▸ hb
        have hE : e '' G = J :=
          Set.image_preimage_eq_of_subset (hSub.trans (Set.image_subset_range _ _))
        rw [← hE, ← image_mubs_of_closedRange e hM hClosed hG] at hm
        obtain ⟨y, hy, rfl⟩ := hm
        exact ⟨y, mem_mubClosureStep.2 ⟨G, hG, hGsub, hy⟩, rfl⟩
  unfold omegaMubClosure
  rw [Set.image_iUnion]
  exact congrArg (fun S : Nat → Set Q ↦ ⋃ n, S n) (funext hStage)

end ClosedOrderEmbedding

section PrefiniteApproximation

variable {A : Type u} [PartialOrder A]

/-- The kernel associated with a finite compact family has prefinite
image: its compact basis is (in the inherited order) exactly the
MUB closure of that family. -/
def prefiniteImage_of_generated
    (hA : IsDcpo A) (hAlg : Chapter3.IsAlgebraicDomain A)
    (hM : HasPropertyM (CompactBasis A)) {F : Set (CompactBasis A)}
    (hF : F.Finite) (K : GeneratedKernel A (omegaMubClosure F)) :
    PrefiniteAlgebraic K.operator.ImageCarrier := by
  let C := omegaMubClosure F
  have hDir := kernelApproximants_directed hAlg hM (omegaMubClosure_closed F)
  let e : CompactBasis K.operator.ImageCarrier ↪o CompactBasis A :=
    { toEmbedding := kernelImageCompactInclusion K.operator
      map_rel_iff' := Iff.rfl }
  have hRange : Set.range e = C := K.range_compactInclusion hDir
  have hClosed {G : Set (CompactBasis A)} (hG : G.Finite) (hGC : G ⊆ Set.range e) :
      MinimalUpperBounds G ⊆ Set.range e := by
    rw [hRange] at hGC ⊢
    exact omegaMubClosure_closed F hG hGC
  let G := e ⁻¹' F
  have hEF : e '' G = F := by
    apply Set.image_preimage_eq_of_subset
    rw [hRange]
    exact subset_omegaMubClosure F
  refine ⟨kernelImage_isDcpo _ hA, K.image_algebraic hDir,
    propertyM_of_closedRange e hM hClosed, G, hF.preimage e.injective.injOn, ?_⟩
  have hImages : e '' omegaMubClosure G = e '' (Set.univ : Set (CompactBasis K.operator.ImageCarrier)) := by
    rw [image_omegaMubClosure_of_closedRange e hM hClosed G, hEF,
      Set.image_univ, hRange]
  exact (Set.image_injective.mpr e.injective) hImages

namespace PrefiniteAlgebraic

theorem lawsonCompact (hA : PrefiniteAlgebraic A) :
    Chapter4.IsLawsonCompact (asOrderedDomain A) :=
  (algebraic_lawsonCompact_iff_compactBasis_propertyM_proved A hA.dcpo
    (basis_to_raw hA.algebraic)).2 hA.propertyM

end PrefiniteAlgebraic

/-- Luan–Li (2025), Theorem 3.2, in the manuscript's indexed encoding.
The forward family is indexed by finite subsets of the compact basis;
the reverse uses finite fixation of ambient compacts by one kernel. -/
theorem thm_prefinite_algebraic (A : Type u) [PartialOrder A] [Nonempty A]
    (hA : IsDcpo A) :
    (Chapter4.IsLawsonCompact (asOrderedDomain A) ∧ Chapter3.IsAlgebraicDomain A) ↔
      Nonempty (PrefiniteKernelApproximation A) := by
  constructor
  · rintro ⟨hL, hAlg⟩
    have hM := (algebraic_lawsonCompact_iff_compactBasis_propertyM_proved
      A hA (basis_to_raw hAlg)).1 hL
    let I := {F : Set (CompactBasis A) // F.Finite}
    let K (F : I) := generatedKernel hA hAlg hM
      (omegaMubClosure F.1) (omegaMubClosure_closed F.1)
    refine ⟨{
      dcpo := hA
      nonemptyA := inferInstance
      I := I
      orderI := inferInstance
      nonemptyI := ⟨⟨∅, Set.finite_empty⟩⟩
      upper := fun F G ↦ ⟨⟨F.1 ∪ G.1, F.2.union G.2⟩,
        Set.subset_union_left, Set.subset_union_right⟩
      operator := fun F ↦ (K F).operator
      monotone := ?_
      supremum := ?_
      prefinite := fun F ↦ prefiniteImage_of_generated hA hAlg hM F.2 (K F) }⟩
    · intro F G hFG x
      apply ((K F).isSup x).2 ((K G).operator.k x)
      rintro a ⟨b, hb, hba, hax⟩
      exact ((K G).isSup x).1 ⟨b, omegaMubClosure_mono hFG hb, hba, hax⟩
    · intro x
      constructor
      · rintro _ ⟨F, rfl⟩
        exact (K F).operator.below x
      · intro y hy
        apply (hAlg x).2.2 y
        intro b hb
        let c : CompactBasis A := ⟨b, hb.1⟩
        let F : I := ⟨{c}, Set.finite_singleton c⟩
        exact le_trans (((K F).isSup x).1
          ⟨c, subset_omegaMubClosure F.1 (by simp [F]), rfl, prop_2_2_2_1 hb.2⟩)
          (hy ⟨F, rfl⟩)
  · rintro ⟨K⟩
    let F : KernelApproximation A := KernelApproximation.ofIndexed K.operator (by
      intro i j
      obtain ⟨k, hik, hjk⟩ := K.upper i j
      exact ⟨k, K.monotone hik, K.monotone hjk⟩) K.supremum
    have hAlgs : ∀ k ∈ F.operators, Chapter3.IsAlgebraicDomain k.ImageCarrier := by
      rintro _ ⟨i, rfl⟩
      exact (K.prefinite i).algebraic
    exact ⟨F.lawsonCompact hA hAlgs (by
      rintro _ ⟨i, rfl⟩
      exact (K.prefinite i).lawsonCompact), F.algebraic hAlgs⟩

end PrefiniteApproximation

end

end CoherentContinuousAlgebraicRetracts
