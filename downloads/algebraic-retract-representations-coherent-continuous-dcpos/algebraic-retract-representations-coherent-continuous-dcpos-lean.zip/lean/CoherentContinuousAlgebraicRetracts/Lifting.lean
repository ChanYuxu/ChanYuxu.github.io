import CoherentContinuousAlgebraicRetracts.OpenSubdcpo
import CoherentContinuousAlgebraicRetracts.InternalLawson
import Practice.DomainTheory.Chapter03.Section32_SumsSmashLifting

/-!
# Adjoining a fresh least element

This file supplies the `D⊥` construction used in the two function-space
corollaries of the frozen source.  The textbook defines lifting as `WithBot`;
the dcpo, continuity, compactness, and coherence properties required by the
paper are proved here.
-/

set_option autoImplicit false
set_option linter.unnecessarySimpa false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

variable {D : Type u} [PartialOrder D]

abbrev Lifting (D : Type u) := WithBot D

/-- Adjoining a fresh bottom preserves directed completeness. -/
theorem lifting_isDcpo (hD : IsDcpo D) : IsDcpo (Lifting D) := by
  intro A hA
  by_cases hNonbot : ∃ x : D, (x : Lifting D) ∈ A
  · let B : Set D := {x | (x : Lifting D) ∈ A}
    have hB : DirectedSet B := by
      constructor
      · rcases hNonbot with ⟨x, hx⟩
        exact ⟨x, hx⟩
      · intro x hx y hy
        obtain ⟨z, hzA, hxz, hyz⟩ := hA.2 hx hy
        cases z using WithBot.recBotCoe with
        | bot => exact (WithBot.not_coe_le_bot x hxz).elim
        | coe z =>
            exact ⟨z, hzA, WithBot.coe_le_coe.mp hxz,
              WithBot.coe_le_coe.mp hyz⟩
    obtain ⟨s, hs⟩ := hD B hB
    refine ⟨(s : Lifting D), ?_⟩
    constructor
    · intro x hxA
      cases x using WithBot.recBotCoe with
      | bot => exact bot_le
      | coe x => exact WithBot.coe_le_coe.mpr (hs.1 hxA)
    · intro z hz
      cases z using WithBot.recBotCoe with
      | bot =>
          rcases hNonbot with ⟨x, hxA⟩
          exact (WithBot.not_coe_le_bot x (hz hxA)).elim
      | coe z =>
          exact WithBot.coe_le_coe.mpr
            (hs.2 z (fun x hxB ↦ WithBot.coe_le_coe.mp (hz hxB)))
  · push Not at hNonbot
    refine ⟨⊥, ?_⟩
    constructor
    · intro x hxA
      cases x using WithBot.recBotCoe with
      | bot => exact le_rfl
      | coe x => exact (hNonbot x hxA).elim
    · intro z _hz
      exact bot_le

/-- The canonical inclusion `D → D⊥` preserves directed suprema. -/
theorem lifting_up_scottContinuous :
    Chapter2.ScottContinuous (fun x : D ↦ (x : Lifting D)) := by
  constructor
  · intro x y hxy
    exact WithBot.coe_le_coe.mpr hxy
  · intro A s hA hs
    constructor
    · rintro _ ⟨x, hxA, rfl⟩
      exact WithBot.coe_le_coe.mpr (hs.1 hxA)
    · intro z hz
      cases z using WithBot.recBotCoe with
      | bot =>
          rcases hA.1 with ⟨x, hxA⟩
          exact (WithBot.not_coe_le_bot x (hz ⟨x, hxA, rfl⟩)).elim
      | coe z =>
          exact WithBot.coe_le_coe.mpr
            (hs.2 z (fun x hxA ↦ WithBot.coe_le_coe.mp (hz ⟨x, hxA, rfl⟩)))

/-- The non-bottom part of a directed set with non-bottom supremum is a
directed set in the original carrier with the corresponding supremum. -/
def liftingBasePart (A : Set (Lifting D)) : Set D :=
  {x | (x : Lifting D) ∈ A}

theorem liftingBasePart_directed_isSup
    {A : Set (Lifting D)} {s : D}
    (hA : DirectedSet A) (hs : IsSup A (s : Lifting D)) :
    DirectedSet (liftingBasePart A) ∧ IsSup (liftingBasePart A) s := by
  have hNonempty : (liftingBasePart A).Nonempty := by
    by_contra hEmpty
    have hbotUpper : IsUpperBound A (⊥ : Lifting D) := by
      intro z hzA
      cases z using WithBot.recBotCoe with
      | bot => exact le_rfl
      | coe z => exact (hEmpty ⟨z, hzA⟩).elim
    exact WithBot.not_coe_le_bot s (hs.2 ⊥ hbotUpper)
  have hDirected : DirectedSet (liftingBasePart A) := by
    constructor
    · exact hNonempty
    · intro x hx y hy
      obtain ⟨z, hzA, hxz, hyz⟩ := hA.2 hx hy
      cases z using WithBot.recBotCoe with
      | bot => exact (WithBot.not_coe_le_bot x hxz).elim
      | coe z =>
          exact ⟨z, hzA, WithBot.coe_le_coe.mp hxz,
            WithBot.coe_le_coe.mp hyz⟩
  refine ⟨hDirected, ?_⟩
  constructor
  · intro x hx
    exact WithBot.coe_le_coe.mp (hs.1 hx)
  · intro z hz
    have hCoeUpper : IsUpperBound A (z : Lifting D) := by
      intro q hqA
      cases q using WithBot.recBotCoe with
      | bot => exact bot_le
      | coe q => exact WithBot.coe_le_coe.mpr (hz hqA)
    exact WithBot.coe_le_coe.mp (hs.2 (z : Lifting D) hCoeUpper)

/-- The fresh bottom is way below every lifted point. -/
theorem lifting_bot_wayBelow (x : Lifting D) : (⊥ : Lifting D) ≪ x := by
  intro A s hA _hs _hxs
  rcases hA.1 with ⟨a, haA⟩
  exact ⟨a, haA, bot_le⟩

/-- Way-below comparisons in `D` lift to comparisons between non-bottom
points of `D⊥`. -/
theorem lifting_coe_wayBelow_coe {a x : D} (hax : a ≪ x) :
    (a : Lifting D) ≪ (x : Lifting D) := by
  intro A s hA hs hxs
  cases s using WithBot.recBotCoe with
  | bot => exact (WithBot.not_coe_le_bot x hxs).elim
  | coe s =>
      let B : Set D := {b | (b : Lifting D) ∈ A}
      have hBnonempty : B.Nonempty := by
        by_contra hEmpty
        have hbotUpper : IsUpperBound A (⊥ : Lifting D) := by
          intro z hzA
          cases z using WithBot.recBotCoe with
          | bot => exact le_rfl
          | coe z => exact (hEmpty ⟨z, hzA⟩).elim
        have hsbot : (s : Lifting D) ≤ ⊥ := hs.2 ⊥ hbotUpper
        exact WithBot.not_coe_le_bot s hsbot
      have hB : DirectedSet B := by
        constructor
        · exact hBnonempty
        · intro b hb c hc
          obtain ⟨z, hzA, hbz, hcz⟩ := hA.2 hb hc
          cases z using WithBot.recBotCoe with
          | bot => exact (WithBot.not_coe_le_bot b hbz).elim
          | coe z =>
              exact ⟨z, hzA, WithBot.coe_le_coe.mp hbz,
                WithBot.coe_le_coe.mp hcz⟩
      have hBsup : IsSup B s := by
        constructor
        · intro b hb
          exact WithBot.coe_le_coe.mp (hs.1 hb)
        · intro z hz
          have hCoeUpper : IsUpperBound A (z : Lifting D) := by
            intro q hqA
            cases q using WithBot.recBotCoe with
            | bot => exact bot_le
            | coe q => exact WithBot.coe_le_coe.mpr (hz hqA)
          exact WithBot.coe_le_coe.mp (hs.2 (z : Lifting D) hCoeUpper)
      have hxsD : x ≤ s := WithBot.coe_le_coe.mp hxs
      rcases hax hB hBsup hxsD with ⟨b, hbB, hab⟩
      exact ⟨(b : Lifting D), hbB, WithBot.coe_le_coe.mpr hab⟩

/-- A basis of `D` lifts to a basis of `D⊥` after adding the fresh bottom. -/
theorem lifting_isContinuous
    (hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D) :
    AbramskyJung.Chapter3.IsContinuousDomain (Lifting D) := by
  let B : Set D := Classical.choose hContinuous
  have hB : IsBasis B := Classical.choose_spec hContinuous
  let liftBasis : Set (Lifting D) :=
    ((fun b : D ↦ (b : Lifting D)) '' B) ∪ {⊥}
  refine ⟨liftBasis, prop_2_2_4_1 ?_⟩
  intro x
  cases x using WithBot.recBotCoe with
  | bot =>
      refine ⟨{⊥}, ?_, directed_singleton ⊥, isSup_singleton ⊥⟩
      intro z hz
      have hzbot : z = (⊥ : Lifting D) := by simpa using hz
      subst z
      exact ⟨Or.inr (by simp), lifting_bot_wayBelow ⊥⟩
  | coe x =>
      let S : Set (Lifting D) :=
        (fun b : D ↦ (b : Lifting D)) '' Approximants B x
      refine ⟨S, ?_, DirectedSet.image
        (fun _ _ h ↦ WithBot.coe_le_coe.mpr h) (hB x).1, ?_⟩
      · rintro z ⟨b, hb, rfl⟩
        exact ⟨Or.inl ⟨b, hb.1, rfl⟩,
          lifting_coe_wayBelow_coe hb.2⟩
      · exact lifting_up_scottContinuous.2 (hB x).1 (hB x).2

/-- The lifted dcpo is Scott compact: every Scott-open neighbourhood of its
least element is the whole carrier. -/
theorem lifting_isScottCompactSpace : IsScottCompactSpace (Lifting D) := by
  intro cover hOpen hCover
  have hbotCovered := hCover (Set.mem_univ (⊥ : Lifting D))
  rcases Set.mem_sUnion.mp hbotCovered with ⟨U, hUcover, hbotU⟩
  refine ⟨{U}, ?_, Set.finite_singleton U, ?_⟩
  · intro V hV
    have hVU : V = U := by simpa using hV
    simpa [hVU] using hUcover
  · intro x _hx
    exact Set.mem_sUnion_of_mem
      (scottOpen_upper (hOpen U hUcover) hbotU bot_le) (by simp)

/-- The original carrier is the Scott-open non-bottom part of its lifting. -/
def liftingNonbot (D : Type u) [PartialOrder D] : Set (Lifting D) :=
  {x | x ≠ ⊥}

theorem liftingNonbot_scottOpen : ScottOpen (liftingNonbot D) := by
  apply scottOpen_of_upper_and_inaccessible
  · intro x y hx hxy hybot
    subst y
    exact hx (le_antisymm hxy bot_le)
  · intro E s hE hs hsNonbot
    by_contra hnone
    have hbotUpper : IsUpperBound E (⊥ : Lifting D) := by
      intro e heE
      apply (WithBot.le_bot_iff).2
      by_contra heNonbot
      exact hnone ⟨e, heE, heNonbot⟩
    exact hsNonbot (le_antisymm (hs.2 ⊥ hbotUpper) bot_le)

/-- The evident order isomorphism between `D` and the non-bottom open
sub-dcpo of `D⊥`. -/
def baseToLiftingNonbot (x : D) : liftingNonbot D :=
  ⟨(x : Lifting D), WithBot.coe_ne_bot⟩

def liftingNonbotToBase (x : liftingNonbot D) : D :=
  x.1.unbot x.2

@[simp]
theorem liftingNonbotToBase_baseTo (x : D) :
    liftingNonbotToBase (baseToLiftingNonbot x) = x := by
  simp [liftingNonbotToBase, baseToLiftingNonbot]

@[simp]
theorem baseTo_liftingNonbotToBase (x : liftingNonbot D) :
    baseToLiftingNonbot (liftingNonbotToBase x) = x := by
  apply Subtype.ext
  exact WithBot.coe_unbot x.1 x.2

theorem baseToLiftingNonbot_scottContinuous :
    Chapter2.ScottContinuous (baseToLiftingNonbot (D := D)) := by
  constructor
  · intro x y hxy
    exact WithBot.coe_le_coe.mpr hxy
  · intro E s hE hs
    constructor
    · rintro _ ⟨x, hxE, rfl⟩
      exact WithBot.coe_le_coe.mpr (hs.1 hxE)
    · intro q hq
      change (s : Lifting D) ≤ q.1
      rw [← WithBot.coe_unbot q.1 q.2]
      exact WithBot.coe_le_coe.mpr
        (hs.2 (liftingNonbotToBase q) (fun x hxE ↦ by
          have hxq := hq ⟨x, hxE, rfl⟩
          change (x : Lifting D) ≤ q.1 at hxq
          rw [← WithBot.coe_unbot q.1 q.2] at hxq
          exact WithBot.coe_le_coe.mp hxq))

theorem liftingNonbotToBase_scottContinuous
    (hD : IsDcpo D) :
    Chapter2.ScottContinuous (liftingNonbotToBase (D := D)) := by
  constructor
  · intro x y hxy
    have hLifted :
        (x.1.unbot x.2 : Lifting D) ≤ (y.1.unbot y.2 : Lifting D) := by
      rw [WithBot.coe_unbot x.1 x.2, WithBot.coe_unbot y.1 y.2]
      exact hxy
    exact WithBot.coe_le_coe.mp hLifted
  · intro E s hE hs
    have hAmbient := scottOpenSubtype_isLUB_ambient
      (lifting_isDcpo hD) liftingNonbot_scottOpen hE hs
    constructor
    · rintro _ ⟨x, hxE, rfl⟩
      have hLifted :
          (x.1.unbot x.2 : Lifting D) ≤
            (s.1.unbot s.2 : Lifting D) := by
        rw [WithBot.coe_unbot x.1 x.2, WithBot.coe_unbot s.1 s.2]
        exact hAmbient.1 ⟨x, hxE, rfl⟩
      exact WithBot.coe_le_coe.mp hLifted
    · intro q hq
      have hqUpper : (q : Lifting D) ∈
          _root_.upperBounds
            (((↑) : liftingNonbot D → Lifting D) '' E) := by
        rintro _ ⟨x, hxE, rfl⟩
        have hxq := WithBot.coe_le_coe.mpr (hq ⟨x, hxE, rfl⟩)
        change (x.1.unbot x.2 : Lifting D) ≤ (q : Lifting D) at hxq
        rw [WithBot.coe_unbot x.1 x.2] at hxq
        exact hxq
      have hsq : s.1 ≤ (q : Lifting D) := hAmbient.2 hqUpper
      rw [← WithBot.coe_unbot s.1 s.2] at hsq
      exact WithBot.coe_le_coe.mp hsq

def liftingNonbotRetract
    (hD : IsDcpo D) :
    AbramskyJung.Chapter3.ContinuousSectionRetractionPair
      (liftingNonbot D) D where
  s := liftingNonbotToBase
  r := baseToLiftingNonbot
  monotone_s := (liftingNonbotToBase_scottContinuous hD).1
  monotone_r := baseToLiftingNonbot_scottContinuous.1
  retract := baseTo_liftingNonbotToBase
  continuous_s := liftingNonbotToBase_scottContinuous hD
  continuous_r := baseToLiftingNonbot_scottContinuous

/-- The inverse orientation of the same continuous order isomorphism. -/
def baseLiftingNonbotRetract
    (hD : IsDcpo D) :
    AbramskyJung.Chapter3.ContinuousSectionRetractionPair
      D (liftingNonbot D) where
  s := baseToLiftingNonbot
  r := liftingNonbotToBase
  monotone_s := baseToLiftingNonbot_scottContinuous.1
  monotone_r := (liftingNonbotToBase_scottContinuous hD).1
  retract := liftingNonbotToBase_baseTo
  continuous_s := baseToLiftingNonbot_scottContinuous
  continuous_r := liftingNonbotToBase_scottContinuous hD

/-- Coherence is preserved by adjoining a fresh bottom. -/
theorem lifting_isCoherent
    [Nonempty D]
    (hD : IsDcpo D) (hCoherent : IsCoherent D) :
    IsCoherent (Lifting D) := by
  have hOpen : ScottOpen (liftingNonbot D) := liftingNonbot_scottOpen
  have hOpenNonempty : (liftingNonbot D).Nonempty := by
    let d : D := Classical.choice (inferInstance : Nonempty D)
    exact ⟨(d : Lifting D), WithBot.coe_ne_bot⟩
  have hOpenCoherent : IsCoherent (liftingNonbot D) :=
    coherent_of_continuous_retract (liftingNonbotRetract hD) hCoherent
  intro K L hK hL
  by_cases hbotK : (⊥ : Lifting D) ∈ K
  · have hKuniv : K = Set.univ := by
      apply Set.eq_univ_of_forall
      intro x
      exact hK.2 hbotK bot_le
    simpa [hKuniv] using hL
  · by_cases hbotL : (⊥ : Lifting D) ∈ L
    · have hLuniv : L = Set.univ := by
        apply Set.eq_univ_of_forall
        intro x
        exact hL.2 hbotL bot_le
      simpa [hLuniv] using hK
    · have hKsub : K ⊆ liftingNonbot D := by
        intro x hxK hxbot
        subst x
        exact hbotK hxK
      have hLsub : L ⊆ liftingNonbot D := by
        intro x hxL hxbot
        subst x
        exact hbotL hxL
      let val : liftingNonbot D → Lifting D := (↑)
      let KU : Set (liftingNonbot D) := val ⁻¹' K
      let LU : Set (liftingNonbot D) := val ⁻¹' L
      have hKU : CompactSaturated KU := by
        constructor
        · exact scottCompact_preimage_openSubtype hOpen hK.1 hKsub
        · intro x y hx hxy
          exact hK.2 hx hxy
      have hLU : CompactSaturated LU := by
        constructor
        · exact scottCompact_preimage_openSubtype hOpen hL.1 hLsub
        · intro x y hx hxy
          exact hL.2 hx hxy
      have hInterU := hOpenCoherent KU LU hKU hLU
      have hImageEq : val '' (KU ∩ LU) = K ∩ L := by
        ext x
        constructor
        · rintro ⟨y, hy, rfl⟩
          exact hy
        · rintro hx
          have hxNonbot : x ∈ liftingNonbot D := hKsub hx.1
          exact ⟨⟨x, hxNonbot⟩, hx, rfl⟩
      constructor
      · rw [← hImageEq]
        exact scottCompact_image_openSubtype
          (lifting_isDcpo hD) hOpen hInterU.1
      · exact saturated_inter hK.2 hL.2

/-- A coherent continuous dcpo becomes Lawson compact after adjoining a fresh
least element. -/
theorem lifting_isLawsonCompact
    [Nonempty D]
    (hD : IsDcpo D)
    (hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D)
    (hCoherent : IsCoherent D) :
    AbramskyJung.Chapter4.IsLawsonCompact
      (asOrderedDomain (Lifting D)) :=
  lawsonCompact_of_scottCompact_and_coherent_internal
    (lifting_isDcpo hD) (lifting_isContinuous hContinuous)
    lifting_isScottCompactSpace (lifting_isCoherent hD hCoherent)

end

end CoherentContinuousAlgebraicRetracts
