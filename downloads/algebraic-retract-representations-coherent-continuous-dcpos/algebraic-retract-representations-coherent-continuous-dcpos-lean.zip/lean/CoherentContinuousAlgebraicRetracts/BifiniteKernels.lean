import CoherentContinuousAlgebraicRetracts.FunctionSpaceCore
import CoherentContinuousAlgebraicRetracts.KernelApproximations

/-! # Bifinite kernels, nested approximations, and order transport -/

set_option autoImplicit false
set_option maxHeartbeats 1400000
set_option linter.unnecessarySimpa false

universe u v

namespace CoherentContinuousAlgebraicRetracts

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

attribute [local instance] kernelImagePartialOrder

variable {A : Type u} {B : Type v} [PartialOrder A] [PartialOrder B]

theorem scottContinuous_orderIso (e : A ≃o B) : Chapter2.ScottContinuous e := by
  refine ⟨e.monotone, ?_⟩
  intro S x _ hx
  refine ⟨?_, ?_⟩
  · rintro _ ⟨a, ha, rfl⟩
    exact e.monotone (hx.1 ha)
  · intro y hy
    have hLE : x ≤ e.symm y := hx.2 _ (by
      intro a ha
      exact (e.le_iff_le).1 (by simpa using hy ⟨a, ha, rfl⟩))
    simpa using e.monotone hLE

def sectionRetractionOfOrderIso (e : A ≃o B) :
    Chapter3.ContinuousSectionRetractionPair A B where
  s := e
  r := e.symm
  monotone_s := e.monotone
  monotone_r := e.symm.monotone
  retract := e.symm_apply_apply
  continuous_s := scottContinuous_orderIso e
  continuous_r := scottContinuous_orderIso e.symm

theorem compact_orderIso (e : A ≃o B) {a : A} (ha : Compact a) : Compact (e a) := by
  intro S s hS hs has
  have hDir := DirectedSet.image e.symm.monotone hS
  have hSup := (scottContinuous_orderIso e.symm).2 hS hs
  have hLE : a ≤ e.symm s := by
    apply e.le_iff_le.1
    simpa using has
  obtain ⟨_, ⟨b, hb, rfl⟩, hab⟩ := ha hDir hSup hLE
  exact ⟨b, hb, by simpa using e.monotone hab⟩

theorem algebraic_orderIso (e : A ≃o B) (hA : Chapter3.IsAlgebraicDomain A) :
    Chapter3.IsAlgebraicDomain B := by
  apply prop_2_2_4_1
  intro b
  let S := Approximants (CompactSet : Set A) (e.symm b)
  have hS := hA (e.symm b)
  refine ⟨e '' S, ?_, DirectedSet.image e.monotone hS.1, ?_⟩
  · rintro _ ⟨a, ha, rfl⟩
    have h := compact_orderIso e ha.1
    have hLE : e a ≤ b := by
      simpa using e.monotone (prop_2_2_2_1 ha.2)
    exact ⟨h, prop_2_2_2_2 le_rfl h hLE⟩
  · simpa using (scottContinuous_orderIso e).2 hS.1 hS.2

def lawsonAlgebraic_orderIso (e : A ≃o B) (hA : LawsonAlgebraic A) :
    LawsonAlgebraic B := by
  let sr := sectionRetractionOfOrderIso e.symm
  have hD := sr.toSectionRetractionPair.isDcpo_of_isDcpo hA.dcpo
  have hAlg := algebraic_orderIso e hA.algebraic
  have hCore := (continuous_lawsonCompact_iff_scottCompact_and_coherent_proved
    hA.dcpo ⟨CompactSet, hA.algebraic⟩).1 hA.lawsonCompact
  have hScott := scottCompactSpace_of_surjective_scottContinuous
    hCore.1 sr.continuous_r e.surjective
  exact ⟨hD, hAlg, lawsonCompact_of_scottCompact_and_coherent_internal
    hD ⟨CompactSet, hAlg⟩ hScott (coherent_of_continuous_retract sr hCore.2)⟩

/-- The inclusion--projection pair attached to an actual kernel image. -/
def kernelImagePair (k : Chapter3.KernelOperator A) :
    Chapter3.ContinuousSectionRetractionPair k.ImageCarrier A where
  s := k.inclusion
  r := k.projection
  monotone_s := k.inclusion_monotone
  monotone_r := k.projection_monotone
  retract := k.projection_inclusion_eq
  continuous_s := k.inclusion_scottContinuous
  continuous_r := k.projection_scottContinuous

/-- An embedding--projection pair induces a below-identity kernel on its
ambient carrier, rather than an arbitrary idempotent. -/
def kernelOfPair (sr : Chapter3.ContinuousSectionRetractionPair A B)
    (hBelow : ∀ b, sr.s (sr.r b) ≤ b) : Chapter3.KernelOperator B where
  k := sr.s ∘ sr.r
  continuous := sr.continuous_s.comp sr.continuous_r
  idem := by intro b; change sr.s (sr.r (sr.s (sr.r b))) = _; rw [sr.retract]; rfl
  below := hBelow

def pairImageIso (sr : Chapter3.ContinuousSectionRetractionPair A B)
    (hBelow : ∀ b, sr.s (sr.r b) ≤ b) : A ≃o (kernelOfPair sr hBelow).ImageCarrier where
  toFun a := ⟨sr.s a, ⟨sr.s a, by
    change sr.s (sr.r (sr.s a)) = sr.s a
    rw [sr.retract]⟩⟩
  invFun b := sr.r b.1
  left_inv := sr.retract
  right_inv := fun b ↦ Subtype.ext ((kernelOfPair sr hBelow).mem_range_iff_fixed.1 b.2)
  map_rel_iff' := by
    intro a a'
    change sr.s a ≤ sr.s a' ↔ a ≤ a'
    exact ⟨fun h ↦ by simpa only [sr.retract] using sr.monotone_r h,
      fun h ↦ sr.monotone_s h⟩

namespace UnpointedBifinite

def toKernelApproximation (hA : UnpointedBifinite A) : KernelApproximation A where
  operators := hA.operators
  directed := ⟨hA.operators_nonempty, by
    intro p hp q hq
    obtain ⟨r, hr, h⟩ := hA.directed p hp q hq
    exact ⟨r, hr, fun x ↦ (h x).1, fun x ↦ (h x).2⟩⟩
  supremum := fun x ↦ by
    have hEq : ((fun k : Chapter3.KernelOperator A ↦ k.k x) '' hA.operators) =
        {y : A | ∃ k ∈ hA.operators, y = k.k x} := by
      ext y
      simp only [Set.mem_image, Set.mem_setOf_eq]
      exact exists_congr (fun _ ↦ and_congr_right (fun _ ↦ eq_comm))
    rw [hEq]
    exact hA.approximates x

/-- Fixing every finite set of compacts by a finite-image kernel suffices.
All finite-image kernels then form a directed approximate identity. -/
def of_compact_finite_fix (hA : IsDcpo A) (hAlg : Chapter3.IsAlgebraicDomain A)
    (hFix : ∀ S : Set A, S.Finite → (∀ x ∈ S, Compact x) →
      ∃ k : Chapter3.KernelOperator A, (Set.range k.k).Finite ∧ ∀ x ∈ S, k.k x = x) :
    UnpointedBifinite A := by
  let K : Set (Chapter3.KernelOperator A) := {k | (Set.range k.k).Finite}
  refine ⟨hA, hAlg, K, ?_, fun _ hk ↦ hk, ?_, ?_⟩
  · obtain ⟨k, hk, _⟩ := hFix ∅ Set.finite_empty (by simp)
    exact ⟨k, hk⟩
  · intro p hp q hq
    obtain ⟨k, hk, hK⟩ := hFix (Set.range p.k ∪ Set.range q.k)
      (Set.Finite.union hp hq) (by
        intro x hx
        rcases hx with ⟨y, rfl⟩ | ⟨y, rfl⟩
        · exact finiteKernel_value_compact p hp y
        · exact finiteKernel_value_compact q hq y)
    refine ⟨k, hk, fun x ↦ ⟨?_, ?_⟩⟩
    · have h := hK (p.k x) (Or.inl ⟨x, rfl⟩)
      exact le_trans h.symm.le (k.continuous.1 (p.below x))
    · have h := hK (q.k x) (Or.inr ⟨x, rfl⟩)
      exact le_trans h.symm.le (k.continuous.1 (q.below x))
  · intro x
    refine ⟨?_, ?_⟩
    · rintro _ ⟨k, _, rfl⟩
      exact k.below x
    · intro y hy
      apply (hAlg x).2.2 y
      intro a ha
      obtain ⟨k, hk, hK⟩ := hFix {a} (Set.finite_singleton _) (by
        intro z hz
        have heq : z = a := by simpa using hz
        exact heq ▸ ha.1)
      exact le_trans (hK a (by simp)).symm.le
        (le_trans (k.continuous.1 (prop_2_2_2_1 ha.2)) (hy ⟨k, hk, rfl⟩))

end UnpointedBifinite

def conjugateKernel (e : A ≃o B) (k : Chapter3.KernelOperator A) :
    Chapter3.KernelOperator B where
  k := fun b ↦ e (k.k (e.symm b))
  continuous := (scottContinuous_orderIso e).comp
    (k.continuous.comp (scottContinuous_orderIso e.symm))
  idem := by intro b; simp only [OrderIso.symm_apply_apply, k.idem]
  below := fun b ↦ by simpa using e.monotone (k.below (e.symm b))

def bifinite_orderIso (e : A ≃o B) (hA : UnpointedBifinite A) : UnpointedBifinite B := by
  apply UnpointedBifinite.of_compact_finite_fix
    ((sectionRetractionOfOrderIso e.symm).toSectionRetractionPair.isDcpo_of_isDcpo hA.dcpo)
    (algebraic_orderIso e hA.algebraic)
  intro S hS hComp
  obtain ⟨k, hk, hFix⟩ := hA.toKernelApproximation.exists_fix_finite
    (hS.image e.symm) (by rintro _ ⟨b, hb, rfl⟩; exact compact_orderIso e.symm (hComp b hb))
  refine ⟨conjugateKernel e k, ?_, ?_⟩
  · apply ((hA.finite_image k hk).image e).subset
    rintro _ ⟨b, rfl⟩
    exact ⟨k.k (e.symm b), ⟨e.symm b, rfl⟩, rfl⟩
  · intro b hb
    change e (k.k (e.symm b)) = b
    rw [hFix (e.symm b) ⟨b, hb, rfl⟩, e.apply_symm_apply]

/-- A directed kernel approximation with bifinite images has a bifinite
carrier. A finite set of compact elements is fixed first at one ambient
stage and then by a single finite-image operator inside that stage. -/
def KernelApproximation.bifinite (F : KernelApproximation A) (hA : IsDcpo A)
    (hStages : ∀ k ∈ F.operators, UnpointedBifinite k.ImageCarrier) : UnpointedBifinite A := by
  apply UnpointedBifinite.of_compact_finite_fix hA
    (F.algebraic (fun k hk ↦ (hStages k hk).algebraic))
  intro S hS hComp
  obtain ⟨outer, ho, hOuter⟩ := F.exists_fix_finite hS hComp
  obtain ⟨inner, hi, hInner⟩ := (hStages outer ho).toKernelApproximation.exists_fix_finite
    (hS.image outer.projection) (by
      rintro _ ⟨x, hx, rfl⟩
      apply (kernelImage_compact_iff outer (outer.projection x)).2
      change Compact (outer.k x)
      rw [hOuter x hx]
      exact hComp x hx)
  let k : Chapter3.KernelOperator A :=
    { k := fun x ↦ outer.inclusion (inner.k (outer.projection x))
      continuous := outer.inclusion_scottContinuous.comp
        (inner.continuous.comp outer.projection_scottContinuous)
      idem := by
        intro x
        have hRetract (z : outer.ImageCarrier) :
            outer.projection (outer.inclusion z) = z := outer.projection_inclusion_eq z
        change outer.inclusion (inner.k (outer.projection (outer.inclusion
          (inner.k (outer.projection x))))) = _
        rw [hRetract, inner.idem]
      below := fun x ↦ le_trans (outer.inclusion_monotone (inner.below _)) (outer.below x) }
  refine ⟨k, ?_, ?_⟩
  · apply (((hStages outer ho).finite_image inner hi).image outer.inclusion).subset
    rintro _ ⟨x, rfl⟩
    exact ⟨inner.k (outer.projection x), ⟨outer.projection x, rfl⟩, rfl⟩
  · intro x hx
    change outer.inclusion (inner.k (outer.projection x)) = x
    rw [hInner (outer.projection x) ⟨x, hx, rfl⟩, outer.inclusion_projection_eq,
      hOuter x hx]

end

end CoherentContinuousAlgebraicRetracts
