import CoherentContinuousAlgebraicRetracts.InternalCoherence

/-!
# Nonempty Scott-open sub-dcpos

This file formalizes source item `lem:open-subdcpo`.  The order-theoretic and
topological core is adapted from the independently checked proof in
`Data/Formalizations/Papers/ScottIsbellCoincidence/.../ScottOpenSubdcpo.lean`;
the continuity, coherence, algebraicity, and compact-element clauses below are
proved here against the present paper's interfaces.
-/

set_option autoImplicit false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

variable {A : Type u} [PartialOrder A]

/-- Direct upper-closure/inaccessibility introduction rule for the project's
complement-based `ScottOpen` predicate. -/
theorem scottOpen_of_upper_and_inaccessible
    {U : Set A} (hUpper : Chapter2.IsUpperSet U)
    (hInaccessible : ∀ {E : Set A} {a : A},
      DirectedSet E → IsSup E a → a ∈ U → ∃ e ∈ E, e ∈ U) :
    ScottOpen U := by
  constructor
  · intro x y hyU hxy hxU
    exact hyU (hUpper hxU hxy)
  · intro E a hE hEcomp ha
    by_contra haComp
    rcases hInaccessible hE ha (by simpa using haComp) with
      ⟨e, heE, heU⟩
    exact (hEcomp heE) heU

/-- A Scott-open set containing a directed supremum meets the directed set. -/
theorem scottOpen_meets_directed
    {U : Set A} (hU : ScottOpen U) {E : Set A} {a : A}
    (hE : DirectedSet E) (ha : IsSup E a) (haU : a ∈ U) :
    ∃ e ∈ E, e ∈ U := by
  by_contra hnone
  have hEcomp : E ⊆ Uᶜ := by
    intro e heE heU
    exact hnone ⟨e, heE, heU⟩
  exact (hU.2 hE hEcomp ha) haU

/-- A nonempty Scott-open subtype of a dcpo is a dcpo. -/
theorem scottOpenSubtype_isDcpo
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U)
    (hUNonempty : U.Nonempty) : IsDcpo U := by
  intro E hE
  have hImage : DirectedSet (((↑) : U → A) '' E) :=
    DirectedSet.image (fun _ _ h ↦ h) hE
  obtain ⟨a, ha⟩ := hA _ hImage
  obtain ⟨e₀, he₀E⟩ := hE.1
  have haU : a ∈ U :=
    scottOpen_upper hU e₀.2 (ha.1 ⟨e₀, he₀E, rfl⟩)
  refine ⟨⟨a, haU⟩, ?_⟩
  constructor
  · intro e he
    exact ha.1 ⟨e, he, rfl⟩
  · intro q hq
    change a ≤ q.1
    apply ha.2
    rintro _ ⟨e, heE, rfl⟩
    exact hq heE

/-- Directed suprema in a Scott-open subtype are the ambient suprema. -/
theorem scottOpenSubtype_isLUB_ambient
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U)
    {E : Set U} {a : U} (hE : DirectedSet E) (ha : IsLUB E a) :
    IsLUB (((↑) : U → A) '' E) a.1 := by
  have hImage : DirectedSet (((↑) : U → A) '' E) :=
    DirectedSet.image (fun _ _ h ↦ h) hE
  obtain ⟨p, hp⟩ := hA _ hImage
  obtain ⟨e₀, he₀E⟩ := hE.1
  have hpU : p ∈ U :=
    scottOpen_upper hU e₀.2 (hp.1 ⟨e₀, he₀E, rfl⟩)
  let pU : U := ⟨p, hpU⟩
  have hpSubtype : IsLUB E pU := by
    constructor
    · intro q hq
      exact hp.1 ⟨q, hq, rfl⟩
    · intro q hq
      change p ≤ q.1
      apply hp.2
      rintro _ ⟨r, hrE, rfl⟩
      exact hq hrE
  have hap : a = pU := ha.unique hpSubtype
  have hval : a.1 = p := congrArg Subtype.val hap
  simpa [hval] using hp

/-- The inclusion of a Scott-open subtype is Scott-continuous. -/
theorem scottOpenSubtype_inclusion_scottContinuous
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U) :
    Chapter2.ScottContinuous ((↑) : U → A) := by
  constructor
  · intro x y hxy
    exact hxy
  · intro E a hE ha
    exact scottOpenSubtype_isLUB_ambient hA hU hE ha

/-- An ambient way-below relation remains way-below in the open subtype. -/
theorem wayBelow_subtype_of_ambient
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U)
    {a x : U} (hax : a.1 ≪ x.1) : a ≪ x := by
  intro E y hE hy hxy
  have hyAmbient := scottOpenSubtype_isLUB_ambient hA hU hE hy
  have hImageDir : DirectedSet (((↑) : U → A) '' E) :=
    DirectedSet.image (f := ((↑) : U → A)) (fun _ _ h ↦ h) hE
  rcases hax hImageDir hyAmbient hxy with ⟨e, heImage, hae⟩
  rcases heImage with ⟨eU, heUE, rfl⟩
  exact ⟨eU, heUE, hae⟩

/-- Turn a subset of the open subtype into the corresponding ambient set. -/
def ambientOfOpenSubtype {U : Set A} (V : Set U) : Set A :=
  {x | ∃ hx : x ∈ U, (⟨x, hx⟩ : U) ∈ V}

@[simp]
theorem preimage_ambientOfOpenSubtype {U : Set A} (V : Set U) :
    ((↑) : U → A) ⁻¹' ambientOfOpenSubtype V = V := by
  ext x
  constructor
  · rintro ⟨hxU, hxV⟩
    simpa using hxV
  · intro hxV
    exact ⟨x.2, by simpa using hxV⟩

theorem ambientOfOpenSubtype_isScottOpen
    {U : Set A} (hU : ScottOpen U)
    {V : Set U} (hV : ScottOpen V) :
    ScottOpen (ambientOfOpenSubtype V) := by
  apply scottOpen_of_upper_and_inaccessible
  · rintro x y ⟨hxU, hxV⟩ hxy
    have hyU : y ∈ U := scottOpen_upper hU hxU hxy
    exact ⟨hyU, scottOpen_upper hV hxV hxy⟩
  · intro E a hE ha ⟨haU, haV⟩
    obtain ⟨e₀, he₀E, he₀U⟩ :=
      scottOpen_meets_directed hU hE ha haU
    let F : Set U := {q | q.1 ∈ E ∧ e₀ ≤ q.1}
    have hF : DirectedSet F := by
      constructor
      · exact ⟨⟨e₀, he₀U⟩, he₀E, le_rfl⟩
      · intro x hx y hy
        obtain ⟨e, heE, hxe, hye⟩ :=
          hE.2 (x := x.1) hx.1 (y := y.1) hy.1
        have heU : e ∈ U := scottOpen_upper hU x.2 hxe
        exact ⟨⟨e, heU⟩, ⟨heE, hx.2.trans hxe⟩, hxe, hye⟩
    let aU : U := ⟨a, haU⟩
    have hFLUB : IsLUB F aU := by
      constructor
      · intro q hq
        exact ha.1 hq.1
      · intro q hq
        change a ≤ q.1
        apply ha.2
        intro d hdE
        obtain ⟨e, heE, hde, he₀e⟩ :=
          hE.2 (x := d) hdE (y := e₀) he₀E
        have heU : e ∈ U := scottOpen_upper hU he₀U he₀e
        exact hde.trans
          (hq (show (⟨e, heU⟩ : U) ∈ F from ⟨heE, he₀e⟩))
    obtain ⟨q, hqF, hqV⟩ :=
      scottOpen_meets_directed hV hF hFLUB haV
    exact ⟨q.1, hqF.1, q.2, hqV⟩

theorem preimage_isScottOpen_openSubtype
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U)
    {W : Set A} (hW : ScottOpen W) :
    ScottOpen (((↑) : U → A) ⁻¹' W) := by
  apply scottOpen_of_upper_and_inaccessible
  · intro x y hx hxy
    exact scottOpen_upper hW hx hxy
  · intro E a hE ha haW
    have hAmbientLUB := scottOpenSubtype_isLUB_ambient hA hU hE ha
    have hAmbientDirected : DirectedSet (((↑) : U → A) '' E) :=
      DirectedSet.image (f := ((↑) : U → A)) (fun _ _ h ↦ h) hE
    obtain ⟨x, hxImage, hxW⟩ :=
      scottOpen_meets_directed hW hAmbientDirected hAmbientLUB haW
    obtain ⟨q, hqE, rfl⟩ := hxImage
    exact ⟨q, hqE, hxW⟩

/-- The intrinsic Scott topology on a Scott-open subtype is the induced
subspace topology. -/
theorem scottTopology_openSubtype_eq_induced
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U) :
    (@Chapter2.scottTopologicalSpace U inferInstance) =
      TopologicalSpace.induced ((↑) : U → A)
        (@Chapter2.scottTopologicalSpace A inferInstance) := by
  letI : TopologicalSpace A := Chapter2.scottTopologicalSpace
  apply TopologicalSpace.ext_iff.mpr
  intro V
  rw [Chapter2.isOpen_scottTopologicalSpace_iff]
  rw [isOpen_induced_iff]
  constructor
  · intro hV
    exact ⟨ambientOfOpenSubtype V,
      (Chapter2.isOpen_scottTopologicalSpace_iff).2
        (ambientOfOpenSubtype_isScottOpen hU hV),
      preimage_ambientOfOpenSubtype V⟩
  · rintro ⟨W, hW, rfl⟩
    exact preimage_isScottOpen_openSubtype hA hU
      ((Chapter2.isOpen_scottTopologicalSpace_iff).1 hW)

/-! ## Inherited continuity -/

/-- Continuity is inherited by a nonempty Scott-open subtype. -/
theorem scottOpenSubtype_isContinuous
    (hA : IsDcpo A) (hContinuous : AbramskyJung.Chapter3.IsContinuousDomain A)
    {U : Set A} (hU : ScottOpen U) (hUNonempty : U.Nonempty) :
    AbramskyJung.Chapter3.IsContinuousDomain U := by
  have hRawContinuous : Chapter2.IsContinuousDomain A := by
    rcases hContinuous with ⟨B, hB⟩
    exact ⟨B, basis_to_raw hB⟩
  refine ⟨Set.univ, prop_2_2_4_1 ?_⟩
  intro x
  let S : Set U := {b | b.1 ≪ x.1}
  have hAmbientDir : DirectedSet (wayBelowLower x.1) :=
    continuous_wayBelowLower_directed hRawContinuous x.1
  have hAmbientSup : IsSup (wayBelowLower x.1) x.1 :=
    continuous_wayBelowLower_isSup hRawContinuous x.1
  have hSnonempty : S.Nonempty := by
    obtain ⟨b, hbLower, hbU⟩ :=
      scottOpen_meets_directed hU hAmbientDir hAmbientSup x.2
    exact ⟨⟨b, hbU⟩, hbLower⟩
  have hSdir : DirectedSet S := by
    constructor
    · exact hSnonempty
    · intro b hb c hc
      obtain ⟨d, hdLower, hbd, hcd⟩ :=
        hAmbientDir.2 (x := b.1) hb (y := c.1) hc
      have hdU : d ∈ U := scottOpen_upper hU b.2 hbd
      exact ⟨⟨d, hdU⟩, hdLower, hbd, hcd⟩
  have hSsup : IsSup S x := by
    constructor
    · intro b hb
      change b.1 ≪ x.1 at hb
      exact @prop_2_2_2_1 A _ b.1 x.1 hb
    · intro y hy
      change x.1 ≤ y.1
      apply hAmbientSup.2
      intro b hbLower
      obtain ⟨u, huS⟩ := hSnonempty
      obtain ⟨d, hdLower, hbd, hud⟩ :=
        hAmbientDir.2 (x := b) hbLower
          (y := u.1) huS
      have hdU : d ∈ U := scottOpen_upper hU u.2 hud
      exact hbd.trans (hy (show (⟨d, hdU⟩ : U) ∈ S from hdLower))
  refine ⟨S, ?_, hSdir, hSsup⟩
  intro b hb
  change b.1 ≪ x.1 at hb
  exact ⟨Set.mem_univ b,
    wayBelow_subtype_of_ambient hA hU hb⟩

/-! ## Inherited algebraicity and compact elements -/

/-- Compactness of an element is unchanged on passing to a Scott-open
subtype. -/
theorem compact_openSubtype_iff
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U) (k : U) :
    Compact k ↔ Compact k.1 := by
  constructor
  · intro hk
    intro E a hE ha hka
    have haU : a ∈ U := scottOpen_upper hU k.2 hka
    obtain ⟨e₀, he₀E, he₀U⟩ :=
      scottOpen_meets_directed hU hE ha haU
    let F : Set U := {e | e.1 ∈ E}
    have hF : DirectedSet F := by
      constructor
      · exact ⟨⟨e₀, he₀U⟩, he₀E⟩
      · intro x hx y hy
        obtain ⟨e, heE, hxe, hye⟩ :=
          hE.2 (x := x.1) hx (y := y.1) hy
        have heU : e ∈ U := scottOpen_upper hU x.2 hxe
        exact ⟨⟨e, heU⟩, heE, hxe, hye⟩
    let aU : U := ⟨a, haU⟩
    have hFSup : IsSup F aU := by
      constructor
      · intro e he
        exact ha.1 he
      · intro y hy
        change a ≤ y.1
        apply ha.2
        intro e heE
        obtain ⟨d, hdE, hed, he₀d⟩ :=
          hE.2 (x := e) heE (y := e₀) he₀E
        have hdU : d ∈ U := scottOpen_upper hU he₀U he₀d
        exact hed.trans (hy (show (⟨d, hdU⟩ : U) ∈ F from hdE))
    rcases hk hF hFSup hka with ⟨e, heF, hke⟩
    exact ⟨e.1, heF, hke⟩
  · intro hk
    exact wayBelow_subtype_of_ambient hA hU hk

/-- Algebraicity is inherited by a nonempty Scott-open subtype, and its
compact elements are exactly the ambient compact elements lying in the open
set. -/
theorem scottOpenSubtype_isAlgebraic
    (hA : IsDcpo A) (hAlgebraic : AbramskyJung.Chapter3.IsAlgebraicDomain A)
    {U : Set A} (hU : ScottOpen U) (hUNonempty : U.Nonempty) :
    AbramskyJung.Chapter3.IsAlgebraicDomain U := by
  refine prop_2_2_4_1 ?_
  intro x
  let S : Set U :=
    {k | k.1 ∈ Approximants (CompactSet : Set A) x.1}
  have hAmbientDir :
      DirectedSet (Approximants (CompactSet : Set A) x.1) :=
    (hAlgebraic x.1).1
  have hAmbientSup :
      IsSup (Approximants (CompactSet : Set A) x.1) x.1 :=
    (hAlgebraic x.1).2
  have hSnonempty : S.Nonempty := by
    obtain ⟨k, hkApprox, hkU⟩ :=
      scottOpen_meets_directed hU hAmbientDir hAmbientSup x.2
    exact ⟨⟨k, hkU⟩, hkApprox⟩
  have hSdir : DirectedSet S := by
    constructor
    · exact hSnonempty
    · intro k hk l hl
      obtain ⟨m, hmApprox, hkm, hlm⟩ :=
        hAmbientDir.2 (x := k.1) hk (y := l.1) hl
      have hmU : m ∈ U := scottOpen_upper hU k.2 hkm
      exact ⟨⟨m, hmU⟩, hmApprox, hkm, hlm⟩
  have hSsup : IsSup S x := by
    constructor
    · intro k hk
      exact @prop_2_2_2_1 A _ k.1 x.1 hk.2
    · intro y hy
      change x.1 ≤ y.1
      apply hAmbientSup.2
      intro k hk
      obtain ⟨u, huS⟩ := hSnonempty
      obtain ⟨m, hmApprox, hkm, hum⟩ :=
        hAmbientDir.2 (x := k) hk (y := u.1) huS
      have hmU : m ∈ U := scottOpen_upper hU u.2 hum
      exact hkm.trans (hy (show (⟨m, hmU⟩ : U) ∈ S from hmApprox))
  refine ⟨S, ?_, hSdir, hSsup⟩
  intro k hk
  exact
    ⟨(compact_openSubtype_iff hA hU k).2 hk.1,
      wayBelow_subtype_of_ambient hA hU hk.2⟩

theorem compactSet_openSubtype_eq
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U) :
    (CompactSet : Set U) =
      ((↑) : U → A) ⁻¹' (CompactSet : Set A) := by
  ext k
  exact compact_openSubtype_iff hA hU k

/-! ## Inherited coherence -/

/-- A compact subset of the open subtype remains compact in the ambient
Scott space under the inclusion map. -/
theorem scottCompact_image_openSubtype
    (hA : IsDcpo A) {U : Set A} (hU : ScottOpen U)
    {K : Set U} (hK : ScottCompact K) :
    ScottCompact (((↑) : U → A) '' K) :=
  hK.image_scottContinuous
    (scottOpenSubtype_inclusion_scottContinuous hA hU)

/-- An ambient Scott-compact set contained in the open set is compact in the
open subtype. -/
theorem scottCompact_preimage_openSubtype
    {U K : Set A} (hU : ScottOpen U) (hK : ScottCompact K)
    (hKU : K ⊆ U) :
    ScottCompact (((↑) : U → A) ⁻¹' K) := by
  classical
  intro cover hCoverOpen hCover
  let ambientCover : Set (Set A) :=
    ambientOfOpenSubtype '' cover
  have hAmbientOpen : ∀ V ∈ ambientCover, ScottOpen V := by
    intro V hV
    rcases hV with ⟨W, hWcover, rfl⟩
    exact ambientOfOpenSubtype_isScottOpen hU
      (hCoverOpen W hWcover)
  have hAmbientCover : K ⊆ Set.sUnion ambientCover := by
    intro x hxK
    let xU : U := ⟨x, hKU hxK⟩
    have hxPre : xU ∈ ((↑) : U → A) ⁻¹' K := hxK
    rcases Set.mem_sUnion.mp (hCover hxPre) with
      ⟨W, hWcover, hxW⟩
    exact Set.mem_sUnion_of_mem
      (show x ∈ ambientOfOpenSubtype W from ⟨xU.2, hxW⟩)
      ⟨W, hWcover, rfl⟩
  rcases hK ambientCover hAmbientOpen hAmbientCover with
    ⟨finiteAmbient, hFiniteSub, hFinite, hFiniteCovers⟩
  rcases exists_finite_preimage_cover hFinite hFiniteSub with
    ⟨finiteCover, hFiniteCover, hFiniteCoverSub, hFiniteImage⟩
  refine ⟨finiteCover, hFiniteCoverSub, hFiniteCover, ?_⟩
  intro x hxPre
  have hxAmbient : x.1 ∈ Set.sUnion finiteAmbient :=
    hFiniteCovers hxPre
  rcases Set.mem_sUnion.mp hxAmbient with
    ⟨V, hVfinite, hxV⟩
  rcases hFiniteImage hVfinite with ⟨W, hWfinite, hWV⟩
  apply Set.mem_sUnion_of_mem _ hWfinite
  have hxAmbientW : x.1 ∈ ambientOfOpenSubtype W := by
    rw [hWV]
    exact hxV
  exact (Set.ext_iff.mp (preimage_ambientOfOpenSubtype W) x).1
    hxAmbientW

/-- Coherence is inherited by a nonempty Scott-open subtype. -/
theorem scottOpenSubtype_isCoherent
    (hA : IsDcpo A) (hCoherent : IsCoherent A)
    {U : Set A} (hU : ScottOpen U) (hUNonempty : U.Nonempty) :
    IsCoherent U := by
  intro K L hK hL
  let val : U → A := (↑)
  have hKcompact : ScottCompact (val '' K) :=
    scottCompact_image_openSubtype hA hU hK.1
  have hLcompact : ScottCompact (val '' L) :=
    scottCompact_image_openSubtype hA hU hL.1
  have hKupper : Saturated (val '' K) := by
    rintro x y ⟨k, hkK, rfl⟩ hxy
    have hyU : y ∈ U := scottOpen_upper hU k.2 hxy
    exact ⟨⟨y, hyU⟩, hK.2 hkK hxy, rfl⟩
  have hLupper : Saturated (val '' L) := by
    rintro x y ⟨l, hlL, rfl⟩ hxy
    have hyU : y ∈ U := scottOpen_upper hU l.2 hxy
    exact ⟨⟨y, hyU⟩, hL.2 hlL hxy, rfl⟩
  have hAmbientInter :=
    hCoherent (val '' K) (val '' L)
      ⟨hKcompact, hKupper⟩ ⟨hLcompact, hLupper⟩
  have hSubsetU : (val '' K) ∩ (val '' L) ⊆ U := by
    rintro x ⟨⟨k, _, rfl⟩, _⟩
    exact k.2
  have hPreimage :
      val ⁻¹' ((val '' K) ∩ (val '' L)) = K ∩ L := by
    ext x
    simp only [Set.mem_preimage, Set.mem_inter_iff]
    constructor
    · rintro ⟨⟨k, hk, hkx⟩, ⟨l, hl, hlx⟩⟩
      have hkEq : k = x := Subtype.ext hkx
      have hlEq : l = x := Subtype.ext hlx
      simpa [hkEq, hlEq] using And.intro hk hl
    · rintro ⟨hxK, hxL⟩
      exact ⟨⟨x, hxK, rfl⟩, ⟨x, hxL, rfl⟩⟩
  constructor
  · rw [← hPreimage]
    exact scottCompact_preimage_openSubtype hU
      hAmbientInter.1 hSubsetU
  · exact saturated_inter hK.2 hL.2

end

end CoherentContinuousAlgebraicRetracts
