import CoherentContinuousAlgebraicRetracts.FunctionSpaces
import CoherentContinuousAlgebraicRetracts.PrefiniteKernels

/-!
# Approximation through prefinite algebraic domains

This file formalizes the factorable transfer argument in the final
subsection of the frozen source.  The algebraic characterization it uses
is proved in `PrefiniteKernels`.
-/

set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option linter.unnecessarySimpa false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

/-! ## Indexed factorable approximate identities -/

/-- One Scott-continuous factorization `D → A → D`, with a chosen basis
of the continuous intermediate dcpo. -/
structure FactorStage
    (D : Type u) [PartialOrder D] : Type (u + 1) where
  A : Type u
  [orderA : PartialOrder A]
  [nonemptyA : Nonempty A]
  dcpo : IsDcpo A
  basis : Set A
  basis_isBasis : IsBasis basis
  uMap : D → A
  vMap : A → D
  u_continuous : Chapter2.ScottContinuous uMap
  v_continuous : Chapter2.ScottContinuous vMap
  below : ∀ x : D, vMap (uMap x) ≤ x

attribute [instance] FactorStage.orderA FactorStage.nonemptyA

namespace FactorStage

variable {D : Type u} [PartialOrder D]

def map (S : FactorStage D) (x : D) : D := S.vMap (S.uMap x)

theorem map_continuous (S : FactorStage D) :
    Chapter2.ScottContinuous S.map :=
  S.v_continuous.comp S.u_continuous

end FactorStage

/-- A directed, pointwise approximate identity whose every member is supplied
with a continuous factorization. -/
structure FactorableApproximation
    (D : Type u) [PartialOrder D] : Type (u + 1) where
  I : Type u
  [orderI : Preorder I]
  [nonemptyI : Nonempty I]
  upper : ∀ i j : I, ∃ k : I, i ≤ k ∧ j ≤ k
  stage : I → FactorStage D
  monotone : ∀ {i j : I}, i ≤ j → ∀ x : D,
    (stage i).map x ≤ (stage j).map x
  supremum : ∀ x : D,
    IsSup (Set.range (fun i : I ↦ (stage i).map x)) x

attribute [instance]
  FactorableApproximation.orderI FactorableApproximation.nonemptyI

/-- Condition (ii) of `thm:prefinite-continuous`, retaining both the
factorization and the proof that every intermediate dcpo is prefinite
algebraic. -/
structure PrefiniteFactorableApproximation
    (D : Type u) [PartialOrder D] : Type (u + 1) where
  approximation : FactorableApproximation D
  prefinite : ∀ i : approximation.I,
    PrefiniteAlgebraic (approximation.stage i).A

/-- The increasing-sequence version in the final clause of
`thm:prefinite-continuous`. -/
structure SequentialPrefiniteApproximation
    (D : Type u) [PartialOrder D] : Type (u + 1) where
  stage : Nat → FactorStage D
  monotone : ∀ {n m : Nat}, n ≤ m → ∀ x : D,
    (stage n).map x ≤ (stage m).map x
  supremum : ∀ x : D,
    IsSup (Set.range (fun n : Nat ↦ (stage n).map x)) x
  prefinite : ∀ n : Nat, PrefiniteAlgebraic (stage n).A

namespace SequentialPrefiniteApproximation

variable {D : Type u} [PartialOrder D]

/-- Normalize every intermediate basis to its compact basis, as in the
countability proof in the source. -/
def toPrefiniteFactorable (F : SequentialPrefiniteApproximation D) :
    PrefiniteFactorableApproximation D := by
  let stage : Nat → FactorStage D := fun n ↦
    { A := (F.stage n).A
      orderA := inferInstance
      nonemptyA := inferInstance
      dcpo := (F.stage n).dcpo
      basis := CompactSet
      basis_isBasis := (F.prefinite n).algebraic
      uMap := (F.stage n).uMap
      vMap := (F.stage n).vMap
      u_continuous := (F.stage n).u_continuous
      v_continuous := (F.stage n).v_continuous
      below := (F.stage n).below }
  let approximation : FactorableApproximation D :=
    { I := ULift.{u} Nat
      orderI := inferInstance
      nonemptyI := inferInstance
      upper := fun n m ↦
        ⟨⟨max n.down m.down⟩, Nat.le_max_left _ _, Nat.le_max_right _ _⟩
      stage := fun n ↦ stage n.down
      monotone := by
        intro n m hnm x
        exact F.monotone hnm x
      supremum := by
        intro x
        have hEq :
            Set.range (fun n : ULift.{u} Nat ↦ (stage n.down).map x) =
              Set.range (fun n : Nat ↦ (stage n).map x) := by
          ext y
          constructor
          · rintro ⟨n, rfl⟩
            exact ⟨n.down, rfl⟩
          · rintro ⟨n, rfl⟩
            exact ⟨⟨n⟩, rfl⟩
        rw [hEq]
        simpa [stage, FactorStage.map] using F.supremum x }
  refine ⟨approximation, ?_⟩
  intro n
  simpa [approximation, stage] using F.prefinite n.down

/-- Pull an increasing factorization sequence back along a continuous
section--retraction pair. -/
def pullback
    {A : Type u} [PartialOrder A]
    (F : SequentialPrefiniteApproximation A)
    (sr : AbramskyJung.Chapter3.ContinuousSectionRetractionPair D A) :
    SequentialPrefiniteApproximation D := by
  let stage : Nat → FactorStage D := fun n ↦
    { A := (F.stage n).A
      orderA := inferInstance
      nonemptyA := inferInstance
      dcpo := (F.stage n).dcpo
      basis := (F.stage n).basis
      basis_isBasis := (F.stage n).basis_isBasis
      uMap := fun x ↦ (F.stage n).uMap (sr.s x)
      vMap := fun a ↦ sr.r ((F.stage n).vMap a)
      u_continuous := (F.stage n).u_continuous.comp sr.continuous_s
      v_continuous := sr.continuous_r.comp (F.stage n).v_continuous
      below := by
        intro x
        calc
          sr.r ((F.stage n).map (sr.s x)) ≤ sr.r (sr.s x) :=
            sr.monotone_r ((F.stage n).below (sr.s x))
          _ = x := sr.retract x }
  refine
    { stage := stage
      monotone := ?_
      supremum := ?_
      prefinite := ?_ }
  · intro n m hnm x
    exact sr.monotone_r (F.monotone hnm (sr.s x))
  · intro x
    have hImageSup : IsSup
        (sr.r '' Set.range (fun n : Nat ↦ (F.stage n).map (sr.s x)))
        (sr.r (sr.s x)) := by
      apply sr.continuous_r.2
      · have hMono : Monotone
            (fun n : Nat ↦ (F.stage n).map (sr.s x)) := by
          intro n m hnm
          exact F.monotone hnm (sr.s x)
        constructor
        · exact ⟨(F.stage 0).map (sr.s x), ⟨0, rfl⟩⟩
        · intro y hy z hz
          rcases hy with ⟨n, rfl⟩
          rcases hz with ⟨m, rfl⟩
          exact ⟨(F.stage (max n m)).map (sr.s x),
            ⟨max n m, rfl⟩,
            hMono (Nat.le_max_left _ _), hMono (Nat.le_max_right _ _)⟩
      · exact F.supremum (sr.s x)
    have hRangeEq :
        sr.r '' Set.range (fun n : Nat ↦ (F.stage n).map (sr.s x)) =
          Set.range (fun n : Nat ↦ (stage n).map x) := by
      ext y
      constructor
      · rintro ⟨z, ⟨n, rfl⟩, rfl⟩
        exact ⟨n, rfl⟩
      · rintro ⟨n, rfl⟩
        exact ⟨(F.stage n).map (sr.s x), ⟨n, rfl⟩, rfl⟩
    rw [hRangeEq] at hImageSup
    simpa [sr.retract x] using hImageSup
  · intro n
    simpa [stage] using F.prefinite n

end SequentialPrefiniteApproximation

namespace PrefiniteKernelApproximation

variable {A : Type u} [PartialOrder A]

/-- Regard a kernel approximation as a factorable approximate identity via
the projection to, and inclusion from, each kernel image. -/
def toFactorable (K : PrefiniteKernelApproximation A) :
    PrefiniteFactorableApproximation A := by
  let stage : K.I → FactorStage A := fun i ↦
    let k := K.operator i
    letI : PartialOrder k.ImageCarrier := kernelImagePartialOrder k
    { A := k.ImageCarrier
      orderA := inferInstance
      nonemptyA := ⟨k.projection (Classical.choice K.nonemptyA)⟩
      dcpo := kernelImage_isDcpo k K.dcpo
      basis := CompactSet
      basis_isBasis := (K.prefinite i).algebraic
      uMap := k.projection
      vMap := k.inclusion
      u_continuous := k.projection_scottContinuous
      v_continuous := k.inclusion_scottContinuous
      below := k.below }
  let F : FactorableApproximation A :=
    { I := K.I
      orderI := inferInstance
      nonemptyI := inferInstance
      upper := K.upper
      stage := stage
      monotone := by
        intro i j hij x
        exact K.monotone hij x
      supremum := by
        intro x
        simpa [stage, FactorStage.map] using K.supremum x }
  refine ⟨F, ?_⟩
  intro i
  simpa [F, stage] using K.prefinite i

end PrefiniteKernelApproximation

namespace FactorableApproximation

variable {D : Type u} [PartialOrder D]

/-- Abramsky--Jung, Proposition 4.2.16, in the transfer lemma's interface. -/
theorem continuous_coherent_iff_scottOpenIntersectionWayBelow
    (hD : IsDcpo D)
    (hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D) :
    IsCoherent D ↔
      AbramskyJung.Chapter4.ScottOpenIntersectionWayBelowProperty
        (asOrderedDomain D) :=
  continuous_coherent_iff_scottOpenIntersectionWayBelow_proved hD hContinuous

theorem index_directed (F : FactorableApproximation D) :
    DirectedSet (Set.univ : Set F.I) := by
  constructor
  · exact ⟨Classical.choice (inferInstance : Nonempty F.I), Set.mem_univ _⟩
  · intro i _hi j _hj
    rcases F.upper i j with ⟨k, hik, hjk⟩
    exact ⟨k, Set.mem_univ _, hik, hjk⟩

theorem values_directed (F : FactorableApproximation D) (x : D) :
    DirectedSet (Set.range (fun i : F.I ↦ (F.stage i).map x)) := by
  have hImage := DirectedSet.image
    (fun i j hij ↦ F.monotone hij x) F.index_directed
  simpa only [Set.image_univ] using hImage

/-- Pull a factorable approximate identity back along a continuous
section--retraction pair.  The intermediate dcpos and their bases are left
unchanged. -/
def pullback
    {A : Type u} [PartialOrder A]
    (F : FactorableApproximation A)
    (sr : AbramskyJung.Chapter3.ContinuousSectionRetractionPair D A) :
    FactorableApproximation D := by
  let stage : F.I → FactorStage D := fun i ↦
    { A := (F.stage i).A
      orderA := inferInstance
      nonemptyA := inferInstance
      dcpo := (F.stage i).dcpo
      basis := (F.stage i).basis
      basis_isBasis := (F.stage i).basis_isBasis
      uMap := fun x ↦ (F.stage i).uMap (sr.s x)
      vMap := fun a ↦ sr.r ((F.stage i).vMap a)
      u_continuous := (F.stage i).u_continuous.comp sr.continuous_s
      v_continuous := sr.continuous_r.comp (F.stage i).v_continuous
      below := by
        intro x
        calc
          sr.r ((F.stage i).map (sr.s x)) ≤ sr.r (sr.s x) :=
            sr.monotone_r ((F.stage i).below (sr.s x))
          _ = x := sr.retract x }
  refine
    { I := F.I
      orderI := inferInstance
      nonemptyI := inferInstance
      upper := F.upper
      stage := stage
      monotone := ?_
      supremum := ?_ }
  · intro i j hij x
    exact sr.monotone_r (F.monotone hij (sr.s x))
  · intro x
    have hImageSup : IsSup
        (sr.r '' Set.range (fun i : F.I ↦ (F.stage i).map (sr.s x)))
        (sr.r (sr.s x)) :=
      sr.continuous_r.2 (F.values_directed (sr.s x))
        (F.supremum (sr.s x))
    have hRangeEq :
        sr.r '' Set.range (fun i : F.I ↦ (F.stage i).map (sr.s x)) =
          Set.range (fun i : F.I ↦ (stage i).map x) := by
      ext y
      constructor
      · rintro ⟨z, ⟨i, rfl⟩, rfl⟩
        exact ⟨i, rfl⟩
      · rintro ⟨i, rfl⟩
        exact ⟨(F.stage i).map (sr.s x), ⟨i, rfl⟩, rfl⟩
    rw [hRangeEq] at hImageSup
    simpa [sr.retract x] using hImageSup

/-- The explicit basis obtained by taking the union of all retraction images
of the chosen stage bases. -/
def transferredBasis (F : FactorableApproximation D) : Set D :=
  {y | ∃ i : F.I, ∃ b ∈ (F.stage i).basis,
    y = (F.stage i).vMap b}

/-- The directed approximating set `T_x` from the proof of
`lem:factorable-transfer(a)`. -/
def approximantsAt (F : FactorableApproximation D) (x : D) : Set D :=
  {y | ∃ i : F.I, ∃ b ∈ (F.stage i).basis,
    b ≪ (F.stage i).uMap x ∧ y = (F.stage i).vMap b}

theorem approximantsAt_wayBelow
    (F : FactorableApproximation D) (x : D) :
    approximantsAt F x ⊆ wayBelowLower x := by
  intro y hy
  rcases hy with ⟨i, b, hbBasis, hbWay, rfl⟩
  let S := F.stage i
  intro E s hE hs hxs
  have huSup : IsSup (S.uMap '' E) (S.uMap s) :=
    S.u_continuous.2 hE hs
  have huDir := DirectedSet.image S.u_continuous.1 hE
  have huxs : S.uMap x ≤ S.uMap s := S.u_continuous.1 hxs
  rcases hbWay huDir huSup huxs with ⟨z, hz, hbz⟩
  rcases hz with ⟨e, heE, rfl⟩
  exact ⟨e, heE, le_trans (S.v_continuous.1 hbz) (S.below e)⟩

theorem approximantsAt_directed
    (F : FactorableApproximation D) (x : D) :
    DirectedSet (approximantsAt F x) := by
  constructor
  · let i : F.I := Classical.choice (inferInstance : Nonempty F.I)
    let S := F.stage i
    rcases (S.basis_isBasis (S.uMap x)).1.1 with ⟨b, hb⟩
    exact ⟨S.vMap b, i, b, hb.1, hb.2, rfl⟩
  · intro y hy z hz
    rcases hy with ⟨i, b, hbBasis, hbWay, rfl⟩
    rcases hz with ⟨j, c, hcBasis, hcWay, rfl⟩
    let S := F.stage i
    let T := F.stage j
    let V : Set D :=
      S.uMap ⁻¹' wayBelowUpper b ∩
        T.uMap ⁻¹' wayBelowUpper c
    have hVopen : ScottOpen V := by
      apply scottOpen_inter
      · exact scottOpen_preimage_of_scottContinuous S.u_continuous
          (scottOpen_wayBelowUpper
            ⟨S.basis, basis_to_raw S.basis_isBasis⟩ b)
      · exact scottOpen_preimage_of_scottContinuous T.u_continuous
          (scottOpen_wayBelowUpper
            ⟨T.basis, basis_to_raw T.basis_isBasis⟩ c)
    have hxV : x ∈ V := ⟨hbWay, hcWay⟩
    rcases scottOpen_meets_directed hVopen (F.values_directed x)
        (F.supremum x) hxV with
      ⟨w, ⟨h, rfl⟩, hfhxV⟩
    let H := F.stage h
    have hPreOpen : ScottOpen (H.vMap ⁻¹' V) :=
      scottOpen_preimage_of_scottContinuous H.v_continuous hVopen
    have huIn : H.uMap x ∈ H.vMap ⁻¹' V := hfhxV
    rcases scottOpen_meets_directed hPreOpen
        (H.basis_isBasis (H.uMap x)).1
        (H.basis_isBasis (H.uMap x)).2 huIn with
      ⟨d, hdApprox, hvdV⟩
    refine ⟨H.vMap d, ⟨h, d, hdApprox.1, hdApprox.2, rfl⟩, ?_, ?_⟩
    · calc
        S.vMap b ≤ S.vMap (S.uMap (H.vMap d)) :=
          S.v_continuous.1 (prop_2_2_2_1 hvdV.1)
        _ ≤ H.vMap d := S.below (H.vMap d)
    · calc
        T.vMap c ≤ T.vMap (T.uMap (H.vMap d)) :=
          T.v_continuous.1 (prop_2_2_2_1 hvdV.2)
        _ ≤ H.vMap d := T.below (H.vMap d)

theorem approximantsAt_isSup
    (F : FactorableApproximation D) (x : D) :
    IsSup (approximantsAt F x) x := by
  constructor
  · intro y hy
    exact prop_2_2_2_1 (F.approximantsAt_wayBelow x hy)
  · intro q hq
    apply (F.supremum x).2 q
    rintro _ ⟨i, rfl⟩
    let S := F.stage i
    have hvSup : IsSup
        (S.vMap '' Approximants S.basis (S.uMap x))
        (S.vMap (S.uMap x)) :=
      S.v_continuous.2
        (S.basis_isBasis (S.uMap x)).1
        (S.basis_isBasis (S.uMap x)).2
    apply hvSup.2 q
    rintro _ ⟨b, hbApprox, rfl⟩
    exact hq ⟨i, b, hbApprox.1, hbApprox.2, rfl⟩

/-- Source item `lem:factorable-transfer(a)`: the displayed union is a basis,
so the approximated dcpo is continuous. -/
theorem transfer_basis (F : FactorableApproximation D) :
    IsBasis (transferredBasis F) := by
  apply prop_2_2_4_1
  intro x
  refine ⟨approximantsAt F x, ?_, F.approximantsAt_directed x,
    F.approximantsAt_isSup x⟩
  intro y hy
  rcases hy with ⟨i, b, hbBasis, hbWay, rfl⟩
  exact ⟨⟨i, b, hbBasis, rfl⟩,
    F.approximantsAt_wayBelow x ⟨i, b, hbBasis, hbWay, rfl⟩⟩

theorem transfer_continuous (F : FactorableApproximation D) :
    AbramskyJung.Chapter3.IsContinuousDomain D :=
  ⟨transferredBasis F, F.transfer_basis⟩

/-- A Scott-compact set already lies inside the inverse image of a Scott open
under one member of the directed approximate identity.  This is the finite
subcover step in the proof of `lem:factorable-transfer(b)`. -/
theorem exists_stage_maps_compact_into
    (F : FactorableApproximation D) {K U : Set D}
    (hK : ScottCompact K) (hU : ScottOpen U) (hKU : K ⊆ U) :
    ∃ i : F.I, K ⊆ (F.stage i).map ⁻¹' U := by
  classical
  let cover : Set (Set D) :=
    Set.range (fun i : F.I ↦ (F.stage i).map ⁻¹' U)
  have hCoverOpen : ∀ V ∈ cover, ScottOpen V := by
    intro V hV
    rcases hV with ⟨i, rfl⟩
    exact scottOpen_preimage_of_scottContinuous
      (F.stage i).map_continuous hU
  have hCoverK : K ⊆ Set.sUnion cover := by
    intro x hxK
    rcases scottOpen_meets_directed hU (F.values_directed x)
        (F.supremum x) (hKU hxK) with ⟨y, ⟨i, rfl⟩, hyU⟩
    exact Set.mem_sUnion_of_mem hyU ⟨i, rfl⟩
  rcases hK cover hCoverOpen hCoverK with
    ⟨finiteCover, hFiniteSub, hFinite, hFiniteCovers⟩
  have hIndexWitness :
      ∀ V ∈ finiteCover,
        ∃ i : F.I, (F.stage i).map ⁻¹' U = V := by
    intro V hV
    rcases hFiniteSub hV with ⟨i, rfl⟩
    exact ⟨i, rfl⟩
  let chosenIndex : {V : Set D // V ∈ finiteCover} → F.I := fun V ↦
    Classical.choose (hIndexWitness V.1 V.2)
  have chosenIndex_spec :
      ∀ V : {V : Set D // V ∈ finiteCover},
        (F.stage (chosenIndex V)).map ⁻¹' U = V.1 := by
    intro V
    exact Classical.choose_spec (hIndexWitness V.1 V.2)
  let selected : Set F.I := Set.range chosenIndex
  letI : Finite {V : Set D // V ∈ finiteCover} :=
    Set.finite_coe_iff.mpr hFinite
  have hSelectedFinite : selected.Finite := Set.finite_range chosenIndex
  rcases Chapter2.DirectedSet.exists_upper_finite F.index_directed
      hSelectedFinite (Set.subset_univ selected) with
    ⟨i, _hi, hSelectedLe⟩
  refine ⟨i, ?_⟩
  intro x hxK
  rcases Set.mem_sUnion.mp (hFiniteCovers hxK) with ⟨V, hV, hxV⟩
  let V' : {W : Set D // W ∈ finiteCover} := ⟨V, hV⟩
  have hxChosen : (F.stage (chosenIndex V')).map x ∈ U := by
    change x ∈ (F.stage (chosenIndex V')).map ⁻¹' U
    rw [chosenIndex_spec V']
    exact hxV
  exact scottOpen_upper hU hxChosen
    (F.monotone (hSelectedLe (chosenIndex V') ⟨V', rfl⟩) x)

/-- Source item `lem:factorable-transfer(b)`: coherence is inherited from a
directed factorable approximate identity whose intermediate dcpos are all
coherent.  The proof follows the manuscript: compact witnesses for two
open-set approximations are moved to one common stage, intersected there,
and mapped back. -/
theorem transfer_coherent
    (hD : IsDcpo D) (F : FactorableApproximation D)
    (hCoherent : ∀ i : F.I, IsCoherent (F.stage i).A) :
    IsCoherent D := by
  classical
  have hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D :=
    F.transfer_continuous
  have hOpenIntersection :
      AbramskyJung.Chapter4.ScottOpenIntersectionWayBelowProperty
        (asOrderedDomain D) := by
    intro O U₁ U₂ hOU₁ hOU₂
    rcases (AbramskyJung.Chapter4.scottOpenWayBelow_iff_compactCarrier
        (asOrderedDomain D) hContinuous O U₁).1 hOU₁ with
      ⟨K₁, hK₁, hOK₁, hK₁U₁⟩
    rcases (AbramskyJung.Chapter4.scottOpenWayBelow_iff_compactCarrier
        (asOrderedDomain D) hContinuous O U₂).1 hOU₂ with
      ⟨K₂, hK₂, hOK₂, hK₂U₂⟩
    rcases F.exists_stage_maps_compact_into hK₁.1 U₁.scott_open hK₁U₁ with
      ⟨i, hi⟩
    rcases F.exists_stage_maps_compact_into hK₂.1 U₂.scott_open hK₂U₂ with
      ⟨j, hj⟩
    rcases F.upper i j with ⟨k, hik, hjk⟩
    let S := F.stage k
    have hk₁ : K₁ ⊆ S.map ⁻¹' U₁.carrierSet := by
      intro x hx
      exact scottOpen_upper U₁.scott_open (hi hx) (F.monotone hik x)
    have hk₂ : K₂ ⊆ S.map ⁻¹' U₂.carrierSet := by
      intro x hx
      exact scottOpen_upper U₂.scott_open (hj hx) (F.monotone hjk x)
    let L₁ : Set S.A := Chapter2.upperClosure (S.uMap '' K₁)
    let L₂ : Set S.A := Chapter2.upperClosure (S.uMap '' K₂)
    have hL₁ : CompactSaturated L₁ := by
      constructor
      · exact (ScottCompact.image_scottContinuous S.u_continuous hK₁.1).upperClosure
      · exact Chapter2.isUpperSet_upperClosure (S.uMap '' K₁)
    have hL₂ : CompactSaturated L₂ := by
      constructor
      · exact (ScottCompact.image_scottContinuous S.u_continuous hK₂.1).upperClosure
      · exact Chapter2.isUpperSet_upperClosure (S.uMap '' K₂)
    have hL₁target : L₁ ⊆ S.vMap ⁻¹' U₁.carrierSet := by
      intro a ha
      rcases ha with ⟨b, ⟨x, hxK, rfl⟩, hba⟩
      exact scottOpen_upper U₁.scott_open (hk₁ hxK)
        (S.v_continuous.1 hba)
    have hL₂target : L₂ ⊆ S.vMap ⁻¹' U₂.carrierSet := by
      intro a ha
      rcases ha with ⟨b, ⟨x, hxK, rfl⟩, hba⟩
      exact scottOpen_upper U₂.scott_open (hk₂ hxK)
        (S.v_continuous.1 hba)
    have hLinter : CompactSaturated (L₁ ∩ L₂) :=
      hCoherent k L₁ L₂ hL₁ hL₂
    let K : Set D := Chapter2.upperClosure (S.vMap '' (L₁ ∩ L₂))
    have hK : CompactSaturated K := by
      constructor
      · exact
          (ScottCompact.image_scottContinuous S.v_continuous hLinter.1).upperClosure
      · exact Chapter2.isUpperSet_upperClosure (S.vMap '' (L₁ ∩ L₂))
    have hOK : O.carrierSet ⊆ K := by
      intro x hxO
      have hxK₁ : x ∈ K₁ := hOK₁ hxO
      have hxK₂ : x ∈ K₂ := hOK₂ hxO
      have huL₁ : S.uMap x ∈ L₁ :=
        ⟨S.uMap x, ⟨x, hxK₁, rfl⟩, le_rfl⟩
      have huL₂ : S.uMap x ∈ L₂ :=
        ⟨S.uMap x, ⟨x, hxK₂, rfl⟩, le_rfl⟩
      exact ⟨S.map x, ⟨S.uMap x, ⟨huL₁, huL₂⟩, rfl⟩, S.below x⟩
    have hKU : K ⊆
        (AbramskyJung.Chapter4.ScottOpenCarrier.inter
          (asOrderedDomain D) U₁ U₂).carrierSet := by
      intro y hy
      rcases hy with ⟨z, ⟨a, ha, rfl⟩, hzy⟩
      exact ⟨
        scottOpen_upper U₁.scott_open (hL₁target ha.1) hzy,
        scottOpen_upper U₂.scott_open (hL₂target ha.2) hzy⟩
    exact (AbramskyJung.Chapter4.scottOpenWayBelow_iff_compactCarrier
      (asOrderedDomain D) hContinuous O
      (AbramskyJung.Chapter4.ScottOpenCarrier.inter
        (asOrderedDomain D) U₁ U₂)).2 ⟨K, hK, hOK, hKU⟩
  exact (continuous_coherent_iff_scottOpenIntersectionWayBelow
    hD hContinuous).2 hOpenIntersection

/-- Source item `lem:factorable-transfer(c)`. -/
theorem transfer_scottCompact
    (F : FactorableApproximation D)
    (hCompact : ∃ i : F.I, IsScottCompactSpace (F.stage i).A) :
    IsScottCompactSpace D := by
  rcases hCompact with ⟨i, hAi⟩
  let S := F.stage i
  have hImage : ScottCompact (S.vMap '' (Set.univ : Set S.A)) :=
    ScottCompact.image_scottContinuous S.v_continuous hAi
  have hUpperEq :
      Chapter2.upperClosure (S.vMap '' (Set.univ : Set S.A)) =
        (Set.univ : Set D) := by
    apply Set.eq_univ_of_forall
    intro x
    exact ⟨S.vMap (S.uMap x), ⟨S.uMap x, Set.mem_univ _, rfl⟩,
      S.below x⟩
  change ScottCompact (Set.univ : Set D)
  rw [← hUpperEq]
  exact hImage.upperClosure

/-- The three clauses of source lemma `lem:factorable-transfer`, bundled in
the source's order. -/
theorem lem_factorable_transfer
    (hD : IsDcpo D) (F : FactorableApproximation D) :
    (AbramskyJung.Chapter3.IsContinuousDomain D ∧
      IsBasis F.transferredBasis) ∧
      ((∀ i : F.I, IsCoherent (F.stage i).A) → IsCoherent D) ∧
      ((∃ i : F.I, IsScottCompactSpace (F.stage i).A) →
        IsScottCompactSpace D) := by
  exact ⟨⟨F.transfer_continuous, F.transfer_basis⟩,
    F.transfer_coherent hD, F.transfer_scottCompact⟩

end FactorableApproximation

namespace PrefiniteFactorableApproximation

variable {D A : Type u} [PartialOrder D] [PartialOrder A]

/-- Pullback preserves the prefinite intermediate dcpos because it changes
only the maps into and out of them. -/
def pullback
    (F : PrefiniteFactorableApproximation A)
    (sr : AbramskyJung.Chapter3.ContinuousSectionRetractionPair D A) :
    PrefiniteFactorableApproximation D := by
  refine ⟨F.approximation.pullback sr, ?_⟩
  intro i
  simpa [FactorableApproximation.pullback] using F.prefinite i

end PrefiniteFactorableApproximation

/-! ## Countability and the continuous characterization -/

namespace PrefiniteAlgebraic

variable {A : Type u} [PartialOrder A]

theorem mubClosureStep_finite
    (hM : HasPropertyM A) {S : Set A} (hS : S.Finite) :
    (mubClosureStep S).Finite := by
  let finiteSubsets : Set (Set A) := {F : Set A | F.Finite ∧ F ⊆ S}
  have hFiniteSubsets : finiteSubsets.Finite := by
    apply hS.finite_subsets.subset
    intro F hF
    exact hF.2
  have hFamilyFinite :
      (MinimalUpperBounds '' finiteSubsets).Finite :=
    hFiniteSubsets.image _
  have hMembersFinite :
      ∀ M ∈ MinimalUpperBounds '' finiteSubsets, M.Finite := by
    intro M hMmem
    rcases hMmem with ⟨F, hF, rfl⟩
    exact hM.2 F hF.1
  exact Set.Finite.sUnion hFamilyFinite hMembersFinite

theorem iteratedMubClosure_finite
    (hA : PrefiniteAlgebraic A) (n : Nat) :
    (iteratedMubClosure hA.generators n).Finite := by
  induction n with
  | zero => exact hA.generators_finite
  | succ n ih => exact mubClosureStep_finite hA.propertyM ih

/-- The compact basis of a prefinite algebraic dcpo is countable: it is a
countable union of finite MUB-closure stages. -/
theorem compactBasis_countable (hA : PrefiniteAlgebraic A) :
    (Set.univ : Set (CompactBasis A)).Countable := by
  rw [← hA.generated]
  exact Set.countable_iUnion (fun n ↦
    (hA.iteratedMubClosure_finite n).countable)

theorem compactSet_countable (hA : PrefiniteAlgebraic A) :
    (CompactSet : Set A).Countable := by
  have hImage := hA.compactBasis_countable.image
    (fun k : CompactBasis A ↦ k.1)
  apply hImage.mono
  intro x hx
  exact ⟨⟨x, hx⟩, Set.mem_univ _, rfl⟩

theorem scottCompact (hA : PrefiniteAlgebraic A) :
    IsScottCompactSpace A :=
  scottCompact_of_lawsonCompact_internal hA.lawsonCompact

theorem coherent (hA : PrefiniteAlgebraic A) : IsCoherent A := by
  apply algebraic_coherent_of_compact_principal_intersections_internal
    hA.dcpo (basis_to_raw hA.algebraic)
  intro x y _hx _hy
  exact principalUpper_inter_scottCompact_of_lawsonCompact_internal
    hA.lawsonCompact x y

end PrefiniteAlgebraic

namespace PrefiniteKernelApproximation

variable {A : Type u} [PartialOrder A]

theorem values_directed (K : PrefiniteKernelApproximation A) (x : A) :
    DirectedSet (Set.range (fun i : K.I ↦ (K.operator i).k x)) := by
  have hIndex : DirectedSet (Set.univ : Set K.I) := by
    constructor
    · exact ⟨Classical.choice (inferInstance : Nonempty K.I), Set.mem_univ _⟩
    · intro i _hi j _hj
      rcases K.upper i j with ⟨k, hik, hjk⟩
      exact ⟨k, Set.mem_univ _, hik, hjk⟩
  have hImage := DirectedSet.image
    (fun i j hij ↦ K.monotone hij x) hIndex
  simpa only [Set.image_univ] using hImage

theorem exists_operator_fixing_compact
    (K : PrefiniteKernelApproximation A) {k : A} (hk : Compact k) :
    ∃ i : K.I, (K.operator i).k k = k := by
  rcases hk (K.values_directed k) (K.supremum k) le_rfl with
    ⟨y, ⟨i, rfl⟩, hky⟩
  exact ⟨i, le_antisymm ((K.operator i).below k) hky⟩

/-- Recursively enlarge the operator chosen at the preceding step together
with a prescribed operator for the new compact element. -/
noncomputable def increasingIndex
    (K : PrefiniteKernelApproximation A) (fixer : Nat → K.I) :
    Nat → K.I
  | 0 => fixer 0
  | n + 1 => Classical.choose
      (K.upper (increasingIndex K fixer n) (fixer (n + 1)))

theorem increasingIndex_le_succ
    (K : PrefiniteKernelApproximation A) (fixer : Nat → K.I)
    (n : Nat) :
    increasingIndex K fixer n ≤ increasingIndex K fixer (n + 1) := by
  exact (Classical.choose_spec
    (K.upper (increasingIndex K fixer n) (fixer (n + 1)))).1

theorem fixer_le_increasingIndex_succ
    (K : PrefiniteKernelApproximation A) (fixer : Nat → K.I)
    (n : Nat) :
    fixer (n + 1) ≤ increasingIndex K fixer (n + 1) := by
  exact (Classical.choose_spec
    (K.upper (increasingIndex K fixer n) (fixer (n + 1)))).2

theorem fixer_le_increasingIndex
    (K : PrefiniteKernelApproximation A) (fixer : Nat → K.I)
    {j n : Nat} (hjn : j ≤ n) :
    fixer j ≤ increasingIndex K fixer n := by
  induction n with
  | zero =>
      have hj : j = 0 := Nat.eq_zero_of_le_zero hjn
      subst j
      exact le_rfl
  | succ n ih =>
      by_cases hj : j = n + 1
      · subst j
        exact K.fixer_le_increasingIndex_succ fixer n
      · have hjn' : j ≤ n := Nat.le_of_lt_succ
          (lt_of_le_of_ne hjn hj)
        exact le_trans (ih hjn') (K.increasingIndex_le_succ fixer n)

/-- Extract the cofinal increasing operator sequence described in the final
paragraph of the source proof. -/
noncomputable def sequentialFactorable
    (K : PrefiniteKernelApproximation A)
    (hAlg : AbramskyJung.Chapter3.IsAlgebraicDomain A)
    (hCount : (CompactSet : Set A).Countable) :
    SequentialPrefiniteApproximation A := by
  letI : Countable (CompactBasis A) := hCount.to_subtype
  have hCompactNonempty : (Set.univ : Set (CompactBasis A)).Nonempty := by
    let a : A := Classical.choice K.nonemptyA
    rcases (hAlg a).1.1 with ⟨b, hb⟩
    exact ⟨⟨b, hb.1⟩, Set.mem_univ _⟩
  letI : Nonempty (CompactBasis A) :=
    ⟨Classical.choose hCompactNonempty⟩
  have hEnumerationExists :
      ∃ enumerate : Nat → CompactBasis A, Function.Surjective enumerate :=
    exists_surjective_nat (CompactBasis A)
  let enumerate : Nat → CompactBasis A :=
    Classical.choose hEnumerationExists
  have hEnumerate : Function.Surjective enumerate :=
    Classical.choose_spec hEnumerationExists
  let fixer : Nat → K.I := fun n ↦
    Classical.choose (K.exists_operator_fixing_compact (enumerate n).2)
  have hFixer : ∀ n : Nat,
      (K.operator (fixer n)).k (enumerate n).1 = (enumerate n).1 := by
    intro n
    exact Classical.choose_spec
      (K.exists_operator_fixing_compact (enumerate n).2)
  let index : Nat → K.I := increasingIndex K fixer
  have hIndexMonotone : Monotone index :=
    monotone_nat_of_le_succ (fun n ↦ K.increasingIndex_le_succ fixer n)
  have hEnumeratedFixed : ∀ {j n : Nat}, j ≤ n →
      (K.operator (index n)).k (enumerate j).1 = (enumerate j).1 := by
    intro j n hjn
    apply le_antisymm ((K.operator (index n)).below (enumerate j).1)
    calc
      (enumerate j).1 = (K.operator (fixer j)).k (enumerate j).1 :=
        (hFixer j).symm
      _ ≤ (K.operator (index n)).k (enumerate j).1 :=
        K.monotone (K.fixer_le_increasingIndex fixer hjn) _
  have hSubsequenceSup : ∀ a : A,
      IsSup (Set.range (fun n : Nat ↦ (K.operator (index n)).k a)) a := by
    intro a
    constructor
    · rintro y ⟨n, rfl⟩
      exact (K.operator (index n)).below a
    · intro q hq
      apply (hAlg a).2.2 q
      intro b hb
      rcases hEnumerate ⟨b, hb.1⟩ with ⟨j, hj⟩
      have hba : b ≤ a := prop_2_2_2_1 hb.2
      have hFixed : (K.operator (index j)).k b = b := by
        have := hEnumeratedFixed (j := j) (n := j) le_rfl
        simpa [hj] using this
      calc
        b = (K.operator (index j)).k b := hFixed.symm
        _ ≤ (K.operator (index j)).k a :=
          (K.operator (index j)).continuous.1 hba
        _ ≤ q := hq ⟨j, rfl⟩
  let PF := K.toFactorable
  refine
    { stage := fun n ↦ PF.approximation.stage (index n)
      monotone := ?_
      supremum := ?_
      prefinite := fun n ↦ PF.prefinite (index n) }
  · intro n m hnm x
    exact PF.approximation.monotone (hIndexMonotone hnm) x
  · intro x
    simpa [PF, toFactorable, FactorStage.map] using hSubsequenceSup x

end PrefiniteKernelApproximation

namespace SequentialPrefiniteApproximation

variable {D : Type u} [PartialOrder D]

/-- An increasing prefinite factorization sequence yields a countable basis:
take the union of the images of the countable compact bases of its stages. -/
theorem omegaContinuous (F : SequentialPrefiniteApproximation D) :
    IsOmegaContinuousDomain D := by
  let G := F.toPrefiniteFactorable
  let B := G.approximation.transferredBasis
  letI : Countable G.approximation.I := by
    change Countable (ULift.{u} Nat)
    infer_instance
  have hUnionCountable :
      (⋃ i : G.approximation.I,
        (G.approximation.stage i).vMap ''
          (CompactSet : Set (G.approximation.stage i).A)).Countable := by
    exact Set.countable_iUnion (fun i ↦
      (G.prefinite i).compactSet_countable.image
        (G.approximation.stage i).vMap)
  have hBcountable : B.Countable := by
    apply hUnionCountable.mono
    intro y hy
    rcases hy with ⟨i, b, hb, rfl⟩
    exact Set.mem_iUnion_of_mem i ⟨b, hb, rfl⟩
  exact ⟨B, hBcountable,
    basis_to_raw G.approximation.transfer_basis⟩

end SequentialPrefiniteApproximation

/-- Source item `thm:prefinite-continuous`, excluding only its final
countability refinement, which is stated and proved separately below. -/
theorem thm_prefinite_continuous
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hD : IsDcpo D) :
    (AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain D) ∧
      AbramskyJung.Chapter3.IsContinuousDomain D) ↔
      Nonempty (PrefiniteFactorableApproximation D) := by
  constructor
  · rintro ⟨hLawson, hContinuous⟩
    have hCoherent : IsCoherent D :=
      ((continuous_lawsonCompact_iff_scottCompact_and_coherent_proved
        hD hContinuous).1 hLawson).2
    let W := lawsonRetractWitness hD hContinuous hCoherent hLawson
    letI : PartialOrder (IdealCompletion W.P) :=
      idealCompletionPartialOrder W.P
    letI : Nonempty (IdealCompletion W.P) :=
      ⟨principalIdeal W.P (Classical.choice (inferInstance : Nonempty W.P))⟩
    rcases (thm_prefinite_algebraic (IdealCompletion W.P)
        (idealCompletion_isDcpo W.P)).1
          ⟨W.lawsonCompact, prop_2_2_4_1 W.algebraic⟩ with
      ⟨K⟩
    exact ⟨K.toFactorable.pullback W.pair⟩
  · rintro ⟨F⟩
    have hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D :=
      F.approximation.transfer_continuous
    have hCoherent : IsCoherent D :=
      F.approximation.transfer_coherent hD
        (fun i ↦ (F.prefinite i).coherent)
    have hScott : IsScottCompactSpace D := by
      apply F.approximation.transfer_scottCompact
      let i : F.approximation.I :=
        Classical.choice (inferInstance : Nonempty F.approximation.I)
      exact ⟨i, (F.prefinite i).scottCompact⟩
    exact ⟨lawsonCompact_of_scottCompact_and_coherent_internal
      hD hContinuous hScott hCoherent, hContinuous⟩

/-- Final countability clause of `thm:prefinite-continuous`: a Lawson-compact
dcpo is countably based exactly when its prefinite factorable approximate
identity can be chosen as an increasing sequence. -/
theorem thm_prefinite_continuous_countable
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hD : IsDcpo D) :
    (AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain D) ∧
      IsOmegaContinuousDomain D) ↔
      Nonempty (SequentialPrefiniteApproximation D) := by
  constructor
  · rintro ⟨hLawson, hOmega⟩
    rcases hOmega with ⟨B, hBcount, hBraw⟩
    have hOmega' : IsOmegaContinuousDomain D :=
      ⟨B, hBcount, hBraw⟩
    have hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D :=
      ⟨B, prop_2_2_4_1 hBraw⟩
    have hCoherent : IsCoherent D :=
      ((continuous_lawsonCompact_iff_scottCompact_and_coherent_proved
        hD hContinuous).1 hLawson).2
    let W := countableLawsonRetractWitness
      hD hOmega' hCoherent hLawson
    letI : PartialOrder (IdealCompletion W.P) :=
      idealCompletionPartialOrder W.P
    letI : Nonempty (IdealCompletion W.P) :=
      ⟨principalIdeal W.P (Classical.choice (inferInstance : Nonempty W.P))⟩
    have hAalg : AbramskyJung.Chapter3.IsAlgebraicDomain
        (IdealCompletion W.P) :=
      prop_2_2_4_1 W.omegaAlgebraic.2
    rcases (thm_prefinite_algebraic (IdealCompletion W.P)
        (idealCompletion_isDcpo W.P)).1
          ⟨W.lawsonCompact, hAalg⟩ with ⟨K⟩
    let S := K.sequentialFactorable hAalg W.omegaAlgebraic.1
    exact ⟨S.pullback W.pair⟩
  · rintro ⟨F⟩
    have hOmega : IsOmegaContinuousDomain D := F.omegaContinuous
    have hMain := (thm_prefinite_continuous hD).2
      ⟨F.toPrefiniteFactorable⟩
    exact ⟨hMain.1, hOmega⟩

end

end CoherentContinuousAlgebraicRetracts
