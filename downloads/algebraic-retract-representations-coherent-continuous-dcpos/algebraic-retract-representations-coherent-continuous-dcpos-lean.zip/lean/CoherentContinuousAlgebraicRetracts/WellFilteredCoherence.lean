import CoherentContinuousAlgebraicRetracts.ContinuousCoherence

/-!
# Jia–Jung–Li: coherence and compactness for well-filtered dcpos

The upper Vietoris preimages used in Lemma 3.1 are represented by their
actual predicates `{x | ↑x ∩ K ⊆ U}`. This avoids importing a second Scott
topology or defining an ambient powerdomain.
-/

set_option autoImplicit false
set_option maxHeartbeats 1500000
set_option linter.unnecessarySimpa false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

variable {D : Type u} [PartialOrder D]

/-- Well-filteredness of the Scott space, phrased directly in terms of
its Scott opens and compact saturated sets. -/
def ScottWellFiltered (D : Type u) [PartialOrder D] : Prop :=
  ∀ (F : Set (Set D)), Chapter7.IsFilteredFamily F →
    (∀ K ∈ F, CompactSaturated K) →
    ∀ U : Set D, ScottOpen U → ⋂₀ F ⊆ U → ∃ K ∈ F, K ⊆ U

theorem ScottWellFiltered.of_continuous (hD : IsDcpo D)
    (hCont : Chapter3.IsContinuousDomain D) : ScottWellFiltered D := by
  let X := Chapter7.ScottTopologySpace D
  have hS := Chapter7.prop_7_2_27_continuous_domains_sober D hD
    (show Chapter2.IsContinuousDomain D from by
      rcases hCont with ⟨B, hB⟩
      exact ⟨B, basis_to_raw hB⟩)
  intro F hF hK
  exact (Chapter7.cor_7_2_11_filtered_intersections_compact_saturated X F hS hF
    (fun K hKF ↦ ⟨(hK K hKF).1, fun _ _ hx hxy ↦
      (hK K hKF).2 hx (prop_2_3_2_open_to_order (fun U hU hz ↦ hxy U hU hz))⟩)).open_reflection

theorem scottCompact_iff_directedOpenCover (K : Set D) :
    ScottCompact K ↔ ∀ A : Set (Set D), (∀ U ∈ A, ScottOpen U) →
      DirectedSet A → K ⊆ ⋃₀ A → ∃ U ∈ A, K ⊆ U := by
  constructor
  · intro hK A hOpen hA hCover
    obtain ⟨F, hFsub, hF, hFCov⟩ := hK A hOpen hCover
    obtain ⟨U, hU, hFle⟩ := hA.exists_upper_finite hF hFsub
    refine ⟨U, hU, ?_⟩
    intro x hx
    obtain ⟨V, hV, hxV⟩ := Set.mem_sUnion.mp (hFCov hx)
    exact hFle V hV hxV
  · intro hK cover hOpen hCover
    let A : Set (Set D) := {U | ∃ F : Set (Set D), F.Finite ∧ F ⊆ cover ∧ U = ⋃₀ F}
    have hAopen : ∀ U ∈ A, ScottOpen U := by
      rintro _ ⟨F, _, hFsub, rfl⟩
      exact (Chapter7.ScottTopologySpace D).sUnion_open F
        (fun U hU ↦ hOpen U (hFsub hU))
    have hADir : DirectedSet A := by
      constructor
      · exact ⟨⋃₀ (∅ : Set (Set D)), ∅, Set.finite_empty, Set.empty_subset _, rfl⟩
      · rintro _ ⟨F, hF, hf, rfl⟩ _ ⟨G, hG, hg, rfl⟩
        exact ⟨⋃₀ (F ∪ G), ⟨F ∪ G, hF.union hG, Set.union_subset hf hg, rfl⟩,
          Set.sUnion_mono Set.subset_union_left, Set.sUnion_mono Set.subset_union_right⟩
    obtain ⟨U, ⟨F, hF, hFsub, rfl⟩, hKU⟩ := hK A hAopen hADir (by
      intro x hx
      obtain ⟨W, hW, hxW⟩ := Set.mem_sUnion.mp (hCover hx)
      have hW' : (⋃₀ ({W} : Set (Set D))) ∈ A :=
        ⟨{W}, Set.finite_singleton _, Set.singleton_subset_iff.2 hW, rfl⟩
      exact Set.mem_sUnion_of_mem (Set.mem_sUnion_of_mem hxW (by simp)) hW')
    exact ⟨F, hFsub, hF, hKU⟩

private def sectionAbove (K : Set D) (x : D) : Set D := Set.Ici x ∩ K

private theorem principalUpper_eq_Ici (x : D) :
    Chapter2.upperClosure ({x} : Set D) = Set.Ici x := by
  ext y
  simp [Chapter2.upperClosure]

private theorem sectionAbove_antitone (K : Set D) : Antitone (sectionAbove K) :=
  fun _ _ h _ hz ↦ ⟨le_trans h hz.1, hz.2⟩

/-- The Scott-open preimage of an upper Vietoris basic open in the section
map. The inaccessibility clause is exactly well-filteredness applied to
the sections above the members of a directed set. -/
private theorem sectionCover_scottOpen (hWF : ScottWellFiltered D)
    {K U : Set D} (hSat : Saturated K)
    (hComp : ∀ x, ScottCompact (sectionAbove K x)) (hU : ScottOpen U) :
    ScottOpen {x | sectionAbove K x ⊆ U} := by
  constructor
  · intro x y hy hxy hx
    exact hy ((sectionAbove_antitone K hxy).trans hx)
  · intro E s hE hOutside hSup hs
    let F := sectionAbove K '' E
    have hF : Chapter7.IsFilteredFamily F := by
      constructor
      · exact hE.1.image _
      · rintro _ ⟨a, ha, rfl⟩ _ ⟨b, hb, rfl⟩
        obtain ⟨c, hc, hac, hbc⟩ := hE.2 ha hb
        exact ⟨sectionAbove K c, ⟨c, hc, rfl⟩,
          fun _ hz ↦ ⟨sectionAbove_antitone K hac hz, sectionAbove_antitone K hbc hz⟩⟩
    have hK : ∀ Q ∈ F, CompactSaturated Q := by
      rintro _ ⟨a, _, rfl⟩
      exact ⟨hComp a, fun x y hx hxy ↦ ⟨le_trans hx.1 hxy, hSat hx.2 hxy⟩⟩
    have hFsub : ⋂₀ F ⊆ U := by
      intro x hx
      apply hs
      constructor
      · exact hSup.2 _ (fun a ha ↦ (Set.mem_sInter.mp hx _ ⟨a, ha, rfl⟩).1)
      · obtain ⟨a, ha⟩ := hE.1
        exact (Set.mem_sInter.mp hx _ ⟨a, ha, rfl⟩).2
    obtain ⟨_, ⟨a, ha, rfl⟩, haU⟩ := hWF F hF hK U hU hFsub
    exact hOutside ha haU

private theorem compact_inter_of_compactSections (hWF : ScottWellFiltered D)
    {K L : Set D} (hK : Saturated K) (hL : CompactSaturated L)
    (hComp : ∀ x, ScottCompact (sectionAbove K x)) : ScottCompact (K ∩ L) := by
  apply (scottCompact_iff_directedOpenCover _).2
  intro A hOpen hA hCover
  let pull (U : Set D) := {x | sectionAbove K x ⊆ U}
  let F := pull '' A
  have hF : DirectedSet F := DirectedSet.image (fun _ _ h ↦ fun _ hx ↦ hx.trans h) hA
  have hLsub : L ⊆ ⋃₀ F := by
    intro x hx
    have hSection : sectionAbove K x ⊆ ⋃₀ A :=
      fun _ hy ↦ hCover ⟨hy.2, hL.2 hx hy.1⟩
    obtain ⟨U, hUA, hxU⟩ :=
      (scottCompact_iff_directedOpenCover _).1 (hComp x) A hOpen hA hSection
    exact Set.mem_sUnion_of_mem (show x ∈ pull U from hxU) ⟨U, hUA, rfl⟩
  obtain ⟨_, ⟨U, hUA, rfl⟩, hLU⟩ := (scottCompact_iff_directedOpenCover L).1
    hL.1 F (by rintro _ ⟨U, hUA, rfl⟩; exact sectionCover_scottOpen hWF hK hComp (hOpen U hUA))
    hF hLsub
  exact ⟨U, hUA, fun _ hx ↦ hLU hx.2 ⟨le_rfl, hx.1⟩⟩

/-- Jia–Jung–Li (2016), Lemma 3.1, at its original well-filtered
generality. Two passes of the compact-section argument suffice. -/
theorem jiaJungLi_3_1 (hWF : ScottWellFiltered D) :
    IsCoherent D ↔ ∀ x y : D, ScottCompact
      (Chapter2.upperClosure ({x} : Set D) ∩ Chapter2.upperClosure ({y} : Set D)) := by
  constructor
  · intro h x y
    exact (h _ _ (principalUpper_compactSaturated x) (principalUpper_compactSaturated y)).1
  · intro h K L hK hL
    refine ⟨compact_inter_of_compactSections hWF hK.2 hL ?_, saturated_inter hK.2 hL.2⟩
    intro x
    rw [sectionAbove, ← principalUpper_eq_Ici]
    exact compact_inter_of_compactSections hWF (principalUpper_compactSaturated x).2 hK
      (fun a ↦ by simpa [sectionAbove, ← principalUpper_eq_Ici] using h a x)

/-- The current manuscript's continuous specialization of Lemma 3.1. -/
theorem lem_continuous_coherence_criterion (hD : IsDcpo D)
    (hCont : Chapter3.IsContinuousDomain D) :
    IsCoherent D ↔ ∀ x y : D, ScottCompact
      (Chapter2.upperClosure ({x} : Set D) ∩ Chapter2.upperClosure ({y} : Set D)) :=
  jiaJungLi_3_1 (ScottWellFiltered.of_continuous hD hCont)

/-! ## The five equivalent conditions of Theorem 3.4 -/

def IsFinitelyGeneratedUpper (D : Type u) [PartialOrder D] : Prop :=
  ∃ M : Set D, M.Finite ∧ Chapter2.upperClosure M = Set.univ

private theorem isCompact_scott_univ (hK : IsScottCompactSpace D) :
    @IsCompact D Chapter2.scottTopologicalSpace Set.univ := by
  classical
  letI : TopologicalSpace D := Chapter2.scottTopologicalSpace
  apply isCompact_of_finite_subcover
  intro I U hOpen hU
  obtain ⟨F, hF, hFin, hCover⟩ := hK (Set.range U) (by
    rintro _ ⟨i, rfl⟩
    exact hOpen i) (by
    intro x hx
    obtain ⟨i, hxi⟩ := Set.mem_iUnion.mp (hU hx)
    exact Set.mem_sUnion_of_mem hxi ⟨i, rfl⟩)
  let pick (V : F) : I := Classical.choose (hF V.2)
  letI : Fintype F := hFin.fintype
  refine ⟨Finset.univ.image pick, ?_⟩
  intro x hx
  obtain ⟨V, hVF, hxV⟩ := Set.mem_sUnion.mp (hCover hx)
  let v : F := ⟨V, hVF⟩
  have hv : U (pick v) = V := Classical.choose_spec (hF hVF)
  exact Set.mem_iUnion_of_mem (pick v) (Set.mem_iUnion_of_mem
    (Finset.mem_image.mpr ⟨v, Finset.mem_univ _, rfl⟩) (hv ▸ hxV))

private theorem exists_min_le_of_scottCompact (hD : IsScottCompactSpace D) (x : D) :
    ∃ m : D, IsMin m ∧ m ≤ x := by
  classical
  letI : TopologicalSpace D := Chapter2.scottTopologicalSpace
  have hCompact := isCompact_scott_univ hD
  let C₀ : Set Dᵒᵈ := Set.Ici (OrderDual.toDual x)
  obtain ⟨m, hm⟩ := zorn_le₀ C₀ (by
    intro C hC hChain
    by_cases hNe : C.Nonempty
    · letI : Nonempty C := hNe.to_subtype
      let K (a : C) : Set D := Chapter2.lowerClosure ({OrderDual.ofDual a.1} : Set D)
      have hClosed (a : C) : IsClosed (K a) := by
        constructor
        change ScottOpen (K a)ᶜ
        simpa only [K, ScottOpen, compl_compl] using
          scottClosed_principal_ideal (OrderDual.ofDual a.1)
      have hKCompact (a : C) : IsCompact (K a) :=
        hCompact.of_isClosed_subset (hClosed a) (Set.subset_univ _)
      have hKNonempty (a : C) : (K a).Nonempty :=
        ⟨OrderDual.ofDual a.1, OrderDual.ofDual a.1, by simp, le_rfl⟩
      have hMono {a b : C} (h : a.1 ≤ b.1) : K b ⊆ K a := by
        rintro z ⟨y, hy, hzy⟩
        have heq : y = OrderDual.ofDual b.1 := by simpa using hy
        have hzb : z ≤ OrderDual.ofDual b.1 := by rwa [← heq]
        exact ⟨OrderDual.ofDual a.1, by simp,
          le_trans hzb (show OrderDual.ofDual b.1 ≤ OrderDual.ofDual a.1 from h)⟩
      have hDir : Directed (· ⊇ ·) K := by
        intro a b
        rcases hChain.total a.2 b.2 with h | h
        · exact ⟨b, hMono h, Set.Subset.rfl⟩
        · exact ⟨a, Set.Subset.rfl, hMono h⟩
      obtain ⟨z, hz⟩ := IsCompact.nonempty_iInter_of_directed_nonempty_isCompact_isClosed
        K hDir hKNonempty hKCompact hClosed
      have hLower : ∀ a ∈ C, z ≤ OrderDual.ofDual a := by
        intro a ha
        obtain ⟨q, hq, hzq⟩ := Set.mem_iInter.mp hz ⟨a, ha⟩
        have heq : q = OrderDual.ofDual a := by simpa using hq
        exact heq ▸ hzq
      obtain ⟨a, ha⟩ := hNe
      exact ⟨OrderDual.toDual z,
        show z ≤ x from le_trans (hLower a ha) (hC ha), hLower⟩
    · refine ⟨OrderDual.toDual x, le_rfl, ?_⟩
      exact fun a ha ↦ False.elim (hNe ⟨a, ha⟩))
  refine ⟨OrderDual.ofDual m, ?_, hm.1⟩
  intro y hy
  exact hm.2 (show OrderDual.toDual y ∈ C₀ from le_trans hy (show OrderDual.ofDual m ≤ x from hm.1)) hy

private theorem scottClosed_of_subset_minimal {S : Set D}
    (hS : ∀ x ∈ S, IsMin x) : ScottClosed S := by
  constructor
  · intro x y hy hxy
    exact (le_antisymm hxy (hS y hy hxy)) ▸ hy
  · intro E s hE hSub hs
    obtain ⟨a, ha⟩ := hE.1
    have hUpper : IsUpperBound E a := by
      intro b hb
      obtain ⟨c, hc, hac, hbc⟩ := hE.2 ha hb
      exact le_trans hbc (hS c (hSub hc) hac)
    have heq := le_antisymm (hs.1 ha) (hs.2 a hUpper)
    exact heq ▸ hSub ha

theorem scottCompact_iff_finitelyGeneratedUpper :
    IsScottCompactSpace D ↔ IsFinitelyGeneratedUpper D := by
  classical
  constructor
  · intro hD
    let M : Set D := {x | IsMin x}
    have hGen : Chapter2.upperClosure M = Set.univ := by
      apply Set.eq_univ_of_forall
      intro x
      exact exists_min_le_of_scottCompact hD x
    refine ⟨M, ?_, hGen⟩
    by_cases hNe : M.Nonempty
    · letI : TopologicalSpace D := Chapter2.scottTopologicalSpace
      let U (m : M) : Set D := (M \ {m.1})ᶜ
      have hOpen (m : M) : IsOpen (U m) := by
        change ScottOpen (U m)
        simpa [U, ScottOpen] using (scottClosed_of_subset_minimal
          (S := M \ {m.1}) (fun a h ↦ h.1))
      have hCover : (Set.univ : Set D) ⊆ ⋃ m : M, U m := by
        intro x _
        by_cases hx : x ∈ M
        · exact Set.mem_iUnion_of_mem (⟨x, hx⟩ : M) (by simp [U])
        · let m : M := ⟨Classical.choose hNe, Classical.choose_spec hNe⟩
          exact Set.mem_iUnion_of_mem m (fun h ↦ hx h.1)
      obtain ⟨T, hT⟩ := (isCompact_scott_univ hD).elim_finite_subcover U hOpen hCover
      apply (T.finite_toSet.image (fun m : M ↦ m.1)).subset
      intro m hm
      obtain ⟨a, ha⟩ := Set.mem_iUnion.mp (hT (Set.mem_univ m))
      obtain ⟨haT, hma⟩ := Set.mem_iUnion.mp ha
      have hEq : m = a.1 := by
        by_contra h
        exact hma ⟨hm, h⟩
      exact ⟨a, haT, hEq.symm⟩
    · rw [Set.not_nonempty_iff_eq_empty.mp hNe]
      exact Set.finite_empty
  · rintro ⟨M, hM, hGen⟩
    change ScottCompact (Set.univ : Set D)
    rw [← hGen]
    exact (Chapter4.finiteUpperClosure_isCompactSaturated (asOrderedDomain D) hM).1

def scottPatchSubbasis (D : Type u) [PartialOrder D] : Set (Set D) :=
  {U | ScottOpen U} ∪ {U | ∃ K : Set D, CompactSaturated K ∧ U = Kᶜ}

@[reducible] def scottPatchTopology (D : Type u) [PartialOrder D] : TopologicalSpace D :=
  TopologicalSpace.generateFrom (scottPatchSubbasis D)

def IsScottPatchCompact (D : Type u) [PartialOrder D] : Prop :=
  @IsCompact D (scottPatchTopology D) Set.univ

private theorem patchCompact_of_scottCompact_coherent (hWF : ScottWellFiltered D)
    (hScott : IsScottCompactSpace D) (hC : IsCoherent D) : IsScottPatchCompact D := by
  letI : TopologicalSpace D := scottPatchTopology D
  change IsCompact (Set.univ : Set D)
  apply isCompact_generateFrom (show scottPatchTopology D =
    TopologicalSpace.generateFrom (scottPatchSubbasis D) from rfl)
  intro P hP hCover
  let S : Set (Set D) := {U ∈ P | ScottOpen U}
  let O := ⋃₀ S
  let T : Set (Set D) := {K | CompactSaturated K ∧ Kᶜ ∈ P}
  let F : Set (Set D) := {K | ∃ G : Set (Set D), G.Finite ∧ G ⊆ T ∧ K = ⋂₀ G}
  have hOpen : ScottOpen O :=
    (Chapter7.ScottTopologySpace D).sUnion_open S (fun _ h ↦ h.2)
  have hFin (G : Set (Set D)) (hG : G.Finite) (hSub : G ⊆ T) :
      CompactSaturated (⋂₀ G) := by
    induction G, hG using Set.Finite.induction_on with
    | empty => simpa using (show CompactSaturated (Set.univ : Set D)
        from ⟨hScott, fun _ _ _ _ ↦ Set.mem_univ _⟩)
    | @insert U G _ _ ih =>
      rw [Set.sInter_insert]
      exact hC _ _ (hSub (Set.mem_insert _ _)).1
        (ih (fun _ h ↦ hSub (Set.mem_insert_of_mem _ h)))
  have hF : Chapter7.IsFilteredFamily F := by
    constructor
    · exact ⟨⋂₀ (∅ : Set (Set D)), ∅, Set.finite_empty, Set.empty_subset _, rfl⟩
    · rintro _ ⟨G, hG, hGS, rfl⟩ _ ⟨H, hH, hHS, rfl⟩
      exact ⟨⋂₀ (G ∪ H), ⟨G ∪ H, hG.union hH, Set.union_subset hGS hHS, rfl⟩,
        fun _ hx ↦ ⟨Set.sInter_mono Set.subset_union_left hx,
          Set.sInter_mono Set.subset_union_right hx⟩⟩
  have hFcov : ⋂₀ F ⊆ O := by
    intro x hx
    obtain ⟨U, hU, hxU⟩ := Set.mem_sUnion.mp (hCover (Set.mem_univ x))
    rcases hP hU with hUs | ⟨K, hK, rfl⟩
    · exact Set.mem_sUnion_of_mem hxU ⟨hU, hUs⟩
    · have hKF : (⋂₀ ({K} : Set (Set D))) ∈ F :=
        ⟨{K}, Set.finite_singleton _, Set.singleton_subset_iff.2 ⟨hK, hU⟩, rfl⟩
      have hMem : x ∈ ⋂₀ ({K} : Set (Set D)) := Set.mem_sInter.mp hx _ hKF
      exact False.elim (hxU (by simpa using hMem))
  have hAll : ∀ Q ∈ F, CompactSaturated Q := by
    rintro Q ⟨G, hG, hGT, hEq⟩
    rw [hEq]
    exact hFin G hG hGT
  obtain ⟨_, ⟨G, hG, hGT, rfl⟩, hGO⟩ := hWF F hF hAll O hOpen hFcov
  obtain ⟨C, hCS, hC, hCcov⟩ := (hFin G hG hGT).1 S (fun _ h ↦ h.2) hGO
  refine ⟨C ∪ ((fun K : Set D ↦ Kᶜ) '' G), ?_, hC.union (hG.image _), ?_⟩
  · rintro U (hU | ⟨K, hK, rfl⟩)
    · exact (hCS hU).1
    · exact (hGT hK).2
  · intro x _
    by_cases hx : x ∈ ⋂₀ G
    · obtain ⟨U, hU, hxU⟩ := Set.mem_sUnion.mp (hCcov hx)
      exact Set.mem_sUnion_of_mem hxU (Or.inl hU)
    · obtain ⟨K, hK, hxK⟩ : ∃ K ∈ G, x ∉ K := by
        by_contra h
        apply hx
        intro K hK
        by_contra hn
        exact h ⟨K, hK, hn⟩
      exact Set.mem_sUnion_of_mem hxK (Or.inr ⟨K, hK, rfl⟩)

private theorem lawsonCompact_of_patchCompact (hP : IsScottPatchCompact D) :
    Chapter4.IsLawsonCompact (asOrderedDomain D) := by
  letI : TopologicalSpace D := scottPatchTopology D
  have hCont : @Continuous D D (scottPatchTopology D) (lawsonGeneratedTopologicalSpace D)
      (id : D → D) := by
    apply continuous_generateFrom_iff.2
    intro U hU
    change TopologicalSpace.GenerateOpen (scottPatchSubbasis D) U
    apply TopologicalSpace.GenerateOpen.basic
    rcases hU with h | ⟨x, rfl⟩
    · exact Or.inl h
    · exact Or.inr ⟨_, principalUpper_compactSaturated (show D from x), rfl⟩
  exact (lawsonCompact_iff_isCompact_univ (D := D)).2
    (by
      have hImage := @IsCompact.image D D (scottPatchTopology D)
        (lawsonGeneratedTopologicalSpace D) Set.univ id hP hCont
      simpa only [Set.image_id] using hImage)

/-- Jia–Jung–Li (2016), Theorem 3.4. Each displayed condition is equivalent
to Lawson compactness. Finite generation means upward closure of a finite
subset, not finite generation of the compact-element MUB closure. -/
theorem jiaJungLi_3_4 (_hD : IsDcpo D) (hWF : ScottWellFiltered D) :
    (Chapter4.IsLawsonCompact (asOrderedDomain D) ↔ IsScottPatchCompact D) ∧
    (Chapter4.IsLawsonCompact (asOrderedDomain D) ↔ IsScottCompactSpace D ∧
      ∀ x y : D, ScottCompact
        (Chapter2.upperClosure ({x} : Set D) ∩ Chapter2.upperClosure ({y} : Set D))) ∧
    (Chapter4.IsLawsonCompact (asOrderedDomain D) ↔ IsFinitelyGeneratedUpper D ∧
      ∀ x y : D, ScottCompact
        (Chapter2.upperClosure ({x} : Set D) ∩ Chapter2.upperClosure ({y} : Set D))) ∧
    (Chapter4.IsLawsonCompact (asOrderedDomain D) ↔ IsFinitelyGeneratedUpper D ∧ IsCoherent D) := by
  have hC := jiaJungLi_3_1 hWF
  have hLawson (hL : Chapter4.IsLawsonCompact (asOrderedDomain D)) :
      IsScottCompactSpace D ∧ IsCoherent D :=
    ⟨scottCompact_of_lawsonCompact_internal hL,
      hC.2 (principalUpper_inter_scottCompact_of_lawsonCompact_internal hL)⟩
  have hP (hK : IsScottCompactSpace D ∧ IsCoherent D) : IsScottPatchCompact D :=
    patchCompact_of_scottCompact_coherent hWF hK.1 hK.2
  have hLC : Chapter4.IsLawsonCompact (asOrderedDomain D) ↔
      IsScottCompactSpace D ∧ IsCoherent D :=
    ⟨hLawson, fun h ↦ lawsonCompact_of_patchCompact (hP h)⟩
  have hFin := scottCompact_iff_finitelyGeneratedUpper (D := D)
  exact ⟨⟨fun h ↦ hP (hLawson h), lawsonCompact_of_patchCompact⟩,
    hLC.trans (and_congr Iff.rfl hC), hLC.trans (and_congr hFin hC),
    hLC.trans (and_congr hFin Iff.rfl)⟩

end CoherentContinuousAlgebraicRetracts
