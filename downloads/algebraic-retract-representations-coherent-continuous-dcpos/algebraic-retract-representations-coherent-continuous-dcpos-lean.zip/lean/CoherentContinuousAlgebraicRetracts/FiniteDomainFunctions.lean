import Mathlib.Topology.Order
import CoherentContinuousAlgebraicRetracts.FunctionSpaceCore
import CoherentContinuousAlgebraicRetracts.KernelApproximations
import CoherentContinuousAlgebraicRetracts.OpenSubdcpo

/-!
# Scott-continuous maps out of a finite poset

Compact monotone approximations are constructed in the strict order of the
finite source. For Lawson compactness we use the closed monotone subspace of
the finite product of Lawson codomains.
-/

set_option autoImplicit false
set_option linter.unnecessarySimpa false
set_option maxHeartbeats 1800000

universe u

namespace CoherentContinuousAlgebraicRetracts
namespace FiniteDomain

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

variable {P A : Type u} [PartialOrder P] [PartialOrder A] [Finite P]

/-- Simultaneously approximate finite sets of compact observations at all
source points, respecting the monotonicity constraints of lower points. -/
theorem exists_compactMonotone (hA : Chapter3.IsAlgebraicDomain A)
    (f : FunctionSpace P A) (H : P → Set (CompactBasis A))
    (hFin : ∀ p, (H p).Finite) (hH : ∀ p, ∀ a ∈ H p, a.1 ≤ f p) :
    ∃ g : FunctionSpace P A, (∀ p, Compact (g p)) ∧ g ≤ f ∧
      ∀ p, ∀ a ∈ H p, a.1 ≤ g p := by
  classical
  let C (p : P) := {a : CompactBasis A // a.1 ≤ f p}
  let below := fun (p : P) (r : ∀ q : P, q < p → C q) ↦
    H p ∪ Set.range (fun q : Set.Iio p ↦ (r q.1 q.2).1)
  have hExist (p : P) (r : ∀ q : P, q < p → C q) :
      ∃ a : CompactBasis A, a.1 ≤ f p ∧ a ∈ Chapter2.upperBounds (below p r) := by
    apply exists_compact_upper_le hA ((hFin p).union (Set.finite_range _))
    intro b hb
    rcases hb with hB | ⟨q, rfl⟩
    · exact hH p b hB
    · exact le_trans (r q.1 q.2).2 (f.toContFun.continuous.1 (le_of_lt q.2))
  let step (p : P) (r : ∀ q : P, q < p → C q) : C p :=
    ⟨Classical.choose (hExist p r), (Classical.choose_spec (hExist p r)).1⟩
  let wf : WellFounded ((· < ·) : P → P → Prop) := Finite.wellFounded_of_trans_of_irrefl _
  let c : (p : P) → C p := wf.fix step
  have hStep (p : P) :
      (c p).1 ∈ Chapter2.upperBounds (below p (fun q _ ↦ c q)) := by
    have heq : c p = step p (fun q _ ↦ c q) := wf.fix_eq step p
    rw [heq]
    exact (Classical.choose_spec (hExist p (fun q _ ↦ c q))).2
  have hMono : Monotone (fun p ↦ (c p).1.1) := by
    intro p q hpq
    rcases eq_or_lt_of_le hpq with rfl | hpq
    · exact le_rfl
    · exact hStep q (Or.inr ⟨⟨p, hpq⟩, rfl⟩)
  let g : FunctionSpace P A :=
    ⟨⟨fun p ↦ (c p).1.1, monotone_scottContinuous_of_finite hMono⟩⟩
  exact ⟨g, fun p ↦ (c p).1.2, fun p ↦ (c p).2,
    fun p _ ha ↦ hStep p (Or.inl ha)⟩

theorem compact_of_compactValues (hA : IsDcpo A) {f : FunctionSpace P A}
    (hf : ∀ p, Compact (f p)) : Compact f := by
  intro G s hG hs hfs
  have hw (p : P) : ∃ g ∈ G, f p ≤ g p := by
    have hDir : DirectedSet ((fun g : FunctionSpace P A ↦ g p) '' G) :=
      DirectedSet.image (fun g j h ↦ (show g ≤ j from h) p) hG
    obtain ⟨_, ⟨g, hg, rfl⟩, hfpg⟩ :=
      hf p hDir (FunctionSpace.isSup_apply hA hG hs p) (hfs p)
    exact ⟨g, hg, hfpg⟩
  let pick (p : P) := Classical.choose (hw p)
  have hsub : Set.range pick ⊆ G := by
    rintro _ ⟨p, rfl⟩
    exact (Classical.choose_spec (hw p)).1
  obtain ⟨g, hg, hUpper⟩ := hG.exists_upper_finite (Set.finite_range pick) hsub
  exact ⟨g, hg, fun p ↦ le_trans (Classical.choose_spec (hw p)).2
    (hUpper (pick p) ⟨p, rfl⟩ p)⟩

def compactValueApproximants (f : FunctionSpace P A) : Set (FunctionSpace P A) :=
  {g | (∀ p, Compact (g p)) ∧ g ≤ f}

theorem compactValueApproximants_directed (hAlg : Chapter3.IsAlgebraicDomain A)
    (f : FunctionSpace P A) : DirectedSet (compactValueApproximants f) := by
  constructor
  · obtain ⟨g, hg, hgf, _⟩ := exists_compactMonotone hAlg f
      (fun _ ↦ ∅) (fun _ ↦ Set.finite_empty) (by simp)
    exact ⟨g, hg, hgf⟩
  · intro g hg h hh
    let H (p : P) : Set (CompactBasis A) := {⟨g p, hg.1 p⟩, ⟨h p, hh.1 p⟩}
    obtain ⟨w, hw, hwf, hBound⟩ := exists_compactMonotone hAlg f H (by simp [H]) (by
      intro p a ha
      rcases Set.mem_insert_iff.mp ha with rfl | ha
      · exact hg.2 p
      · have haEq : a = ⟨h p, hh.1 p⟩ := by simpa using ha
        rw [haEq]
        exact hh.2 p)
    exact ⟨w, ⟨hw, hwf⟩, fun p ↦ hBound p ⟨g p, hg.1 p⟩ (by simp [H]),
      fun p ↦ hBound p ⟨h p, hh.1 p⟩ (by simp [H])⟩

theorem compactValueApproximants_isSup (hAlg : Chapter3.IsAlgebraicDomain A)
    (f : FunctionSpace P A) : IsSup (compactValueApproximants f) f := by
  classical
  refine ⟨fun _ hg ↦ hg.2, ?_⟩
  intro q hq p
  apply (hAlg (f p)).2.2 (q p)
  intro a ha
  let b : CompactBasis A := ⟨a, ha.1⟩
  let H (z : P) : Set (CompactBasis A) := if z = p then {b} else ∅
  obtain ⟨g, hg, hgf, hBound⟩ := exists_compactMonotone hAlg f H (by
    intro z
    by_cases hz : z = p <;> simp [H, hz]) (by
    intro z c hc
    by_cases hz : z = p
    · subst z
      have hcEq : c = b := by simpa [H] using hc
      rw [hcEq]
      exact prop_2_2_2_1 ha.2
    · simp [H, hz] at hc)
  exact le_trans (hBound p b (by simp [H])) (hq ⟨hg, hgf⟩ p)

theorem functionSpace_algebraic (hA : IsDcpo A) (hAlg : Chapter3.IsAlgebraicDomain A) :
    Chapter3.IsAlgebraicDomain (FunctionSpace P A) := by
  apply prop_2_2_4_1
  intro f
  refine ⟨compactValueApproximants f, ?_,
    compactValueApproximants_directed hAlg f, compactValueApproximants_isSup hAlg f⟩
  intro g hg
  have hG := compact_of_compactValues hA hg.1
  exact ⟨hG, prop_2_2_2_2 le_rfl hG hg.2⟩

private theorem exists_compact_separation (hA : Chapter3.IsAlgebraicDomain A)
    {x y : A} (hxy : ¬ x ≤ y) : ∃ k : CompactBasis A, k.1 ≤ x ∧ ¬ k.1 ≤ y := by
  classical
  by_contra h
  apply hxy
  apply (hA x).2.2 y
  intro k hk
  by_contra hn
  exact h ⟨⟨k, hk.1⟩, prop_2_2_2_1 hk.2, hn⟩

/-- With an algebraic Lawson-compact codomain, the function space out of a
finite poset is Lawson compact and algebraic. -/
def lawsonAlgebraic (hA : LawsonAlgebraic A) : LawsonAlgebraic (FunctionSpace P A) := by
  refine ⟨FunctionSpace.isDcpo_of_codomain hA.dcpo,
    functionSpace_algebraic hA.dcpo hA.algebraic, ?_⟩
  classical
  letI : TopologicalSpace A := lawsonGeneratedTopologicalSpace A
  letI : CompactSpace A := ⟨(lawsonCompact_iff_isCompact_univ (D := A)).1 hA.lawsonCompact⟩
  let M : Set (P → A) := {f | Monotone f}
  have hM : IsClosed M := by
    constructor
    apply isOpen_iff_mem_nhds.2
    intro f hf
    have hf' : ¬ Monotone f := hf
    have hWitness : ∃ p q : P, p ≤ q ∧ ¬ f p ≤ f q := by
      by_contra h
      apply hf'
      intro p q hpq
      by_contra hbad
      exact h ⟨p, q, hpq, hbad⟩
    obtain ⟨p, q, hpq, hbad⟩ := hWitness
    obtain ⟨k, hk, hkn⟩ := exists_compact_separation hA.algebraic hbad
    let U := compactPrincipalUpper A k
    have hUo : IsOpen U := isOpen_lawson_of_scottOpen
      (compactPrincipalUpper_scottOpen A (basis_to_raw hA.algebraic) k)
    have hUc : IsClosed U := isClosed_lawson_principalUpper k.1
    let V : Set (P → A) :=
      (fun g : P → A ↦ g p) ⁻¹' U ∩ (fun g : P → A ↦ g q) ⁻¹' Uᶜ
    have hVo : IsOpen V := (hUo.preimage (continuous_apply p)).inter
      (hUc.isOpen_compl.preimage (continuous_apply q))
    have hFv : f ∈ V := ⟨⟨k.1, by simp, hk⟩, by
      rintro ⟨x, hx, hxf⟩
      have heq : x = k.1 := by simpa using hx
      exact hkn (heq ▸ hxf)⟩
    refine Filter.mem_of_superset (hVo.mem_nhds hFv) ?_
    rintro g ⟨hp, hq⟩ hMon
    exact hq (Chapter2.isUpperSet_upperClosure _ hp (hMon hpq))
  letI : CompactSpace M := isCompact_iff_compactSpace.1 hM.isCompact
  let toFS : M → FunctionSpace P A := fun f ↦
    ⟨⟨f.1, monotone_scottContinuous_of_finite f.2⟩⟩
  letI : TopologicalSpace (FunctionSpace P A) :=
    lawsonGeneratedTopologicalSpace (FunctionSpace P A)
  have hEval (p : P) : Continuous (fun f : M ↦ f.1 p) :=
    (continuous_apply p).comp continuous_subtype_val
  have hCont : Continuous toFS := by
    apply continuous_generateFrom_iff.2
    intro O hO
    rcases hO with hScott | ⟨f, rfl⟩
    · let U : Set (FunctionSpace P A) := O
      have hU : ScottOpen U := hScott
      change IsOpen (toFS ⁻¹' U)
      apply isOpen_iff_mem_nhds.2
      intro x hx
      obtain ⟨g, hg, hgO⟩ := scottOpen_meets_directed hU
        (compactValueApproximants_directed hA.algebraic (toFS x))
        (compactValueApproximants_isSup hA.algebraic (toFS x)) hx
      let V : Set M := ⋂ p, (fun f : M ↦ f.1 p) ⁻¹'
        compactPrincipalUpper A ⟨g p, hg.1 p⟩
      have hVo : IsOpen V := isOpen_iInter_of_finite fun p ↦
        (isOpen_lawson_of_scottOpen (compactPrincipalUpper_scottOpen
          A (basis_to_raw hA.algebraic) ⟨g p, hg.1 p⟩)).preimage (hEval p)
      have hxV : x ∈ V := Set.mem_iInter.2 fun p ↦ ⟨g p, by simp, hg.2 p⟩
      refine Filter.mem_of_superset (hVo.mem_nhds hxV) ?_
      intro y hy
      apply scottOpen_upper hU hgO
      intro p
      obtain ⟨a, ha, hay⟩ := Set.mem_iInter.1 hy p
      have heq : a = g p := by simpa using ha
      exact heq ▸ hay
    · let g : FunctionSpace P A := f
      change IsOpen (toFS ⁻¹' (Chapter2.upperClosure ({g} : Set (FunctionSpace P A)))ᶜ)
      let U (p : P) : Set M := (fun h : M ↦ h.1 p) ⁻¹'
        (Chapter2.upperClosure ({g p} : Set A))ᶜ
      have hUp (p : P) : IsOpen (U p) := by
        have hC : IsClosed (Chapter2.upperClosure ({g p} : Set A)) :=
          isClosed_lawson_principalUpper (g p)
        exact hC.isOpen_compl.preimage (hEval p)
      have hEq : toFS ⁻¹' (Chapter2.upperClosure ({g} : Set (FunctionSpace P A)))ᶜ =
          ⋃ p, U p := by
        ext h
        change (¬ ∃ a ∈ ({g} : Set (FunctionSpace P A)), a ≤ toFS h) ↔ _
        have h₁ : (∃ a ∈ ({g} : Set (FunctionSpace P A)), a ≤ toFS h) ↔
            ∀ p, g p ≤ h.1 p := by simp [toFS]; rfl
        rw [h₁, not_forall]
        simp [U, Chapter2.upperClosure]
      rw [hEq]
      exact isOpen_iUnion hUp
  have hSurj : Function.Surjective toFS := by
    intro f
    exact ⟨⟨fun p ↦ f p, f.toContFun.continuous.1⟩, FunctionSpace.ext (fun _ ↦ rfl)⟩
  have hCompact := isCompact_univ.image hCont
  rw [Set.image_univ, hSurj.range_eq] at hCompact
  exact (lawsonCompact_iff_isCompact_univ (D := FunctionSpace P A)).2 hCompact

end FiniteDomain
end CoherentContinuousAlgebraicRetracts
