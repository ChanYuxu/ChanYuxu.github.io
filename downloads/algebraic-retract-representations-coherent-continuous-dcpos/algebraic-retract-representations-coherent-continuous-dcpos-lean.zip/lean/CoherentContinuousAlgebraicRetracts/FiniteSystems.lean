import CoherentContinuousAlgebraicRetracts.FiniteCommonApproximations
import Mathlib.Data.Finset.Sort

/-!
# Finite systems indexed by nonempty subsets

This file formalizes the finite-system poset of
`def:approximating-poset` in source SHA-256
`e6af94a9b81f5546fd03a5553bcb16f8958f9daa62bbba1dc6d1984a74f6ac6a`.

The source describes restriction to an increasing enumeration of a nonempty
subset of `[n]`.  Equivalently, a restriction is pullback along a strictly
increasing embedding `Fin k ↪o Fin n`; this representation makes composition
of restrictions definitionally explicit.
-/

set_option autoImplicit false
set_option maxHeartbeats 800000

universe u

namespace CoherentContinuousAlgebraicRetracts

noncomputable section

namespace FiniteSystems

variable {T : Type u}

local instance : DecidableEq T := Classical.decEq _

/-- The labels immediately below a component indexed by `J`. -/
def children {n : ℕ}
    (label : Finset (Fin n) → T) (J : Finset (Fin n)) : Finset T :=
  J.attach.image (fun j ↦ label (J.erase j.1))

/-- A finite system with one label for every subset of `Fin n`.

The empty-subset label is unused.  Retaining it in the total function avoids
partial-function bureaucracy; every mathematical statement below is restricted
to nonempty subsets, exactly as in the source. -/
structure System (Φ : Finset T → Finset T) where
  arity : ℕ
  positive : 0 < arity
  label : Finset (Fin arity) → T
  empty_normalized :
    label ∅ = label {⟨0, positive⟩}
  valid : ∀ J : Finset (Fin arity), 2 ≤ J.card →
    label J ∈ Φ (children label J)

namespace System

variable {Φ : Finset T → Finset T}

@[ext (iff := false)]
theorem ext {p q : System Φ}
    (hArity : p.arity = q.arity)
    (hLabel : HEq p.label q.label) :
    p = q := by
  cases p
  cases q
  cases hArity
  cases hLabel
  rfl

/-- Extensionality with labels transported along equality of arities. -/
theorem ext_cast {p q : System Φ}
    (hArity : p.arity = q.arity)
    (hLabel : ∀ J : Finset (Fin p.arity),
      p.label J = q.label
        (J.map (Fin.castOrderIso hArity).toEmbedding)) :
    p = q := by
  cases p with
  | mk pn hp pl pe pv =>
    cases q with
    | mk qn hq ql qe qv =>
      dsimp at hArity
      subst qn
      have hLabels : pl = ql := by
        funext J
        have hMap :
            J.map (Fin.castOrderIso (Eq.refl pn)).toEmbedding = J := by
          ext x
          constructor
          · intro hx
            rcases Finset.mem_map.mp hx with ⟨y, hy, hxy⟩
            have : x = y := by simpa using hxy.symm
            simpa [this] using hy
          · intro hx
            exact Finset.mem_map.mpr ⟨x, hx, by simp⟩
        simpa only [hMap] using hLabel J
      subst ql
      rfl

/-- Relabel a subset along an embedding of finite index sets. -/
def mapSubset {n m : ℕ} (f : Fin n ↪ Fin m)
    (J : Finset (Fin n)) : Finset (Fin m) :=
  J.map f

@[simp]
theorem mapSubset_card {n m : ℕ} (f : Fin n ↪ Fin m)
    (J : Finset (Fin n)) :
    (mapSubset f J).card = J.card := by
  simp [mapSubset]

@[simp]
theorem mapSubset_erase {n m : ℕ} (f : Fin n ↪ Fin m)
    (J : Finset (Fin n)) (j : Fin n) :
    mapSubset f (J.erase j) = (mapSubset f J).erase (f j) := by
  exact Finset.map_erase f J j

private def idOrderEmb (n : ℕ) : Fin n ↪o Fin n :=
  OrderEmbedding.ofStrictMono (fun x : Fin n ↦ x) (fun _ _ h ↦ h)

@[simp]
theorem mapSubset_id {n : ℕ} (J : Finset (Fin n)) :
    mapSubset (idOrderEmb n).toEmbedding J = J := by
  classical
  ext x
  constructor
  · intro hx
    rcases Finset.mem_map.mp hx with ⟨y, hy, hxy⟩
    have : x = y := by simpa [idOrderEmb] using hxy.symm
    simpa [this] using hy
  · intro hx
    exact Finset.mem_map.mpr ⟨x, hx, by simp [idOrderEmb]⟩

theorem mapSubset_comp {l m n : ℕ}
    (f : Fin l ↪o Fin m) (g : Fin m ↪o Fin n)
    (J : Finset (Fin l)) :
    mapSubset g.toEmbedding (mapSubset f.toEmbedding J) =
      mapSubset (f.trans g).toEmbedding J := by
  classical
  ext z
  constructor
  · intro hz
    rcases Finset.mem_map.mp hz with ⟨y, hy, hgy⟩
    rcases Finset.mem_map.mp hy with ⟨x, hx, hfx⟩
    apply Finset.mem_map.mpr
    refine ⟨x, hx, ?_⟩
    subst y
    exact hgy
  · intro hz
    rcases Finset.mem_map.mp hz with ⟨x, hx, hxz⟩
    apply Finset.mem_map.mpr
    refine ⟨f x, Finset.mem_map.mpr ⟨x, hx, rfl⟩, ?_⟩
    exact hxz

private theorem children_reindex
    (q : System Φ) {n : ℕ} (f : Fin n ↪o Fin q.arity)
    (pulled : Finset (Fin n) → T)
    (hpulled : ∀ K : Finset (Fin n), K.Nonempty →
      pulled K = q.label (mapSubset f.toEmbedding K))
    (J : Finset (Fin n)) (hJ : 2 ≤ J.card) :
    children pulled J =
      children q.label (mapSubset f.toEmbedding J) := by
  classical
  ext e
  constructor
  · intro he
    rcases Finset.mem_image.mp he with ⟨j, hj, rfl⟩
    have hjJ : j.1 ∈ J := j.2
    have hErase : (J.erase j.1).Nonempty := by
      rw [Finset.nonempty_iff_ne_empty]
      intro hEmpty
      have hcardErase : (J.erase j.1).card = 0 := by simp [hEmpty]
      have hcardJ := Finset.card_erase_of_mem hjJ
      omega
    rw [hpulled (J.erase j.1) hErase]
    have hfj : f j.1 ∈ mapSubset f.toEmbedding J := by
      exact Finset.mem_map.mpr ⟨j.1, hjJ, rfl⟩
    apply Finset.mem_image.mpr
    refine ⟨⟨f j.1, hfj⟩, Finset.mem_attach _ _, ?_⟩
    simp only [mapSubset_erase]
    rfl
  · intro he
    rcases Finset.mem_image.mp he with ⟨k, hk, rfl⟩
    rcases Finset.mem_map.mp k.2 with ⟨j, hjJ, hfj⟩
    have hErase : (J.erase j).Nonempty := by
      rw [Finset.nonempty_iff_ne_empty]
      intro hEmpty
      have hcardErase : (J.erase j).card = 0 := by simp [hEmpty]
      have hcardJ := Finset.card_erase_of_mem hjJ
      omega
    apply Finset.mem_image.mpr
    refine ⟨⟨j, hjJ⟩, Finset.mem_attach _ _, ?_⟩
    dsimp
    rw [hpulled (J.erase j) hErase, mapSubset_erase, hfj]

/-- Labels of a restriction.  The empty component is normalized to the first
singleton component; nonempty components are the literal pullback used in the
source. -/
def pulledLabel (q : System Φ) {n : ℕ} (hn : 0 < n)
    (f : Fin n ↪o Fin q.arity) (J : Finset (Fin n)) : T :=
  if hJ : J.Nonempty then
    q.label (mapSubset f.toEmbedding J)
  else
    q.label {f ⟨0, hn⟩}

@[simp]
theorem pulledLabel_of_nonempty (q : System Φ) {n : ℕ} (hn : 0 < n)
    (f : Fin n ↪o Fin q.arity) (J : Finset (Fin n)) (hJ : J.Nonempty) :
    pulledLabel q hn f J = q.label (mapSubset f.toEmbedding J) := by
  simp [pulledLabel, hJ]

@[simp]
theorem pulledLabel_empty (q : System Φ) {n : ℕ} (hn : 0 < n)
    (f : Fin n ↪o Fin q.arity) :
    pulledLabel q hn f ∅ = q.label {f ⟨0, hn⟩} := by
  simp [pulledLabel]

/-- Pull a system back along a strictly increasing embedding.  This is the
source's restriction to a nonempty subset, written through its increasing
enumeration. -/
def reindex (q : System Φ) {n : ℕ} (hn : 0 < n)
    (f : Fin n ↪o Fin q.arity) : System Φ where
  arity := n
  positive := hn
  label J := pulledLabel q hn f J
  empty_normalized := by
    simp [pulledLabel, hn, mapSubset]
  valid J hJ := by
    rw [pulledLabel_of_nonempty _ _ _ _ (Finset.card_pos.mp (by omega))]
    rw [children_reindex q f (pulledLabel q hn f)
      (fun K hK ↦ pulledLabel_of_nonempty q hn f K hK) J hJ]
    exact q.valid (mapSubset f.toEmbedding J) (by simpa using hJ)

@[simp]
theorem reindex_arity (q : System Φ) {n : ℕ} (hn : 0 < n)
    (f : Fin n ↪o Fin q.arity) :
    (q.reindex hn f).arity = n := rfl

@[simp]
theorem reindex_label (q : System Φ) {n : ℕ} (hn : 0 < n)
    (f : Fin n ↪o Fin q.arity) (J : Finset (Fin n)) (hJ : J.Nonempty) :
    (q.reindex hn f).label J = q.label (mapSubset f.toEmbedding J) := by
  exact pulledLabel_of_nonempty q hn f J hJ

@[simp]
theorem reindex_id (q : System Φ) :
    q.reindex q.positive (idOrderEmb q.arity) = q := by
  refine System.ext (p := q.reindex q.positive (idOrderEmb q.arity))
    (q := q) rfl ?_
  apply heq_of_eq
  funext J
  change Finset (Fin q.arity) at J
  by_cases hJ : J.Nonempty
  · change pulledLabel q q.positive (idOrderEmb q.arity) J = q.label J
    rw [pulledLabel_of_nonempty q q.positive (idOrderEmb q.arity) J hJ,
      mapSubset_id]
  · have hEmpty : J = ∅ := Finset.not_nonempty_iff_eq_empty.mp hJ
    subst J
    change pulledLabel q q.positive (idOrderEmb q.arity) ∅ = q.label ∅
    rw [pulledLabel_empty]
    simpa [idOrderEmb] using q.empty_normalized.symm

theorem reindex_reindex
    (q : System Φ) {m n : ℕ} (hm : 0 < m) (hn : 0 < n)
    (f : Fin m ↪o Fin n) (g : Fin n ↪o Fin q.arity) :
    (q.reindex hn g).reindex hm f = q.reindex hm (f.trans g) := by
  refine System.ext
    (p := (q.reindex hn g).reindex hm f)
    (q := q.reindex hm (f.trans g)) rfl ?_
  apply heq_of_eq
  funext J
  change Finset (Fin m) at J
  by_cases hJ : J.Nonempty
  · change pulledLabel (q.reindex hn g) hm f J =
      pulledLabel q hm (f.trans g) J
    rw [pulledLabel_of_nonempty _ _ _ _ hJ,
      pulledLabel_of_nonempty _ _ _ _ hJ]
    have hMapNonempty : (mapSubset f.toEmbedding J).Nonempty :=
      @Finset.Nonempty.map _ _ f.toEmbedding J hJ
    exact (reindex_label q hn g (mapSubset f.toEmbedding J) hMapNonempty).trans
      (congrArg q.label (mapSubset_comp f g J))
  · have hEmpty : J = ∅ := Finset.not_nonempty_iff_eq_empty.mp hJ
    subst J
    change pulledLabel (q.reindex hn g) hm f ∅ =
      pulledLabel q hm (f.trans g) ∅
    rw [pulledLabel_empty, pulledLabel_empty]
    rw [reindex_label]
    · rfl
    · exact ⟨f ⟨0, hm⟩, Finset.mem_singleton_self _⟩

/-- Restriction order: `p ≤ q` when `p` is the pullback of `q` along an
increasing embedding of its index set. -/
def Restricts (p q : System Φ) : Prop :=
  ∃ f : Fin p.arity ↪o Fin q.arity,
    ∀ J : Finset (Fin p.arity),
      J.Nonempty →
      p.label J = q.label (mapSubset f.toEmbedding J)

private theorem orderEmb_self_eq_id {n : ℕ} (f : Fin n ↪o Fin n) :
    f = idOrderEmb n := by
  have hf : f = (Finset.univ : Finset (Fin n)).orderEmbOfFin (by simp) :=
    Finset.orderEmbOfFin_unique' (by simp) (fun _ ↦ Finset.mem_univ _)
  have hid : idOrderEmb n =
      (Finset.univ : Finset (Fin n)).orderEmbOfFin (by simp) :=
    Finset.orderEmbOfFin_unique' (by simp) (fun _ ↦ Finset.mem_univ _)
  exact hf.trans hid.symm

instance : PartialOrder (System Φ) where
  le := Restricts
  le_refl p := by
    refine ⟨idOrderEmb p.arity, ?_⟩
    intro J _hJ
    rw [mapSubset_id]
  le_trans p q r hpq hqr := by
    rcases hpq with ⟨f, hpf⟩
    rcases hqr with ⟨g, hqg⟩
    refine ⟨f.trans g, ?_⟩
    intro J hJ
    have hMapNonempty : (mapSubset f.toEmbedding J).Nonempty :=
      @Finset.Nonempty.map _ _ f.toEmbedding J hJ
    rw [hpf J hJ, hqg (mapSubset f.toEmbedding J) hMapNonempty]
    exact congrArg r.label (mapSubset_comp f g J)
  le_antisymm p q hpq hqp := by
    rcases p with ⟨pn, hpn, pl, pv⟩
    rcases q with ⟨qn, hqn, ql, qv⟩
    rcases hpq with ⟨f, hpf⟩
    rcases hqp with ⟨g, _hqg⟩
    have hnm : pn ≤ qn := by
      simpa using Fintype.card_le_of_injective f f.injective
    have hmn : qn ≤ pn := by
      simpa using Fintype.card_le_of_injective g g.injective
    have harity : pn = qn := Nat.le_antisymm hnm hmn
    subst qn
    rw [orderEmb_self_eq_id f] at hpf
    have hLabels : pl = ql := by
      funext J
      by_cases hJ : J.Nonempty
      · simpa only [mapSubset_id] using hpf J hJ
      · have hEmpty : J = ∅ := Finset.not_nonempty_iff_eq_empty.mp hJ
        subst J
        calc
          pl ∅ = pl {⟨0, hpn⟩} := pv
          _ = ql {⟨0, hqn⟩} := by
            simpa only [mapSubset_id] using
              hpf {⟨0, hpn⟩} (by simp)
          _ = ql ∅ := qv.symm
    subst ql
    rfl

/-- A one-index system.  There are no validity equations in arity one. -/
def singleton (e : T) : System Φ where
  arity := 1
  positive := Nat.zero_lt_one
  label _ := e
  empty_normalized := rfl
  valid J hJ := by
    have : J.card ≤ 1 := by simpa using Finset.card_le_card (Finset.subset_univ J)
    omega

instance [Nonempty T] : Nonempty (System Φ) :=
  ⟨singleton (Classical.choice ‹Nonempty T›)⟩

end System

end FiniteSystems

end

end CoherentContinuousAlgebraicRetracts
