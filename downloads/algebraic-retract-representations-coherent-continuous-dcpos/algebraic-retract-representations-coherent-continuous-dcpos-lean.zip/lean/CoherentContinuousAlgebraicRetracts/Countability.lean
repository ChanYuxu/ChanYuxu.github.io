import CoherentContinuousAlgebraicRetracts.FiniteCoverRestriction

/-!
# Countability of the finite-system presentation

This file formalizes the counting argument used in source item
`cor:countable`.  A finite system is injected into the dependent sum of its
arity and its finite label table.  Consequently a countable basis gives a
countable finite-system poset, and a countable presentation poset gives a
countable compact basis for its ideal completion.
-/

set_option autoImplicit false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

variable {D : Type u} [PartialOrder D]
variable {B : Set D}

/-- The source's set `T_B = {(a,b) in B^2 | a << b}` is countable when
the chosen basis is countable. -/
theorem basisPair_countable (hB : B.Countable) :
    Countable (BasisPair B) := by
  letI : Countable B := hB.to_subtype
  exact Function.Embedding.countable
    { toFun := fun e : BasisPair B ↦ (e.first, e.second)
      inj' := by
        intro e f hef
        cases e
        cases f
        cases hef
        rfl }

namespace FiniteSystems.System

variable {T : Type u} {Φ : Finset T → Finset T}

/-- Forget the validity proofs and retain the finite label table. -/
def countabilityCode (p : FiniteSystems.System Φ) :
    (n : ℕ) × (Finset (Fin n) → T) :=
  ⟨p.arity, p.label⟩

theorem countabilityCode_injective :
    Function.Injective (countabilityCode (Φ := Φ)) := by
  intro p q hpq
  have hData := Sigma.mk.inj hpq
  exact FiniteSystems.System.ext hData.1 hData.2

/-- There are at most countably many finite systems over a countable label
type.  The proof is the formal version of "for each `n`, only finitely many
slots have to be filled, and then take the union over `n`". -/
theorem countable [Countable T] :
    Countable (FiniteSystems.System Φ) := by
  exact Function.Embedding.countable
    { toFun := countabilityCode (Φ := Φ)
      inj' := countabilityCode_injective (Φ := Φ) }

end FiniteSystems.System

/-- If the presentation poset is countable, the principal ideals form a
countable compact basis of its ideal completion. -/
theorem idealCompletion_compactSet_countable
    (P : Type u) [PartialOrder P] [Nonempty P] [Countable P] :
    (CompactSet : Set (IdealCompletion P)).Countable := by
  rw [compactSet_eq_range_principal]
  exact Set.countable_range (principalIdeal P)

/-- A countable presentation poset has an omega-algebraic ideal completion. -/
theorem idealCompletion_isOmegaAlgebraic
    (P : Type u) [PartialOrder P] [Nonempty P] [Countable P] :
    IsOmegaAlgebraicDomain (IdealCompletion P) :=
  ⟨idealCompletion_compactSet_countable P,
    idealCompletion_isAlgebraic P⟩

end

end CoherentContinuousAlgebraicRetracts
