import CoherentContinuousAlgebraicRetracts.PrefiniteApproximation
import CoherentContinuousAlgebraicRetracts.WellFilteredCoherence

/-!
# Applications of algebraic retract representations

Umbrella module for the frozen source's countability, function-space, and
prefinite-approximation sections.  The core retract theorem remains in
`CoherentContinuousAlgebraicRetracts`; this second root avoids an import cycle
because the application modules use that theorem.
-/
