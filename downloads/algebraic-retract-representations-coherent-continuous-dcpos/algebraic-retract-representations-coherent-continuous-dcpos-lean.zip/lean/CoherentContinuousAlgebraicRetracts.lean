import FormalizationBase
import CoherentContinuousAlgebraicRetracts.FiniteCommonApproximations
import CoherentContinuousAlgebraicRetracts.FiniteSystemPresentation
import CoherentContinuousAlgebraicRetracts.FiniteCoverRestriction
import CoherentContinuousAlgebraicRetracts.Countability
import CoherentContinuousAlgebraicRetracts.InternalCoherence
import CoherentContinuousAlgebraicRetracts.InternalLawson

/-!
# Algebraic retract representations of coherent continuous dcpos

Source-bound formalization for the manuscript frozen at
`source/已粘贴的文本.txt`, SHA-256
`e6af94a9b81f5546fd03a5553bcb16f8958f9daa62bbba1dc6d1984a74f6ac6a`.

This module does not silently transfer the completion verdict of the earlier
manuscript.  It reuses its proved ideal-completion and retract API, and feeds
that API with the current source's finite-system presentation.
-/

set_option autoImplicit false

universe u

namespace CoherentContinuousAlgebraicRetracts

open Set
open AbramskyJung
open AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts

noncomputable section

/-! ## Lower finiteness of the compact elements of an ideal completion -/

/-- Compact ideals, equipped with their inherited inclusion order.  The
underlying ideal completion is represented in the reused library as a
preorder together with a separately proved antisymmetry fact, so this small
wrapper installs the mathematically intended partial order without creating a
competing global instance on the ideal completion itself. -/
structure CompactIdeal (P : Type u) [PartialOrder P] where
  carrier : IdealCompletion P
  isCompact : Compact carrier

namespace CompactIdeal

variable {P : Type u} [PartialOrder P]

@[ext]
theorem ext {I J : CompactIdeal P} (h : I.carrier = J.carrier) : I = J := by
  cases I
  cases J
  cases h
  rfl

instance : PartialOrder (CompactIdeal P) where
  le I J := I.carrier ≤ J.carrier
  le_refl I := le_rfl
  le_trans I J K hIJ hJK := le_trans hIJ hJK
  le_antisymm I J hIJ hJI := by
    apply CompactIdeal.ext
    apply Subtype.ext
    exact Set.Subset.antisymm hIJ hJI

end CompactIdeal

/-- The principal-ideal correspondence transports lower finiteness of `P` to
the compact-element poset of `Idl(P)`.  This is the lower-finiteness clause
used in the current source statement of `thm:coherent-retract`. -/
theorem compactIdealElements_lowerFinite
    (P : Type u) [PartialOrder P] [Nonempty P]
    (hP : IsLowerFinite P) :
    IsLowerFinite (CompactIdeal P) := by
  intro I
  rcases (compact_iff_principal P I.carrier).1 I.isCompact with ⟨p, hp⟩
  let principalCompact : P → CompactIdeal P :=
    fun q ↦
      { carrier := principalIdeal P q
        isCompact :=
          (compact_iff_principal P (principalIdeal P q)).2 ⟨q, rfl⟩ }
  refine ((hP p).image principalCompact).subset ?_
  intro J hJ
  rcases hJ with ⟨I', hI', hJI'⟩
  have hI'I : I' = I := by simpa using hI'
  subst I'
  rcases (compact_iff_principal P J.carrier).1 J.isCompact with ⟨q, hq⟩
  have hqp : q ≤ p := by
    change J.carrier ≤ I.carrier at hJI'
    have hprincipal : principalIdeal P q ≤ principalIdeal P p := by
      rw [hq, hp] at hJI'
      exact hJI'
    exact (mem_principalIdeal P).1
      ((principalIdeal_le_iff_mem P).1 hprincipal)
  refine ⟨q, ?_, ?_⟩
  · exact ⟨p, by simp, hqp⟩
  · apply CompactIdeal.ext
    change principalIdeal P q = J.carrier
    exact hq.symm

/-! ## Exact source-facing witnesses for the current main theorem -/

/-- The coherent branch of the current source theorem.  The representing
algebraic dcpo is the ideal completion of a nonempty lower-finite poset; hence
its compact-element poset is itself lower finite. -/
structure CoherentRetractWitness (D : Type u) [PartialOrder D] where
  P : Type u
  [orderP : PartialOrder P]
  [nonemptyP : Nonempty P]
  pair : AbramskyJung.Chapter3.ContinuousSectionRetractionPair
    D (IdealCompletion P)
  coherent : IsCoherent (IdealCompletion P)
  algebraic : IsAlgebraicDomain (IdealCompletion P)
  compactLowerFinite :
    IsLowerFinite (CompactIdeal P)

attribute [instance]
  CoherentRetractWitness.orderP
  CoherentRetractWitness.nonemptyP

/-- The Lawson-compact branch of the current source theorem. -/
structure LawsonRetractWitness (D : Type u) [PartialOrder D] where
  P : Type u
  [orderP : PartialOrder P]
  [nonemptyP : Nonempty P]
  pair : AbramskyJung.Chapter3.ContinuousSectionRetractionPair
    D (IdealCompletion P)
  algebraic : IsAlgebraicDomain (IdealCompletion P)
  lawsonCompact :
    AbramskyJung.Chapter4.IsLawsonCompact
      (asOrderedDomain (IdealCompletion P))
  compactLowerFinite :
    IsLowerFinite (CompactIdeal P)

attribute [instance]
  LawsonRetractWitness.orderP
  LawsonRetractWitness.nonemptyP

/-! ## Countable source-facing witnesses -/

/-- The countable coherent branch of `cor:countable`.  In addition to the
main theorem's data, the presentation poset is countable and the ideal
completion carries its countable compact basis explicitly. -/
structure CountableCoherentRetractWitness
    (D : Type u) [PartialOrder D] where
  P : Type u
  [orderP : PartialOrder P]
  [nonemptyP : Nonempty P]
  [countableP : Countable P]
  pair : AbramskyJung.Chapter3.ContinuousSectionRetractionPair
    D (IdealCompletion P)
  coherent : IsCoherent (IdealCompletion P)
  omegaAlgebraic : IsOmegaAlgebraicDomain (IdealCompletion P)
  compactLowerFinite : IsLowerFinite (CompactIdeal P)

attribute [instance]
  CountableCoherentRetractWitness.orderP
  CountableCoherentRetractWitness.nonemptyP
  CountableCoherentRetractWitness.countableP

/-- The countable Lawson-compact branch of `cor:countable`. -/
structure CountableLawsonRetractWitness
    (D : Type u) [PartialOrder D] where
  P : Type u
  [orderP : PartialOrder P]
  [nonemptyP : Nonempty P]
  [countableP : Countable P]
  pair : AbramskyJung.Chapter3.ContinuousSectionRetractionPair
    D (IdealCompletion P)
  omegaAlgebraic : IsOmegaAlgebraicDomain (IdealCompletion P)
  lawsonCompact :
    AbramskyJung.Chapter4.IsLawsonCompact
      (asOrderedDomain (IdealCompletion P))
  compactLowerFinite : IsLowerFinite (CompactIdeal P)

attribute [instance]
  CountableLawsonRetractWitness.orderP
  CountableLawsonRetractWitness.nonemptyP
  CountableLawsonRetractWitness.countableP

/-- Current-source coherent witness, obtained from the revised finite-system
presentation and the verified ideal-completion implementation. -/
def coherentRetractWitness
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hDcpo : IsDcpo D)
    (hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D)
    (hCoherent : IsCoherent D) :
    CoherentRetractWitness D := by
  let B : Set D := Classical.choose hContinuous
  have hB : IsBasis B := Classical.choose_spec hContinuous
  have hRawContinuous : Chapter2.IsContinuousDomain D :=
    ⟨B, basis_to_raw hB⟩
  let choices := commonChoiceData hB hCoherent
  let R := FiniteSystemPresentation.presentationData choices hB
  let W := R.toCoherentApproximationPresentation hRawContinuous
  exact
    { P := W.P
      orderP := inferInstance
      nonemptyP := inferInstance
      pair := W.continuousSectionRetractionPair hDcpo
      coherent :=
        idealCompletion_coherent_of_finiteCompleteBinaryMUBs_internal
          W.P W.finite_complete_binary_mubs
      algebraic := idealCompletion_isAlgebraic W.P
      compactLowerFinite :=
        compactIdealElements_lowerFinite W.P R.lower_finite }

/-- Current-source Lawson witness.  Scott compactness supplies a finite
validity cover; restricting the finite-system index poset to its upward
closure gives property `M`, hence a Lawson-compact ideal completion. -/
def lawsonRetractWitness
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hDcpo : IsDcpo D)
    (hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D)
    (hCoherent : IsCoherent D)
    (hLawson :
      AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain D)) :
    LawsonRetractWitness D := by
  let B : Set D := Classical.choose hContinuous
  have hB : IsBasis B := Classical.choose_spec hContinuous
  have hRawContinuous : Chapter2.IsContinuousDomain D :=
    ⟨B, basis_to_raw hB⟩
  have hScottCompact : IsScottCompactSpace D :=
    scottCompact_of_lawsonCompact_internal hLawson
  let choices := commonChoiceData hB hCoherent
  let R := FiniteSystemPresentation.presentationData choices hB
  have hFiniteCover :=
    FiniteCoverRestriction.exists_finite_validity_cover R hScottCompact
  let K : Set R.P := Classical.choose hFiniteCover
  have hKfinite : K.Finite := (Classical.choose_spec hFiniteCover).1
  have hKnonempty : K.Nonempty := (Classical.choose_spec hFiniteCover).2.1
  have hKcover : (Set.univ : Set D) ⊆
      Set.sUnion (R.binary.V '' K : Set (Set D)) :=
    (Classical.choose_spec hFiniteCover).2.2
  let R₀ := FiniteCoverRestriction.restrictedData R hKnonempty hKcover
  let C := R₀.toCoherentApproximationPresentation hRawContinuous
  have hPropertyM : HasPropertyM C.P := by
    exact FiniteCoverRestriction.propertyM R hKfinite
  exact
    { P := C.P
      orderP := inferInstance
      nonemptyP := inferInstance
      pair := C.continuousSectionRetractionPair hDcpo
      algebraic := idealCompletion_isAlgebraic C.P
      lawsonCompact :=
        (idealCompletion_lawsonCompact_iff_propertyM_internal C.P).2 hPropertyM
      compactLowerFinite :=
        compactIdealElements_lowerFinite C.P R₀.lower_finite }

/-- Countable coherent witness built from the countable basis selected in the
hypothesis, rather than from an arbitrary basis of the continuous dcpo. -/
def countableCoherentRetractWitness
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hDcpo : IsDcpo D)
    (hOmega : IsOmegaContinuousDomain D)
    (hCoherent : IsCoherent D) :
    CountableCoherentRetractWitness D := by
  let B : Set D := Classical.choose hOmega
  have hBspec := Classical.choose_spec hOmega
  have hBcount : B.Countable := hBspec.1
  have hB : IsBasis B := prop_2_2_4_1 hBspec.2
  have hRawContinuous : Chapter2.IsContinuousDomain D :=
    ⟨B, basis_to_raw hB⟩
  let choices := commonChoiceData hB hCoherent
  haveI : Countable (BasisPair B) := basisPair_countable hBcount
  haveI : Countable (FiniteSystems.System choices.Φ) :=
    FiniteSystems.System.countable
  let R := FiniteSystemPresentation.presentationData choices hB
  letI : Countable R.P := by
    change Countable (FiniteSystems.System choices.Φ)
    infer_instance
  let W := R.toCoherentApproximationPresentation hRawContinuous
  letI : Countable W.P := by
    change Countable R.P
    infer_instance
  exact
    { P := W.P
      orderP := inferInstance
      nonemptyP := inferInstance
      countableP := inferInstance
      pair := W.continuousSectionRetractionPair hDcpo
      coherent :=
        idealCompletion_coherent_of_finiteCompleteBinaryMUBs_internal
          W.P W.finite_complete_binary_mubs
      omegaAlgebraic := idealCompletion_isOmegaAlgebraic W.P
      compactLowerFinite :=
        compactIdealElements_lowerFinite W.P R.lower_finite }

/-- Countable Lawson witness obtained by the same finite-cover restriction as
the main theorem.  A subtype of a countable presentation poset remains
countable. -/
def countableLawsonRetractWitness
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hDcpo : IsDcpo D)
    (hOmega : IsOmegaContinuousDomain D)
    (hCoherent : IsCoherent D)
    (hLawson :
      AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain D)) :
    CountableLawsonRetractWitness D := by
  let B : Set D := Classical.choose hOmega
  have hBspec := Classical.choose_spec hOmega
  have hBcount : B.Countable := hBspec.1
  have hB : IsBasis B := prop_2_2_4_1 hBspec.2
  have hRawContinuous : Chapter2.IsContinuousDomain D :=
    ⟨B, basis_to_raw hB⟩
  have hScottCompact : IsScottCompactSpace D :=
    scottCompact_of_lawsonCompact_internal hLawson
  let choices := commonChoiceData hB hCoherent
  haveI : Countable (BasisPair B) := basisPair_countable hBcount
  haveI : Countable (FiniteSystems.System choices.Φ) :=
    FiniteSystems.System.countable
  let R := FiniteSystemPresentation.presentationData choices hB
  letI : Countable R.P := by
    change Countable (FiniteSystems.System choices.Φ)
    infer_instance
  have hFiniteCover :=
    FiniteCoverRestriction.exists_finite_validity_cover R hScottCompact
  let K : Set R.P := Classical.choose hFiniteCover
  have hKfinite : K.Finite := (Classical.choose_spec hFiniteCover).1
  have hKnonempty : K.Nonempty := (Classical.choose_spec hFiniteCover).2.1
  have hKcover : (Set.univ : Set D) ⊆
      Set.sUnion (R.binary.V '' K : Set (Set D)) :=
    (Classical.choose_spec hFiniteCover).2.2
  let R₀ := FiniteCoverRestriction.restrictedData R hKnonempty hKcover
  letI : Countable R₀.P := by
    change Countable (FiniteCoverRestriction.RestrictedIndex R K)
    infer_instance
  let C := R₀.toCoherentApproximationPresentation hRawContinuous
  letI : Countable C.P := by
    change Countable R₀.P
    infer_instance
  have hPropertyM : HasPropertyM C.P := by
    exact FiniteCoverRestriction.propertyM R hKfinite
  exact
    { P := C.P
      orderP := inferInstance
      nonemptyP := inferInstance
      countableP := inferInstance
      pair := C.continuousSectionRetractionPair hDcpo
      omegaAlgebraic := idealCompletion_isOmegaAlgebraic C.P
      lawsonCompact :=
        (idealCompletion_lawsonCompact_iff_propertyM_internal C.P).2 hPropertyM
      compactLowerFinite :=
        compactIdealElements_lowerFinite C.P R₀.lower_finite }

/-- Source label `thm:coherent-retract` in the current manuscript.

The first conjunct gives a coherent algebraic ideal completion whose compact
elements are lower finite.  The second conjunct gives a Lawson-compact
algebraic ideal completion under the source's Lawson-compact hypothesis.
-/
theorem thm_coherent_retract
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hDcpo : IsDcpo D)
    (hContinuous : AbramskyJung.Chapter3.IsContinuousDomain D)
    (hCoherent : IsCoherent D) :
    Nonempty (CoherentRetractWitness D) ∧
      (AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain D) →
        Nonempty (LawsonRetractWitness D)) := by
  exact
    ⟨⟨coherentRetractWitness hDcpo hContinuous hCoherent⟩,
      fun hLawson ↦
        ⟨lawsonRetractWitness hDcpo hContinuous hCoherent hLawson⟩⟩

/-- Source item `cor:countable`.  The compact basis is countable because it is
the range of the principal-ideal map from the countable finite-system poset.
The Lawson branch uses a subtype of that same countable poset. -/
theorem cor_countable
    {D : Type u} [PartialOrder D] [Nonempty D]
    (hDcpo : IsDcpo D)
    (hOmega : IsOmegaContinuousDomain D)
    (hCoherent : IsCoherent D) :
    Nonempty (CountableCoherentRetractWitness D) ∧
      (AbramskyJung.Chapter4.IsLawsonCompact (asOrderedDomain D) →
        Nonempty (CountableLawsonRetractWitness D)) := by
  exact
    ⟨⟨countableCoherentRetractWitness hDcpo hOmega hCoherent⟩,
      fun hLawson ↦
        ⟨countableLawsonRetractWitness
          hDcpo hOmega hCoherent hLawson⟩⟩

end

end CoherentContinuousAlgebraicRetracts
