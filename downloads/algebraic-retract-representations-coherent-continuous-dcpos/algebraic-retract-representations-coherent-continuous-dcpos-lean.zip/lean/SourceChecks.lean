import CoherentContinuousAlgebraicRetractsApplications

/-! Source-signature and genuinely unpointed regression checks. -/

set_option autoImplicit false

open Set AbramskyJung AbramskyJung.Chapter2
open AbramskyJung.CoherentContinuousRetracts
open CoherentContinuousAlgebraicRetracts

universe u

section Statements

variable {D A B : Type u} [PartialOrder D] [PartialOrder A] [PartialOrder B]

example (hD : IsDcpo D) (hC : Chapter3.IsContinuousDomain D) :
    IsCoherent D ↔ Chapter4.ScottOpenIntersectionWayBelowProperty (asOrderedDomain D) :=
  FactorableApproximation.continuous_coherent_iff_scottOpenIntersectionWayBelow hD hC

example (hD : IsDcpo D) (hA : IsAlgebraicDomain D) :
    Chapter4.IsLawsonCompact (asOrderedDomain D) ↔ HasPropertyM (CompactBasis D) :=
  algebraic_lawsonCompact_iff_compactBasis_propertyM_proved D hD hA

example (hWF : ScottWellFiltered D) :
    IsCoherent D ↔ ∀ x y : D, ScottCompact
      (Chapter2.upperClosure ({x} : Set D) ∩ Chapter2.upperClosure ({y} : Set D)) :=
  jiaJungLi_3_1 hWF

example (hD : IsDcpo D) (hWF : ScottWellFiltered D) :
    let Lawson := Chapter4.IsLawsonCompact (asOrderedDomain D)
    let PrincipalIntersections := ∀ x y : D, ScottCompact
      (Chapter2.upperClosure ({x} : Set D) ∩ Chapter2.upperClosure ({y} : Set D))
    (Lawson ↔ IsScottPatchCompact D) ∧
    (Lawson ↔ IsScottCompactSpace D ∧ PrincipalIntersections) ∧
    (Lawson ↔ IsFinitelyGeneratedUpper D ∧ PrincipalIntersections) ∧
    (Lawson ↔ IsFinitelyGeneratedUpper D ∧ IsCoherent D) :=
  jiaJungLi_3_4 hD hWF

example (hD : IsDcpo D) (hC : Chapter3.IsContinuousDomain D) :
    Chapter4.IsLawsonCompact (asOrderedDomain D) ↔ IsScottCompactSpace D ∧ IsCoherent D :=
  continuous_lawsonCompact_iff_scottCompact_and_coherent_proved hD hC

example [Nonempty A] (hA : IsDcpo A) :
    (Chapter4.IsLawsonCompact (asOrderedDomain A) ∧ Chapter3.IsAlgebraicDomain A) ↔
      Nonempty (PrefiniteKernelApproximation A) :=
  thm_prefinite_algebraic A hA

noncomputable example [Nonempty A] [Nonempty B]
    (hA : LawsonAlgebraic A) (hB : UnpointedBifinite B) :
    LawsonAlgebraic (FunctionSpace B A) × UnpointedBifinite (FunctionSpace A B) :=
  thm_algebraic_function_spaces hA hB

end Statements

namespace SourceChecks

/-- Two incomparable minima with a shared upper element. -/
inductive Fork where
  | left
  | right
  | apex
  deriving DecidableEq

instance : Fintype Fork where
  elems := {Fork.left, Fork.right, Fork.apex}
  complete x := by cases x <;> simp

instance : PartialOrder Fork where
  le x y := x = y ∨ y = .apex
  le_refl _ := Or.inl rfl
  le_trans _ _ _ h₁ h₂ := by
    rcases h₂ with h₂ | h₂
    · exact h₂ ▸ h₁
    · exact Or.inr h₂
  le_antisymm _ _ h₁ h₂ := by
    rcases h₁ with h₁ | h₁
    · exact h₁
    · rcases h₂ with h₂ | h₂
      · exact h₂.symm
      · exact h₂.trans h₁.symm

theorem fork_not_pointed : ¬ ∃ b : Fork, ∀ x : Fork, b ≤ x := by
  rintro ⟨b, hb⟩
  have hLeft := hb Fork.left
  have hRight := hb Fork.right
  change b = Fork.left ∨ Fork.left = Fork.apex at hLeft
  change b = Fork.right ∨ Fork.right = Fork.apex at hRight
  rcases hLeft with rfl | h
  · rcases hRight with h | h <;> cases h
  · cases h

noncomputable def fork_bifinite : UnpointedBifinite Fork := by
  apply UnpointedBifinite.of_compact_finite_fix finite_poset_isDcpo finite_poset_algebraic
  intro _ _ _
  exact ⟨⟨id, scottContinuous_id, fun _ ↦ rfl, fun _ ↦ le_rfl⟩,
    Set.toFinite _, fun _ _ ↦ rfl⟩

/-- No `OrderBot` instance is available; the two minima are incomparable. -/
noncomputable example {A : Type} [PartialOrder A] (hA : LawsonAlgebraic A) :
    UnpointedBifinite (FunctionSpace A Fork) :=
  luanLi_5_6 hA fork_bifinite

end SourceChecks

#eval "SOURCE_CHECKS_PASS"
