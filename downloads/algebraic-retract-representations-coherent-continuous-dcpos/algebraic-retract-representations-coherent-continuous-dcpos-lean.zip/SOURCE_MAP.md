# Selected correspondence

## Theorem 1.1 (PDF p. 2)

TeX label: `thm:coherent-retract`

Coherent and Lawson-compact retract representations

- `CoherentContinuousAlgebraicRetracts.thm_coherent_retract`

## Lemma 2.2 (PDF p. 3)

TeX label: `lem:continuous-coherence-criterion`

Coherence via principal upper sets

- `CoherentContinuousAlgebraicRetracts.lem_continuous_coherence_criterion`

## Lemma 2.3 (PDF p. 4)

TeX label: `lem:coherence-retract`

Continuous Lawson compactness criterion (part b)

- `CoherentContinuousAlgebraicRetracts.continuous_lawsonCompact_iff_scottCompact_and_coherent_proved`

## Lemma 3.3 (PDF p. 6)

TeX label: `lem:finite-common-approximations`

Finite common approximations

- `CoherentContinuousAlgebraicRetracts.finite_common_approximations`

## Proposition 3.8 (PDF p. 11)

TeX label: `prop:constructed-retraction`

Coherent approximation presentation and retraction witness

- `CoherentContinuousAlgebraicRetracts.FiniteSystemPresentation.presentationData`
- `CoherentContinuousAlgebraicRetracts.coherentRetractWitness`

## Lemma 3.10 (PDF p. 12)

TeX label: `lem:compact-open-restriction`

Property M for the restricted poset

- `CoherentContinuousAlgebraicRetracts.FiniteCoverRestriction.propertyM`

## Corollary 3.11 (PDF p. 13)

TeX label: `cor:countable`

Countably based representations

- `CoherentContinuousAlgebraicRetracts.cor_countable`

## Theorem 4.1 (PDF p. 14)

TeX label: `thm:algebraic-function-spaces`

The two algebraic function-space results

- `CoherentContinuousAlgebraicRetracts.thm_algebraic_function_spaces`

## Corollary 4.2 (PDF p. 14)

TeX label: `thm:continuous-function-spaces`

Continuous function-space transfer

- `CoherentContinuousAlgebraicRetracts.thm_continuous_function_spaces`

## Corollary 4.3 (PDF p. 15)

TeX label: `cor:coherent-function-space`

Coherent function spaces

- `CoherentContinuousAlgebraicRetracts.cor_coherent_function_space`

## Corollary 4.4 (PDF p. 15)

TeX label: `cor:pointed-function-space`

Maps into a pointed RB-domain

- `CoherentContinuousAlgebraicRetracts.cor_pointed_function_space`

## Theorem 4.5 (PDF p. 16)

TeX label: `thm:prefinite-algebraic`

Prefinite kernels on algebraic dcpos

- `CoherentContinuousAlgebraicRetracts.thm_prefinite_algebraic`

## Lemma 4.6 (PDF p. 16)

TeX label: `lem:factorable-transfer`

Transfer through approximating stages

- `CoherentContinuousAlgebraicRetracts.FactorableApproximation.lem_factorable_transfer`

## Theorem 4.7 (PDF p. 17)

TeX label: `thm:prefinite-continuous`

Prefinite factorizations and countable refinement

- `CoherentContinuousAlgebraicRetracts.thm_prefinite_continuous`
- `CoherentContinuousAlgebraicRetracts.thm_prefinite_continuous_countable`
