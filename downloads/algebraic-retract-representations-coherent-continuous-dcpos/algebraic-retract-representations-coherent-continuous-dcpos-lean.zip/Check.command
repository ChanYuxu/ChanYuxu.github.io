#!/bin/sh
set -eu
cd "$(dirname "$0")/lean"
if ! command -v lake >/dev/null 2>&1; then
  printf "%s\n" "Install Elan and make lake available on PATH." >&2
  exit 127
fi
exec lake build "$@"
