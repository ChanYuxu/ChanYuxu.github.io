# Reproducible proof audit

Manuscript SHA-256 (original source, not included): `e6af94a9b81f5546fd03a5553bcb16f8958f9daa62bbba1dc6d1984a74f6ac6a`.

Toolchain: `leanprover/lean4:v4.30.0-rc2`; Mathlib: `5450b53e5ddc75d46418fabb605edbf36bd0beb6`.

The proof files and audit commands are the same files from the source-bound audit. The packaging change relocates the two local Lake dependencies into the archive, preserving their Lean options.

Scope: the main retract result, the countability refinement, the function-space results, and prefinite approximation, including the literature results needed by these proofs. This is not a claim that every prose assertion in the manuscript is separately encoded.

The audit uses trust level zero and checks 1312 declarations in 23 proof modules (175 private declarations), plus 6 explicitly selected reused proofs. The only transitive axioms in scope are `Classical.choice`, `Quot.sound`, `propext`. Some supporting textbook files contain unrelated declarations with proof gaps; none of these gaps is a dependency of an audited declaration. The textbook package is not audited as a whole.

Independent mathematical review has not been run and human review is pending.
