# Algebraic retract representations of coherent continuous dcpos

Open `index.html` for the offline Lean reader, or run `Check.command` on macOS, `Check.cmd` on Windows, or `sh Check.command` on Unix to build the project. Opening the HTML does not run Lean.

With Elan and Git installed, the equivalent commands from `lean/` are:

```sh
lake build
lake env lean --trust=0 SourceChecks.lean
lake env lean --trust=0 AxiomAudit.lean
```

The first build may fetch pinned dependencies. The archive does not contain Mathlib or any caches. There is no dependency on a separate local checkout of the author's code.

See AUDIT.md for scope, SOURCE_MAP.md for PDF-to-Lean correspondence, and SOURCE_SHA256.tsv for the bundled source inventory and reuse origins. To check archive files run `shasum -a 256 -c SHA256SUMS` from this directory (use `SOURCE_ONLY_SHA256SUMS` for the reader's source-only download).
