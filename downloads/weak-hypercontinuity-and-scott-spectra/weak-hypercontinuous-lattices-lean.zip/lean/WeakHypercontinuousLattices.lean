import WeakHypercontinuousLattices.MainClosedness
import WeakHypercontinuousLattices.MaximalBoundary
import WeakHypercontinuousLattices.PrincipalIdeals
import WeakHypercontinuousLattices.ScottSpectrumProducts

/-! The current source-bound checkpoint. Importing this file does not claim
coverage or acceptance for the entire manuscript. See `REPRODUCE.md`. -/
