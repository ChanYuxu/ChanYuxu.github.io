import WeakHypercontinuousLattices.LeanCriteria
import Mathlib.Order.CompleteLatticeIntervals
import Mathlib.Data.Finset.Lattice.Fold

/-! The actual principal ideal, with its inherited order, is used throughout.
Appendix A's bounded-complete hypotheses impose neither a global top nor
unrestricted binary joins. -/

noncomputable section

open Set ScottSpectraReviewed
open scoped Topology

namespace WeakHypercontinuousLattices

universe u v w

/-- The nonempty bounded joins clause of Definition A.1. -/
def HasBoundedJoins (P : Type u) [Preorder P] : Prop :=
  ∀ S : Set P, S.Nonempty → BddAbove S → ∃ s, IsLUB S s

/-- Definition A.1: bounded-complete dcpo with the designated least element
given by `OrderBot`. -/
def IsPointedBoundedCompleteDcpo (P : Type u) [PartialOrder P] [OrderBot P] : Prop :=
  IsDcpo P ∧ HasBoundedJoins P

/-- Definition A.1: a continuous pointed bounded-complete dcpo. -/
def IsPointedBcDomain (P : Type u) [PartialOrder P] [OrderBot P] : Prop :=
  IsContinuousDcpo P ∧ HasBoundedJoins P

theorem hasBoundedJoins_of_completeLattice (P : Type u) [CompleteLattice P] :
    HasBoundedJoins P := fun S _ _ => ⟨sSup S, isLUB_sSup S⟩

theorem boundedJoins_exists_isLUB {P : Type u} [PartialOrder P] [OrderBot P]
    (hbc : HasBoundedJoins P) {S : Set P} (hb : BddAbove S) : ∃ s, IsLUB S s := by
  by_cases hne : S.Nonempty
  · exact hbc S hne hb
  · refine ⟨⊥, ⟨?_, fun _ _ => bot_le⟩⟩
    intro z hz
    exact False.elim (hne ⟨z, hz⟩)

/-- Lemma A.3's nonempty infima: take the bounded join of the lower bounds.
This does not manufacture an infimum for the empty set. -/
theorem boundedJoins_exists_isGLB {P : Type u} [PartialOrder P] [OrderBot P]
    (hbc : HasBoundedJoins P) {S : Set P} (hne : S.Nonempty) : ∃ s, IsGLB S s := by
  obtain ⟨z, hz⟩ := hne
  have hb : BddAbove (lowerBounds S) := ⟨z, fun _ hb => hb hz⟩
  obtain ⟨s, hs⟩ := boundedJoins_exists_isLUB hbc hb
  exact ⟨s, isLUB_lowerBounds.mp hs⟩

/-- The actual ambient infimum of a pair, including pairs with no common
upper bound. -/
def bcMeet {P : Type u} [PartialOrder P] [OrderBot P] (hbc : HasBoundedJoins P)
    (x y : P) : P :=
  Classical.choose
    (boundedJoins_exists_isGLB hbc (S := ({x, y} : Set P)) ⟨x, by simp⟩)

theorem bcMeet_isGLB {P : Type u} [PartialOrder P] [OrderBot P]
    (hbc : HasBoundedJoins P) (x y : P) : IsGLB ({x, y} : Set P) (bcMeet hbc x y) :=
  Classical.choose_spec
    (boundedJoins_exists_isGLB hbc (S := ({x, y} : Set P)) ⟨x, by simp⟩)

/-- The semilattice structure promised by A.3, on the original order. -/
@[implicit_reducible]
def boundedJoinsSemilatticeInf {P : Type u} [PartialOrder P] [OrderBot P]
    (hbc : HasBoundedJoins P) : SemilatticeInf P where
  __ := ‹PartialOrder P›
  inf := bcMeet hbc
  inf_le_left x y := (bcMeet_isGLB hbc x y).1 (show x ∈ ({x, y} : Set P) by simp)
  inf_le_right x y := (bcMeet_isGLB hbc x y).1 (show y ∈ ({x, y} : Set P) by simp)
  le_inf x y z hxy hxz := (bcMeet_isGLB hbc y z).2
    (show x ∈ lowerBounds ({y, z} : Set P) from by simp [hxy, hxz])

theorem principalIdeal_isLUB_of_image {P : Type u} [PartialOrder P] {a : P}
    {S : Set (Iic a)} {s : Iic a} (hs : IsLUB (Subtype.val '' S) s.val) :
    IsLUB S s :=
  IsLUB.of_image Subtype.coe_le_coe hs

theorem principalIdeal_image_nonemptyDirected {P : Type u} [PartialOrder P] {a : P}
    {S : Set (Iic a)} (hS : NonemptyDirected S) : NonemptyDirected (Subtype.val '' S) :=
  ⟨hS.1.image _, directedOn_image.mpr (hS.2.mono fun _ _ h => h)⟩

/-- The directed supremum in the ideal is computed in the ambient dcpo. -/
theorem principalIdeal_isLUB_image_of_directed {P : Type u} [PartialOrder P] {a : P}
    (hP : IsDcpo P) {S : Set (Iic a)} (hS : NonemptyDirected S)
    {s : Iic a} (hs : IsLUB S s) : IsLUB (Subtype.val '' S) s.val := by
  obtain ⟨l, hl⟩ := hP _ (principalIdeal_image_nonemptyDirected hS)
  have hla : l ≤ a := hl.2 (by rintro _ ⟨p, _, rfl⟩; exact p.property)
  have hEq : s = (⟨l, hla⟩ : Iic a) :=
    hs.unique (principalIdeal_isLUB_of_image hl)
  rw [hEq]
  exact hl

/-- In pointed bounded-complete domains, the same calculation holds for
all joins, including the empty join. -/
theorem principalIdeal_isLUB_image {P : Type u} [PartialOrder P] [OrderBot P] {a : P}
    (hbc : HasBoundedJoins P) {S : Set (Iic a)} {s : Iic a} (hs : IsLUB S s) :
    IsLUB (Subtype.val '' S) s.val := by
  have hb : BddAbove (Subtype.val '' S) :=
    ⟨a, by rintro _ ⟨p, _, rfl⟩; exact p.property⟩
  obtain ⟨l, hl⟩ := boundedJoins_exists_isLUB hbc hb
  have hla' : l ≤ a := hl.2 (by rintro _ ⟨p, _, rfl⟩; exact p.property)
  have hEq : s = (⟨l, hla'⟩ : Iic a) :=
    hs.unique (principalIdeal_isLUB_of_image hl)
  rw [hEq]
  exact hl

/-- Nonempty infima of ideals are computed in the ambient order. There is
no claim about the ambient infimum of the empty set. -/
theorem principalIdeal_isGLB_image {P : Type u} [PartialOrder P] {a : P}
    {S : Set (Iic a)} (hne : S.Nonempty) {s : Iic a} (hs : IsGLB S s) :
    IsGLB (Subtype.val '' S) s.val := by
  constructor
  · rintro _ ⟨p, hp, rfl⟩
    exact hs.1 hp
  · intro z hz
    obtain ⟨p, hp⟩ := hne
    have hza : z ≤ a := (hz ⟨p, hp, rfl⟩).trans p.property
    exact hs.2 (show (⟨z, hza⟩ : Iic a) ∈ lowerBounds S from
      fun q hq => hz ⟨q, hq, rfl⟩)

theorem principalIdeal_exists_isLUB {P : Type u} [PartialOrder P] [OrderBot P]
    (hbc : HasBoundedJoins P) (a : P) (S : Set (Iic a)) : ∃ s, IsLUB S s := by
  have ha : a ∈ upperBounds (Subtype.val '' S) := by
    rintro _ ⟨p, _, rfl⟩
    exact p.property
  obtain ⟨s, hs⟩ := boundedJoins_exists_isLUB hbc ⟨a, ha⟩
  exact ⟨⟨s, hs.2 ha⟩, principalIdeal_isLUB_of_image hs⟩

/-- A source-faithful complete lattice structure on the ideal in a merely
bounded-complete poset. This definition is not a global instance. -/
@[implicit_reducible]
def principalIdealCompleteLattice {P : Type u} [PartialOrder P] [OrderBot P]
    (hbc : HasBoundedJoins P) (a : P) : CompleteLattice (Iic a) := by
  let h := principalIdeal_exists_isLUB hbc a
  letI : SupSet (Iic a) := ⟨fun S => Classical.choose (h S)⟩
  exact completeLatticeOfSup _ (fun S => Classical.choose_spec (h S))

theorem principalIdeal_inclusion_scottContinuous {P : Type u} [PartialOrder P]
    (hP : IsDcpo P) (a : P) :
    ScottContinuous (Subtype.val : Iic a → P) :=
  fun _ hne hdir _ hs => principalIdeal_isLUB_image_of_directed hP ⟨hne, hdir⟩ hs

theorem principalIdeal_wayBelow {P : Type u} [PartialOrder P] {a : P}
    (hP : IsDcpo P) {x y : Iic a} (hxy : WayBelow x.val y.val) : WayBelow x y := by
  intro S hS z hz hyz
  obtain ⟨_, ⟨p, hp, rfl⟩, hxp⟩ := hxy _ (principalIdeal_image_nonemptyDirected hS)
    z.val (principalIdeal_isLUB_image_of_directed hP hS hz) hyz
  exact ⟨p, hp, hxp⟩

theorem principalIdeal_isContinuousDcpo {P : Type u} [PartialOrder P]
    (hP : IsContinuousDcpo P) (a : P) : IsContinuousDcpo (Iic a) := by
  refine ⟨?_, ?_⟩
  · intro S hS
    obtain ⟨z, hz⟩ := hP.1 _ (principalIdeal_image_nonemptyDirected hS)
    have hza : z ≤ a := hz.2 (by rintro _ ⟨p, _, rfl⟩; exact p.property)
    exact ⟨⟨z, hza⟩, principalIdeal_isLUB_of_image hz⟩
  · intro x
    let A : Set (Iic a) := {u | WayBelow u.val x.val}
    let B : Set (Iic a) := {u | WayBelow u x}
    have hAB : A ⊆ B := fun _ hu => principalIdeal_wayBelow hP.1 hu
    have hA : NonemptyDirected A := by
      constructor
      · obtain ⟨p, hp⟩ := (hP.2 x.val).1.1
        exact ⟨⟨p, (wayBelow_le hp).trans x.property⟩, hp⟩
      · intro p hp q hq
        obtain ⟨r, hr, hpr, hqr⟩ := (hP.2 x.val).1.2 p.val hp q.val hq
        exact ⟨⟨r, (wayBelow_le hr).trans x.property⟩, hr, hpr, hqr⟩
    have hAx : IsLUB A x := by
      constructor
      · intro y hy
        show y.val ≤ x.val
        exact wayBelow_le (show WayBelow y.val x.val from hy)
      · intro y hy
        apply (hP.2 x.val).2.2
        intro p hp
        exact hy (show (⟨p, (wayBelow_le hp).trans x.property⟩ : Iic a) ∈ A from hp)
    refine ⟨⟨hA.1.mono hAB, ?_⟩, ⟨fun _ hy => wayBelow_le hy, ?_⟩⟩
    · intro p (hp : WayBelow p x) q (hq : WayBelow q x)
      obtain ⟨p', hp', hpp'⟩ := hp A hA x hAx le_rfl
      obtain ⟨q', hq', hqq'⟩ := hq A hA x hAx le_rfl
      obtain ⟨r, hr, hpr, hqr⟩ := hA.2 p' hp' q' hq'
      exact ⟨r, hAB hr, hpp'.trans hpr, hqq'.trans hqr⟩
    · intro y hy
      exact hAx.2 (fun _ hp => hy (hAB hp))

/-- Binary meet is jointly Scott-continuous, on all directed subsets
of the coordinatewise product. -/
theorem meet_scottContinuous_of_continuousDcpo {P : Type u} [SemilatticeInf P]
    (hP : IsContinuousDcpo P) : ScottContinuous (fun p : P × P => p.1 ⊓ p.2) := by
  intro D hne hdir z hz
  constructor
  · rintro _ ⟨p, hp, rfl⟩
    exact inf_le_inf (hz.1 hp).1 (hz.1 hp).2
  · intro w hw
    apply (hP.2 (z.1 ⊓ z.2)).2.2
    intro a (ha : WayBelow a (z.1 ⊓ z.2))
    have hFst : NonemptyDirected (Prod.fst '' D) :=
      ⟨hne.image _, directedOn_image.mpr (hdir.mono fun _ _ h => h.1)⟩
    have hSnd : NonemptyDirected (Prod.snd '' D) :=
      ⟨hne.image _, directedOn_image.mpr (hdir.mono fun _ _ h => h.2)⟩
    have hL := isLUB_prod.mp hz
    obtain ⟨_, ⟨p, hp, rfl⟩, hap⟩ := ha _ hFst z.1 hL.1 inf_le_left
    obtain ⟨_, ⟨q, hq, rfl⟩, haq⟩ := ha _ hSnd z.2 hL.2 inf_le_right
    obtain ⟨r, hr, hpr, hqr⟩ := hdir p hp q hq
    exact (le_inf (hap.trans hpr.1) (haq.trans hqr.2)).trans
      (hw ⟨r, hr, rfl⟩)

theorem finite_nonempty_inf_scottContinuous {D : Type v} {P : Type u} {ι : Type w}
    [Preorder D] [SemilatticeInf P] (hP : IsContinuousDcpo P) (f : ι → D → P)
    (F : Finset ι) (hF : F.Nonempty) (hf : ∀ i ∈ F, ScottContinuous (f i)) :
    ScottContinuous (fun x => F.inf' hF (fun i => f i x)) := by
  classical
  induction F using Finset.induction_on with
  | empty => exact (Finset.not_nonempty_empty hF).elim
  | @insert i F _ ih =>
    by_cases he : F.Nonempty
    · have hci := hf i (Finset.mem_insert_self _ _)
      have hcF := ih he (fun j hj => hf j (Finset.mem_insert_of_mem hj))
      have hc := (hci.prodMk hcF).comp (meet_scottContinuous_of_continuousDcpo hP)
      simpa [Function.comp_def, Finset.inf'_insert he] using hc
    · have h0 : F = ∅ := Finset.not_nonempty_iff_eq_empty.mp he
      subst F
      simpa using hf i (Finset.mem_insert_self _ _)

theorem bcMeet_scottContinuous {P : Type u} [PartialOrder P] [OrderBot P]
    (hP : IsPointedBcDomain P) :
    ScottContinuous (fun p : P × P => bcMeet hP.2 p.1 p.2) := by
  letI : SemilatticeInf P := boundedJoinsSemilatticeInf hP.2
  exact meet_scottContinuous_of_continuousDcpo hP.1

/-- Lemma A.3's finite pointwise meets, spelled nonempty on a carrier that
need not have a greatest element. -/
theorem bc_finite_nonempty_inf_scottContinuous {D : Type v} {P : Type u} {ι : Type w}
    [Preorder D] [PartialOrder P] [OrderBot P] (hP : IsPointedBcDomain P)
    (f : ι → D → P) (F : Finset ι) (hF : F.Nonempty) (hf : ∀ i ∈ F, ScottContinuous (f i)) :
    letI : SemilatticeInf P := boundedJoinsSemilatticeInf hP.2
    ScottContinuous (fun x => F.inf' hF (fun i => f i x)) := by
  letI : SemilatticeInf P := boundedJoinsSemilatticeInf hP.2
  exact finite_nonempty_inf_scottContinuous hP.1 f F hF hf

/-- The specified Scott retraction to the principal ideal. -/
def principalMeetProjection {P : Type u} [SemilatticeInf P] (a : P) (x : P) : Iic a :=
  ⟨x ⊓ a, inf_le_right⟩

theorem principalMeetProjection_gc {P : Type u} [SemilatticeInf P] (a : P) :
    GaloisConnection (Subtype.val : Iic a → P) (principalMeetProjection a) := by
  intro y x
  change y.val ≤ x ↔ y.val ≤ x ⊓ a
  exact ⟨fun h => le_inf h y.property, fun h => h.trans inf_le_left⟩

theorem principalMeetProjection_retract {P : Type u} [SemilatticeInf P] (a : P)
    (z : Iic a) : principalMeetProjection a z.val = z :=
  Subtype.ext (inf_eq_left.mpr z.property)

theorem principalMeetProjection_scottContinuous {P : Type u} [SemilatticeInf P]
    (hP : IsContinuousDcpo P) (a : P) : ScottContinuous (principalMeetProjection a) := by
  have hm : ScottContinuous (fun x : P => x ⊓ a) :=
    (ScottContinuous.id.prodMk (ScottContinuous.const a)).comp
      (meet_scottContinuous_of_continuousDcpo hP)
  intro D hne hdir z hz
  apply IsLUB.of_image Subtype.coe_le_coe
  simpa only [image_image, principalMeetProjection] using hm hne hdir hz

theorem principalMeetProjection_dualScottContinuous {P : Type u} [SemilatticeInf P]
    (a : P) : @ScottContinuous Pᵒᵈ (Iic a)ᵒᵈ _ _ (principalMeetProjection a) :=
  fun _ _ _ _ hs => (principalMeetProjection_gc a).dual.isLUB_l_image hs

/-- Lemma A.8's map, with meet constructed from bounded completeness. -/
def bcMeetProjection {P : Type u} [PartialOrder P] [OrderBot P]
    (hbc : HasBoundedJoins P) (a : P) (x : P) : Iic a := by
  letI : SemilatticeInf P := boundedJoinsSemilatticeInf hbc
  exact principalMeetProjection a x

theorem appA8_meet_projection {P : Type u} [PartialOrder P] [OrderBot P]
    (hP : IsPointedBcDomain P) (a : P) :
    ScottContinuous (bcMeetProjection hP.2 a) ∧
      @ScottContinuous Pᵒᵈ (Iic a)ᵒᵈ _ _ (bcMeetProjection hP.2 a) ∧
      GaloisConnection (Subtype.val : Iic a → P) (bcMeetProjection hP.2 a) := by
  letI : SemilatticeInf P := boundedJoinsSemilatticeInf hP.2
  exact ⟨principalMeetProjection_scottContinuous hP.1 a,
    principalMeetProjection_dualScottContinuous a, principalMeetProjection_gc a⟩

/-- Lemma 3.2, using Mathlib's complete-lattice structure on the literal
principal ideal, with the inclusion and meet retraction from the source. -/
theorem source_principalIdeal_weak {M : Type u} [CompleteLattice M]
    (hM : WeakHypercontinuous M) (a : M) : WeakHypercontinuous (Iic a) := by
  apply source_biScott_quotient hM (principalIdeal_isContinuousDcpo hM.1 a)
    (principalMeetProjection a)
  · exact fun z => ⟨z.val, principalMeetProjection_retract a z⟩
  · exact ScottNecessity.continuous_scott (principalMeetProjection_scottContinuous hM.1 a)
  · exact ScottNecessity.continuous_scott (principalMeetProjection_dualScottContinuous a)

end WeakHypercontinuousLattices
