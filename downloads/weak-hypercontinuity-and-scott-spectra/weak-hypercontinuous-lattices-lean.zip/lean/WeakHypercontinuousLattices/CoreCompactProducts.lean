import ScottSpectraReviewed.ScottClosedHyperspace
import ScottSpectraReviewed.ContinuousLatticeBasics
import ScottSpectraReviewed.CompleteQuotients
import ScottSpectraReviewed.UpperScottEq

set_option autoImplicit false

/-!
Core-compact Scott spaces and their closed-set lattices. The product argument
works with continuity of the lattice of opens; no local compactness, sobriety,
or directed completeness of the underlying orders is imposed.
-/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u v

namespace WeakHypercontinuousLattices
open ScottSpectraReviewed ScottSpectraReviewed.ScottNecessity

/-- The nontrivial inclusion in the Scott/product topology equality.
The section assignment into the lattice of opens preserves nonempty directed
suprema by Scott openness on each vertical line. -/
theorem isOpen_prod_of_isScottOpen_core {P : Type u} {Q : Type v}
    [PartialOrder P] [PartialOrder Q]
    (hcore : @IsCoreCompact P (scottTopology P)) {U : Set (P × Q)}
    (hU : IsOpen[scottTopology (P × Q)] U) :
    @IsOpen (P × Q) (@instTopologicalSpaceProd P Q (scottTopology P) (scottTopology Q)) U := by
  letI : TopologicalSpace P := scottTopology P
  letI : TopologicalSpace Q := scottTopology Q
  have hUspec := (isScottOpen_iff U).mp hU
  let V : Q → Opens P := fun q =>
    ⟨{p | (p,q) ∈ U}, isScottOpen_preimage
      (ScottContinuous.id.prodMk (ScottContinuous.const q)) hU⟩
  have hV : ScottContinuous V := by
    intro D hne hdir q hq
    constructor
    · rintro _ ⟨d,hd,rfl⟩ p hp
      exact hUspec.1 (show (p,d) ≤ (p,q) from ⟨le_rfl,hq.1 hd⟩) hp
    · intro W hW p hp
      have hr := isScottOpen_preimage ((ScottContinuous.const p).prodMk ScottContinuous.id) hU
      obtain ⟨d,hd,hpd⟩ := ((isScottOpen_iff _).mp hr).2 hne hdir hq hp
      exact hW (mem_image_of_mem V hd) hpd
  apply isOpen_iff_mem_nhds.mpr
  rintro ⟨x,y⟩ hxy
  obtain ⟨W,hxW,hW⟩ := coreCompact_iff_neighborhood.mp hcore (V y) x hxy
  let T : Set Q := {q | WayBelow W (V q)}
  have hT : IsOpen T := isScottOpen_preimage hV (isScottOpen_wayAbove hcore W)
  apply mem_of_superset (prod_mem_nhds (W.isOpen.mem_nhds hxW) (hT.mem_nhds hW))
  rintro ⟨p,q⟩ ⟨hp,hq⟩
  exact (wayBelow_le (show WayBelow W (V q) from hq)) hp

/-- CKL(d), with the core-compact factor displayed on the left. -/
theorem scottTopology_eq_prod_of_coreCompact_left {P : Type u} {Q : Type v}
    [PartialOrder P] [PartialOrder Q]
    (hcore : @IsCoreCompact P (scottTopology P)) :
    scottTopology (P × Q) =
      @instTopologicalSpaceProd P Q (scottTopology P) (scottTopology Q) := by
  letI : TopologicalSpace P := scottTopology P
  letI : TopologicalSpace Q := scottTopology Q
  apply le_antisymm
  · have hcont : Continuous[scottTopology (P × Q), inferInstance]
        (id : P × Q → P × Q) := by
      letI : TopologicalSpace (P × Q) := scottTopology (P × Q)
      exact (continuous_scott ScottContinuous.fst).prodMk (continuous_scott ScottContinuous.snd)
    exact continuous_id_iff_le.mp hcont
  · intro U hU
    exact isOpen_prod_of_isScottOpen_core hcore hU

/-- CKL(d) in the source order, with the arbitrary factor first. -/
theorem scottTopology_eq_prod_of_coreCompact {P : Type u} {Q : Type v}
    [PartialOrder P] [PartialOrder Q]
    (hcore : @IsCoreCompact P (scottTopology P)) :
    scottTopology (Q × P) =
      @instTopologicalSpaceProd Q P (scottTopology Q) (scottTopology P) := by
  letI : TopologicalSpace P := scottTopology P
  letI : TopologicalSpace Q := scottTopology Q
  apply le_antisymm
  · have hcont : Continuous[scottTopology (Q × P), inferInstance]
        (id : Q × P → Q × P) := by
      letI : TopologicalSpace (Q × P) := scottTopology (Q × P)
      exact (continuous_scott ScottContinuous.fst).prodMk (continuous_scott ScottContinuous.snd)
    exact continuous_id_iff_le.mp hcont
  · intro U hU
    have hswap : ScottContinuous (Prod.swap : P × Q → Q × P) :=
      ScottContinuous.snd.prodMk ScottContinuous.fst
    have hpre : @IsOpen (P × Q)
        (@instTopologicalSpaceProd P Q (scottTopology P) (scottTopology Q))
        (Prod.swap ⁻¹' U) :=
      isOpen_prod_of_isScottOpen_core hcore (isScottOpen_preimage hswap hU)
    simpa only [preimage_preimage, Prod.swap_swap_eq, preimage_id'] using
      hpre.preimage (continuous_swap : Continuous (Prod.swap : Q × P → P × Q))

/-- Finite Scott powers of a core-compact Scott space carry the product
topology. Adapted from the locally compact version in
`ScottSpectraReviewed.ScottNecessityProducts` using the core-compact
binary equality above. -/
theorem isOpen_pi_of_isScottOpen_core {P : Type u} [PartialOrder P]
    (hcore : @IsCoreCompact P (scottTopology P))
    (ι : Type v) [Finite ι] {U : Set (ι → P)}
    (hU : IsOpen[scottTopology (ι → P)] U) :
    @IsOpen (ι → P) (@Pi.topologicalSpace ι (fun _ => P) (fun _ => scottTopology P)) U := by
  letI : TopologicalSpace P := scottTopology P
  have hfinite : ∀ (ι : Type v) [Finite ι], ∀ U : Set (ι → P),
      IsOpen[scottTopology (ι → P)] U → IsOpen U := by
    intro ι _
    apply Finite.induction_empty_option (P := fun ι : Type v =>
      ∀ U : Set (ι → P), IsOpen[scottTopology (ι → P)] U → IsOpen U)
    · intro α β e ih S hS
      have hpre := ih _ (isScottOpen_preimage (scottContinuous_reindex e.symm) hS)
      have hcont : Continuous (fun f : β → P => fun i : α => f (e i)) :=
        continuous_pi fun i => continuous_apply (e i)
      have h := hpre.preimage hcont
      convert h using 1
      ext f
      simp only [mem_preimage]
      have heq : (fun j : β => f (e (e.symm j))) = f := by
        funext j
        rw [e.apply_symm_apply]
      rw [heq]
    · intro S _
      by_cases hs : S.Nonempty
      · have heq : S = univ := by
          obtain ⟨f, hf⟩ := hs
          exact eq_univ_of_forall fun g => (Subsingleton.elim f g) ▸ hf
        rw [heq]
        exact isOpen_univ
      · rw [Set.not_nonempty_iff_eq_empty.mp hs]
        exact isOpen_empty
    · intro α _ ih S hS
      let r : (P × (α → P)) → Option α → P := fun p i => Option.casesOn i p.1 p.2
      have hr : ScottContinuous r := by
        apply scottContinuous_pi
        intro i
        cases i with
        | none => exact ScottContinuous.fst
        | some i => exact ScottContinuous.snd.comp (scottContinuous_eval i)
      have hpre := isOpen_prod_of_isScottOpen_core hcore (isScottOpen_preimage hr hS)
      have hsnd : @Continuous (Option α → P) (α → P)
          (inferInstance : TopologicalSpace (Option α → P)) (scottTopology (α → P))
          (fun f i => f (some i)) := by
        apply (@continuous_def (Option α → P) (α → P)
          (inferInstance : TopologicalSpace (Option α → P)) (scottTopology (α → P)) _).mpr
        intro T hT
        exact (ih T hT).preimage (continuous_pi fun i => continuous_apply (some i))
      letI : TopologicalSpace (α → P) := scottTopology (α → P)
      have hcont : Continuous (fun f : Option α → P => (f none, fun i : α => f (some i))) :=
        (continuous_apply none).prodMk hsnd
      have h := hpre.preimage hcont
      convert h using 1
      ext f
      simp only [mem_preimage]
      have heq : r (f none, fun i : α => f (some i)) = f := by
        funext i
        cases i <;> rfl
      rw [heq]
  exact hfinite ι U hU

namespace CoreCompactScottClosed

open ScottSpectraReviewed.ScottClosedHyperspace

variable {P : Type u} [PartialOrder P]
local instance : TopologicalSpace P := scottTopology P

theorem continuous_finiteClosureMap
    (hcore : @IsCoreCompact P (scottTopology P)) {ι : Type v} [Fintype ι] :
    @Continuous (ι → P) (Carrier P)
      (@Pi.topologicalSpace ι (fun _ => P) (fun _ => scottTopology P))
      (scottTopology (Carrier P)) finiteClosureMap := by
  apply continuous_def.mpr
  intro U hU
  exact isOpen_pi_of_isScottOpen_core hcore ι
    (isScottOpen_preimage scottContinuous_finiteClosureMap hU)

/-- Finite-point closure maps produce the lower Vietoris neighborhoods.
Adapted from the locally compact proof in
`ScottSpectraReviewed.ScottClosedHyperspace`, now using only core
compactness through the finite-power result. -/
theorem isLowerVietorisOpen_of_isScottOpen
    (hcore : @IsCoreCompact P (scottTopology P)) {U : Set (Carrier P)}
    (hU : IsOpen[scottTopology (Carrier P)] U) :
    IsOpen[ClosedLattice.lowerVietorisTopology P] U := by
  classical
  letI : TopologicalSpace (Carrier P) := ClosedLattice.lowerVietorisTopology P
  have hUspec := (isScottOpen_iff U).mp hU
  apply isOpen_iff_mem_nhds.mpr
  intro A hAU
  obtain ⟨_, ⟨F, hFA, rfl⟩, hFU⟩ := hUspec.2
    (finiteApproximants_nonemptyDirected A).1 (finiteApproximants_nonemptyDirected A).2
    (finiteApproximants_isLUB A) hAU
  let p : F → P := fun i => i.val
  have hp : finiteClosureMap p ∈ U := by
    rw [finiteClosureMap_subtype]
    exact hFU
  have hpre : IsOpen (finiteClosureMap (P := P) (ι := F) ⁻¹' U) :=
    (@continuous_def (F → P) (Carrier P)
      (inferInstance : TopologicalSpace (F → P)) (scottTopology (Carrier P)) _).mp
      (continuous_finiteClosureMap hcore) U hU
  obtain ⟨V, hV, hbox⟩ := isOpen_pi_iff'.mp hpre p hp
  let O : F → Opens P := fun i => ⟨V i, (hV i).1⟩
  let W : Set (Carrier P) := ⋂ i : F, ClosedLattice.hit (O i)
  have hWopen : IsOpen W := isOpen_iInter_of_finite fun i =>
    isOpen_generateFrom_of_mem ⟨O i, rfl⟩
  have hAW : A ∈ W := mem_iInter.mpr fun i =>
    ⟨i.val, hFA i.property, (hV i).2⟩
  apply mem_of_superset (hWopen.mem_nhds hAW)
  intro B hBW
  have hchoose : ∀ i : F, ∃ y : P, y ∈ (B : Set P) ∧ y ∈ V i := by
    intro i
    exact mem_iInter.mp hBW i
  choose q hqB hqV using hchoose
  have hqbox : q ∈ Set.univ.pi V := fun i _ => hqV i
  have hqU : finiteClosureMap q ∈ U := hbox hqbox
  have hqB' : finiteClosureMap q ≤ B := Finset.sup_le
    (fun i _ => (principal_le_iff (q i) B).mpr (hqB i))
  exact hUspec.1 hqB' hqU

/-- CKL(c), first assertion, on the actual lattice of closed sets of
the intrinsic Scott space. -/
theorem scottTopology_eq_upper (hcore : @IsCoreCompact P (scottTopology P)) :
    scottTopology (Carrier P) = upperTopology (Carrier P) := by
  apply le_antisymm (scott_le_upperTopology _)
  intro U hU
  rw [← ClosedLattice.lowerVietoris_eq_upper (X := P)]
  exact isLowerVietorisOpen_of_isScottOpen hcore hU

/-- CKL(c), second assertion, in its two defining components: continuity of
the actual lattice of Scott opens and equality of the dual topologies. -/
theorem scottOpens_continuous_and_dualTopologyEquality
    (hcore : @IsCoreCompact P (scottTopology P)) :
    IsContinuousLattice (@Opens P (scottTopology P)) ∧
      DualTopologyEquality (@Opens P (scottTopology P)) :=
  ⟨hcore, OrderIsoTransfer.scott_eq_upper (ClosedLattice.complementOrderIso P)
    (scottTopology_eq_upper hcore)⟩

end CoreCompactScottClosed

section DependentProducts

variable {ι : Type v} {P : ι → Type u}

private theorem scottContinuous_depPi {A : Type*} [Preorder A] [∀ i, Preorder (P i)]
    (f : A → ∀ i, P i) (hf : ∀ i, ScottContinuous (fun a => f a i)) :
    ScottContinuous f := by
  intro D hne hdir x hx
  apply isLUB_pi.mpr
  intro i
  simpa only [image_image, Function.comp_def] using hf i hne hdir hx

private theorem scottContinuous_depEval [∀ i, Preorder (P i)] (i : ι) :
    ScottContinuous (fun f : ∀ i, P i => f i) := by
  intro D _ _ x hx
  exact (isLUB_pi.mp hx) i

private theorem scottContinuous_update [DecidableEq ι] [∀ i, Preorder (P i)] (i : ι) :
    ScottContinuous (fun p : P i × (∀ j, P j) => Function.update p.2 i p.1) := by
  apply scottContinuous_depPi
  intro j
  by_cases h : j = i
  · subst j
    simpa only [Function.update_self] using
      (ScottContinuous.fst : ScottContinuous (Prod.fst : P i × (∀ k, P k) → P i))
  · simpa only [Function.update_of_ne h, Function.comp_def] using
      (ScottContinuous.snd :
        ScottContinuous (Prod.snd : P i × (∀ k, P k) → (∀ k, P k))).comp
        (scottContinuous_depEval (P := P) j)

private def finiteSupportTrunc [DecidableEq ι] [∀ i, PartialOrder (P i)] [∀ i, OrderBot (P i)]
    (F : Finset ι) (x : ∀ i, P i) (i : ι) : P i :=
  if i ∈ F then x i else ⊥

private theorem finiteSupportTrunc_mono [DecidableEq ι] [∀ i, PartialOrder (P i)]
    [∀ i, OrderBot (P i)] (x : ∀ i, P i) {F G : Finset ι} (hFG : F ⊆ G) :
    finiteSupportTrunc F x ≤ finiteSupportTrunc G x := by
  intro i
  by_cases h : i ∈ F
  · simp [finiteSupportTrunc, h, hFG h]
  · simp [finiteSupportTrunc, h]

private theorem finiteSupportTrunc_le [DecidableEq ι] [∀ i, PartialOrder (P i)]
    [∀ i, OrderBot (P i)] (F : Finset ι) (x : ∀ i, P i) :
    finiteSupportTrunc F x ≤ x := by
  intro i
  by_cases h : i ∈ F <;> simp [finiteSupportTrunc, h]

abbrev scottProductTopology (P : ι → Type u) [∀ i, Preorder (P i)] :
    TopologicalSpace (∀ i, P i) :=
  @Pi.topologicalSpace ι P (fun i => scottTopology (P i))

abbrev upperProductTopology (P : ι → Type u) [∀ i, Preorder (P i)] :
    TopologicalSpace (∀ i, P i) :=
  @Pi.topologicalSpace ι P (fun i => upperTopology (P i))

/-- Extension by bottom from finitely many coordinates is continuous from the
product of the Scott spaces to the intrinsic Scott space on the whole family.
Induction adds one coordinate using the core-compact binary product theorem. -/
private theorem continuous_finiteSupportTrunc [DecidableEq ι] [∀ i, PartialOrder (P i)]
    [∀ i, OrderBot (P i)] (hcore : ∀ i, @IsCoreCompact (P i) (scottTopology (P i)))
    (F : Finset ι) :
    Continuous[scottProductTopology P, scottTopology (∀ i, P i)]
      (finiteSupportTrunc (P := P) F) := by
  induction F using Finset.induction_on with
  | empty =>
    have heq : finiteSupportTrunc (P := P) ∅ = fun _ => ⊥ := by
      funext x i
      simp [finiteSupportTrunc]
    rw [heq]
    exact @continuous_const (∀ i, P i) (∀ i, P i) (scottProductTopology P)
      (scottTopology (∀ i, P i)) ⊥
  | @insert i F hi ih =>
    let f : P i × (∀ j, P j) → (∀ j, P j) := fun p => Function.update p.2 i p.1
    have hf : Continuous[scottTopology (P i × (∀ j, P j)), scottTopology (∀ j, P j)] f :=
      continuous_scott (scottContinuous_update i)
    rw [scottTopology_eq_prod_of_coreCompact_left (Q := (∀ j, P j)) (hcore i)] at hf
    have hproj : Continuous[scottProductTopology P, scottTopology (P i)]
        (fun x : (∀ j, P j) => x i) :=
      @continuous_apply ι P (fun j => scottTopology (P j)) i
    have hpair := @Continuous.prodMk (P i) (∀ j, P j) (∀ j, P j)
      (scottTopology (P i)) (scottTopology (∀ j, P j)) (scottProductTopology P) _ _
      hproj ih
    have hcomp := @Continuous.comp (∀ j, P j) (P i × (∀ j, P j)) (∀ j, P j)
      (scottProductTopology P)
      (@instTopologicalSpaceProd (P i) (∀ j, P j)
        (scottTopology (P i)) (scottTopology (∀ j, P j)))
      (scottTopology (∀ j, P j)) _ _ hf hpair
    have heq : f ∘ (fun x : (∀ j, P j) => (x i, finiteSupportTrunc F x)) =
        finiteSupportTrunc (insert i F) := by
      funext x j
      by_cases hij : j = i
      · subst j
        simp [f, finiteSupportTrunc]
      · simp [f, finiteSupportTrunc, hij]
    rwa [heq] at hcomp

/-- Arbitrary dependent products of pointed posets with core-compact Scott
spaces have their intrinsic Scott topology equal to the actual product
topology. Finite-support truncations form a nonempty directed family with
supremum the original tuple, including when the index type is empty. -/
theorem scottTopology_eq_pi_of_coreCompact [∀ i, PartialOrder (P i)]
    [∀ i, OrderBot (P i)] (hcore : ∀ i, @IsCoreCompact (P i) (scottTopology (P i))) :
    scottTopology (∀ i, P i) = scottProductTopology P := by
  classical
  letI : ∀ i, TopologicalSpace (P i) := fun i => scottTopology (P i)
  apply le_antisymm
  · have hcont : Continuous[scottTopology (∀ i, P i), scottProductTopology P]
        (id : (∀ i, P i) → (∀ i, P i)) := by
      letI : TopologicalSpace (∀ i, P i) := scottTopology (∀ i, P i)
      exact continuous_pi (fun i => continuous_scott (scottContinuous_depEval i))
    exact continuous_id_iff_le.mp hcont
  · intro U hU
    have hUspec := (isScottOpen_iff U).mp hU
    letI : TopologicalSpace (∀ i, P i) := scottProductTopology P
    apply isOpen_iff_mem_nhds.mpr
    intro x hx
    let S : Set (∀ i, P i) := range (fun F : Finset ι => finiteSupportTrunc F x)
    have hne : S.Nonempty := ⟨finiteSupportTrunc ∅ x, ⟨∅, rfl⟩⟩
    have hdir : DirectedOn (· ≤ ·) S := by
      rintro _ ⟨F,rfl⟩ _ ⟨G,rfl⟩
      exact ⟨finiteSupportTrunc (F ∪ G) x, ⟨F ∪ G,rfl⟩,
        finiteSupportTrunc_mono x Finset.subset_union_left,
        finiteSupportTrunc_mono x Finset.subset_union_right⟩
    have hlub : IsLUB S x := by
      constructor
      · rintro _ ⟨F,rfl⟩
        exact finiteSupportTrunc_le F x
      · intro y hy i
        have hle : finiteSupportTrunc {i} x ≤ y := hy ⟨{i},rfl⟩
        simpa [finiteSupportTrunc] using hle i
    obtain ⟨_, ⟨F,rfl⟩, hF⟩ := hUspec.2 hne hdir hlub hx
    have hpre : IsOpen (finiteSupportTrunc F ⁻¹' U) :=
      @IsOpen.preimage _ _ (scottProductTopology P) (scottTopology (∀ i, P i))
        _ (continuous_finiteSupportTrunc hcore F) _ hU
    exact mem_of_superset (hpre.mem_nhds hF) fun z hz =>
      hUspec.1 (finiteSupportTrunc_le F z) hz

/-- Upper topologies commute with arbitrary products of posets with greatest
elements. The top element is used only to identify an evaluation cylinder
with the complement of a principal ideal of the product. -/
theorem upperTopology_eq_pi [∀ i, Preorder (P i)] [∀ i, OrderTop (P i)] :
    upperTopology (∀ i, P i) = upperProductTopology P := by
  classical
  letI : ∀ i, TopologicalSpace (P i) := fun i => upperTopology (P i)
  apply le_antisymm
  · have hproj (i : ι) : Continuous[upperTopology (∀ i, P i), upperTopology (P i)]
        (fun x : (∀ j, P j) => x i) := by
      letI : TopologicalSpace (∀ i, P i) := upperTopology (∀ i, P i)
      apply continuous_generateFrom_iff.mpr
      rintro _ ⟨a,rfl⟩
      let b : (∀ j, P j) := Function.update (fun _ => ⊤) i a
      have heq : (fun x : (∀ j, P j) => x i) ⁻¹' (Iic a)ᶜ = (Iic b)ᶜ := by
        ext x
        simp only [mem_preimage, mem_compl_iff, mem_Iic]
        apply not_congr
        constructor
        · intro hi j
          by_cases hji : j = i
          · subst j
            simpa [b] using hi
          · simp [b, Function.update_of_ne hji]
        · intro hb
          simpa [b] using hb i
      rw [heq]
      exact isOpen_generateFrom_of_mem ⟨b,rfl⟩
    have hcont : Continuous[upperTopology (∀ i, P i), upperProductTopology P]
        (id : (∀ i, P i) → (∀ i, P i)) := by
      letI : TopologicalSpace (∀ i, P i) := upperTopology (∀ i, P i)
      exact continuous_pi hproj
    exact continuous_id_iff_le.mp hcont
  · apply TopologicalSpace.le_generateFrom_iff_subset_isOpen.mpr
    rintro _ ⟨a,rfl⟩
    letI : TopologicalSpace (∀ i, P i) := upperProductTopology P
    change IsOpen ((Iic a)ᶜ : Set (∀ i, P i))
    have heq : (Iic a)ᶜ = ⋃ i, (fun x : (∀ j, P j) => x i) ⁻¹' (Iic (a i))ᶜ := by
      ext x
      simp only [mem_compl_iff, mem_Iic, mem_iUnion, mem_preimage, Pi.le_def, not_forall]
    rw [heq]
    apply isOpen_iUnion
    intro i
    have hi : IsOpen[upperTopology (P i)] (Iic (a i))ᶜ :=
      isOpen_generateFrom_of_mem ⟨a i,rfl⟩
    exact hi.preimage (@continuous_apply ι P (fun j => upperTopology (P j)) i)

/-- The topology-equality component of weak hypercontinuity is stable under
products when the dual Scott factors are core compact. -/
theorem dualTopologyEquality_pi [∀ i, PartialOrder (P i)]
    [∀ i, OrderBot (P i)] [∀ i, OrderTop (P i)]
    (hcore : ∀ i, @IsCoreCompact (P i)ᵒᵈ (scottTopology (P i)ᵒᵈ))
    (hd : ∀ i, DualTopologyEquality (P i)) :
    DualTopologyEquality (∀ i, P i) := by
  change scottTopology (∀ i, (P i)ᵒᵈ) = upperTopology (∀ i, (P i)ᵒᵈ)
  rw [scottTopology_eq_pi_of_coreCompact hcore, upperTopology_eq_pi]
  change @Pi.topologicalSpace ι (fun i => (P i)ᵒᵈ) (fun i => scottTopology (P i)ᵒᵈ) =
    @Pi.topologicalSpace ι (fun i => (P i)ᵒᵈ) (fun i => upperTopology (P i)ᵒᵈ)
  rw [show (fun i => scottTopology (P i)ᵒᵈ) = fun i => upperTopology (P i)ᵒᵈ from funext hd]

end DependentProducts

section TopologicalProducts

variable {X : Type u} {Y : Type v} [TopologicalSpace X] [TopologicalSpace Y]

private def opensRectangle (U : Opens X) (V : Opens Y) : Opens (X × Y) :=
  ⟨(U : Set X) ×ˢ (V : Set Y), U.isOpen.prod V.isOpen⟩

/-- The set of points above which the whole compact fiber is in an open
subset of a product. The tube lemma makes this set an actual open. -/
private def compactFiberOpen {K : Set Y} (hK : IsCompact K) (W : Opens (X × Y)) :
    Opens X :=
  ⟨{x | ({x} : Set X) ×ˢ K ⊆ (W : Set (X × Y))}, by
    apply isOpen_iff_mem_nhds.mpr
    intro x hx
    obtain ⟨A,B,hA,_,hxA,hKB,hAB⟩ :=
      generalized_tube_lemma (isCompact_singleton (x := x)) hK W.isOpen hx
    exact mem_of_superset (hA.mem_nhds (hxA rfl)) fun z hz p hp =>
      hAB ⟨(mem_singleton_iff.mp hp.1).symm ▸ hz,hKB hp.2⟩⟩

/-- If the right-hand factor admits a compact sandwich, way-below
approximation of the left-hand open gives way-below approximation of
the product open. The directed open cover is arbitrary. -/
private theorem wayBelow_opensRectangle_of_compact {U' U : Opens X}
    (hU : WayBelow U' U) {V' V : Opens Y} {K : Set Y} (hK : IsCompact K)
    (hV'K : (V' : Set Y) ⊆ K) (hKV : K ⊆ (V : Set Y)) :
    WayBelow (opensRectangle U' V') (opensRectangle U V) := by
  intro D hD p hp hpUV
  letI : Nonempty D := hD.1.to_subtype
  have hp_eq : sSup D = p := (isLUB_sSup D).unique hp
  let T : Opens (X × Y) → Opens X := compactFiberOpen hK
  have hTmono : Monotone T := by
    intro W W' hWW' x hx p hp
    exact hWW' (hx hp)
  have hTdir : NonemptyDirected (T '' D) :=
    ⟨hD.1.image T, directedOn_image.mpr (hD.2.mono hTmono)⟩
  have hUT : U ≤ sSup (T '' D) := by
    intro x hx
    let A : D → Set Y := fun d => {y | (x,y) ∈ (d.val : Set (X × Y))}
    have hAopen : ∀ d, IsOpen (A d) := fun d =>
      d.val.isOpen.preimage (continuous_const.prodMk continuous_id)
    have hAdir : Directed (· ⊆ ·) A := by
      intro d e
      obtain ⟨f,hf,hdf,hef⟩ := hD.2 d d.property e e.property
      exact ⟨⟨f,hf⟩,fun _ hy => hdf hy,fun _ hy => hef hy⟩
    have hKA : K ⊆ ⋃ d, A d := by
      intro y hy
      have hp' : (x,y) ∈ p := hpUV ⟨hx,hKV hy⟩
      rw [← hp_eq] at hp'
      obtain ⟨d,hd,hxyd⟩ := Opens.mem_sSup.mp hp'
      exact mem_iUnion.mpr ⟨⟨d,hd⟩,hxyd⟩
    obtain ⟨d,hd⟩ := hK.elim_directed_cover A hAopen hKA hAdir
    apply Opens.mem_sSup.mpr
    refine ⟨T d.val,mem_image_of_mem T d.property,?_⟩
    rintro ⟨z,y⟩ ⟨hz,hy⟩
    have : z = x := mem_singleton_iff.mp hz
    subst z
    exact hd hy
  obtain ⟨_,⟨d,hd,rfl⟩,hTd⟩ := hU (T '' D) hTdir _ (isLUB_sSup _) hUT
  exact ⟨d,hd,fun p hp' => hTd hp'.1 ⟨rfl,hV'K hp'.2⟩⟩

/-- A product of a core-compact space and a locally compact space is
core compact. Local compactness means the compact-saturated neighborhood
sandwich on the right; no separation axiom is required on either factor. -/
theorem isCoreCompact_prod_of_isCoreCompact_isLocallyCompact
    (hx : IsCoreCompact X) (hy : IsLocallyCompact Y) : IsCoreCompact (X × Y) := by
  apply coreCompact_iff_neighborhood.mpr
  intro W p hp
  obtain ⟨A,B,hA,hB,ha,hb,hAB⟩ := isOpen_prod_iff.mp W.isOpen p.1 p.2 hp
  let U : Opens X := ⟨A,hA⟩
  let V : Opens Y := ⟨B,hB⟩
  obtain ⟨U',hxU',hU'⟩ := coreCompact_iff_neighborhood.mp hx U p.1 ha
  obtain ⟨V',K,hyV',hV'K,hKV,hK,_⟩ := hy V p.2 hb
  exact ⟨opensRectangle U' V', ⟨hxU',hyV'⟩,
    wayBelow_mono le_rfl (wayBelow_opensRectangle_of_compact hU' hK hV'K hKV) hAB⟩

end TopologicalProducts
end WeakHypercontinuousLattices
