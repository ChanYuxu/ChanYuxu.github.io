import ScottSpectraReviewed.OrderBasics
import Mathlib.Order.Zorn
import Mathlib.Topology.Compactness.Compact
import Mathlib.Topology.DiscreteSubset

/-! Appendix A.10–A.12, with the pointed bounded-complete carrier retained.
The conventions for nonempty directed sets and the two intrinsic topologies
are reused from `ScottSpectraReviewed.OrderBasics`. -/

noncomputable section

open Set ScottSpectraReviewed
open scoped Topology

universe u

namespace WeakHypercontinuousLattices

/-- The set `Max(P)` in Appendix A. -/
def maximalElements (P : Type u) [Preorder P] : Set P := {m | IsMax m}

/-- Lemma A.10 (`lem:maximal-extension`). No bottom is needed for this lemma. -/
theorem exists_ge_isMax {P : Type u} [PartialOrder P] (hdcpo : IsDcpo P) (x : P) :
    ∃ m : P, x ≤ m ∧ IsMax m := by
  apply zorn_le_nonempty_Ici₀ x _ x le_rfl
  intro c _ hchain y hy
  obtain ⟨s, hs⟩ := hdcpo c ⟨⟨y, hy⟩, hchain.directedOn⟩
  exact ⟨s, hs.1⟩

/-- Lemma A.11 (`lem:remove-maximal-scott-open`). The maximal elements
are taken in the original order, and the openness in the dual order. -/
theorem dualScott_isOpen_compl_of_subset_maximal {P : Type u} [PartialOrder P]
    (S : Set Pᵒᵈ) (hS : S ⊆ maximalElements P) :
    IsOpen[scottTopology Pᵒᵈ] Sᶜ := by
  refine (isScottOpen_iff Sᶜ).2 ⟨?_, ?_⟩
  · intro x y hxy hx hy
    have hmax : IsMax (OrderDual.ofDual y) := hS hy
    have hyx : OrderDual.ofDual y ≤ OrderDual.ofDual x := hxy
    have heq : y = x := le_antisymm (hmax hyx) hxy
    exact hx (heq ▸ hy)
  · intro D hDne hDdir d hdlub hdnot
    by_contra hn
    have hDS : D ⊆ S := by
      intro s hs
      by_contra hsn
      exact hn ⟨s, hs, hsn⟩
    obtain ⟨x, hx⟩ := hDne
    have hDsingle : D = {x} := by
      apply Set.Subset.antisymm
      · intro y hy
        obtain ⟨z, hz, hxz, hyz⟩ := hDdir x hx y hy
        have hmax : IsMax (OrderDual.ofDual z) := hS (hDS hz)
        have hzx : z = x := le_antisymm
          (show z ≤ x from hmax (show OrderDual.ofDual z ≤ OrderDual.ofDual x from hxz)) hxz
        have hzy : z = y := le_antisymm
          (show z ≤ y from hmax (show OrderDual.ofDual z ≤ OrderDual.ofDual y from hyz)) hyz
        exact Set.mem_singleton_iff.mpr (hzy.symm.trans hzx)
      · exact Set.singleton_subset_iff.mpr hx
    rw [hDsingle] at hdlub
    have hd : d = x := hdlub.unique isLUB_singleton
    exact hdnot (hd.symm ▸ hDS hx)

/-- The compactness half of Proposition A.12. This part does not use the
equality between the two topologies, or continuity of the dcpo. -/
theorem maximalElements_isCompact_dualUpper {P : Type u} [PartialOrder P] [OrderBot P]
    (hdcpo : IsDcpo P)
    (hbc : ∀ S : Set P, S.Nonempty → BddAbove S → ∃ s, IsLUB S s) :
    @IsCompact Pᵒᵈ (upperTopology Pᵒᵈ) (maximalElements P) := by
  classical
  letI : TopologicalSpace Pᵒᵈ := upperTopology Pᵒᵈ
  apply isCompact_generateFrom' (S := {U | ∃ p : Pᵒᵈ, (Iic p)ᶜ = U}) rfl
  intro ι U hcover
  choose p hp using fun i => (U i).property
  let a : ι → P := fun i => OrderDual.ofDual (p i)
  by_contra hsub
  have hbound (J : Finset ι) : ∃ m : P, ∀ i ∈ J, a i ≤ m := by
    have hn : ¬ maximalElements P ⊆ ⋃ i ∈ (J : Set ι), (U i : Set Pᵒᵈ) := by
      intro hc
      exact hsub ⟨(J : Set ι), J.finite_toSet, hc⟩
    obtain ⟨m, _, hm⟩ := Set.not_subset.mp hn
    refine ⟨m, ?_⟩
    intro i hi
    by_contra hle
    apply hm
    refine Set.mem_iUnion₂.mpr ⟨i, hi, ?_⟩
    rw [← hp i]
    exact hle
  let T (J : Finset ι) : Set P := a '' (J : Set ι)
  have hL (J : Finset ι) : ∃ b : P, IsLUB (T J) b := by
    by_cases hne : (T J).Nonempty
    · obtain ⟨m, hm⟩ := hbound J
      refine hbc (T J) hne ⟨m, ?_⟩
      rintro _ ⟨i, hi, rfl⟩
      exact hm i hi
    · refine ⟨⊥, ⟨?_, fun _ _ => bot_le⟩⟩
      intro x hx
      exact False.elim (hne ⟨x, hx⟩)
  choose b hb using hL
  have hmono {J K : Finset ι} (hJK : J ⊆ K) : b J ≤ b K := by
    apply (hb J).2
    rintro _ ⟨i, hi, rfl⟩
    exact (hb K).1 ⟨i, hJK hi, rfl⟩
  have hdir : NonemptyDirected (range b) := by
    refine ⟨⟨b ∅, mem_range_self ∅⟩, ?_⟩
    rintro _ ⟨J, rfl⟩ _ ⟨K, rfl⟩
    exact ⟨b (J ∪ K), mem_range_self (J ∪ K),
      hmono Finset.subset_union_left, hmono Finset.subset_union_right⟩
  obtain ⟨s, hs⟩ := hdcpo (range b) hdir
  obtain ⟨m, hsm, hm⟩ := exists_ge_isMax hdcpo s
  have hle (i : ι) : a i ≤ m :=
    ((hb ({i} : Finset ι)).1 ⟨i, by simp, rfl⟩).trans
      ((hs.1 (mem_range_self {i})).trans hsm)
  obtain ⟨i, hi⟩ := mem_iUnion.mp (hcover hm)
  rw [← hp i] at hi
  exact hi (hle i)

/-- Under the dual-topology equality, the relative upper topology on `Max(P)`
is discrete. This proof has no completeness assumptions. -/
theorem maximalElements_isDiscrete_dualUpper {P : Type u} [PartialOrder P]
    (hdual : DualTopologyEquality P) :
    @IsDiscrete Pᵒᵈ (upperTopology Pᵒᵈ) (maximalElements P) := by
  letI : TopologicalSpace Pᵒᵈ := upperTopology Pᵒᵈ
  apply isDiscrete_iff_forall_exists_isOpen.mpr
  intro m hm
  let S : Set Pᵒᵈ := maximalElements P \ {m}
  refine ⟨Sᶜ, ?_, ?_⟩
  · change IsOpen[upperTopology Pᵒᵈ] Sᶜ
    change scottTopology Pᵒᵈ = upperTopology Pᵒᵈ at hdual
    rw [← hdual]
    exact dualScott_isOpen_compl_of_subset_maximal S (fun _ hs => hs.1)
  · ext z
    constructor
    · intro hz
      by_contra hneq
      exact hz.1 ⟨hz.2, hneq⟩
    · intro hz
      have heq : z = m := mem_singleton_iff.mp hz
      subst z
      exact ⟨fun h => h.2 (mem_singleton m), hm⟩

/-- The finite-boundary conclusion already holds without continuity. -/
theorem finite_maximal_of_dual_topology_eq_upper {P : Type u} [PartialOrder P] [OrderBot P]
    (hdcpo : IsDcpo P)
    (hbc : ∀ S : Set P, S.Nonempty → BddAbove S → ∃ s, IsLUB S s)
    (hdual : DualTopologyEquality P) : (maximalElements P).Finite := by
  letI : TopologicalSpace Pᵒᵈ := upperTopology Pᵒᵈ
  exact (maximalElements_isCompact_dualUpper hdcpo hbc).finite
    (maximalElements_isDiscrete_dualUpper hdual)

/-- Proposition A.12 (`prop:finite-max-bc`) with the continuous dcpo,
nonempty bounded completeness, and dual-topology equality hypotheses exposed. -/
theorem appA12_finite_maximal_elements {P : Type u} [PartialOrder P] [OrderBot P]
    (hcontinuous : IsContinuousDcpo P)
    (hbc : ∀ S : Set P, S.Nonempty → BddAbove S → ∃ s, IsLUB S s)
    (hdual : DualTopologyEquality P) : (maximalElements P).Finite :=
  finite_maximal_of_dual_topology_eq_upper hcontinuous.1 hbc hdual

/-- The principal ideal cover used in A.14, without finiteness assumptions. -/
theorem iUnion_principal_ideals_maximal_eq_univ {P : Type u} [PartialOrder P]
    (hdcpo : IsDcpo P) : (⋃ m ∈ maximalElements P, Iic m) = (univ : Set P) := by
  refine subset_antisymm (subset_univ _) ?_
  intro x _
  obtain ⟨m, hxm, hm⟩ := exists_ge_isMax hdcpo x
  exact mem_iUnion₂.mpr ⟨m, hm, hxm⟩

end WeakHypercontinuousLattices
