import WeakHypercontinuousLattices.LeanCriteria
import ScottSpectraReviewed.UpperTopologySobriety

/-! Source Theorem 2.2(a). Compact saturated neighbourhoods are built on
the actual dual order; the proof does not assume that the dual is continuous. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
open ScottSpectraReviewed

namespace WeakHypercontinuousLattices

universe u

theorem dualUpper_isLocallyCompact {L : Type u} [CompleteLattice L]
    (hc : IsContinuousLattice L) : @IsLocallyCompact Lᵒᵈ (upperTopology Lᵒᵈ) := by
  letI : TopologicalSpace Lᵒᵈ := upperTopology Lᵒᵈ
  have aux (U : Set Lᵒᵈ) (hU : IsOpen U) :
      ∀ x ∈ U, ∃ (V : Opens Lᵒᵈ) (K : Set Lᵒᵈ),
        x ∈ V ∧ (V : Set Lᵒᵈ) ⊆ K ∧ K ⊆ U ∧ IsCompact K ∧ IsSaturated K := by
    change GenerateOpen {s : Set Lᵒᵈ | ∃ a : Lᵒᵈ, (Iic a)ᶜ = s} U at hU
    induction hU with
    | basic U hb =>
      obtain ⟨a, rfl⟩ := hb
      intro x hx
      have hxa : ¬(OrderDual.ofDual a : L) ≤ OrderDual.ofDual x := hx
      have hb : ∃ b : L, WayBelow b (OrderDual.ofDual a) ∧
          ¬ b ≤ OrderDual.ofDual x := by
        by_contra! hn
        exact hxa ((hc.2 (OrderDual.ofDual a)).2.2 hn)
      obtain ⟨b, hba, hbx⟩ := hb
      let V : Opens Lᵒᵈ := ⟨(Iic (OrderDual.toDual b))ᶜ,
        isOpen_generateFrom_of_mem ⟨OrderDual.toDual b, rfl⟩⟩
      let K : Set Lᵒᵈ := {y | ¬ WayBelow b (OrderDual.ofDual y)}
      have hKclosed : IsClosed[scottTopology L] K :=
        @IsOpen.isClosed_compl L (scottTopology L) {y | WayBelow b y}
          (isScottOpen_wayAbove hc b)
      refine ⟨V, K, hbx, ?_, ?_, ?_, (upper_isSaturated_iff K).mpr ?_⟩
      · intro y hy hw
        have hby : b ≤ OrderDual.ofDual y := wayBelow_le hw
        exact hy hby
      · intro y hy hy'
        exact hy (wayBelow_mono le_rfl hba (show OrderDual.ofDual a ≤ OrderDual.ofDual y from hy'))
      · exact @upper_isCompact_of_dualScottClosed Lᵒᵈ _ K hKclosed
      · intro y z hyz hy hz
        exact hy (wayBelow_mono le_rfl hz
          (show OrderDual.ofDual z ≤ OrderDual.ofDual y from hyz))
    | univ =>
      intro x _
      letI : CompactSpace Lᵒᵈ := upper_compactSpace Lᵒᵈ
      exact ⟨⊤, univ, mem_univ x, subset_univ _, subset_rfl, isCompact_univ,
        (upper_isSaturated_iff _).mpr isUpperSet_univ⟩
    | inter U W _ _ ihU ihW =>
      intro x hx
      obtain ⟨V₁, K₁, hx₁, hV₁, hKU, hK₁, hs₁⟩ := ihU x hx.1
      obtain ⟨V₂, K₂, hx₂, hV₂, hKW, hK₂, hs₂⟩ := ihW x hx.2
      have hu₁ := (upper_isSaturated_iff K₁).mp hs₁
      have hu₂ := (upper_isSaturated_iff K₂).mp hs₂
      exact ⟨V₁ ⊓ V₂, K₁ ∩ K₂, ⟨hx₁, hx₂⟩, inter_subset_inter hV₁ hV₂,
        inter_subset_inter hKU hKW, upper_isCompact_inter hu₁ hu₂ hK₁ hK₂,
        (upper_isSaturated_iff _).mpr (hu₁.inter hu₂)⟩
    | sUnion S _ ih =>
      intro x hx
      obtain ⟨U, hUS, hxU⟩ := mem_sUnion.mp hx
      obtain ⟨V, K, h₁, h₂, h₃, h₄, h₅⟩ := ih U hUS x hxU
      exact ⟨V, K, h₁, h₂, h₃.trans (subset_sUnion_of_mem hUS), h₄, h₅⟩
  intro U x hx
  exact aux U U.isOpen x hx

/-- Source Theorem 2.2(a): the dual Scott space is sober, locally compact,
and consequently core compact. Quasi-sobriety plus T0 gives sobriety. -/
theorem source_dualScott_of_weak {L : Type u} [CompleteLattice L]
    (h : WeakHypercontinuous L) :
    @QuasiSober Lᵒᵈ (scottTopology Lᵒᵈ) ∧
      @T0Space Lᵒᵈ (scottTopology Lᵒᵈ) ∧
      @IsLocallyCompact Lᵒᵈ (scottTopology Lᵒᵈ) ∧
      @IsCoreCompact Lᵒᵈ (scottTopology Lᵒᵈ) := by
  have ht : scottTopology Lᵒᵈ = upperTopology Lᵒᵈ := h.2
  rw [ht]
  letI : TopologicalSpace Lᵒᵈ := upperTopology Lᵒᵈ
  have hlocal := dualUpper_isLocallyCompact h.1
  exact ⟨upper_quasiSober Lᵒᵈ, upper_t0Space Lᵒᵈ, hlocal,
    locallyCompact_isCoreCompact hlocal⟩

end WeakHypercontinuousLattices
