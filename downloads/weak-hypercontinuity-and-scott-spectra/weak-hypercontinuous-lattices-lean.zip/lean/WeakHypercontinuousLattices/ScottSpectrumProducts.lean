import ScottSpectraReviewed.SpectrumComap
import ScottSpectraReviewed.ContinuousProducts
import ScottSpectraReviewed.ScottNecessityProducts
import ScottSpectraReviewed.UpperScottEq
import Mathlib.Data.Sum.Order
import Mathlib.Topology.Homeomorph.Defs

set_option autoImplicit false

/-!
The actual completely-prime-filter spectra of products. The two injections
are inverse images along the coordinate projections. A proper completely prime
filter of the product belongs to exactly one component, detected by
`(⊤,⊥)` and `(⊥,⊤)`.
-/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v

namespace WeakHypercontinuousLattices
open ScottSpectraReviewed
namespace ScottSpectrumProducts

variable {L : Type u} {M : Type v} [CompleteLattice L] [CompleteLattice M]

private def leftProjection : FrameHom (L × M) L where
  toFun := Prod.fst
  map_inf' _ _ := rfl
  map_top' := rfl
  map_sSup' := Prod.fst_sSup

private def rightProjection : FrameHom (L × M) M where
  toFun := Prod.snd
  map_inf' _ _ := rfl
  map_top' := rfl
  map_sSup' := Prod.snd_sSup

def includeLeft (F : Spectrum L) : Spectrum (L × M) := Spectrum.comap leftProjection F

def includeRight (F : Spectrum M) : Spectrum (L × M) := Spectrum.comap rightProjection F

@[simp] theorem mem_includeLeft (F : Spectrum L) (p : L × M) :
    p ∈ includeLeft F ↔ p.1 ∈ F := Iff.rfl

@[simp] theorem mem_includeRight (F : Spectrum M) (p : L × M) :
    p ∈ includeRight F ↔ p.2 ∈ F := Iff.rfl

private theorem sSup_leftBottom_image (S : Set L) :
    sSup ((fun a : L => (a,(⊥ : M))) '' S) = (sSup S,⊥) := by
  apply Prod.ext
  · simp [Prod.fst_sSup, image_image]
  · rw [Prod.snd_sSup]
    apply le_antisymm (sSup_le ?_) bot_le
    rintro _ ⟨_,⟨a,ha,rfl⟩,rfl⟩
    exact le_rfl

private theorem sSup_rightBottom_image (S : Set M) :
    sSup ((fun b : M => ((⊥ : L),b)) '' S) = (⊥,sSup S) := by
  apply Prod.ext
  · rw [Prod.fst_sSup]
    apply le_antisymm (sSup_le ?_) bot_le
    rintro _ ⟨_,⟨b,hb,rfl⟩,rfl⟩
    exact le_rfl
  · simp [Prod.snd_sSup, image_image]

def restrictLeft (F : Spectrum (L × M)) (hF : ((⊤,⊥) : L × M) ∈ F) : Spectrum L where
  filter := (Order.IsPFilter.of_def (F := {a : L | ((a,⊥) : L × M) ∈ F})
    ⟨⊤,hF⟩
    (by
      intro a ha b hb
      refine ⟨a ⊓ b, ?_, inf_le_left, inf_le_right⟩
      exact F.mem_of_le (show (a,⊥) ⊓ (b,⊥) ≤ ((a ⊓ b,⊥) : L × M) from
        ⟨le_rfl,inf_le_left⟩) ((F.inf_mem_iff _ _).mpr ⟨ha,hb⟩))
    (by
      intro a b hab ha
      exact F.mem_of_le (show ((a,⊥) : L × M) ≤ (b,⊥) from ⟨hab,le_rfl⟩) ha)).toPFilter
  proper := F.proper
  completely_prime := by
    intro S h
    change ((sSup S,⊥) : L × M) ∈ F at h
    rw [← sSup_leftBottom_image] at h
    obtain ⟨_,⟨a,ha,rfl⟩,haF⟩ := F.completely_prime _ h
    exact ⟨a,ha,haF⟩

def restrictRight (F : Spectrum (L × M)) (hF : ((⊥,⊤) : L × M) ∈ F) : Spectrum M where
  filter := (Order.IsPFilter.of_def (F := {b : M | ((⊥,b) : L × M) ∈ F})
    ⟨⊤,hF⟩
    (by
      intro a ha b hb
      refine ⟨a ⊓ b, ?_, inf_le_left, inf_le_right⟩
      exact F.mem_of_le (show (⊥,a) ⊓ (⊥,b) ≤ ((⊥,a ⊓ b) : L × M) from
        ⟨inf_le_left,le_rfl⟩) ((F.inf_mem_iff _ _).mpr ⟨ha,hb⟩))
    (by
      intro a b hab ha
      exact F.mem_of_le (show ((⊥,a) : L × M) ≤ (⊥,b) from ⟨le_rfl,hab⟩) ha)).toPFilter
  proper := F.proper
  completely_prime := by
    intro S h
    change ((⊥,sSup S) : L × M) ∈ F at h
    rw [← sSup_rightBottom_image] at h
    obtain ⟨_,⟨a,ha,rfl⟩,haF⟩ := F.completely_prime _ h
    exact ⟨a,ha,haF⟩

@[simp] theorem includeLeft_restrictLeft (F : Spectrum (L × M)) (hF : ((⊤,⊥) : L × M) ∈ F) :
    includeLeft (restrictLeft F hF) = F := by
  apply SetLike.ext
  rintro ⟨a,b⟩
  change (((a,⊥) : L × M) ∈ F) ↔ (a,b) ∈ F
  constructor
  · exact F.mem_of_le ⟨le_rfl,bot_le⟩
  · intro hab
    have h := (F.inf_mem_iff (a,b) (⊤,⊥)).mpr ⟨hab,hF⟩
    have heq : ((a,b) : L × M) ⊓ (⊤,⊥) = (a,⊥) := Prod.ext (inf_top_eq a) (inf_bot_eq b)
    rwa [heq] at h

@[simp] theorem includeRight_restrictRight (F : Spectrum (L × M)) (hF : ((⊥,⊤) : L × M) ∈ F) :
    includeRight (restrictRight F hF) = F := by
  apply SetLike.ext
  rintro ⟨a,b⟩
  change (((⊥,b) : L × M) ∈ F) ↔ (a,b) ∈ F
  constructor
  · exact F.mem_of_le ⟨bot_le,le_rfl⟩
  · intro hab
    have h := (F.inf_mem_iff (a,b) (⊥,⊤)).mpr ⟨hab,hF⟩
    have heq : ((a,b) : L × M) ⊓ (⊥,⊤) = (⊥,b) := Prod.ext (inf_bot_eq a) (inf_top_eq b)
    rwa [heq] at h

theorem leftTop_mem_or_rightTop_mem (F : Spectrum (L × M)) :
    ((⊤,⊥) : L × M) ∈ F ∨ ((⊥,⊤) : L × M) ∈ F := by
  have hSup : sSup ({(⊤,⊥),(⊥,⊤)} : Set (L × M)) = (⊤ : L × M) := by
    rw [sSup_pair]
    exact Prod.ext (sup_bot_eq (⊤ : L)) (bot_sup_eq (⊤ : M))
  have h := F.top_mem
  rw [← hSup] at h
  obtain ⟨p,hp,hpF⟩ := F.completely_prime _ h
  rcases hp with (rfl | rfl)
  · exact Or.inl hpF
  · exact Or.inr hpF

theorem not_both_component_tops (F : Spectrum (L × M)) :
    ¬ (((⊤,⊥) : L × M) ∈ F ∧ ((⊥,⊤) : L × M) ∈ F) := by
  rintro ⟨hleft,hright⟩
  have hm := (F.inf_mem_iff (⊤,⊥) (⊥,⊤)).mpr ⟨hleft,hright⟩
  have heq : ((⊤,⊥) : L × M) ⊓ (⊥,⊤) = ⊥ :=
    Prod.ext (inf_bot_eq (⊤ : L)) (bot_inf_eq (⊤ : M))
  rw [heq] at hm
  exact F.bot_not_mem hm

def fromSum : (Spectrum L ⊕ Spectrum M) → Spectrum (L × M) :=
  Sum.elim includeLeft includeRight

theorem fromSum_surjective : Function.Surjective (fromSum (L := L) (M := M)) := by
  intro F
  rcases leftTop_mem_or_rightTop_mem F with hF | hF
  · exact ⟨Sum.inl (restrictLeft F hF),includeLeft_restrictLeft F hF⟩
  · exact ⟨Sum.inr (restrictRight F hF),includeRight_restrictRight F hF⟩

theorem fromSum_le_iff (F G : Spectrum L ⊕ Spectrum M) :
    fromSum F ≤ fromSum G ↔ F ≤ G := by
  cases F with
  | inl F =>
    cases G with
    | inl G =>
      rw [Sum.inl_le_inl_iff]
      constructor
      · intro h a ha
        exact h (show (((a,⊥) : L × M) ∈ includeLeft F) from ha)
      · intro h p hp
        exact h (show p.1 ∈ F from hp)
    | inr G =>
      simp only [Sum.not_inl_le_inr, iff_false]
      intro h
      exact G.bot_not_mem (h (show ((⊤,⊥) : L × M) ∈ includeLeft F from F.top_mem))
  | inr F =>
    cases G with
    | inl G =>
      simp only [Sum.not_inr_le_inl, iff_false]
      intro h
      exact G.bot_not_mem (h (show ((⊥,⊤) : L × M) ∈ includeRight F from F.top_mem))
    | inr G =>
      rw [Sum.inr_le_inr_iff]
      constructor
      · intro h a ha
        exact h (show (((⊥,a) : L × M) ∈ includeRight F) from ha)
      · intro h p hp
        exact h (show p.2 ∈ F from hp)

/-- The disjoint union carries the componentwise sum order (not the
lexicographic order). The map into the product spectrum is projection-comap
on each component. -/
def sumSpectrumOrderIso : Spectrum L ⊕ Spectrum M ≃o Spectrum (L × M) where
  toEquiv := Equiv.ofBijective fromSum ⟨
    fun F G h => le_antisymm ((fromSum_le_iff F G).mp h.le)
      ((fromSum_le_iff G F).mp h.ge), fromSum_surjective⟩
  map_rel_iff' := fromSum_le_iff _ _

/-- The actual topological disjoint sum of two specified topologies. -/
abbrev sumTopology {P : Type u} {Q : Type v}
    (tP : TopologicalSpace P) (tQ : TopologicalSpace Q) : TopologicalSpace (P ⊕ Q) :=
  letI : TopologicalSpace P := tP
  letI : TopologicalSpace Q := tQ
  inferInstance

abbrev spectrumSumTopology (L : Type u) (M : Type v)
    [CompleteLattice L] [CompleteLattice M] :
    TopologicalSpace (Spectrum L ⊕ Spectrum M) :=
  sumTopology Spectrum.hullKernelTopology Spectrum.hullKernelTopology

theorem continuous_fromSum :
    Continuous[spectrumSumTopology L M, Spectrum.hullKernelTopology]
      (fromSum (L := L) (M := M)) := by
  letI : TopologicalSpace (Spectrum L) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum M) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum (L × M)) := Spectrum.hullKernelTopology
  apply continuous_def.mpr
  intro S hS
  obtain ⟨p,rfl⟩ := hS
  exact isOpen_sum_iff.mpr ⟨⟨p.1,rfl⟩,⟨p.2,rfl⟩⟩

theorem isOpenMap_fromSum :
    @IsOpenMap (Spectrum L ⊕ Spectrum M) (Spectrum (L × M))
      (spectrumSumTopology L M) Spectrum.hullKernelTopology fromSum := by
  letI : TopologicalSpace (Spectrum L) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum M) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum (L × M)) := Spectrum.hullKernelTopology
  intro U hU
  obtain ⟨⟨a,ha⟩,⟨b,hb⟩⟩ := isOpen_sum_iff.mp hU
  have hm (z : Spectrum L ⊕ Spectrum M) :
      fromSum z ∈ Spectrum.hat (a,b) ↔ z ∈ U := by
    cases z with
    | inl G =>
      change G ∈ Spectrum.hat a ↔ G ∈ Sum.inl ⁻¹' U
      rw [ha]
    | inr G =>
      change G ∈ Spectrum.hat b ↔ G ∈ Sum.inr ⁻¹' U
      rw [hb]
  refine ⟨(a,b),?_⟩
  ext z
  constructor
  · intro hz
    obtain ⟨w,rfl⟩ := fromSum_surjective z
    exact ⟨w,(hm w).mp hz,rfl⟩
  · rintro ⟨w,hw,rfl⟩
    exact (hm w).mpr hw

/-- Same underlying equivalence as the order isomorphism, now between the
topological disjoint sum and the actual hull-kernel topology. -/
def sumSpectrumHomeomorph :
    @Homeomorph (Spectrum L ⊕ Spectrum M) (Spectrum (L × M))
      (spectrumSumTopology L M) Spectrum.hullKernelTopology := by
  letI : TopologicalSpace (Spectrum L) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum M) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum (L × M)) := Spectrum.hullKernelTopology
  exact sumSpectrumOrderIso.toEquiv.toHomeomorphOfContinuousOpen
    continuous_fromSum isOpenMap_fromSum

@[simp] theorem sumSpectrumHomeomorph_toEquiv :
    @Homeomorph.toEquiv (Spectrum L ⊕ Spectrum M) (Spectrum (L × M))
      (spectrumSumTopology L M) Spectrum.hullKernelTopology sumSpectrumHomeomorph =
      sumSpectrumOrderIso.toEquiv :=
  rfl

/-- The homeomorphism in the direction displayed in Proposition 4.3. -/
def spectrumProductHomeomorph :
    @Homeomorph (Spectrum (L × M)) (Spectrum L ⊕ Spectrum M)
      Spectrum.hullKernelTopology (spectrumSumTopology L M) :=
  @Homeomorph.symm (Spectrum L ⊕ Spectrum M) (Spectrum (L × M))
    (spectrumSumTopology L M) Spectrum.hullKernelTopology sumSpectrumHomeomorph

section ScottSum

variable {P : Type u} {Q : Type v} [PartialOrder P] [PartialOrder Q]

theorem scottContinuous_inl : ScottContinuous (Sum.inl : P → P ⊕ Q) := by
  intro D hne _ x hx
  constructor
  · rintro _ ⟨d,hd,rfl⟩
    exact Sum.inl_mono (hx.1 hd)
  · intro z hz
    cases z with
    | inl p =>
      exact Sum.inl_mono (hx.2 fun d hd =>
        Sum.inl_le_inl_iff.mp (hz (mem_image_of_mem Sum.inl hd)))
    | inr q =>
      obtain ⟨d,hd⟩ := hne
      exact False.elim (Sum.not_inl_le_inr (hz (mem_image_of_mem Sum.inl hd)))

theorem scottContinuous_inr : ScottContinuous (Sum.inr : Q → P ⊕ Q) := by
  have hswap := ScottNecessity.scottContinuous_orderIso (OrderIso.sumComm Q P)
  exact (scottContinuous_inl (P := Q) (Q := P)).comp hswap

private theorem dirSupInacc_inl {U : Set (P ⊕ Q)}
    (hU : DirSupInacc ((Sum.inl : P → P ⊕ Q) ⁻¹' U))
    {D : Set (P ⊕ Q)} (hne : D.Nonempty) (hdir : DirectedOn (· ≤ ·) D)
    {p : P} (hp : IsLUB D (Sum.inl p)) (hpU : Sum.inl p ∈ U) : (D ∩ U).Nonempty := by
  let E := (Sum.inl : P → P ⊕ Q) ⁻¹' D
  have hinl {q : P ⊕ Q} (hq : q ∈ D) : ∃ a : P, Sum.inl a = q := by
    have hle := hp.1 hq
    cases q with
    | inl a => exact ⟨a,rfl⟩
    | inr b => exact False.elim (Sum.not_inr_le_inl hle)
  have hEne : E.Nonempty := by
    obtain ⟨q,hq⟩ := hne
    obtain ⟨a,rfl⟩ := hinl hq
    exact ⟨a,hq⟩
  have hEdir : DirectedOn (· ≤ ·) E := by
    intro a ha b hb
    obtain ⟨q,hq,haq,hbq⟩ := hdir (Sum.inl a) ha (Sum.inl b) hb
    obtain ⟨c,rfl⟩ := hinl hq
    exact ⟨c,hq,Sum.inl_le_inl_iff.mp haq,Sum.inl_le_inl_iff.mp hbq⟩
  have hElub : IsLUB E p := by
    constructor
    · intro a ha
      exact Sum.inl_le_inl_iff.mp (hp.1 ha)
    · intro a ha
      have hpa : (Sum.inl p : P ⊕ Q) ≤ Sum.inl a := by
        apply hp.2
        intro q hq
        obtain ⟨b,rfl⟩ := hinl hq
        exact Sum.inl_mono (ha hq)
      exact Sum.inl_le_inl_iff.mp hpa
  obtain ⟨a,ha,haU⟩ := hU hEne hEdir hElub hpU
  exact ⟨Sum.inl a,ha,haU⟩

/-- Scott topology on the incomparable, componentwise sum of two orders is
their topological disjoint sum. A nonempty directed set having a supremum
cannot contain points from two components. -/
theorem scottTopology_eq_sum :
    scottTopology (P ⊕ Q) = sumTopology (scottTopology P) (scottTopology Q) := by
  letI : TopologicalSpace P := scottTopology P
  letI : TopologicalSpace Q := scottTopology Q
  apply TopologicalSpace.ext
  funext U
  apply propext
  constructor
  · intro hU
    exact isOpen_sum_iff.mpr ⟨ScottNecessity.isScottOpen_preimage scottContinuous_inl hU,
      ScottNecessity.isScottOpen_preimage scottContinuous_inr hU⟩
  · intro hU
    have hOpen := isOpen_sum_iff.mp hU
    have hleft := (isScottOpen_iff _).mp hOpen.1
    have hright := (isScottOpen_iff _).mp hOpen.2
    apply (isScottOpen_iff _).mpr
    constructor
    · intro s t hst hs
      cases s <;> cases t
      · exact hleft.1 (Sum.inl_le_inl_iff.mp hst) hs
      · exact False.elim (Sum.not_inl_le_inr hst)
      · exact False.elim (Sum.not_inr_le_inl hst)
      · exact hright.1 (Sum.inr_le_inr_iff.mp hst) hs
    · intro D hne hdir z hZ hzU
      cases z with
      | inl p => exact dirSupInacc_inl hleft.2 hne hdir hZ hzU
      | inr q =>
        let s := OrderIso.sumComm P Q
        have hne' : (s '' D).Nonempty := hne.image s
        have hdir' : DirectedOn (· ≤ ·) (s '' D) :=
          directedOn_image.mpr (hdir.mono s.monotone)
        have hZ' : IsLUB (s '' D) (Sum.inl q) := s.isLUB_image'.mpr hZ
        have hs : DirSupInacc ((Sum.inl : Q → Q ⊕ P) ⁻¹' (s.symm ⁻¹' U)) :=
          hright.2
        obtain ⟨_,⟨d,hd,rfl⟩,hdU⟩ := dirSupInacc_inl hs hne' hdir' hZ' hzU
        exact ⟨d,hd,by simpa only [mem_preimage,s.symm_apply_apply] using hdU⟩

end ScottSum

theorem spectrumSumTopology_eq_scott (hL : SpectrumIsScott L) (hM : SpectrumIsScott M) :
    spectrumSumTopology L M = scottTopology (Spectrum L ⊕ Spectrum M) := by
  unfold SpectrumIsScott at hL hM
  change sumTopology (Spectrum.hullKernelTopology (L := L))
    (Spectrum.hullKernelTopology (L := M)) = _
  rw [hL,hM,scottTopology_eq_sum]

/-- The last identification displayed in Proposition 4.3, with the sum
carrying its intrinsic order rather than an independently chosen topology. -/
def spectrumProductScottSumHomeomorph (hL : SpectrumIsScott L) (hM : SpectrumIsScott M) :
    @Homeomorph (Spectrum (L × M)) (Spectrum L ⊕ Spectrum M)
      Spectrum.hullKernelTopology (scottTopology (Spectrum L ⊕ Spectrum M)) := by
  rw [← spectrumSumTopology_eq_scott hL hM]
  exact spectrumProductHomeomorph

/-- The spectrum of a product is a Scott space whenever both factor
spectra are Scott spaces. The proof transports the same underlying map
through the two exact topologies. -/
theorem spectrumIsScott_prod (hL : SpectrumIsScott L) (hM : SpectrumIsScott M) :
    SpectrumIsScott (L × M) := by
  letI : TopologicalSpace (Spectrum L) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum M) := Spectrum.hullKernelTopology
  letI : TopologicalSpace (Spectrum (L × M)) := Spectrum.hullKernelTopology
  let e : (Spectrum L ⊕ Spectrum M) ≃o Spectrum (L × M) := sumSpectrumOrderIso
  change Spectrum.hullKernelTopology (L := L × M) = scottTopology (Spectrum (L × M))
  have hsum := spectrumSumTopology_eq_scott hL hM
  apply TopologicalSpace.ext
  funext U
  apply propext
  have hTransport : IsOpen[scottTopology (Spectrum (L × M))] U ↔
      IsOpen[scottTopology (Spectrum L ⊕ Spectrum M)] (e ⁻¹' U) :=
    OrderIsoTransfer.isOpen_scott_iff_preimage e U
  rw [← hsum] at hTransport
  refine ⟨fun hU => hTransport.mpr (hU.preimage continuous_fromSum),?_⟩
  intro hU
  have hpre := hTransport.mp hU
  have himage := isOpenMap_fromSum _ hpre
  change IsOpen (e '' (e ⁻¹' U)) at himage
  have heq : e '' (e ⁻¹' U) = U := e.surjective.image_preimage U
  rwa [heq] at himage

/-- The one-element lattice has an empty spectrum (no proper filters),
so its two topologies agree. -/
theorem spectrumIsScott_of_subsingleton (L : Type u)
    [CompleteLattice L] [Subsingleton L] : SpectrumIsScott L := by
  have hF (F : Spectrum L) : False :=
    F.bot_not_mem ((Subsingleton.elim (⊤ : L) (⊥ : L)) ▸ F.top_mem)
  change Spectrum.hullKernelTopology (L := L) = scottTopology (Spectrum L)
  apply TopologicalSpace.ext
  funext U
  have hU : U = ∅ := Set.eq_empty_iff_forall_notMem.mpr fun F _ => hF F
  rw [hU]
  exact propext ⟨fun _ => @isOpen_empty _ (scottTopology (Spectrum L)),
    fun _ => @isOpen_empty _ Spectrum.hullKernelTopology⟩

private theorem wayBelow_prod {a x : L} {b y : M}
    (ha : WayBelow a x) (hb : WayBelow b y) : WayBelow (a,b) (x,y) := by
  intro D hD p hp hle
  have hfst : NonemptyDirected (Prod.fst '' D) := ⟨hD.1.image _, hD.2.fst⟩
  have hsnd : NonemptyDirected (Prod.snd '' D) := ⟨hD.1.image _, hD.2.snd⟩
  obtain ⟨_,⟨d,hd,rfl⟩,had⟩ :=
    ha (Prod.fst '' D) hfst p.1 (isLUB_prod.mp hp).1 hle.1
  obtain ⟨_,⟨e,he,rfl⟩,hbe⟩ :=
    hb (Prod.snd '' D) hsnd p.2 (isLUB_prod.mp hp).2 hle.2
  obtain ⟨f,hf,hdf,hef⟩ := hD.2 d hd e he
  exact ⟨f,hf,⟨had.trans hdf.1,hbe.trans hef.2⟩⟩

/-- Continuous complete lattices admit the usual order-theoretic binary
product, with no spectrum assumption. -/
theorem continuousLattice_prod (hL : IsContinuousLattice L) (hM : IsContinuousLattice M) :
    IsContinuousLattice (L × M) := by
  refine ⟨completeLattice_isDcpo _, fun p => ?_,⟩
  constructor
  · refine ⟨⟨⊥,wayBelow_bot _ _⟩,?_⟩
    intro a ha b hb
    exact ⟨a ⊔ b,wayBelow_sup ha hb,le_sup_left,le_sup_right⟩
  · constructor
    · intro x hx
      exact wayBelow_le hx
    · intro q hq
      constructor
      · apply (hL.2 p.1).2.2
        intro a ha
        exact (hq (wayBelow_prod ha (wayBelow_bot M p.2))).1
      · apply (hM.2 p.2).2.2
        intro b hb
        exact (hq (wayBelow_prod (wayBelow_bot L p.1) hb)).2

/-- The closedness part of Proposition 4.3, on the actual coordinatewise
product. The displayed spectrum homeomorphism is
`spectrumProductHomeomorph`; its Scott-sum identification is
`scottTopology_eq_sum`. -/
theorem source_scspec_product_membership
    (hL : IsDistributive L ∧ IsContinuousLattice L ∧ SpectrumIsScott L)
    (hM : IsDistributive M ∧ IsContinuousLattice M ∧ SpectrumIsScott M) :
    IsDistributive (L × M) ∧ IsContinuousLattice (L × M) ∧ SpectrumIsScott (L × M) :=
  ⟨fun a b c => Prod.ext (hL.1 a.1 b.1 c.1) (hM.1 a.2 b.2 c.2),
    continuousLattice_prod hL.2.1 hM.2.1, spectrumIsScott_prod hL.2.2 hM.2.2⟩

/-- Every one-point complete lattice belongs to the Scott-spectrum
subcategory. No particular coding of the singleton lattice is imposed. -/
theorem source_scspec_terminal (L : Type u) [CompleteLattice L] [Subsingleton L] :
    IsDistributive L ∧ IsContinuousLattice L ∧ SpectrumIsScott L := by
  refine ⟨fun _ _ _ => Subsingleton.elim _ _, ?_, spectrumIsScott_of_subsingleton L⟩
  refine ⟨completeLattice_isDcpo _, fun x => ?_⟩
  have hx : WayBelow x x := by
    have heq : (⊥ : L) = x := Subsingleton.elim _ _
    exact heq ▸ wayBelow_bot L x
  refine ⟨⟨⟨x,hx⟩,fun a ha b hb => ⟨x,hx,wayBelow_le ha,wayBelow_le hb⟩⟩,?_⟩
  exact ⟨fun _ ha => wayBelow_le ha,fun _ hu => hu hx⟩

end ScottSpectrumProducts
end WeakHypercontinuousLattices
