import ScottSpectraReviewed.LawsonBasics
import ScottSpectraReviewed.TopologicalModels
import Mathlib.Order.GaloisConnection.Basic

/-! The exact maps in Lemma 3.3, `lem:canonical-adjunction`.

The Scott continuity of the upper adjoint uses a compact Lawson sandwich
instead of the relative Alexander subbase lemma. The underlying lattice, dual
Scott topology, maps, and adjunction are unchanged. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace WeakHypercontinuousLattices
open ScottSpectraReviewed

/-- The actual open-set lattice of the Scott space on the dual order. -/
abbrev DualScottOpens (M : Type u) [Preorder M] :=
  @Opens Mᵒᵈ (scottTopology Mᵒᵈ)

/-- `I(a) = M \\ ↑a` with the upper set computed in the original order. -/
def canonicalI (M : Type u) [Preorder M] (a : M) : DualScottOpens M :=
  @Opens.mk Mᵒᵈ (scottTopology Mᵒᵈ) ((Ici a)ᶜ : Set M) (by
    letI : TopologicalSpace Mᵒᵈ := scottTopology Mᵒᵈ
    letI : Topology.IsScott Mᵒᵈ univ := ⟨rfl⟩
    change IsOpen ((Iic (OrderDual.toDual a))ᶜ : Set Mᵒᵈ)
    exact isClosed_Iic.isOpen_compl)

/-- `R(U) = inf (M \\ U)`, including the empty complement. -/
def canonicalR (M : Type u) [CompleteLattice M] (U : DualScottOpens M) : M :=
  sInf ((U : Set Mᵒᵈ)ᶜ : Set M)

theorem canonical_gc (M : Type u) [CompleteLattice M] :
    GaloisConnection (canonicalI M) (canonicalR M) := by
  intro a U
  change ((Ici a)ᶜ : Set M) ⊆ (U : Set Mᵒᵈ) ↔
    a ≤ sInf ((U : Set Mᵒᵈ)ᶜ : Set M)
  constructor
  · intro h
    apply le_sInf
    intro x hx
    by_contra hax
    exact hx (h hax)
  · intro ha x hx
    by_contra hxU
    exact hx (ha.trans (sInf_le hxU))

theorem canonicalI_sSup (M : Type u) [CompleteLattice M] (S : Set M) :
    canonicalI M (sSup S) = sSup (canonicalI M '' S) :=
  ((canonical_gc M).isLUB_l_image (isLUB_sSup S)).unique (isLUB_sSup _)

theorem canonicalR_sSup_fibre (M : Type u) [CompleteLattice M] (U : DualScottOpens M) :
    canonicalR M U = sSup {a : M | canonicalI M a ≤ U} :=
  le_antisymm (le_sSup ((canonical_gc M _ _).2 le_rfl))
    (sSup_le fun a ha => (canonical_gc M a U).1 ha)

@[simp] theorem canonicalR_canonicalI (M : Type u) [CompleteLattice M] (a : M) :
    canonicalR M (canonicalI M a) = a := by
  change sInf (((Ici a)ᶜ)ᶜ) = a
  rw [compl_compl]
  exact le_antisymm (sInf_le (show a ∈ Ici a from le_rfl)) (le_sInf fun _ hb => hb)

theorem canonicalI_scottContinuous (M : Type u) [CompleteLattice M] :
    ScottContinuous (canonicalI M) := by
  intro D _ _ x hx
  exact (canonical_gc M).isLUB_l_image hx

/-- The dual Scott continuity follows from the upper-adjoint property alone. -/
theorem canonicalR_dualScottContinuous (M : Type u) [CompleteLattice M] :
    ScottContinuous (OrderDual.toDual ∘ canonicalR M ∘ OrderDual.ofDual :
      (DualScottOpens M)ᵒᵈ → Mᵒᵈ) := by
  intro D _ _ x hx
  exact (canonical_gc M).dual.isLUB_l_image hx

/-- For `a ≪ b`, `I(a) ⊆ M \\ {x | a ≪ x} ⊆ I(b)`. The middle set is
Lawson closed and thus compact also in the coarser dual Scott topology. -/
theorem canonicalI_wayBelow (M : Type u) [CompleteLattice M]
    (hcontinuous : IsContinuousLattice M)
    (hweak : scottTopology Mᵒᵈ = upperTopology Mᵒᵈ)
    {a b : M} (hab : WayBelow a b) : WayBelow (canonicalI M a) (canonicalI M b) := by
  let K : Set M := {x | WayBelow a x}ᶜ
  letI : TopologicalSpace M := lawsonTopology M
  letI : CompactSpace M := lawson_compactSpace
  have hK : IsCompact K := (isLawsonOpen_wayAbove hcontinuous a).isClosed_compl.isCompact
  have ht : lawsonTopology M ≤ scottTopology Mᵒᵈ := by
    rw [hweak]
    exact Topology.lawson_le_lower
  have hKd : @IsCompact Mᵒᵈ (scottTopology Mᵒᵈ) K := by
    have hi : Continuous[lawsonTopology M, scottTopology Mᵒᵈ] (id : M → M) :=
      continuous_id_of_le ht
    simpa only [image_id] using
      (@IsCompact.image M M (lawsonTopology M) (scottTopology Mᵒᵈ)
        K id hK hi)
  apply @wayBelow_opens_of_compact_sandwich Mᵒᵈ (scottTopology Mᵒᵈ)
    (canonicalI M a) (canonicalI M b) K ?_ ?_ hKd
  · intro x hx hax
    exact hx (wayBelow_le hax)
  · intro x hx hbx
    exact hx (wayBelow_mono le_rfl hab hbx)

/-- A left adjoint preserving way-below has Scott-continuous right adjoint
when the original lattice is continuous; applied to the exact source maps. -/
theorem canonicalR_scottContinuous (M : Type u) [CompleteLattice M]
    (hcontinuous : IsContinuousLattice M)
    (hweak : scottTopology Mᵒᵈ = upperTopology Mᵒᵈ) :
    ScottContinuous (canonicalR M) := by
  intro D hne hdir U hU
  refine ⟨?_, ?_⟩
  · rintro _ ⟨V, hVD, rfl⟩
    exact (canonical_gc M).monotone_u (hU.1 hVD)
  · intro c hc
    apply (hcontinuous.2 (canonicalR M U)).2.2
    intro a ha
    have hIa := canonicalI_wayBelow M hcontinuous hweak ha
    obtain ⟨V, hVD, haV⟩ :=
      hIa D ⟨hne, hdir⟩ U hU ((canonical_gc M).l_u_le U)
    exact ((canonical_gc M a V).1 haV).trans (hc ⟨V, hVD, rfl⟩)

/-- Source-facing interface for Lemma 3.3, with the original maps and all
of its conclusions, not merely a retraction by unspecified witnesses. -/
theorem lem_canonical_adjunction (M : Type u) [CompleteLattice M]
    (hcontinuous : IsContinuousLattice M)
    (hweak : scottTopology Mᵒᵈ = upperTopology Mᵒᵈ) :
    (∀ S : Set M, canonicalI M (sSup S) = sSup (canonicalI M '' S)) ∧
    (∀ U : DualScottOpens M, canonicalR M U = sSup {a : M | canonicalI M a ≤ U}) ∧
    GaloisConnection (canonicalI M) (canonicalR M) ∧
    canonicalR M ∘ canonicalI M = id ∧
    ScottContinuous (canonicalI M) ∧ ScottContinuous (canonicalR M) ∧
    ScottContinuous (OrderDual.toDual ∘ canonicalR M ∘ OrderDual.ofDual :
      (DualScottOpens M)ᵒᵈ → Mᵒᵈ) :=
  ⟨canonicalI_sSup M, canonicalR_sSup_fibre M, canonical_gc M,
    funext (canonicalR_canonicalI M), canonicalI_scottContinuous M,
    canonicalR_scottContinuous M hcontinuous hweak, canonicalR_dualScottContinuous M⟩

end WeakHypercontinuousLattices
