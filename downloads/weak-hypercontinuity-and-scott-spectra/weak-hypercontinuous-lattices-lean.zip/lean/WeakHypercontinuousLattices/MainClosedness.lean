import WeakHypercontinuousLattices.DualLocalCompactness
import WeakHypercontinuousLattices.CoreCompactProducts
import WeakHypercontinuousLattices.CanonicalAdjunction
import WeakHypercontinuousLattices.ScottFunctionLattice
import ScottSpectraReviewed.ContinuousProducts
import Mathlib.Order.GaloisConnection.Basic

/-! The pointwise function lattice of the manuscript, the lifted canonical
bi-Scott quotient, and arbitrary-product closure. The code is source-bound
to the current TeX manuscript, not obtained from the November spectrum iff. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
open ScottSpectraReviewed ScottSpectraReviewed.ScottNecessity

namespace WeakHypercontinuousLattices

universe u v w

theorem weakHypercontinuous_orderIso {A : Type u} {B : Type v}
    [CompleteLattice A] [CompleteLattice B]
    (e : A ≃o B) (hA : WeakHypercontinuous A) : WeakHypercontinuous B :=
  ⟨continuousDcpo_of_scottRetract hA.1 e.symm e
    (scottContinuous_orderIso e.symm) (scottContinuous_orderIso e) e.apply_symm_apply,
    OrderIsoTransfer.scott_eq_upper e.dual hA.2⟩

/-- Theorem 3.4, including products indexed by any type, not just finite products. -/
theorem source_weak_products {ι : Type u} {P : ι → Type v}
    [∀ i, CompleteLattice (P i)] (h : ∀ i, WeakHypercontinuous (P i)) :
    WeakHypercontinuous (∀ i, P i) :=
  ⟨continuousLattice_pi (fun i => (h i).1),
    dualTopologyEquality_pi (fun i => (source_dualScott_of_weak (h i)).2.2.2)
      (fun i => (h i).2)⟩

/-- The intrinsic Scott space of a continuous dcpo is core compact. -/
theorem coreCompact_scott_of_continuous {D : Type u} [PartialOrder D]
    (hd : IsContinuousDcpo D) : @IsCoreCompact D (scottTopology D) := by
  letI : TopologicalSpace D := scottTopology D
  apply coreCompact_iff_neighborhood.mpr
  intro U x hx
  obtain ⟨a, ha, haU⟩ := ((isScottOpen_iff (U : Set D)).mp U.isOpen).2
    (hd.2 x).1.1 (hd.2 x).1.2 (hd.2 x).2 hx
  let V : Opens D := ⟨{y | WayBelow a y}, isScottOpen_wayAbove hd a⟩
  refine ⟨V, ha, ?_⟩
  intro S hS W hW hUW
  have ha' : a ∈ W := hUW haU
  have haUnion : a ∈ (sSup S : Opens D) := (hW.sSup_eq.symm ▸ ha')
  obtain ⟨C,hCS,haC⟩ := Opens.mem_sSup.mp haUnion
  exact ⟨C,hCS,fun y hy => ((isScottOpen_iff (C : Set D)).mp C.isOpen).1
    (wayBelow_le (show WayBelow a y from hy)) haC⟩

/-- Lemma 3.6. The intermediate space is the actual lattice of Scott-open
subsets: the order isomorphism is by evaluation membership. -/
theorem source_open_set_target {D : Type u} {M : Type v}
    [PartialOrder D] [CompleteLattice M]
    (hD : @IsCoreCompact D (scottTopology D)) (hM : WeakHypercontinuous M) :
    WeakHypercontinuous (ScottFunction D (DualScottOpens M)) := by
  letI : TopologicalSpace D := scottTopology D
  letI : TopologicalSpace Mᵒᵈ := scottTopology Mᵒᵈ
  obtain ⟨_,_,hLocal,hCore⟩ := source_dualScott_of_weak hM
  have hCoreProd : @IsCoreCompact (D × Mᵒᵈ) (scottTopology (D × Mᵒᵈ)) := by
    rw [scottTopology_eq_prod_of_coreCompact hCore]
    exact isCoreCompact_prod_of_isCoreCompact_isLocallyCompact hD hLocal
  exact weakHypercontinuous_orderIso (scottFunctionOpensIso D Mᵒᵈ).symm
    (CoreCompactScottClosed.scottOpens_continuous_and_dualTopologyEquality hCoreProd)

/-- Theorem 3.7. The printed assumption that D is a dcpo is retained;
the Scott-open membership argument itself works with any partial order. -/
theorem source_function_space {D : Type u} {M : Type v}
    [PartialOrder D] [CompleteLattice M]
    (_dcpoD : IsDcpo D) (hD : @IsCoreCompact D (scottTopology D))
    (hM : WeakHypercontinuous M) :
    WeakHypercontinuous (ScottFunction D M) := by
  have hi := canonicalI_scottContinuous M
  have hr := canonicalR_scottContinuous M hM.1 hM.2
  let i := scottPostcompose D (canonicalI M) hi
  let r := scottPostcompose D (canonicalR M) hr
  have hi' : ScottContinuous i :=
    scottPostcompose_scottContinuous D (canonicalI M) hi
  have hr' : ScottContinuous r :=
    scottPostcompose_scottContinuous D (canonicalR M) hr
  have hgc : GaloisConnection i r := scottPostcompose_gc D _ _ hi hr (canonical_gc M)
  have hri : Function.LeftInverse r i := scottPostcompose_leftInverse D _ _ hi hr
    (canonicalR_canonicalI M)
  let rd : (ScottFunction D (DualScottOpens M))ᵒᵈ → (ScottFunction D M)ᵒᵈ :=
    fun x => OrderDual.toDual (r (OrderDual.ofDual x))
  have hrd : ScottContinuous
      (α := (ScottFunction D (DualScottOpens M))ᵒᵈ) (β := (ScottFunction D M)ᵒᵈ) rd :=
    fun S _ _ x hx => hgc.dual.isLUB_l_image hx
  have hN := source_open_set_target hD hM
  have hc : IsContinuousLattice (ScottFunction D M) :=
    continuousDcpo_of_scottRetract hN.1 i r hi' hr' hri
  exact source_biScott_quotient hN hc r hri.surjective
    (continuous_scott hr') (continuous_scott hrd)

/-- The exponential closure needed by Theorem 3.8. The canonically defined
evaluation and currying (including the inverse laws) are in ScottFunctionLattice. -/
theorem source_weak_exponential {L : Type u} {M : Type v}
    [CompleteLattice L] [CompleteLattice M]
    (hL : WeakHypercontinuous L) (hM : WeakHypercontinuous M) :
    WeakHypercontinuous (ScottFunction L M) :=
  source_function_space hL.1.1 (coreCompact_scott_of_continuous hL.1) hM

end WeakHypercontinuousLattices
