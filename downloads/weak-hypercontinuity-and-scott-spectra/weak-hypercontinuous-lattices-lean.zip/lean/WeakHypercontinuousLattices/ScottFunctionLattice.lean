import ScottSpectraReviewed.ScottNecessityProducts
import Mathlib.Order.GaloisConnection.Basic

/-! The actual Scott-continuous maps and pointwise order in the manuscript.
Scott continuity ranges over all nonempty directed sets, and the supremum
construction proves the pointwise equation for every family, including the
empty family. Infima are not asserted to be pointwise. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v w

namespace WeakHypercontinuousLattices
open ScottSpectraReviewed

abbrev ScottFunction (D : Type u) (M : Type v) [Preorder D] [Preorder M] :=
  {f : D → M // ScottContinuous f}

section CompleteTarget

variable {D : Type u} {M : Type v} [Preorder D] [CompleteLattice M]

def scottFunctionSup (S : Set (ScottFunction D M)) : ScottFunction D M :=
  ⟨fun d => sSup ((fun f : ScottFunction D M => f.1 d) '' S), by
    intro E hne hd x hx
    constructor
    · rintro _ ⟨d, hdE, rfl⟩
      apply sSup_le
      rintro _ ⟨f, hf, rfl⟩
      exact (f.2.monotone (hx.1 hdE)).trans (le_sSup ⟨f, hf, rfl⟩)
    · intro y hy
      apply sSup_le
      rintro _ ⟨f, hf, rfl⟩
      apply (f.2 hne hd hx).2
      rintro _ ⟨d, hdE, rfl⟩
      exact (le_sSup (s := (fun g : ScottFunction D M => g.1 d) '' S)
        ⟨f, hf, rfl⟩).trans (hy ⟨d, hdE, rfl⟩)⟩

instance : SupSet (ScottFunction D M) := ⟨scottFunctionSup⟩

theorem scottFunctionSup_isLUB (S : Set (ScottFunction D M)) :
    IsLUB S (scottFunctionSup S) := by
  constructor
  · intro f hf d
    exact le_sSup ⟨f, hf, rfl⟩
  · intro g hg d
    apply sSup_le
    rintro _ ⟨f, hf, rfl⟩
    exact hg hf d

instance : CompleteLattice (ScottFunction D M) :=
  completeLatticeOfSup _ scottFunctionSup_isLUB

/-- Lemma 3.5, including its stronger all-set pointwise join equation. -/
theorem scottFunction_sSup_apply (S : Set (ScottFunction D M)) (d : D) :
    (sSup S).1 d = sSup ((fun f : ScottFunction D M => f.1 d) '' S) := rfl

theorem scottFunction_isLUB_iff_apply (S : Set (ScottFunction D M))
    (f : ScottFunction D M) :
    IsLUB S f ↔ ∀ d : D, IsLUB ((fun g : ScottFunction D M => g.1 d) '' S) (f.1 d) := by
  constructor
  · intro h d
    rw [← (isLUB_sSup S).unique h, scottFunction_sSup_apply]
    exact isLUB_sSup _
  · intro h
    suffices hEq : sSup S = f by rw [← hEq]; exact isLUB_sSup _
    apply Subtype.ext
    funext d
    change (sSup S).1 d = f.1 d
    rw [scottFunction_sSup_apply]
    exact (isLUB_sSup _).unique (h d)

theorem scottFunction_apply_scottContinuous (d : D) :
    ScottContinuous (fun f : ScottFunction D M => f.1 d) := by
  intro S _ _ f h
  exact (scottFunction_isLUB_iff_apply S f).mp h d

end CompleteTarget

section Composition

variable (D : Type u) [Preorder D]
variable {M : Type v} {N : Type w}

def scottPostcompose [Preorder M] [Preorder N] (g : M → N) (hg : ScottContinuous g)
    (f : ScottFunction D M) : ScottFunction D N :=
  ⟨g ∘ f.1, f.2.comp hg⟩

@[simp] theorem scottPostcompose_apply [Preorder M] [Preorder N]
    (g : M → N) (hg : ScottContinuous g) (f : ScottFunction D M) (d : D) :
    (scottPostcompose D g hg f).1 d = g (f.1 d) := rfl

theorem scottPostcompose_scottContinuous [CompleteLattice M] [CompleteLattice N]
    (g : M → N) (hg : ScottContinuous g) :
    ScottContinuous (scottPostcompose D g hg) := by
  intro S hn hd f hf
  apply (scottFunction_isLUB_iff_apply _ _).mpr
  intro d
  have he := scottFunction_apply_scottContinuous (M := M) d
  have h := (he.comp hg) hn hd hf
  rw [image_image]
  exact h

theorem scottPostcompose_gc [Preorder M] [Preorder N]
    (i : M → N) (r : N → M) (hi : ScottContinuous i) (hr : ScottContinuous r)
    (h : GaloisConnection i r) :
    GaloisConnection (scottPostcompose D i hi) (scottPostcompose D r hr) := by
  intro f g
  exact ⟨fun a d => (h _ _).mp (a d), fun a d => (h _ _).mpr (a d)⟩

theorem scottPostcompose_leftInverse [Preorder M] [Preorder N]
    (i : M → N) (r : N → M) (hi : ScottContinuous i) (hr : ScottContinuous r)
    (h : Function.LeftInverse r i) :
    Function.LeftInverse (scottPostcompose D r hr) (scottPostcompose D i hi) := by
  intro f
  exact Subtype.ext (funext fun d => h (f.1 d))

end Composition

section Evaluation

variable {A : Type w} {D : Type u} {M : Type v}
  [Preorder A] [Preorder D] [CompleteLattice M]

theorem scottFunction_eval_scottContinuous :
    ScottContinuous (fun p : ScottFunction D M × D => p.1.1 p.2) := by
  intro S hn hd p hp
  obtain ⟨f, x⟩ := p
  obtain ⟨hF, hX⟩ := isLUB_prod.mp hp
  constructor
  · rintro _ ⟨s, hs, rfl⟩
    exact ((hp.1 hs).1 s.2).trans (f.2.monotone (hp.1 hs).2)
  · intro y hy
    apply ((scottFunction_isLUB_iff_apply _ _).mp hF x).2
    rintro _ ⟨_, ⟨s, hs, rfl⟩, rfl⟩
    have hdir : DirectedOn (· ≤ ·) (Prod.snd '' S) :=
      directedOn_image.mpr (hd.mono (fun _ _ h => h.2))
    apply (s.1.2 (hn.image Prod.snd) hdir hX).2
    rintro _ ⟨_, ⟨t, ht, rfl⟩, rfl⟩
    obtain ⟨z, hz, hsz, htz⟩ := hd s hs t ht
    exact ((hsz.1 t.2).trans (z.1.2.monotone htz.2)).trans (hy ⟨z, hz, rfl⟩)

def scottFunctionCurry (f : ScottFunction (A × D) M) :
    ScottFunction A (ScottFunction D M) :=
  ⟨fun a => ⟨fun d => f.1 (a, d),
      ((ScottContinuous.const a).prodMk ScottContinuous.id).comp f.2⟩, by
    intro S hn hd a ha
    apply (scottFunction_isLUB_iff_apply _ _).mpr
    intro d
    rw [image_image]
    exact ((ScottContinuous.id.prodMk (ScottContinuous.const d)).comp f.2) hn hd ha⟩

def scottFunctionUncurry (f : ScottFunction A (ScottFunction D M)) :
    ScottFunction (A × D) M :=
  ⟨fun p => (f.1 p.1).1 p.2,
    (((ScottContinuous.fst.comp f.2).prodMk ScottContinuous.snd)).comp
      scottFunction_eval_scottContinuous⟩

def scottFunctionCurryIso : ScottFunction (A × D) M ≃o
    ScottFunction A (ScottFunction D M) where
  toFun := scottFunctionCurry
  invFun := scottFunctionUncurry
  left_inv f := Subtype.ext (funext (fun ⟨_, _⟩ => rfl))
  right_inv f := Subtype.ext (funext (fun _ => Subtype.ext (funext (fun _ => rfl))))
  map_rel_iff' := by
    intro f g
    exact ⟨fun h p => h p.1 p.2, fun h a d => h (a, d)⟩

end Evaluation

section OpenSets

variable (D : Type u) (P : Type v) [Preorder D] [Preorder P]

local instance : TopologicalSpace P := scottTopology P
local instance : TopologicalSpace (D × P) := scottTopology (D × P)

abbrev ScottOpenLattice (Q : Type w) [Preorder Q] :=
  @Opens Q (scottTopology Q)

/-- The membership relation associated to a Scott map into Scott opens.
This is the actual open set corresponding to the manuscript's Sierpiński
currying composite. -/
def scottOpenOfFunction (f : ScottFunction D (ScottOpenLattice P)) :
    ScottOpenLattice (D × P) :=
  @Opens.mk (D × P) (scottTopology (D × P))
    {dp | dp.2 ∈ (f.1 dp.1 : Set P)} (by
      apply (isScottOpen_iff _).mpr
      constructor
      · intro x y hxy hx
        have hmem : x.2 ∈ (f.1 y.1 : Set P) := f.2.monotone hxy.1 hx
        exact ((isScottOpen_iff _).mp (f.1 y.1).2).1 hxy.2 hmem
      · intro S hn hd x hx hxf
        obtain ⟨hD, hP⟩ := isLUB_prod.mp hx
        have hdD : DirectedOn (· ≤ ·) (Prod.fst '' S) :=
          directedOn_image.mpr (hd.mono (fun _ _ h => h.1))
        have hdP : DirectedOn (· ≤ ·) (Prod.snd '' S) :=
          directedOn_image.mpr (hd.mono (fun _ _ h => h.2))
        have hfu : sSup (f.1 '' (Prod.fst '' S)) = f.1 x.1 :=
          (isLUB_sSup _).unique (f.2 (hn.image Prod.fst) hdD hD)
        change x.2 ∈ (f.1 x.1 : Set P) at hxf
        rw [← hfu] at hxf
        obtain ⟨V, ⟨_, ⟨s, hs, rfl⟩, rfl⟩, hxV⟩ := Opens.mem_sSup.mp hxf
        obtain ⟨_, ⟨t, ht, rfl⟩, htV⟩ :=
          ((isScottOpen_iff _).mp (f.1 s.1).2).2 (hn.image Prod.snd) hdP hP hxV
        obtain ⟨z, hz, hsz, htz⟩ := hd s hs t ht
        refine ⟨z, hz, ?_⟩
        exact ((isScottOpen_iff _).mp (f.1 z.1).2).1 htz.2
          (f.2.monotone hsz.1 htV))

def scottOpenSlice (U : ScottOpenLattice (D × P)) (d : D) :
    ScottOpenLattice P :=
  @Opens.mk P (scottTopology P) {p | (d, p) ∈ (U : Set (D × P))}
    (ScottNecessity.isScottOpen_preimage
      ((ScottContinuous.const d).prodMk ScottContinuous.id) U.2)

def scottFunctionOfOpen (U : ScottOpenLattice (D × P)) :
    ScottFunction D (ScottOpenLattice P) :=
  ⟨scottOpenSlice D P U, by
    intro S hn hd x hx
    constructor
    · rintro _ ⟨d, hdS, rfl⟩ p hp
      exact ((isScottOpen_iff _).mp U.2).1
        (show (d, p) ≤ (x, p) from ⟨hx.1 hdS, le_rfl⟩) hp
    · intro V hV p hp
      have hslice : IsOpen[scottTopology D] {d | (d, p) ∈ (U : Set (D × P))} :=
        ScottNecessity.isScottOpen_preimage
          (ScottContinuous.id.prodMk (ScottContinuous.const p)) U.2
      obtain ⟨d, hdS, hdp⟩ := ((isScottOpen_iff _).mp hslice).2 hn hd hx hp
      exact hV ⟨d, hdS, rfl⟩ hdp⟩

def scottFunctionOpensIso : ScottFunction D (ScottOpenLattice P) ≃o
    ScottOpenLattice (D × P) where
  toFun := scottOpenOfFunction D P
  invFun := scottFunctionOfOpen D P
  left_inv f := by
    apply Subtype.ext
    funext d
    ext p
    rfl
  right_inv U := by
    ext p
    rfl
  map_rel_iff' := by
    intro f g
    exact ⟨fun h d p hp => h (show (d, p) ∈ scottOpenOfFunction D P f from hp),
      fun h p hp => h p.1 hp⟩

end OpenSets

section Retract

variable {P : Type u} {Q : Type v} [PartialOrder P] [PartialOrder Q]

/-- Exact Scott-retract transfer for arbitrary continuous dcpos. The
way-below set is the entire source set, not only the images of approximants;
those images are proved cofinal in it. -/
theorem continuousDcpo_of_scottRetract (hP : IsContinuousDcpo P)
    (i : Q → P) (r : P → Q) (hi : ScottContinuous i) (hr : ScottContinuous r)
    (hri : Function.LeftInverse r i) :
    IsContinuousDcpo Q := by
  have hQ : IsDcpo Q := by
    intro S hS
    obtain ⟨p, hp⟩ := hP.1 (i '' S)
      ⟨hS.1.image i, directedOn_image.mpr (hS.2.mono @hi.monotone)⟩
    have h := hr (hS.1.image i) (directedOn_image.mpr (hS.2.mono @hi.monotone)) hp
    have hEq : r '' (i '' S) = S := by
      ext s
      constructor
      · rintro ⟨_, ⟨y, hy, rfl⟩, rfl⟩
        simpa only [hri y] using hy
      · intro hs
        exact ⟨i s, ⟨s, hs, rfl⟩, hri s⟩
    exact ⟨r p, hEq ▸ h⟩
  refine ⟨hQ, ?_⟩
  intro q
  let W : Set P := {p | WayBelow p (i q)}
  have hW := hP.2 (i q)
  let T := r '' W
  have hT : NonemptyDirected T :=
    ⟨hW.1.1.image r, directedOn_image.mpr (hW.1.2.mono @hr.monotone)⟩
  have hTq : IsLUB T q := by
    simpa only [hri q] using hr hW.1.1 hW.1.2 hW.2
  have hinc : T ⊆ {a | WayBelow a q} := by
    rintro _ ⟨p, hp, rfl⟩ S hS x hx hqx
    have hp' : WayBelow p (i q) := hp
    obtain ⟨_, ⟨s, hs, rfl⟩, hps⟩ := hp' (i '' S)
      ⟨hS.1.image i, directedOn_image.mpr (hS.2.mono @hi.monotone)⟩
      (i x) (hi hS.1 hS.2 hx) (hi.monotone hqx)
    exact ⟨s, hs, (hri s) ▸ hr.monotone hps⟩
  refine ⟨⟨hT.1.mono hinc, ?_⟩, ?_, ?_⟩
  · intro a ha b hb
    obtain ⟨a', ha', haa'⟩ := ha T hT q hTq le_rfl
    obtain ⟨b', hb', hbb'⟩ := hb T hT q hTq le_rfl
    obtain ⟨c, hc, hac, hbc⟩ := hT.2 a' ha' b' hb'
    exact ⟨c, hinc hc, haa'.trans hac, hbb'.trans hbc⟩
  · intro a ha
    exact wayBelow_le ha
  · intro b hb
    exact hTq.2 fun _ ht => hb (hinc ht)

end Retract

end WeakHypercontinuousLattices
