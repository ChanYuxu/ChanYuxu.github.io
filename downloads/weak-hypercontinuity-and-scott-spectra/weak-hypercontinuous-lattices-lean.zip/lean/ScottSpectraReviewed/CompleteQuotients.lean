import ScottSpectraReviewed.HomAdjoints

/-! Source Lemma `lem:quotient` (frozen TeX lines 945--982). The source route
is used: transfer the frame law, approximate by q(images of elements way-below
the actual left adjoint), and pull dual Scott opens back along the actual
upper-continuous right adjoint. -/

noncomputable section
open Set
open scoped Topology
universe u v

namespace ScottSpectraReviewed

/-- Every upper-topology open is Scott open, for the full topologies. -/
theorem scott_le_upperTopology (P : Type u) [Preorder P] :
    scottTopology P ≤ upperTopology P := by
  apply TopologicalSpace.le_generateFrom_iff_subset_isOpen.mpr
  rintro _ ⟨a, rfl⟩
  exact ((isScottClosed_iff (Set.Iic a)).mpr
    ⟨isLowerSet_Iic a, dirSupClosed_Iic a⟩).isOpen_compl

namespace CompleteHom

variable {A : Type u} {B : Type v} [CompleteLattice A] [CompleteLattice B]

theorem quotient_isFrame (hA : IsFrame A) (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) : IsFrame B := by
  intro b S
  obtain ⟨a, rfl⟩ := hq b
  have hS : q '' (q ⁻¹' S) = S := hq.image_preimage S
  calc
    q a ⊓ sSup S = q (a ⊓ sSup (q ⁻¹' S)) := by rw [map_inf, map_sSup, hS]
    _ = sSup (q '' ((fun c => a ⊓ c) '' (q ⁻¹' S))) := by rw [hA, map_sSup]
    _ = sSup ((fun c => q a ⊓ c) '' S) := by
      congr 1
      ext c
      constructor
      · rintro ⟨_, ⟨d, hd, rfl⟩, rfl⟩
        exact ⟨q d, hd, (map_inf q a d).symm⟩
      · rintro ⟨b, hb, rfl⟩
        obtain ⟨d, rfl⟩ := hq b
        exact ⟨a ⊓ d, ⟨d, hb, rfl⟩, map_inf q a d⟩

/-- The source's way-below implication through the actual left adjoint. -/
theorem wayBelow_map_of_wayBelow_leftAdjoint (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) {a : A} {b : B}
    (ha : WayBelow a (leftAdjoint q b)) : WayBelow (q a) b := by
  intro D hD x hx hbx
  have hLD := monotone_image_nonemptyDirected (leftAdjoint q)
    (leftAdjoint_monotone q) D hD
  obtain ⟨_, ⟨d, hd, rfl⟩, had⟩ := ha (leftAdjoint q '' D) hLD
    (leftAdjoint q x) (leftAdjoint_isLUB q D x hx) (leftAdjoint_monotone q hbx)
  refine ⟨d, hd, ?_⟩
  simpa only [q_leftAdjoint q hq] using OrderHomClass.monotone q had

def quotientApproximants (q : CompleteLatticeHom A B) (b : B) : Set B :=
  q '' {a : A | WayBelow a (leftAdjoint q b)}

theorem quotientApproximants_nonemptyDirected (hcont : IsContinuousLattice A)
    (q : CompleteLatticeHom A B) (b : B) : NonemptyDirected (quotientApproximants q b) :=
  monotone_image_nonemptyDirected q (OrderHomClass.monotone q) _ (hcont.2 _).1

theorem quotientApproximants_isLUB (hcont : IsContinuousLattice A)
    (q : CompleteLatticeHom A B) (hq : Function.Surjective q) (b : B) :
    IsLUB (quotientApproximants q b) b := by
  have h := map_isLUB q {a : A | WayBelow a (leftAdjoint q b)}
    (leftAdjoint q b) (hcont.2 _).2
  rwa [q_leftAdjoint q hq] at h

theorem quotientApproximants_wayBelow (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) (b : B) :
    quotientApproximants q b ⊆ {c : B | WayBelow c b} := by
  rintro _ ⟨a, ha, rfl⟩
  exact wayBelow_map_of_wayBelow_leftAdjoint q hq ha

theorem quotient_isContinuousLattice (hcont : IsContinuousLattice A)
    (q : CompleteLatticeHom A B) (hq : Function.Surjective q) : IsContinuousLattice B := by
  refine ⟨completeLattice_isDcpo B, ?_⟩
  intro b
  have hD := quotientApproximants_nonemptyDirected hcont q b
  have hSup := quotientApproximants_isLUB hcont q hq b
  have hWB := quotientApproximants_wayBelow q hq b
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · obtain ⟨c, hc⟩ := hD.1
    exact ⟨c, hWB hc⟩
  · intro c hc d hd
    obtain ⟨e, he, hce⟩ := hc (quotientApproximants q b) hD b hSup le_rfl
    obtain ⟨f, hf, hdf⟩ := hd (quotientApproximants q b) hD b hSup le_rfl
    obtain ⟨g, hg, heg, hfg⟩ := hD.2 e he f hf
    exact ⟨g, hWB hg, hce.trans heg, hdf.trans hfg⟩
  · constructor
    · intro c hc
      exact wayBelow_le hc
    · intro c hc
      exact hSup.2 (fun d hd => hc (hWB hd))

theorem map_scottContinuous (q : CompleteLatticeHom A B) : ScottContinuous q := by
  intro D _ _ a ha
  exact map_isLUB q D a ha

theorem preimage_isScottOpen (q : CompleteLatticeHom A B)
    (W : Set B) (hW : IsOpen[scottTopology B] W) :
    IsOpen[scottTopology A] (q ⁻¹' W) := by
  rw [isScottOpen_iff] at hW ⊢
  refine ⟨?_, ?_⟩
  · intro a b hab ha
    exact hW.1 (OrderHomClass.monotone q hab) ha
  · intro D hne hdir a ha hqa
    have hD := monotone_image_nonemptyDirected q (OrderHomClass.monotone q) D ⟨hne, hdir⟩
    obtain ⟨_, ⟨d, hd, rfl⟩, hqd⟩ := hW.2 hD.1 hD.2 (map_isLUB q D a ha) hqa
    exact ⟨d, hd, hqd⟩

/-- The exact subbasic inverse-image identity from the source. -/
theorem rightAdjoint_preimage_compl_Ici (q : CompleteLatticeHom A B) (a : A) :
    rightAdjoint q ⁻¹' (Set.Ici a)ᶜ = (Set.Ici (q a))ᶜ := by
  ext b
  exact not_congr ((rightAdjoint_gc q) a b).symm

def rightAdjointDual (q : CompleteLatticeHom A B) : OrderDual B → OrderDual A :=
  fun b => OrderDual.toDual (rightAdjoint q (OrderDual.ofDual b))

theorem rightAdjoint_upperContinuous (q : CompleteLatticeHom A B) :
    Continuous[upperTopology (OrderDual B), upperTopology (OrderDual A)]
      (rightAdjointDual q) := by
  apply continuous_generateFrom_iff.mpr
  rintro _ ⟨a, rfl⟩
  have heq : rightAdjointDual q ⁻¹' (Set.Iic a)ᶜ =
      (Set.Iic (OrderDual.toDual (q (OrderDual.ofDual a))))ᶜ := by
    ext b
    change (¬ OrderDual.ofDual a ≤ rightAdjoint q (OrderDual.ofDual b)) ↔
      ¬ q (OrderDual.ofDual a) ≤ OrderDual.ofDual b
    exact not_congr ((rightAdjoint_gc q) _ _).symm
  rw [heq]
  exact TopologicalSpace.isOpen_generateFrom_of_mem
    ⟨OrderDual.toDual (q (OrderDual.ofDual a)), rfl⟩

theorem quotient_dualTopologyEquality (hdual : DualTopologyEquality A)
    (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    DualTopologyEquality B := by
  change scottTopology (OrderDual B) = upperTopology (OrderDual B)
  apply le_antisymm
  · exact scott_le_upperTopology _
  · intro W hW
    letI : TopologicalSpace (OrderDual A) := upperTopology (OrderDual A)
    letI : TopologicalSpace (OrderDual B) := upperTopology (OrderDual B)
    have hpre := preimage_isScottOpen (CompleteLatticeHom.dual q) W hW
    change scottTopology (OrderDual A) = upperTopology (OrderDual A) at hdual
    rw [hdual] at hpre
    have hopen := (rightAdjoint_upperContinuous q).isOpen_preimage _ hpre
    have heq : rightAdjointDual q ⁻¹'
        ((CompleteLatticeHom.dual q) ⁻¹' W) = W := by
      ext b
      change q (rightAdjoint q b) ∈ W ↔ b ∈ W
      rw [q_rightAdjoint q hq]
      rfl
    rwa [heq] at hopen

end CompleteHom

/-- Exact source-facing Lemma `lem:quotient`. B is not assumed continuous or
a frame, and its dual topology equality is derived rather than stored. -/
theorem source_quotient {A : Type u} {B : Type v} [CompleteLattice A] [CompleteLattice B]
    (hA : IsFrame A) (hcont : IsContinuousLattice A) (hdual : DualTopologyEquality A)
    (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    IsFrame B ∧ IsContinuousLattice B ∧ DualTopologyEquality B :=
  ⟨CompleteHom.quotient_isFrame hA q hq, CompleteHom.quotient_isContinuousLattice hcont q hq,
    CompleteHom.quotient_dualTopologyEquality hdual q hq⟩

end ScottSpectraReviewed
