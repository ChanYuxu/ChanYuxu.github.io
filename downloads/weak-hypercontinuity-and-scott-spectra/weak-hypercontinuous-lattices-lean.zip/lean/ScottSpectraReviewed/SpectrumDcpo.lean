import ScottSpectraReviewed.Spectrum

noncomputable section
open Set
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace Spectrum
variable {L : Type u} [CompleteLattice L]

/-- The supremum is the actual union of the directed family of filters. -/
def directedUnion (D : Set (Spectrum L)) (hD : NonemptyDirected D) : Spectrum L where
  filter := (Order.IsPFilter.of_def
    (F := {a | ∃ F ∈ D, a ∈ F})
    (by
      obtain ⟨F, hF⟩ := hD.1
      exact ⟨⊤, F, hF, F.top_mem⟩)
    (by
      rintro a ⟨F, hF, ha⟩ b ⟨G, hG, hb⟩
      obtain ⟨H, hH, hFH, hGH⟩ := hD.2 F hF G hG
      exact ⟨a ⊓ b, ⟨H, hH, (H.inf_mem_iff a b).mpr ⟨hFH ha, hGH hb⟩⟩,
        inf_le_left, inf_le_right⟩)
    (by
      rintro a b hab ⟨F, hF, ha⟩
      exact ⟨F, hF, F.mem_of_le hab ha⟩)).toPFilter
  proper := by
    rintro ⟨F, _, hF⟩
    exact F.proper hF
  completely_prime := by
    rintro S ⟨F, hF, hSF⟩
    obtain ⟨a, ha, haF⟩ := F.completely_prime S hSF
    exact ⟨a, ha, F, hF, haF⟩

@[simp] theorem mem_directedUnion (D : Set (Spectrum L)) (hD : NonemptyDirected D)
    (a : L) : a ∈ directedUnion D hD ↔ ∃ F ∈ D, a ∈ F := Iff.rfl

theorem directedUnion_isLUB (D : Set (Spectrum L)) (hD : NonemptyDirected D) :
    IsLUB D (directedUnion D hD) := by
  constructor
  · intro F hF a ha
    exact ⟨F, hF, ha⟩
  · intro G hG a ha
    obtain ⟨F, hF, haF⟩ := ha
    exact hG hF haF

theorem isDcpo : IsDcpo (Spectrum L) :=
  fun D hD => ⟨directedUnion D hD, directedUnion_isLUB D hD⟩

theorem hat_isScottOpen (a : L) : IsOpen[scottTopology (Spectrum L)] (hat a) := by
  rw [isScottOpen_iff]
  refine ⟨?_, ?_⟩
  · intro F G hFG hF
    exact hFG hF
  · intro D hne hdir F hF ha
    have e : F = directedUnion D ⟨hne, hdir⟩ :=
      hF.unique (directedUnion_isLUB D ⟨hne, hdir⟩)
    change a ∈ F at ha
    rw [e] at ha
    obtain ⟨G, hG, haG⟩ := ha
    exact ⟨G, hG, haG⟩

/-- Lean orders topologies oppositely to inclusion of open sets. This
inequality says that every hull-kernel open is Scott open. -/
theorem scott_le_hullKernel :
    scottTopology (Spectrum L) ≤ hullKernelTopology (L := L) := by
  rintro U ⟨a, rfl⟩
  exact hat_isScottOpen a

end Spectrum
end ScottSpectraReviewed
