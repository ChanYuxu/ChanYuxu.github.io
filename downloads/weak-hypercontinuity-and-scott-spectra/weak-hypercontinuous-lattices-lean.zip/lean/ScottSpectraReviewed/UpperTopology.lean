import ScottSpectraReviewed.LawsonBasics
import Mathlib.Topology.Sober

/-! The upper topology on a complete lattice, source lines 452--477.
The compact-upper/dual-Scott-closed equivalence is an independently proved
background bridge also needed by the separately indexed canonical repair.
It assumes neither continuity nor distributivity. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed

variable {L : Type u} [CompleteLattice L]

theorem upper_specializes_iff (x y : L) :
    @Specializes L (upperTopology L) x y ↔ y ≤ x := by
  letI : TopologicalSpace L := upperTopology L
  letI : Topology.IsUpper L := ⟨rfl⟩
  rw [specializes_iff_mem_closure, Topology.IsUpper.closure_singleton]
  rfl

theorem upper_t0Space (L : Type u) [CompleteLattice L] :
    @T0Space L (upperTopology L) := by
  letI : TopologicalSpace L := upperTopology L
  letI : Topology.IsUpper L := ⟨rfl⟩
  infer_instance

/-- Every dual Scott-closed set is compact for the upper topology. Generic
Lawson compactness, not continuity, is the only compactness premise used. -/
theorem upper_isCompact_of_dualScottClosed {K : Set L}
    (hK : IsClosed[scottTopology Lᵒᵈ] K) :
    @IsCompact L (upperTopology L) K := by
  have hcompact : @IsCompact L (lawsonTopology Lᵒᵈ) K := by
    letI : TopologicalSpace L := lawsonTopology Lᵒᵈ
    letI : CompactSpace L := @lawson_compactSpace Lᵒᵈ _
    have hclosed : IsClosed K := hK.mono Topology.lawson_le_scott
    exact hclosed.isCompact
  have hcont : Continuous[lawsonTopology Lᵒᵈ, upperTopology L] (id : L → L) :=
    continuous_id_iff_le.mpr Topology.lawson_le_lower
  simpa only [image_id] using
    (@IsCompact.image L L (lawsonTopology Lᵒᵈ) (upperTopology L) K id hcompact hcont)

/-- A compact upper set is closed under every nonempty filtered infimum.
The complements of principal lower sets form a directed cover if the proposed
infimum were outside the upper set; compactness then gives a contradiction. -/
theorem dualScottClosed_of_upper_isCompact {K : Set L}
    (hupper : IsUpperSet K) (hK : @IsCompact L (upperTopology L) K) :
    IsClosed[scottTopology Lᵒᵈ] K := by
  apply (isScottClosed_iff (P := Lᵒᵈ) K).mpr
  refine ⟨hupper, ?_⟩
  intro D hDK hne hdir x hx
  letI : TopologicalSpace L := upperTopology L
  letI : Nonempty D := hne.to_subtype
  by_contra hxK
  let U : D → Set L := fun d => (Iic (OrderDual.ofDual d.val))ᶜ
  have hU : ∀ d, IsOpen (U d) := fun d =>
    isOpen_generateFrom_of_mem ⟨OrderDual.ofDual d.val, rfl⟩
  have hcover : K ⊆ ⋃ d, U d := by
    intro k hk
    by_contra hkU
    have hkD : ∀ d ∈ D, k ≤ d := by
      intro d hd
      by_contra hkd
      exact hkU (mem_iUnion.mpr ⟨⟨d,hd⟩, by exact hkd⟩)
    have hkx : k ≤ x := hx.2 hkD
    exact hxK (hupper hkx hk)
  have hUdir : Directed (· ⊆ ·) U := by
    intro d e
    obtain ⟨f, hf, hfd, hfe⟩ := hdir d d.property e e.property
    refine ⟨⟨f,hf⟩, ?_, ?_⟩
    · intro k hk hkf
      exact hk (hkf.trans hfd)
    · intro k hk hkf
      exact hk (hkf.trans hfe)
  obtain ⟨d, hd⟩ := hK.elim_directed_cover U hU hcover hUdir
  exact hd (hDK d.property) le_rfl

/-- Exact generic bridge for upper subsets; no topology equality, frame or
continuity is assumed. -/
theorem upper_isCompact_iff_dualScottClosed {K : Set L} (hupper : IsUpperSet K) :
    @IsCompact L (upperTopology L) K ↔ IsClosed[scottTopology Lᵒᵈ] K :=
  ⟨dualScottClosed_of_upper_isCompact hupper, upper_isCompact_of_dualScottClosed⟩

theorem upper_compactSpace (L : Type u) [CompleteLattice L] :
    @CompactSpace L (upperTopology L) := by
  letI : TopologicalSpace L := upperTopology L
  letI : Topology.IsUpper L := ⟨rfl⟩
  classical
  constructor
  apply isCompact_of_finite_subcover
  intro ι U hU hcover
  obtain ⟨i,hbot⟩ := mem_iUnion.mp (hcover (mem_univ (⊥ : L)))
  refine ⟨{i}, ?_⟩
  intro x _
  exact mem_iUnion₂.mpr ⟨i, by simp,
    (Topology.IsUpper.isUpperSet_of_isOpen (hU i)) bot_le hbot⟩

/-- The source proves coherence by the continuous join map. The equivalent
dual-closed-set proof is retained as an additional useful API. -/
theorem upper_isCompact_inter {K H : Set L} (hKupper : IsUpperSet K)
    (hHupper : IsUpperSet H) (hK : @IsCompact L (upperTopology L) K)
    (hH : @IsCompact L (upperTopology L) H) :
    @IsCompact L (upperTopology L) (K ∩ H) := by
  letI : TopologicalSpace Lᵒᵈ := scottTopology Lᵒᵈ
  exact upper_isCompact_of_dualScottClosed
    ((dualScottClosed_of_upper_isCompact hKupper hK).inter
      (dualScottClosed_of_upper_isCompact hHupper hH))

theorem upper_continuous_sup :
    @Continuous (L × L) L
      (@instTopologicalSpaceProd L L (upperTopology L) (upperTopology L))
      (upperTopology L) (fun p => p.1 ⊔ p.2) := by
  letI : TopologicalSpace L := upperTopology L
  letI : Topology.IsUpper L := ⟨rfl⟩
  exact continuous_sup

/-- The fixed-meet right adjoint specified in the printed frame argument. -/
def frameMeetRightAdjoint (a b : L) : L := sSup {z : L | a ⊓ z ≤ b}

theorem frameMeetRightAdjoint_gc (hL : IsFrame L) (a : L) :
    GaloisConnection (fun z => a ⊓ z) (frameMeetRightAdjoint a) := by
  intro z b
  constructor
  · intro h
    exact le_sSup h
  · intro h
    apply (inf_le_inf_left a h).trans
    change a ⊓ sSup {w : L | a ⊓ w ≤ b} ≤ b
    rw [hL]
    apply sSup_le
    rintro _ ⟨w,hw,rfl⟩
    exact hw

/-- Fixed meet is upper-continuous for every frame; the right adjoint is
constructed, not assumed. -/
theorem upper_continuous_inf_left (hL : IsFrame L) (a : L) :
    Continuous[upperTopology L, upperTopology L] (fun z => a ⊓ z) := by
  letI : TopologicalSpace L := upperTopology L
  apply continuous_generateFrom_iff.mpr
  rintro U ⟨b,rfl⟩
  have heq : (fun z : L => a ⊓ z) ⁻¹' (Iic b)ᶜ =
      (Iic (frameMeetRightAdjoint a b))ᶜ := by
    ext z
    exact not_congr (frameMeetRightAdjoint_gc hL a z b)
  rw [heq]
  exact isOpen_generateFrom_of_mem ⟨_,rfl⟩

/-- Source-route coherence proof using precisely K∩H = {k∨h}. -/
theorem upper_isCompact_inter_via_sup {K H : Set L} (hKupper : IsUpperSet K)
    (hHupper : IsUpperSet H) (hK : @IsCompact L (upperTopology L) K)
    (hH : @IsCompact L (upperTopology L) H) :
    @IsCompact L (upperTopology L) (K ∩ H) := by
  letI : TopologicalSpace L := upperTopology L
  have heq : (fun p : L × L => p.1 ⊔ p.2) '' (K ×ˢ H) = K ∩ H := by
    ext x
    constructor
    · rintro ⟨⟨k,h⟩, ⟨hk,hh⟩, rfl⟩
      exact ⟨hKupper le_sup_left hk, hHupper le_sup_right hh⟩
    · intro hx
      exact ⟨(x,x), hx, sup_idem x⟩
  rw [← heq]
  exact (hK.prod hH).image upper_continuous_sup

/-- The generic point of an irreducible closed set is its actual supremum.
The proof uses the finite principal-lower-set closed subbasis, rather than
assuming a representation theorem or sobriety of the upper topology. -/
theorem upper_irreducible_closed_eq_Iic {C : Set L}
    (hCclosed : IsClosed[upperTopology L] C)
    (hCirr : @IsIrreducible L (upperTopology L) C) : C = Iic (sSup C) := by
  letI : TopologicalSpace L := upperTopology L
  letI : Topology.IsUpper L := ⟨rfl⟩
  classical
  apply subset_antisymm
  · intro x hx
    exact le_sSup hx
  · intro x hx
    by_contra hxC
    obtain ⟨V, ⟨T,hT,rfl⟩, hxV, hVC⟩ :=
      Topology.IsUpper.isTopologicalBasis.exists_subset_of_mem_open hxC hCclosed.isOpen_compl
    have hcover : C ⊆ (lowerClosure T : Set L) := by
      intro c hc
      by_contra hcT
      exact hVC hcT hc
    let F : Finset (Set L) := hT.toFinset.image (fun t => Iic t)
    have hFc : ∀ Z ∈ F, IsClosed Z := by
      intro Z hZ
      obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hZ
      exact isClosed_Iic
    have hCF : C ⊆ ⋃₀ (F : Set (Set L)) := by
      intro c hc
      obtain ⟨t,ht,hct⟩ := hcover hc
      apply mem_sUnion.mpr
      refine ⟨Iic t, ?_, hct⟩
      exact Finset.mem_image.mpr ⟨t, hT.mem_toFinset.mpr ht, rfl⟩
    obtain ⟨Z,hZF,hCZ⟩ := isIrreducible_iff_sUnion_isClosed.mp hCirr F hFc hCF
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hZF
    have hSup : sSup C ≤ t := sSup_le hCZ
    exact hxV ⟨t, hT.mem_toFinset.mp ht, hx.trans hSup⟩

theorem upper_quasiSober (L : Type u) [CompleteLattice L] :
    @QuasiSober L (upperTopology L) := by
  letI : TopologicalSpace L := upperTopology L
  letI : Topology.IsUpper L := ⟨rfl⟩
  constructor
  intro C hCirr hCclosed
  refine ⟨sSup C, ?_⟩
  change closure {sSup C} = C
  rw [Topology.IsUpper.closure_singleton]
  exact (upper_irreducible_closed_eq_Iic hCclosed hCirr).symm

/-- Source-facing first part of `lem:upper-topology`. The final
locally-compact-frame/Scott-equality implication belongs to the later web
criterion and is not asserted by this basic wrapper. -/
theorem source_upper_topology_basic (L : Type u) [CompleteLattice L] :
    @CompactSpace L (upperTopology L) ∧
    @QuasiSober L (upperTopology L) ∧ @T0Space L (upperTopology L) ∧
    ∀ K H : Set L, IsUpperSet K → IsUpperSet H →
      @IsCompact L (upperTopology L) K → @IsCompact L (upperTopology L) H →
      @IsCompact L (upperTopology L) (K ∩ H) :=
  ⟨upper_compactSpace L, upper_quasiSober L, upper_t0Space L,
    fun _ _ hK hH hKc hHc => upper_isCompact_inter_via_sup hK hH hKc hHc⟩

end ScottSpectraReviewed
