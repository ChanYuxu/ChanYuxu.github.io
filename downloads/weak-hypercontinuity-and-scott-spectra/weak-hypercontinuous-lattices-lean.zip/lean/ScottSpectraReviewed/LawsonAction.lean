import ScottSpectraReviewed.LawsonBaire
import Mathlib.Topology.Compactness.Compact
import Mathlib.Topology.Baire.LocallyCompactRegular
import Mathlib.Topology.MetricSpace.Basic

/-! Lawson (1974), Lemma 2.1, Proposition 2.2 and the compact-metric
action theorem 3.2. The actual action is an unbundled map with an explicit
associativity law; this preserves the source's semigroup/right-identity
generality instead of silently requiring a unital monoid action.
The general compact-Hausdorff theorem 5.1 is a subsequent quotient step.
-/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace LawsonAction

section Separation
variable {S : Type u} {X : Type v} [Semigroup S]
variable [TopologicalSpace S] [TopologicalSpace X] [T2Space X]

/-- Source Lemma 2.1: a genuine lower continuity point separates the actual
action image of a product neighborhood from a neighborhood of y. -/
theorem source_lemma_2_1 (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (htrans : ∀ r : S, Continuous (fun s : S => r*s))
    (hfixed : ∀ r, Continuous (π r))
    (s : S) (x y : X) (r : S)
    (hneq : π r (π s x) ≠ π r y)
    (hjoint : ContinuousAt (fun p : S × X => π p.1 p.2) (r*s,x)) :
    ∃ W U V, IsOpen W ∧ s ∈ W ∧ IsOpen U ∧ x ∈ U ∧
      IsOpen V ∧ y ∈ V ∧ ∀ w ∈ W, ∀ z ∈ U, π w z ∉ V := by
  obtain ⟨A,B,hA,hB,hax,hyb,hdis⟩ := t2_separation hneq
  have hc : Continuous (fun p : S × X => (r*p.1,p.2)) :=
    ((htrans r).comp continuous_fst).prodMk continuous_snd
  have hcomp : ContinuousAt (fun p : S × X => π r (π p.1 p.2)) (s,x) := by
    have hc' : ContinuousAt ((fun p : S × X => π p.1 p.2) ∘
        (fun p : S × X => (r*p.1,p.2))) (s,x) :=
      ContinuousAt.comp_of_eq hjoint hc.continuousAt rfl
    have heq : ((fun p : S × X => π p.1 p.2) ∘
        (fun p : S × X => (r*p.1,p.2))) =
        (fun p : S × X => π r (π p.1 p.2)) := by
      funext p
      exact hassoc r p.1 p.2
    rw [heq] at hc'
    exact hc'
  have hpre : {p : S × X | π r (π p.1 p.2) ∈ A} ∈ 𝓝 (s,x) :=
    hcomp.eventually (hA.mem_nhds hax)
  obtain ⟨W,U,hW,hsW,hU,hxU,hWU⟩ := mem_nhds_prod_iff'.mp hpre
  refine ⟨W,U,π r ⁻¹' B,hW,hsW,hU,hxU,hB.preimage (hfixed r),hyb,?_⟩
  intro w hw z hz hbad
  exact Set.disjoint_left.mp hdis (hWU (show (w,z) ∈ W ×ˢ U from ⟨hw,hz⟩)) hbad

/-- Source Proposition 2.2: the finite subcover of the compact complement
constructs one product neighborhood in every prescribed action neighborhood. -/
theorem source_proposition_2_2 [CompactSpace X] (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (htrans : ∀ r : S, Continuous (fun s : S => r*s))
    (hfixed : ∀ r, Continuous (π r))
    (s : S) (x : X)
    (hseparators : ∀ y : X, π s x ≠ y → ∃ r : S,
      π r (π s x) ≠ π r y ∧
        ContinuousAt (fun p : S × X => π p.1 p.2) (r*s,x)) :
    ContinuousAt (fun p : S × X => π p.1 p.2) (s,x) := by
  apply continuousAt_def.mpr
  intro A hA
  obtain ⟨P,hPA,hPopen,hxP⟩ := mem_nhds_iff.mp hA
  have hex : ∀ y : (Pᶜ : Set X), ∃ W U V, IsOpen W ∧ s ∈ W ∧
      IsOpen U ∧ x ∈ U ∧ IsOpen V ∧ (y : X) ∈ V ∧
        ∀ w ∈ W, ∀ z ∈ U, π w z ∉ V := by
    intro y
    have hne : π s x ≠ y := fun h => y.property (h ▸ hxP)
    obtain ⟨r,hr,hjoint⟩ := hseparators y hne
    exact source_lemma_2_1 π hassoc htrans hfixed s x y r hr hjoint
  choose W U V hW hsW hU hxU hV hyV havoid using hex
  have hcover : Pᶜ ⊆ ⋃ y : (Pᶜ : Set X), V y := by
    intro y hy
    exact mem_iUnion.mpr ⟨⟨y,hy⟩,hyV ⟨y,hy⟩⟩
  obtain ⟨F,hF⟩ := hPopen.isClosed_compl.isCompact.elim_finite_subcover V hV hcover
  have hWn : (⋂ y ∈ F, W y) ∈ 𝓝 s :=
    (biInter_finset_mem F).mpr (fun y _ => (hW y).mem_nhds (hsW y))
  have hUn : (⋂ y ∈ F, U y) ∈ 𝓝 x :=
    (biInter_finset_mem F).mpr (fun y _ => (hU y).mem_nhds (hxU y))
  apply Filter.mem_of_superset (prod_mem_nhds hWn hUn)
  rintro ⟨w,z⟩ ⟨hw,hz⟩
  apply hPA
  by_contra hbad
  obtain ⟨y,hyF,hy⟩ := mem_iUnion₂.mp (hF hbad)
  exact havoid y w (mem_iInter₂.mp hw y hyF) z (mem_iInter₂.mp hz y hyF) hy

end Separation

section MetricAction
variable {S : Type u} {X : Type v} [Semigroup S]
variable [TopologicalSpace S] [BaireSpace S] [MetricSpace X] [CompactSpace X]

/-- Source Theorem 3.2, with its explicitly allowed Baire generality. The
metric assumption belongs only to this intermediate action codomain. -/
theorem source_theorem_3_2 (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (htrans : ∀ r : S, Continuous (fun s : S => r*s))
    (hleft : ∀ x : X, Continuous (fun s : S => π s x))
    (hright : ∀ s : S, Continuous (π s))
    (s₀ : S) (hSsurj : Function.Surjective (fun r : S => r*s₀))
    (hXsurj : Function.Surjective (π s₀)) (x : X) :
    ContinuousAt (fun p : S × X => π p.1 p.2) (s₀,x) := by
  apply source_proposition_2_2 π hassoc htrans hright s₀ x
  intro y hxy
  obtain ⟨z,hz⟩ := hXsurj y
  obtain ⟨A,B,hA,hB,hax,hyb,hdis⟩ := t2_separation hxy
  let U : Set S := {t | π t x ∈ A ∧ π t z ∈ B}
  have hU : IsOpen U := (hA.preimage (hleft x)).inter (hB.preimage (hleft z))
  have hsU : s₀ ∈ U := ⟨hax,hz.symm ▸ hyb⟩
  have hdense : Dense {t : S | ContinuousAt (fun p : S × X => π p.1 p.2) (t,x)} :=
    dense_of_mem_residual (LawsonBaire.residual_jointContinuousAt π x hleft hright)
  obtain ⟨t,hUt,ht⟩ := hdense.inter_open_nonempty U hU ⟨s₀,hsU⟩
  obtain ⟨r,hr⟩ := hSsurj t
  change r*s₀=t at hr
  have htneq : π t x ≠ π t z := by
    intro h
    exact Set.disjoint_left.mp hdis hUt.1 (h.symm ▸ hUt.2)
  refine ⟨r,?_,?_⟩
  · intro h
    apply htneq
    calc
      π t x = π (r*s₀) x := by rw [hr]
      _ = π r (π s₀ x) := hassoc r s₀ x
      _ = π r y := h
      _ = π r (π s₀ z) := by rw [hz]
      _ = π (r*s₀) z := (hassoc r s₀ z).symm
      _ = π t z := by rw [hr]
  · simpa only [hr] using ht

/-- Source Corollary 3.3 with a specified right identity, not an added
left-identity or unital-action typeclass. -/
theorem source_corollary_3_3 (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (htrans : ∀ r : S, Continuous (fun s : S => r*s))
    (hleft : ∀ x : X, Continuous (fun s : S => π s x))
    (hright : ∀ s : S, Continuous (π s))
    (e : S) (he : ∀ s : S, s*e=s) (hunit : ∀ x : X, π e x=x) (x : X) :
    ContinuousAt (fun p : S × X => π p.1 p.2) (e,x) := by
  exact source_theorem_3_2 π hassoc htrans hleft hright e
    (fun s => ⟨s,he s⟩) (fun y => ⟨y,hunit y⟩) x

end MetricAction
end LawsonAction
end ScottSpectraReviewed
