import ScottSpectraReviewed.CompactWebSequences
import ScottSpectraReviewed.LowerHyperspace

/-! The filtered compact-neighborhood/minimum proof in source
`thm:compactweb`, lines 392--451. The internal lower-relation openness
hypothesis is kept explicit until the actual hyperspace semilattice theorem
is available; it is not an asserted source-facing theorem premise.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace CompactWeb

variable {P : Type u} [PartialOrder P] [TopologicalSpace P]

/-- Exactly the neighborhood sequences `A_x` in the printed proof, indexed
from zero. These fields specify only the original sequence conditions. -/
structure CompactSequence (x : P) where
  sets : ℕ → Set P
  closed : ∀ n, IsClosed (sets n)
  nhds : ∀ n, sets n ∈ 𝓝 x
  nested : ∀ n, sets (n + 1) ⊆ interior (sets n)
  lower : ∀ n, ∀ a ∈ sets (n + 1), ∀ b ∈ sets (n + 1),
    ∃ c ∈ sets n, c ≤ a ∧ c ≤ b

namespace CompactSequence

def kernel {x : P} (C : CompactSequence x) : Set P := ⋂ n, C.sets n

theorem antitone {x : P} (C : CompactSequence x) : Antitone C.sets :=
  antitone_nat_of_succ_le fun n => (C.nested n).trans interior_subset

theorem self_mem_kernel {x : P} (C : CompactSequence x) : x ∈ C.kernel :=
  mem_iInter.mpr fun n => mem_of_mem_nhds (C.nhds n)

theorem isClosed_kernel {x : P} (C : CompactSequence x) : IsClosed C.kernel :=
  isClosed_iInter C.closed

variable [CompactSpace P] [T2Space P] [OrderClosedTopology P]

omit [T2Space P] [OrderClosedTopology P] in
theorem isCompact_kernel {x : P} (C : CompactSequence x) : IsCompact C.kernel :=
  C.isClosed_kernel.isCompact

omit [T2Space P] in
/-- The original nested compact intersection argument, not a lattice-infimum
argument: each pair in `K_C` has a common lower bound inside `K_C`. -/
theorem filtered_kernel {x : P} (C : CompactSequence x) : NonemptyFiltered C.kernel := by
  refine ⟨⟨x, C.self_mem_kernel⟩, ?_⟩
  intro a ha b hb
  let F : ℕ → Set P := fun n => C.sets n ∩ Iic a ∩ Iic b
  have hFclosed : ∀ n, IsClosed (F n) := fun n =>
    ((C.closed n).inter isClosed_Iic).inter isClosed_Iic
  have hFnonempty : ∀ n, (F n).Nonempty := by
    intro n
    obtain ⟨c, hc, hca, hcb⟩ := C.lower n a (mem_iInter.mp ha (n + 1))
      b (mem_iInter.mp hb (n + 1))
    exact ⟨c, ⟨hc, hca⟩, hcb⟩
  have hFnested : ∀ n, F (n + 1) ⊆ F n := by
    intro n z hz
    exact ⟨⟨interior_subset (C.nested n hz.1.1), hz.1.2⟩, hz.2⟩
  obtain ⟨c, hc⟩ := IsCompact.nonempty_iInter_of_sequence_nonempty_isCompact_isClosed
    F hFnested hFnonempty ((hFclosed 0).isCompact) hFclosed
  exact ⟨c, mem_iInter.mpr (fun n => (mem_iInter.mp hc n).1.1),
    (mem_iInter.mp hc 0).1.2, (mem_iInter.mp hc 0).2⟩

end CompactSequence

variable [CompactSpace P] [T2Space P] [OrderClosedTopology P]

omit [CompactSpace P] [T2Space P] in
/-- A nonempty compact filtered set in a closed partial order has a least
element. The proof uses precisely the finite-intersection property of its
closed principal lower subsets; there is no completeness assumption. -/
theorem compact_filtered_hasLeast {K : Set P} (hK : IsCompact K)
    (hfiltered : NonemptyFiltered K) : ∃ m, IsLeast K m := by
  classical
  have hfinite : ∀ S : Finset K, ∃ z ∈ K, ∀ k ∈ S, z ≤ (k : P) := by
    intro S
    induction S using Finset.induction_on with
    | empty =>
        obtain ⟨z, hz⟩ := hfiltered.1
        exact ⟨z, hz, by simp⟩
    | @insert k S hk ih =>
        obtain ⟨z, hzK, hz⟩ := ih
        obtain ⟨w, hwK, hwk, hwz⟩ := hfiltered.2 k k.property z hzK
        refine ⟨w, hwK, ?_⟩
        intro l hl
        rcases Finset.mem_insert.mp hl with rfl | hl
        · exact hwk
        · exact hwz.trans (hz l hl)
  have hnonempty : (K ∩ ⋂ k : K, Iic (k : P)).Nonempty :=
    hK.inter_iInter_nonempty (fun k : K => Iic (k : P)) (fun _ => isClosed_Iic)
      (fun S => by
        obtain ⟨z, hzK, hz⟩ := hfinite S
        exact ⟨z, hzK, mem_iInter₂.mpr hz⟩)
  obtain ⟨m, hmK, hm⟩ := hnonempty
  exact ⟨m, hmK, fun k hk => mem_iInter.mp hm ⟨k, hk⟩⟩

namespace CompactSequence

def minimum {x : P} (C : CompactSequence x) : P :=
  Classical.choose (compact_filtered_hasLeast C.isCompact_kernel C.filtered_kernel)

omit [T2Space P] in
theorem minimum_isLeast {x : P} (C : CompactSequence x) : IsLeast C.kernel C.minimum :=
  Classical.choose_spec (compact_filtered_hasLeast C.isCompact_kernel C.filtered_kernel)

omit [T2Space P] in
theorem minimum_le_self {x : P} (C : CompactSequence x) : C.minimum ≤ x :=
  C.minimum_isLeast.2 C.self_mem_kernel

end CompactSequence

omit [OrderClosedTopology P] in
/-- Construction of the source's compact-neighborhood sequences, with each
coordinate constrained by an arbitrary prescribed neighborhood `A_n`.
The displayed relation openness is an internal lemma input only. -/
theorem exists_compactSequence
    (hrel : ∀ O : Set P, IsOpen O →
      IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2})
    (x : P) (A : ℕ → Set P) (hA : ∀ n, A n ∈ 𝓝 x) :
    ∃ C : CompactSequence x, ∀ n, C.sets n ⊆ A n := by
  classical
  let Stage := {E : Set P // IsClosed E ∧ E ∈ 𝓝 x}
  have hinit : ∃ E : Stage, E.val ⊆ A 0 := by
    obtain ⟨E, hE, hEclosed, hEA⟩ := exists_mem_nhds_isClosed_subset (hA 0)
    exact ⟨⟨E, hEclosed, hE⟩, hEA⟩
  have hstep : ∀ n (E : Stage), ∃ E' : Stage,
      E'.val ⊆ A (n + 1) ∧ E'.val ⊆ interior E.val ∧
      ∀ a ∈ E'.val, ∀ b ∈ E'.val, ∃ c ∈ E.val, c ≤ a ∧ c ≤ b := by
    intro n E
    have hxE : x ∈ interior E.val := mem_interior_iff_mem_nhds.mpr E.property.2
    have hR := (hrel (interior E.val) isOpen_interior).mem_nhds
      (show (x, x) ∈ {p : P × P | ∃ z ∈ interior E.val, z ≤ p.1 ∧ z ≤ p.2}
        from ⟨x, hxE, le_rfl, le_rfl⟩)
    obtain ⟨V, hV, W, hW, hVW⟩ := mem_nhds_prod_iff.mp hR
    have hN : (V ∩ W) ∩ (interior E.val ∩ A (n + 1)) ∈ 𝓝 x :=
      inter_mem (inter_mem hV hW)
        (inter_mem (interior_mem_nhds.mpr E.property.2) (hA (n + 1)))
    obtain ⟨E', hE', hE'closed, hE'N⟩ := exists_mem_nhds_isClosed_subset hN
    refine ⟨⟨E', hE'closed, hE'⟩, fun a ha => (hE'N ha).2.2,
      fun a ha => (hE'N ha).2.1, ?_⟩
    intro a ha b hb
    have hab : (a, b) ∈ V ×ˢ W := ⟨(hE'N ha).1.1, (hE'N hb).1.2⟩
    obtain ⟨c, hc, hca, hcb⟩ := hVW hab
    exact ⟨c, interior_subset hc, hca, hcb⟩
  let step : ℕ → Stage → Stage := fun n E => Classical.choose (hstep n E)
  let stages : ℕ → Stage := Nat.rec (Classical.choose hinit) (fun n E => step n E)
  let C : CompactSequence x :=
    { sets := fun n => (stages n).val
      closed := fun n => (stages n).property.1
      nhds := fun n => (stages n).property.2
      nested := fun n => (Classical.choose_spec (hstep n (stages n))).2.1
      lower := fun n => (Classical.choose_spec (hstep n (stages n))).2.2 }
  refine ⟨C, ?_⟩
  intro n
  cases n with
  | zero => exact Classical.choose_spec hinit
  | succ n => exact (Classical.choose_spec (hstep n (stages n))).1

omit [OrderClosedTopology P] in
theorem exists_compactSequence_refinement
    (hrel : ∀ O : Set P, IsOpen O →
      IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2})
    {x : P} (C C' : CompactSequence x) :
    ∃ D : CompactSequence x, ∀ n, D.sets n ⊆ C.sets n ∩ C'.sets n :=
  exists_compactSequence hrel x (fun n => C.sets n ∩ C'.sets n)
    (fun n => inter_mem (C.nhds n) (C'.nhds n))

def sequenceMinima (x : P) : Set P := range (CompactSequence.minimum (x := x))

theorem sequenceMinima_nonemptyDirected
    (hrel : ∀ O : Set P, IsOpen O →
      IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2})
    (x : P) : NonemptyDirected (sequenceMinima x) := by
  obtain ⟨C, _⟩ := exists_compactSequence hrel x (fun _ => univ) (fun _ => univ_mem)
  refine ⟨⟨C.minimum, mem_range_self C⟩, ?_⟩
  rintro a ⟨C, rfl⟩ b ⟨C', rfl⟩
  obtain ⟨D, hD⟩ := exists_compactSequence_refinement hrel C C'
  refine ⟨D.minimum, mem_range_self D, C.minimum_isLeast.2 ?_, C'.minimum_isLeast.2 ?_⟩
  · exact mem_iInter.mpr fun n => (hD n (mem_iInter.mp D.minimum_isLeast.1 n)).1
  · exact mem_iInter.mpr fun n => (hD n (mem_iInter.mp D.minimum_isLeast.1 n)).2

theorem self_mem_closure_sequenceMinima
    (hrel : ∀ O : Set P, IsOpen O →
      IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2})
    (x : P) : x ∈ closure (sequenceMinima x) := by
  apply mem_closure_iff.mpr
  intro U hU hxU
  obtain ⟨C, hC⟩ := exists_compactSequence hrel x (fun _ => U) (fun _ => hU.mem_nhds hxU)
  exact ⟨C.minimum, hC 0 (mem_iInter.mp C.minimum_isLeast.1 0), mem_range_self C⟩

theorem sequenceMinima_isLUB
    (hrel : ∀ O : Set P, IsOpen O →
      IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2})
    (x : P) : IsLUB (sequenceMinima x) x := by
  constructor
  · rintro _ ⟨C, rfl⟩
    exact C.minimum_le_self
  · intro y hy
    exact (closure_minimal hy isClosed_Iic) (self_mem_closure_sequenceMinima hrel x)

/-- The internal compact-web proof after lower-relation openness has been
proved. It follows the countable compact intersection and directed-minimum
route of the source; the extra relation premise is not a source certificate. -/
theorem isClosed_of_isScottClosed_of_lowerRelation
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : HasLocalLowerBounds P)
    (hrel : ∀ O : Set P, IsOpen O →
      IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2})
    {B : Set P} (hB : IsClosed[scottTopology P] B) : IsClosed B := by
  apply isClosed_of_closure_subset
  intro x hxB
  have hBspec := (isScottClosed_iff B).mp hB
  have hminB : sequenceMinima x ⊆ B := by
    rintro _ ⟨C, rfl⟩
    obtain ⟨b, hbB, hbC⟩ := countable_closed_nhds_intersection hup hweb hB hxB
      C.sets C.closed C.nhds
    exact hBspec.1 (C.minimum_isLeast.2 hbC) hbB
  have hdir := sequenceMinima_nonemptyDirected hrel x
  exact hBspec.2 hminB hdir.1 hdir.2 (sequenceMinima_isLUB hrel x)

theorem compactweb_of_lowerRelation
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : HasLocalLowerBounds P)
    (hrel : ∀ O : Set P, IsOpen O →
      IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2}) :
    IsDcpo P ∧ ∀ U : Set P,
      IsOpen[scottTopology P] U ↔ IsOpen U ∧ IsUpperSet U := by
  refine ⟨CompactOrdered.isDcpo, fun U => ⟨?_, ?_⟩⟩
  · intro hU
    refine ⟨?_, ((isScottOpen_iff U).mp hU).1⟩
    have hcompl : IsClosed[scottTopology P] Uᶜ :=
      @IsOpen.isClosed_compl P (scottTopology P) U hU
    simpa only [compl_compl] using
      (isClosed_of_isScottClosed_of_lowerRelation hup hweb hrel hcompl).isOpen_compl
  · rintro ⟨hU, hupper⟩
    exact CompactOrdered.isScottOpen_of_isOpen_upper hU hupper

end CompactWeb
end ScottSpectraReviewed
