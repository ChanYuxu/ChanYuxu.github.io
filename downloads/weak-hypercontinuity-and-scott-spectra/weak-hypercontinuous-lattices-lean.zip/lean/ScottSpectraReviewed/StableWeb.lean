import ScottSpectraReviewed.CompactWeb
import ScottSpectraReviewed.PatchBasis

/-! Exact source cor:stableweb, lines428--451: the literal patch topology,
its U minus K basis, the original web, and the compact ordered criterion.
No Scott-space conclusion or patch certificate is assumed. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace Patch

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance stableWebSpecializationOrder : PartialOrder X := specializationOrder X

theorem original_upperClosure_eq {U : Set X} (hU : IsOpen U) :
    (upperClosure U : Set X) = U := by
  ext x
  constructor
  · rintro ⟨y,hy,hyx⟩
    exact hyx.mem_open hU hy
  · intro hx
    exact ⟨x,hx,le_rfl⟩

theorem localLowerBounds_of_web (hweb : IsWebSpace X) :
    CompactWeb.HasLocalLowerBounds X := by
  intro U hU x hx
  obtain ⟨W,hWU,hW⟩ := hweb x U (hU.mem_nhds hx)
  refine ⟨W,hW.1,hWU,?_⟩
  intro y hy
  obtain ⟨z,hz,hzx,hzy⟩ := hW.2 y hy
  exact ⟨z,hz,(specializationLE_iff z x).mp hzx,(specializationLE_iff z y).mp hzy⟩

theorem isOpen_upper_diff (hweb : IsWebSpace X) (U : Opens X)
    {K : Set X} (hKs : IsSaturated K) :
    IsOpen (upperClosure ((U : Set X) \ K) : Set X) := by
  have hKlower : IsLowerSet Kᶜ := by
    intro a b hab hb haK
    exact hb ((isSaturated_iff_specialization_upper K).mp hKs b a
      ((specializationLE_iff b a).mpr hab) haK)
  exact CompactWeb.isOpen_upperClosure_inter
    (fun V hV => (original_upperClosure_eq hV).symm ▸ hV)
    (localLowerBounds_of_web hweb) U.isOpen hKlower

theorem isOpen_upperClosure_patch (hweb : IsWebSpace X) (S : Set X)
    (hS : IsOpen[patchTopology X] S) :
    IsOpen[patchTopology X] (upperClosure S : Set X) := by
  apply isOpen_original
  rw [isOpen_iff_forall_mem_open]
  rintro y ⟨x,hx,hxy⟩
  obtain ⟨U,K,_,hKs,hxUK,hsub⟩ := exists_basic_subset hS x hx
  refine ⟨upperClosure ((U : Set X) \ K),?_,isOpen_upper_diff hweb U hKs,
    ⟨x,hxUK,hxy⟩⟩
  rintro z ⟨a,ha,haz⟩
  exact ⟨a,hsub ha,haz⟩

theorem localLowerBounds_patch (hweb : IsWebSpace X) :
    @CompactWeb.HasLocalLowerBounds X stableWebSpecializationOrder (patchTopology X) := by
  intro S hS x hxS
  obtain ⟨U,K,hK,hKs,hxUK,hsub⟩ := exists_basic_subset hS x hxS
  obtain ⟨W,hWU,hW⟩ := hweb x U (U.isOpen.mem_nhds hxUK.1)
  have hWpatch : W ∈ @nhds X (patchTopology X) x :=
    (@nhds_mono X (patchTopology X) ‹TopologicalSpace X› x le_original) hW.1
  have hKpatch : Kᶜ ∈ @nhds X (patchTopology X) x :=
    @IsOpen.mem_nhds X (patchTopology X) x Kᶜ
      (isOpen_compl_compact_saturated hK hKs) hxUK.2
  refine ⟨W \ K,inter_mem hWpatch hKpatch,?_,?_⟩
  · intro y hy
    exact hsub ⟨hWU hy.1,hy.2⟩
  · intro y hy
    obtain ⟨z,hz,hzx,hzy⟩ := hW.2 y hy.1
    have hzK : z ∉ K := by
      intro hzK
      exact hxUK.2 ((isSaturated_iff_specialization_upper K).mp hKs z x hzx hzK)
    exact ⟨z,⟨hz,hzK⟩,(specializationLE_iff z x).mp hzx,
      (specializationLE_iff z y).mp hzy⟩

end Patch

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance stableWebSourceSpecializationOrder : PartialOrder X := specializationOrder X

/-- Every stably compact web space has exactly the full Scott topology of
its actual specialization order, with precisely the manuscript hypotheses. -/
theorem source_stableweb (hstable : IsStablyCompact X) (hweb : IsWebSpace X) :
    ‹TopologicalSpace X› = scottTopology X := by
  letI : CompactSpace X := hstable.1
  letI : QuasiSober X := hstable.2.2.1
  have hcompact := Patch.compactSpace hstable.2.2.2.2
  have ht2 := Patch.t2Space hstable.2.1
  have hclosed : @OrderClosedTopology X (patchTopology X) _ := by
    refine @OrderClosedTopology.mk X (patchTopology X)
      stableWebSourceSpecializationOrder.toPreorder ?_
    convert Patch.isClosed_specialization hstable.2.1 using 1
    ext p
    exact (specializationLE_iff p.1 p.2).symm
  have hcriterion := @source_compactweb X stableWebSourceSpecializationOrder
    (patchTopology X) hcompact ht2 hclosed
    (Patch.isOpen_upperClosure_patch hweb) (Patch.localLowerBounds_patch hweb)
  apply TopologicalSpace.ext
  funext U
  apply propext
  constructor
  · intro hU
    exact (hcriterion.2 U).mpr ⟨Patch.isOpen_original hU,fun _ _ hxy hx =>
      hxy.mem_open hU hx⟩
  · intro hU
    obtain ⟨hUpatch,hUupper⟩ := (hcriterion.2 U).mp hU
    exact Patch.isOpen_of_patch_upper hstable.2.1 hcompact hUpatch
      (fun a b hab ha => hUupper ((specializationLE_iff a b).mp hab) ha)

end ScottSpectraReviewed
