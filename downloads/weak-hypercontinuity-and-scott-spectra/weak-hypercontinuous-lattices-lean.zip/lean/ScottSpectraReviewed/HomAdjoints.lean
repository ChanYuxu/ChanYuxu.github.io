import ScottSpectraReviewed.OrderBasics
import Mathlib.Order.GaloisConnection.Basic

/-! Actual sInf/sSup adjoints of a complete lattice homomorphism, as specified
in source lines 955--961. No adjoint or section equation is assumed. -/

noncomputable section
open Set
universe u v

namespace ScottSpectraReviewed
namespace CompleteHom

variable {A : Type u} {B : Type v} [CompleteLattice A] [CompleteLattice B]

def leftAdjoint (q : CompleteLatticeHom A B) (b : B) : A := sInf {a : A | b ≤ q a}

def rightAdjoint (q : CompleteLatticeHom A B) (b : B) : A := sSup {a : A | q a ≤ b}

theorem le_q_leftAdjoint (q : CompleteLatticeHom A B) (b : B) : b ≤ q (leftAdjoint q b) := by
  rw [leftAdjoint, map_sInf]
  apply le_sInf
  rintro _ ⟨a, ha, rfl⟩
  exact ha

theorem q_rightAdjoint_le (q : CompleteLatticeHom A B) (b : B) : q (rightAdjoint q b) ≤ b := by
  rw [rightAdjoint, map_sSup]
  apply sSup_le
  rintro _ ⟨a, ha, rfl⟩
  exact ha

theorem leftAdjoint_gc (q : CompleteLatticeHom A B) : GaloisConnection (leftAdjoint q) q := by
  intro b a
  constructor
  · intro h
    exact (le_q_leftAdjoint q b).trans (OrderHomClass.monotone q h)
  · exact fun h => sInf_le h

theorem rightAdjoint_gc (q : CompleteLatticeHom A B) : GaloisConnection q (rightAdjoint q) := by
  intro a b
  constructor
  · exact fun h => le_sSup h
  · intro h
    exact (OrderHomClass.monotone q h).trans (q_rightAdjoint_le q b)

theorem leftAdjoint_monotone (q : CompleteLatticeHom A B) : Monotone (leftAdjoint q) :=
  (leftAdjoint_gc q).monotone_l

theorem rightAdjoint_monotone (q : CompleteLatticeHom A B) : Monotone (rightAdjoint q) :=
  (rightAdjoint_gc q).monotone_u

@[simp] theorem q_leftAdjoint (q : CompleteLatticeHom A B) (hq : Function.Surjective q)
    (b : B) : q (leftAdjoint q b) = b := by
  apply le_antisymm
  · obtain ⟨a, rfl⟩ := hq b
    exact OrderHomClass.monotone q ((leftAdjoint_gc q) (q a) a |>.mpr le_rfl)
  · exact le_q_leftAdjoint q b

@[simp] theorem q_rightAdjoint (q : CompleteLatticeHom A B) (hq : Function.Surjective q)
    (b : B) : q (rightAdjoint q b) = b := by
  apply le_antisymm
  · exact q_rightAdjoint_le q b
  · obtain ⟨a, rfl⟩ := hq b
    exact OrderHomClass.monotone q ((rightAdjoint_gc q) a (q a) |>.mp le_rfl)

theorem leftAdjoint_q_le (q : CompleteLatticeHom A B) (a : A) : leftAdjoint q (q a) ≤ a :=
  (leftAdjoint_gc q).l_u_le a

theorem le_rightAdjoint_q (q : CompleteLatticeHom A B) (a : A) : a ≤ rightAdjoint q (q a) :=
  (rightAdjoint_gc q).le_u_l a

theorem leftAdjoint_isLUB (q : CompleteLatticeHom A B) (D : Set B)
    (b : B) (hb : IsLUB D b) : IsLUB (leftAdjoint q '' D) (leftAdjoint q b) :=
  (leftAdjoint_gc q).isLUB_l_image hb

theorem rightAdjoint_isGLB (q : CompleteLatticeHom A B) (D : Set B)
    (b : B) (hb : IsGLB D b) : IsGLB (rightAdjoint q '' D) (rightAdjoint q b) :=
  (rightAdjoint_gc q).isGLB_u_image hb

theorem leftAdjoint_map_sSup (q : CompleteLatticeHom A B) (S : Set B) :
    leftAdjoint q (sSup S) = sSup (leftAdjoint q '' S) :=
  (leftAdjoint_isLUB q S (sSup S) (isLUB_sSup S)).unique (isLUB_sSup _)

theorem rightAdjoint_map_sInf (q : CompleteLatticeHom A B) (S : Set B) :
    rightAdjoint q (sInf S) = sInf (rightAdjoint q '' S) :=
  (rightAdjoint_isGLB q S (sInf S) (isGLB_sInf S)).unique (isGLB_sInf _)

theorem map_isLUB (q : CompleteLatticeHom A B) (D : Set A)
    (a : A) (ha : IsLUB D a) : IsLUB (q '' D) (q a) := by
  rw [← (isLUB_sSup D).unique ha, map_sSup]
  exact isLUB_sSup _

theorem monotone_image_nonemptyDirected {P : Type u} {Q : Type v}
    [Preorder P] [Preorder Q] (f : P → Q) (hf : Monotone f)
    (D : Set P) (hD : NonemptyDirected D) : NonemptyDirected (f '' D) := by
  refine ⟨hD.1.image f, ?_⟩
  rintro _ ⟨a, ha, rfl⟩ _ ⟨b, hb, rfl⟩
  obtain ⟨c, hc, hac, hbc⟩ := hD.2 a ha b hb
  exact ⟨f c, ⟨c, hc, rfl⟩, hf hac, hf hbc⟩

/-- Source-facing adjoint equations for the actual formulas. -/
theorem source_hom_adjoints (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    GaloisConnection (leftAdjoint q) q ∧ GaloisConnection q (rightAdjoint q) ∧
      (∀ b, q (leftAdjoint q b) = b) ∧ (∀ b, q (rightAdjoint q b) = b) :=
  ⟨leftAdjoint_gc q, rightAdjoint_gc q, q_leftAdjoint q hq, q_rightAdjoint q hq⟩

end CompleteHom
end ScottSpectraReviewed
