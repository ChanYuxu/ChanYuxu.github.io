import ScottSpectraReviewed.OrderBasics
import Mathlib.Topology.Sober
import Mathlib.Topology.Compactness.LocallyCompact
import Mathlib.Topology.Sets.Closeds

/-! Literal topological definitions and elementary operative preliminaries,
frozen manuscript lines 160--203 and 250--256. No Hausdorffness, countability
or Scott-space conclusion is included in these source predicates.

The compact-saturated sandwich and saturation formula have the same explicit
shape as CoreCompactNonSober/simplified/CoreCompactNonSober/TopologicalDefinitions.lean,
SHA256 26b016a3cc60e12da2c0c8b81a91b666f07f0bd5791cc49d1acbe098ed3257a0.
They are rechecked below against the present source; no theorem/status from
that project is imported. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed

section Definitions
variable {X : Type u} [TopologicalSpace X]

def SpecializationLE (x y : X) : Prop := x ∈ closure ({y} : Set X)

theorem specializationLE_iff (x y : X) : SpecializationLE x y ↔ y ⤳ x :=
  specializes_iff_mem_closure.symm

/-- Saturated means the intersection of all open supersets; upperness will
be a proved equivalence, not an additional defining assumption. -/
def IsSaturated (K : Set X) : Prop :=
  K = ⋂₀ {U : Set X | IsOpen U ∧ K ⊆ U}

def IsLocallyCompact (X : Type u) [TopologicalSpace X] : Prop :=
  ∀ (U : Opens X) (x : X), x ∈ U →
    ∃ (V : Opens X) (K : Set X),
      x ∈ V ∧ (V : Set X) ⊆ K ∧ K ⊆ (U : Set X) ∧ IsCompact K ∧ IsSaturated K

/-- The paper explicitly uses continuity of the actual lattice O(X). -/
def IsCoreCompact (X : Type u) [TopologicalSpace X] : Prop :=
  IsContinuousLattice (Opens X)

def IsWebAt (x : X) (W : Set X) : Prop :=
  W ∈ 𝓝 x ∧ ∀ y ∈ W, ∃ z ∈ W, SpecializationLE z x ∧ SpecializationLE z y

def IsWebSpace (X : Type u) [TopologicalSpace X] : Prop :=
  ∀ x : X, ∀ U ∈ 𝓝 x, ∃ W : Set X, W ⊆ U ∧ IsWebAt x W

def IsCoherent (X : Type u) [TopologicalSpace X] : Prop :=
  ∀ K J : Set X, IsCompact K → IsSaturated K →
    IsCompact J → IsSaturated J → IsCompact (K ∩ J)

/-- Sobriety is actual Mathlib quasi-sobriety plus T0, so generic points
exist and are unique. -/
def IsStablyCompact (X : Type u) [TopologicalSpace X] : Prop :=
  CompactSpace X ∧ IsLocallyCompact X ∧ QuasiSober X ∧ T0Space X ∧ IsCoherent X

@[implicit_reducible] def patchTopology (X : Type u) [TopologicalSpace X] :
    TopologicalSpace X :=
  TopologicalSpace.generateFrom
    ({U : Set X | IsOpen U} ∪ {U | ∃ K : Set X, IsCompact K ∧ IsSaturated K ∧ Kᶜ = U})

theorem isOpen_upper_specialization {U : Set X} (hU : IsOpen U)
    {x y : X} (hxy : SpecializationLE x y) (hx : x ∈ U) : y ∈ U :=
  ((specializationLE_iff x y).mp hxy).mem_open hU hx

theorem isSaturated_iff_specialization_upper (K : Set X) :
    IsSaturated K ↔ ∀ x y, SpecializationLE x y → x ∈ K → y ∈ K := by
  constructor
  · intro hK x y hxy hx
    rw [hK]
    intro U hU
    exact isOpen_upper_specialization hU.1 hxy (hU.2 hx)
  · intro hK
    apply subset_antisymm
    · intro x hx U hU
      exact hU.2 hx
    · intro x hx
      by_contra hxK
      have hKU : K ⊆ (closure ({x} : Set X))ᶜ := by
        intro y hy hyx
        exact hxK (hK y x hyx hy)
      exact (mem_sInter.mp hx _ ⟨isClosed_closure.isOpen_compl, hKU⟩)
        (subset_closure (mem_singleton x))

theorem sobriety_iff_unique_generic [T0Space X] :
    QuasiSober X ↔ ∀ C : Set X, IsClosed C → IsIrreducible C →
      ∃! x : X, closure ({x} : Set X) = C := by
  constructor
  · intro h C hC hI
    letI : QuasiSober X := h
    obtain ⟨x, hx⟩ := QuasiSober.sober hI hC
    refine ⟨x, hx, ?_⟩
    intro y hy
    exact IsGenericPoint.eq (show IsGenericPoint y C from hy) hx
  · intro h
    constructor
    intro C hI hC
    obtain ⟨x, hx, _⟩ := h C hC hI
    exact ⟨x, hx⟩

end Definitions

section CoreCompact
variable {X : Type u} [TopologicalSpace X]

theorem wayBelow_opens_of_compact_sandwich (V U : Opens X) (K : Set X)
    (hVK : (V : Set X) ⊆ K) (hKU : K ⊆ (U : Set X)) (hK : IsCompact K) :
    WayBelow V U := by
  intro D hD p hp hUp
  letI : Nonempty D := hD.1.to_subtype
  have hs : sSup D = p := (isLUB_sSup D).unique hp
  have hcover : K ⊆ ⋃ d : D, (d : Opens X) := by
    intro x hx
    have hxS : x ∈ sSup D := hs ▸ hUp (hKU hx)
    obtain ⟨d, hdD, hxd⟩ := Opens.mem_sSup.mp hxS
    exact mem_iUnion.mpr ⟨⟨d,hdD⟩, hxd⟩
  have hdir : Directed (· ⊆ ·) (fun d : D => (d : Opens X) : D → Set X) := by
    intro d e
    obtain ⟨f, hf, hdf, hef⟩ := hD.2 d d.property e e.property
    exact ⟨⟨f,hf⟩, hdf, hef⟩
  obtain ⟨d, hKd⟩ := hK.elim_directed_cover (fun d : D => (d : Opens X))
    (fun d => d.val.isOpen) hcover hdir
  exact ⟨d, d.property, hVK.trans hKd⟩

/-- Actual neighborhood-core-compactness/continuous-lattice equivalence. -/
theorem coreCompact_iff_neighborhood :
    IsCoreCompact X ↔ ∀ (U : Opens X) (x : X), x ∈ U →
      ∃ V : Opens X, x ∈ V ∧ WayBelow V U := by
  constructor
  · intro h U x hx
    have hs : sSup {V : Opens X | WayBelow V U} = U :=
      (isLUB_sSup _).unique (h.2 U).2
    rw [← hs] at hx
    obtain ⟨V, hV, hxV⟩ := Opens.mem_sSup.mp hx
    exact ⟨V,hxV,hV⟩
  · intro h
    refine ⟨completeLattice_isDcpo _, ?_⟩
    intro U
    refine ⟨⟨⟨⊥,wayBelow_bot _ U⟩, ?_⟩, ?_, ?_⟩
    · intro V hV W hW
      exact ⟨V ⊔ W, wayBelow_sup hV hW, le_sup_left, le_sup_right⟩
    · intro V hV
      exact wayBelow_le hV
    · intro B hB x hx
      obtain ⟨V,hxV,hVU⟩ := h U x hx
      exact hB hVU hxV

theorem locallyCompact_isCoreCompact (hX : IsLocallyCompact X) : IsCoreCompact X := by
  apply coreCompact_iff_neighborhood.mpr
  intro U x hx
  obtain ⟨V,K,hxV,hVK,hKU,hK,_⟩ := hX U x hx
  exact ⟨V,hxV,wayBelow_opens_of_compact_sandwich V U K hVK hKU hK⟩

end CoreCompact

section DSpace
variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance : PartialOrder X := specializationOrder X

def IsDSpace (X : Type u) [TopologicalSpace X] [T0Space X] : Prop :=
  letI : PartialOrder X := specializationOrder X
  IsDcpo X ∧ ∀ U : Set X, IsOpen U → IsOpen[scottTopology X] U

theorem directed_isIrreducible {D : Set X} (hD : NonemptyDirected D) :
    IsIrreducible D := by
  refine ⟨hD.1, ?_⟩
  intro U V hU hV hDU hDV
  obtain ⟨d,hd,hdu⟩ := hDU
  obtain ⟨e,he,hev⟩ := hDV
  obtain ⟨f,hf,hdf,hef⟩ := hD.2 d hd e he
  exact ⟨f,hf,hdf.mem_open hU hdu,hef.mem_open hV hev⟩

theorem sober_directed_generic_sup [QuasiSober X] {D : Set X}
    (hD : NonemptyDirected D) : ∃ s : X, IsLUB D s ∧ s ∈ closure D := by
  obtain ⟨s,hs⟩ := QuasiSober.sober (directed_isIrreducible hD).closure isClosed_closure
  refine ⟨s, ⟨?_,?_⟩, hs.mem⟩
  · intro d hd
    exact hs.specializes (subset_closure hd)
  · intro u hu
    have hDC : D ⊆ closure ({u} : Set X) := by
      intro d hd
      exact (hu hd : u ⤳ d).mem_closure
    exact (specializes_iff_mem_closure).mpr
      (closure_minimal hDC isClosed_closure hs.mem)

/-- Every sober space is a d-space, by the exact directed-closure argument
printed in the manuscript. No web or local compactness premise is used. -/
theorem sober_isDSpace [QuasiSober X] : IsDSpace X := by
  refine ⟨fun D hD => (sober_directed_generic_sup hD).imp (fun _ h => h.1), ?_⟩
  intro U hU
  apply (isScottOpen_iff U).mpr
  refine ⟨?_,?_⟩
  · intro x y hxy hx
    exact hxy.mem_open hU hx
  · intro D hne hdir x hx hxU
    obtain ⟨s,hs,hsC⟩ := sober_directed_generic_sup ⟨hne,hdir⟩
    have hxs : s = x := hs.unique hx
    obtain ⟨d,hdU,hdD⟩ := mem_closure_iff.mp (hxs ▸ hsC) U hU hxU
    exact ⟨d,hdD,hdU⟩

end DSpace

namespace ClosedLattice
variable {X : Type u} [TopologicalSpace X]

abbrev Carrier (X : Type u) [TopologicalSpace X] := Closeds X

def hit (U : Opens X) : Set (Carrier X) := {C | ((C : Set X) ∩ U).Nonempty}

@[implicit_reducible] def lowerVietorisTopology (X : Type u) [TopologicalSpace X] :
    TopologicalSpace (Carrier X) :=
  TopologicalSpace.generateFrom {S | ∃ U : Opens X, hit U = S}

theorem hit_eq_compl_Iic (U : Opens X) : hit U = (Iic U.compl)ᶜ := by
  classical
  ext C
  change ((C : Set X) ∩ (U : Set X)).Nonempty ↔ ¬C ≤ U.compl
  constructor
  · rintro ⟨x,hxC,hxU⟩ h
    exact h hxC hxU
  · intro h
    by_contra hnone
    apply h
    intro x hxC hxU
    exact hnone ⟨x,hxC,hxU⟩

theorem lowerVietoris_eq_upper : lowerVietorisTopology X = upperTopology (Carrier X) := by
  change TopologicalSpace.generateFrom _ = TopologicalSpace.generateFrom _
  congr 1
  ext S
  constructor
  · rintro ⟨U,rfl⟩
    exact ⟨U.compl, (hit_eq_compl_Iic U).symm⟩
  · rintro ⟨C,rfl⟩
    exact ⟨C.compl, by simpa only [Closeds.compl_compl] using hit_eq_compl_Iic C.compl⟩

def eta (x : X) : Carrier X := ⟨closure ({x} : Set X), isClosed_closure⟩

theorem eta_preimage_hit (U : Opens X) : eta ⁻¹' hit U = (U : Set X) := by
  ext x
  exact (isGenericPoint_closure.mem_open_set_iff U.isOpen).symm

theorem eta_isInducing :
    @Topology.IsInducing X (Carrier X) ‹TopologicalSpace X› (lowerVietorisTopology X) eta := by
  letI : TopologicalSpace (Carrier X) := lowerVietorisTopology X
  refine ⟨?_⟩
  change ‹TopologicalSpace X› = TopologicalSpace.induced eta (TopologicalSpace.generateFrom _)
  rw [induced_generateFrom_eq]
  have hg : (fun S : Set (Carrier X) => eta ⁻¹' S) ''
      {S | ∃ U : Opens X, hit U = S} = {U : Set X | IsOpen U} := by
    ext U
    constructor
    · rintro ⟨_,⟨V,rfl⟩,rfl⟩
      change IsOpen (eta ⁻¹' hit V)
      rw [eta_preimage_hit]
      exact V.isOpen
    · intro hU
      exact ⟨hit ⟨U,hU⟩,⟨⟨U,hU⟩,rfl⟩,eta_preimage_hit ⟨U,hU⟩⟩
  rw [hg,generateFrom_setOf_isOpen]

theorem eta_injective [T0Space X] : Function.Injective (eta (X := X)) := by
  intro x y h
  have hC := congrArg (fun C : Carrier X => (C : Set X)) h
  exact (inseparable_iff_closure_eq.mpr hC).eq

theorem eta_isEmbedding [T0Space X] :
    @Topology.IsEmbedding X (Carrier X) ‹TopologicalSpace X› (lowerVietorisTopology X) eta := by
  letI : TopologicalSpace (Carrier X) := lowerVietorisTopology X
  exact ⟨eta_isInducing,eta_injective⟩

/-- The order anti-isomorphism is complementation on the actual closed and
open subsets, not an arbitrary representation. -/
def complementOrderIso (X : Type u) [TopologicalSpace X] :
    Carrier X ≃o (Opens X)ᵒᵈ := Closeds.complOrderIso X

theorem isCoframe : IsCoframe (Carrier X) := by
  intro C S
  rw [sInf_image]
  exact sup_sInf_eq

end ClosedLattice
end ScottSpectraReviewed
