import Mathlib.Topology.Order.LawsonTopology
import Mathlib.Order.Hom.CompleteLattice

/-! Exact order conventions of the reviewed manuscript. Directed sets are
nonempty; the way-below relation quantifies over every existing directed
supremum, not merely sequences. No theorem conclusion is part of a model. -/

noncomputable section
open Set
open scoped Topology
universe u v

namespace ScottSpectraReviewed

def NonemptyDirected {P : Type u} [Preorder P] (D : Set P) : Prop :=
  D.Nonempty ∧ DirectedOn (· ≤ ·) D

def NonemptyFiltered {P : Type u} [Preorder P] (D : Set P) : Prop :=
  D.Nonempty ∧ DirectedOn (· ≥ ·) D

def IsDcpo (P : Type u) [PartialOrder P] : Prop :=
  ∀ D : Set P, NonemptyDirected D → ∃ x, IsLUB D x

def WayBelow {P : Type u} [Preorder P] (a b : P) : Prop :=
  ∀ (D : Set P), NonemptyDirected D → ∀ x, IsLUB D x → b ≤ x →
    ∃ d ∈ D, a ≤ d

def IsContinuousDcpo (P : Type u) [PartialOrder P] : Prop :=
  IsDcpo P ∧ ∀ x : P,
    NonemptyDirected {a | WayBelow a x} ∧ IsLUB {a | WayBelow a x} x

def IsContinuousLattice (L : Type u) [CompleteLattice L] : Prop :=
  IsContinuousDcpo L

/-- Ordinary finite distributivity only: not the stronger Mathlib class
`CompleteDistribLattice`, which would already assume the coframe law. -/
def IsDistributive (L : Type u) [Lattice L] : Prop :=
  ∀ a b c : L, a ⊓ (b ⊔ c) = (a ⊓ b) ⊔ (a ⊓ c)

def IsFrame (L : Type u) [CompleteLattice L] : Prop :=
  ∀ (a : L) (S : Set L), a ⊓ sSup S = sSup ((fun b => a ⊓ b) '' S)

def IsCoframe (L : Type u) [CompleteLattice L] : Prop :=
  ∀ (a : L) (S : Set L), a ⊔ sInf S = sInf ((fun b => a ⊔ b) '' S)

abbrev scottTopology (P : Type u) [Preorder P] : TopologicalSpace P :=
  Topology.scott P Set.univ

abbrev upperTopology (P : Type u) [Preorder P] : TopologicalSpace P :=
  Topology.upper P

abbrev lawsonTopology (P : Type u) [Preorder P] : TopologicalSpace P :=
  Topology.lawson P

def DualTopologyEquality (L : Type u) [Preorder L] : Prop :=
  scottTopology Lᵒᵈ = upperTopology Lᵒᵈ

theorem isScottOpen_iff {P : Type u} [Preorder P] (U : Set P) :
    IsOpen[scottTopology P] U ↔ IsUpperSet U ∧ DirSupInacc U := by
  letI : TopologicalSpace P := scottTopology P
  letI : Topology.IsScott P Set.univ := ⟨rfl⟩
  simpa only [dirSupInaccOn_univ] using
    (Topology.IsScott.isOpen_iff_isUpperSet_and_dirSupInaccOn
      (α := P) (s := U) (D := Set.univ))

theorem isScottClosed_iff {P : Type u} [Preorder P] (C : Set P) :
    IsClosed[scottTopology P] C ↔ IsLowerSet C ∧ DirSupClosed C := by
  letI : TopologicalSpace P := scottTopology P
  letI : Topology.IsScott P Set.univ := ⟨rfl⟩
  exact Topology.IsScott.isClosed_iff_isLowerSet_and_dirSupClosed

theorem completeLattice_isDcpo (L : Type u) [CompleteLattice L] : IsDcpo L :=
  fun D _ => ⟨sSup D, isLUB_sSup D⟩

theorem wayBelow_le {P : Type u} [Preorder P] {a b : P}
    (h : WayBelow a b) : a ≤ b := by
  have hD : NonemptyDirected ({b} : Set P) := by
    refine ⟨singleton_nonempty b, ?_⟩
    intro x hx y hy
    exact ⟨b, mem_singleton b, (mem_singleton_iff.mp hx).le,
      (mem_singleton_iff.mp hy).le⟩
  obtain ⟨d, hd, had⟩ := h {b} hD b isLUB_singleton le_rfl
  exact (mem_singleton_iff.mp hd) ▸ had

theorem wayBelow_mono {P : Type u} [Preorder P] {a' a b b' : P}
    (haa : a' ≤ a) (hab : WayBelow a b) (hbb : b ≤ b') : WayBelow a' b' := by
  intro D hD x hx hbx
  obtain ⟨d, hd, had⟩ := hab D hD x hx (hbb.trans hbx)
  exact ⟨d, hd, haa.trans had⟩

theorem wayBelow_bot (L : Type u) [CompleteLattice L] (x : L) :
    WayBelow (⊥ : L) x := by
  intro D hD _ _ _
  obtain ⟨d, hd⟩ := hD.1
  exact ⟨d, hd, bot_le⟩

theorem wayBelow_sup {L : Type u} [SemilatticeSup L] {a b x : L}
    (ha : WayBelow a x) (hb : WayBelow b x) : WayBelow (a ⊔ b) x := by
  intro D hD y hy hxy
  obtain ⟨d, hd, had⟩ := ha D hD y hy hxy
  obtain ⟨e, he, hbe⟩ := hb D hD y hy hxy
  obtain ⟨f, hf, hdf, hef⟩ := hD.2 d hd e he
  exact ⟨f, hf, sup_le (had.trans hdf) (hbe.trans hef)⟩

end ScottSpectraReviewed
