import ScottSpectraReviewed.ScottClosedHyperspace
import ScottSpectraReviewed.SpectrumLocalCompact
import ScottSpectraReviewed.ContinuousFrame
import ScottSpectraReviewed.UpperScottEq

/-! The actual cited CK23 necessary implication, Theorem 4.15 (4) => (2),
used by the frozen manuscript at line 1670. The proof follows CK23's
finite-point-closure / closed-set-lattice route, then uses the proved actual
Hofmann--Lawson representation and complement order isomorphism. No web
property of the spectrum or continuity of its closed-set lattice is assumed.
-/

noncomputable section
open Set TopologicalSpace
universe u

namespace ScottSpectraReviewed
namespace ScottNecessity

variable {L : Type u} [CompleteLattice L]

theorem spectrum_isScott_implies_dualTopologyEquality
    (hframe : IsFrame L) (hcontinuous : IsContinuousLattice L)
    (hspectrum : SpectrumIsScott L) : DualTopologyEquality L := by
  change Spectrum.hullKernelTopology (L := L) = scottTopology (Spectrum L) at hspectrum
  letI : TopologicalSpace (Spectrum L) := scottTopology (Spectrum L)
  have hlocal : IsLocallyCompact (Spectrum L) := by
    have hlocal0 : @IsLocallyCompact (Spectrum L) (Spectrum.hullKernelTopology (L := L)) :=
      Spectrum.hullKernel_isLocallyCompact hframe hcontinuous
    rw [hspectrum] at hlocal0
    exact hlocal0
  have hclosed := ScottClosedHyperspace.scottTopology_eq_upper hlocal
  have e0 := Spectrum.openOrderIso hframe hcontinuous
  change L ≃o @Opens (Spectrum L) (Spectrum.hullKernelTopology (L := L)) at e0
  rw [hspectrum] at e0
  let e : ScottClosedHyperspace.Carrier (Spectrum L) ≃o Lᵒᵈ :=
    (Closeds.complOrderIso (Spectrum L)).trans e0.dual.symm
  exact OrderIsoTransfer.scott_eq_upper e hclosed

end ScottNecessity

/-- Exact hypotheses of the cited necessary half of the source main theorem:
ordinary finite distributivity, continuity, and actual spectrum topology
equality. The arbitrary frame law is derived, not an extra hypothesis. -/
theorem source_ck23_necessity {L : Type u} [CompleteLattice L]
    (hdistributive : IsDistributive L) (hcontinuous : IsContinuousLattice L)
    (hspectrum : SpectrumIsScott L) : DualTopologyEquality L :=
  ScottNecessity.spectrum_isScott_implies_dualTopologyEquality
    (continuousDistributiveLattice_isFrame hcontinuous hdistributive) hcontinuous hspectrum

end ScottSpectraReviewed
