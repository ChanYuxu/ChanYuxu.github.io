import ScottSpectraReviewed.PatchCompact
import Mathlib.Topology.Order.OrderClosed

/-! Separation and order parts of the actual patch correspondence from
source250--256. Opens/saturation/compactness in the generators always refer
to the original topology, not silently to the patch topology. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace Patch

variable {X : Type u} [TopologicalSpace X]

theorem isOpen_original {U : Set X} (hU : IsOpen U) :
    IsOpen[patchTopology X] U :=
  isOpen_generateFrom_of_mem (.inl hU)

theorem isOpen_compl_compact_saturated {K : Set X} (hK : IsCompact K)
    (hKs : IsSaturated K) : IsOpen[patchTopology X] Kᶜ :=
  isOpen_generateFrom_of_mem (.inr ⟨K,hK,hKs,rfl⟩)

theorem le_original : patchTopology X ≤ ‹TopologicalSpace X› := by
  intro U hU
  exact isOpen_original hU

/-- The compact-saturated separation forced by local compactness and the
actual original specialization relation. -/
theorem exists_compact_separation (hlocal : IsLocallyCompact X) {x y : X}
    (hxy : ¬ SpecializationLE x y) :
    ∃ (V : Opens X) (K : Set X), x ∈ V ∧ (V : Set X) ⊆ K ∧
      IsCompact K ∧ IsSaturated K ∧ y ∉ K := by
  let U : Opens X := ⟨(closure ({y} : Set X))ᶜ,isClosed_closure.isOpen_compl⟩
  obtain ⟨V,K,hxV,hVK,hKU,hK,hKs⟩ := hlocal U x hxy
  refine ⟨V,K,hxV,hVK,hK,hKs,?_⟩
  intro hyK
  exact hKU hyK (subset_closure (mem_singleton y))

theorem t2Space [T0Space X] (hlocal : IsLocallyCompact X) :
    @T2Space X (patchTopology X) := by
  refine @T2Space.mk X (patchTopology X) ?_
  intro x y hne
  have hor : ¬ SpecializationLE x y ∨ ¬ SpecializationLE y x := by
    by_contra h
    push Not at h
    exact hne (((specializationLE_iff y x).mp h.2).antisymm
      ((specializationLE_iff x y).mp h.1)).eq
  rcases hor with hxy | hyx
  · obtain ⟨V,K,hxV,hVK,hK,hKs,hyK⟩ := exists_compact_separation hlocal hxy
    refine ⟨V,Kᶜ,isOpen_original V.isOpen,isOpen_compl_compact_saturated hK hKs,
      hxV,hyK,Set.disjoint_left.mpr ?_⟩
    intro z hzV hzK
    exact hzK (hVK hzV)
  · obtain ⟨V,K,hyV,hVK,hK,hKs,hxK⟩ := exists_compact_separation hlocal hyx
    refine ⟨Kᶜ,V,isOpen_compl_compact_saturated hK hKs,isOpen_original V.isOpen,
      hxK,hyV,Set.disjoint_left.mpr ?_⟩
    intro z hzK hzV
    exact hzK (hVK hzV)

/-- Closedness of the original specialization relation in the patch
product; no order reversal is hidden in this statement. -/
theorem isClosed_specialization (hlocal : IsLocallyCompact X) :
    @IsClosed (X × X) (@instTopologicalSpaceProd X X (patchTopology X) (patchTopology X))
      {p | SpecializationLE p.1 p.2} := by
  rw [← @isOpen_compl_iff (X × X)
    {p | SpecializationLE p.1 p.2}
    (@instTopologicalSpaceProd X X (patchTopology X) (patchTopology X)),
    @isOpen_iff_forall_mem_open (X × X)
    (@instTopologicalSpaceProd X X (patchTopology X) (patchTopology X))]
  intro p hp
  obtain ⟨V,K,hpV,hVK,hK,hKs,hpK⟩ := exists_compact_separation hlocal hp
  have hprod : @IsOpen (X × X)
      (@instTopologicalSpaceProd X X (patchTopology X) (patchTopology X))
      ((V : Set X) ×ˢ Kᶜ) :=
    @IsOpen.prod X X (patchTopology X) (patchTopology X) (V : Set X) Kᶜ
      (isOpen_original V.isOpen) (isOpen_compl_compact_saturated hK hKs)
  refine ⟨(V : Set X) ×ˢ Kᶜ,?_,hprod,hpV,hpK⟩
  rintro ⟨a,b⟩ ⟨haV,hbK⟩ hab
  exact hbK ((isSaturated_iff_specialization_upper K).mp hKs a b hab (hVK haV))

/-- The upper-open part of the patch correspondence. The compactness here
is explicitly compactness of the actual patch topology, not a premise that
the original topology has already been shown to be Scott. -/
theorem isOpen_of_patch_upper (hlocal : IsLocallyCompact X)
    (hcompact : @CompactSpace X (patchTopology X)) {U : Set X}
    (hU : IsOpen[patchTopology X] U)
    (hupper : ∀ a b, SpecializationLE a b → a ∈ U → b ∈ U) : IsOpen U := by
  classical
  rw [isOpen_iff_forall_mem_open]
  intro x hxU
  have hchoices : ∀ y : {y : X // y ∉ U}, ∃ (V : Opens X) (K : Set X),
      x ∈ V ∧ (V : Set X) ⊆ K ∧ IsCompact K ∧ IsSaturated K ∧ (y : X) ∉ K := by
    intro y
    apply exists_compact_separation hlocal
    intro hxy
    exact y.property (hupper x y hxy hxU)
  choose V K hxV hVK hK hKs hyK using hchoices
  have hF : @IsCompact X (patchTopology X) Uᶜ :=
    @IsClosed.isCompact X (patchTopology X) Uᶜ hcompact
      (@IsOpen.isClosed_compl X (patchTopology X) U hU)
  have hcover : Uᶜ ⊆ ⋃ y : {y : X // y ∉ U}, (K y)ᶜ := by
    intro y hy
    exact mem_iUnion.mpr ⟨⟨y,hy⟩,hyK ⟨y,hy⟩⟩
  obtain ⟨s,hs⟩ := @IsCompact.elim_finite_subcover X (patchTopology X) Uᶜ
    {y : X // y ∉ U} hF (fun y => (K y)ᶜ)
    (fun y => isOpen_compl_compact_saturated (hK y) (hKs y)) hcover
  let W : Set X := ⋂ y ∈ s, (V y : Set X)
  have hW : IsOpen W := s.finite_toSet.isOpen_biInter (fun y _ => (V y).isOpen)
  have hxW : x ∈ W := mem_iInter₂.mpr (fun y _ => hxV y)
  refine ⟨W,?_,hW,hxW⟩
  intro z hzW
  by_contra hzU
  obtain ⟨y,hy,hzK⟩ := mem_iUnion₂.mp (hs hzU)
  exact hzK (hVK y (mem_iInter₂.mp hzW y hy))

theorem isOpen_iff_patch_upper (hlocal : IsLocallyCompact X)
    (hcompact : @CompactSpace X (patchTopology X)) (U : Set X) :
    IsOpen U ↔ IsOpen[patchTopology X] U ∧
      ∀ a b, SpecializationLE a b → a ∈ U → b ∈ U := by
  constructor
  · intro hU
    exact ⟨isOpen_original hU,fun _ _ hxy hx => isOpen_upper_specialization hU hxy hx⟩
  · rintro ⟨hU,hu⟩
    exact isOpen_of_patch_upper hlocal hcompact hU hu

end Patch
end ScottSpectraReviewed
