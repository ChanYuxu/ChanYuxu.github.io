import ScottSpectraReviewed.UpperTopology
import ScottSpectraReviewed.TopologicalModels

/-! Source-model wrappers for the upper topology. Saturation is the literal
intersection-of-open-supersets predicate from the source, not an assumed
upper-set surrogate. The patch equality is a proved bridge for the separately
recorded canonical repair; it does not claim that the closed-set lattice is
continuous. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed

variable {L : Type u} [CompleteLattice L]

theorem upper_isSaturated_iff (K : Set L) :
    @IsSaturated L (upperTopology L) K ↔ IsUpperSet K := by
  letI : TopologicalSpace L := upperTopology L
  rw [isSaturated_iff_specialization_upper]
  constructor
  · intro h x y hxy hx
    exact h x y ((specializationLE_iff x y).mpr ((upper_specializes_iff y x).mpr hxy)) hx
  · intro h x y hxy hx
    exact h ((upper_specializes_iff y x).mp ((specializationLE_iff x y).mp hxy)) hx

/-- Coherence for the actual source saturation predicate, by its printed
join-image argument. -/
theorem upper_isCoherent (L : Type u) [CompleteLattice L] :
    @IsCoherent L (upperTopology L) := by
  intro K H hK hKs hH hHs
  exact upper_isCompact_inter_via_sup ((upper_isSaturated_iff K).mp hKs)
    ((upper_isSaturated_iff H).mp hHs) hK hH

/-- Every frame with the upper topology is a web space. Both the fixed-meet
map and its needed continuity were proved in `UpperTopology`; no additional
local compactness, coframe law or Scott-space hypothesis is used. -/
theorem upper_isWebSpace (hL : IsFrame L) : @IsWebSpace L (upperTopology L) := by
  letI : TopologicalSpace L := upperTopology L
  letI : Topology.IsUpper L := ⟨rfl⟩
  intro x U hU
  obtain ⟨V,hVU,hVopen,hxV⟩ := mem_nhds_iff.mp hU
  let W : Set L := (fun y : L => x ⊓ y) ⁻¹' V
  have hWopen : IsOpen W := hVopen.preimage (upper_continuous_inf_left hL x)
  have hxW : x ∈ W := by simpa only [W,mem_preimage,inf_idem] using hxV
  have hWV : W ⊆ V := by
    intro y hy
    exact (Topology.IsUpper.isUpperSet_of_isOpen hVopen) inf_le_right hy
  refine ⟨W,hWV.trans hVU,hWopen.mem_nhds hxW,?_⟩
  intro y hy
  refine ⟨x ⊓ y, ?_, ?_, ?_⟩
  · simpa only [W,mem_preimage,← inf_assoc,inf_idem] using hy
  · exact (specializationLE_iff _ _).mpr ((upper_specializes_iff _ _).mpr inf_le_left)
  · exact (specializationLE_iff _ _).mpr ((upper_specializes_iff _ _).mpr inf_le_right)

/-- The upper topology on a complete lattice is stably compact whenever it
has the manuscript's compact-saturated sandwich form of local compactness. -/
theorem upper_isStablyCompact (hlocal : @IsLocallyCompact L (upperTopology L)) :
    @IsStablyCompact L (upperTopology L) :=
  ⟨upper_compactSpace L,hlocal,upper_quasiSober L,upper_t0Space L,upper_isCoherent L⟩

/-- The exact patch identification needed by the corrected canonical route.
This holds for every complete lattice, and does not assert continuity of L. -/
theorem upper_patchTopology_eq_dualLawson (L : Type u) [CompleteLattice L] :
    @patchTopology L (upperTopology L) = lawsonTopology Lᵒᵈ := by
  have hfamily :
      {U : Set L | ∃ K : Set L, @IsCompact L (upperTopology L) K ∧
        @IsSaturated L (upperTopology L) K ∧ Kᶜ = U} =
      {U : Set L | IsOpen[scottTopology Lᵒᵈ] U} := by
    ext U
    constructor
    · rintro ⟨K,hK,hKs,rfl⟩
      exact @IsClosed.isOpen_compl Lᵒᵈ (scottTopology Lᵒᵈ) K
        (dualScottClosed_of_upper_isCompact ((upper_isSaturated_iff K).mp hKs) hK)
    · intro hU
      have hK : IsClosed[scottTopology Lᵒᵈ] Uᶜ :=
        @IsOpen.isClosed_compl Lᵒᵈ (scottTopology Lᵒᵈ) U hU
      have hupper : IsUpperSet (Uᶜ : Set L) := ((isScottClosed_iff (P := Lᵒᵈ) Uᶜ).mp hK).1
      exact ⟨Uᶜ,upper_isCompact_of_dualScottClosed hK,
        (upper_isSaturated_iff _).mpr hupper,compl_compl U⟩
  change generateFrom
    ({U : Set L | IsOpen[upperTopology L] U} ∪
      {U | ∃ K : Set L, @IsCompact L (upperTopology L) K ∧
        @IsSaturated L (upperTopology L) K ∧ Kᶜ = U}) = _
  rw [hfamily]
  exact @generateFrom_union_isOpen L (upperTopology L) (scottTopology Lᵒᵈ)

/-- Applying the same actual patch construction to a topology identified
with the upper topology. This preserves the chosen topology, not just an
abstract homeomorphic compact space. -/
theorem patchTopology_eq_dualLawson_of_eq_upper (t : TopologicalSpace L)
    (ht : t = upperTopology L) : @patchTopology L t = lawsonTopology Lᵒᵈ := by
  subst t
  exact upper_patchTopology_eq_dualLawson L

end ScottSpectraReviewed
