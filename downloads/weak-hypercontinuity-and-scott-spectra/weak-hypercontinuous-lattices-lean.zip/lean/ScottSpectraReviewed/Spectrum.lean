import ScottSpectraReviewed.OrderBasics
import Mathlib.Order.PFilter

/-! The actual spectrum consists of proper completely prime lattice filters.
Its order is inclusion of the full carriers. -/

noncomputable section
open Set
universe u v

namespace ScottSpectraReviewed

structure Spectrum (L : Type u) [CompleteLattice L] where
  filter : Order.PFilter L
  proper : (⊥ : L) ∉ filter
  completely_prime (S : Set L) : sSup S ∈ filter → ∃ a ∈ S, a ∈ filter

namespace Spectrum
variable {L : Type u} [CompleteLattice L]

instance : SetLike (Spectrum L) L where
  coe F := F.filter
  coe_injective' := by
    intro F G h
    have e : F.filter = G.filter := Order.PFilter.ext _ _ h
    cases F
    cases G
    cases e
    rfl

instance : PartialOrder (Spectrum L) := PartialOrder.ofSetLike (Spectrum L) L

theorem mem_of_le (F : Spectrum L) {a b : L} (hab : a ≤ b) (ha : a ∈ F) : b ∈ F :=
  Order.PFilter.mem_of_le hab ha

@[simp] theorem top_mem (F : Spectrum L) : (⊤ : L) ∈ F :=
  Order.PFilter.top_mem

@[simp] theorem bot_not_mem (F : Spectrum L) : (⊥ : L) ∉ F := F.proper

@[simp] theorem inf_mem_iff (F : Spectrum L) (a b : L) :
    a ⊓ b ∈ F ↔ a ∈ F ∧ b ∈ F := Order.PFilter.inf_mem_iff

@[simp] theorem sSup_mem_iff (F : Spectrum L) (S : Set L) :
    sSup S ∈ F ↔ ∃ a ∈ S, a ∈ F := by
  constructor
  · exact F.completely_prime S
  · rintro ⟨a, ha, haF⟩
    exact F.mem_of_le (le_sSup ha) haF

/-- The printed basic hull-kernel open. -/
def hat (a : L) : Set (Spectrum L) := {F | a ∈ F}

@[simp] theorem hat_top : hat (⊤ : L) = Set.univ := by ext F; simp [hat]

@[simp] theorem hat_bot : hat (⊥ : L) = ∅ := by ext F; simp [hat]

theorem hat_inf (a b : L) : hat (a ⊓ b) = hat a ∩ hat b := by
  ext F
  exact F.inf_mem_iff a b

theorem hat_sSup (S : Set L) : hat (sSup S) = ⋃ a ∈ S, hat a := by
  ext F
  simp only [hat, mem_setOf_eq, mem_iUnion, sSup_mem_iff, exists_prop]

/-- All hull-kernel opens are hats, including arbitrary unions and empty ones. -/
@[implicit_reducible]
def hullKernelTopology : TopologicalSpace (Spectrum L) where
  IsOpen U := ∃ a : L, hat a = U
  isOpen_univ := ⟨⊤, hat_top⟩
  isOpen_inter := by
    rintro U V ⟨a, rfl⟩ ⟨b, rfl⟩
    exact ⟨a ⊓ b, hat_inf a b⟩
  isOpen_sUnion := by
    intro S hS
    choose a ha using hS
    refine ⟨⨆ (U : S), a U.1 U.2, ?_⟩
    ext F
    simp only [hat, mem_setOf_eq, mem_sUnion]
    constructor
    · intro hF
      have heq : (⨆ U : S, a U.1 U.2) = sSup (Set.range (fun U : S => a U.1 U.2)) :=
        rfl
      rw [heq, sSup_mem_iff] at hF
      obtain ⟨_, ⟨U, rfl⟩, hFU⟩ := hF
      exact ⟨U.1, U.2, (Set.ext_iff.mp (ha U.1 U.2) F).mp hFU⟩
    · rintro ⟨U, hU, hFU⟩
      have haFU : a U hU ∈ F := (Set.ext_iff.mp (ha U hU) F).mpr hFU
      exact F.mem_of_le (le_iSup (fun V : S => a V.1 V.2) ⟨U, hU⟩) haFU

end Spectrum

def SpectrumIsScott (L : Type u) [CompleteLattice L] : Prop :=
  Spectrum.hullKernelTopology (L := L) = scottTopology (Spectrum L)

/-- Exact main statement. This is only a proposition definition, not a proof. -/
def MainStatement : Prop :=
  ∀ (L : Type u) [CompleteLattice L], IsDistributive L → IsContinuousLattice L →
    (SpectrumIsScott L ↔ DualTopologyEquality L)

end ScottSpectraReviewed
