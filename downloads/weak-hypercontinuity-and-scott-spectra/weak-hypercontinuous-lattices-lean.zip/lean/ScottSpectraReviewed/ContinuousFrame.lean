import ScottSpectraReviewed.ContinuousLatticeBasics

/-! The operative preliminary assertion in the reviewed source, lines 148--156:
every distributive continuous lattice is a frame. The proof follows the source:
take finite joins, apply meet-continuity, then use finite distributivity.
Finite joins include the empty join, so this proves the law also for `S = ∅`.
-/

noncomputable section
open Set
universe u

namespace ScottSpectraReviewed

/-- All finite joins from a set, including the empty join. -/
def finiteJoins {L : Type u} [CompleteLattice L] (S : Set L) : Set L :=
  {d | ∃ F : Set L, F.Finite ∧ F ⊆ S ∧ sSup F = d}

theorem finiteJoins_nonemptyDirected {L : Type u} [CompleteLattice L]
    (S : Set L) : NonemptyDirected (finiteJoins S) := by
  constructor
  · exact ⟨⊥, ∅, finite_empty, empty_subset S, sSup_empty⟩
  · rintro d ⟨F, hF, hFS, rfl⟩ e ⟨G, hG, hGS, rfl⟩
    exact ⟨sSup (F ∪ G), ⟨F ∪ G, hF.union hG, union_subset hFS hGS, rfl⟩,
      sSup_le_sSup subset_union_left, sSup_le_sSup subset_union_right⟩

theorem finiteJoins_isLUB {L : Type u} [CompleteLattice L]
    (S : Set L) : IsLUB (finiteJoins S) (sSup S) := by
  constructor
  · rintro d ⟨F, _, hFS, rfl⟩
    exact sSup_le_sSup hFS
  · intro z hz
    apply sSup_le
    intro s hs
    have hmem : s ∈ finiteJoins S :=
      ⟨{s}, finite_singleton s, singleton_subset_iff.mpr hs, sSup_singleton⟩
    exact hz hmem

theorem sSup_finiteJoins {L : Type u} [CompleteLattice L] (S : Set L) :
    sSup (finiteJoins S) = sSup S :=
  (isLUB_sSup _).unique (finiteJoins_isLUB S)

/-- Finite distributivity, still stated only with the source's ordinary
binary-distributivity hypothesis. -/
theorem distributive_inf_sSup_finite {L : Type u} [CompleteLattice L]
    (hL : IsDistributive L) (a : L) (F : Set L) (hF : F.Finite) :
    a ⊓ sSup F = sSup ((fun s => a ⊓ s) '' F) := by
  induction F, hF using Set.Finite.induction_on with
  | empty => simp
  | @insert s F hs hF ih =>
      rw [sSup_insert, hL, ih, Set.image_insert_eq, sSup_insert]

/-- Exact source-facing preliminary result: a continuous complete lattice with
ordinary finite distributivity satisfies the actual arbitrary-join frame law. -/
theorem continuousDistributiveLattice_isFrame {L : Type u} [CompleteLattice L]
    (hcontinuous : IsContinuousLattice L) (hdistributive : IsDistributive L) :
    IsFrame L := by
  intro a S
  calc
    a ⊓ sSup S = a ⊓ sSup (finiteJoins S) := by rw [sSup_finiteJoins]
    _ = sSup ((fun d => a ⊓ d) '' finiteJoins S) :=
      continuousLattice_meet_continuous hcontinuous a _ (finiteJoins_nonemptyDirected S)
    _ = sSup ((fun s => a ⊓ s) '' S) := by
      apply le_antisymm
      · apply sSup_le
        rintro _ ⟨d, ⟨F, hF, hFS, rfl⟩, rfl⟩
        change a ⊓ sSup F ≤ _
        rw [distributive_inf_sSup_finite hdistributive a F hF]
        exact sSup_le_sSup (image_mono hFS)
      · apply sSup_le
        rintro _ ⟨s, hs, rfl⟩
        exact le_sSup ⟨s,
          ⟨{s}, finite_singleton s, singleton_subset_iff.mpr hs, sSup_singleton⟩, rfl⟩

end ScottSpectraReviewed
