import ScottSpectraReviewed.ContinuousLatticeBasics
import Mathlib.Topology.Compactness.Compact
import Mathlib.Topology.Order.OrderClosed

/-! Lawson foundations for the reviewed source, lines 245--249.

Closed order, Hausdorffness and compactness are adapted from
`CoreCompactNonSober/simplified/CoreCompactSimplified/HeZhangLawsonBasic.lean`,
SHA-256 `13c1eba532695f40b7688bd7a1721ee33b6e2cc2fdf5093e764e1b2653ea3781`.
Its exact arbitrary-directed-set definitions have been compared with the
current source definitions; the current `ContinuousLatticeBasics` contains the
checked interpolation/open-set prerequisites. No origin module or acceptance
status is imported. The joint meet continuity argument below is newly written.
-/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed

/-- The source defines Lawson as the topology generated jointly by Scott and
upper topology on the order dual. Mathlib orders topologies by reverse inclusion
of open sets, so this generated join is its lattice meet. -/
theorem lawsonTopology_eq_scott_inf_upperDual {P : Type u} [Preorder P] :
    lawsonTopology P = scottTopology P ⊓ upperTopology Pᵒᵈ := by
  change Topology.lower P ⊓ Topology.scott P univ =
    Topology.scott P univ ⊓ Topology.lower P
  exact inf_comm (Topology.lower P) (Topology.scott P univ)

theorem isLawsonOpen_wayAbove {P : Type u} [PartialOrder P]
    (hP : IsContinuousDcpo P) (a : P) :
    IsOpen[lawsonTopology P] {x | WayBelow a x} :=
  Topology.lawson_le_scott _ (isScottOpen_wayAbove hP a)

theorem isLawsonOpen_compl_Ici {P : Type u} [Preorder P] (a : P) :
    IsOpen[lawsonTopology P] (Ici a)ᶜ :=
  Topology.lawson_le_lower _ (isOpen_generateFrom_of_mem ⟨a, rfl⟩)

/-- A separating rectangle proves closedness of order on every continuous dcpo. -/
theorem lawson_orderClosed {P : Type u} [PartialOrder P]
    (hP : IsContinuousDcpo P) : @OrderClosedTopology P (lawsonTopology P) _ := by
  letI : TopologicalSpace P := lawsonTopology P
  constructor
  apply isOpen_compl_iff.mp
  apply isOpen_iff_mem_nhds.mpr
  rintro ⟨a, b⟩ hab
  change ¬a ≤ b at hab
  have hex : ∃ z, WayBelow z a ∧ ¬z ≤ b := by
    by_contra! h
    exact hab ((hP.2 a).2.2 h)
  obtain ⟨z, hza, hzb⟩ := hex
  let U : Set P := {x | WayBelow z x}
  let V : Set P := (Ici z)ᶜ
  have hUV : U ×ˢ V ∈ 𝓝 (a, b) :=
    ((isLawsonOpen_wayAbove hP z).prod (isLawsonOpen_compl_Ici z)).mem_nhds
      ⟨hza, hzb⟩
  apply Filter.mem_of_superset hUV
  rintro ⟨x, y⟩ ⟨hx, hy⟩ hxy
  exact hy ((wayBelow_le hx).trans hxy)

theorem lawson_t2Space {P : Type u} [PartialOrder P]
    (hP : IsContinuousDcpo P) : @T2Space P (lawsonTopology P) := by
  letI : TopologicalSpace P := lawsonTopology P
  letI : OrderClosedTopology P := lawson_orderClosed hP
  infer_instance

theorem lawson_orderRelations_closed {P : Type u} [PartialOrder P]
    (hP : IsContinuousDcpo P) :
    @IsClosed (P × P)
      (@instTopologicalSpaceProd P P (lawsonTopology P) (lawsonTopology P))
      {p | p.1 ≤ p.2} ∧
    @IsClosed (P × P)
      (@instTopologicalSpaceProd P P (lawsonTopology P) (lawsonTopology P))
      {p | p.2 ≤ p.1} := by
  letI : TopologicalSpace P := lawsonTopology P
  letI : OrderClosedTopology P := lawson_orderClosed hP
  exact ⟨isClosed_le_prod, isClosed_le_prod'⟩

/-- The ultrafilter argument in fact needs only completeness, not continuity. -/
theorem ultrafilter_le_lawson_nhds {L : Type u} [CompleteLattice L]
    (F : Ultrafilter L) : ∃ x : L, (F : Filter L) ≤ @nhds L (lawsonTopology L) x := by
  let E : Set L := {e | ∃ A : Set L, A ∈ F ∧ sInf A = e}
  have hne : E.Nonempty := ⟨sInf univ, univ, univ_mem, rfl⟩
  have hdir : DirectedOn (· ≤ ·) E := by
    rintro a ⟨A, hAF, rfl⟩ b ⟨B, hBF, rfl⟩
    refine ⟨sInf (A ∩ B), ⟨A ∩ B, inter_mem hAF hBF, rfl⟩, ?_, ?_⟩
    · exact sInf_le_sInf inter_subset_left
    · exact sInf_le_sInf inter_subset_right
  let x : L := sSup E
  refine ⟨x, ?_⟩
  change (F : Filter L) ≤ @nhds L (Topology.lower L ⊓ Topology.scott L univ) x
  rw [nhds_inf]
  apply le_inf
  · have h : Tendsto (id : L → L) F (@nhds L (Topology.lower L) x) := by
      apply tendsto_nhds_generateFrom_iff.mpr
      rintro _ ⟨a, rfl⟩ hax
      change (Ici a)ᶜ ∈ F
      apply Ultrafilter.compl_mem_iff_notMem.mpr
      intro haF
      apply hax
      change a ≤ sSup E
      have hinf : a ≤ sInf (Ici a) := le_sInf fun b hb ↦ hb
      exact hinf.trans (le_sSup ⟨Ici a, haF, rfl⟩)
    simpa only [Filter.Tendsto, Filter.map_id] using h
  · letI : TopologicalSpace L := scottTopology L
    apply le_nhds_iff.mpr
    intro U hxU hU
    obtain ⟨e, ⟨A, hAF, rfl⟩, heU⟩ :=
      ((isScottOpen_iff U).mp hU).2 hne hdir (isLUB_sSup E) hxU
    apply Filter.mem_of_superset hAF
    intro a ha
    exact ((isScottOpen_iff U).mp hU).1 (sInf_le ha) heU

theorem lawson_compactSpace {L : Type u} [CompleteLattice L] :
    @CompactSpace L (lawsonTopology L) := by
  letI : TopologicalSpace L := lawsonTopology L
  constructor
  apply isCompact_iff_ultrafilter_le_nhds.mpr
  intro F _
  obtain ⟨x, hx⟩ := ultrafilter_le_lawson_nhds F
  exact ⟨x, mem_univ _, hx⟩

/-- Exact source-domain compact-Hausdorff interface. The continuity premise is
retained, although compactness alone holds on every complete lattice. -/
theorem continuousLattice_lawson_compact_hausdorff {L : Type u} [CompleteLattice L]
    (hL : IsContinuousLattice L) :
    @CompactSpace L (lawsonTopology L) ∧ @T2Space L (lawsonTopology L) :=
  ⟨lawson_compactSpace, lawson_t2Space hL⟩

/-- Exact source-domain closed-order interface. -/
theorem continuousLattice_lawson_orderClosed {L : Type u} [CompleteLattice L]
    (hL : IsContinuousLattice L) : @OrderClosedTopology L (lawsonTopology L) _ :=
  lawson_orderClosed hL

/-- Binary meet is jointly Lawson continuous on every continuous complete
lattice. No finite/infinite distributivity or countability is assumed. -/
theorem continuousLattice_lawson_inf {L : Type u} [CompleteLattice L]
    (hL : IsContinuousLattice L) :
    @Continuous (L × L) L
      (@instTopologicalSpaceProd L L (lawsonTopology L) (lawsonTopology L))
      (lawsonTopology L) (fun p => p.1 ⊓ p.2) := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : OrderClosedTopology L := lawson_orderClosed hL
  have hscott : @Continuous (L × L) L _ (scottTopology L)
      (fun p => p.1 ⊓ p.2) := by
    apply continuous_def.mpr
    intro U hU
    apply isOpen_iff_mem_nhds.mpr
    rintro ⟨a, b⟩ habU
    obtain ⟨c, hc, hcU⟩ := ((isScottOpen_iff U).mp hU).2
      (hL.2 (a ⊓ b)).1.1 (hL.2 (a ⊓ b)).1.2 (hL.2 (a ⊓ b)).2 habU
    have hca : WayBelow c a := wayBelow_mono le_rfl hc inf_le_left
    have hcb : WayBelow c b := wayBelow_mono le_rfl hc inf_le_right
    have hV := isLawsonOpen_wayAbove hL c
    have hN : {x | WayBelow c x} ×ˢ {x | WayBelow c x} ∈ 𝓝 (a, b) :=
      (hV.prod hV).mem_nhds ⟨hca, hcb⟩
    apply Filter.mem_of_superset hN
    rintro ⟨x, y⟩ ⟨hx, hy⟩
    exact ((isScottOpen_iff U).mp hU).1 (le_inf (wayBelow_le hx) (wayBelow_le hy)) hcU
  have hlower : @Continuous (L × L) L _ (Topology.lower L)
      (fun p => p.1 ⊓ p.2) := by
    apply continuous_generateFrom_iff.mpr
    rintro _ ⟨a, rfl⟩
    have hpre : (fun p : L × L => p.1 ⊓ p.2) ⁻¹' (Ici a)ᶜ =
        ((Ici a) ×ˢ (Ici a))ᶜ := by
      ext p
      simp only [mem_preimage, mem_compl_iff, mem_Ici, mem_prod, le_inf_iff]
    rw [hpre]
    exact (isClosed_Ici.prod isClosed_Ici).isOpen_compl
  change @Continuous (L × L) L _ (Topology.lower L ⊓ scottTopology L)
    (fun p => p.1 ⊓ p.2)
  exact continuous_inf_rng.mpr ⟨hlower, hscott⟩

end ScottSpectraReviewed
