import ScottSpectraReviewed.UpperTopologySobriety
import ScottSpectraReviewed.StableWeb
import Mathlib.Order.Bounds.OrderIso

/-! Actual order/topology transport for the last clause of source
`lem:upper-topology` and the complement-isomorphism step in
`lem:hyperspace-scott`. The complete stably-compact-web argument is proved
in the imported source theorem; no such conclusion is stored as an extra
assumption of the numbered lemma. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u v

namespace ScottSpectraReviewed

theorem upper_specializationOrder_eq (L : Type u) [CompleteLattice L] :
    @specializationOrder L (upperTopology L) (upper_t0Space L) =
      (inferInstance : PartialOrder L) :=
  PartialOrder.ext (fun x y => upper_specializes_iff y x)

/-- The last clause of source `lem:upper-topology`, proved through the
actual stably-compact-web corollary. The specialization order is explicitly
identified with the original lattice order before comparing Scott topologies.
-/
theorem upper_eq_scott_of_frame_locallyCompact {L : Type u} [CompleteLattice L]
    (hframe : IsFrame L) (hlocal : @IsLocallyCompact L (upperTopology L)) :
    upperTopology L=scottTopology L := by
  letI : TopologicalSpace L := upperTopology L
  letI : T0Space L := upper_t0Space L
  have h := source_stableweb (upper_isStablyCompact hlocal) (upper_isWebSpace hframe)
  change upperTopology L = @scottTopology L
    (@specializationOrder L (upperTopology L) (upper_t0Space L)).toPreorder at h
  rw [upper_specializationOrder_eq L] at h
  exact h

/-- Full numbered source `lem:upper-topology`, not only its earlier basic
compact/sober/coherent subset. Sobriety has its actual existence and T0
uniqueness components. The final equality has exactly the frame and genuine
compact-saturated local-compactness hypotheses in the manuscript. -/
theorem source_upper_topology (L : Type u) [CompleteLattice L] :
    @CompactSpace L (upperTopology L) ∧ @QuasiSober L (upperTopology L) ∧
      @T0Space L (upperTopology L) ∧ @IsCoherent L (upperTopology L) ∧
      (IsFrame L → @IsLocallyCompact L (upperTopology L) → upperTopology L=scottTopology L) :=
  ⟨upper_compactSpace L,upper_quasiSober L,upper_t0Space L,upper_isCoherent L,
    upper_eq_scott_of_frame_locallyCompact⟩

namespace OrderIsoTransfer
variable {P : Type u} {Q : Type v} [Preorder P] [Preorder Q]

/-- Order isomorphisms preserve the full Scott topology, with arbitrary
existing directed suprema, not merely a sequential approximation topology. -/
theorem continuous_scott (e : P ≃o Q) :
    @Continuous P Q (scottTopology P) (scottTopology Q) e := by
  apply continuous_def.mpr
  intro U hU
  obtain ⟨hupper,hinacc⟩ := (isScottOpen_iff U).mp hU
  apply (isScottOpen_iff (e ⁻¹' U)).mpr
  refine ⟨hupper.preimage e.monotone,?_⟩
  intro D hDne hDdir x hx hxU
  have hdir : DirectedOn (· ≤ ·) (e '' D) :=
    directedOn_image.mpr (hDdir.mono e.monotone)
  obtain ⟨_,⟨d,hd,rfl⟩,hdU⟩ := hinacc (hDne.image e) hdir (e.isLUB_image'.mpr hx) hxU
  exact ⟨d,hd,hdU⟩

theorem continuous_upper (e : P ≃o Q) :
    @Continuous P Q (upperTopology P) (upperTopology Q) e := by
  apply continuous_generateFrom_iff.mpr
  rintro _ ⟨b,rfl⟩
  have heq : e ⁻¹' (Iic b)ᶜ=(Iic (e.symm b))ᶜ := by
    ext x
    simp only [mem_preimage,mem_compl_iff,mem_Iic,e.le_symm_apply]
  rw [heq]
  exact isOpen_generateFrom_of_mem ⟨e.symm b,rfl⟩

theorem isOpen_scott_iff_preimage (e : P ≃o Q) (U : Set Q) :
    IsOpen[scottTopology Q] U ↔ IsOpen[scottTopology P] (e ⁻¹' U) := by
  letI : TopologicalSpace P := scottTopology P
  letI : TopologicalSpace Q := scottTopology Q
  constructor
  · exact fun h => h.preimage (continuous_scott e)
  · intro h
    have h' := h.preimage (continuous_scott e.symm)
    simpa only [preimage_preimage,Function.comp_def,e.apply_symm_apply,preimage_id'] using h'

theorem isOpen_upper_iff_preimage (e : P ≃o Q) (U : Set Q) :
    IsOpen[upperTopology Q] U ↔ IsOpen[upperTopology P] (e ⁻¹' U) := by
  letI : TopologicalSpace P := upperTopology P
  letI : TopologicalSpace Q := upperTopology Q
  constructor
  · exact fun h => h.preimage (continuous_upper e)
  · intro h
    have h' := h.preimage (continuous_upper e.symm)
    simpa only [preimage_preimage,Function.comp_def,e.apply_symm_apply,preimage_id'] using h'

/-- Topology equality is transported along the actual specified order
isomorphism, not asserted on an unrelated homeomorphic model. -/
theorem scott_eq_upper (e : P ≃o Q) (hP : scottTopology P=upperTopology P) :
    scottTopology Q=upperTopology Q := by
  apply TopologicalSpace.ext
  funext U
  apply propext
  rw [isOpen_scott_iff_preimage e U,isOpen_upper_iff_preimage e U,hP]

end OrderIsoTransfer

namespace OrderIsoTransfer
variable {P : Type u} {Q : Type v} [CompleteLattice P] [CompleteLattice Q]

/-- The full arbitrary-join frame identity is preserved, including the
empty family, by an actual complete-lattice order isomorphism. -/
theorem isFrame (e : P ≃o Q) (hP : IsFrame P) : IsFrame Q := by
  intro a S
  apply e.symm.injective
  calc
    e.symm (a ⊓ sSup S) = e.symm a ⊓ sSup (e.symm '' S) := by
      rw [InfHomClass.map_inf,map_sSup]
    _ = sSup ((fun b => e.symm a ⊓ b) '' (e.symm '' S)) := hP _ _
    _ = e.symm (sSup ((fun b => a ⊓ b) '' S)) := by
      rw [map_sSup]
      have hf : (fun b : Q => e.symm a ⊓ e.symm b)=(fun b : Q => e.symm (a ⊓ b)) :=
        funext (fun b => (InfHomClass.map_inf e.symm a b).symm)
      simpa only [image_image,Function.comp_def] using
        congrArg (fun g : Q → P => sSup (g '' S)) hf

end OrderIsoTransfer
end ScottSpectraReviewed
