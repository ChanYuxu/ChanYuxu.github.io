import ScottSpectraReviewed.LawsonBasics
import Mathlib.Topology.Homeomorph.Lemmas

/-! Arbitrary products of continuous complete lattices, source lines 248--250.
The carrier is the full dependent function space, not finite-support functions.
Single-coordinate bottom extensions are only used to prove approximation.
The Lawson/product-topology identity uses continuity of all evaluations and
the compact-to-Hausdorff identity-map argument.
-/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed

theorem nonemptyDirected_pi_eval {ι : Type u} {L : ι → Type v}
    [∀ i, Preorder (L i)] (D : Set (∀ i, L i)) (hD : NonemptyDirected D) (i : ι) :
    NonemptyDirected (Function.eval i '' D) := by
  constructor
  · exact hD.1.image _
  · rintro a ⟨f, hf, rfl⟩ b ⟨g, hg, rfl⟩
    obtain ⟨k, hk, hfk, hgk⟩ := hD.2 f hf g hg
    exact ⟨k i, ⟨k, hk, rfl⟩, hfk i, hgk i⟩

/-- Extend one coordinate by bottom in every other coordinate of the full Pi. -/
def piSingleBottom {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (i : ι) (a : L i) : ∀ j, L j := by
  classical
  exact Function.update ⊥ i a

theorem piSingleBottom_le_iff {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (i : ι) (a : L i) (x : ∀ j, L j) :
    piSingleBottom i a ≤ x ↔ a ≤ x i := by
  classical
  simp [piSingleBottom, update_le_iff]

@[simp] theorem piSingleBottom_apply_self {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (i : ι) (a : L i) : piSingleBottom i a i = a := by
  classical
  simp [piSingleBottom]

theorem wayBelow_piSingleBottom {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (i : ι) {a : L i} {x : ∀ j, L j}
    (ha : WayBelow a (x i)) : WayBelow (piSingleBottom i a) x := by
  intro D hD y hy hxy
  obtain ⟨b, ⟨d, hd, rfl⟩, had⟩ :=
    ha (Function.eval i '' D) (nonemptyDirected_pi_eval D hD i)
      (y i) ((isLUB_pi.mp hy) i) (hxy i)
  exact ⟨d, hd, (piSingleBottom_le_iff i a d).mpr had⟩

/-- Every arbitrary dependent product of continuous complete lattices is a
continuous complete lattice, on its full function carrier. -/
theorem continuousLattice_pi {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (hL : ∀ i, IsContinuousLattice (L i)) :
    IsContinuousLattice (∀ i, L i) := by
  refine ⟨completeLattice_isDcpo _, fun x => ?_⟩
  constructor
  · refine ⟨⟨⊥, wayBelow_bot _ _⟩, ?_⟩
    intro a ha b hb
    exact ⟨a ⊔ b, wayBelow_sup ha hb, le_sup_left, le_sup_right⟩
  · constructor
    · intro a ha
      exact wayBelow_le ha
    · intro z hz i
      apply ((hL i).2 (x i)).2.2
      intro a ha
      have hs := hz (wayBelow_piSingleBottom i ha)
      simpa only [piSingleBottom_apply_self] using hs i

/-- Useful source-host instance: the genuine full endofunction lattice `L^L`. -/
theorem continuousLattice_endofunction {L : Type u} [CompleteLattice L]
    (hL : IsContinuousLattice L) : IsContinuousLattice (L → L) :=
  continuousLattice_pi (fun _ : L => hL)

/-- All coordinate evaluations preserve the full Scott topology. -/
theorem continuous_scott_pi_eval {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (i : ι) :
    @Continuous (∀ j, L j) (L i) (scottTopology (∀ j, L j)) (scottTopology (L i))
      (Function.eval i) := by
  apply continuous_def.mpr
  intro U hU
  apply (isScottOpen_iff _).mpr
  constructor
  · intro x y hxy hx
    exact ((isScottOpen_iff U).mp hU).1 (hxy i) hx
  · intro D hDne hDdir x hx hxU
    have hDi := nonemptyDirected_pi_eval D ⟨hDne, hDdir⟩ i
    obtain ⟨a, ⟨d, hd, rfl⟩, haU⟩ :=
      ((isScottOpen_iff U).mp hU).2 hDi.1 hDi.2 ((isLUB_pi.mp hx) i) hxU
    exact ⟨d, hd, haU⟩

/-- All coordinate evaluations are Lawson continuous, even before continuity
of the individual complete lattices is assumed. -/
theorem continuous_lawson_pi_eval {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (i : ι) :
    @Continuous (∀ j, L j) (L i) (lawsonTopology (∀ j, L j)) (lawsonTopology (L i))
      (Function.eval i) := by
  have hscott : @Continuous (∀ j, L j) (L i) (lawsonTopology (∀ j, L j))
      (scottTopology (L i)) (Function.eval i) :=
    continuous_le_dom
      (show lawsonTopology (∀ j, L j) ≤ scottTopology (∀ j, L j) from inf_le_right)
      (continuous_scott_pi_eval i)
  have hlower : @Continuous (∀ j, L j) (L i) (lawsonTopology (∀ j, L j))
      (Topology.lower (L i)) (Function.eval i) := by
    apply continuous_generateFrom_iff.mpr
    rintro _ ⟨a, rfl⟩
    have hpre : Function.eval i ⁻¹' (Ici a)ᶜ = (Ici (piSingleBottom i a))ᶜ := by
      ext x
      change (¬a ≤ x i) ↔ ¬piSingleBottom i a ≤ x
      exact not_congr (piSingleBottom_le_iff i a x).symm
    rw [hpre]
    exact isLawsonOpen_compl_Ici (piSingleBottom i a)
  change @Continuous (∀ j, L j) (L i) (lawsonTopology (∀ j, L j))
    (Topology.lower (L i) ⊓ scottTopology (L i)) (Function.eval i)
  exact continuous_inf_rng.mpr ⟨hlower, hscott⟩

/-- Exact arbitrary-product Lawson-topology identity on the full Pi carrier. -/
theorem continuousLattice_pi_lawsonTopology_eq {ι : Type u} {L : ι → Type v}
    [∀ i, CompleteLattice (L i)] (hL : ∀ i, IsContinuousLattice (L i)) :
    lawsonTopology (∀ i, L i) =
      @Pi.topologicalSpace ι L (fun i => lawsonTopology (L i)) := by
  letI : ∀ i, TopologicalSpace (L i) := fun i => lawsonTopology (L i)
  let tprod : TopologicalSpace (∀ i, L i) :=
    @Pi.topologicalSpace ι L (fun i => lawsonTopology (L i))
  have hId : @Continuous (∀ i, L i) (∀ i, L i)
      (lawsonTopology (∀ i, L i)) tprod id := by
    exact @continuous_pi (∀ i, L i) ι L (lawsonTopology (∀ i, L i))
      (fun i => lawsonTopology (L i)) id (fun i => continuous_lawson_pi_eval i)
  have ht2 : @T2Space (∀ i, L i) tprod := by
    letI : ∀ i, T2Space (L i) := fun i => lawson_t2Space (hL i)
    infer_instance
  have hinv : @Continuous (∀ i, L i) (∀ i, L i)
      tprod (lawsonTopology (∀ i, L i)) id :=
    @Continuous.continuous_symm_of_equiv_compact_to_t2
      (∀ i, L i) (∀ i, L i) (lawsonTopology (∀ i, L i)) tprod
      lawson_compactSpace ht2 (Equiv.refl _) hId
  exact le_antisymm (continuous_id_iff_le.mp hId) (continuous_id_iff_le.mp hinv)

theorem continuousLattice_endofunction_lawsonTopology_eq {L : Type u} [CompleteLattice L]
    (hL : IsContinuousLattice L) :
    lawsonTopology (L → L) = @Pi.topologicalSpace L (fun _ => L)
      (fun _ => lawsonTopology L) :=
  continuousLattice_pi_lawsonTopology_eq (fun _ : L => hL)

end ScottSpectraReviewed
