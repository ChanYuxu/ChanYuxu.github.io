import Mathlib.Topology.Baire.Lemmas
import Mathlib.Topology.MetricSpace.Pseudo.Lemmas
import Mathlib.Topology.MetricSpace.Defs
import Mathlib.Order.Filter.CountablyGenerated
import Mathlib.Tactic.Positivity

/-! The Baire separate-continuity lemma cited as Proposition 3.1 in
Lawson (1974), printed p.277. Source/OCR bindings and the exact planned
interfaces are in `audit/worker-upper-lawson-interfaces.md`.

The domain X is only Baire; the neighborhood filter at the specified y₀
is countably generated. No global first-countability or metric hypothesis
is placed on X or Y. The metric is on the codomain only. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u v w

namespace ScottSpectraReviewed
namespace LawsonBaire

variable {X : Type u} {Y : Type v} {Z : Type w}
variable [TopologicalSpace X] [TopologicalSpace Y] [PseudoMetricSpace Z]

/-- Uniform oscillation on one member of the actual countable local basis. -/
def oscillationControl (f : X → Y → Z) (y₀ : Y) (B : ℕ → Set Y)
    (r : ℝ) (n : ℕ) : Set X :=
  {x | ∀ y ∈ B n, dist (f x y) (f x y₀) ≤ r}

omit [TopologicalSpace Y] in
theorem oscillationControl_isClosed (f : X → Y → Z) (y₀ : Y)
    (B : ℕ → Set Y) (r : ℝ) (n : ℕ)
    (hleft : ∀ y, Continuous (fun x => f x y)) :
    IsClosed (oscillationControl f y₀ B r n) := by
  simpa only [oscillationControl,setOf_forall] using
    (isClosed_iInter fun y : Y => isClosed_iInter fun _ : y ∈ B n =>
      isClosed_le ((hleft y).dist (hleft y₀)) continuous_const)

omit [TopologicalSpace X] in
theorem oscillationControl_cover (f : X → Y → Z) (y₀ : Y)
    (B : ℕ → Set Y) (hB : (𝓝 y₀).HasBasis (fun _ : ℕ => True) B)
    (hright : ∀ x, Continuous (f x)) {r : ℝ} (hr : 0 < r) :
    ⋃ n, oscillationControl f y₀ B r n = univ := by
  apply eq_univ_of_forall
  intro x
  have hev : {y | dist (f x y) (f x y₀) < r} ∈ 𝓝 y₀ :=
    (Metric.continuousAt_iff'.mp (hright x).continuousAt) r hr
  obtain ⟨n,_,hn⟩ := hB.mem_iff.mp hev
  exact mem_iUnion.mpr ⟨n,fun y hy => (hn hy).le⟩

theorem jointContinuousAt_of_oscillation_interiors (f : X → Y → Z) (y₀ : Y)
    (B : ℕ → Set Y) (hB : (𝓝 y₀).HasBasis (fun _ : ℕ => True) B)
    (hleft : Continuous (fun x => f x y₀))
    {x : X}
    (hx : ∀ k : ℕ, ∃ n : ℕ,
      x ∈ interior (oscillationControl f y₀ B (1 / (k + 1 : ℝ)) n)) :
    ContinuousAt (fun p : X × Y => f p.1 p.2) (x,y₀) := by
  apply Metric.continuousAt_iff'.mpr
  intro ε hε
  obtain ⟨k,hk⟩ := exists_nat_one_div_lt (half_pos hε)
  obtain ⟨n,hxn⟩ := hx k
  have hleftEv : {a | dist (f a y₀) (f x y₀) < ε / 2} ∈ 𝓝 x :=
    (Metric.continuousAt_iff'.mp hleft.continuousAt) (ε / 2) (half_pos hε)
  have hprod :
      (interior (oscillationControl f y₀ B (1 / (k + 1 : ℝ)) n) ∩
        {a | dist (f a y₀) (f x y₀) < ε / 2}) ×ˢ B n ∈ 𝓝 (x,y₀) :=
    prod_mem_nhds (inter_mem (isOpen_interior.mem_nhds hxn) hleftEv)
      (hB.mem_of_mem trivial)
  apply Filter.mem_of_superset hprod
  rintro ⟨a,b⟩ ⟨⟨ha,haε⟩,hb⟩
  have hab : dist (f a b) (f a y₀) ≤ 1 / (k + 1 : ℝ) :=
    (interior_subset ha) b hb
  calc
    dist (f a b) (f x y₀) ≤ dist (f a b) (f a y₀) + dist (f a y₀) (f x y₀) :=
      dist_triangle _ _ _
    _ < ε / 2 + ε / 2 := add_lt_add (hab.trans_lt hk) haε
    _ = ε := add_halves ε

/-- Residual joint continuity along the specified countably based slice,
first with the actual neighborhood basis exposed. -/
theorem residual_jointContinuousAt_of_basis [BaireSpace X]
    (f : X → Y → Z) (y₀ : Y) (B : ℕ → Set Y)
    (hB : (𝓝 y₀).HasBasis (fun _ : ℕ => True) B)
    (hleft : ∀ y, Continuous (fun x => f x y))
    (hright : ∀ x, Continuous (f x)) :
    {x | ContinuousAt (fun p : X × Y => f p.1 p.2) (x,y₀)} ∈ residual X := by
  let G : ℕ → Set X := fun k =>
    ⋃ n, interior (oscillationControl f y₀ B (1 / (k + 1 : ℝ)) n)
  have hGopen : ∀ k, IsOpen (G k) := fun k => isOpen_iUnion fun _ => isOpen_interior
  have hGdense : ∀ k, Dense (G k) := by
    intro k
    apply dense_iUnion_interior_of_closed
    · intro n
      exact oscillationControl_isClosed f y₀ B _ n hleft
    · exact oscillationControl_cover f y₀ B hB hright (by positivity)
  have hres : (⋂ k, G k) ∈ residual X :=
    residual_of_dense_Gδ (.iInter_of_isOpen hGopen)
      (dense_iInter_of_isOpen hGopen hGdense)
  apply Filter.mem_of_superset hres
  intro x hx
  apply jointContinuousAt_of_oscillation_interiors f y₀ B hB (hleft y₀)
  intro k
  exact mem_iUnion.mp (mem_iInter.mp hx k)

/-- Pointwise countable-generation interface; no global countability or
metrizability hypothesis on either domain is introduced. -/
theorem residual_jointContinuousAt [BaireSpace X]
    (f : X → Y → Z) (y₀ : Y) [(𝓝 y₀).IsCountablyGenerated]
    (hleft : ∀ y, Continuous (fun x => f x y))
    (hright : ∀ x, Continuous (f x)) :
    {x | ContinuousAt (fun p : X × Y => f p.1 p.2) (x,y₀)} ∈ residual X := by
  obtain ⟨B,hB⟩ := (𝓝 y₀).exists_antitone_basis
  exact residual_jointContinuousAt_of_basis f y₀ B hB.1 hleft hright

/-- Exact metric-codomain source wrapper for Lawson (1974), Proposition 3.1.
Its proof is the same oscillation/closed-cover Baire argument; the internal
pseudometric generality is not an extra premise of this source statement. -/
theorem source_proposition_3_1 {Z' : Type w} [MetricSpace Z'] [BaireSpace X]
    (f : X → Y → Z') (y₀ : Y) [(𝓝 y₀).IsCountablyGenerated]
    (hleft : ∀ y, Continuous (fun x => f x y))
    (hright : ∀ x, Continuous (f x)) :
    {x | ContinuousAt (fun p : X × Y => f p.1 p.2) (x,y₀)} ∈ residual X :=
  residual_jointContinuousAt f y₀ hleft hright

end LawsonBaire
end ScottSpectraReviewed
