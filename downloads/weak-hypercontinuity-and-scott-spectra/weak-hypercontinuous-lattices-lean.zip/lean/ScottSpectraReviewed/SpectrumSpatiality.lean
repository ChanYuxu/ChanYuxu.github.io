import ScottSpectraReviewed.Separation
import ScottSpectraReviewed.ContinuousLatticeBasics
import Mathlib.Topology.Sets.Opens

/-! Proved spatiality foundations for the actual cited Hofmann--Lawson
statement, source lines 221--224. Scott-open lattice filters are constructed
from an interpolating descending sequence; no spatiality certificate or cited
mathematical axiom is assumed. The sequence generates a filter whose openness
is proved against arbitrary nonempty directed sets. -/

noncomputable section
open Set
open scoped Topology
universe u

namespace ScottSpectraReviewed

/-- Every way-below interval in a continuous lattice contains an actual
Scott-open order filter through its upper endpoint, bounded below by its
lower endpoint. -/
theorem exists_scottOpen_filter_between {L : Type u} [CompleteLattice L]
    (hcont : IsContinuousLattice L) {c b : L} (hcb : WayBelow c b) :
    ∃ H : Order.PFilter L, IsOpen[scottTopology L] (H : Set L) ∧ b ∈ H ∧
      (H : Set L) ⊆ Set.Ici c := by
  classical
  let T := {x : L // WayBelow c x}
  let step : T → T := fun x =>
    ⟨(wayBelow_interpolate hcont x.2).choose,
      (wayBelow_interpolate hcont x.2).choose_spec.1⟩
  have hstep : ∀ x : T, WayBelow (step x).1 x.1 := by
    intro x
    exact (wayBelow_interpolate hcont x.2).choose_spec.2
  let r : ℕ → T := Nat.rec ⟨b, hcb⟩ (fun _ x => step x)
  have hsucc : ∀ n, WayBelow (r (n + 1)).1 (r n).1 := by
    intro n
    exact hstep (r n)
  have hanti : Antitone (fun n => (r n).1) :=
    antitone_nat_of_succ_le (fun n => wayBelow_le (hsucc n))
  let H : Order.PFilter L := (Order.IsPFilter.of_def
    (F := {x : L | ∃ n : ℕ, (r n).1 ≤ x})
    (by exact ⟨b, 0, le_rfl⟩)
    (by
      rintro x ⟨n, hn⟩ y ⟨m, hm⟩
      exact ⟨(r (max n m)).1, ⟨max n m, le_rfl⟩,
        (hanti (Nat.le_max_left n m)).trans hn,
        (hanti (Nat.le_max_right n m)).trans hm⟩)
    (by
      rintro x y hxy ⟨n, hn⟩
      exact ⟨n, hn.trans hxy⟩)).toPFilter
  refine ⟨H, ?_, ⟨0, le_rfl⟩, ?_⟩
  · rw [isScottOpen_iff]
    refine ⟨?_, ?_⟩
    · intro x y hxy hx
      exact Order.PFilter.mem_of_le hxy hx
    · intro D hne hdir x hx hxH
      obtain ⟨n, hn⟩ := hxH
      obtain ⟨d, hd, hrd⟩ := hsucc n D ⟨hne, hdir⟩ x hx hn
      exact ⟨d, hd, n + 1, hrd⟩
  · rintro x ⟨n, hn⟩
    exact (wayBelow_le (r n).2).trans hn

namespace Spectrum

variable {L : Type u} [CompleteLattice L]

theorem exists_mem_not_mem (hL : IsFrame L) (hcont : IsContinuousLattice L)
    (a v : L) (hav : ¬ a ≤ v) : ∃ F : Spectrum L, a ∈ F ∧ v ∉ F := by
  classical
  have hc : ∃ c : L, WayBelow c a ∧ ¬ c ≤ v := by
    by_contra hc
    apply hav
    apply (hcont.2 a).2.2
    intro c hca
    by_contra hcv
    exact hc ⟨c, hca, hcv⟩
  obtain ⟨c, hca, hcv⟩ := hc
  obtain ⟨H, hHopen, haH, hHc⟩ := exists_scottOpen_filter_between hcont hca
  have hvH : v ∉ H := fun hv => hcv (hHc hv)
  obtain ⟨F, hHF, hvF⟩ := source_separation hL H hHopen v hvH
  exact ⟨F, hHF haH, hvF⟩

theorem hat_subset_hat_iff (hL : IsFrame L) (hcont : IsContinuousLattice L)
    (a b : L) : hat a ⊆ hat b ↔ a ≤ b := by
  constructor
  · intro h
    by_contra hab
    obtain ⟨F, haF, hbF⟩ := exists_mem_not_mem hL hcont a b hab
    exact hbF (h haF)
  · intro hab F haF
    exact F.mem_of_le hab haF

theorem hat_injective (hL : IsFrame L) (hcont : IsContinuousLattice L) :
    Function.Injective (hat (L := L)) := by
  intro a b hab
  exact le_antisymm ((hat_subset_hat_iff hL hcont a b).mp hab.subset)
    ((hat_subset_hat_iff hL hcont b a).mp hab.symm.subset)

local instance spatialityHullKernelInstance : TopologicalSpace (Spectrum L) := hullKernelTopology

/-- Opens of the actual hull-kernel space, with its topology fixed explicitly. -/
abbrev HullKernelOpens (L : Type u) [CompleteLattice L] :=
  @TopologicalSpace.Opens (Spectrum L) (hullKernelTopology (L := L))

/-- The actual map a to hat(a) is a complete-order isomorphism, hence in
particular the frame isomorphism asserted in the source. -/
def openOrderIso (hL : IsFrame L) (hcont : IsContinuousLattice L) :
    L ≃o HullKernelOpens L where
  toFun a := ⟨hat a, ⟨a, rfl⟩⟩
  invFun U := Classical.choose U.isOpen
  left_inv a := by
    apply hat_injective hL hcont
    exact Classical.choose_spec (show IsOpen[hullKernelTopology] (hat a) from ⟨a, rfl⟩)
  right_inv U := by
    apply TopologicalSpace.Opens.ext
    exact Classical.choose_spec U.isOpen
  map_rel_iff' := by
    intro a b
    exact hat_subset_hat_iff hL hcont a b

@[simp] theorem openOrderIso_apply (hL : IsFrame L) (hcont : IsContinuousLattice L)
    (a : L) : ((openOrderIso hL hcont a) : Set (Spectrum L)) = hat a := rfl

end Spectrum

/-- Source-facing spatiality component of the cited Hofmann--Lawson theorem,
with the specified map rather than an arbitrary isomorphic open-set lattice. -/
theorem source_spectrum_frameIso {L : Type u} [CompleteLattice L]
    (hL : IsFrame L) (hcont : IsContinuousLattice L) :
    ∃ e : L ≃o Spectrum.HullKernelOpens L,
      ∀ a : L, (e a : Set (Spectrum L)) = Spectrum.hat a :=
  ⟨Spectrum.openOrderIso hL hcont, fun _ => rfl⟩

end ScottSpectraReviewed
