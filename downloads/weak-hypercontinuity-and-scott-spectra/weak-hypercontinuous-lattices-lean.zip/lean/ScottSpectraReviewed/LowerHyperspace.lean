import ScottSpectraReviewed.CompactWebLocal

/-! The actual Vietoris hyperspace of closed lower subsets from source
314--344. On a compact Hausdorff space, compact subsets are precisely closed
subsets, so `Compacts P` gives the literal carrier with the standard Vietoris
topology; the subtype condition is exactly lowerness, not continuity of meet.
The ambient compact/closed-order facts are proved below. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace LowerHyperspace

variable {P : Type u} [PartialOrder P] [TopologicalSpace P]
variable [CompactSpace P] [T2Space P]

omit [PartialOrder P] in
/-- Source 323--329, on the actual Vietoris hyperspace. -/
theorem isClosed_inclusion :
    IsClosed {p : Compacts P × Compacts P | p.1 ≤ p.2} := by
  rw [← isOpen_compl_iff,isOpen_iff_forall_mem_open]
  intro p hp
  have hn : ¬ ((p.1 : Set P) ⊆ (p.2 : Set P)) := hp
  obtain ⟨a,haA,haB⟩ := Set.not_subset.mp hn
  obtain ⟨O,V,hO,hV,haO,hBV,hdisj⟩ :=
    normal_separation isClosed_singleton p.2.isCompact.isClosed
      (disjoint_singleton_left.mpr haB)
  let Aopen := {K : Compacts P | ((K : Set P) ∩ O).Nonempty}
  let Bopen := {K : Compacts P | (K : Set P) ⊆ V}
  refine ⟨Aopen ×ˢ Bopen,?_,
    (Compacts.isOpen_inter_nonempty_of_isOpen hO).prod
      (Compacts.isOpen_subsets_of_isOpen hV),⟨a,haA,haO (mem_singleton a)⟩,hBV⟩
  rintro ⟨A,B⟩ ⟨⟨z,hzA,hzO⟩,hB⟩ hAB
  exact Set.disjoint_left.mp hdisj hzO (hB (hAB hzA))

omit [PartialOrder P] in
instance compactsOrderClosed : OrderClosedTopology (Compacts P) :=
  ⟨isClosed_inclusion⟩

omit [PartialOrder P] in
/-- The standard full Vietoris hyperspace, including the empty closed set.
All compact subsets are closed and conversely under exactly these ambient
compact Hausdorff assumptions. No order on P is needed for this background. -/
theorem source_vietoris_compact_hausdorff :
    CompactSpace (Compacts P) ∧ T2Space (Compacts P) :=
  ⟨inferInstance,inferInstance⟩

omit [PartialOrder P] in
/-- Literal carrier identification used by the source when calling this
the hyperspace of all closed subsets. Both directions preserve the set. -/
def closedCompactEquiv : Closeds P ≃ Compacts P where
  toFun C := ⟨C,C.isClosed.isCompact⟩
  invFun K := ⟨K,K.isCompact.isClosed⟩
  left_inv _ := rfl
  right_inv _ := rfl

/-- Source 317--323. Openness of upward closures suffices; the local web
hypothesis is used later to show separate continuity of intersection. -/
theorem isClosed_lowerSets
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P)) :
    IsClosed {K : Compacts P | IsLowerSet (K : Set P)} := by
  rw [← isOpen_compl_iff,isOpen_iff_forall_mem_open]
  intro C hC
  have hex : ∃ a ∈ (C : Set P), ∃ b, b ≤ a ∧ b ∉ (C : Set P) := by
    by_contra h
    apply hC
    intro b a hba ha
    by_contra hb
    exact h ⟨b,ha,a,hba,hb⟩
  obtain ⟨a,haC,b,hba,hbC⟩ := hex
  obtain ⟨O,V,hO,hV,hbO,hCV,hdisj⟩ :=
    normal_separation isClosed_singleton C.isCompact.isClosed
      (disjoint_singleton_left.mpr hbC)
  let bad := {K : Compacts P | (K : Set P) ⊆ V} ∩
    {K : Compacts P | ((K : Set P) ∩ upperClosure O).Nonempty}
  refine ⟨bad,?_,(Compacts.isOpen_subsets_of_isOpen hV).inter
    (Compacts.isOpen_inter_nonempty_of_isOpen (hup O hO)),
    hCV,⟨a,haC,b,hbO (mem_singleton b),hba⟩⟩
  rintro K ⟨hKV,⟨c,hcK,z,hzO,hzc⟩⟩ hK
  exact Set.disjoint_left.mp hdisj hzO (hKV (hK hzc hcK))

/-- Exactly the set called `mathcal L` in the source. -/
def Carrier (P : Type u) [PartialOrder P] [TopologicalSpace P] :=
  {K : Compacts P // IsLowerSet (K : Set P)}

instance : PartialOrder (Carrier P) := inferInstanceAs
  (PartialOrder {K : Compacts P // IsLowerSet (K : Set P)})

instance : TopologicalSpace (Carrier P) := inferInstanceAs
  (TopologicalSpace {K : Compacts P // IsLowerSet (K : Set P)})

instance carrierOrderClosed : OrderClosedTopology (Carrier P) :=
  inferInstanceAs (OrderClosedTopology {K : Compacts P // IsLowerSet (K : Set P)})

instance carrierInf : SemilatticeInf (Carrier P) :=
  Subtype.semilatticeInf (fun _ _ hA hB => hA.inter hB)

theorem compactSpace
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P)) :
    CompactSpace (Carrier P) :=
  isCompact_iff_compactSpace.mp (isClosed_lowerSets hup).isCompact

omit [CompactSpace P] in
/-- The hit identity in the first line of source 331--336. -/
theorem meet_hit_iff (A B : Carrier P) (O : Set P) :
    ((((A ⊓ B).val : Compacts P) : Set P) ∩ O).Nonempty ↔
      ((A.val : Set P) ∩ upperClosure (O ∩ (B.val : Set P))).Nonempty := by
  constructor
  · rintro ⟨z,⟨hzA,hzB⟩,hzO⟩
    exact ⟨z,hzA,z,⟨hzO,hzB⟩,le_rfl⟩
  · rintro ⟨a,haA,z,⟨hzO,hzB⟩,hza⟩
    exact ⟨z,⟨A.property hza haA,hzB⟩,hzO⟩

omit [CompactSpace P] in
theorem isOpen_meet_hit
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : CompactWeb.HasLocalLowerBounds P) (B : Carrier P)
    {O : Set P} (hO : IsOpen O) :
    IsOpen {A : Carrier P |
      ((((A ⊓ B).val : Compacts P) : Set P) ∩ O).Nonempty} := by
  have heq : {A : Carrier P |
      ((((A ⊓ B).val : Compacts P) : Set P) ∩ O).Nonempty} =
      Subtype.val ⁻¹' {A : Compacts P |
        ((A : Set P) ∩ upperClosure (O ∩ (B.val : Set P))).Nonempty} := by
    ext A
    exact meet_hit_iff A B O
  rw [heq]
  exact (Compacts.isOpen_inter_nonempty_of_isOpen
    (CompactWeb.isOpen_upperClosure_inter hup hweb hO B.property)).preimage
      continuous_subtype_val

omit [CompactSpace P] in
/-- Source 331--339: intersection is separately continuous in the genuine
Vietoris topology. Joint continuity is not an assumption here. -/
theorem continuous_inf_fixed
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : CompactWeb.HasLocalLowerBounds P) (B : Carrier P) :
    Continuous (fun A : Carrier P => A ⊓ B) := by
  apply continuous_induced_rng.mpr
  apply continuous_induced_rng.mpr
  apply TopologicalSpace.vietoris.continuous_iff.mpr
  constructor
  · intro O hO
    let V : Set P := ((B.val : Set P) \ O)ᶜ
    have hV : IsOpen V :=
      (B.val.isCompact.isClosed.inter hO.isClosed_compl).isOpen_compl
    have heq : (fun A : Carrier P => (((A ⊓ B).val : Compacts P) : Set P)) ⁻¹'
        O.powerset = Subtype.val ⁻¹' {A : Compacts P | (A : Set P) ⊆ V} := by
      ext A
      change ((A.val : Set P) ∩ (B.val : Set P) ⊆ O) ↔ (A.val : Set P) ⊆ V
      simp only [V,subset_def,mem_inter_iff,mem_compl_iff,mem_diff]
      constructor
      · intro h a ha ⟨hb,hn⟩
        exact hn (h a ⟨ha,hb⟩)
      · intro h a ⟨ha,hb⟩
        by_contra hn
        exact h a ha ⟨hb,hn⟩
    change IsOpen ((fun A : Carrier P => (((A ⊓ B).val : Compacts P) : Set P)) ⁻¹'
      O.powerset)
    rw [heq]
    exact (Compacts.isOpen_subsets_of_isOpen hV).preimage continuous_subtype_val
  · intro F hF
    have heq : (fun A : Carrier P => (((A ⊓ B).val : Compacts P) : Set P)) ⁻¹'
        F.powerset = {A : Carrier P |
          ((((A ⊓ B).val : Compacts P) : Set P) ∩ Fᶜ).Nonempty}ᶜ := by
      ext A
      change (((A ⊓ B).val : Set P) ⊆ F) ↔
        ¬ ((((A ⊓ B).val : Set P) ∩ Fᶜ).Nonempty)
      simp only [subset_def,Set.Nonempty,mem_inter_iff,mem_compl_iff]
      constructor
      · intro h ⟨a,ha,hn⟩
        exact hn (h a ha)
      · intro h a ha
        by_contra hn
        exact h ⟨a,ha,hn⟩
    change IsClosed ((fun A : Carrier P => (((A ⊓ B).val : Compacts P) : Set P)) ⁻¹'
      F.powerset)
    rw [heq]
    exact (isOpen_meet_hit hup hweb B hF.isOpen_compl).isClosed_compl

variable [OrderClosedTopology P]

/-- The actual principal-ideal map `e` from source 340--344. -/
def principalIdeal (x : P) : Carrier P :=
  ⟨⟨Iic x,isClosed_Iic.isCompact⟩,isLowerSet_Iic x⟩

omit [T2Space P] in
theorem principalIdeal_continuous
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P)) :
    Continuous (principalIdeal : P → Carrier P) := by
  apply continuous_induced_rng.mpr
  apply continuous_induced_rng.mpr
  apply TopologicalSpace.vietoris.continuous_iff.mpr
  constructor
  · intro O hO
    have heq : (fun x : P => ((principalIdeal x).val : Set P)) ⁻¹' O.powerset =
        (upperClosure Oᶜ : Set P)ᶜ := by
      ext x
      change (Iic x ⊆ O) ↔ ¬ ∃ z ∈ Oᶜ, z ≤ x
      simp only [subset_def,mem_Iic,mem_compl_iff]
      constructor
      · intro h ⟨z,hn,hz⟩
        exact hn (h z hz)
      · intro h z hz
        by_contra hn
        exact h ⟨z,hn,hz⟩
    change IsOpen ((fun x : P => ((principalIdeal x).val : Set P)) ⁻¹' O.powerset)
    rw [heq]
    exact (CompactSemilattice.isClosed_upperClosure hO.isClosed_compl).isOpen_compl
  · intro F hF
    have heq : (fun x : P => ((principalIdeal x).val : Set P)) ⁻¹' F.powerset =
        (upperClosure Fᶜ : Set P)ᶜ := by
      ext x
      change (Iic x ⊆ F) ↔ ¬ ∃ z ∈ Fᶜ, z ≤ x
      simp only [subset_def,mem_Iic,mem_compl_iff]
      constructor
      · intro h ⟨z,hn,hz⟩
        exact hn (h z hz)
      · intro h z hz
        by_contra hn
        exact h ⟨z,hn,hz⟩
    change IsClosed ((fun x : P => ((principalIdeal x).val : Set P)) ⁻¹' F.powerset)
    rw [heq]
    exact (hup Fᶜ hF.isOpen_compl).isClosed_compl

/-- Source 345--350, once the separately-to-jointly continuous semilattice
theorem has actually been supplied for this hyperspace. The extra premise is
an explicit internal proof obligation, not the final compact-web theorem. -/
theorem isOpen_lowerRelation
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hjoint : Continuous (fun q : Carrier P × Carrier P => q.1 ⊓ q.2))
    {O : Set P} (hO : IsOpen O) :
    IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2} := by
  have hmap : Continuous (fun p : P × P =>
      (principalIdeal p.1 ⊓ principalIdeal p.2).val) :=
    continuous_subtype_val.comp (hjoint.comp
      ((principalIdeal_continuous hup).prodMap (principalIdeal_continuous hup)))
  have h := (Compacts.isOpen_inter_nonempty_of_isOpen hO).preimage hmap
  convert h using 1
  ext p
  change (∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2) ↔
    ((Iic p.1 ∩ Iic p.2) ∩ O).Nonempty
  constructor
  · rintro ⟨z,hzO,hza,hzb⟩
    exact ⟨z,⟨hza,hzb⟩,hzO⟩
  · rintro ⟨z,⟨hza,hzb⟩,hzO⟩
    exact ⟨z,hzO,hza,hzb⟩

/-- The source's actual lower relation, with the full separately-to-jointly
continuous theorem proved in the dependency closure. No joint-continuity
certificate or extra relation-openness premise remains. -/
theorem source_lowerRelation
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : CompactWeb.HasLocalLowerBounds P) {O : Set P} (hO : IsOpen O) :
    IsOpen {p : P × P | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2} := by
  letI : CompactSpace (Carrier P) := compactSpace hup
  have hsep : ∀ A : Carrier P, Continuous (fun B : Carrier P => A ⊓ B) := by
    intro A
    simpa only [inf_comm] using continuous_inf_fixed hup hweb A
  have hjoint := @CompactSemilattice.source_proposition_7_4 (Carrier P)
    carrierInf _ inferInstance inferInstance
    ⟨isClosed_inclusion.preimage (continuous_subtype_val.prodMap continuous_subtype_val)⟩ hsep
  exact isOpen_lowerRelation hup hjoint hO

end LowerHyperspace
end ScottSpectraReviewed
