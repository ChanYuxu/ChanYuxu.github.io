import ScottSpectraReviewed.OrderBasics

/-! Continuous-dcpo and continuous-lattice facts used by the reviewed source,
preliminaries, lines 140--156. Arbitrary nonempty directed sets are used.

The two-stage-approximant interpolation proof is adapted from
`CoreCompactNonSober/simplified/CoreCompactSimplified/HeZhangLawsonBasic.lean`,
SHA-256 `13c1eba532695f40b7688bd7a1721ee33b6e2cc2fdf5093e764e1b2653ea3781`.
Its `ElementWayBelow`, `NonemptyDirected`, and `IsContinuousDcpo` definitions
were compared with this project's definitions: they have the same quantifiers,
nonemptiness convention, LUB formulation, and continuity hypotheses.
No acceptance status or external theorem from that project is imported.
-/

noncomputable section
open Set
open scoped Topology
universe u

namespace ScottSpectraReviewed

/-- Interpolation for the source's way-below relation on every continuous dcpo. -/
theorem wayBelow_interpolate {P : Type u} [PartialOrder P]
    (hP : IsContinuousDcpo P) {a c : P} (hac : WayBelow a c) :
    ∃ b : P, WayBelow a b ∧ WayBelow b c := by
  let E : Set P := {e | ∃ b, WayBelow e b ∧ WayBelow b c}
  have hne : E.Nonempty := by
    obtain ⟨b, hbc⟩ := (hP.2 c).1.1
    obtain ⟨e, heb⟩ := (hP.2 b).1.1
    exact ⟨e, b, heb, hbc⟩
  have hdir : DirectedOn (· ≤ ·) E := by
    rintro x ⟨b, hxb, hbc⟩ y ⟨d, hyd, hdc⟩
    obtain ⟨k, hkc, hbk, hdk⟩ := (hP.2 c).1.2 b hbc d hdc
    obtain ⟨x', hx'k, hxx'⟩ :=
      (wayBelow_mono le_rfl hxb hbk) _ (hP.2 k).1 k (hP.2 k).2 le_rfl
    obtain ⟨y', hy'k, hyy'⟩ :=
      (wayBelow_mono le_rfl hyd hdk) _ (hP.2 k).1 k (hP.2 k).2 le_rfl
    obtain ⟨z, hzk, hx'z, hy'z⟩ := (hP.2 k).1.2 x' hx'k y' hy'k
    exact ⟨z, ⟨k, hzk, hkc⟩, hxx'.trans hx'z, hyy'.trans hy'z⟩
  have hsup : IsLUB E c := by
    constructor
    · rintro e ⟨b, heb, hbc⟩
      exact (wayBelow_le heb).trans (wayBelow_le hbc)
    · intro y hy
      apply (hP.2 c).2.2
      intro b hbc
      apply (hP.2 b).2.2
      intro e heb
      exact hy ⟨b, heb, hbc⟩
  obtain ⟨e, ⟨b, heb, hbc⟩, hae⟩ := hac E ⟨hne, hdir⟩ c hsup le_rfl
  exact ⟨b, wayBelow_mono hae heb le_rfl, hbc⟩

/-- The source's double-upper set is open for the full intrinsic Scott topology. -/
theorem isScottOpen_wayAbove {P : Type u} [PartialOrder P]
    (hP : IsContinuousDcpo P) (a : P) :
    IsOpen[scottTopology P] {x | WayBelow a x} := by
  apply (isScottOpen_iff _).mpr
  constructor
  · intro b c hbc hab
    exact wayBelow_mono le_rfl hab hbc
  · intro D hDne hDdir x hx hax
    obtain ⟨b, hab, hbx⟩ := wayBelow_interpolate hP hax
    obtain ⟨d, hd, hbd⟩ := hbx D ⟨hDne, hDdir⟩ x hx le_rfl
    exact ⟨d, hd, wayBelow_mono le_rfl hab hbd⟩

/-- Meet with a fixed element preserves every nonempty directed LUB in a
continuous complete lattice. This is derived from continuity, not assumed as
part of `IsContinuousLattice`. -/
theorem continuousLattice_inf_isLUB {L : Type u} [CompleteLattice L]
    (hL : IsContinuousLattice L) (a : L) (D : Set L)
    (hD : NonemptyDirected D) (x : L) (hx : IsLUB D x) :
    IsLUB ((fun d => a ⊓ d) '' D) (a ⊓ x) := by
  constructor
  · rintro _ ⟨d, hd, rfl⟩
    exact inf_le_inf_left a (hx.1 hd)
  · intro z hz
    apply (hL.2 (a ⊓ x)).2.2
    intro b hb
    have hbx : WayBelow b x := wayBelow_mono le_rfl hb inf_le_right
    obtain ⟨d, hd, hbd⟩ := hbx D hD x hx le_rfl
    have hba : b ≤ a := (wayBelow_le hb).trans inf_le_left
    exact (le_inf hba hbd).trans (hz ⟨d, hd, rfl⟩)

/-- The meet-continuity identity used in the source's finite-join argument. -/
theorem continuousLattice_meet_continuous {L : Type u} [CompleteLattice L]
    (hL : IsContinuousLattice L) (a : L) (D : Set L)
    (hD : NonemptyDirected D) :
    a ⊓ sSup D = sSup ((fun d => a ⊓ d) '' D) :=
  (continuousLattice_inf_isLUB hL a D hD (sSup D) (isLUB_sSup D)).unique
    (isLUB_sSup _)

end ScottSpectraReviewed
