import ScottSpectraReviewed.LawsonAction
import Mathlib.Topology.Metrizable.Basic
import Mathlib.Topology.Metrizable.Uniformity
import Mathlib.Topology.Algebra.Monoid
import Mathlib.Topology.Separation.Hausdorff
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Algebra.Group.End

/-! Actual compact metric coordinate quotients for Lawson (1974), Theorem
5.1. The original compact spaces are not assumed metrizable. The coordinate
quotient is the actual image in a countable product of real lines. Equality
of coordinates is extended from a dense set of acting elements, rather than
postulated as an action congruence. Source provenance and OCR limitations are
recorded in `audit/worker-upper-lawson-interfaces.md`.
-/

noncomputable section
open Set TopologicalSpace Topology Filter
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace LawsonMetricQuotient

variable {S : Type u} {X : Type v}

/-- The actual observable coordinates used in the source quotient. -/
def coordinates (π : S → X → X) (f : X → ℝ) (T : Set S) (x : X) : T → ℝ :=
  fun t => f (π t x)

/-- The quotient is realized as the actual image of the coordinate map. -/
abbrev CoordinateImage (π : S → X → X) (f : X → ℝ) (T : Set S) :=
  Set.range (coordinates π f T)

def coordinateQuotient (π : S → X → X) (f : X → ℝ) (T : Set S)
    (x : X) : CoordinateImage π f T := ⟨coordinates π f T x, x, rfl⟩

theorem coordinateQuotient_surjective (π : S → X → X) (f : X → ℝ) (T : Set S) :
    Function.Surjective (coordinateQuotient π f T) := by
  rintro ⟨y,x,rfl⟩
  exact ⟨x,rfl⟩

section Topology
variable [TopologicalSpace S] [TopologicalSpace X]

omit [TopologicalSpace S] in
theorem continuous_coordinates (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hfixed : ∀ s, Continuous (π s)) (hf : Continuous f) :
    Continuous (coordinates π f T) :=
  continuous_pi fun t => hf.comp (hfixed t)

omit [TopologicalSpace S] in
theorem continuous_coordinateQuotient (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hfixed : ∀ s, Continuous (π s)) (hf : Continuous f) :
    Continuous (coordinateQuotient π f T) :=
  (continuous_coordinates π f T hfixed hf).subtype_mk _

omit [TopologicalSpace S] in
theorem compactSpace_coordinateImage [CompactSpace X]
    (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hfixed : ∀ s, Continuous (π s)) (hf : Continuous f) :
    CompactSpace (CoordinateImage π f T) :=
  isCompact_iff_compactSpace.mp (isCompact_range (continuous_coordinates π f T hfixed hf))

omit [TopologicalSpace S] in
theorem isQuotientMap_coordinateQuotient [CompactSpace X]
    (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hfixed : ∀ s, Continuous (π s)) (hf : Continuous f) :
    IsQuotientMap (coordinateQuotient π f T) :=
  _root_.IsQuotientMap.of_surjective_continuous (coordinateQuotient_surjective π f T)
    (continuous_coordinateQuotient π f T hfixed hf)

omit [TopologicalSpace S] [TopologicalSpace X] in
/-- The countable family metrizes only its image, not the original X. -/
theorem metrizableSpace_coordinateImage (π : S → X → X) (f : X → ℝ)
    (T : Set S) [Countable T] : MetrizableSpace (CoordinateImage π f T) :=
  inferInstance

/-- This is the density step in source 5.1(6): equality of all countable
coordinates implies equality for every acting element. -/
theorem coordinates_eq_iff_of_dense (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hT : Dense T) (hleft : ∀ x, Continuous (fun s => π s x))
    (hf : Continuous f) (x y : X) :
    coordinates π f T x = coordinates π f T y ↔
      ∀ s : S, f (π s x) = f (π s y) := by
  constructor
  · intro h
    have hclosed : IsClosed {s : S | f (π s x) = f (π s y)} :=
      isClosed_eq (hf.comp (hleft x)) (hf.comp (hleft y))
    have hsub : T ⊆ {s : S | f (π s x) = f (π s y)} := by
      intro s hs
      exact congrFun h ⟨s,hs⟩
    exact fun s => closure_minimal hsub hclosed (hT s)
  · intro h
    exact funext fun t => h t

end Topology

section Action
variable [Semigroup S] [TopologicalSpace S] [TopologicalSpace X]

/-- The actual equivalence is an action congruence, proved from density and
the explicit associativity law. -/
theorem coordinates_eq_action (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hT : Dense T) (hleft : ∀ x, Continuous (fun s => π s x))
    (hf : Continuous f) (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    {x y : X} (h : coordinates π f T x = coordinates π f T y) (s : S) :
    coordinates π f T (π s x) = coordinates π f T (π s y) := by
  funext t
  change f (π t (π s x)) = f (π t (π s y))
  rw [← hassoc, ← hassoc]
  exact (coordinates_eq_iff_of_dense π f T hT hleft hf x y).mp h (t*s)

noncomputable def representative (π : S → X → X) (f : X → ℝ) (T : Set S)
    (y : CoordinateImage π f T) : X := Classical.choose y.property

omit [Semigroup S] [TopologicalSpace S] [TopologicalSpace X] in
theorem representative_spec (π : S → X → X) (f : X → ℝ) (T : Set S)
    (y : CoordinateImage π f T) :
    coordinateQuotient π f T (representative π f T y) = y := by
  apply Subtype.ext
  exact Classical.choose_spec y.property

/-- The induced action on the actual coordinate image. Continuity is proved
below through the genuine compact-to-Hausdorff quotient map. -/
noncomputable def quotientAction (π : S → X → X) (f : X → ℝ) (T : Set S)
    (s : S) (y : CoordinateImage π f T) : CoordinateImage π f T :=
  coordinateQuotient π f T (π s (representative π f T y))

theorem quotientAction_quotient (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hT : Dense T) (hleft : ∀ x, Continuous (fun s => π s x))
    (hf : Continuous f) (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (s : S) (x : X) :
    quotientAction π f T s (coordinateQuotient π f T x) =
      coordinateQuotient π f T (π s x) := by
  apply Subtype.ext
  apply coordinates_eq_action π f T hT hleft hf hassoc
  exact congrArg Subtype.val (representative_spec π f T (coordinateQuotient π f T x))

theorem quotientAction_assoc (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hT : Dense T) (hleft : ∀ x, Continuous (fun s => π s x))
    (hf : Continuous f) (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (r s : S) (y : CoordinateImage π f T) :
    quotientAction π f T (r*s) y =
      quotientAction π f T r (quotientAction π f T s y) := by
  obtain ⟨x,rfl⟩ := coordinateQuotient_surjective π f T y
  rw [quotientAction_quotient π f T hT hleft hf hassoc,
    quotientAction_quotient π f T hT hleft hf hassoc,
    quotientAction_quotient π f T hT hleft hf hassoc, hassoc]

omit [Semigroup S] [TopologicalSpace S] [TopologicalSpace X] in
theorem quotientAction_unit (π : S → X → X) (f : X → ℝ) (T : Set S)
    (e : S) (hunit : ∀ x : X, π e x=x) (y : CoordinateImage π f T) :
    quotientAction π f T e y = y := by
  simp only [quotientAction, hunit, representative_spec]

omit [Semigroup S] in
theorem continuous_quotientAction_left (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hleft : ∀ x, Continuous (fun s => π s x))
    (hfixed : ∀ s, Continuous (π s)) (hf : Continuous f)
    (y : CoordinateImage π f T) : Continuous (fun s => quotientAction π f T s y) :=
  (continuous_coordinateQuotient π f T hfixed hf).comp (hleft _)

theorem continuous_quotientAction_right [CompactSpace X]
    (π : S → X → X) (f : X → ℝ) (T : Set S)
    (hT : Dense T) (hleft : ∀ x, Continuous (fun s => π s x))
    (hfixed : ∀ s, Continuous (π s)) (hf : Continuous f)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x)) (s : S) :
    Continuous (quotientAction π f T s) := by
  apply (isQuotientMap_coordinateQuotient π f T hfixed hf).continuous_iff.mpr
  have heq : quotientAction π f T s ∘ coordinateQuotient π f T =
      coordinateQuotient π f T ∘ π s := by
    funext x
    exact quotientAction_quotient π f T hT hleft hf hassoc s x
  rw [heq]
  exact (continuous_coordinateQuotient π f T hfixed hf).comp (hfixed s)

end Action

section ImageSemigroup
variable [Semigroup S]

/-- The pointwise topology on actual endofunctions. -/
instance pointwiseEndTopology [TopologicalSpace X] :
    TopologicalSpace (Function.End X) :=
  inferInstanceAs (TopologicalSpace (X → X))

instance pointwiseEndT2Space [TopologicalSpace X] [T2Space X] :
    T2Space (Function.End X) :=
  inferInstanceAs (T2Space (X → X))

/-- The actual image congruence on the acting semigroup: two elements are
identified precisely when their induced selfmaps are equal. Composition is
the real multiplication, not an unrelated abstract certificate. -/
def imageSemigroup (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x)) :
    Subsemigroup (Function.End X) where
  carrier := Set.range π
  mul_mem' := by
    rintro _ _ ⟨r,rfl⟩ ⟨s,rfl⟩
    exact ⟨r*s,funext (hassoc r s)⟩

def imageProjection (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (s : S) : imageSemigroup π hassoc := ⟨π s,s,rfl⟩

theorem imageProjection_surjective (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x)) :
    Function.Surjective (imageProjection π hassoc) := by
  rintro ⟨_,s,rfl⟩
  exact ⟨s,rfl⟩

variable [TopologicalSpace S] [TopologicalSpace X]

theorem continuous_imageProjection (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (hleft : ∀ x, Continuous (fun s => π s x)) :
    Continuous (imageProjection π hassoc) :=
  (continuous_pi hleft).subtype_mk _

theorem compactSpace_imageSemigroup [CompactSpace S] (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (hleft : ∀ x, Continuous (fun s => π s x)) :
    CompactSpace (imageSemigroup π hassoc) :=
  isCompact_iff_compactSpace.mp (isCompact_range (continuous_pi hleft))

omit [TopologicalSpace S] in
theorem continuous_imageSemigroup_left (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (hfixed : ∀ s, Continuous (π s)) (a : imageSemigroup π hassoc) :
    Continuous (fun b : imageSemigroup π hassoc => a*b) := by
  obtain ⟨s,hs⟩ := a.property
  have ha : Continuous (a.val : X → X) := hs ▸ hfixed s
  apply Continuous.subtype_mk
  exact continuous_pi fun x => ha.comp ((continuous_apply x).comp continuous_subtype_val)

omit [TopologicalSpace S] in
theorem continuous_imageSemigroup_right (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (a : imageSemigroup π hassoc) :
    Continuous (fun b : imageSemigroup π hassoc => b*a) := by
  apply Continuous.subtype_mk
  exact continuous_pi fun x => (continuous_apply ((a.val : X → X) x)).comp continuous_subtype_val

omit [TopologicalSpace S] in
theorem continuous_imageEvaluation_left (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x)) (x : X) :
    Continuous (fun a : imageSemigroup π hassoc => (a.val : X → X) x) :=
  (continuous_apply x).comp continuous_subtype_val

omit [TopologicalSpace S] in
theorem continuous_imageEvaluation_right (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (hfixed : ∀ s, Continuous (π s)) (a : imageSemigroup π hassoc) :
    Continuous (a.val : X → X) := by
  obtain ⟨s,hs⟩ := a.property
  exact hs ▸ hfixed s

end ImageSemigroup

section MetricImage
variable [Semigroup S] [TopologicalSpace S] [MetricSpace X]
/-- Source 5.1(8), using the actual compact action-image congruence. The
metric hypothesis is only on the quotient action space. In particular the
original acting S is not assumed metrizable. -/
theorem joint_imageEvaluation_at_identity [CompactSpace S]
    [CompactSpace X] (π : S → X → X)
    (hassoc : ∀ r s x, π (r*s) x = π r (π s x))
    (hleft : ∀ x, Continuous (fun s => π s x))
    (hfixed : ∀ s, Continuous (π s))
    (e : S) (hunit : ∀ x : X, π e x=x) (x : X) :
    ContinuousAt (fun p : imageSemigroup π hassoc × X => (p.1.val : X → X) p.2)
      (imageProjection π hassoc e,x) := by
  letI : CompactSpace (imageSemigroup π hassoc) :=
    compactSpace_imageSemigroup π hassoc hleft
  apply LawsonAction.source_corollary_3_3
    (fun a : imageSemigroup π hassoc => (a.val : X → X))
    (fun _ _ _ => rfl)
    (continuous_imageSemigroup_left π hassoc hfixed)
    (continuous_imageEvaluation_left π hassoc)
    (continuous_imageEvaluation_right π hassoc hfixed)
    (imageProjection π hassoc e)
  · intro a
    apply Subtype.ext
    funext y
    exact congrArg (a.val : X → X) (hunit y)
  · exact hunit

end MetricImage
end LawsonMetricQuotient
end ScottSpectraReviewed
