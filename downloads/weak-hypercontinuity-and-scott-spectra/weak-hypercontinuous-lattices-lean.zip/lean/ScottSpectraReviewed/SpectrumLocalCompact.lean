import ScottSpectraReviewed.SpectrumSpatiality
import ScottSpectraReviewed.SpectrumSobriety
import ScottSpectraReviewed.TopologicalModels
import Mathlib.Data.Finset.Lattice.Fold

/-! Actual compact-saturated neighborhoods of the hull-kernel spectrum of a
continuous frame, completing the cited Hofmann--Lawson statement at source
lines 221--224. Compactness is proved by actual arbitrary open covers and
Scott-open-filter separation, not stored in a witness structure. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace Spectrum

variable {L : Type u} [CompleteLattice L]
local instance localCompactHullKernelInstance : TopologicalSpace (Spectrum L) := hullKernelTopology

/-- The actual set of all completely prime filters extending H. -/
def extensions (H : Order.PFilter L) : Set (Spectrum L) :=
  {G | (H : Set L) ⊆ G}

theorem extensions_isSaturated (H : Order.PFilter L) : IsSaturated (extensions H) := by
  apply subset_antisymm
  · intro G hG U hU
    exact hU.2 hG
  · intro G hG a ha
    exact mem_sInter.mp hG (hat a) ⟨⟨a, rfl⟩, fun F hF => hF ha⟩

/-- Compactness of the literal extension set, using separation and the
arbitrary finite joins of an arbitrary indexed open cover. -/
theorem extensions_isCompact (hL : IsFrame L) (H : Order.PFilter L)
    (hH : IsOpen[scottTopology L] (H : Set L)) : IsCompact (extensions H) := by
  classical
  apply isCompact_of_finite_subcover
  intro ι U hU hcover
  choose a ha using hU
  have hvH : sSup (Set.range a) ∈ H := by
    by_contra hvH
    obtain ⟨G, hHG, hvG⟩ := source_separation hL H hH (sSup (Set.range a)) hvH
    obtain ⟨i, hGi⟩ := mem_iUnion.mp (hcover hHG)
    have haiG : a i ∈ G := (Set.ext_iff.mp (ha i) G).mpr hGi
    exact hvG (G.mem_of_le (le_sSup (mem_range_self i)) haiG)
  let D : Set L := Set.range (fun J : Finset ι => J.sup a)
  have hD : NonemptyDirected D := by
    refine ⟨⟨(∅ : Finset ι).sup a, ∅, rfl⟩, ?_⟩
    rintro _ ⟨I, rfl⟩ _ ⟨J, rfl⟩
    exact ⟨(I ∪ J).sup a, ⟨I ∪ J, rfl⟩,
      Finset.sup_mono Finset.subset_union_left, Finset.sup_mono Finset.subset_union_right⟩
  have hsup : IsLUB D (sSup (Set.range a)) := by
    constructor
    · rintro _ ⟨J, rfl⟩
      exact Finset.sup_le (fun i _ => le_sSup (mem_range_self i))
    · intro v hv
      apply sSup_le
      rintro _ ⟨i, rfl⟩
      exact hv ⟨{i}, Finset.sup_singleton⟩
  obtain ⟨_, ⟨J, rfl⟩, hJH⟩ := ((isScottOpen_iff (H : Set L)).mp hH).2
    hD.1 hD.2 hsup hvH
  refine ⟨J, ?_⟩
  intro G hG
  have hJG : J.sup a ∈ G := hG hJH
  rw [Finset.sup_eq_sSup_image] at hJG
  obtain ⟨_, ⟨i, hi, rfl⟩, haiG⟩ := G.completely_prime _ hJG
  exact mem_iUnion₂.mpr ⟨i, hi, (Set.ext_iff.mp (ha i) G).mp haiG⟩

/-- The source compact-saturated sandwich definition, on the actual
hull-kernel topology, with no Hausdorff or countability premise. -/
theorem hullKernel_isLocallyCompact (hL : IsFrame L) (hcont : IsContinuousLattice L) :
    IsLocallyCompact (Spectrum L) := by
  intro U F hFU
  obtain ⟨b, hb⟩ := U.isOpen
  have hbF : b ∈ F := (Set.ext_iff.mp hb F).mpr hFU
  have hs : sSup {c : L | WayBelow c b} = b := (isLUB_sSup _).unique (hcont.2 b).2
  obtain ⟨c, hcb, hcF⟩ := F.completely_prime {c : L | WayBelow c b} (hs.symm ▸ hbF)
  obtain ⟨H, hHopen, hbH, hHc⟩ := exists_scottOpen_filter_between hcont hcb
  refine ⟨⟨hat c, ⟨c, rfl⟩⟩, extensions H, hcF, ?_, ?_,
    extensions_isCompact hL H hHopen, extensions_isSaturated H⟩
  · intro G hcG a haH
    exact G.mem_of_le (hHc haH) hcG
  · intro G hG
    exact (Set.ext_iff.mp hb G).mp (hG hbH)

end Spectrum

/-- Source-facing full cited Hofmann--Lawson statement on the actual proper
completely prime filter spectrum and the specified hat map. All conclusions
are proved here, not assumed from the citation. -/
theorem source_hofmannLawson {L : Type u} [CompleteLattice L]
    (hL : IsFrame L) (hcont : IsContinuousLattice L) :
    @IsLocallyCompact (Spectrum L) (Spectrum.hullKernelTopology (L := L)) ∧
      @T0Space (Spectrum L) (Spectrum.hullKernelTopology (L := L)) ∧
      @QuasiSober (Spectrum L) (Spectrum.hullKernelTopology (L := L)) ∧
      ∃ e : L ≃o Spectrum.HullKernelOpens L,
        ∀ a : L, (e a : Set (Spectrum L)) = Spectrum.hat a :=
  ⟨Spectrum.hullKernel_isLocallyCompact hL hcont, Spectrum.hullKernel_t0,
    Spectrum.hullKernel_quasiSober, source_spectrum_frameIso hL hcont⟩

end ScottSpectraReviewed
