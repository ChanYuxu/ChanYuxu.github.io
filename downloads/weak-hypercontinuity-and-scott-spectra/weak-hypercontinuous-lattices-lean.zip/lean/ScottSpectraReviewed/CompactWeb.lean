import ScottSpectraReviewed.CompactWebCriterion
import ScottSpectraReviewed.LowerHyperspace

/-! Exact frozen-source Proposition thm:compactweb, lines282--451.
The entire printed Vietoris/separate-continuity/Lawson/compact-sequence/FIP/
filtered-minimum proof route is in the actual Lean dependency closure. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed

theorem source_compactweb {P : Type u} [PartialOrder P] [TopologicalSpace P]
    [CompactSpace P] [T2Space P] [OrderClosedTopology P]
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : CompactWeb.HasLocalLowerBounds P) :
    IsDcpo P ∧ ∀ U : Set P,
      IsOpen[scottTopology P] U ↔ IsOpen U ∧ IsUpperSet U :=
  CompactWeb.compactweb_of_lowerRelation hup hweb
    (fun _ hO => LowerHyperspace.source_lowerRelation hup hweb hO)

end ScottSpectraReviewed
