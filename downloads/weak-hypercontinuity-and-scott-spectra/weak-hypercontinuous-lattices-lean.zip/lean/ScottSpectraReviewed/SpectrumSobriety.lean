import ScottSpectraReviewed.Spectrum
import Mathlib.Topology.Sober

/-! Actual sobriety and T0 of the hull-kernel spectrum. An irreducible closed
set produces the proper completely prime filter of hats it meets, and that
actual filter is proved to be its generic point. No sobriety theorem is assumed.
This proves the sobriety component of source lines 221--224. -/

noncomputable section
open Set
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace Spectrum

variable {L : Type u} [CompleteLattice L]
local instance sobrietyHullKernelInstance : TopologicalSpace (Spectrum L) := hullKernelTopology

theorem hullKernel_closure_singleton (F : Spectrum L) :
    closure ({F} : Set (Spectrum L)) = Set.Iic F := by
  ext G
  constructor
  · intro hG a haG
    obtain ⟨H, haH, hHF⟩ :=
      mem_closure_iff.mp hG (hat a) (show IsOpen (hat a) from ⟨a, rfl⟩) haG
    exact (mem_singleton_iff.mp hHF) ▸ haH
  · intro hGF
    apply mem_closure_iff.mpr
    rintro U ⟨a, rfl⟩ haG
    exact ⟨F, hGF haG, mem_singleton F⟩

theorem hullKernel_t0 : T0Space (Spectrum L) := by
  rw [t0Space_iff_inseparable]
  intro F G hFG
  apply SetLike.ext
  intro a
  exact hFG.mem_open_iff (show IsOpen (hat a) from ⟨a, rfl⟩)

/-- The actual filter of all hats meeting the irreducible set C. -/
def ofIrreducible (C : Set (Spectrum L)) (hC : IsIrreducible C) : Spectrum L where
  filter := (Order.IsPFilter.of_def
    (F := {a : L | ∃ F ∈ C, a ∈ F})
    (by
      obtain ⟨F, hF⟩ := hC.1
      exact ⟨⊤, F, hF, F.top_mem⟩)
    (by
      rintro a ⟨F, hF, haF⟩ b ⟨G, hG, hbG⟩
      obtain ⟨H, hH, haH, hbH⟩ := hC.2 (hat a) (hat b)
        (show IsOpen (hat a) from ⟨a, rfl⟩) (show IsOpen (hat b) from ⟨b, rfl⟩)
        ⟨F, hF, haF⟩ ⟨G, hG, hbG⟩
      exact ⟨a ⊓ b, ⟨H, hH, (H.inf_mem_iff a b).mpr ⟨haH, hbH⟩⟩,
        inf_le_left, inf_le_right⟩)
    (by
      rintro a b hab ⟨F, hF, haF⟩
      exact ⟨F, hF, F.mem_of_le hab haF⟩)).toPFilter
  proper := by
    rintro ⟨F, hF, hbot⟩
    exact F.proper hbot
  completely_prime := by
    rintro S ⟨F, hF, hSF⟩
    obtain ⟨a, ha, haF⟩ := F.completely_prime S hSF
    exact ⟨a, ha, F, hF, haF⟩

@[simp] theorem mem_ofIrreducible (C : Set (Spectrum L)) (hC : IsIrreducible C) (a : L) :
    a ∈ ofIrreducible C hC ↔ ∃ F ∈ C, a ∈ F := Iff.rfl

theorem ofIrreducible_mem (C : Set (Spectrum L)) (hC : IsIrreducible C)
    (hclosed : IsClosed C) : ofIrreducible C hC ∈ C := by
  have hmem : ofIrreducible C hC ∈ closure C := by
    apply mem_closure_iff.mpr
    rintro U ⟨a, rfl⟩ ha
    obtain ⟨F, hF, haF⟩ := ha
    exact ⟨F, haF, hF⟩
  exact hclosed.closure_eq.subset hmem

theorem ofIrreducible_isGenericPoint (C : Set (Spectrum L)) (hC : IsIrreducible C)
    (hclosed : IsClosed C) : IsGenericPoint (ofIrreducible C hC) C := by
  apply subset_antisymm
  · exact closure_minimal (singleton_subset_iff.mpr (ofIrreducible_mem C hC hclosed)) hclosed
  · intro G hG
    rw [hullKernel_closure_singleton]
    intro a haG
    exact ⟨G, hG, haG⟩

theorem hullKernel_quasiSober : QuasiSober (Spectrum L) := by
  constructor
  intro C hC hclosed
  exact ⟨ofIrreducible C hC, ofIrreducible_isGenericPoint C hC hclosed⟩

end Spectrum

/-- Source-facing sobriety component of the cited theorem. The continuous
frame premises are retained; the internal proof actually works more generally. -/
theorem source_spectrum_sober {L : Type u} [CompleteLattice L]
    (hL : IsFrame L) (hcont : IsContinuousLattice L) :
    @T0Space (Spectrum L) (Spectrum.hullKernelTopology (L := L)) ∧
      @QuasiSober (Spectrum L) (Spectrum.hullKernelTopology (L := L)) := by
  clear hL hcont
  exact ⟨Spectrum.hullKernel_t0, Spectrum.hullKernel_quasiSober⟩

end ScottSpectraReviewed
