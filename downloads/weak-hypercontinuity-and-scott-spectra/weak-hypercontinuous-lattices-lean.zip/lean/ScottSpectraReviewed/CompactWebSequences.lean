import ScottSpectraReviewed.CompactWebLocal
import Mathlib.Topology.Separation.Regular

/-! The countable closed-neighborhood argument in source `thm:compactweb`,
lines 350--390. Countable sequences here are the printed auxiliary compactness
construction; the topology and dcpo hypotheses remain entirely arbitrary.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace CompactWeb

variable {P : Type u} [PartialOrder P] [TopologicalSpace P]

/-- The compact-product finite-intersection argument used for the source's
sets `F_n`. Every finite initial chain is constructed backwards from its last
coordinate; compactness then supplies one infinite monotone selection. -/
theorem exists_monotone_selection [OrderClosedTopology P]
    (F : ℕ → Set P) (hFcompact : ∀ n, IsCompact (F n))
    (hFnonempty : ∀ n, (F n).Nonempty)
    (hprev : ∀ n, ∀ y ∈ F (n + 1), ∃ z ∈ F n, z ≤ y) :
    ∃ b : ℕ → P, (∀ n, b n ∈ F n) ∧ Monotone b := by
  classical
  letI (n : ℕ) : CompactSpace (F n) := (isCompact_iff_compactSpace.mp (hFcompact n))
  letI (n : ℕ) : Nonempty (F n) := (hFnonempty n).to_subtype
  let X := ∀ n : ℕ, F n
  have hfinite : ∀ m (y : F m), ∃ b : X, b m = y ∧
      ∀ n < m, (b n : P) ≤ (b (n + 1) : P) := by
    intro m
    induction m with
    | zero =>
        intro y
        exact ⟨Function.update (fun n => Classical.choice (inferInstance : Nonempty (F n))) 0 y,
          Function.update_self _ _ _, by simp⟩
    | succ m ih =>
        intro y
        obtain ⟨z, hzF, hzy⟩ := hprev m y y.property
        obtain ⟨b, hbm, hb⟩ := ih ⟨z, hzF⟩
        let c : X := Function.update b (m + 1) y
        refine ⟨c, Function.update_self _ _ _, ?_⟩
        intro n hnm
        by_cases hn : n < m
        · have hn' : n ≠ m + 1 := Nat.ne_of_lt (lt_trans hn (Nat.lt_succ_self m))
          have hn1 : n + 1 ≠ m + 1 := Nat.ne_of_lt (Nat.succ_lt_succ hn)
          simpa only [c, Function.update_of_ne hn', Function.update_of_ne hn1] using hb n hn
        · have hn' : n = m := le_antisymm (Nat.le_of_lt_succ hnm) (Nat.le_of_not_lt hn)
          subst n
          simpa only [c, Function.update_of_ne (Nat.ne_of_lt (Nat.lt_succ_self m)),
            Function.update_self, hbm] using hzy
  let A : ℕ → Set X := fun n => {b | (b n : P) ≤ (b (n + 1) : P)}
  have hAclosed : ∀ n, IsClosed (A n) := fun n =>
    isClosed_le (continuous_subtype_val.comp (continuous_apply n))
      (continuous_subtype_val.comp (continuous_apply (n + 1)))
  have hAfip : ∀ S : Finset ℕ, (⋂ n ∈ S, A n).Nonempty := by
    intro S
    let m := S.sup id + 1
    obtain ⟨b, _, hb⟩ := hfinite m (Classical.choice (inferInstance : Nonempty (F m)))
    refine ⟨b, mem_iInter₂.mpr ?_⟩
    intro n hn
    exact hb n (lt_of_le_of_lt (Finset.le_sup (f := id) hn) (Nat.lt_succ_self _))
  obtain ⟨b, hb⟩ := CompactSpace.iInter_nonempty hAclosed hAfip
  exact ⟨fun n => (b n : P), fun n => (b n).property,
    monotone_nat_of_le_succ fun n => mem_iInter.mp hb n⟩

variable [CompactSpace P] [T2Space P] [OrderClosedTopology P]

omit [OrderClosedTopology P] in
/-- The exact recursive `E_n,a_n` construction of the source, zero-indexed.
The step inclusion records the lower predecessor needed for backward finite
chains, not just nested compact neighborhoods. -/
theorem exists_closed_neighborhood_chain
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : HasLocalLowerBounds P) {B : Set P} (hB : IsLowerSet B)
    {x : P} (hxB : x ∈ closure B) (C : ℕ → Set P)
    (hC : ∀ n, C n ∈ 𝓝 x) :
    ∃ (E : ℕ → Set P) (a : ℕ → P),
      (∀ n, IsClosed (E n) ∧ E n ∈ 𝓝 x ∧ a n ∈ B ∧ a n ≤ x ∧ a n ∈ interior (E n)) ∧
      (∀ n, E n ⊆ C n) ∧
      (∀ n, E (n + 1) ⊆ interior (E n) ∩
        (upperClosure (interior (E n) ∩ Iic (a n)) : Set P)) := by
  classical
  let Stage := {z : Set P × P // IsClosed z.1 ∧ z.1 ∈ 𝓝 x ∧
    z.2 ∈ B ∧ z.2 ≤ x ∧ z.2 ∈ interior z.1}
  have hinit : ∃ z : Stage, z.val.1 ⊆ C 0 := by
    obtain ⟨E, hE, hEclosed, hEC⟩ :=
      exists_mem_nhds_isClosed_subset (interior_mem_nhds.mpr (hC 0))
    obtain ⟨a, ⟨haB, hax⟩, haE⟩ := lower_localization hweb hB isOpen_interior
      (mem_interior_iff_mem_nhds.mpr hE) hxB
    exact ⟨⟨(E, a), hEclosed, hE, haB, hax, haE⟩,
      hEC.trans interior_subset⟩
  have hstep : ∀ n (z : Stage), ∃ z' : Stage,
      z'.val.1 ⊆ C (n + 1) ∧ z'.val.1 ⊆ interior z.val.1 ∩
        (upperClosure (interior z.val.1 ∩ Iic z.val.2) : Set P) := by
    intro n z
    let U : Set P := (interior z.val.1 ∩
      (upperClosure (interior z.val.1 ∩ Iic z.val.2) : Set P)) ∩ interior (C (n + 1))
    have hUopen : IsOpen U :=
      (isOpen_interior.inter
        (isOpen_upperClosure_inter hup hweb isOpen_interior (isLowerSet_Iic z.val.2))).inter isOpen_interior
    have hxU : x ∈ U :=
      ⟨⟨mem_interior_iff_mem_nhds.mpr z.property.2.1,
        ⟨z.val.2, ⟨z.property.2.2.2.2, le_rfl⟩, z.property.2.2.2.1⟩⟩,
        mem_interior_iff_mem_nhds.mpr (hC (n + 1))⟩
    obtain ⟨E, hE, hEclosed, hEU⟩ := exists_mem_nhds_isClosed_subset (hUopen.mem_nhds hxU)
    obtain ⟨a, ⟨haB, hax⟩, haE⟩ := lower_localization hweb hB isOpen_interior
      (mem_interior_iff_mem_nhds.mpr hE) hxB
    exact ⟨⟨(E, a), hEclosed, hE, haB, hax, haE⟩,
      fun y hy => interior_subset (hEU hy).2, fun y hy => (hEU hy).1⟩
  let step : ℕ → Stage → Stage := fun n z => Classical.choose (hstep n z)
  let stages : ℕ → Stage := Nat.rec (Classical.choose hinit) (fun n z => step n z)
  refine ⟨fun n => (stages n).val.1, fun n => (stages n).val.2,
    fun n => (stages n).property, ?_, ?_⟩
  · intro n
    cases n with
    | zero => exact Classical.choose_spec hinit
    | succ n => exact (Classical.choose_spec (hstep n (stages n))).1
  · intro n
    exact (Classical.choose_spec (hstep n (stages n))).2

/-- Equation (countable-compact-intersection) of the printed proof. The source
closed set is Scott closed, while the `C_n` are closed in the original compact
Hausdorff topology. No countable neighborhood basis is assumed. -/
theorem countable_closed_nhds_intersection
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : HasLocalLowerBounds P) {B : Set P}
    (hB : IsClosed[scottTopology P] B) {x : P} (hxB : x ∈ closure B)
    (C : ℕ → Set P) (hCclosed : ∀ n, IsClosed (C n))
    (hCnhds : ∀ n, C n ∈ 𝓝 x) : (B ∩ ⋂ n, C n).Nonempty := by
  have hBspec := (isScottClosed_iff B).mp hB
  obtain ⟨E, a, hEa, hEC, hEstep⟩ :=
    exists_closed_neighborhood_chain hup hweb hBspec.1 hxB C hCnhds
  let F : ℕ → Set P := fun n => E n ∩ Iic (a n)
  have hFcompact : ∀ n, IsCompact (F n) := fun n =>
    ((hEa n).1.inter isClosed_Iic).isCompact
  have hFnonempty : ∀ n, (F n).Nonempty := fun n =>
    ⟨a n, interior_subset (hEa n).2.2.2.2, le_rfl⟩
  have hprev : ∀ n, ∀ y ∈ F (n + 1), ∃ z ∈ F n, z ≤ y := by
    intro n y hy
    obtain ⟨z, ⟨hzE, hza⟩, hzy⟩ := (hEstep n hy.1).2
    exact ⟨z, ⟨interior_subset hzE, hza⟩, hzy⟩
  obtain ⟨b, hbF, hbmono⟩ := exists_monotone_selection F hFcompact hFnonempty hprev
  obtain ⟨s, hs⟩ := CompactOrdered.exists_isLUB_of_monotone b hbmono
  have hsB : s ∈ B := hBspec.2
    (by rintro _ ⟨n, rfl⟩; exact hBspec.1 (hbF n).2 (hEa n).2.2.1)
    (range_nonempty b) hbmono.directed_le.directedOn_range hs
  have hlim : Tendsto b atTop (𝓝 s) := CompactOrdered.tendsto_of_monotone_isLUB hbmono hs
  have hEanti : Antitone E := antitone_nat_of_succ_le
    (fun n => (hEstep n).trans (inter_subset_left.trans interior_subset))
  refine ⟨s, hsB, mem_iInter.mpr ?_⟩
  intro n
  apply (hCclosed n).mem_of_tendsto hlim
  exact (eventually_ge_atTop n).mono fun m hnm => hEC n (hEanti hnm (hbF m).1)

end CompactWeb
end ScottSpectraReviewed
