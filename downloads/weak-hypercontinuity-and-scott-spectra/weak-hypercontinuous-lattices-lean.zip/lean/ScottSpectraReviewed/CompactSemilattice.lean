import ScottSpectraReviewed.OrderBasics
import ScottSpectraReviewed.LawsonConstruction
import Mathlib.Topology.Order.OrderClosed
import Mathlib.Topology.Maps.Proper.Basic
import Mathlib.Topology.Homeomorph.Lemmas
import Mathlib.Topology.Separation.Regular

/-! The Lawson separate-to-joint theorem used by the source at 334--337 and
581--585. Proposition 7.2 is proved by the compact closed-order projection
argument. Proposition 7.3 uses the actual compact principal ideal action,
through the proved original Corollary 5.2 and its Baire/metric-quotient
dependencies. Proposition 7.4 then follows by the proved upper/lower-open
topology reduction. No additional continuity premise or external axiom
enters the source-facing joint theorem.
-/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace CompactSemilattice

section CompactOrder
variable {P : Type u} [PartialOrder P] [TopologicalSpace P]
variable [CompactSpace P] [OrderClosedTopology P]

/-- A compact projection of the actual closed order relation makes the upper
closure of a closed set closed. No algebraic continuity is assumed. -/
theorem isClosed_upperClosure {C : Set P} (hC : IsClosed C) :
    IsClosed (upperClosure C : Set P) := by
  have hR : IsClosed {p : P × P | p.1 ∈ C ∧ p.1 ≤ p.2} :=
    (hC.preimage continuous_fst).inter isClosed_le_prod
  have heq : Prod.snd '' {p : P × P | p.1 ∈ C ∧ p.1 ≤ p.2} =
      (upperClosure C : Set P) := by
    ext z
    constructor
    · rintro ⟨⟨a,b⟩,⟨ha,hab⟩,rfl⟩
      exact ⟨a,ha,hab⟩
    · rintro ⟨a,ha,haz⟩
      exact ⟨(a,z),⟨ha,haz⟩,rfl⟩
  rw [← heq]
  exact isClosedMap_snd_of_compactSpace _ hR

theorem isClosed_lowerClosure {C : Set P} (hC : IsClosed C) :
    IsClosed (lowerClosure C : Set P) := by
  have hR : IsClosed {p : P × P | p.2 ∈ C ∧ p.1 ≤ p.2} :=
    (hC.preimage continuous_snd).inter isClosed_le_prod
  have heq : Prod.fst '' {p : P × P | p.2 ∈ C ∧ p.1 ≤ p.2} =
      (lowerClosure C : Set P) := by
    ext z
    constructor
    · rintro ⟨⟨a,b⟩,⟨hb,hab⟩,rfl⟩
      exact ⟨b,hb,hab⟩
    · rintro ⟨a,ha,hza⟩
      exact ⟨(z,a),⟨ha,hza⟩,rfl⟩
  rw [← heq]
  exact isClosedMap_fst_of_compactSpace _ hR

end CompactOrder

section Meet
variable {P : Type u} [SemilatticeInf P] [TopologicalSpace P]
variable [CompactSpace P] [OrderClosedTopology P]

/-- Lawson's lower-semicontinuity half, in the equivalent closed-upper-set
form. The compact witness is a genuine common lower bound, and the greatest
lower bound is the source's actual meet operation. -/
theorem inf_preimage_isClosed_of_upper {C : Set P} (hC : IsClosed C)
    (hupper : IsUpperSet C) :
    IsClosed ((fun p : P × P => p.1 ⊓ p.2) ⁻¹' C) := by
  let R : Set ((P × P) × P) :=
    {p | p.2 ∈ C ∧ p.2 ≤ p.1.1 ∧ p.2 ≤ p.1.2}
  have hR : IsClosed R :=
    (hC.preimage continuous_snd).inter
      ((isClosed_le continuous_snd continuous_fst.fst).inter
        (isClosed_le continuous_snd continuous_fst.snd))
  have heq : Prod.fst '' R = (fun p : P × P => p.1 ⊓ p.2) ⁻¹' C := by
    ext p
    constructor
    · rintro ⟨⟨q,z⟩,⟨hz,hzq⟩,rfl⟩
      exact hupper (le_inf hzq.1 hzq.2) hz
    · intro hp
      exact ⟨(p,p.1 ⊓ p.2),⟨hp,inf_le_left,inf_le_right⟩,rfl⟩
  rw [← heq]
  exact isClosedMap_fst_of_compactSpace _ hR

/-- Every open lower set has an open meet preimage. This statement alone
does not supply joint continuity for arbitrary opens. -/
theorem inf_preimage_isOpen_of_lower {U : Set P} (hU : IsOpen U)
    (hlower : IsLowerSet U) :
    IsOpen ((fun p : P × P => p.1 ⊓ p.2) ⁻¹' U) := by
  have hclosed := inf_preimage_isClosed_of_upper hU.isClosed_compl hlower.compl
  simpa only [preimage_compl, compl_compl] using hclosed.isOpen_compl

end Meet

section Separate
variable {P : Type u} [SemilatticeInf P] [TopologicalSpace P]

/-- The local upward-openness consequence of genuine separate continuity,
used independently in the paper's semilattice arguments. -/
theorem isOpen_upperClosure_of_separate
    (hsep : ∀ a : P, Continuous (fun b : P => a ⊓ b))
    {U : Set P} (hU : IsOpen U) : IsOpen (upperClosure U : Set P) := by
  apply isOpen_iff_mem_nhds.mpr
  rintro x ⟨a,ha,hax⟩
  have hpre : x ∈ (fun b : P => a ⊓ b) ⁻¹' U := by
    simpa only [mem_preimage,inf_eq_left.mpr hax] using ha
  apply Filter.mem_of_superset ((hU.preimage (hsep a)).mem_nhds hpre)
  intro b hb
  exact ⟨a ⊓ b,hb,inf_le_right⟩

end Separate

section UpperHalf
variable {P : Type u} [SemilatticeInf P] [TopologicalSpace P]
variable [CompactSpace P] [T2Space P]

/-- The actual principal ideal L(x), with its real meet multiplication and
identity x, used in Lawson (1974), Proposition 7.3. -/
@[implicit_reducible] def principalIdealMonoid (x : P) : CommMonoid (Iic x) where
  one := ⟨x,le_rfl⟩
  mul a b := ⟨a.val ⊓ b.val,inf_le_left.trans a.property⟩
  mul_assoc a b c := by apply Subtype.ext; exact inf_assoc _ _ _
  one_mul a := by apply Subtype.ext; exact inf_eq_right.mpr a.property
  mul_one a := by apply Subtype.ext; exact inf_eq_left.mpr a.property
  mul_comm a b := by apply Subtype.ext; exact inf_comm _ _

/-- Lawson's upper-semicontinuity half. The genuinely non-unital action of
the actual compact principal ideal on all P is handled by proved Corollary
5.2, rather than pretending that x is identity on all of P. -/
theorem inf_preimage_isOpen_of_upper
    (hsep : ∀ a : P, Continuous (fun b : P => a ⊓ b))
    {U : Set P} (hU : IsOpen U) (hupper : IsUpperSet U) :
    IsOpen ((fun p : P × P => p.1 ⊓ p.2) ⁻¹' U) := by
  apply isOpen_iff_mem_nhds.mpr
  rintro ⟨x,y⟩ hxy
  letI : CommMonoid (Iic x) := principalIdealMonoid x
  have hclosed : IsClosed (Iic x) := by
    have heq : Iic x={z : P | x ⊓ z=z} := by
      ext z
      exact inf_eq_right.symm
    rw [heq]
    exact isClosed_eq (hsep x) continuous_id
  letI : CompactSpace (Iic x) := isCompact_iff_compactSpace.mp hclosed.isCompact
  let π : Iic x → P → P := fun a b => a.val ⊓ b
  have hassoc : ∀ r s z, π (r*s) z=π r (π s z) := by
    intro r s z
    exact inf_assoc r.val s.val z
  have hleft : ∀ b : P, Continuous (fun a : Iic x => π a b) := by
    intro b
    have heq : (fun a : Iic x => π a b)=(fun a : Iic x => b ⊓ a.val) := by
      funext a
      exact inf_comm _ _
    rw [heq]
    exact (hsep b).comp continuous_subtype_val
  have hfixed : ∀ a : Iic x, Continuous (π a) := fun a => hsep a.val
  have hjoint := LawsonConstruction.joint_at_one_nonunital π hassoc hleft hfixed y
  have hpre : (fun p : Iic x × P => π p.1 p.2) ⁻¹' U ∈ 𝓝 ((1 : Iic x),y) :=
    hjoint.eventually (hU.mem_nhds hxy)
  obtain ⟨A',V,hA',hxA',hV,hyV,hAV⟩ := mem_nhds_prod_iff'.mp hpre
  obtain ⟨A,hA,rfl⟩ := isOpen_induced_iff.mp hA'
  let B : Set P := (fun u => x ⊓ u) ⁻¹' A
  have hB : IsOpen B := hA.preimage (hsep x)
  have hxB : x ∈ B := by
    change x ⊓ x ∈ A
    simpa only [inf_idem] using hxA'
  apply Filter.mem_of_superset (prod_mem_nhds (hB.mem_nhds hxB) (hV.mem_nhds hyV))
  rintro ⟨u,v⟩ ⟨hu,hv⟩
  have hlow : (x ⊓ u) ⊓ v ∈ U :=
    hAV (show ((⟨x ⊓ u,inf_le_left⟩ : Iic x),v) ∈
      ((Subtype.val : Iic x → P) ⁻¹' A) ×ˢ V from ⟨hu,hv⟩)
  exact hupper (inf_le_inf inf_le_right le_rfl) hlow

theorem source_proposition_7_3
    (hsep : ∀ a : P, Continuous (fun b : P => a ⊓ b))
    {U : Set P} (hU : IsOpen U) (hupper : IsUpperSet U) :
    IsOpen ((fun p : P × P => p.1 ⊓ p.2) ⁻¹' U) :=
  inf_preimage_isOpen_of_upper hsep hU hupper

end UpperHalf

section SeparateCompact
variable {P : Type u} [SemilatticeInf P] [TopologicalSpace P]
variable [CompactSpace P] [T2Space P] [OrderClosedTopology P]

/-- Upper/lower open separation in the present semitopological semilattice.
The closed neighborhood is chosen in the actual topology and its upward
closure is closed by compact projection; upward closure of its interior is
open by the proved separate-continuity consequence. -/
theorem exists_upper_lower_separation
    (hsep : ∀ a : P, Continuous (fun b : P => a ⊓ b))
    (x y : P) (hxy : ¬x ≤ y) :
    ∃ U V : Set P, IsOpen U ∧ IsUpperSet U ∧ IsOpen V ∧ IsLowerSet V ∧
      x ∈ U ∧ y ∈ V ∧ Disjoint U V := by
  obtain ⟨A,B,hA,hB,hxA,hyB,hAB⟩ :=
    isOpen_prod_iff.mp (isClosed_le_prod (α := P)).isOpen_compl x y hxy
  obtain ⟨C,hCx,hCclosed,hCA⟩ := exists_mem_nhds_isClosed_subset (hA.mem_nhds hxA)
  let U : Set P := upperClosure (interior C)
  let V : Set P := (upperClosure C : Set P)ᶜ
  refine ⟨U,V,isOpen_upperClosure_of_separate hsep isOpen_interior,
    (upperClosure (interior C)).upper,(isClosed_upperClosure hCclosed).isOpen_compl,
    (upperClosure C).upper.compl,?_,?_,?_⟩
  · exact subset_upperClosure (mem_interior_iff_mem_nhds.mpr hCx)
  · rintro ⟨c,hc,hcy⟩
    exact (hAB (show (c,y) ∈ A ×ˢ B from ⟨hCA hc,hyB⟩)) hcy
  · apply Set.disjoint_left.mpr
    rintro z ⟨c,hc,hcz⟩ hzV
    exact hzV ⟨c,interior_subset hc,hcz⟩

/-- The topology generated by the actual upper and lower opens. -/
@[implicit_reducible] def upperLowerOpenTopology (P : Type u)
    [Preorder P] [TopologicalSpace P] : TopologicalSpace P :=
  generateFrom {U : Set P | IsOpen U ∧ (IsUpperSet U ∨ IsLowerSet U)}

/-- The Nachbin-type topology reduction needed here, proved directly for
the current semitopological semilattice using compact-to-Hausdorff rigidity.
It is not an assumed topology equality. -/
theorem upperLowerOpenTopology_eq
    (hsep : ∀ a : P, Continuous (fun b : P => a ⊓ b)) :
    upperLowerOpenTopology P = ‹TopologicalSpace P› := by
  let t : TopologicalSpace P := ‹TopologicalSpace P›
  let g : Set (Set P) := {U | IsOpen[t] U ∧ (IsUpperSet U ∨ IsLowerSet U)}
  have hpair := exists_upper_lower_separation hsep
  have ht2 : @T2Space P (generateFrom g) := by
    letI : TopologicalSpace P := generateFrom g
    constructor
    intro x y hxy
    by_cases hle : x ≤ y
    · have hynx : ¬y ≤ x := fun hyx => hxy (le_antisymm hle hyx)
      obtain ⟨U,V,hU,hUup,hV,hVlow,hyU,hxV,hdis⟩ := hpair y x hynx
      exact ⟨V,U,isOpen_generateFrom_of_mem ⟨hV,Or.inr hVlow⟩,
        isOpen_generateFrom_of_mem ⟨hU,Or.inl hUup⟩,hxV,hyU,hdis.symm⟩
    · obtain ⟨U,V,hU,hUup,hV,hVlow,hxU,hyV,hdis⟩ := hpair x y hle
      exact ⟨U,V,isOpen_generateFrom_of_mem ⟨hU,Or.inl hUup⟩,
        isOpen_generateFrom_of_mem ⟨hV,Or.inr hVlow⟩,hxU,hyV,hdis⟩
  have hId : Continuous[t,generateFrom g] (id : P → P) := by
    apply continuous_generateFrom_iff.mpr
    intro U hU
    exact hU.1
  have hinv : Continuous[generateFrom g,t] (id : P → P) :=
    @Continuous.continuous_symm_of_equiv_compact_to_t2
      P P t (generateFrom g) ‹CompactSpace P› ht2 (Equiv.refl _) hId
  exact le_antisymm (continuous_id_iff_le.mp hinv) (continuous_id_iff_le.mp hId)

/-- Internal upper/lower-open reduction. The source-facing theorem below
supplies its upper-open premise using the actual proved Proposition 7.3. -/
theorem continuous_inf_of_upper_preimages
    (hsep : ∀ a : P, Continuous (fun b : P => a ⊓ b))
    (hupper : ∀ U : Set P, IsOpen U → IsUpperSet U →
      IsOpen ((fun p : P × P => p.1 ⊓ p.2) ⁻¹' U)) :
    Continuous (fun p : P × P => p.1 ⊓ p.2) := by
  have hcont : Continuous[_,upperLowerOpenTopology P] (fun p : P × P => p.1 ⊓ p.2) := by
    apply continuous_generateFrom_iff.mpr
    rintro U ⟨hU,hord⟩
    exact hord.elim (hupper U hU) (inf_preimage_isOpen_of_lower hU)
  apply continuous_def.mpr
  intro U hU
  exact continuous_def.mp hcont U ((upperLowerOpenTopology_eq hsep).symm ▸ hU)

/-- Lawson (1974), Proposition 7.4, with exactly the assumptions invoked by
the manuscript. The upper half is now a proved consequence of original
Corollary 5.2, not an extra premise of this theorem. -/
theorem source_proposition_7_4
    (hsep : ∀ a : P, Continuous (fun b : P => a ⊓ b)) :
    Continuous (fun p : P × P => p.1 ⊓ p.2) :=
  continuous_inf_of_upper_preimages hsep
    (fun _ hU hupper => inf_preimage_isOpen_of_upper hsep hU hupper)

end SeparateCompact

/-- Exact external target. This proposition definition is inhabited by
jointContinuityStatement_proved below; its assumptions are precisely those
invoked by both source applications. -/
def JointContinuityStatement : Prop :=
  ∀ (P : Type u) [SemilatticeInf P] [TopologicalSpace P]
    [CompactSpace P] [T2Space P] [OrderClosedTopology P],
    (∀ a : P, Continuous (fun b : P => a ⊓ b)) →
      Continuous (fun p : P × P => p.1 ⊓ p.2)

theorem jointContinuityStatement_proved : JointContinuityStatement.{u} := by
  intro P _ _ _ _ _ hsep
  exact source_proposition_7_4 hsep

end CompactSemilattice
end ScottSpectraReviewed
