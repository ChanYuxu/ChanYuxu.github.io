import ScottSpectraReviewed.OrderBasics
import Mathlib.Topology.Order.OrderClosed
import Mathlib.Topology.Compactness.Compact
import Mathlib.Topology.ClusterPt

/-! The compact ordered convergence assertions of the frozen source, lines
258--270. The proofs use arbitrary directed index preorders and arbitrary
filters, not just sequences. Closed order and compactness are actual
topological hypotheses, not conclusions stored in an auxiliary structure. -/

noncomputable section
open Set Filter
open scoped Topology
universe u v

namespace ScottSpectraReviewed

namespace CompactOrdered

variable {P : Type u} [PartialOrder P] [TopologicalSpace P]
variable [OrderClosedTopology P]

/-- A cluster point of an increasing net is its least upper bound. -/
theorem isLUB_of_mapClusterPt {ι : Type v} [Preorder ι]
    [IsDirectedOrder ι] [Nonempty ι] {f : ι → P} (hf : Monotone f)
    {x : P} (hx : MapClusterPt x atTop f) : IsLUB (range f) x := by
  constructor
  · rintro _ ⟨i, rfl⟩
    exact (isClosed_Ici : IsClosed (Ici (f i))).mem_of_mapClusterPt hx
      ((eventually_ge_atTop i).mono fun j hij => hf hij)
  · intro z hz
    exact (isClosed_Iic : IsClosed (Iic z)).mem_of_mapClusterPt hx
      (Eventually.of_forall fun i => hz (mem_range_self i))

/-- Compactness supplies the cluster point used in the source proof. -/
theorem exists_isLUB_of_monotone [CompactSpace P] {ι : Type v}
    [Preorder ι] [IsDirectedOrder ι] [Nonempty ι]
    (f : ι → P) (hf : Monotone f) : ∃ x, IsLUB (range f) x := by
  obtain ⟨x, hx⟩ := exists_clusterPt_of_compactSpace (map f atTop)
  exact ⟨x, isLUB_of_mapClusterPt hf hx⟩

/-- Uniqueness of the cluster point gives convergence of the whole net. -/
theorem tendsto_of_monotone_isLUB [CompactSpace P] {ι : Type v}
    [Preorder ι] [IsDirectedOrder ι] [Nonempty ι]
    {f : ι → P} (hf : Monotone f) {x : P} (hx : IsLUB (range f) x) :
    Tendsto f atTop (𝓝 x) := by
  apply tendsto_nhds_of_unique_mapClusterPt
  intro y hy
  exact (isLUB_of_mapClusterPt hf hy).unique hx

/-- The source's dcpo consequence, for every nonempty directed subset. -/
theorem isDcpo [CompactSpace P] : IsDcpo P := by
  intro D hD
  letI : Nonempty D := hD.1.to_subtype
  letI : IsDirectedOrder D := hD.2.isDirectedOrder
  obtain ⟨x, hx⟩ := exists_isLUB_of_monotone (fun d : D => (d : P))
    (fun _ _ h => h)
  refine ⟨x, ?_, ?_⟩
  · intro d hd
    exact hx.1 ⟨⟨d, hd⟩, rfl⟩
  · intro z hz
    apply hx.2
    rintro _ ⟨d, rfl⟩
    exact hz d.property

/-- The directed set itself is the net index set; there is no countability
or chosen-sequence premise. -/
theorem tendsto_directed [CompactSpace P] (D : Set P) (hD : NonemptyDirected D)
    {x : P} (hx : IsLUB D x) :
    Tendsto (fun d : D => (d : P)) atTop (𝓝 x) := by
  letI : Nonempty D := hD.1.to_subtype
  letI : IsDirectedOrder D := hD.2.isDirectedOrder
  apply tendsto_of_monotone_isLUB (f := fun d : D => (d : P)) (fun _ _ h => h)
  constructor
  · rintro _ ⟨d, rfl⟩
    exact hx.1 d.property
  · intro z hz
    exact hx.2 (fun d hd => hz ⟨⟨d, hd⟩, rfl⟩)

/-- The filtered statement is the same proved result on the order dual. -/
theorem tendsto_filtered [CompactSpace P] (D : Set P) (hD : NonemptyFiltered D)
    {x : P} (hx : IsGLB D x) :
    Tendsto (fun d : D => (d : P)) atBot (𝓝 x) := by
  letI : TopologicalSpace Pᵒᵈ := ‹TopologicalSpace P›
  letI : CompactSpace Pᵒᵈ := ‹CompactSpace P›
  letI : OrderClosedTopology Pᵒᵈ := inferInstance
  exact @tendsto_directed Pᵒᵈ _ _ _ _ D hD x hx

/-- Compact closed-order squeeze, valid for arbitrary index filters. A
refinement at each cluster point of the middle net preserves both outside
limits, so closedness of the order forces that cluster point to be the limit.
This does not assume a linear order or an order topology. -/
theorem squeeze [CompactSpace P] {ι : Type v} {F : Filter ι}
    {a b c : ι → P} {x : P}
    (ha : Tendsto a F (𝓝 x)) (hc : Tendsto c F (𝓝 x))
    (hab : ∀ᶠ i in F, a i ≤ b i) (hbc : ∀ᶠ i in F, b i ≤ c i) :
    Tendsto b F (𝓝 x) := by
  apply tendsto_nhds_of_unique_mapClusterPt
  intro y hy
  let G : Filter ι := comap b (𝓝 y) ⊓ F
  haveI : NeBot G := neBot_inf_comap_iff_map'.mpr hy
  have hb : Tendsto b G (𝓝 y) := map_le_iff_le_comap.mpr inf_le_left
  have ha' : Tendsto a G (𝓝 x) := ha.mono_left inf_le_right
  have hc' : Tendsto c G (𝓝 x) := hc.mono_left inf_le_right
  have hxy : x ≤ y := le_of_tendsto_of_tendsto ha' hb
    (hab.filter_mono inf_le_right)
  have hyx : y ≤ x := le_of_tendsto_of_tendsto hb hc'
    (hbc.filter_mono inf_le_right)
  exact le_antisymm hyx hxy

/-- Every open upper set is Scott open in the original compact ordered
topology. This is one direction only, not the unproved web criterion. -/
theorem isScottOpen_of_isOpen_upper [CompactSpace P] {U : Set P}
    (hU : IsOpen U) (hupper : IsUpperSet U) : IsOpen[scottTopology P] U := by
  apply (isScottOpen_iff U).mpr
  refine ⟨hupper, ?_⟩
  intro D hne hdir x hx hxU
  have hevent := (tendsto_directed D ⟨hne,hdir⟩ hx).eventually (hU.mem_nhds hxU)
  letI : Nonempty D := hne.to_subtype
  letI : IsDirectedOrder D := hdir.isDirectedOrder
  obtain ⟨d, hdU⟩ := hevent.exists
  exact ⟨d, d.property, hdU⟩

end CompactOrdered
end ScottSpectraReviewed
