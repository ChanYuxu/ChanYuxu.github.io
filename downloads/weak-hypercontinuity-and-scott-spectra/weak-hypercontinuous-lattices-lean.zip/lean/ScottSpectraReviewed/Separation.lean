import ScottSpectraReviewed.PrimeElements
import Mathlib.Order.Zorn

noncomputable section
open Set
open scoped Topology
universe u

namespace ScottSpectraReviewed

theorem IsFrame.isDistributive {L : Type u} [CompleteLattice L]
    (h : IsFrame L) : IsDistributive L := by
  intro a b c
  simpa only [sSup_pair, Set.image_pair] using h a {b, c}

/-- The exact maximal-prime-element proof used in source Lemma separation.
Only finite distributivity is needed internally. -/
theorem scottOpen_filter_separation {L : Type u} [CompleteLattice L]
    (hL : IsDistributive L) (H : Order.PFilter L)
    (hH : IsOpen[scottTopology L] (H : Set L)) (v : L) (hv : v ∉ H) :
    ∃ G : Spectrum L, (H : Set L) ⊆ G ∧ v ∉ G := by
  classical
  let S : Set L := {p | v ≤ p ∧ p ∉ H}
  have hchains : ∀ C ⊆ S, IsChain (· ≤ ·) C →
      ∀ y ∈ C, ∃ ub ∈ S, ∀ z ∈ C, z ≤ ub := by
    intro C hCS hc y hy
    have hdir : DirectedOn (· ≤ ·) C := by
      intro a ha b hb
      by_cases hab : a = b
      · exact ⟨b, hb, hab.le, le_rfl⟩
      · rcases hc ha hb hab with hab | hba
        · exact ⟨b, hb, hab, le_rfl⟩
        · exact ⟨a, ha, le_rfl, hba⟩
    refine ⟨sSup C, ⟨(hCS hy).1.trans (le_sSup hy), ?_⟩,
      fun z hz => le_sSup hz⟩
    intro hsup
    obtain ⟨d, hd, hdH⟩ := ((isScottOpen_iff (H : Set L)).mp hH).2
      ⟨y, hy⟩ hdir (isLUB_sSup C) hsup
    exact (hCS hd).2 hdH
  obtain ⟨p, hvp, hpmax⟩ := zorn_le_nonempty₀ S hchains v ⟨le_rfl, hv⟩
  have hpH : p ∉ H := hpmax.1.2
  have hprime : IsProperMeetPrime p := by
    refine ⟨lt_top_iff_ne_top.mpr ?_, ?_⟩
    · intro hp
      exact hpH (hp ▸ H.top_mem)
    · intro a b hab
      by_contra hn
      push_neg at hn
      have hpa : p ⊔ a ∈ H := by
        by_contra hpa
        have hle := hpmax.2 ⟨hvp.trans le_sup_left, hpa⟩ le_sup_left
        exact hn.1 (le_sup_right.trans hle)
      have hpb : p ⊔ b ∈ H := by
        by_contra hpb
        have hle := hpmax.2 ⟨hvp.trans le_sup_left, hpb⟩ le_sup_left
        exact hn.2 (le_sup_right.trans hle)
      have hmeet : (p ⊔ a) ⊓ (p ⊔ b) ≤ p := by
        rw [hL (p ⊔ a) p b]
        refine sup_le inf_le_right ?_
        calc
          (p ⊔ a) ⊓ b = b ⊓ (p ⊔ a) := inf_comm _ _
          _ = (b ⊓ p) ⊔ (b ⊓ a) := hL b p a
          _ ≤ p := sup_le inf_le_right ((inf_comm b a) ▸ hab)
      exact hpH (Order.PFilter.mem_of_le hmeet (H.inf_mem hpa hpb))
  refine ⟨Spectrum.ofPrimeElement p hprime, ?_, ?_⟩
  · intro a ha
    change ¬ a ≤ p
    exact fun hap => hpH (Order.PFilter.mem_of_le hap ha)
  · change ¬ ¬ v ≤ p
    exact fun hn => hn hvp

/-- Source-facing Lemma `lem:separation`: no continuity assumption on A. -/
theorem source_separation {A : Type u} [CompleteLattice A] (hA : IsFrame A)
    (H : Order.PFilter A) (hH : IsOpen[scottTopology A] (H : Set A))
    (v : A) (hv : v ∉ H) :
    ∃ G : Spectrum A, (H : Set A) ⊆ G ∧ v ∉ G :=
  scottOpen_filter_separation hA.isDistributive H hH v hv

end ScottSpectraReviewed
