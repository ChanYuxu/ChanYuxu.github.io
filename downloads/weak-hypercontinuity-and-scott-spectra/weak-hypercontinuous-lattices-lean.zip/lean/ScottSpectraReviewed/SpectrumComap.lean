import ScottSpectraReviewed.SpectrumDcpo

/-! Inverse images of actual proper completely prime filters under the
Mathlib frame homomorphism. This is the map used in source Theorem transfer,
not an assumed surjection or a proxy spectrum. -/

noncomputable section
open Set
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace Spectrum

variable {L : Type u} {A : Type v} [CompleteLattice L] [CompleteLattice A]

/-- The genuine inverse-image map on spectra. -/
def comap (e : FrameHom L A) (G : Spectrum A) : Spectrum L where
  filter := (Order.IsPFilter.of_def
    (F := {a : L | e a ∈ G})
    (by
      refine ⟨⊤, ?_⟩
      change e ⊤ ∈ G
      simpa only [map_top] using G.top_mem)
    (by
      intro a ha b hb
      refine ⟨a ⊓ b, ?_, inf_le_left, inf_le_right⟩
      change e (a ⊓ b) ∈ G
      rw [map_inf]
      exact (G.inf_mem_iff _ _).mpr ⟨ha, hb⟩)
    (by
      intro a b hab ha
      exact G.mem_of_le (OrderHomClass.monotone e hab) ha)).toPFilter
  proper := by
    intro h
    change e ⊥ ∈ G at h
    exact G.proper (by simpa only [map_bot] using h)
  completely_prime := by
    intro S h
    change e (sSup S) ∈ G at h
    rw [map_sSup] at h
    obtain ⟨_, ⟨a, ha, rfl⟩, hea⟩ := G.completely_prime (e '' S) h
    exact ⟨a, ha, hea⟩

@[simp] theorem mem_comap (e : FrameHom L A) (G : Spectrum A) (a : L) :
    a ∈ comap e G ↔ e a ∈ G := Iff.rfl

theorem comap_monotone (e : FrameHom L A) : Monotone (comap e) := by
  intro G H hGH a ha
  exact hGH ha

@[simp] theorem preimage_hat_comap (e : FrameHom L A) (a : L) :
    comap e ⁻¹' hat a = hat (e a) := rfl

theorem comap_image_nonemptyDirected (e : FrameHom L A)
    (D : Set (Spectrum A)) (hD : NonemptyDirected D) :
    NonemptyDirected (comap e '' D) := by
  refine ⟨hD.1.image (comap e), ?_⟩
  rintro _ ⟨F, hF, rfl⟩ _ ⟨G, hG, rfl⟩
  obtain ⟨H, hH, hFH, hGH⟩ := hD.2 F hF G hG
  exact ⟨comap e H, ⟨H, hH, rfl⟩,
    comap_monotone e hFH, comap_monotone e hGH⟩

/-- Inverse images commute with the actual directed unions. -/
theorem comap_directedUnion (e : FrameHom L A)
    (D : Set (Spectrum A)) (hD : NonemptyDirected D) :
    comap e (directedUnion D hD) =
      directedUnion (comap e '' D) (comap_image_nonemptyDirected e D hD) := by
  apply SetLike.ext
  intro a
  simp only [mem_comap, mem_directedUnion]
  constructor
  · rintro ⟨G, hG, hea⟩
    exact ⟨comap e G, ⟨G, hG, rfl⟩, hea⟩
  · rintro ⟨_, ⟨G, hG, rfl⟩, hea⟩
    exact ⟨G, hG, hea⟩

theorem comap_isLUB (e : FrameHom L A)
    (D : Set (Spectrum A)) (hD : NonemptyDirected D)
    (G : Spectrum A) (hG : IsLUB D G) :
    IsLUB (comap e '' D) (comap e G) := by
  rw [hG.unique (directedUnion_isLUB D hD), comap_directedUnion]
  exact directedUnion_isLUB _ _

/-- Scott continuity, proved by preservation of arbitrary nonempty directed
suprema rather than just sequential unions. -/
theorem comap_scottContinuous (e : FrameHom L A) : ScottContinuous (comap e) := by
  intro D hne hdir G hG
  exact comap_isLUB e D ⟨hne, hdir⟩ G hG

theorem comap_preimage_isScottOpen (e : FrameHom L A)
    (W : Set (Spectrum L)) (hW : IsOpen[scottTopology (Spectrum L)] W) :
    IsOpen[scottTopology (Spectrum A)] (comap e ⁻¹' W) := by
  rw [isScottOpen_iff] at hW ⊢
  refine ⟨?_, ?_⟩
  · intro G H hGH hG
    exact hW.1 (comap_monotone e hGH) hG
  · intro D hne hdir G hG hGW
    have hD := comap_image_nonemptyDirected e D ⟨hne, hdir⟩
    obtain ⟨_, ⟨H, hH, rfl⟩, hHW⟩ :=
      hW.2 hD.1 hD.2 (comap_isLUB e D ⟨hne, hdir⟩ G hG) hGW
    exact ⟨H, hH, hHW⟩

end Spectrum
end ScottSpectraReviewed
