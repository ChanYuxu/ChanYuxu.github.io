import ScottSpectraReviewed.PatchOrdered

/-! Basic patch opens are literally U minus K, as used in source
cor:stableweb. U is open and K compact saturated in the original topology.
Finite intersections are repackaged by union of the compact saturated K's;
the full patch topology is not replaced by just its subbasis. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace Patch

variable {X : Type u} [TopologicalSpace X]

theorem saturated_empty : IsSaturated (∅ : Set X) :=
  (isSaturated_iff_specialization_upper _).mpr (by simp)

theorem saturated_union {K J : Set X} (hK : IsSaturated K) (hJ : IsSaturated J) :
    IsSaturated (K ∪ J) := by
  apply (isSaturated_iff_specialization_upper _).mpr
  intro x y hxy hx
  rcases hx with hx | hx
  · exact Or.inl ((isSaturated_iff_specialization_upper _).mp hK x y hxy hx)
  · exact Or.inr ((isSaturated_iff_specialization_upper _).mp hJ x y hxy hx)

theorem exists_basic_subset {S : Set X} (hS : IsOpen[patchTopology X] S) :
    ∀ x ∈ S, ∃ (U : Opens X) (K : Set X), IsCompact K ∧ IsSaturated K ∧
      x ∈ (U : Set X) \ K ∧ (U : Set X) \ K ⊆ S := by
  change GenerateOpen
    ({U : Set X | IsOpen U} ∪ {U | ∃ K : Set X, IsCompact K ∧ IsSaturated K ∧ Kᶜ = U}) S at hS
  induction hS with
  | basic S hS =>
      intro x hx
      rcases hS with hS | ⟨K,hK,hKs,rfl⟩
      · exact ⟨⟨S,hS⟩,∅,isCompact_empty,saturated_empty,⟨hx,notMem_empty x⟩,
          fun _ h => h.1⟩
      · exact ⟨⊤,K,hK,hKs,⟨mem_univ x,hx⟩,fun _ h => h.2⟩
  | univ =>
      intro x _
      exact ⟨⊤,∅,isCompact_empty,saturated_empty,⟨mem_univ x,notMem_empty x⟩,
        subset_univ _⟩
  | inter S T _ _ ihS ihT =>
      intro x hx
      obtain ⟨U,K,hK,hKs,hxK,hsubK⟩ := ihS x hx.1
      obtain ⟨V,J,hJ,hJs,hxJ,hsubJ⟩ := ihT x hx.2
      refine ⟨U ⊓ V,K ∪ J,hK.union hJ,saturated_union hKs hJs,
        ⟨⟨hxK.1,hxJ.1⟩,?_⟩,?_⟩
      · exact fun h => h.elim hxK.2 hxJ.2
      · intro z hz
        exact ⟨hsubK ⟨hz.1.1,fun h => hz.2 (Or.inl h)⟩,
          hsubJ ⟨hz.1.2,fun h => hz.2 (Or.inr h)⟩⟩
  | sUnion S _ ih =>
      intro x hx
      obtain ⟨T,hTS,hxT⟩ := mem_sUnion.mp hx
      obtain ⟨U,K,hK,hKs,hxK,hsubK⟩ := ih T hTS x hxT
      exact ⟨U,K,hK,hKs,hxK,hsubK.trans (subset_sUnion_of_mem hTS)⟩

end Patch
end ScottSpectraReviewed
