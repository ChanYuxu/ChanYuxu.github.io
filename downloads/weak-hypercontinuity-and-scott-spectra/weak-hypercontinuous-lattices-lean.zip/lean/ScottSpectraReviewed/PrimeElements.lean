import ScottSpectraReviewed.SpectrumDcpo

noncomputable section
open Set
universe u

namespace ScottSpectraReviewed

def IsProperMeetPrime {L : Type u} [CompleteLattice L] (p : L) : Prop :=
  p < ⊤ ∧ ∀ a b : L, a ⊓ b ≤ p → a ≤ p ∨ b ≤ p

namespace Spectrum
variable {L : Type u} [CompleteLattice L]

def primeElement (F : Spectrum L) : L := sSup {a : L | a ∉ F}

theorem primeElement_not_mem (F : Spectrum L) : F.primeElement ∉ F := by
  intro h
  obtain ⟨a, ha, haF⟩ := F.completely_prime {a : L | a ∉ F} h
  exact ha haF

theorem mem_iff_not_le_primeElement (F : Spectrum L) (a : L) :
    a ∈ F ↔ ¬ a ≤ F.primeElement := by
  constructor
  · intro ha hap
    exact F.primeElement_not_mem (F.mem_of_le hap ha)
  · intro h
    by_contra ha
    exact h (le_sSup ha)

theorem primeElement_isProperMeetPrime (F : Spectrum L) :
    IsProperMeetPrime F.primeElement := by
  classical
  refine ⟨lt_top_iff_ne_top.mpr ?_, ?_⟩
  · intro h
    exact F.primeElement_not_mem (h ▸ F.top_mem)
  · intro a b hab
    by_contra h
    push_neg at h
    have ha : a ∈ F := (F.mem_iff_not_le_primeElement a).mpr h.1
    have hb : b ∈ F := (F.mem_iff_not_le_primeElement b).mpr h.2
    exact F.primeElement_not_mem (F.mem_of_le hab ((F.inf_mem_iff a b).mpr ⟨ha, hb⟩))

def ofPrimeElement (p : L) (hp : IsProperMeetPrime p) : Spectrum L where
  filter := (Order.IsPFilter.of_def (F := {a : L | ¬ a ≤ p})
    ⟨⊤, not_le_of_gt hp.1⟩
    (by
      intro a ha b hb
      refine ⟨a ⊓ b, ?_, inf_le_left, inf_le_right⟩
      exact fun h => (hp.2 a b h).elim ha hb)
    (by
      intro a b hab ha hbp
      exact ha (hab.trans hbp))).toPFilter
  proper := fun h => h bot_le
  completely_prime := by
    classical
    intro S h
    change ¬ sSup S ≤ p at h
    by_contra hnone
    apply h
    apply sSup_le
    intro a ha
    by_contra hap
    exact hnone ⟨a, ha, hap⟩

@[simp] theorem mem_ofPrimeElement (p : L) (hp : IsProperMeetPrime p) (a : L) :
    a ∈ ofPrimeElement p hp ↔ ¬ a ≤ p := Iff.rfl

theorem ofPrimeElement_primeElement (F : Spectrum L) :
    ofPrimeElement F.primeElement F.primeElement_isProperMeetPrime = F := by
  apply SetLike.ext
  intro a
  exact (F.mem_iff_not_le_primeElement a).symm

end Spectrum
end ScottSpectraReviewed
