import ScottSpectraReviewed.ScottNecessityProducts

/-! The actual closed-set-lattice argument of CK23 Propositions 4.1 and 4.4,
specialized to a locally compact Scott space. The carrier is `Closeds` of the
full Scott topology, with its actual complete lattice and lower Vietoris
topology. No continuity of this complete lattice is assumed or concluded.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u v w

namespace ScottSpectraReviewed
namespace ScottClosedHyperspace

variable {P : Type u} [PartialOrder P]
local instance : TopologicalSpace P := scottTopology P

abbrev Carrier (P : Type u) [PartialOrder P] := @Closeds P (scottTopology P)

def principal (x : P) : Carrier P :=
  ⟨Iic x, (isScottClosed_iff _).mpr ⟨isLowerSet_Iic x,
    fun _ hD _ _ _ hLUB => hLUB.2 hD⟩⟩

theorem principal_le_iff (x : P) (A : Carrier P) : principal x ≤ A ↔ x ∈ (A : Set P) := by
  constructor
  · intro h
    exact h le_rfl
  · intro hx z hz
    exact ((isScottClosed_iff (A : Set P)).mp A.isClosed).1 hz hx

theorem principal_eq_eta (x : P) : principal x = ClosedLattice.eta x := by
  apply le_antisymm
  · intro z hz
    exact ((isScottClosed_iff (closure ({x} : Set P))).mp isClosed_closure).1 hz
      (subset_closure (mem_singleton x))
  · exact closure_minimal (singleton_subset_iff.mpr (show x ∈ (principal x : Set P) from le_rfl))
      (principal x).isClosed

theorem scottContinuous_principal : ScottContinuous (principal (P := P)) := by
  intro D hne hdir x hx
  constructor
  · rintro _ ⟨d, hd, rfl⟩
    exact fun _ hzd => hzd.trans (hx.1 hd)
  · intro A hA
    apply (principal_le_iff x A).mpr
    have hDA : D ⊆ (A : Set P) := fun d hd =>
      (principal_le_iff d A).mp (hA (mem_image_of_mem principal hd))
    exact ((isScottClosed_iff (A : Set P)).mp A.isClosed).2 hDA hne hdir hx

def finiteClosure (F : Finset P) : Carrier P := F.sup principal

def finiteClosureMap {ι : Type v} [Fintype ι] (p : ι → P) : Carrier P :=
  Finset.univ.sup (fun i => principal (p i))

theorem finiteClosureMap_subtype (F : Finset P) :
    finiteClosureMap (fun i : F => (i : P)) = finiteClosure F := by
  classical
  apply le_antisymm
  · apply Finset.sup_le
    intro i _
    exact Finset.le_sup i.property
  · apply Finset.sup_le
    intro i hi
    exact Finset.le_sup (f := fun j : F => principal (j : P))
      (Finset.mem_univ (⟨i, hi⟩ : F))

theorem scottContinuous_finset_sup {A : Type v} {B : Type w} {ι : Type u}
    [Preorder A] [CompleteLattice B] (F : Finset ι) (f : ι → A → B)
    (hf : ∀ i, ScottContinuous (f i)) : ScottContinuous (fun a => F.sup (fun i => f i a)) := by
  classical
  induction F using Finset.induction_on with
  | empty => simpa only [Finset.sup_empty] using (ScottContinuous.const (⊥ : B) (α := A))
  | @insert i F hi ih =>
      simpa only [Finset.sup_insert] using ((hf i).prodMk ih).comp ScottContinuous.sup₂

theorem scottContinuous_finiteClosureMap {ι : Type v} [Fintype ι] :
    ScottContinuous (finiteClosureMap (P := P) (ι := ι)) :=
  scottContinuous_finset_sup Finset.univ _
    (fun i => (ScottNecessity.scottContinuous_eval i).comp scottContinuous_principal)

theorem continuous_finiteClosureMap (hlocal : @IsLocallyCompact P (scottTopology P))
    {ι : Type v} [Fintype ι] :
    @Continuous (ι → P) (Carrier P)
      (@Pi.topologicalSpace ι (fun _ => P) (fun _ => scottTopology P))
      (scottTopology (Carrier P)) finiteClosureMap := by
  apply continuous_def.mpr
  intro U hU
  exact ScottNecessity.isOpen_pi_of_isScottOpen hlocal ι
    (ScottNecessity.isScottOpen_preimage scottContinuous_finiteClosureMap hU)

def finiteApproximants (A : Carrier P) : Set (Carrier P) :=
  {C | ∃ F : Finset P, (↑F : Set P) ⊆ A ∧ finiteClosure F = C}

theorem finiteApproximants_nonemptyDirected (A : Carrier P) :
    NonemptyDirected (finiteApproximants A) := by
  classical
  refine ⟨⟨finiteClosure ∅, ∅, by simp, rfl⟩, ?_⟩
  rintro _ ⟨F, hFA, rfl⟩ _ ⟨G, hGA, rfl⟩
  refine ⟨finiteClosure (F ∪ G), ⟨F ∪ G, ?_, rfl⟩,
    Finset.sup_mono Finset.subset_union_left, Finset.sup_mono Finset.subset_union_right⟩
  intro x hx
  rcases Finset.mem_union.mp hx with hx | hx
  · exact hFA hx
  · exact hGA hx

theorem finiteApproximants_isLUB (A : Carrier P) : IsLUB (finiteApproximants A) A := by
  classical
  constructor
  · rintro _ ⟨F, hFA, rfl⟩
    exact Finset.sup_le (fun x hx => (principal_le_iff x A).mpr (hFA hx))
  · intro B hB x hx
    have hmem : finiteClosure {x} ∈ finiteApproximants A :=
      ⟨{x}, by simpa only [Finset.coe_singleton, singleton_subset_iff] using hx, rfl⟩
    have hle := hB hmem
    have hprincipal : principal x ≤ B := by simpa only [finiteClosure, Finset.sup_singleton] using hle
    exact (principal_le_iff x B).mp hprincipal

/-- CK23 Proposition 4.1's finite-product-neighborhood argument on the actual
closed-set carrier. Empty finite approximants are included automatically. -/
theorem isLowerVietorisOpen_of_isScottOpen
    (hlocal : @IsLocallyCompact P (scottTopology P)) {U : Set (Carrier P)}
    (hU : IsOpen[scottTopology (Carrier P)] U) :
    IsOpen[ClosedLattice.lowerVietorisTopology P] U := by
  classical
  letI : TopologicalSpace (Carrier P) := ClosedLattice.lowerVietorisTopology P
  have hUspec := (isScottOpen_iff U).mp hU
  apply isOpen_iff_mem_nhds.mpr
  intro A hAU
  obtain ⟨_, ⟨F, hFA, rfl⟩, hFU⟩ := hUspec.2
    (finiteApproximants_nonemptyDirected A).1 (finiteApproximants_nonemptyDirected A).2
    (finiteApproximants_isLUB A) hAU
  let p : F → P := fun i => i.val
  have hp : finiteClosureMap p ∈ U := by
    rw [finiteClosureMap_subtype]
    exact hFU
  have hpre : IsOpen (finiteClosureMap (P := P) (ι := F) ⁻¹' U) :=
    (@continuous_def (F → P) (Carrier P)
      (inferInstance : TopologicalSpace (F → P)) (scottTopology (Carrier P)) _).mp
      (continuous_finiteClosureMap hlocal) U hU
  obtain ⟨V, hV, hbox⟩ := isOpen_pi_iff'.mp hpre p hp
  let O : F → Opens P := fun i => ⟨V i, (hV i).1⟩
  let W : Set (Carrier P) := ⋂ i : F, ClosedLattice.hit (O i)
  have hWopen : IsOpen W := isOpen_iInter_of_finite fun i =>
    isOpen_generateFrom_of_mem ⟨O i, rfl⟩
  have hAW : A ∈ W := mem_iInter.mpr fun i =>
    ⟨i.val, hFA i.property, (hV i).2⟩
  apply mem_of_superset (hWopen.mem_nhds hAW)
  intro B hBW
  have hchoose : ∀ i : F, ∃ y : P, y ∈ (B : Set P) ∧ y ∈ V i := by
    intro i
    exact mem_iInter.mp hBW i
  choose q hqB hqV using hchoose
  have hqbox : q ∈ Set.univ.pi V := fun i _ => hqV i
  have hqU : finiteClosureMap q ∈ U := hbox hqbox
  have hqB' : finiteClosureMap q ≤ B := Finset.sup_le
    (fun i _ => (principal_le_iff (q i) B).mpr (hqB i))
  exact hUspec.1 hqB' hqU

/-- The cited equality sigma Gamma(P) = upper Gamma(P), without any
continuity/web hypothesis on Gamma(P) or on its Scott topology. -/
theorem scottTopology_eq_upper (hlocal : @IsLocallyCompact P (scottTopology P)) :
    scottTopology (Carrier P) = upperTopology (Carrier P) := by
  rw [← ClosedLattice.lowerVietoris_eq_upper (X := P)]
  ext U
  constructor
  · exact isLowerVietorisOpen_of_isScottOpen hlocal
  · intro hU
    have hId : Continuous[scottTopology (Carrier P), ClosedLattice.lowerVietorisTopology P]
        (id : Carrier P → Carrier P) := by
      apply continuous_generateFrom_iff.mpr
      rintro _ ⟨O, rfl⟩
      rw [ClosedLattice.hit_eq_compl_Iic]
      apply (isScottOpen_iff _).mpr
      constructor
      · intro A B hAB hA hB
        exact hA (hAB.trans hB)
      · intro D hne hdir A hA hnot
        by_contra hno
        have hall : ∀ d ∈ D, d ≤ O.compl := by
          intro d hd
          by_contra h
          exact hno ⟨d, hd, h⟩
        exact hnot (hA.2 hall)
    exact (@continuous_def (Carrier P) (Carrier P) (scottTopology (Carrier P))
      (ClosedLattice.lowerVietorisTopology P) id).mp hId U hU

end ScottClosedHyperspace
end ScottSpectraReviewed
