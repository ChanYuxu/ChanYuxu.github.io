import ScottSpectraReviewed.TopologicalModels
import Mathlib.Data.Fintype.Option
import Mathlib.Order.Bounds.OrderIso

/-! Finite-product foundations for the cited CK23 necessary implication.
CK23 Proposition 4.4 uses finite-power Scott/product equality before applying
its Proposition 4.1. Here the actual spectrum's proved local compactness
allows the compact-sandwich proof of that equality, rather than the more
general core-compact directed-space proof of CK23 Theorem 3.5.
Primary source: DOI 10.3934/math.2023242, pages 4866 and 4868--4870.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u v w

namespace ScottSpectraReviewed
namespace ScottNecessity

theorem continuous_scott {P : Type u} {Q : Type v} [Preorder P] [Preorder Q]
    {f : P → Q} (hf : ScottContinuous f) :
    Continuous[scottTopology P, scottTopology Q] f := by
  apply continuous_def.mpr
  intro U hU
  have hUspec := (isScottOpen_iff U).mp hU
  apply (isScottOpen_iff _).mpr
  refine ⟨fun a b hab ha => hUspec.1 (hf.monotone hab) ha, ?_⟩
  intro D hne hdir x hx hfx
  have himage : NonemptyDirected (f '' D) :=
    ⟨hne.image f, directedOn_image.mpr (hdir.mono @hf.monotone)⟩
  obtain ⟨_, ⟨d, hd, rfl⟩, hfd⟩ := hUspec.2 himage.1 himage.2 (hf hne hdir hx) hfx
  exact ⟨d, hd, hfd⟩

theorem isScottOpen_preimage {P : Type u} {Q : Type v} [Preorder P] [Preorder Q]
    {f : P → Q} (hf : ScottContinuous f) {U : Set Q}
    (hU : IsOpen[scottTopology Q] U) : IsOpen[scottTopology P] (f ⁻¹' U) :=
  (@continuous_def P Q (scottTopology P) (scottTopology Q) f).mp
    (continuous_scott hf) U hU

theorem scottContinuous_eval {ι : Type u} {P : Type v} [Preorder P] (i : ι) :
    ScottContinuous (fun f : ι → P => f i) := by
  intro D _ _ x hx
  exact (isLUB_pi.mp hx) i

theorem scottContinuous_pi {A : Type u} {ι : Type v} {P : Type w}
    [Preorder A] [Preorder P] (f : ι → A → P) (hf : ∀ i, ScottContinuous (f i)) :
    ScottContinuous (fun a i => f i a) := by
  intro D hne hdir x hx
  apply isLUB_pi.mpr
  intro i
  simpa only [image_image, Function.comp_def] using hf i hne hdir hx

theorem scottContinuous_reindex {ι : Type u} {κ : Type v} {P : Type w}
    [Preorder P] (r : κ → ι) :
    ScottContinuous (fun f : ι → P => fun j : κ => f (r j)) :=
  scottContinuous_pi _ (fun j => scottContinuous_eval (r j))

theorem scottContinuous_orderIso {P : Type u} {Q : Type v}
    [Preorder P] [Preorder Q] (e : P ≃o Q) : ScottContinuous e := by
  intro D _ _ x hx
  exact e.isLUB_image'.mpr hx

/-- The compact-sandwich proof of Scott/product equality. Only the left
Scott space needs the source form of local compactness; Q is arbitrary. -/
theorem isOpen_prod_of_isScottOpen {P : Type u} {Q : Type v}
    [PartialOrder P] [PartialOrder Q]
    (hlocal : @IsLocallyCompact P (scottTopology P)) {U : Set (P × Q)}
    (hU : IsOpen[scottTopology (P × Q)] U) :
    @IsOpen (P × Q) (@instTopologicalSpaceProd P Q (scottTopology P) (scottTopology Q)) U := by
  letI : TopologicalSpace P := scottTopology P
  letI : TopologicalSpace Q := scottTopology Q
  have hUspec := (isScottOpen_iff U).mp hU
  have hleft : ∀ y : Q, IsOpen {x : P | (x, y) ∈ U} := fun y =>
    isScottOpen_preimage (ScottContinuous.id.prodMk (ScottContinuous.const y)) hU
  have hright : ∀ x : P, IsOpen {y : Q | (x, y) ∈ U} := fun x =>
    isScottOpen_preimage ((ScottContinuous.const x).prodMk ScottContinuous.id) hU
  apply isOpen_iff_mem_nhds.mpr
  rintro ⟨x, y⟩ hxy
  obtain ⟨V, K, hxV, hVK, hKslice, hKcompact, _⟩ := hlocal ⟨_, hleft y⟩ x hxy
  let W : Set Q := {z | ∀ a ∈ K, (a, z) ∈ U}
  have hWopen : IsOpen W := by
    apply (isScottOpen_iff W).mpr
    constructor
    · intro a b hab ha z hz
      exact hUspec.1 (show (z, a) ≤ (z, b) from ⟨le_rfl, hab⟩) (ha z hz)
    · intro D hne hdir z hz hzW
      letI : Nonempty D := hne.to_subtype
      let A : D → Set P := fun d => {a | (a, (d : Q)) ∈ U}
      have hAopen : ∀ d : D, IsOpen (A d) := fun d => hleft d.val
      have hcover : K ⊆ ⋃ d : D, A d := by
        intro a ha
        obtain ⟨d, hd, had⟩ := ((isScottOpen_iff _).mp (hright a)).2 hne hdir hz (hzW a ha)
        exact mem_iUnion.mpr ⟨⟨d, hd⟩, had⟩
      have hAdir : Directed (· ⊆ ·) A := by
        intro d e
        obtain ⟨f, hf, hdf, hef⟩ := hdir d d.property e e.property
        refine ⟨⟨f, hf⟩, ?_, ?_⟩
        · intro a ha
          exact hUspec.1 (show (a, (d : Q)) ≤ (a, f) from ⟨le_rfl, hdf⟩) ha
        · intro a ha
          exact hUspec.1 (show (a, (e : Q)) ≤ (a, f) from ⟨le_rfl, hef⟩) ha
      obtain ⟨d, hd⟩ := hKcompact.elim_directed_cover A hAopen hcover hAdir
      exact ⟨d, d.property, hd⟩
  have hyW : y ∈ W := hKslice
  apply mem_of_superset (prod_mem_nhds (V.isOpen.mem_nhds hxV) (hWopen.mem_nhds hyW))
  rintro ⟨a, b⟩ ⟨ha, hb⟩
  exact hb a (hVK ha)

/-- Every finite power of a locally compact Scott space has its actual
product topology equal to its intrinsic Scott topology. The proof is by
finite-type empty/option induction, with genuine reindexing, not a change of
carrier to finite-supported functions. -/
theorem isOpen_pi_of_isScottOpen {P : Type u} [PartialOrder P]
    (hlocal : @IsLocallyCompact P (scottTopology P))
    (ι : Type v) [Finite ι] {U : Set (ι → P)}
    (hU : IsOpen[scottTopology (ι → P)] U) :
    @IsOpen (ι → P) (@Pi.topologicalSpace ι (fun _ => P) (fun _ => scottTopology P)) U := by
  letI : TopologicalSpace P := scottTopology P
  have hfinite : ∀ (ι : Type v) [Finite ι], ∀ U : Set (ι → P),
      IsOpen[scottTopology (ι → P)] U → IsOpen U := by
    intro ι _
    apply Finite.induction_empty_option (P := fun ι : Type v =>
      ∀ U : Set (ι → P), IsOpen[scottTopology (ι → P)] U → IsOpen U)
    · intro α β e ih S hS
      have hpre := ih _ (isScottOpen_preimage (scottContinuous_reindex e.symm) hS)
      have hcont : Continuous (fun f : β → P => fun i : α => f (e i)) :=
        continuous_pi fun i => continuous_apply (e i)
      have h := hpre.preimage hcont
      convert h using 1
      ext f
      simp only [mem_preimage]
      have heq : (fun j : β => f (e (e.symm j))) = f := by
        funext j
        rw [e.apply_symm_apply]
      rw [heq]
    · intro S _
      by_cases hs : S.Nonempty
      · have heq : S = univ := by
          obtain ⟨f, hf⟩ := hs
          exact eq_univ_of_forall fun g => (Subsingleton.elim f g) ▸ hf
        rw [heq]
        exact isOpen_univ
      · rw [Set.not_nonempty_iff_eq_empty.mp hs]
        exact isOpen_empty
    · intro α _ ih S hS
      let r : (P × (α → P)) → Option α → P := fun p i => Option.casesOn i p.1 p.2
      have hr : ScottContinuous r := by
        apply scottContinuous_pi
        intro i
        cases i with
        | none => exact ScottContinuous.fst
        | some i => exact ScottContinuous.snd.comp (scottContinuous_eval i)
      have hpre := isOpen_prod_of_isScottOpen hlocal (isScottOpen_preimage hr hS)
      have hsnd : @Continuous (Option α → P) (α → P)
          (inferInstance : TopologicalSpace (Option α → P)) (scottTopology (α → P))
          (fun f i => f (some i)) := by
        apply (@continuous_def (Option α → P) (α → P)
          (inferInstance : TopologicalSpace (Option α → P)) (scottTopology (α → P)) _).mpr
        intro T hT
        exact (ih T hT).preimage (continuous_pi fun i => continuous_apply (some i))
      letI : TopologicalSpace (α → P) := scottTopology (α → P)
      have hcont : Continuous (fun f : Option α → P => (f none, fun i : α => f (some i))) :=
        (continuous_apply none).prodMk hsnd
      have h := hpre.preimage hcont
      convert h using 1
      ext f
      simp only [mem_preimage]
      have heq : r (f none, fun i => f (some i)) = f := by
        funext i
        cases i <;> rfl
      rw [heq]
  exact hfinite ι U hU

end ScottNecessity
end ScottSpectraReviewed
