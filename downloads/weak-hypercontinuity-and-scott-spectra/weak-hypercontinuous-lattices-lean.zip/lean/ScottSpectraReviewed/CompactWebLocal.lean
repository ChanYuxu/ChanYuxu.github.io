import ScottSpectraReviewed.CompactOrdered
import ScottSpectraReviewed.CompactSemilattice
import Mathlib.Topology.Sets.VietorisTopology

/-! Source Proposition `thm:compactweb`, lines 282--453.  This module proves
the first two local assertions of the printed proof (lines 296--313), not
the whole proposition.  Its neighborhood is not required to be open. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace CompactWeb

variable {P : Type u} [PartialOrder P] [TopologicalSpace P]

/-- Literally the local common-lower-bound hypothesis in source 286--293.
This is a specification of the source hypothesis, not a certificate carrying
any conclusion of the compact-web criterion. -/
def HasLocalLowerBounds (P : Type u) [PartialOrder P] [TopologicalSpace P] : Prop :=
  ∀ (U : Set P), IsOpen U → ∀ x ∈ U,
    ∃ W : Set P, W ∈ 𝓝 x ∧ W ⊆ U ∧
      ∀ y ∈ W, ∃ z ∈ W, z ≤ x ∧ z ≤ y

/-- Source first paragraph: upward closure remains open after intersection
with an arbitrary lower set, which is not required to be closed. -/
theorem isOpen_upperClosure_inter
    (hup : ∀ U : Set P, IsOpen U → IsOpen (upperClosure U : Set P))
    (hweb : HasLocalLowerBounds P) {U F : Set P}
    (hU : IsOpen U) (hF : IsLowerSet F) :
    IsOpen (upperClosure (U ∩ F) : Set P) := by
  rw [isOpen_iff_forall_mem_open]
  rintro x ⟨s,hs,hxs⟩
  obtain ⟨W,hW,hWU,hlower⟩ := hweb U hU s hs.1
  obtain ⟨V,hVW,hV,hsV⟩ := mem_nhds_iff.mp hW
  refine ⟨upperClosure V,?_,hup V hV,⟨s,hsV,hxs⟩⟩
  rintro y ⟨v,hvV,hvy⟩
  obtain ⟨z,hzW,hzs,hzv⟩ := hlower v (hVW hvV)
  exact ⟨z,⟨hWU hzW,hF hzs hs.2⟩,hzv.trans hvy⟩

/-- Source (lower-localization): closure of a lower set is witnessed by
points below the point of closure inside each specified open neighborhood. -/
theorem lower_localization (hweb : HasLocalLowerBounds P) {B U : Set P}
    (hB : IsLowerSet B) (hU : IsOpen U) {x : P} (hxU : x ∈ U)
    (hxB : x ∈ closure B) : (B ∩ Iic x ∩ U).Nonempty := by
  obtain ⟨W,hW,hWU,hlower⟩ := hweb U hU x hxU
  obtain ⟨V,hVW,hV,hxV⟩ := mem_nhds_iff.mp hW
  obtain ⟨a,haV,haB⟩ := mem_closure_iff.mp hxB V hV hxV
  obtain ⟨z,hzW,hzx,hza⟩ := hlower a (hVW haV)
  exact ⟨z,⟨hB hza haB,hzx⟩,hWU hzW⟩

end CompactWeb
end ScottSpectraReviewed
