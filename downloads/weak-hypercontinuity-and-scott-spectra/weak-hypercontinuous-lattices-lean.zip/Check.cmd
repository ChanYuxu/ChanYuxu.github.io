@echo off
setlocal
cd /d "%~dp0lean" || exit /b 1
lake build
exit /b %errorlevel%
