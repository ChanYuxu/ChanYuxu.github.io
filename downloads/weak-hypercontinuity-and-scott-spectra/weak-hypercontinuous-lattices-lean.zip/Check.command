#!/bin/sh
set -eu
cd "$(dirname "$0")/lean"
exec lake build
