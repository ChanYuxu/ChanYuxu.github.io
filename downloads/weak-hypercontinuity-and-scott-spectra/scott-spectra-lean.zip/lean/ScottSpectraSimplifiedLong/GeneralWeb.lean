import ScottSpectraSimplifiedLong.PointSequence
import ScottSpectraSimplifiedLong.CoprimeCountable
import ScottSpectraSimplifiedLong.Observables
import ScottSpectraReviewed.GeneralWebClosedTrace
import ScottSpectraReviewed.GeneralWebQuotientTopology

/-! New source Theorem web. Its coprime subspace uses the NEW whole-space
Borel/countable proof, and its actual Scott patch inputs use NEW upper-patch.
The unchanged Urysohn coordinate/evaluation quotient and literal eta-trace
constructions are reused, not replaced by arbitrary models or maps. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u v
namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
variable {X : Type u} [TopologicalSpace X] [T0Space X] [QuasiSober X]
namespace GeneralWeb
open ScottSpectraReviewed.GeneralWeb

section Trace
variable {Q : Type v} [CompleteLattice Q]
theorem closedTrace_sequence_contradiction [QuasiSober X]
    (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q) (hq : Function.Surjective q)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (hframe : IsFrame Qᵒᵈ) (hcont : IsContinuousLattice Qᵒᵈ)
    (heq : scottTopology Q = upperTopology Q)
    (hcount : @SecondCountableTopology Q (scottTopology Q))
    (B : Set X) (hB : letI : PartialOrder X := specializationOrder X;
      IsClosed[scottTopology X] B)
    (g : X) (c : ℕ → X) (hgB : g ∉ B) (hcB : ∀ n, c n ∈ B)
    (hc : Tendsto c atTop (𝓝 g))
    (hfixg : CompleteHom.leftAdjoint q (q (ClosedLattice.eta g)) = ClosedLattice.eta g)
    (hfixc : ∀ n, CompleteHom.leftAdjoint q (q (ClosedLattice.eta (c n))) = ClosedLattice.eta (c n)) :
    False := by
  letI : TopologicalSpace (CoprimeElements Q) := CoprimeElements.hullKernelTopology
  have hclosed : IsClosed (etaTrace q B) := by
    change IsClosed[CoprimeElements.hullKernelTopology] (etaTrace q B)
    rw [coprimeHullKernel_eq_intrinsic_scott Q hframe hcont heq hcount]
    exact etaTrace_isScottClosed q hq B hB
  have hseq := fixedPointCoprime_tendsto q hq hη heq g c hc hfixg hfixc
  have hmem : fixedPointCoprime q hq g hfixg ∈ etaTrace q B :=
    hclosed.mem_of_tendsto hseq (Eventually.of_forall fun n =>
      (fixedPointCoprime_mem_etaTrace_iff q hq (c n) (hfixc n) B).mpr (hcB n))
  exact hgB ((fixedPointCoprime_mem_etaTrace_iff q hq g hfixg B).mp hmem)


end Trace

/-- The source arbitrary Scott-closed-set assertion. All metric quotient,
spectral representation, countability and fixed-point inputs to the final
closed-trace contradiction are constructed internally under source hypotheses.
-/
theorem scottClosed_isClosed (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (B : Set X) (hB : letI : PartialOrder X := specializationOrder X;
      IsClosed[scottTopology X] B) : IsClosed B := by
  classical
  letI : PartialOrder X := specializationOrder X
  apply isClosed_of_closure_subset
  intro x hxClosure
  by_contra hxB
  obtain ⟨g, c, hgx, hgClosure, hgB, hfcg, hfcc, hc⟩ :=
    source_pointSequence hlocal hweb B hB x hxClosure hxB
  obtain ⟨Q, tQ, lQ, hQ⟩ := quotient_fixing_pointSequence hlocal hweb g c hfcg
    (fun n => (hfcc n).2)
  letI : TopologicalSpace Q := tQ
  letI : CompleteLattice Q := lQ
  obtain ⟨hQcompact, hQT2, hQmetric, hQinf, hQsup, q, hq, hqcont, hfixg, hfixc⟩ := hQ
  letI : CompactSpace Q := hQcompact
  letI : T2Space Q := hQT2
  letI : MetrizableSpace Q := hQmetric
  letI : ContinuousInf Q := hQinf
  letI : ContinuousSup Q := hQsup
  have hMframe : IsFrame ((ClosedLattice.Carrier X)ᵒᵈ) := ClosedLattice.isCoframe
  have hMcont : IsContinuousLattice ((ClosedLattice.Carrier X)ᵒᵈ) :=
    ClosedLattice.carrier_dual_isContinuous hlocal
  have hMdual : DualTopologyEquality ((ClosedLattice.Carrier X)ᵒᵈ) :=
    Canonical.carrier_scott_eq_upper hlocal hweb
  obtain ⟨hQframe, hQcont, hQdual⟩ := source_quotient hMframe hMcont hMdual q.dual hq
  have hQeq : scottTopology Q = upperTopology Q := hQdual
  letI : OrderClosedTopology Q := MetricLatticeQuotient.orderClosedTopology_of_continuousInf
  letI : TopologicalSpace (ClosedLattice.Carrier X) := ClosedLattice.canonicalPatchTopology X
  letI : CompactSpace (ClosedLattice.Carrier X) :=
    Canonical.compactSpace hlocal hweb
  have hMopen : ∀ U : Set (ClosedLattice.Carrier X),
      IsOpen[scottTopology (ClosedLattice.Carrier X)] U → IsOpen U :=
    fun U hU => ((Canonical.isOpen_iff_patch_upper hlocal hweb U).mp hU).1
  have hQcount : @SecondCountableTopology Q (scottTopology Q) :=
    scott_secondCountable_of_compactMetricQuotient q hq hqcont hMopen
  have hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta :=
    @Topology.IsEmbedding.continuous X (ClosedLattice.Carrier X) ClosedLattice.eta
      ‹TopologicalSpace X› (scottTopology (ClosedLattice.Carrier X))
      (Canonical.eta_isEmbedding hlocal hweb)
  exact closedTrace_sequence_contradiction q hq hη hQframe hQcont hQeq hQcount
    B hB g c hgB (fun n => (hfcc n).1) hc hfixg hfixc

end GeneralWeb

/-- Every locally compact sober web space is the full Scott space of its
actual specialization partial order, exactly as in the reviewed source. -/
theorem source_web (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    letI : PartialOrder X := specializationOrder X
    ‹TopologicalSpace X› = scottTopology X := by
  letI : PartialOrder X := specializationOrder X
  apply TopologicalSpace.ext_isClosed
  intro B
  constructor
  · intro hB
    have hopen : IsOpen[scottTopology X] Bᶜ := (sober_isDSpace (X := X)).2 Bᶜ hB.isOpen_compl
    exact @IsClosed.mk X (scottTopology X) B hopen
  · exact GeneralWeb.scottClosed_isClosed hlocal hweb B

end ScottSpectraSimplifiedLong

