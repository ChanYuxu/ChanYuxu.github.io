import ScottSpectraReviewed.UpperTopologySobriety
import ScottSpectraReviewed.PatchOrdered
import ScottSpectraReviewed.PatchProduct
import ScottSpectraSimplifiedLong.CompactMeetScottClosed

/-! The actual upper/patch proof of Proposition `prop:upper-patch` of the
frozen simplified-long manuscript. Fixed meet and join maps are shown to
preserve compact saturated inverse images using the printed adjunction
formulas, before invoking the proved separate-to-joint theorem. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed

@[implicit_reducible] def upperPatchTopology (M : Type u) [CompleteLattice M] :
    TopologicalSpace M := @patchTopology M (upperTopology M)

namespace UpperPatch
variable {M : Type u} [instM : CompleteLattice M]

theorem compactSpace (M : Type u) [CompleteLattice M] :
    @CompactSpace M (upperPatchTopology M) := by
  letI : TopologicalSpace M := upperTopology M
  letI : CompactSpace M := upper_compactSpace M
  letI : QuasiSober M := upper_quasiSober M
  exact Patch.compactSpace (upper_isCoherent M)

theorem t2Space (hlocal : @IsLocallyCompact M (upperTopology M)) :
    @T2Space M (upperPatchTopology M) := by
  letI : TopologicalSpace M := upperTopology M
  letI : T0Space M := upper_t0Space M
  exact Patch.t2Space hlocal

theorem orderClosed (hlocal : @IsLocallyCompact M (upperTopology M)) :
    @OrderClosedTopology M (upperPatchTopology M) _ := by
  letI : TopologicalSpace M := upperTopology M
  refine @OrderClosedTopology.mk M (upperPatchTopology M) _ ?_
  have h := Patch.isClosed_specialization hlocal
  have heq : {p : M × M | SpecializationLE p.1 p.2} = {p : M × M | p.1 ≤ p.2} := by
    ext p
    exact (specializationLE_iff _ _).trans (upper_specializes_iff _ _)
  rwa [heq] at h

theorem isOpen_iff_upper (hlocal : @IsLocallyCompact M (upperTopology M))
    (U : Set M) : IsOpen[upperTopology M] U ↔
      IsOpen[upperPatchTopology M] U ∧ IsUpperSet U := by
  letI : TopologicalSpace M := upperTopology M
  have h := Patch.isOpen_iff_patch_upper hlocal (compactSpace M) U
  refine h.trans ?_
  constructor
  · rintro ⟨hU, hu⟩
    refine ⟨hU, ?_⟩
    intro a b hab ha
    exact hu a b ((specializationLE_iff a b).mpr ((upper_specializes_iff b a).mpr hab)) ha
  · rintro ⟨hU, hu⟩
    exact ⟨hU, fun a b hab ha => hu
      ((upper_specializes_iff b a).mp ((specializationLE_iff a b).mp hab)) ha⟩

/-- Saturation of a compact set is compact in the genuine upper topology. -/
theorem isCompact_upperClosure {K : Set M}
    (hK : @IsCompact M (upperTopology M) K) :
    @IsCompact M (upperTopology M) (upperClosure K : Set M) := by
  letI : TopologicalSpace M := upperTopology M
  letI : Topology.IsUpper M := ⟨rfl⟩
  apply isCompact_of_finite_subcover
  intro ι U hU hcover
  obtain ⟨F, hF⟩ := hK.elim_finite_subcover U hU (subset_upperClosure.trans hcover)
  refine ⟨F, ?_⟩
  rintro x ⟨k, hk, hkx⟩
  obtain ⟨i, hi, hki⟩ := mem_iUnion₂.mp (hF hk)
  exact mem_iUnion₂.mpr ⟨i, hi,
    (Topology.IsUpper.isUpperSet_of_isOpen (hU i)) hkx hki⟩

theorem continuous_of_compact_saturated_preimages (f : M → M)
    (hf : Continuous[upperTopology M, upperTopology M] f)
    (hpre : ∀ K : Set M, @IsCompact M (upperTopology M) K →
      @IsSaturated M (upperTopology M) K →
      @IsCompact M (upperTopology M) (f ⁻¹' K) ∧
      @IsSaturated M (upperTopology M) (f ⁻¹' K)) :
    Continuous[upperPatchTopology M, upperPatchTopology M] f := by
  apply continuous_generateFrom_iff.mpr
  rintro U (hU | ⟨K, hK, hKs, rfl⟩)
  · exact @Patch.isOpen_original M (upperTopology M) _ (continuous_def.mp hf U hU)
  · rw [preimage_compl]
    exact @Patch.isOpen_compl_compact_saturated M (upperTopology M) _
      (hpre K hK hKs).1 (hpre K hK hKs).2

/-- The literal compact-saturated meet inverse-image formula from the source. -/
theorem inf_preimage_eq (a : M) {K : Set M} (hK : IsUpperSet K) :
    (fun x : M => a ⊓ x) ⁻¹' K = (upperClosure (K ∩ Iic a) : Set M) := by
  ext x
  constructor
  · intro hx
    exact ⟨a ⊓ x, ⟨hx, inf_le_left⟩, inf_le_right⟩
  · rintro ⟨k, ⟨hk, hka⟩, hkx⟩
    exact hK (le_inf hka hkx) hk

theorem continuous_inf_left (hframe : IsFrame M) (a : M) :
    Continuous[upperPatchTopology M, upperPatchTopology M] (fun x => a ⊓ x) := by
  apply continuous_of_compact_saturated_preimages _ (upper_continuous_inf_left hframe a)
  intro K hK hKs
  rw [inf_preimage_eq a ((upper_isSaturated_iff K).mp hKs)]
  refine ⟨isCompact_upperClosure ?_, (upper_isSaturated_iff _).mpr (upperClosure _).upper⟩
  letI : TopologicalSpace M := upperTopology M
  letI : Topology.IsUpper M := ⟨rfl⟩
  exact hK.inter_right isClosed_Iic

theorem continuous_inf (hframe : IsFrame M)
    (hlocal : @IsLocallyCompact M (upperTopology M)) :
    @Continuous (M × M) M
      (@instTopologicalSpaceProd M M (upperPatchTopology M) (upperPatchTopology M))
      (upperPatchTopology M) (fun p => p.1 ⊓ p.2) := by
  letI : TopologicalSpace M := upperPatchTopology M
  letI : CompactSpace M := compactSpace M
  letI : T2Space M := t2Space hlocal
  letI : OrderClosedTopology M := orderClosed hlocal
  exact CompactSemilattice.source_proposition_7_4 (continuous_inf_left hframe)

/-- The source's actual left adjoint to fixed join, implemented by the
already constructed frame-meet right adjoint in the order dual. -/
def joinLeftAdjoint (a y : M) : M :=
  frameMeetRightAdjoint (L := Mᵒᵈ) a y

theorem joinLeftAdjoint_gc (hcoframe : IsCoframe M) (a : M) :
    GaloisConnection (joinLeftAdjoint a) (fun x : M => a ⊔ x) := by
  intro y x
  exact ((frameMeetRightAdjoint_gc (L := Mᵒᵈ) hcoframe a) x y).symm

theorem upper_continuous_joinLeftAdjoint (hcoframe : IsCoframe M) (a : M) :
    Continuous[upperTopology M, upperTopology M] (joinLeftAdjoint a) := by
  apply continuous_generateFrom_iff.mpr
  rintro U ⟨b, rfl⟩
  have heq : (joinLeftAdjoint a) ⁻¹' (Iic b)ᶜ = (Iic (a ⊔ b))ᶜ := by
    ext x
    exact not_congr (joinLeftAdjoint_gc hcoframe a x b)
  rw [heq]
  exact isOpen_generateFrom_of_mem ⟨_, rfl⟩

theorem upper_continuous_sup_left (a : M) :
    Continuous[upperTopology M, upperTopology M] (fun x : M => a ⊔ x) := by
  letI : TopologicalSpace M := upperTopology M
  exact upper_continuous_sup.comp (continuous_const.prodMk continuous_id)

/-- The literal compact-saturated join inverse-image formula from the source. -/
theorem sup_preimage_eq (hcoframe : IsCoframe M) (a : M) {K : Set M}
    (hK : IsUpperSet K) :
    (fun x : M => a ⊔ x) ⁻¹' K =
      (upperClosure ((joinLeftAdjoint a) '' K) : Set M) := by
  ext x
  constructor
  · intro hx
    exact ⟨joinLeftAdjoint a (a ⊔ x), ⟨a ⊔ x, hx, rfl⟩,
      (joinLeftAdjoint_gc hcoframe a (a ⊔ x) x).mpr le_rfl⟩
  · rintro ⟨_, ⟨k, hk, rfl⟩, hkx⟩
    exact hK ((joinLeftAdjoint_gc hcoframe a k x).mp hkx) hk

theorem continuous_sup_left (hcoframe : IsCoframe M) (a : M) :
    Continuous[upperPatchTopology M, upperPatchTopology M] (fun x : M => a ⊔ x) := by
  apply continuous_of_compact_saturated_preimages _ (upper_continuous_sup_left a)
  intro K hK hKs
  rw [sup_preimage_eq hcoframe a ((upper_isSaturated_iff K).mp hKs)]
  letI : TopologicalSpace M := upperTopology M
  exact ⟨isCompact_upperClosure (hK.image (upper_continuous_joinLeftAdjoint hcoframe a)),
    (upper_isSaturated_iff _).mpr (upperClosure _).upper⟩

theorem continuous_sup (hcoframe : IsCoframe M)
    (hlocal : @IsLocallyCompact M (upperTopology M)) :
    @Continuous (M × M) M
      (@instTopologicalSpaceProd M M (upperPatchTopology M) (upperPatchTopology M))
      (upperPatchTopology M) (fun p => p.1 ⊔ p.2) := by
  have hc : @CompactSpace Mᵒᵈ (upperPatchTopology M) := compactSpace M
  have ht : @T2Space Mᵒᵈ (upperPatchTopology M) := @t2Space M instM hlocal
  have ho : @OrderClosedTopology Mᵒᵈ (upperPatchTopology M) _ := by
    letI : TopologicalSpace M := upperPatchTopology M
    letI : OrderClosedTopology M := orderClosed hlocal
    infer_instance
  exact @CompactSemilattice.source_proposition_7_4 Mᵒᵈ _ (upperPatchTopology M) hc ht ho
    (fun a => continuous_sup_left hcoframe a)

/-- The full Scott equality, proved at the cited Lawson73 lower-closed-set
boundary. No general-web theorem or continuity of the lattice is used. -/
theorem eq_scott (hframe : IsFrame M)
    (hlocal : @IsLocallyCompact M (upperTopology M)) :
    upperTopology M = scottTopology M := by
  letI : TopologicalSpace M := upperPatchTopology M
  letI : CompactSpace M := compactSpace M
  letI : T2Space M := t2Space hlocal
  letI : OrderClosedTopology M := orderClosed hlocal
  have hmeet := continuous_inf hframe hlocal
  apply TopologicalSpace.ext
  funext U
  apply propext
  constructor
  · intro hU
    obtain ⟨hUpatch, hupper⟩ := (isOpen_iff_upper hlocal U).mp hU
    exact CompactOrdered.isScottOpen_of_isOpen_upper hUpatch hupper
  · intro hU
    obtain ⟨hlower, hdir⟩ := (isScottClosed_iff Uᶜ).mp
      (@IsOpen.isClosed_compl M (scottTopology M) U hU)
    have hclosed : IsClosed Uᶜ :=
      (CompactMeet.source_lawson73_theorem13 hmeet hlower).mpr hdir
    exact (isOpen_iff_upper hlocal U).mpr
      ⟨by simpa only [compl_compl] using hclosed.isOpen_compl,
        ((isScottOpen_iff U).mp hU).1⟩

/-- The actual binary operations descend from the patch product to the
product of upper topologies, using compact upper rectangles. -/
theorem upper_continuous_inf (hframe : IsFrame M)
    (hlocal : @IsLocallyCompact M (upperTopology M)) :
    @Continuous (M × M) M
      (@instTopologicalSpaceProd M M (upperTopology M) (upperTopology M))
      (upperTopology M) (fun p => p.1 ⊓ p.2) := by
  letI : TopologicalSpace M := upperPatchTopology M
  letI : CompactSpace M := compactSpace M
  letI : OrderClosedTopology M := orderClosed hlocal
  exact Patch.continuous_prod_mono_to_upper
    (upperTopology M) (upperTopology M) (upperTopology M)
    (isOpen_iff_upper hlocal) (isOpen_iff_upper hlocal) (isOpen_iff_upper hlocal)
    (fun p => p.1 ⊓ p.2) (continuous_inf hframe hlocal)
    (fun _ _ h => inf_le_inf h.1 h.2)

theorem upper_continuous_sup (hcoframe : IsCoframe M)
    (hlocal : @IsLocallyCompact M (upperTopology M)) :
    @Continuous (M × M) M
      (@instTopologicalSpaceProd M M (upperTopology M) (upperTopology M))
      (upperTopology M) (fun p => p.1 ⊔ p.2) := by
  letI : TopologicalSpace M := upperPatchTopology M
  letI : CompactSpace M := compactSpace M
  letI : OrderClosedTopology M := orderClosed hlocal
  exact Patch.continuous_prod_mono_to_upper
    (upperTopology M) (upperTopology M) (upperTopology M)
    (isOpen_iff_upper hlocal) (isOpen_iff_upper hlocal) (isOpen_iff_upper hlocal)
    (fun p => p.1 ⊔ p.2) (continuous_sup hcoframe hlocal)
    (fun _ _ h => sup_le_sup h.1 h.2)

/-- Exact complete-frame source interface of Proposition `prop:upper-patch`.
The coframe law occurs only in the conditional second part, not in the
Scott equality or patch meet-continuity hypotheses. -/
theorem source_upper_patch (hframe : IsFrame M)
    (hlocal : @IsLocallyCompact M (upperTopology M)) :
    upperTopology M = scottTopology M ∧
      @Continuous (M × M) M
        (@instTopologicalSpaceProd M M (upperPatchTopology M) (upperPatchTopology M))
        (upperPatchTopology M) (fun p => p.1 ⊓ p.2) ∧
      (IsCoframe M →
        @CompactSpace M (upperPatchTopology M) ∧ @T2Space M (upperPatchTopology M) ∧
        @Continuous (M × M) M
          (@instTopologicalSpaceProd M M (upperPatchTopology M) (upperPatchTopology M))
          (upperPatchTopology M) (fun p => p.1 ⊔ p.2) ∧
        @Continuous (M × M) M
          (@instTopologicalSpaceProd M M (upperTopology M) (upperTopology M))
          (upperTopology M) (fun p => p.1 ⊓ p.2) ∧
        @Continuous (M × M) M
          (@instTopologicalSpaceProd M M (upperTopology M) (upperTopology M))
          (upperTopology M) (fun p => p.1 ⊔ p.2)) := by
  refine ⟨eq_scott hframe hlocal, continuous_inf hframe hlocal, ?_⟩
  intro hcoframe
  exact ⟨compactSpace M, t2Space hlocal, continuous_sup hcoframe hlocal,
    upper_continuous_inf hframe hlocal, upper_continuous_sup hcoframe hlocal⟩

end UpperPatch
end ScottSpectraSimplifiedLong
