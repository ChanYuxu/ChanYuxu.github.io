import ScottSpectraReviewed.CompactWebCriterion

/-! Exact Lawson (1973), Theorem 13 closure criterion, used as an external
foundation by the simplified-long manuscript. The lower set is not required
to be directed. The implementation reuses the independently proved compact
closed-neighborhood/FIP/directed-minimum argument of CompactWebCriterion,
not the later general-web theorem or the upper-patch proposition. This is
an alternative implementation of the cited external result; the manuscript
itself does not reproduce Lawson's tail-infimum proof. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed

namespace CompactMeet
variable {P : Type u} [SemilatticeInf P] [TopologicalSpace P]

/-- Closed natural order is derived from meet continuity and Hausdorffness,
so it is not an additional assumption in the cited closure criterion. -/
theorem orderClosed [T2Space P]
    (hcont : Continuous (fun p : P × P => p.1 ⊓ p.2)) : OrderClosedTopology P := by
  constructor
  have heq : {p : P × P | p.1 ≤ p.2} = {p : P × P | p.1 ⊓ p.2 = p.1} := by
    ext p
    exact inf_eq_left.symm
  rw [heq]
  exact isClosed_eq hcont continuous_fst

theorem isOpen_upperClosure
    (hcont : Continuous (fun p : P × P => p.1 ⊓ p.2))
    {U : Set P} (hU : IsOpen U) : IsOpen (upperClosure U : Set P) := by
  apply CompactSemilattice.isOpen_upperClosure_of_separate _ hU
  intro a
  have hc : Continuous (fun _ : P => a) := continuous_const
  exact hcont.comp (hc.prodMk continuous_id)

/-- The actual meet provides the local common-lower-bound neighborhoods. -/
theorem hasLocalLowerBounds
    (hcont : Continuous (fun p : P × P => p.1 ⊓ p.2)) :
    CompactWeb.HasLocalLowerBounds P := by
  intro U hU x hxU
  let W : Set P := U ∩ (fun y : P => x ⊓ y) ⁻¹' U
  have hW : IsOpen W := hU.inter
    (hU.preimage (hcont.comp (continuous_const.prodMk continuous_id)))
  have hxW : x ∈ W := by simpa only [W, mem_inter_iff, mem_preimage, inf_idem, and_self] using hxU
  refine ⟨W, hW.mem_nhds hxW, ?_, ?_⟩
  · exact inter_subset_left
  · intro y hy
    refine ⟨x ⊓ y, ?_, inf_le_left, inf_le_right⟩
    exact ⟨hy.2, by simpa only [mem_preimage, ← inf_assoc, inf_idem] using hy.2⟩

theorem lowerRelation_isOpen
    (hcont : Continuous (fun p : P × P => p.1 ⊓ p.2))
    {U : Set P} (hU : IsOpen U) :
    IsOpen {p : P × P | ∃ z ∈ U, z ≤ p.1 ∧ z ≤ p.2} := by
  have heq : {p : P × P | ∃ z ∈ U, z ≤ p.1 ∧ z ≤ p.2} =
      (fun p : P × P => p.1 ⊓ p.2) ⁻¹' (upperClosure U : Set P) := by
    ext p
    constructor
    · rintro ⟨z, hz, hz1, hz2⟩
      exact ⟨z, hz, le_inf hz1 hz2⟩
    · rintro ⟨z, hz, hzp⟩
      exact ⟨z, hz, hzp.trans inf_le_left, hzp.trans inf_le_right⟩
  rw [heq]
  exact (isOpen_upperClosure hcont hU).preimage hcont

/-- Lawson (1973), Theorem 13: for a compact Hausdorff topological meet
semilattice, a lower set is closed exactly when it contains every existing
nonempty directed supremum of its members. Natural-order closedness is proved,
not an extra hypothesis. No directedness of A is assumed. -/
theorem source_lawson73_theorem13 [CompactSpace P] [T2Space P]
    (hcont : Continuous (fun p : P × P => p.1 ⊓ p.2))
    {A : Set P} (hA : IsLowerSet A) : IsClosed A ↔ DirSupClosed A := by
  letI : OrderClosedTopology P := orderClosed hcont
  constructor
  · intro hclosed
    have hopen := CompactOrdered.isScottOpen_of_isOpen_upper hclosed.isOpen_compl hA.compl
    have hsclosed : IsClosed[scottTopology P] A := by
      simpa only [compl_compl] using
        (@IsOpen.isClosed_compl P (scottTopology P) Aᶜ hopen)
    exact ((isScottClosed_iff A).mp hsclosed).2
  · intro hdir
    exact CompactWeb.isClosed_of_isScottClosed_of_lowerRelation
      (fun U hU => isOpen_upperClosure hcont hU) (hasLocalLowerBounds hcont)
      (fun U hU => lowerRelation_isOpen hcont hU)
      ((isScottClosed_iff A).mpr ⟨hA, hdir⟩)

end CompactMeet
end ScottSpectraSimplifiedLong
