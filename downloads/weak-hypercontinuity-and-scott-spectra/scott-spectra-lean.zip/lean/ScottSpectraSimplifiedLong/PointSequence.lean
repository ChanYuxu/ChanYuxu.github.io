import ScottSpectraSimplifiedLong.SourceReuse
import Mathlib.Order.Filter.CountablyGenerated
import Mathlib.Topology.Sequences

/-! Source thm:web, simplified-long lines829--846: the actual first-countable point below
the original closure point, decreasing original-open basis, and first-
countable sequence inside the original Scott-closed B. Neither B nor X is
replaced by a different order/topological model. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
namespace GeneralWeb

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance generalWebPointSpecializationOrder : PartialOrder X := specializationOrder X
variable [QuasiSober X]

/-- All source selection data are retained: the actual open basis U,
the intermediate b_n, and the actual first-countable c_n below b_n. -/
theorem source_pointSequence_data (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (B : Set X) (hB : IsClosed[scottTopology X] B)
    (x : X) (hx : x ∈ closure B) (hxB : x ∉ B) :
    ∃ g : X, g ≤ x ∧ g ∈ closure B ∧ g ∉ B ∧ (𝓝 g).IsCountablyGenerated ∧
      ∃ U : ℕ → Set X, (∀ n, g ∈ U n ∧ IsOpen (U n)) ∧
        (𝓝 g).HasAntitoneBasis U ∧ ∃ b c : ℕ → X,
          (∀ n, b n ∈ B ∧ b n ∈ U n) ∧
          (∀ n, c n ≤ b n ∧ c n ∈ U n ∧ c n ∈ B ∧ (𝓝 (c n)).IsCountablyGenerated) ∧
          Tendsto c atTop (𝓝 g) := by
  have hclosed := (isScottClosed_iff B).mp hB
  have hcore := (source_fc_core hlocal hweb).2 x
  have hex : ∃ g ∈ FirstCountableCore.firstCountableBelow x, g ∉ B := by
    by_contra h
    push Not at h
    exact hxB (hclosed.2 h hcore.1.1 hcore.1.2 hcore.2)
  obtain ⟨g,hgcore,hgB⟩ := hex
  have hgfc : (𝓝 g).IsCountablyGenerated := hgcore.1
  have hgcl : g ∈ closure B :=
    (show x ⤳ g from hgcore.2).mem_closed isClosed_closure hx
  letI : (𝓝 g).IsCountablyGenerated := hgfc
  obtain ⟨U,hU,hbasis⟩ := (nhds_basis_opens g).exists_antitone_subbasis
  have hbex : ∀ n, ∃ b : X, b ∈ U n ∧ b ∈ B := by
    intro n
    exact mem_closure_iff.mp hgcl (U n) (hU n).2 (hU n).1
  choose b hbU hbB using hbex
  have hcex : ∀ n, ∃ c : X, c ≤ b n ∧ (∀ k : ℕ, c ∈ U n) ∧
      (𝓝 c).IsCountablyGenerated := by
    intro n
    exact (source_fc_core hlocal hweb).1 (b n) (fun _ => U n)
      (fun _ => (hU n).2.mem_nhds (hbU n))
  choose c hcb hcU hcfc using hcex
  have hcB : ∀ n, c n ∈ B := fun n => hclosed.1 (hcb n) (hbB n)
  have hconv : Tendsto c atTop (𝓝 g) := by
    apply hbasis.1.tendsto_right_iff.mpr
    intro n _
    filter_upwards [eventually_ge_atTop n] with m hnm
    exact hbasis.2 hnm (hcU m 0)
  exact ⟨g,hgcore.2,hgcl,hgB,hgfc,U,hU,hbasis,b,c,
    (fun n => ⟨hbB n,hbU n⟩),(fun n => ⟨hcb n,hcU n 0,hcB n,hcfc n⟩),hconv⟩

/-- Source-facing sequence reduction used by the final contradiction.
The richer preceding theorem constructs the basis and intermediate b_n;
only the data needed downstream are projected here. -/
theorem source_pointSequence (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (B : Set X) (hB : IsClosed[scottTopology X] B)
    (x : X) (hx : x ∈ closure B) (hxB : x ∉ B) :
    ∃ (g : X) (c : ℕ → X), g ≤ x ∧ g ∈ closure B ∧ g ∉ B ∧
      (𝓝 g).IsCountablyGenerated ∧
      (∀ n, c n ∈ B ∧ (𝓝 (c n)).IsCountablyGenerated) ∧ Tendsto c atTop (𝓝 g) := by
  obtain ⟨g,hgx,hgcl,hgB,hgfc,_,_,_,_,c,_,hc,hconv⟩ :=
    source_pointSequence_data hlocal hweb B hB x hx hxB
  exact ⟨g,c,hgx,hgcl,hgB,hgfc,(fun n => ⟨(hc n).2.2.1,(hc n).2.2.2⟩),hconv⟩

end GeneralWeb
end ScottSpectraSimplifiedLong

