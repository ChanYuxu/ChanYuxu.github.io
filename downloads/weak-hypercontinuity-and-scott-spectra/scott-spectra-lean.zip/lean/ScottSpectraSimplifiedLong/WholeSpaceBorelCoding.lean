import ScottSpectraReviewed.BorelCore

/-! The literal whole-space membership code in the simplified manuscript.
Unlike the older Borel-core lemma, the range here is the image of all of X.
The cited Pi2 consequence is proved directly by countable Scott-open implication
conditions: nonemptiness, refinement, finite-cover primeness and compact rounding.
No quasi-Polish or Borel-image theorem is assumed as an axiom. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraSimplifiedLong
namespace WholeSpaceBorel

open ScottSpectraReviewed ScottSpectraReviewed.BorelCore

/-- Literal Boolean masks and subsets of Nat are order-isomorphic. -/
def cantorPowersetOrderIso : Cantor ≃o Set ℕ := by
  classical
  refine
    { toFun := fun a => {n | a n = true}
      invFun := fun S n => decide (n ∈ S)
      left_inv := ?_
      right_inv := ?_
      map_rel_iff' := ?_ }
  · intro a
    funext n
    cases ha : a n <;> simp [ha]
  · intro S
    ext n
    simp
  · intro a b
    constructor
    · intro h n
      exact (bool_le_iff_true_imp _ _).mpr (fun ha => h ha)
    · intro h n hn
      exact (bool_le_iff_true_imp _ _).mp (h n) hn

variable {X : Type u} [TopologicalSpace X]

omit [TopologicalSpace X] in
@[simp] theorem code_asPowerset (B : ℕ → Set X) (x : X) :
    cantorPowersetOrderIso (code B x) = {n | x ∈ B n} := by
  ext n
  exact code_apply_eq_true B x n

/-- Compact rounding is a relation on basis indices, not a hypothesis on codes. -/
def CompactRound (B : ℕ → Set X) (k i : ℕ) : Prop :=
  ∃ K : Set X, IsCompact K ∧ B k ⊆ K ∧ K ⊆ B i

/-- Countable point conditions on the literal basis membership code. -/
def GoodCode (B : ℕ → Set X) (a : Cantor) : Prop :=
  (∃ i, a i = true) ∧
  (∀ i j, a i = true → a j = true →
    ∃ k, a k = true ∧ B k ⊆ B i ∩ B j) ∧
  (∀ i (F : Finset ℕ), B i ⊆ ⋃ j ∈ F, B j → a i = true →
    ∃ j ∈ F, a j = true) ∧
  (∀ i, a i = true → ∃ k, a k = true ∧ CompactRound B k i)

omit [TopologicalSpace X] in
theorem code_le_iff_indices (B : ℕ → Set X) (x : X) (a : Cantor) :
    code B x ≤ a ↔ ∀ n, x ∈ B n → a n = true := by
  constructor
  · intro h n hxn
    exact (bool_le_iff_true_imp _ _).mp (h n) ((code_apply_eq_true B x n).mpr hxn)
  · intro h n
    exact (bool_le_iff_true_imp _ _).mpr (fun hxn =>
      h n ((code_apply_eq_true B x n).mp hxn))

theorem code_good (B : ℕ → Set X) (hB : IsTopologicalBasis (range B))
    (hX : IsLocallyCompact X) (x : X) : GoodCode B (code B x) := by
  classical
  refine ⟨?_, ?_, ?_, ?_⟩
  · obtain ⟨_, ⟨i, rfl⟩, hxi, _⟩ := hB.exists_subset_of_mem_open (mem_univ x) isOpen_univ
    exact ⟨i, (code_apply_eq_true B x i).mpr hxi⟩
  · intro i j hi hj
    have hx : x ∈ B i ∩ B j :=
      ⟨(code_apply_eq_true B x i).mp hi, (code_apply_eq_true B x j).mp hj⟩
    obtain ⟨_, ⟨k, rfl⟩, hxk, hk⟩ := hB.exists_subset_of_mem_open hx
      ((hB.isOpen (mem_range_self i)).inter (hB.isOpen (mem_range_self j)))
    exact ⟨k, (code_apply_eq_true B x k).mpr hxk, hk⟩
  · intro i F hcover hi
    obtain ⟨j, hjF, hxj⟩ := mem_iUnion₂.mp (hcover ((code_apply_eq_true B x i).mp hi))
    exact ⟨j, hjF, (code_apply_eq_true B x j).mpr hxj⟩
  · intro i hi
    obtain ⟨V, K, hxV, hVK, hKi, hK, _⟩ :=
      hX ⟨B i, hB.isOpen (mem_range_self i)⟩ x ((code_apply_eq_true B x i).mp hi)
    obtain ⟨_, ⟨k, rfl⟩, hxk, hkV⟩ := hB.exists_subset_of_mem_open hxV V.isOpen
    exact ⟨k, (code_apply_eq_true B x k).mpr hxk, K, hK, hkV.trans hVK, hKi⟩

/-- The closed lower set whose generic point reconstructs a good code. -/
def codeLower (B : ℕ → Set X) (a : Cantor) : Set X := {x | code B x ≤ a}

theorem codeLower_isClosed (B : ℕ → Set X) (hB : IsTopologicalBasis (range B))
    (a : Cantor) : IsClosed (codeLower B a) := by
  have heq : codeLower B a = ⋂ n : ℕ, {x : X | x ∉ B n ∨ a n = true} := by
    ext x
    simp only [codeLower, mem_setOf_eq, mem_iInter, code_le_iff_indices]
    constructor
    · intro h n
      by_cases hx : x ∈ B n
      · exact Or.inr (h n hx)
      · exact Or.inl hx
    · intro h n hx
      exact (h n).resolve_left (not_not.mpr hx)
  rw [heq]
  apply isClosed_iInter
  intro n
  by_cases ha : a n = true
  · simp [ha]
  · have heq' : {x : X | x ∉ B n ∨ a n = true} = (B n)ᶜ := by ext x; simp [ha]
    rw [heq']
    exact (hB.isOpen (mem_range_self n)).isClosed_compl

theorem goodCode_meets_basis (B : ℕ → Set X) (hB : IsTopologicalBasis (range B))
    (a : Cantor) (ha : GoodCode B a) (i : ℕ) (hi : a i = true) :
    (codeLower B a ∩ B i).Nonempty := by
  classical
  obtain ⟨k, hk, K, hK, hkK, hKi⟩ := ha.2.2.2 i hi
  have hKC : (K ∩ codeLower B a).Nonempty := by
    by_contra hnone
    have hcover : K ⊆ ⋃ n : {n : ℕ // a n ≠ true}, B n.1 := by
      intro x hxK
      have hxC : x ∉ codeLower B a := fun hxC => hnone ⟨x, hxK, hxC⟩
      have hex : ∃ n, x ∈ B n ∧ a n ≠ true := by
        by_contra hno
        apply hxC
        apply (code_le_iff_indices B x a).mpr
        intro n hxn
        by_contra han
        exact hno ⟨n, hxn, han⟩
      obtain ⟨n, hxn, han⟩ := hex
      exact mem_iUnion.mpr ⟨⟨n, han⟩, hxn⟩
    obtain ⟨J, hJ⟩ := hK.elim_finite_subcover
      (fun n : {n : ℕ // a n ≠ true} => B n.1)
      (fun n => hB.isOpen (mem_range_self n.1)) hcover
    let F : Finset ℕ := J.image Subtype.val
    have hfinite : B k ⊆ ⋃ j ∈ F, B j := by
      intro x hxk
      obtain ⟨j, hj, hxj⟩ := mem_iUnion₂.mp (hJ (hkK hxk))
      exact mem_iUnion₂.mpr ⟨j.1, Finset.mem_image.mpr ⟨j, hj, rfl⟩, hxj⟩
    obtain ⟨j, hj, haj⟩ := ha.2.2.1 k F hfinite hk
    obtain ⟨n, _, hnj⟩ := Finset.mem_image.mp hj
    exact n.2 (hnj ▸ haj)
  obtain ⟨x, hxK, hxC⟩ := hKC
  exact ⟨x, hxC, hKi hxK⟩

theorem goodCode_irreducible (B : ℕ → Set X) (hB : IsTopologicalBasis (range B))
    (a : Cantor) (ha : GoodCode B a) : IsIrreducible (codeLower B a) := by
  constructor
  · obtain ⟨i, hi⟩ := ha.1
    exact (goodCode_meets_basis B hB a ha i hi).mono inter_subset_left
  · intro U V hU hV hCU hCV
    obtain ⟨x, hxC, hxU⟩ := hCU
    obtain ⟨y, hyC, hyV⟩ := hCV
    obtain ⟨_, ⟨i, rfl⟩, hxi, hiU⟩ := hB.exists_subset_of_mem_open hxU hU
    obtain ⟨_, ⟨j, rfl⟩, hyj, hjV⟩ := hB.exists_subset_of_mem_open hyV hV
    have hai : a i = true := (code_le_iff_indices B x a).mp hxC i hxi
    have haj : a j = true := (code_le_iff_indices B y a).mp hyC j hyj
    obtain ⟨k, hak, hk⟩ := ha.2.1 i j hai haj
    obtain ⟨z, hzC, hzk⟩ := goodCode_meets_basis B hB a ha k hak
    exact ⟨z, hzC, hiU (hk hzk).1, hjV (hk hzk).2⟩

theorem goodCode_mem_range [QuasiSober X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (range B))
    (a : Cantor) (ha : GoodCode B a) : a ∈ range (code B) := by
  obtain ⟨x, hx⟩ := QuasiSober.sober (goodCode_irreducible B hB a ha)
    (codeLower_isClosed B hB a)
  refine ⟨x, ?_⟩
  apply le_antisymm
  · exact hx.mem
  · intro i
    apply (bool_le_iff_true_imp _ _).mpr
    intro hai
    obtain ⟨y, hyC, hyi⟩ := goodCode_meets_basis B hB a ha i hai
    have hxy : SpecializationLE y x := by
      change y ∈ closure ({x} : Set X)
      rw [hx.def]
      exact hyC
    exact (code_apply_eq_true B x i).mpr
      (isOpen_upper_specialization (hB.isOpen (mem_range_self i)) hxy hyi)

theorem range_code_eq_good [QuasiSober X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (range B)) (hX : IsLocallyCompact X) :
    range (code B) = {a | GoodCode B a} := by
  ext a
  constructor
  · rintro ⟨x, rfl⟩
    exact code_good B hB hX x
  · exact goodCode_mem_range B hB a

/-- Every full Scott open of P(N) is open for the separately named Cantor
topology; this is proved from finite-mask directed suprema. -/
theorem scottOpen_isCantorOpen (U : Set Cantor)
    (hU : IsOpen[scottTopology Cantor] U) : IsOpen U := by
  apply isOpen_iff_mem_nhds.mpr
  intro a ha
  obtain ⟨F, hFa, hFU⟩ := exists_finiteMask_of_mem_isScottOpen U hU ha
  let V : Set Cantor := ⋂ n ∈ F, positive n
  have hV : IsOpen V := F.finite_toSet.isOpen_biInter (fun n _ => (positive_isClopen n).2)
  have haV : a ∈ V := mem_iInter₂.mpr (fun n hn => (finiteMask_le_iff F a).mp hFa n hn)
  apply Filter.mem_of_superset (hV.mem_nhds haV)
  intro b hb
  exact hFU b ((finiteMask_le_iff F b).mpr (fun n hn => mem_iInter₂.mp hb n hn))

abbrev ConditionIndex := Unit ⊕ ((ℕ × ℕ) ⊕ ((ℕ × Finset ℕ) ⊕ ℕ))

def antecedent (B : ℕ → Set X) : ConditionIndex → Set Cantor := by
  classical
  exact fun
    | .inl _ => univ
    | .inr (.inl (i, j)) => positive i ∩ positive j
    | .inr (.inr (.inl (i, F))) => if B i ⊆ ⋃ j ∈ F, B j then positive i else ∅
    | .inr (.inr (.inr i)) => positive i

def consequent (B : ℕ → Set X) : ConditionIndex → Set Cantor
  | .inl _ => ⋃ i : ℕ, positive i
  | .inr (.inl (i, j)) => ⋃ k : ℕ, ⋃ (_ : B k ⊆ B i ∩ B j), positive k
  | .inr (.inr (.inl (_, F))) => ⋃ j ∈ F, positive j
  | .inr (.inr (.inr i)) => ⋃ k : ℕ, ⋃ (_ : CompactRound B k i), positive k

omit [TopologicalSpace X] in
theorem antecedent_scottOpen (B : ℕ → Set X) (t : ConditionIndex) :
    IsOpen[scottTopology Cantor] (antecedent B t) := by
  classical
  letI : TopologicalSpace Cantor := scottTopology Cantor
  rcases t with _ | (⟨i, j⟩ | (⟨i, F⟩ | i))
  · exact isOpen_univ
  · exact (positive_isScottOpen i).inter (positive_isScottOpen j)
  · dsimp [antecedent]
    split_ifs
    · exact positive_isScottOpen i
    · exact isOpen_empty
  · exact positive_isScottOpen i

theorem consequent_scottOpen (B : ℕ → Set X) (t : ConditionIndex) :
    IsOpen[scottTopology Cantor] (consequent B t) := by
  letI : TopologicalSpace Cantor := scottTopology Cantor
  rcases t with _ | (⟨i, j⟩ | (⟨i, F⟩ | i))
  · exact isOpen_iUnion (fun n => positive_isScottOpen n)
  · exact isOpen_iUnion (fun k => isOpen_iUnion (fun _ => positive_isScottOpen k))
  · exact isOpen_iUnion (fun k => isOpen_iUnion (fun _ => positive_isScottOpen k))
  · exact isOpen_iUnion (fun k => isOpen_iUnion (fun _ => positive_isScottOpen k))

theorem goodCode_iff_implications (B : ℕ → Set X) (a : Cantor) :
    GoodCode B a ↔ ∀ t, a ∈ antecedent B t → a ∈ consequent B t := by
  classical
  constructor
  · intro ha t
    rcases t with _ | (⟨i, j⟩ | (⟨i, F⟩ | i))
    · intro _
      obtain ⟨i, hi⟩ := ha.1
      exact mem_iUnion.mpr ⟨i, hi⟩
    · rintro ⟨hi, hj⟩
      obtain ⟨k, hk, hki⟩ := ha.2.1 i j hi hj
      exact mem_iUnion₂.mpr ⟨k, hki, hk⟩
    · dsimp [antecedent]
      split_ifs with hcover
      · intro hi
        obtain ⟨j, hj, haj⟩ := ha.2.2.1 i F hcover hi
        exact mem_iUnion₂.mpr ⟨j, hj, haj⟩
      · exact False.elim
    · intro hi
      obtain ⟨k, hk, hround⟩ := ha.2.2.2 i hi
      exact mem_iUnion₂.mpr ⟨k, hround, hk⟩
  · intro ha
    refine ⟨?_, ?_, ?_, ?_⟩
    · have h := ha (.inl ()) (mem_univ a)
      change a ∈ ⋃ i : ℕ, positive i at h
      obtain ⟨i, hi⟩ := mem_iUnion.mp h
      exact ⟨i, hi⟩
    · intro i j hi hj
      obtain ⟨k, hki, hk⟩ := mem_iUnion₂.mp (ha (.inr (.inl (i, j))) ⟨hi, hj⟩)
      exact ⟨k, hk, hki⟩
    · intro i F hcover hi
      have hai : a ∈ antecedent B (.inr (.inr (.inl (i, F)))) := by
        simpa only [antecedent, if_pos hcover] using hi
      obtain ⟨j, hj, haj⟩ := mem_iUnion₂.mp (ha (.inr (.inr (.inl (i, F)))) hai)
      exact ⟨j, hj, haj⟩
    · intro i hi
      obtain ⟨k, hround, hk⟩ := mem_iUnion₂.mp (ha (.inr (.inr (.inr i))) hi)
      exact ⟨k, hk, hround⟩

/-- Exact Pi2 representation of the whole code image by Scott-open
implications. The index type is countable; no empty-code exception is omitted. -/
theorem range_code_pi2 [QuasiSober X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (range B)) (hX : IsLocallyCompact X) :
    range (code B) = ⋂ t : ConditionIndex, (antecedent B t)ᶜ ∪ consequent B t := by
  rw [range_code_eq_good B hB hX]
  ext a
  simp only [mem_setOf_eq, mem_iInter, mem_union, mem_compl_iff]
  rw [goodCode_iff_implications]
  exact forall_congr' (fun _ => imp_iff_not_or)

/-- The printed countable intersection, literally indexed by Nat. -/
theorem range_code_pi2_nat [QuasiSober X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (range B)) (hX : IsLocallyCompact X) :
    ∃ U V : ℕ → Set Cantor,
      (∀ n, IsOpen[scottTopology Cantor] (U n)) ∧
      (∀ n, IsOpen[scottTopology Cantor] (V n)) ∧
      range (code B) = ⋂ n : ℕ, (U n)ᶜ ∪ V n := by
  classical
  obtain ⟨enum, henum⟩ := (Set.to_countable (univ : Set ConditionIndex)).exists_eq_range
    (show (univ : Set ConditionIndex).Nonempty from ⟨Sum.inl (), mem_univ _⟩)
  refine ⟨fun n => antecedent B (enum n), fun n => consequent B (enum n),
    fun n => antecedent_scottOpen B (enum n), fun n => consequent_scottOpen B (enum n), ?_⟩
  rw [range_code_pi2 B hB hX]
  ext a
  simp only [mem_iInter]
  constructor
  · intro h n
    exact h (enum n)
  · intro h t
    have ht : t ∈ range enum := henum ▸ mem_univ t
    obtain ⟨n, rfl⟩ := ht
    exact h n

theorem range_code_measurable [QuasiSober X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (range B)) (hX : IsLocallyCompact X) :
    @MeasurableSet Cantor (borel Cantor) (range (code B)) := by
  letI : MeasurableSpace Cantor := borel Cantor
  letI : BorelSpace Cantor := ⟨rfl⟩
  rw [range_code_pi2 B hB hX]
  exact MeasurableSet.iInter (fun t =>
    (scottOpen_isCantorOpen _ (antecedent_scottOpen B t)).measurableSet.compl.union
      (scottOpen_isCantorOpen _ (consequent_scottOpen B t)).measurableSet)

theorem code_scott_open_preimage (B : ℕ → Set X) (hB : IsTopologicalBasis (range B))
    (U : Set X) (hU : IsOpen U) :
    ∃ V : Set Cantor, IsOpen[scottTopology Cantor] V ∧ code B ⁻¹' V = U := by
  letI : TopologicalSpace Cantor := scottTopology Cantor
  let V : Set Cantor := ⋃ n : ℕ, ⋃ (_ : B n ⊆ U), positive n
  refine ⟨V, isOpen_iUnion (fun n => isOpen_iUnion (fun _ => positive_isScottOpen n)), ?_⟩
  ext x
  simp only [V, mem_preimage, mem_iUnion, positive, mem_setOf_eq, exists_prop]
  constructor
  · rintro ⟨n, hBnU, hxn⟩
    exact hBnU ((code_apply_eq_true B x n).mp hxn)
  · intro hxU
    obtain ⟨_, ⟨n, rfl⟩, hxBn, hn⟩ := hB.exists_subset_of_mem_open hxU hU
    exact ⟨n, hn, (code_apply_eq_true B x n).mpr hxBn⟩

theorem code_isEmbedding [T0Space X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (range B)) :
    @Topology.IsEmbedding X Cantor ‹TopologicalSpace X› (scottTopology Cantor) (code B) := by
  letI : TopologicalSpace Cantor := scottTopology Cantor
  refine ⟨⟨?_⟩, (basisEmbedding B hB).injective⟩
  apply TopologicalSpace.ext
  funext U
  apply propext
  constructor
  · intro hU
    obtain ⟨V, hV, hVU⟩ := code_scott_open_preimage B hB U hU
    exact isOpen_induced_iff.mpr ⟨V, hV, hVU⟩
  · intro hU
    obtain ⟨V, hV, rfl⟩ := isOpen_induced_iff.mp hU
    exact (code_scottContinuous B (fun n => hB.isOpen (mem_range_self n))).isOpen_preimage V hV

/-- Source eq:borel-coding for an arbitrary given enumerated basis. -/
theorem source_borel_coding [T0Space X] [QuasiSober X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (range B)) (hX : IsLocallyCompact X) :
    @Topology.IsEmbedding X Cantor ‹TopologicalSpace X› (scottTopology Cantor) (code B) ∧
    @MeasurableSet Cantor (borel Cantor) (range (code B)) ∧
    (∀ U : Set X, IsOpen U → ∃ V : Set Cantor, IsOpen V ∧ code B ⁻¹' V = U) :=
  ⟨code_isEmbedding B hB, range_code_measurable B hB hX, code_open_preimage B hB⟩

end WholeSpaceBorel
end ScottSpectraSimplifiedLong
