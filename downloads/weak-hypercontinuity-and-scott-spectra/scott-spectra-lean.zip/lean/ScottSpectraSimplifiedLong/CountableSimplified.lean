import ScottSpectraSimplifiedLong.WholeSpaceBorelCoding
import ScottSpectraReviewed.CountableCoding

/-! The simplified manuscript's countable-space proof. The code image is all
of X, and S is exactly the countable union of principal ideals of b_n. The
ambient Borel relation, analytic rank and ordinal/fusion contradiction reuse
the existing actual proof APIs with G=univ; no Borel-core subset is selected. -/

noncomputable section
open Set TopologicalSpace Ordinal Order
open scoped Topology Cardinal
universe u

namespace ScottSpectraSimplifiedLong

open ScottSpectraReviewed ScottSpectraReviewed.Countable

variable {X : Type u} [TopologicalSpace X] [T0Space X] [QuasiSober X]
local instance countableSpecializationOrder : PartialOrder X := specializationOrder X

theorem scottClosed_isClosed [SecondCountableTopology X] (hX : IsLocallyCompact X)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (B : Set X) (hB : IsClosed[scottTopology X] B) : IsClosed B := by
  classical
  apply isClosed_of_closure_subset
  intro x hxClosure
  by_contra hxB
  letI : Nonempty X := ⟨x⟩
  obtain ⟨basis, hBasis, _⟩ := BorelCore.exists_nat_open_basis X
  let e : X ↪o BorelCore.Cantor := BorelCore.basisEmbedding basis hBasis
  let G : Set X := univ
  have hG : @MeasurableSet BorelCore.Cantor (borel BorelCore.Cantor) (e '' G) := by
    change @MeasurableSet BorelCore.Cantor (borel BorelCore.Cantor)
      (BorelCore.code basis '' univ)
    rw [image_univ]
    exact WholeSpaceBorel.range_code_measurable basis hBasis hX
  have hopen : ∀ U : Set X, IsOpen U →
      ∃ O : Set BorelCore.Cantor, IsOpen O ∧ e ⁻¹' O = U :=
    BorelCore.code_open_preimage basis hBasis
  have hGcore : ∀ (y : X) (U : Set X), IsOpen U → y ∈ U →
      ∃ g ∈ G, g ∈ U ∧ g ≤ y := by
    intro y U _ hyU
    exact ⟨y, mem_univ y, hyU, le_rfl⟩
  obtain ⟨V, hV, hVanti, hVbasis⟩ := exists_decreasing_open_localBasis x
  have hchoices : ∀ n : ℕ, ∃ b : X, b ∈ V n ∧ b ∈ B := by
    intro n
    exact mem_closure_iff.mp hxClosure (V n) (hV n).1 (hV n).2
  choose b hbV hbB using hchoices
  choose O hO hpreimage using (fun n => hopen (V n) (hV n).1)
  let S : Set X := sequenceLowerSet b
  have hSlower : IsLowerSet S := sequenceLowerSet_isLowerSet b
  have hlevelClosure : ∀ n : ℕ, x ∈ closure (level G S V n) := by
    intro n
    apply mem_closure_iff.mpr
    intro U hU hxU
    obtain ⟨k, hk⟩ := hVbasis (U ∩ V n) (hU.inter (hV n).1) ⟨hxU, (hV n).2⟩
    let m : ℕ := max n k
    have hVm : V m ⊆ U ∩ V n := (hVanti (le_max_right n k)).trans hk
    have hbmS : b m ∈ S := by
      apply mem_iUnion.mpr
      refine ⟨m, ?_⟩
      change b m ≤ b m
      exact le_rfl
    exact ⟨b m, (hVm (hbV m)).1,
      ⟨⟨mem_univ _, hbmS⟩, (hVm (hbV m)).2⟩⟩
  let C : ℕ → Set BorelCore.Cantor := codedLevel e G b O
  have hCimage : ∀ n, C n = e '' level G S V n :=
    fun n => codedLevel_eq_image e G b O V hpreimage n
  have hCmeas : ∀ n,
      @MeasurableSet BorelCore.Cantor (borel BorelCore.Cantor) (C n) :=
    fun n => codedLevel_measurable e G b O hG hO n
  have hd : IsDSpace X := sober_isDSpace
  have hwf : WellFounded (codedRelation C) := codedRelation_wellFounded hd.1 e B hB x hxB
    V (fun n => (hV n).1) hVanti hVbasis G b hbB C hCimage
  letI : PolishSpace RankCarrier := rankCarrier_polishSpace
  obtain ⟨γbound, hγbound, hrankBound⟩ := AnalyticRank.source_borel_rank_bounded
    (codedRelation C) (codedRelation_measurable C hCmeas) hwf
  let r : ℕ → X → Ordinal := fun n a => (hwf.apply (n, e a)).rank
  apply rank_fusion_impossible (locallyCompact_isCoreCompact hX) hη x G S hSlower
    V (fun n => (hV n).1) (fun n => (hV n).2) hVanti hlevelClosure hGcore
    r γbound hγbound (fun n a => hrankBound (n, e a))
  intro n a b' ha hb' hab'
  have hrel : codedRelation C (n + 1, e b') (n, e a) := by
    refine ⟨rfl, ?_, ?_, e.monotone hab'⟩
    · rw [hCimage n]
      exact ⟨a, ha, rfl⟩
    · rw [hCimage (n + 1)]
      exact ⟨b', hb', rfl⟩
  exact Acc.rank_lt_of_rel (hwf.apply (n, e a)) hrel

/-- Source thm:countable: countably based locally compact sober X, with the
literal eta map continuous into the full Scott topology on all closed sets. -/
theorem source_countable [SecondCountableTopology X] (hX : IsLocallyCompact X)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta) :
    ‹TopologicalSpace X› = scottTopology X := by
  apply TopologicalSpace.ext_isClosed
  intro B
  constructor
  · intro hB
    have hopen : IsOpen[scottTopology X] Bᶜ := (sober_isDSpace (X := X)).2 Bᶜ hB.isOpen_compl
    exact @IsClosed.mk X (scottTopology X) B hopen
  · exact scottClosed_isClosed hX hη B

end ScottSpectraSimplifiedLong
