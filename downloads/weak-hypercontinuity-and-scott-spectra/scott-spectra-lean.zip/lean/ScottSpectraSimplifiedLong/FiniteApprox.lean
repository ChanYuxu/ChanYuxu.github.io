import ScottSpectraReviewed.HostCommonNet

/-! Source Lemma finite-approx. Unlike the old common-net proof, this file
constructs finite products of self-approximation filters and takes finite meets.
It does not use the old commonRelation or commonNet theorems. The generic
ClosureNet neighborhood realizer is reused only to expose a genuine net. -/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
namespace Host
open HostCarrier
variable {L : Type u} [CompleteLattice L]

/-- Source squeeze/unique-cluster step for arbitrary nontrivial filters. -/
theorem join_converges_of_upper_join {P : Type u} [Lattice P]
    [TopologicalSpace P] [CompactSpace P] [OrderClosedTopology P]
    {ι : Type u} {F : Filter ι} {a : ι → P} {u s : P}
    (ha : Tendsto a F (𝓝 u))
    (hupper : Tendsto (fun i => (u ⊔ s) ⊔ a i) F (𝓝 (u ⊔ s))) :
    Tendsto (fun i => a i ⊔ s) F (𝓝 (u ⊔ s)) := by
  apply tendsto_nhds_of_unique_mapClusterPt
  intro y hy
  let G : Filter ι := comap (fun i => a i ⊔ s) (𝓝 y) ⊓ F
  haveI : NeBot G := neBot_inf_comap_iff_map'.mpr hy
  have hm : Tendsto (fun i => a i ⊔ s) G (𝓝 y) :=
    map_le_iff_le_comap.mpr inf_le_left
  have hau : Tendsto a G (𝓝 u) := ha.mono_left inf_le_right
  have htop : Tendsto (fun i => (u ⊔ s) ⊔ a i) G (𝓝 (u ⊔ s)) :=
    hupper.mono_left inf_le_right
  have huy : u ≤ y := le_of_tendsto_of_tendsto hau hm
    (Eventually.of_forall fun _ => le_sup_left)
  have hsy : s ≤ y := le_of_tendsto_of_tendsto tendsto_const_nhds hm
    (Eventually.of_forall fun _ => le_sup_right)
  have hyw : y ≤ u ⊔ s := le_of_tendsto_of_tendsto hm htop
    (Eventually.of_forall fun _ =>
      sup_le le_sup_right (le_sup_of_le_left le_sup_right))
  exact le_antisymm hyw (sup_le huy hsy)

/-- The finite product/meet construction, before the last unique-cluster step. -/
theorem finite_upper_filter (hL : HostSectionContext L) (u : HostCarrier L)
    (S : Finset (HostCarrier L)) :
    letI := completeLattice hL
    ∃ F : Filter L, NeBot F ∧
      Tendsto (translation (L := L)) F
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
      ∀ s ∈ S, Tendsto (fun a : L => (u ⊔ s) ⊔ translation a) F
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) (u ⊔ s)) := by
  classical
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : CompactSpace (HostCarrier L) := lawson_compactSpace
  letI : OrderClosedTopology (HostCarrier L) := lawson_orderClosed (isContinuousLattice hL)
  letI : ContinuousInf (HostCarrier L) :=
    ⟨continuousLattice_lawson_inf (isContinuousLattice hL)⟩
  induction S using Finset.induction_on with
  | empty =>
      let F : Filter L := map (selfApproxNet hL u) atTop
      exact ⟨F, inferInstance,
        tendsto_map'_iff.mpr (selfApproxNet_tendsto hL u).1, by simp⟩
  | @insert s S hs ih =>
      obtain ⟨F, hF, hf, hold⟩ := ih
      letI : NeBot F := hF
      let w : HostCarrier L := u ⊔ s
      let G : Filter L := map (selfApproxNet hL w) atTop
      haveI : NeBot G := inferInstance
      have hg : Tendsto (translation (L := L)) G (𝓝 w) :=
        tendsto_map'_iff.mpr (selfApproxNet_tendsto hL w).1
      have hgj : Tendsto (fun b : L => w ⊔ translation b) G (𝓝 w) := by
        apply tendsto_map'_iff.mpr
        have hh := (selfApproxNet_tendsto hL w).2
        have heq : (fun i => w ⊔ translation (selfApproxNet hL w i)) =
            (fun i => composeTranslation (selfApproxNet hL w i) w) := by
          funext i
          exact (sup_comm _ _).trans (generator_join hL _ w)
        change Tendsto (fun i => w ⊔ translation (selfApproxNet hL w i)) atTop (𝓝 w)
        rwa [heq]
      let H : Filter L := map (fun z : L × L => z.1 ⊓ z.2) (F ×ˢ G)
      haveI : NeBot H := inferInstance
      have hmeet : Tendsto (fun z : L × L => translation (z.1 ⊓ z.2))
          (F ×ˢ G) (𝓝 u) := by
        have hh := (hf.comp tendsto_fst).inf_nhds (hg.comp tendsto_snd)
        have heq : (fun z : L × L => translation (z.1 ⊓ z.2)) =
            (fun z => translation z.1 ⊓ translation z.2) := by
          funext z
          exact translation_inf hL z.1 z.2
        rw [heq]
        simpa only [w, inf_sup_self] using hh
      refine ⟨H, inferInstance, tendsto_map'_iff.mpr hmeet, ?_⟩
      intro t ht
      apply tendsto_map'_iff.mpr
      rcases Finset.mem_insert.mp ht with ht | ht
      · subst t
        apply CompactOrdered.squeeze tendsto_const_nhds (hgj.comp tendsto_snd)
        · exact Eventually.of_forall fun _ => le_sup_left
        · exact Eventually.of_forall fun z =>
            sup_le_sup_left (OrderHomClass.monotone (frameHom hL) inf_le_right) w
      · apply CompactOrdered.squeeze tendsto_const_nhds ((hold t ht).comp tendsto_fst)
        · exact Eventually.of_forall fun _ => le_sup_left
        · exact Eventually.of_forall fun z =>
            sup_le_sup_left (OrderHomClass.monotone (frameHom hL) inf_le_left) (u ⊔ t)

theorem finite_approx_filter (hL : HostSectionContext L) (u : HostCarrier L)
    (S : Finset (HostCarrier L)) :
    letI := completeLattice hL
    ∃ F : Filter L, NeBot F ∧
      Tendsto (translation (L := L)) F
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
      ∀ s ∈ S, Tendsto (fun a : L => translation a ⊔ s) F
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) (u ⊔ s)) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : CompactSpace (HostCarrier L) := lawson_compactSpace
  letI : OrderClosedTopology (HostCarrier L) := lawson_orderClosed (isContinuousLattice hL)
  obtain ⟨F, hF, hf, hj⟩ := finite_upper_filter hL u S
  exact ⟨F, hF, hf, fun s hs => join_converges_of_upper_join hf (hj s hs)⟩

def finiteGraph (hL : HostSectionContext L) {m : ℕ} (s : Fin m → HostCarrier L) :
    L → HostCarrier L × (Fin m → HostCarrier L) :=
  letI := completeLattice hL
  fun a => (translation a, fun j => translation a ⊔ s j)

def finitePoint (hL : HostSectionContext L) (u : HostCarrier L) {m : ℕ}
    (s : Fin m → HostCarrier L) : HostCarrier L × (Fin m → HostCarrier L) :=
  letI := completeLattice hL
  (u, fun j => u ⊔ s j)

theorem finite_mem_closure (hL : HostSectionContext L) (u : HostCarrier L)
    {m : ℕ} (s : Fin m → HostCarrier L) :
    letI := completeLattice hL
    letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
    finitePoint hL u s ∈ closure (range (finiteGraph hL s)) := by
  classical
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  obtain ⟨F, hF, hf, hj⟩ := finite_approx_filter hL u (Finset.univ.image s)
  letI : NeBot F := hF
  have hp : Tendsto (finiteGraph hL s) F (𝓝 (finitePoint hL u s)) :=
    hf.prodMk_nhds (tendsto_pi_nhds.mpr (fun j =>
      hj (s j) (Finset.mem_image.mpr ⟨j, Finset.mem_univ j, rfl⟩)))
  exact isClosed_closure.mem_of_tendsto hp
    (Eventually.of_forall fun a => subset_closure (mem_range_self a))

abbrev FiniteApproxIndex (hL : HostSectionContext L) (u : HostCarrier L)
    {m : ℕ} (s : Fin m → HostCarrier L) :=
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  ClosureNet.Index (finitePoint hL u s)

def finiteApproxNet (hL : HostSectionContext L) (u : HostCarrier L)
    {m : ℕ} (s : Fin m → HostCarrier L) : FiniteApproxIndex hL u s → L :=
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  ClosureNet.value (finite_mem_closure hL u s)

theorem finiteApproxNet_tendsto (hL : HostSectionContext L) (u : HostCarrier L)
    {m : ℕ} (s : Fin m → HostCarrier L) :
    letI := completeLattice hL
    Tendsto (fun i => translation (finiteApproxNet hL u s i)) atTop
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
      ∀ j, Tendsto (fun i => translation (finiteApproxNet hL u s i) ⊔ s j) atTop
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) (u ⊔ s j)) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  have hp := ClosureNet.tendsto_value (finite_mem_closure hL u s)
  refine ⟨(continuous_fst.tendsto _).comp hp, ?_⟩
  intro j
  exact ((continuous_apply j).tendsto _).comp ((continuous_snd.tendsto _).comp hp)

/-- Exact printed finite-family statement, with a nonempty directed index
preorder in the source universe, including the empty family. -/
theorem source_finite_approx (hL : HostSectionContext L) (u : HostCarrier L)
    (m : ℕ) (s : Fin m → HostCarrier L) :
    letI := completeLattice hL
    ∃ (ι : Type u) (p : Preorder ι),
      letI := p
      IsDirectedOrder ι ∧ Nonempty ι ∧ ∃ a : ι → L,
        Tendsto (fun i => translation (a i)) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
        ∀ j, Tendsto (fun i => translation (a i) ⊔ s j) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) (u ⊔ s j)) := by
  letI := completeLattice hL
  exact ⟨FiniteApproxIndex hL u s, inferInstance, inferInstance, inferInstance,
    finiteApproxNet hL u s, finiteApproxNet_tendsto hL u s⟩

end Host
end ScottSpectraSimplifiedLong
