import ScottSpectraSimplifiedLong.GeneralWeb
import ScottSpectraSimplifiedLong.HostCoframe
import ScottSpectraReviewed.SpectrumWeb
import ScottSpectraReviewed.ScottNecessity

/-! Final new-source assembly. The main proof uses the new upper-patch,
whole-space Borel/countable chain and finite simultaneous approximation host.
It is not an alias of the older public main/web/countable theorem. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u
namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed

/-- New source Corollary coframe, on the actual completely-prime-filter
spectrum and its inclusion order, using the new web theorem. -/
theorem source_coframe {L : Type u} [CompleteLattice L]
    (hframe : IsFrame L) (hcont : IsContinuousLattice L) (hcoframe : IsCoframe L) :
    SpectrumIsScott L := by
  letI : TopologicalSpace (Spectrum L) := Spectrum.hullKernelTopology
  letI : T0Space (Spectrum L) := Spectrum.hullKernel_t0
  letI : QuasiSober (Spectrum L) := Spectrum.hullKernel_quasiSober
  have h := ScottSpectraSimplifiedLong.source_web
    (Spectrum.hullKernel_isLocallyCompact hframe hcont)
    (Spectrum.hullKernel_isWebSpace hframe hcont hcoframe)
  change Spectrum.hullKernelTopology (L := L) =
    @scottTopology (Spectrum L)
      (@specializationOrder (Spectrum L) Spectrum.hullKernelTopology
        Spectrum.hullKernel_t0).toPreorder at h
  rw [Spectrum.hullKernel_specializationOrder_eq] at h
  exact h

namespace Host
variable {L : Type u} [CompleteLattice L]

/-- New source embedding, with its specified literal host and translation map.
Both laws are now supplied by the new finite-approximation proof chain. -/
theorem source_embedding_literal (hL : HostSectionContext L) :
    letI := HostCarrier.completeLattice hL
    IsContinuousLattice (HostCarrier L) ∧ IsFrame (HostCarrier L) ∧
    IsCoframe (HostCarrier L) ∧ Function.Injective (HostCarrier.frameHom hL) ∧
    (∀ a b : L, WayBelow a b →
      WayBelow ((HostCarrier.frameHom hL) a) ((HostCarrier.frameHom hL) b)) ∧
    (∀ a x : L, (((HostCarrier.frameHom hL) a : HostCarrier L) : L → L) x = a ⊔ x) := by
  letI := HostCarrier.completeLattice hL
  exact ⟨HostCarrier.isContinuousLattice hL, source_framehost hL,
    source_coframehost hL, HostCarrier.translation_injective,
    fun _ _ hab => HostCarrier.translation_wayBelow hL hab, fun _ _ => rfl⟩
end Host

/-- Exact existential interface of new source Theorem embedding. -/
theorem source_embedding {L : Type u} [CompleteLattice L]
    (hcontinuous : IsContinuousLattice L) (hframe : IsFrame L)
    (hdual : DualTopologyEquality L) :
    ∃ (T : Type u) (c : CompleteLattice T),
      letI := c
      IsContinuousLattice T ∧ IsFrame T ∧ IsCoframe T ∧
      ∃ h : FrameHom L T, Function.Injective h ∧
        ∀ a b : L, WayBelow a b → WayBelow (h a) (h b) := by
  let hL : HostSectionContext L := ⟨hcontinuous, hframe, hdual⟩
  refine ⟨HostCarrier L, HostCarrier.completeLattice hL, ?_⟩
  letI := HostCarrier.completeLattice hL
  obtain ⟨hc,hf,hco,hinj,hwb,_⟩ := Host.source_embedding_literal hL
  exact ⟨hc,hf,hco,HostCarrier.frameHom hL,hinj,hwb⟩

/-- New source Theorem main: unchanged, universe-polymorphic statement with
no additional premise, proved along this source version's actual main chain. -/
theorem source_main {L : Type u} [CompleteLattice L]
    (hdistributive : IsDistributive L) (hcontinuous : IsContinuousLattice L) :
    SpectrumIsScott L ↔ DualTopologyEquality L := by
  constructor
  · exact source_ck23_necessity hdistributive hcontinuous
  · intro hdual
    have hframe : IsFrame L :=
      continuousDistributiveLattice_isFrame hcontinuous hdistributive
    let hL : HostSectionContext L := ⟨hcontinuous,hframe,hdual⟩
    letI : CompleteLattice (HostCarrier L) := HostCarrier.completeLattice hL
    obtain ⟨hc,hf,hco,hinj,hwb,_⟩ := Host.source_embedding_literal hL
    exact ScottSpectraSimplifiedLong.source_transfer hframe hf hcontinuous
      (HostCarrier.frameHom hL) hinj hwb (source_coframe hf hc hco)

theorem mainStatement_proved : MainStatement.{u} := by
  intro L _ hdistributive hcontinuous
  exact source_main hdistributive hcontinuous

end ScottSpectraSimplifiedLong
