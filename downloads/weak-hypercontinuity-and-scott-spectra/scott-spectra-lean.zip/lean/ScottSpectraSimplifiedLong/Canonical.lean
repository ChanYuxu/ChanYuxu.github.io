import ScottSpectraSimplifiedLong.UpperPatch
import ScottSpectraSimplifiedLong.WebCoframe
import ScottSpectraReviewed.CanonicalRepair

/-! New source Proposition canonical: actual closed sets and actual Scott
patch, now obtained from the general upper-patch proposition, not from an
assumed continuity of Gamma(X) or a Lawson-topology identification. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u
namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
namespace Canonical
open ClosedLattice
variable {X : Type u} [TopologicalSpace X] [T0Space X]

theorem carrier_scott_eq_upper (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    scottTopology (Carrier X) = upperTopology (Carrier X) :=
  (UpperPatch.eq_scott (isFrame_of_web hweb) (carrier_upper_locallyCompact hlocal)).symm

theorem patch_eq_upperPatch (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    canonicalPatchTopology X = upperPatchTopology (Carrier X) := by
  unfold canonicalPatchTopology upperPatchTopology
  rw [carrier_scott_eq_upper hlocal hweb]

theorem stablyCompact (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @IsStablyCompact (Carrier X) (scottTopology (Carrier X)) := by
  rw [carrier_scott_eq_upper hlocal hweb]
  exact upper_isStablyCompact (carrier_upper_locallyCompact hlocal)

theorem compactSpace (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @CompactSpace (Carrier X) (canonicalPatchTopology X) := by
  rw [patch_eq_upperPatch hlocal hweb]
  exact UpperPatch.compactSpace (Carrier X)

theorem t2Space (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @T2Space (Carrier X) (canonicalPatchTopology X) := by
  rw [patch_eq_upperPatch hlocal hweb]
  exact UpperPatch.t2Space (carrier_upper_locallyCompact hlocal)

theorem continuous_inf (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (canonicalPatchTopology X) (canonicalPatchTopology X))
      (canonicalPatchTopology X) (fun p => p.1 ⊓ p.2) := by
  rw [patch_eq_upperPatch hlocal hweb]
  exact UpperPatch.continuous_inf (isFrame_of_web hweb) (carrier_upper_locallyCompact hlocal)

theorem continuous_sup (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (canonicalPatchTopology X) (canonicalPatchTopology X))
      (canonicalPatchTopology X) (fun p => p.1 ⊔ p.2) := by
  rw [patch_eq_upperPatch hlocal hweb]
  exact UpperPatch.continuous_sup ClosedLattice.isCoframe (carrier_upper_locallyCompact hlocal)

theorem scott_continuous_inf (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (scottTopology (Carrier X)) (scottTopology (Carrier X)))
      (scottTopology (Carrier X)) (fun p => p.1 ⊓ p.2) := by
  rw [carrier_scott_eq_upper hlocal hweb]
  exact UpperPatch.upper_continuous_inf (isFrame_of_web hweb) (carrier_upper_locallyCompact hlocal)

theorem scott_continuous_sup (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (scottTopology (Carrier X)) (scottTopology (Carrier X)))
      (scottTopology (Carrier X)) (fun p => p.1 ⊔ p.2) := by
  rw [carrier_scott_eq_upper hlocal hweb]
  exact UpperPatch.upper_continuous_sup ClosedLattice.isCoframe (carrier_upper_locallyCompact hlocal)

theorem isOpen_iff_patch_upper (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (U : Set (Carrier X)) :
    IsOpen[scottTopology (Carrier X)] U ↔
      IsOpen[canonicalPatchTopology X] U ∧ IsUpperSet U := by
  rw [carrier_scott_eq_upper hlocal hweb, patch_eq_upperPatch hlocal hweb]
  exact UpperPatch.isOpen_iff_upper (carrier_upper_locallyCompact hlocal) U

theorem eta_isEmbedding (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Topology.IsEmbedding X (Carrier X) ‹TopologicalSpace X›
      (scottTopology (Carrier X)) eta := by
  rw [carrier_scott_eq_upper hlocal hweb, ← lowerVietoris_eq_upper]
  exact ClosedLattice.eta_isEmbedding

theorem opens_dualTopologyEquality (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    DualTopologyEquality (Opens X) :=
  OrderIsoTransfer.scott_eq_upper (complementOrderIso X)
    (carrier_scott_eq_upper hlocal hweb)

theorem eta_upperClosure_eq_hit (U : Opens X) :
    (upperClosure (eta '' (U : Set X)) : Set (Carrier X)) = hit U := by
  rw [← eta_saturation_hit U]
  ext C
  constructor
  · rintro ⟨_, ⟨x, hx, rfl⟩, hC⟩
    exact ⟨x, hx, hC⟩
  · rintro ⟨x, hx, hC⟩
    exact ⟨eta x, ⟨x, hx, rfl⟩, hC⟩

/-- Full source Proposition canonical, including both product-continuous
operations and the final continuous-frame/coframe/open-dual equality clause. -/
theorem source_canonical [QuasiSober X] (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    scottTopology (Carrier X) = upperTopology (Carrier X) ∧
    @IsStablyCompact (Carrier X) (scottTopology (Carrier X)) ∧
    @CompactSpace (Carrier X) (canonicalPatchTopology X) ∧
    @T2Space (Carrier X) (canonicalPatchTopology X) ∧
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (canonicalPatchTopology X) (canonicalPatchTopology X))
      (canonicalPatchTopology X) (fun p => p.1 ⊓ p.2) ∧
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (canonicalPatchTopology X) (canonicalPatchTopology X))
      (canonicalPatchTopology X) (fun p => p.1 ⊔ p.2) ∧
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (scottTopology (Carrier X)) (scottTopology (Carrier X)))
      (scottTopology (Carrier X)) (fun p => p.1 ⊓ p.2) ∧
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (scottTopology (Carrier X)) (scottTopology (Carrier X)))
      (scottTopology (Carrier X)) (fun p => p.1 ⊔ p.2) ∧
    @Topology.IsEmbedding X (Carrier X) ‹TopologicalSpace X› (scottTopology (Carrier X)) eta ∧
    (∀ x y : X, eta x ≤ eta y ↔ SpecializationLE x y) ∧
    (∀ U : Opens X, (upperClosure (eta '' (U : Set X)) : Set (Carrier X)) = hit U) ∧
    IsContinuousLattice (Opens X) ∧ IsFrame (Opens X) ∧ IsCoframe (Opens X) ∧
    DualTopologyEquality (Opens X) := by
  exact ⟨carrier_scott_eq_upper hlocal hweb, stablyCompact hlocal hweb,
    compactSpace hlocal hweb, t2Space hlocal hweb,
    continuous_inf hlocal hweb, continuous_sup hlocal hweb,
    scott_continuous_inf hlocal hweb, scott_continuous_sup hlocal hweb,
    eta_isEmbedding hlocal hweb, canonical_eta_le_eta_iff, eta_upperClosure_eq_hit,
    locallyCompact_isCoreCompact hlocal, opens_isFrame X,
    web_iff_opens_coframe.mp hweb, opens_dualTopologyEquality hlocal hweb⟩

end Canonical
end ScottSpectraSimplifiedLong
