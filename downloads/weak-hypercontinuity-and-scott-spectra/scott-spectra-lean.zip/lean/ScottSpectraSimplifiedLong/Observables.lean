import ScottSpectraSimplifiedLong.SourceReuse
import ScottSpectraReviewed.MetricLatticeQuotient
import ScottSpectraReviewed.HomAdjoints
import Mathlib.Order.Filter.CountablyGenerated
import Mathlib.Topology.UrysohnsLemma

/-! Source thm:web, simplified-long lines847--876; patch inputs adapted to the new upper-patch proof. The ambient Scott neighborhood basis at
eta(z) is proved using the actual hit/saturation identity, not inferred from
an embedding into eta(X). Actual Urysohn observables are then fed to the
proved complete metric-lattice quotient construction. Fixed-point equations
are derived from its actual left adjoint and factor functions. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u v

namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
namespace GeneralWeb

open ClosedLattice
variable {X : Type u} [TopologicalSpace X] [T0Space X]

/-- The real-valued form required by the metric-quotient lemma, with its
actual patch topology pinned explicitly. Range-in-Icc data below supplies
the genuine [0,1]-valued continuous map by unitIntervalMap. -/
abbrev PatchRealFunction (X : Type u) [TopologicalSpace X] :=
  @ContinuousMap (Carrier X) ℝ (canonicalPatchTopology X) inferInstance

def unitIntervalMap {Y : Type v} [TopologicalSpace Y]
    (f : C(Y, ℝ)) (hf : ∀ y, f y ∈ Icc (0 : ℝ) 1) : C(Y, Icc (0 : ℝ) 1) where
  toFun y := ⟨f y,hf y⟩
  continuous_toFun := f.continuous.subtype_mk _

@[simp] theorem unitIntervalMap_coe {Y : Type v} [TopologicalSpace Y]
    (f : C(Y, ℝ)) (hf : ∀ y, f y ∈ Icc (0 : ℝ) 1) (y : Y) :
    (unitIntervalMap f hf y : ℝ)=f y := rfl

/-- The genuine ambient Scott basis at the principal closure eta(z).
Every basis member is literally hit(V_n) for an actual original-open V_n.
-/
theorem exists_scott_eta_basis (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (z : X) (hz : (𝓝 z).IsCountablyGenerated) :
    ∃ V : ℕ → Opens X, (∀ n, z ∈ V n) ∧
      (∀ n, IsOpen[scottTopology (Carrier X)] (hit (V n))) ∧
      (@nhds (Carrier X) (scottTopology (Carrier X)) (eta z)).HasBasis
        (fun _ : ℕ => True) (fun n => hit (V n)) := by
  letI : (𝓝 z).IsCountablyGenerated := hz
  obtain ⟨U,hU,hbasis⟩ := (nhds_basis_opens z).exists_antitone_subbasis
  let V : ℕ → Opens X := fun n => ⟨U n,(hU n).2⟩
  letI : TopologicalSpace (Carrier X) := scottTopology (Carrier X)
  have hVo : ∀ n, IsOpen (hit (V n)) := by
    intro n
    change IsOpen[scottTopology (Carrier X)] _
    rw [Canonical.carrier_scott_eq_upper hlocal hweb]
    exact hit_isOpen_upper (V n)
  have hVm : ∀ n, hit (V n) ∈ 𝓝 (eta z) := fun n =>
    (hVo n).mem_nhds ⟨z,subset_closure (mem_singleton z),(hU n).1⟩
  refine ⟨V,fun n => (hU n).1,hVo,⟨?_⟩⟩
  intro S
  constructor
  · intro hS
    obtain ⟨O,hOS,hO,hzO⟩ := mem_nhds_iff.mp hS
    have heta : Continuous (eta : X → Carrier X) :=
      (Canonical.eta_isEmbedding hlocal hweb).continuous
    have hpre : eta ⁻¹' O ∈ 𝓝 z := (hO.preimage heta).mem_nhds hzO
    obtain ⟨n,_,hn⟩ := hbasis.1.mem_iff.mp hpre
    refine ⟨n,trivial,?_⟩
    intro C hC
    have hsat : C ∈ {D : Carrier X | ∃ x ∈ (V n : Set X), eta x ≤ D} := by
      rw [eta_saturation_hit (V n)]
      exact hC
    obtain ⟨x,hxV,hxC⟩ := hsat
    exact hOS (((isScottOpen_iff O).mp hO).1 hxC (hn hxV))
  · rintro ⟨n,_,hn⟩
    exact Filter.mem_of_superset (hVm n) hn

theorem scott_eta_isCountablyGenerated (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (z : X) (hz : (𝓝 z).IsCountablyGenerated) :
    (@nhds (Carrier X) (scottTopology (Carrier X)) (eta z)).IsCountablyGenerated := by
  obtain ⟨_,_,_,h⟩ := exists_scott_eta_basis hlocal hweb z hz
  exact h.isCountablyGenerated

/-- Actual source Urysohn family on the actual normal patch space. The
positive-support inclusion, value one, and full [0,1] range are all proved.
-/
theorem exists_observables (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (z : ℕ → X) (hz : ∀ n, (𝓝 (z n)).IsCountablyGenerated) :
    ∃ V : ℕ → ℕ → Opens X,
      (∀ n k, z n ∈ V n k) ∧
      (∀ n, (@nhds (Carrier X) (scottTopology (Carrier X)) (eta (z n))).HasBasis
        (fun _ : ℕ => True) (fun k => hit (V n k))) ∧
      ∃ F : ℕ × ℕ → PatchRealFunction X,
        (∀ i, F i (eta (z i.1))=1) ∧
        (∀ i m, F i m ∈ Icc (0 : ℝ) 1) ∧
        (∀ i, {m : Carrier X | 0 < F i m} ⊆ hit (V i.1 i.2)) := by
  choose V hVz hVo hVbasis using fun n => exists_scott_eta_basis hlocal hweb (z n) (hz n)
  letI : TopologicalSpace (Carrier X) := canonicalPatchTopology X
  letI : CompactSpace (Carrier X) := Canonical.compactSpace hlocal hweb
  letI : T2Space (Carrier X) := Canonical.t2Space hlocal hweb
  have hex : ∀ i : ℕ × ℕ, ∃ f : C(Carrier X, ℝ),
      f (eta (z i.1))=1 ∧ (∀ m, f m ∈ Icc (0 : ℝ) 1) ∧
        {m : Carrier X | 0 < f m} ⊆ hit (V i.1 i.2) := by
    intro i
    have hW : IsOpen (hit (V i.1 i.2)) :=
      ((Canonical.isOpen_iff_patch_upper hlocal hweb _).mp (hVo i.1 i.2)).1
    have htW : eta (z i.1) ∈ hit (V i.1 i.2) :=
      ⟨z i.1,subset_closure (mem_singleton _),hVz i.1 i.2⟩
    obtain ⟨f,hfzero,hfone,hfbounds⟩ := exists_continuous_zero_one_of_isClosed
      hW.isClosed_compl isClosed_singleton (by simpa using htW)
    refine ⟨f,hfone (mem_singleton _),hfbounds,?_⟩
    intro m hm
    change 0 < f m at hm
    by_contra hn
    have hzero : f m=0 := hfzero hn
    rw [hzero] at hm
    exact (lt_irrefl 0) hm
  choose F hFone hFbounds hFsupport using hex
  exact ⟨V,hVz,hVbasis,F,hFone,hFbounds,hFsupport⟩

omit [T0Space X] in
/-- The actual left adjoint fixes t because actual quotient factors force
its least section to meet a genuine ambient Scott neighborhood basis at t.
No fixed-point conclusion is included among this lemma's hypotheses. -/
theorem leftAdjoint_fixed_of_basis_observables {Q : Type v}
    [TopologicalSpace Q] [CompleteLattice Q]
    (q : CompleteLatticeHom (Carrier X) Q) (hq : Function.Surjective q)
    (t : Carrier X) (W : ℕ → Set (Carrier X))
    (hW : (@nhds (Carrier X) (scottTopology (Carrier X)) t).HasBasis
      (fun _ : ℕ => True) W)
    (F : ℕ → PatchRealFunction X) (G : ℕ → C(Q, ℝ))
    (hFone : ∀ k, F k t=1)
    (hFsupport : ∀ k, {m : Carrier X | 0 < F k m} ⊆ W k)
    (hfactor : ∀ k m, G k (q m)=F k m) :
    CompleteHom.leftAdjoint q (q t)=t := by
  apply le_antisymm (CompleteHom.leftAdjoint_q_le q t)
  by_contra hnot
  let m := CompleteHom.leftAdjoint q (q t)
  have hO : IsOpen[scottTopology (Carrier X)] (Iic m)ᶜ :=
    ((isScottClosed_iff (Iic m)).mpr ⟨isLowerSet_Iic m,dirSupClosed_Iic m⟩).isOpen_compl
  have hN : (Iic m)ᶜ ∈ @nhds (Carrier X) (scottTopology (Carrier X)) t :=
    @IsOpen.mem_nhds (Carrier X) (scottTopology (Carrier X)) t (Iic m)ᶜ hO hnot
  obtain ⟨k,_,hk⟩ := hW.mem_iff.mp hN
  have hfm : F k m=1 := by
    calc
      F k m = G k (q m) := (hfactor k m).symm
      _ = G k (q t) := by rw [CompleteHom.q_leftAdjoint q hq]
      _ = F k t := hfactor k t
      _ = 1 := hFone k
  have hmW : m ∈ W k := hFsupport k (by change 0 < F k m; rw [hfm]; exact zero_lt_one)
  exact (hk hmW) (Set.mem_Iic.mpr (le_refl m))

/-- Rich actual quotient output, retaining the source ambient hit bases,
Urysohn observables, their real factor functions, all range/value/support
specifications, and the derived left-adjoint fixed-point equations. The
complete quotient is constructed by source_metric_quotient, not assumed.
-/
theorem quotient_fixing_sequence_full (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (z : ℕ → X) (hz : ∀ n, (𝓝 (z n)).IsCountablyGenerated) :
    ∃ (Q : Type u) (tQ : TopologicalSpace Q) (lQ : CompleteLattice Q),
      letI : TopologicalSpace Q := tQ
      letI : CompleteLattice Q := lQ
      CompactSpace Q ∧ T2Space Q ∧ MetrizableSpace Q ∧ ContinuousInf Q ∧ ContinuousSup Q ∧
        ∃ q : CompleteLatticeHom (Carrier X) Q,
          Function.Surjective q ∧
          @Continuous (Carrier X) Q (canonicalPatchTopology X) tQ q ∧
          ∃ (V : ℕ → ℕ → Opens X) (F : ℕ × ℕ → PatchRealFunction X) (G : ℕ × ℕ → C(Q, ℝ)),
            (∀ n k, z n ∈ V n k) ∧
            (∀ n, (@nhds (Carrier X) (scottTopology (Carrier X)) (eta (z n))).HasBasis
              (fun _ : ℕ => True) (fun k => hit (V n k))) ∧
            (∀ i, F i (eta (z i.1))=1) ∧
            (∀ i m, F i m ∈ Icc (0 : ℝ) 1) ∧
            (∀ i, {m : Carrier X | 0 < F i m} ⊆ hit (V i.1 i.2)) ∧
            (∀ i m, G i (q m)=F i m) ∧
            (∀ i a, G i a ∈ Icc (0 : ℝ) 1) ∧
            ∀ n, CompleteHom.leftAdjoint q (q (eta (z n)))=eta (z n) := by
  obtain ⟨V,hVz,hVbasis,F,hFone,hFbounds,hFsupport⟩ := exists_observables hlocal hweb z hz
  letI : TopologicalSpace (Carrier X) := canonicalPatchTopology X
  letI : CompactSpace (Carrier X) := Canonical.compactSpace hlocal hweb
  letI : T2Space (Carrier X) := Canonical.t2Space hlocal hweb
  letI : ContinuousInf (Carrier X) := ⟨Canonical.continuous_inf hlocal hweb⟩
  letI : ContinuousSup (Carrier X) := ⟨Canonical.continuous_sup hlocal hweb⟩
  obtain ⟨Q,tQ,lQ,hcompact,ht2,hmetric,hinf,hsup,q,hq,hcont,hfactor⟩ :=
    source_metric_quotient (Set.range F) (Set.countable_range F)
  letI : TopologicalSpace Q := tQ
  letI : CompleteLattice Q := lQ
  have hGex : ∀ i : ℕ × ℕ, ∃ g : C(Q, ℝ), ∀ m : Carrier X, g (q m)=F i m :=
    fun i => hfactor (F i) ⟨i,rfl⟩
  choose G hG using hGex
  have hGbounds : ∀ i a, G i a ∈ Icc (0 : ℝ) 1 := by
    intro i a
    obtain ⟨m,rfl⟩ := hq a
    rw [hG]
    exact hFbounds i m
  have hfixed : ∀ n, CompleteHom.leftAdjoint q (q (eta (z n)))=eta (z n) := by
    intro n
    exact leftAdjoint_fixed_of_basis_observables q hq (eta (z n)) (fun k => hit (V n k))
      (hVbasis n) (fun k => F (n,k)) (fun k => G (n,k)) (fun k => hFone (n,k))
      (fun k => hFsupport (n,k)) (fun k m => hG (n,k) m)
  exact ⟨Q,tQ,lQ,hcompact,ht2,hmetric,hinf,hsup,q,hq,hcont,
    V,F,G,hVz,hVbasis,hFone,hFbounds,hFsupport,hG,hGbounds,hfixed⟩

theorem quotient_fixing_sequence (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (z : ℕ → X) (hz : ∀ n, (𝓝 (z n)).IsCountablyGenerated) :
    ∃ (Q : Type u) (tQ : TopologicalSpace Q) (lQ : CompleteLattice Q),
      letI : TopologicalSpace Q := tQ
      letI : CompleteLattice Q := lQ
      CompactSpace Q ∧ T2Space Q ∧ MetrizableSpace Q ∧ ContinuousInf Q ∧ ContinuousSup Q ∧
        ∃ q : CompleteLatticeHom (Carrier X) Q, Function.Surjective q ∧
          @Continuous (Carrier X) Q (canonicalPatchTopology X) tQ q ∧
          ∀ n, CompleteHom.leftAdjoint q (q (eta (z n)))=eta (z n) := by
  obtain ⟨Q,tQ,lQ,hrest⟩ := quotient_fixing_sequence_full hlocal hweb z hz
  letI : TopologicalSpace Q := tQ
  letI : CompleteLattice Q := lQ
  obtain ⟨hcompact,ht2,hmetric,hinf,hsup,q,hq,hcont,_,_,_,_,_,_,_,_,_,_,hfixed⟩ := hrest
  exact ⟨Q,tQ,lQ,hcompact,ht2,hmetric,hinf,hsup,q,hq,hcont,hfixed⟩

def pointSequenceEnumeration (g : X) (c : ℕ → X) : ℕ → X
  | 0 => g
  | n+1 => c n

omit [T0Space X] in
/-- Duplicates in the enumerated countable family are harmless: its actual
eta range is precisely the source set E. -/
theorem eta_pointSequenceEnumeration_range (g : X) (c : ℕ → X) :
    Set.range (fun n => eta (pointSequenceEnumeration g c n))=
      {eta g} ∪ Set.range (fun n => eta (c n)) := by
  ext t
  constructor
  · rintro ⟨n,rfl⟩
    cases n with
    | zero => exact Or.inl (mem_singleton _)
    | succ n => exact Or.inr ⟨n,rfl⟩
  · rintro (h | ⟨n,rfl⟩)
    · rcases mem_singleton_iff.mp h with rfl
      exact ⟨0,rfl⟩
    · exact ⟨n+1,rfl⟩

/-- The exact compact metric complete-lattice quotient interface for the
source's g,c_n. All topology/lattice witnesses and q are constructed above;
the fixed equations are genuine conclusions, not input certificate fields.
-/
theorem quotient_fixing_pointSequence (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (g : X) (c : ℕ → X) (hg : (𝓝 g).IsCountablyGenerated)
    (hc : ∀ n, (𝓝 (c n)).IsCountablyGenerated) :
    ∃ (Q : Type u) (tQ : TopologicalSpace Q) (lQ : CompleteLattice Q),
      letI : TopologicalSpace Q := tQ
      letI : CompleteLattice Q := lQ
      CompactSpace Q ∧ T2Space Q ∧ MetrizableSpace Q ∧ ContinuousInf Q ∧ ContinuousSup Q ∧
        ∃ q : CompleteLatticeHom (Carrier X) Q, Function.Surjective q ∧
          @Continuous (Carrier X) Q (canonicalPatchTopology X) tQ q ∧
          CompleteHom.leftAdjoint q (q (eta g))=eta g ∧
          ∀ n, CompleteHom.leftAdjoint q (q (eta (c n)))=eta (c n) := by
  have hfc : ∀ n, (𝓝 (pointSequenceEnumeration g c n)).IsCountablyGenerated := by
    intro n
    cases n with
    | zero => exact hg
    | succ n => exact hc n
  obtain ⟨Q,tQ,lQ,hrest⟩ := quotient_fixing_sequence hlocal hweb (pointSequenceEnumeration g c) hfc
  letI : TopologicalSpace Q := tQ
  letI : CompleteLattice Q := lQ
  obtain ⟨hcompact,ht2,hmetric,hinf,hsup,q,hq,hcont,hfixed⟩ := hrest
  exact ⟨Q,tQ,lQ,hcompact,ht2,hmetric,hinf,hsup,q,hq,hcont,hfixed 0,fun n => hfixed (n+1)⟩

end GeneralWeb
end ScottSpectraSimplifiedLong

