import ScottSpectraReviewed.UpperTopologySobriety
import ScottSpectraReviewed.Fusion
import ScottSpectraReviewed.WebFirstCountable
import ScottSpectraReviewed.MetricLatticeQuotient
import ScottSpectraReviewed.CompleteQuotients
import ScottSpectraReviewed.HostSelfApprox
import ScottSpectraReviewed.SpectrumTransfer
import ScottSpectraSimplifiedLong.Canonical

/-! Exact new-source interfaces for unchanged results, with explicit reuse.
All reused implementations are in the separately hash-bound reviewed package;
its old acceptance labels are not inherited by this source version. -/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u v
namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed

/-- New source Lemma upper-topology, all complete lattices. -/
theorem source_upper_topology (M : Type u) [CompleteLattice M] :
    @CompactSpace M (upperTopology M) ∧ @QuasiSober M (upperTopology M) ∧
    @T0Space M (upperTopology M) ∧ @IsCoherent M (upperTopology M) :=
  ⟨upper_compactSpace M, upper_quasiSober M, upper_t0Space M, upper_isCoherent M⟩

section Spaces
variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance : PartialOrder X := specializationOrder X

/-- New source Lemma lower-vietoris-locally-compact. -/
theorem source_lowerVietoris_locallyCompact (hX : IsLocallyCompact X) :
    @IsLocallyCompact (ClosedLattice.Carrier X) (ClosedLattice.lowerVietorisTopology X) :=
  ClosedLattice.source_lowerVietoris_locallyCompact hX

/-- New source Lemma fusion, with literal eta and arbitrary lower sets. -/
theorem source_fusion (hcore : IsCoreCompact X)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (A : ℕ → Set X) (hA : Antitone A) (hlower : ∀ n, IsLowerSet (A n)) :
    closure (⋂ n, A n) = ⋂ n, closure (A n) :=
  ScottSpectraReviewed.source_fusion hcore hη A hA hlower

/-- Lower relation continuity supplied by the NEW canonical/upper-patch chain. -/
theorem lowerRelation_isOpen (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (U : Set X) (hU : IsOpen U) :
    IsOpen {p : X × X | ∃ c ∈ U, SpecializationLE c p.1 ∧ SpecializationLE c p.2} := by
  letI : TopologicalSpace (ClosedLattice.Carrier X) := scottTopology (ClosedLattice.Carrier X)
  have heta : Continuous (ClosedLattice.eta : X → ClosedLattice.Carrier X) :=
    (Canonical.eta_isEmbedding hlocal hweb).continuous
  have hE := (heta.comp continuous_fst).prodMk (heta.comp continuous_snd)
  have hF : Continuous (fun p : X × X => ClosedLattice.eta p.1 ⊓ ClosedLattice.eta p.2) :=
    (Canonical.scott_continuous_inf hlocal hweb).comp hE
  have hhit : IsOpen (ClosedLattice.hit (⟨U,hU⟩ : Opens X)) := by
    change IsOpen[scottTopology (ClosedLattice.Carrier X)] _
    rw [Canonical.carrier_scott_eq_upper hlocal hweb]
    exact ClosedLattice.hit_isOpen_upper ⟨U,hU⟩
  have hh := hhit.preimage hF
  have heq : (fun p : X × X => ClosedLattice.eta p.1 ⊓ ClosedLattice.eta p.2) ⁻¹'
      ClosedLattice.hit (⟨U,hU⟩ : Opens X) =
      {p : X × X | ∃ c ∈ U, SpecializationLE c p.1 ∧ SpecializationLE c p.2} := by
    ext p
    constructor
    · rintro ⟨c, ⟨hca, hcb⟩, hcU⟩
      exact ⟨c, hcU, hca, hcb⟩
    · rintro ⟨c, hcU, hca, hcb⟩
      exact ⟨c, ⟨hca, hcb⟩, hcU⟩
  rwa [heq] at hh

/-- Full new source Lemma fc-core. The neighborhood recursion is reused,
but the input lower relation is proved by the new source's canonical chain. -/
theorem source_fc_core [QuasiSober X] (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    (∀ (x : X) (U : ℕ → Set X), (∀ n, U n ∈ 𝓝 x) →
      ∃ m : X, m ≤ x ∧ (∀ n, m ∈ U n) ∧ (𝓝 m).IsCountablyGenerated) ∧
    ∀ x : X, NonemptyDirected (FirstCountableCore.firstCountableBelow x) ∧
      IsLUB (FirstCountableCore.firstCountableBelow x) x := by
  apply FirstCountableCore.of_lowerRelation hlocal
  intro U hU
  have h := lowerRelation_isOpen hlocal hweb U hU
  convert h using 1
  ext p
  change (∃ z ∈ U, p.1 ⤳ z ∧ p.2 ⤳ z) ↔
    (∃ z ∈ U, SpecializationLE z p.1 ∧ SpecializationLE z p.2)
  simp only [specializationLE_iff]
end Spaces

/-- New source Lemma metric-quotient: same literal countable evaluation image
and partition-of-unity congruence proof as the reviewed package. -/
theorem source_metric_quotient {M : Type u} [TopologicalSpace M] [CompleteLattice M]
    [CompactSpace M] [T2Space M] [ContinuousInf M] [ContinuousSup M]
    (F₀ : Set C(M, ℝ)) (hF : F₀.Countable) :
    ∃ (Q : Type u) (tQ : TopologicalSpace Q) (lQ : CompleteLattice Q),
      letI : TopologicalSpace Q := tQ
      letI : CompleteLattice Q := lQ
      CompactSpace Q ∧ T2Space Q ∧ MetrizableSpace Q ∧ ContinuousInf Q ∧ ContinuousSup Q ∧
        ∃ q : CompleteLatticeHom M Q, Function.Surjective q ∧ Continuous q ∧
          ∀ f ∈ F₀, ∃ g : C(Q, ℝ), ∀ a : M, g (q a) = f a :=
  ScottSpectraReviewed.source_metric_quotient F₀ hF

/-- New source Lemma quotient; target continuity is concluded, not assumed. -/
theorem source_quotient {A : Type u} {B : Type v} [CompleteLattice A] [CompleteLattice B]
    (hA : IsFrame A) (hcont : IsContinuousLattice A) (hdual : DualTopologyEquality A)
    (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    IsFrame B ∧ IsContinuousLattice B ∧ DualTopologyEquality B :=
  ScottSpectraReviewed.source_quotient hA hcont hdual q hq

namespace Host
open HostCarrier
variable {L : Type u} [CompleteLattice L]

/-- New source Lemma hostbase: the literal product-Lawson translation closure. -/
theorem source_hostbase (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsContinuousLattice (HostCarrier L) ∧
    (∀ S : Set (HostCarrier L),
      ((sInf S : HostCarrier L) : L → L) = sInf (Subtype.val '' S)) ∧
    (∀ D : Set (HostCarrier L), NonemptyDirected D →
      ((sSup D : HostCarrier L) : L → L) = sSup (Subtype.val '' D)) ∧
    lawsonTopology (HostCarrier L) = (inferInstance : TopologicalSpace (HostCarrier L)) ∧
    Function.Injective (translation (L := L)) ∧
    (∀ S : Set L, translation (sSup S) = sSup (translation '' S)) ∧
    (∀ a b : L, translation (a ⊓ b) = translation a ⊓ translation b) ∧
    translation (⊤ : L) = ⊤ ∧
    (∀ a b : L, WayBelow a b → WayBelow (translation a) (translation b)) :=
  HostCarrier.source_hostbase hL

/-- New source Lemma escape, retaining positive indexing and both exclusions. -/
theorem source_escape (hL : HostSectionContext L) (r : L) (d : ℕ → L)
    (hpair : ∀ n m : ℕ, 1 ≤ n → 1 ≤ m → n ≠ m → r ≤ d n ⊔ d m) :
    IsClosed[lawsonTopology L] (escapeUpper r d) ∧
    ¬∃ (Wstar : Set L) (W : ℕ → Set L),
      IsOpen[lawsonTopology L] Wstar ∧
      (∀ n : ℕ, 1 ≤ n → IsOpen[lawsonTopology L] (W n)) ∧
      (∀ n : ℕ, 1 ≤ n → d n ∈ Wstar ∧
        ∀ i : ℕ, 1 ≤ i → i < n → d n ∈ W i) ∧
      (@closure L (lawsonTopology L) Wstar ∩ Ici r = ∅) ∧
      (∀ n : ℕ, 1 ≤ n → @closure L (lawsonTopology L) (W n) ∩ Ici (d n) = ∅) :=
  HostCarrier.source_escape hL r d hpair

/-- New source Lemma diagonal, continuity only at the indicated point. -/
theorem source_diagonal (hL : HostSectionContext L) (b : L) :
    @ContinuousAt L L (lawsonTopology L) (lawsonTopology L) (fun a => b ⊔ a) b :=
  HostCarrier.source_diagonal hL b

/-- New source Lemma nuclei, including the specified generator-join formula. -/
theorem source_nuclei (hL : HostSectionContext L) :
    letI := completeLattice hL
    (∀ t : HostCarrier L, ∃ n : Nucleus L, (n : L → L) = (t : L → L)) ∧
    (∀ (a : L) (t : HostCarrier L), translation a ⊔ t = composeTranslation a t) ∧
    (∀ (a : L) (S : Set (HostCarrier L)),
      translation a ⊔ sInf S = sInf ((fun t : HostCarrier L => translation a ⊔ t) '' S)) :=
  HostCarrier.source_nuclei hL

/-- New source Lemma selfapprox, with an actual nonempty directed net. -/
theorem source_selfapprox (hL : HostSectionContext L) (t : HostCarrier L) :
    letI := completeLattice hL
    ∃ (ι : Type u) (p : Preorder ι),
      letI := p
      IsDirectedOrder ι ∧ Nonempty ι ∧
      ∃ a : ι → L,
        Tendsto (fun i => translation (a i)) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) t) ∧
        Tendsto (fun i => composeTranslation (a i) t) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) t) :=
  HostCarrier.source_selfapprox hL t
end Host

/-- Operative cited filter-separation equation, on any frame, not only a
continuous one. The concrete maximal Scott-open-filter proof is reused. -/
theorem filter_separation {A : Type u} [CompleteLattice A] (hA : IsFrame A)
    (H : Order.PFilter A) (hH : IsOpen[scottTopology A] (H : Set A))
    (v : A) (hv : v ∉ H) :
    ∃ G : Spectrum A, (H : Set A) ⊆ G ∧ v ∉ G :=
  ScottSpectraReviewed.source_separation hA H hH v hv

/-- New source Theorem transfer: no continuity of the target frame is added. -/
theorem source_transfer {L : Type u} {A : Type v} [CompleteLattice L] [CompleteLattice A]
    (hL : IsFrame L) (hA : IsFrame A)
    (hcont : IsContinuousLattice L) (e : FrameHom L A) (he : Function.Injective e)
    (hWB : ∀ a b, WayBelow a b → WayBelow (e a) (e b))
    (hASpec : SpectrumIsScott A) : SpectrumIsScott L :=
  ScottSpectraReviewed.source_transfer hL hA hcont e he hWB hASpec

end ScottSpectraSimplifiedLong
