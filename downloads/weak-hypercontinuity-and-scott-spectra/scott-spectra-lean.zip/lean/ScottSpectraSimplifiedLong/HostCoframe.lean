import ScottSpectraSimplifiedLong.HostFrame

/-! New source Proposition coframehost, lines1303--1386. The triangle recursion
is adapted from the previously proved HostCoframe.lean, using the new lemma's
singleton finite-target nets at both choices. No universal common net is used.
All witnesses remain functions in the literal product-Lawson translation host. -/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
namespace Host
open HostCarrier
variable {L : Type u} [CompleteLattice L]

abbrev SingleNetIndex (hL : HostSectionContext L) (u v : HostCarrier L) :=
  FiniteApproxIndex hL u (fun _ : Fin 1 => v)

def singleNet (hL : HostSectionContext L) (u v : HostCarrier L) :
    SingleNetIndex hL u v → L :=
  finiteApproxNet hL u (fun _ : Fin 1 => v)

theorem singleNet_tendsto (hL : HostSectionContext L) (u v : HostCarrier L) :
    letI := completeLattice hL
    Tendsto (fun i => translation (singleNet hL u v i)) atTop
      (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
    Tendsto (fun i => translation (singleNet hL u v i) ⊔ v) atTop
      (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) (u ⊔ v)) := by
  letI := completeLattice hL
  have h := finiteApproxNet_tendsto hL u (fun _ : Fin 1 => v)
  exact ⟨h.1, h.2 0⟩

theorem singleNet_translation_coordinate_tendsto (hL : HostSectionContext L)
    (u v : HostCarrier L) (x : L) :
    Tendsto (fun i : SingleNetIndex hL u v => singleNet hL u v i ⊔ x) atTop
      (@nhds L (lawsonTopology L) ((u : L → L) x)) := by
  letI := completeLattice hL
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  exact ((continuous_lawson_evaluation hL x).tendsto u).comp (singleNet_tendsto hL u v).1

theorem singleNet_join_coordinate_tendsto (hL : HostSectionContext L)
    (u v : HostCarrier L) (x : L) :
    letI := completeLattice hL
    Tendsto (fun i : SingleNetIndex hL u v => (v : L → L) (singleNet hL u v i ⊔ x)) atTop
      (@nhds L (lawsonTopology L) (((u ⊔ v : HostCarrier L) : L → L) x)) := by
  letI := completeLattice hL
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  have h := ((continuous_lawson_evaluation hL x).tendsto (u ⊔ v)).comp
    (singleNet_tendsto hL u v).2
  have heq :
      (fun i : SingleNetIndex hL u v => ((translation (singleNet hL u v i) ⊔ v : HostCarrier L) : L → L) x) =
      (fun i => (v : L → L) (singleNet hL u v i ⊔ x)) := by
    funext i
    exact generator_join_apply hL _ v x
  change Tendsto
    (fun i : SingleNetIndex hL u v => ((translation (singleNet hL u v i) ⊔ v : HostCarrier L) : L → L) x)
    atTop (@nhds L (lawsonTopology L) (((u ⊔ v : HostCarrier L) : L → L) x)) at h
  rwa [heq] at h

/-- The source's nonempty-filtered coframe law, before finite-meet completion. -/
theorem filtered_coframe (hL : HostSectionContext L) (u : HostCarrier L)
    (D : Set (HostCarrier L)) (hD : NonemptyFiltered D) :
    letI := completeLattice hL
    u ⊔ sInf D = sInf ((fun d : HostCarrier L => u ⊔ d) '' D) := by
  classical
  letI := completeLattice hL
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : CompactSpace (HostCarrier L) := lawson_compactSpace
  letI : OrderClosedTopology (HostCarrier L) := lawson_orderClosed (isContinuousLattice hL)
  letI : Nonempty D := hD.1.to_subtype
  letI : IsCodirectedOrder D := hD.2.isCodirectedOrder
  apply le_antisymm
  · apply le_sInf
    rintro _ ⟨d, hd, rfl⟩
    exact sup_le_sup_left (sInf_le hd) u
  · by_contra hqp
    let v : HostCarrier L := sInf D
    let p : HostCarrier L := u ⊔ v
    let q : HostCarrier L := sInf ((fun d : HostCarrier L => u ⊔ d) '' D)
    have hqp' : ¬q ≤ p := hqp
    have hex : ∃ x : L, ¬(q : L → L) x ≤ (p : L → L) x := by
      by_contra! h
      exact hqp' h
    obtain ⟨x, hqx⟩ := hex
    let b := (p : L → L) x
    have hr : ∃ r : L, WayBelow r ((q : L → L) x) ∧ ¬r ≤ b := by
      by_contra! h
      exact hqx ((hL.1.2 ((q : L → L) x)).2.2 h)
    obtain ⟨r, hrq, hrb⟩ := hr
    have hub : (u : L → L) b = b :=
      le_antisymm (((le_sup_left : u ≤ p) b).trans_eq (idempotent hL p x))
        (inflationary hL u b)
    obtain ⟨Wstar, hWstar, hbWstar, hstar⟩ :=
      exists_open_closure_avoiding_principalUpper hL b r hrb
    have hDlim : Tendsto (fun d : D => (d : HostCarrier L)) atBot (𝓝 v) :=
      CompactOrdered.tendsto_filtered D hD (isGLB_sInf D)
    let C : ((L × L) × Set L) → L := fun z => (z.1.1 ⊔ z.1.2) ⊔ x
    let Good : ((L × L) × Set L) → Prop := fun z =>
      WayBelow r ((u : L → L) (z.1.2 ⊔ x)) ∧ (¬C z ≤ b) ∧
        IsOpen z.2 ∧ b ∈ z.2 ∧ closure z.2 ∩ Ici (C z) = ∅
    let Hist : Type u := {F : Finset ((L × L) × Set L) // ∀ z ∈ F, Good z}
    have hchoose : ∀ H : Hist, ∃ z : (L × L) × Set L, Good z ∧ C z ∈ Wstar ∧
        ∀ y ∈ H.val, C z ∈ y.2 ∧ r ≤ C y ⊔ C z := by
      intro H
      let W : Set L := Wstar ∩ ⋂ y ∈ (H.val : Set ((L × L) × Set L)), y.2
      have hWopen : IsOpen W := hWstar.inter
        (H.val.finite_toSet.isOpen_biInter fun y hy => (H.property y hy).2.2.1)
      have hbW : b ∈ W :=
        ⟨hbWstar, mem_iInter₂.mpr (fun y hy => (H.property y hy).2.2.2.1)⟩
      have hA0 := (singleNet_join_coordinate_tendsto hL u v x).eventually (hWopen.mem_nhds hbW)
      have hAold : ∀ᶠ i : SingleNetIndex hL u v in atTop,
          ∀ y ∈ H.val, WayBelow r (singleNet hL u v i ⊔ (y.1.2 ⊔ x)) :=
        (eventually_all_finset H.val).mpr (fun y hy =>
          (singleNet_translation_coordinate_tendsto hL u v (y.1.2 ⊔ x)).eventually
            ((isLawsonOpen_wayAbove hL.1 r).mem_nhds (H.property y hy).1))
      obtain ⟨ia, haW, haOld⟩ := (hA0.and hAold).exists
      let a := singleNet hL u v ia
      have hDcoord := ((continuous_lawson_evaluation hL (a ⊔ x)).tendsto v).comp hDlim
      obtain ⟨d, hdW⟩ := (hDcoord.eventually (hWopen.mem_nhds haW)).exists
      have hqud : q ≤ u ⊔ (d : HostCarrier L) := sInf_le ⟨(d : HostCarrier L), d.property, rfl⟩
      have hqdu : q ≤ (d : HostCarrier L) ⊔ u := hqud.trans_eq (sup_comm u (d : HostCarrier L))
      have hrtarget : WayBelow r ((((d : HostCarrier L) ⊔ u : HostCarrier L) : L → L) x) :=
        wayBelow_mono le_rfl hrq (hqdu x)
      have hB0 := (singleNet_translation_coordinate_tendsto hL (d : HostCarrier L) u (a ⊔ x)).eventually
        (hWopen.mem_nhds hdW)
      have hB1 := (singleNet_join_coordinate_tendsto hL (d : HostCarrier L) u x).eventually
        ((isLawsonOpen_wayAbove hL.1 r).mem_nhds hrtarget)
      obtain ⟨ib, hbW0, hbr⟩ := (hB0.and hB1).exists
      let bn := singleNet hL (d : HostCarrier L) u ib
      have hcW : (a ⊔ bn) ⊔ x ∈ W := by
        rw [sup_assoc, sup_left_comm a bn x]
        exact hbW0
      have hbnc : bn ⊔ x ≤ (a ⊔ bn) ⊔ x :=
        sup_le (le_sup_of_le_left le_sup_right) le_sup_right
      have hcb : ¬(a ⊔ bn) ⊔ x ≤ b := by
        intro h
        exact hrb ((wayBelow_le hbr).trans ((monotone hL u (hbnc.trans h)).trans_eq hub))
      obtain ⟨Wnew, hWnew, hbWnew, hsep⟩ :=
        exists_open_closure_avoiding_principalUpper hL b ((a ⊔ bn) ⊔ x) hcb
      refine ⟨((a, bn), Wnew), ⟨hbr, hcb, hWnew, hbWnew, hsep⟩, hcW.1, ?_⟩
      intro y hy
      refine ⟨mem_iInter₂.mp hcW.2 y hy, (wayBelow_le (haOld y hy)).trans ?_⟩
      have hac : a ≤ (a ⊔ bn) ⊔ x := le_sup_of_le_left le_sup_left
      have hyc : y.1.2 ⊔ x ≤ C y :=
        sup_le (le_sup_of_le_left le_sup_right) le_sup_right
      exact sup_le (le_sup_of_le_right hac) (le_sup_of_le_left hyc)
    let next : Hist → (L × L) × Set L := fun H => Classical.choose (hchoose H)
    have hnext : ∀ H : Hist, Good (next H) ∧ C (next H) ∈ Wstar ∧
        ∀ y ∈ H.val, C (next H) ∈ y.2 ∧ r ≤ C y ⊔ C (next H) :=
      fun H => Classical.choose_spec (hchoose H)
    let extend : Hist → Hist := fun H =>
      ⟨insert (next H) H.val, by
        intro z hz
        rcases Finset.mem_insert.mp hz with hz | hz
        · subst z
          exact (hnext H).1
        · exact H.property z hz⟩
    let hist : ℕ → Hist := Nat.rec ⟨∅, by simp⟩ (fun _ H => extend H)
    have hOldmem : ∀ m n : ℕ, m < n → next (hist m) ∈ (hist n).val := by
      intro m n
      induction n with
      | zero => intro hmn; exact False.elim (Nat.not_lt_zero m hmn)
      | succ n ih =>
          intro hmn
          change next (hist m) ∈ insert (next (hist n)) (hist n).val
          by_cases hmn' : m < n
          · exact Finset.mem_insert_of_mem (ih hmn')
          · have hm : m = n := le_antisymm (Nat.le_of_lt_succ hmn) (Nat.le_of_not_lt hmn')
            subst m
            exact Finset.mem_insert_self _ _
    let seq : ℕ → L := fun n => C (next (hist n))
    let Wseq : ℕ → Set L := fun n => (next (hist n)).2
    have hpair : ∀ n m : ℕ, 1 ≤ n → 1 ≤ m → n ≠ m → r ≤ seq n ⊔ seq m := by
      intro n m _ _ hne
      by_cases hnm : n < m
      · exact ((hnext (hist m)).2.2 (next (hist n)) (hOldmem n m hnm)).2
      · have hmn : m < n := lt_of_le_of_ne (le_of_not_gt hnm) (Ne.symm hne)
        have h := ((hnext (hist n)).2.2 (next (hist m)) (hOldmem m n hmn)).2
        change r ≤ seq m ⊔ seq n at h
        exact h.trans_eq (sup_comm (seq m) (seq n))
    apply no_excluded_sequence hL r seq hpair Wstar Wseq hWstar
    · intro n _
      exact (hnext (hist n)).1.2.2.1
    · intro n _
      refine ⟨(hnext (hist n)).2.1, ?_⟩
      intro i _ hin
      exact ((hnext (hist n)).2.2 (next (hist i)) (hOldmem i n hin)).1
    · exact hstar
    · intro n _
      exact (hnext (hist n)).1.2.2.2.2

/-- Arbitrary meets are filtered meets of finite meets, including the empty
finite meet. This is the source's final reduction, expressed on the dual using
the already proved finite-join calculation. -/
theorem isCoframe (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsCoframe (HostCarrier L) := by
  letI := completeLattice hL
  change IsFrame (HostCarrier L)ᵒᵈ
  have hdistributive : IsDistributive (HostCarrier L)ᵒᵈ :=
    fun a b c => finite_sup_inf_distributive hL a b c
  intro a S
  calc
    a ⊓ sSup S = a ⊓ sSup (finiteJoins S) := by rw [sSup_finiteJoins]
    _ = sSup ((fun d => a ⊓ d) '' finiteJoins S) :=
      filtered_coframe hL a _ (finiteJoins_nonemptyDirected S)
    _ = sSup ((fun s => a ⊓ s) '' S) := by
      apply le_antisymm
      · apply sSup_le
        rintro _ ⟨d, ⟨F, hF, hFS, rfl⟩, rfl⟩
        change a ⊓ sSup F ≤ _
        rw [distributive_inf_sSup_finite hdistributive a F hF]
        exact sSup_le_sSup (image_mono hFS)
      · apply sSup_le
        rintro _ ⟨s, hs, rfl⟩
        exact le_sSup ⟨s,
          ⟨{s}, finite_singleton s, singleton_subset_iff.mpr hs, sSup_singleton⟩, rfl⟩

/-- Exact source Proposition `prop:coframehost` on the literal translation
closure, with precisely the three standing host hypotheses. -/
theorem source_coframehost (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsCoframe (HostCarrier L) :=
  isCoframe hL

end Host
end ScottSpectraSimplifiedLong

