import ScottSpectraSimplifiedLong.FiniteApprox
import ScottSpectraReviewed.ContinuousFrame

/-! Source Proposition framehost, using precisely three targets of the
new finite-approximation theorem, not the previous universal common net. -/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u
namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
namespace Host
open HostCarrier
variable {L : Type u} [CompleteLattice L]

theorem finite_sup_inf_distributive (hL : HostSectionContext L) (u v z : HostCarrier L) :
    letI := completeLattice hL
    u ⊔ (v ⊓ z) = (u ⊔ v) ⊓ (u ⊔ z) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : T2Space (HostCarrier L) := lawson_t2Space (isContinuousLattice hL)
  letI : ContinuousInf (HostCarrier L) :=
    ⟨continuousLattice_lawson_inf (isContinuousLattice hL)⟩
  let s : Fin 3 → HostCarrier L := ![v, z, v ⊓ z]
  have hn := finiteApproxNet_tendsto hL u s
  have hleft := hn.2 (2 : Fin 3)
  have hright := (hn.2 (0 : Fin 3)).inf_nhds (hn.2 (1 : Fin 3))
  have heq :
      (fun i : FiniteApproxIndex hL u s => translation (finiteApproxNet hL u s i) ⊔ (v ⊓ z)) =
      (fun i => (translation (finiteApproxNet hL u s i) ⊔ v) ⊓
        (translation (finiteApproxNet hL u s i) ⊔ z)) := by
    funext i
    simpa only [sInf_pair, image_pair] using
      generator_join_sInf hL (finiteApproxNet hL u s i) {v, z}
  change Tendsto
    (fun i : FiniteApproxIndex hL u s => translation (finiteApproxNet hL u s i) ⊔ (v ⊓ z))
    atTop (𝓝 (u ⊔ (v ⊓ z))) at hleft
  change Tendsto
    (fun i : FiniteApproxIndex hL u s =>
      (translation (finiteApproxNet hL u s i) ⊔ v) ⊓
        (translation (finiteApproxNet hL u s i) ⊔ z))
    atTop (𝓝 ((u ⊔ v) ⊓ (u ⊔ z))) at hright
  rw [heq] at hleft
  exact tendsto_nhds_unique hleft hright

theorem finite_isDistributive (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsDistributive (HostCarrier L) := by
  letI := completeLattice hL
  letI : DistribLattice (HostCarrier L) :=
    { (inferInstance : Lattice (HostCarrier L)) with
      le_sup_inf := fun x y z => (finite_sup_inf_distributive hL x y z).ge }
  exact fun x y z => inf_sup_left x y z

/-- Exact source Proposition framehost on the literal translation closure. -/
theorem source_framehost (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsFrame (HostCarrier L) := by
  letI := completeLattice hL
  exact continuousDistributiveLattice_isFrame
    (isContinuousLattice hL) (finite_isDistributive hL)

end Host
end ScottSpectraSimplifiedLong
