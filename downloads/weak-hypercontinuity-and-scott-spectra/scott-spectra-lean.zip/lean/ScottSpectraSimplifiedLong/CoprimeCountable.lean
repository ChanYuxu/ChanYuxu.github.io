import ScottSpectraSimplifiedLong.CountableSimplified
import ScottSpectraReviewed.GeneralWebCoprimeCountable

/-! The actual Cop(Q) subspace becomes intrinsic Scott by the NEW full-image
Borel/countable theorem, only after its literal eta continuity is proved. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u
namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed
namespace GeneralWeb
open ScottSpectraReviewed.GeneralWeb
variable (Q : Type u) [CompleteLattice Q]
local instance : TopologicalSpace (CoprimeElements Q) := CoprimeElements.hullKernelTopology
local instance : T0Space (CoprimeElements Q) := coprimeHullKernel_t0 Q
local instance : QuasiSober (CoprimeElements Q) := coprimeHullKernel_quasiSober Q

theorem coprimeHullKernel_eq_intrinsic_scott (hframe : IsFrame Qᵒᵈ)
    (hcont : IsContinuousLattice Qᵒᵈ) (heq : scottTopology Q = upperTopology Q)
    (hcount : @SecondCountableTopology Q (scottTopology Q)) :
    CoprimeElements.hullKernelTopology (Q := Q) = scottTopology (CoprimeElements Q) := by
  letI : SecondCountableTopology (CoprimeElements Q) :=
    coprimeHullKernel_secondCountable Q heq hcount
  have h := ScottSpectraSimplifiedLong.source_countable
    (coprimeHullKernel_isLocallyCompact Q hframe hcont)
    (coprime_eta_continuous Q hframe hcont heq)
  change CoprimeElements.hullKernelTopology =
    @scottTopology (CoprimeElements Q) (specializationOrder (CoprimeElements Q)).toPreorder at h
  rw [coprimeHullKernel_specializationOrder_eq Q] at h
  exact h

end GeneralWeb
end ScottSpectraSimplifiedLong
