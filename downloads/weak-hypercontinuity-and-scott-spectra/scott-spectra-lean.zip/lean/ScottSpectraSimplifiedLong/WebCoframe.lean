import ScottSpectraReviewed.SpectrumWeb

/-! The new manuscript's operative equivalence (web-coframe), for arbitrary
spaces: the actual opens lattice is a coframe exactly when the space is web.
The two elementary proofs on literal closed sets are reused through the actual
complement order isomorphism. No local compactness or sobriety is assumed. -/

noncomputable section
open TopologicalSpace
universe u

namespace ScottSpectraSimplifiedLong
open ScottSpectraReviewed

/-- Source equation web-coframe, both directions on the given space. -/
theorem web_iff_opens_coframe {X : Type u} [TopologicalSpace X] :
    IsWebSpace X ↔ IsCoframe (Opens X) := by
  constructor
  · intro hweb
    exact OrderIsoTransfer.isFrame (ClosedLattice.complementOrderIso X)
      (ClosedLattice.isFrame_of_web hweb)
  · intro hcoframe
    exact isWebSpace_of_closedLattice_frame
      (OrderIsoTransfer.isFrame (ClosedLattice.complementOrderIso X).symm hcoframe)

end ScottSpectraSimplifiedLong
