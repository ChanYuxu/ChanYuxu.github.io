import ScottSpectraReviewed.HostSelfApprox
import Mathlib.Order.Filter.Prod
import Mathlib.Order.Filter.Pi

/-! Source Lemma `lem:commonnet`, statement 1400--1407, proof 1408--1475.
The relation is the literal closure of the source's generator-join graph.
No join continuity or coframe law is assumed.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed

/- General closure realization by an actual neighborhood-directed net.
This is not a sequence or a first-countability principle. -/
namespace ClosureNet

variable {A : Type u} {X : Type v} [TopologicalSpace X]

abbrev Index (x : X) := OrderDual {U : Set X // U ∈ 𝓝 x}

instance index_nonempty (x : X) : Nonempty (Index x) := ⟨⟨univ, univ_mem⟩⟩

instance index_directed (x : X) : IsDirectedOrder (Index x) :=
  ⟨fun i j => ⟨⟨i.val ∩ j.val, inter_mem i.property j.property⟩,
    inter_subset_left, inter_subset_right⟩⟩

theorem exists_value {f : A → X} {x : X} (hx : x ∈ closure (range f))
    (U : Index x) : ∃ a : A, f a ∈ U.val := by
  have hf : ∃ᶠ y in 𝓝 x, y ∈ range f := mem_closure_iff_frequently.mp hx
  obtain ⟨_, ⟨a, rfl⟩, haU⟩ := (hf.and_eventually U.property).exists
  exact ⟨a, haU⟩

def value {f : A → X} {x : X} (hx : x ∈ closure (range f)) (U : Index x) : A :=
  Classical.choose (exists_value hx U)

theorem value_mem {f : A → X} {x : X} (hx : x ∈ closure (range f)) (U : Index x) :
    f (value hx U) ∈ U.val := Classical.choose_spec (exists_value hx U)

theorem tendsto_value {f : A → X} {x : X} (hx : x ∈ closure (range f)) :
    Tendsto (fun U : Index x => f (value hx U)) atTop (𝓝 x) := by
  apply tendsto_def.mpr
  intro U hU
  let j : Index x := ⟨U, hU⟩
  apply (eventually_ge_atTop j).mono
  intro i hji
  exact hji (value_mem hx i)

end ClosureNet

namespace HostCarrier

variable {L : Type u} [CompleteLattice L]

/-- Exactly the source's closed relation `R_w` in the square of the actual
intrinsic Lawson host. -/
def commonRelation (hL : HostSectionContext L) (w : HostCarrier L) :
    Set (HostCarrier L × HostCarrier L) :=
  letI := completeLattice hL
  @closure (HostCarrier L × HostCarrier L)
    (@instTopologicalSpaceProd (HostCarrier L) (HostCarrier L)
      (lawsonTopology (HostCarrier L)) (lawsonTopology (HostCarrier L)))
    (range (fun a : L => (translation a, w ⊔ translation a)))

theorem translation_dense (hL : HostSectionContext L) (t : HostCarrier L) :
    letI := completeLattice hL
    t ∈ @closure (HostCarrier L) (lawsonTopology (HostCarrier L))
      (range (translation (L := L))) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  exact isClosed_closure.mem_of_tendsto (selfApproxNet_tendsto hL t).1
    (Eventually.of_forall fun i => subset_closure (mem_range_self (selfApproxNet hL t i)))

theorem commonRelation_first_projection (hL : HostSectionContext L)
    (u w : HostCarrier L) : ∃ z : HostCarrier L, (u, z) ∈ commonRelation hL w := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : CompactSpace (HostCarrier L) := lawson_compactSpace
  letI : T2Space (HostCarrier L) := lawson_t2Space (isContinuousLattice hL)
  have hRcompact : IsCompact (commonRelation hL w) := isClosed_closure.isCompact
  have hImageClosed : IsClosed (Prod.fst '' commonRelation hL w) :=
    (hRcompact.image continuous_fst).isClosed
  have hrange : range (translation (L := L)) ⊆ Prod.fst '' commonRelation hL w := by
    rintro _ ⟨a, rfl⟩
    exact ⟨(translation a, w ⊔ translation a), subset_closure (mem_range_self a), rfl⟩
  obtain ⟨⟨u', z⟩, hz, hu⟩ :=
    closure_minimal hrange hImageClosed (translation_dense hL u)
  exact ⟨z, hu ▸ hz⟩

theorem commonRelation_bounds (hL : HostSectionContext L) (u w z : HostCarrier L)
    (h : (u, z) ∈ commonRelation hL w) : u ≤ z ∧ w ≤ z := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : OrderClosedTopology (HostCarrier L) := lawson_orderClosed (isContinuousLattice hL)
  constructor
  · exact closure_minimal (by
      rintro _ ⟨a, rfl⟩
      change translation a ≤ w ⊔ translation a
      exact le_sup_right)
      isClosed_le_prod h
  · exact closure_minimal (by
      rintro _ ⟨a, rfl⟩
      change w ≤ w ⊔ translation a
      exact le_sup_left)
      (isClosed_le continuous_const continuous_snd) h

theorem commonRelation_generator_inf (hL : HostSectionContext L) (w : HostCarrier L)
    (a b : L) :
    letI := completeLattice hL
    (w ⊔ translation a) ⊓ (w ⊔ translation b) = w ⊔ translation (a ⊓ b) := by
  letI := completeLattice hL
  apply Subtype.ext
  funext x
  rw [coe_inf hL]
  change ((w ⊔ translation a : HostCarrier L) : L → L) x ⊓
      ((w ⊔ translation b : HostCarrier L) : L → L) x =
    ((w ⊔ translation (a ⊓ b) : HostCarrier L) : L → L) x
  rw [sup_comm w (translation a), sup_comm w (translation b),
    sup_comm w (translation (a ⊓ b))]
  rw [generator_join_apply hL, generator_join_apply hL, generator_join_apply hL]
  have heq : (a ⊓ b) ⊔ x = (a ⊔ x) ⊓ (b ⊔ x) :=
    congrArg (fun f : L → L => f x) (joinTranslation_inf hL a b)
  exact (preserves_inf hL w (a ⊔ x) (b ⊔ x)).symm.trans
    (congrArg (fun y => (w : L → L) y) heq.symm)

theorem commonRelation_infClosed (hL : HostSectionContext L) (w : HostCarrier L) :
    letI := completeLattice hL
    InfClosed (commonRelation hL w) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : ContinuousInf (HostCarrier L) := ⟨continuousLattice_lawson_inf (isContinuousLattice hL)⟩
  intro p hp q hq
  have hcont : Continuous (fun z :
      (HostCarrier L × HostCarrier L) × (HostCarrier L × HostCarrier L) => z.1 ⊓ z.2) :=
    (continuous_fst.fst.inf continuous_snd.fst).prodMk
      (continuous_fst.snd.inf continuous_snd.snd)
  apply map_mem_closure₂ hcont hp hq
  rintro _ ⟨a, rfl⟩ _ ⟨b, rfl⟩
  refine ⟨a ⊓ b, ?_⟩
  exact Prod.ext (translation_inf hL a b)
    (commonRelation_generator_inf hL w a b).symm

theorem commonRelation_self (hL : HostSectionContext L) (w : HostCarrier L) :
    (w, w) ∈ commonRelation hL w := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  have hsecond : Tendsto
      (fun i : SelfApproxIndex w => w ⊔ translation (selfApproxNet hL w i)) atTop (𝓝 w) := by
    have h := (selfApproxNet_tendsto hL w).2
    have heq : (fun i : SelfApproxIndex w => composeTranslation (selfApproxNet hL w i) w) =
        (fun i => w ⊔ translation (selfApproxNet hL w i)) := by
      funext i
      exact (generator_join hL _ w).symm.trans (sup_comm _ _)
    rwa [heq] at h
  exact isClosed_closure.mem_of_tendsto
    ((selfApproxNet_tendsto hL w).1.prodMk_nhds hsecond)
    (Eventually.of_forall fun i => subset_closure (mem_range_self (selfApproxNet hL w i)))

theorem commonRelation_upper_target (hL : HostSectionContext L) (u w : HostCarrier L)
    (huw : u ≤ w) : (u, w) ∈ commonRelation hL w := by
  letI := completeLattice hL
  obtain ⟨z, hz⟩ := commonRelation_first_projection hL u w
  have hwz := (commonRelation_bounds hL u w z hz).2
  have h := commonRelation_infClosed hL w hz (commonRelation_self hL w)
  change (u ⊓ w, z ⊓ w) ∈ commonRelation hL w at h
  simpa only [inf_eq_left.mpr huw, inf_eq_right.mpr hwz] using h

abbrev CommonUpperTarget (u : HostCarrier L) := {w : HostCarrier L // u ≤ w}

/-- The finite product-net/meet/squeeze step of the source, in its general
nonbottom-filter form. A real arbitrary directed net is realized below. -/
theorem finite_upperTargets_filter (hL : HostSectionContext L) (u : HostCarrier L)
    (S : Finset (CommonUpperTarget u)) :
    letI := completeLattice hL
    ∃ F : Filter L, NeBot F ∧
      Tendsto (translation (L := L)) F (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
      ∀ w ∈ S, Tendsto (fun a : L => w.val ⊔ translation a) F
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) w.val) := by
  classical
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : CompactSpace (HostCarrier L) := lawson_compactSpace
  letI : OrderClosedTopology (HostCarrier L) := lawson_orderClosed (isContinuousLattice hL)
  letI : ContinuousInf (HostCarrier L) := ⟨continuousLattice_lawson_inf (isContinuousLattice hL)⟩
  induction S using Finset.induction_on with
  | empty =>
      let F : Filter L := comap (translation (L := L)) (𝓝 u)
      have hF : NeBot F := comap_neBot_iff_frequently.mpr
        (mem_closure_iff_frequently.mp (translation_dense hL u))
      exact ⟨F, hF, map_comap_le, by simp⟩
  | @insert w S hw ih =>
      obtain ⟨F, hF, hfirst, hOld⟩ := ih
      letI : NeBot F := hF
      let g : L → HostCarrier L × HostCarrier L := fun a => (translation a, w.val ⊔ translation a)
      have hclosure : (u, w.val) ∈ closure (range g) :=
        commonRelation_upper_target hL u w.val w.property
      let G : Filter L := comap g (𝓝 (u, w.val))
      haveI : NeBot G := comap_neBot_iff_frequently.mpr
        (mem_closure_iff_frequently.mp hclosure)
      have hg : Tendsto g G (𝓝 (u, w.val)) := map_comap_le
      have hgfirst : Tendsto (translation (L := L)) G (𝓝 u) :=
        (continuous_fst.tendsto (u, w.val)).comp hg
      have hgsecond : Tendsto (fun a : L => w.val ⊔ translation a) G (𝓝 w.val) :=
        (continuous_snd.tendsto (u, w.val)).comp hg
      let H : Filter L := map (fun q : L × L => q.1 ⊓ q.2) (F ×ˢ G)
      haveI : NeBot H := inferInstance
      have hmeet : Tendsto (fun q : L × L => translation (q.1 ⊓ q.2)) (F ×ˢ G) (𝓝 u) := by
        have h := (hfirst.comp tendsto_fst).inf_nhds (hgfirst.comp tendsto_snd)
        have heq : (fun q : L × L => translation (q.1 ⊓ q.2)) =
            (fun q => translation q.1 ⊓ translation q.2) := by
          funext q
          exact translation_inf hL q.1 q.2
        rw [heq]
        simpa only [inf_idem] using h
      refine ⟨H, inferInstance, tendsto_map'_iff.mpr hmeet, ?_⟩
      intro v hv
      apply tendsto_map'_iff.mpr
      rcases Finset.mem_insert.mp hv with hv | hv
      · subst v
        apply CompactOrdered.squeeze tendsto_const_nhds (hgsecond.comp tendsto_snd)
        · exact Eventually.of_forall fun _ => le_sup_left
        · exact Eventually.of_forall fun q =>
            sup_le_sup_left (OrderHomClass.monotone (frameHom hL) inf_le_right) w.val
      · apply CompactOrdered.squeeze tendsto_const_nhds ((hOld v hv).comp tendsto_fst)
        · exact Eventually.of_forall fun _ => le_sup_left
        · exact Eventually.of_forall fun q =>
            sup_le_sup_left (OrderHomClass.monotone (frameHom hL) inf_le_left) v.val

def upperTargetsGraph (hL : HostSectionContext L) (u : HostCarrier L) :
    L → HostCarrier L × (CommonUpperTarget u → HostCarrier L) :=
  letI := completeLattice hL
  fun a => (translation a, fun w => w.val ⊔ translation a)

def upperTargetsPoint (u : HostCarrier L) :
    HostCarrier L × (CommonUpperTarget u → HostCarrier L) := (u, fun w => w.val)

/-- The literal product closure statement for all upper targets, derived from
finite products and squeeze rather than any assumed join continuity. -/
theorem upperTargets_mem_closure (hL : HostSectionContext L) (u : HostCarrier L) :
    letI := completeLattice hL
    letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
    upperTargetsPoint u ∈ closure (range (upperTargetsGraph hL u)) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  apply mem_closure_iff_nhds.mpr
  intro U hU
  obtain ⟨V, hV, W, hW, hVW⟩ := mem_nhds_prod_iff.mp hU
  rw [nhds_pi] at hW
  obtain ⟨S, N, hN, hNW⟩ := Filter.mem_pi'.mp hW
  obtain ⟨F, hF, hfirst, htargets⟩ := finite_upperTargets_filter hL u S
  letI : NeBot F := hF
  have hevent : ∀ᶠ a in F, ∀ w ∈ S, w.val ⊔ translation a ∈ N w :=
    (eventually_all_finset S).mpr (fun w hw => (htargets w hw).eventually (hN w))
  obtain ⟨a, haV, haTargets⟩ := ((hfirst.eventually hV).and hevent).exists
  refine ⟨upperTargetsGraph hL u a, ?_, mem_range_self a⟩
  apply hVW
  exact ⟨haV, hNW (fun w hw => haTargets w hw)⟩

/-- A real neighborhood-directed index for the source's simultaneous closure
relation in the full product over every upper target. -/
abbrev CommonNetIndex (hL : HostSectionContext L) (u : HostCarrier L) :=
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  ClosureNet.Index (upperTargetsPoint u)

def commonNet (hL : HostSectionContext L) (u : HostCarrier L) :
    CommonNetIndex hL u → L :=
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  ClosureNet.value (upperTargets_mem_closure hL u)

theorem commonNet_upperTargets_tendsto (hL : HostSectionContext L) (u : HostCarrier L) :
    letI := completeLattice hL
    Tendsto (fun i : CommonNetIndex hL u => translation (commonNet hL u i)) atTop
      (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
    ∀ w : CommonUpperTarget u,
      Tendsto (fun i : CommonNetIndex hL u => w.val ⊔ translation (commonNet hL u i)) atTop
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) w.val) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  have h := ClosureNet.tendsto_value (upperTargets_mem_closure hL u)
  constructor
  · exact (continuous_fst.tendsto (upperTargetsPoint u)).comp h
  · intro w
    exact (((continuous_apply w).comp continuous_snd).tendsto (upperTargetsPoint u)).comp h

theorem continuous_scott_joinRight (s : L) :
    @Continuous L L (scottTopology L) (scottTopology L) (fun z => z ⊔ s) := by
  have heq : (fun z : L => z ⊔ s) = (fun z : L => s ⊔ z) := funext (fun z => sup_comm z s)
  rw [heq]
  exact continuous_scott_joinLeft s

theorem commonNet_tendsto (hL : HostSectionContext L) (u : HostCarrier L) :
    letI := completeLattice hL
    Tendsto (fun i : CommonNetIndex hL u => translation (commonNet hL u i)) atTop
      (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
    ∀ s : HostCarrier L,
      Tendsto (fun i : CommonNetIndex hL u => translation (commonNet hL u i) ⊔ s) atTop
        (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) (u ⊔ s)) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  have hupper := commonNet_upperTargets_tendsto hL u
  refine ⟨hupper.1, ?_⟩
  intro s
  let w : CommonUpperTarget u := ⟨u ⊔ s, le_sup_left⟩
  have hscottMap : @Continuous (HostCarrier L) (HostCarrier L)
      (lawsonTopology (HostCarrier L)) (scottTopology (HostCarrier L)) (fun z => z ⊔ s) :=
    continuous_le_dom
      (show lawsonTopology (HostCarrier L) ≤ scottTopology (HostCarrier L) from inf_le_right)
      (continuous_scott_joinRight s)
  have hscottAt : Tendsto (fun z : HostCarrier L => z ⊔ s) (𝓝 u)
      (@nhds (HostCarrier L) (scottTopology (HostCarrier L)) (u ⊔ s)) :=
    @Continuous.continuousAt (HostCarrier L) (HostCarrier L)
      (lawsonTopology (HostCarrier L)) (scottTopology (HostCarrier L))
      (fun z => z ⊔ s) u hscottMap
  have hscott : Tendsto (fun i : CommonNetIndex hL u => translation (commonNet hL u i) ⊔ s)
      atTop (@nhds (HostCarrier L) (scottTopology (HostCarrier L)) (u ⊔ s)) :=
    hscottAt.comp hupper.1
  have hlower : Tendsto (fun i : CommonNetIndex hL u => translation (commonNet hL u i) ⊔ s)
      atTop (@nhds (HostCarrier L) (Topology.lower (HostCarrier L)) (u ⊔ s)) := by
    apply tendsto_nhds_generateFrom_iff.mpr
    rintro _ ⟨v, rfl⟩ hv
    have hev := (hupper.2 w).eventually ((isLawsonOpen_compl_Ici v).mem_nhds hv)
    apply hev.mono
    intro i hi hvi
    apply hi
    exact hvi.trans (sup_le le_sup_right ((le_sup_right : s ≤ u ⊔ s).trans le_sup_left))
  change Tendsto (fun i : CommonNetIndex hL u => translation (commonNet hL u i) ⊔ s) atTop
    (@nhds (HostCarrier L) (Topology.lower (HostCarrier L) ⊓ scottTopology (HostCarrier L)) (u ⊔ s))
  rw [@nhds_inf (HostCarrier L) (Topology.lower (HostCarrier L)) (scottTopology (HostCarrier L)) (u ⊔ s)]
  exact tendsto_inf.mpr ⟨hlower, hscott⟩

theorem sup_inf_distributive (hL : HostSectionContext L) (u v z : HostCarrier L) :
    letI := completeLattice hL
    u ⊔ (v ⊓ z) = (u ⊔ v) ⊓ (u ⊔ z) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  letI : T2Space (HostCarrier L) := lawson_t2Space (isContinuousLattice hL)
  letI : ContinuousInf (HostCarrier L) := ⟨continuousLattice_lawson_inf (isContinuousLattice hL)⟩
  have hnet := commonNet_tendsto hL u
  have hleft := hnet.2 (v ⊓ z)
  have hright := (hnet.2 v).inf_nhds (hnet.2 z)
  have heq :
      (fun i : CommonNetIndex hL u => translation (commonNet hL u i) ⊔ (v ⊓ z)) =
      (fun i => (translation (commonNet hL u i) ⊔ v) ⊓
        (translation (commonNet hL u i) ⊔ z)) := by
    funext i
    simpa only [sInf_pair, image_pair] using
      generator_join_sInf hL (commonNet hL u i) {v, z}
  rw [heq] at hleft
  exact tendsto_nhds_unique hleft hright

theorem isDistributive (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsDistributive (HostCarrier L) := by
  letI := completeLattice hL
  letI : DistribLattice (HostCarrier L) :=
    { (inferInstance : Lattice (HostCarrier L)) with
      le_sup_inf := fun x y z => (sup_inf_distributive hL x y z).ge }
  exact fun x y z => inf_sup_left x y z

theorem isFrame (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsFrame (HostCarrier L) := by
  letI := completeLattice hL
  exact continuousDistributiveLattice_isFrame (isContinuousLattice hL) (isDistributive hL)

/-- The printed common-net existence statement and the actual frame conclusion.
The index is genuinely nonempty directed and not assumed countable. -/
theorem source_commonnet (hL : HostSectionContext L) :
    letI := completeLattice hL
    (∀ u : HostCarrier L, ∃ (ι : Type u) (p : Preorder ι),
      letI := p
      IsDirectedOrder ι ∧ Nonempty ι ∧ ∃ a : ι → L,
        Tendsto (fun i => translation (a i)) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) u) ∧
        ∀ s : HostCarrier L, Tendsto (fun i => translation (a i) ⊔ s) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) (u ⊔ s))) ∧
    IsFrame (HostCarrier L) := by
  letI := completeLattice hL
  letI : TopologicalSpace (HostCarrier L) := lawsonTopology (HostCarrier L)
  refine ⟨fun u => ?_, isFrame hL⟩
  exact ⟨CommonNetIndex hL u, inferInstance, inferInstance, inferInstance,
    commonNet hL u, commonNet_tendsto hL u⟩

end HostCarrier
end ScottSpectraReviewed
