import ScottSpectraReviewed.ClosedLatticeHyperspace
import ScottSpectraReviewed.LawsonBasics
import ScottSpectraReviewed.CompactSemilattice
import ScottSpectraReviewed.PatchProduct

/-! A separately recorded repair of source `prop:canonical`. The printed
inference that Gamma(X) is a continuous lattice is not used or overwritten:
only Gamma(X) dual is proved continuous, through actual complementation
with O(X). Its Lawson topology is proved equal to the actual patch topology
of (Gamma(X), Scott), rather than substituted as a different topology.

The resulting canonical statement retains the original hypotheses and
conclusions. This is a proof repair after the documented failed source
inference H1, not a claim that the printed intermediate assertion was true.
-/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed

section CoframeLawson
variable {L : Type u} [CompleteLattice L]

theorem sup_left_isLUB (a : L) {D : Set L} (hne : D.Nonempty)
    {x : L} (hx : IsLUB D x) :
    IsLUB ((fun d => a ⊔ d) '' D) (a ⊔ x) := by
  constructor
  · rintro _ ⟨d,hd,rfl⟩
    exact sup_le_sup_left (hx.1 hd) a
  · intro z hz
    obtain ⟨d,hd⟩ := hne
    refine sup_le (le_sup_left.trans (hz ⟨d,hd,rfl⟩)) (hx.2 ?_)
    intro e he
    exact le_sup_right.trans (hz ⟨e,he,rfl⟩)

/-- Fixed join preserves every existing nonempty directed supremum,
without a continuity or coframe hypothesis on L. -/
theorem scott_continuous_sup_left (a : L) :
    @Continuous L L (scottTopology L) (scottTopology L) (fun b => a ⊔ b) := by
  apply continuous_def.mpr
  intro U hU
  obtain ⟨hupper,hinacc⟩ := (isScottOpen_iff U).mp hU
  apply (isScottOpen_iff _).mpr
  have hm : Monotone (fun b : L => a ⊔ b) := fun _ _ h => sup_le_sup_left h a
  refine ⟨hupper.preimage hm,?_⟩
  intro D hne hdir x hx hxU
  obtain ⟨_,⟨d,hd,rfl⟩,hdU⟩ := hinacc (hne.image (fun b => a ⊔ b))
    (directedOn_image.mpr (hdir.mono hm)) (sup_left_isLUB a hne hx) hxU
  exact ⟨d,hd,hdU⟩

/-- Fixed join is Lawson continuous under the actual arbitrary-meet
coframe law. The lower half is the proved frame-meet right-adjoint argument
on the dual, not an extra continuity assumption. -/
theorem coframe_lawson_sup_left (hcoframe : IsCoframe L) (a : L) :
    @Continuous L L (lawsonTopology L) (lawsonTopology L) (fun b => a ⊔ b) := by
  have hscott : @Continuous L L (lawsonTopology L) (scottTopology L)
      (fun b => a ⊔ b) := by
    apply continuous_def.mpr
    intro U hU
    exact Topology.lawson_le_scott _ (continuous_def.mp (scott_continuous_sup_left a) U hU)
  have hdualframe : IsFrame Lᵒᵈ := hcoframe
  have hupper := upper_continuous_inf_left hdualframe (OrderDual.toDual a)
  have hlower : @Continuous L L (lawsonTopology L) (Topology.lower L)
      (fun b => a ⊔ b) := by
    apply continuous_def.mpr
    intro U hU
    exact Topology.lawson_le_lower _ (continuous_def.mp hupper U hU)
  change @Continuous L L (lawsonTopology L) (Topology.lower L ⊓ scottTopology L)
    (fun b => a ⊔ b)
  exact continuous_inf_rng.mpr ⟨hlower,hscott⟩

/-- The other operation of a continuous coframe is jointly Lawson
continuous by the fully proved original Lawson separate-to-joint theorem.
-/
theorem continuousCoframe_lawson_sup (hcont : IsContinuousLattice L)
    (hcoframe : IsCoframe L) :
    @Continuous (L × L) L
      (@instTopologicalSpaceProd L L (lawsonTopology L) (lawsonTopology L))
      (lawsonTopology L) (fun p => p.1 ⊔ p.2) := by
  have hc : @CompactSpace Lᵒᵈ (lawsonTopology L) := @lawson_compactSpace L _
  have ht : @T2Space Lᵒᵈ (lawsonTopology L) := @lawson_t2Space L _ hcont
  have ho : @OrderClosedTopology Lᵒᵈ (lawsonTopology L) _ := by
    refine @OrderClosedTopology.mk Lᵒᵈ (lawsonTopology L) _ ?_
    exact (lawson_orderRelations_closed hcont).2
  exact @CompactSemilattice.source_proposition_7_4 Lᵒᵈ _ (lawsonTopology L) hc ht ho
    (fun a => coframe_lawson_sup_left hcoframe a)

end CoframeLawson

namespace ClosedLattice
variable {X : Type u} [TopologicalSpace X] [T0Space X]

/-- Literally the patch topology of the original Scott closed-set space. -/
@[implicit_reducible] def canonicalPatchTopology (X : Type u) [TopologicalSpace X] :
    TopologicalSpace (Carrier X) := @patchTopology (Carrier X) (scottTopology (Carrier X))

theorem canonicalPatch_eq_dualLawson (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    canonicalPatchTopology X=lawsonTopology ((Carrier X)ᵒᵈ) :=
  patchTopology_eq_dualLawson_of_eq_upper (scottTopology (Carrier X))
    (carrier_scott_eq_upper hlocal hweb)

theorem canonicalPatch_compactSpace (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @CompactSpace (Carrier X) (canonicalPatchTopology X) := by
  rw [canonicalPatch_eq_dualLawson (X := X) hlocal hweb]
  exact @lawson_compactSpace ((Carrier X)ᵒᵈ) _

theorem canonicalPatch_t2Space (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @T2Space (Carrier X) (canonicalPatchTopology X) := by
  rw [canonicalPatch_eq_dualLawson (X := X) hlocal hweb]
  exact @lawson_t2Space ((Carrier X)ᵒᵈ) _ (carrier_dual_isContinuous hlocal)

theorem canonicalPatch_orderClosed (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @OrderClosedTopology (Carrier X) (canonicalPatchTopology X) _ := by
  rw [canonicalPatch_eq_dualLawson (X := X) hlocal hweb]
  refine @OrderClosedTopology.mk (Carrier X) (lawsonTopology ((Carrier X)ᵒᵈ)) _ ?_
  exact (lawson_orderRelations_closed (carrier_dual_isContinuous hlocal)).2

/-- Union of actual closed sets is meet on the continuous dual lattice. -/
theorem canonicalPatch_continuous_sup (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (canonicalPatchTopology X) (canonicalPatchTopology X))
      (canonicalPatchTopology X) (fun p => p.1 ⊔ p.2) := by
  rw [canonicalPatch_eq_dualLawson (X := X) hlocal hweb]
  exact @continuousLattice_lawson_inf ((Carrier X)ᵒᵈ) _ (carrier_dual_isContinuous hlocal)

/-- Intersection is join on that same dual lattice. Its coframe law is the
proved web-space frame law on Gamma(X), and joint continuity uses actual
Lawson Proposition 7.4. No continuity of Gamma(X) is asserted. -/
theorem canonicalPatch_continuous_inf (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (canonicalPatchTopology X) (canonicalPatchTopology X))
      (canonicalPatchTopology X) (fun p => p.1 ⊓ p.2) := by
  rw [canonicalPatch_eq_dualLawson (X := X) hlocal hweb]
  have hcoframe : IsCoframe ((Carrier X)ᵒᵈ) := isFrame_of_web hweb
  exact @continuousCoframe_lawson_sup ((Carrier X)ᵒᵈ) _
    (carrier_dual_isContinuous hlocal) hcoframe

theorem carrier_specializationLE_iff (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (C D : Carrier X) :
    @SpecializationLE (Carrier X) (scottTopology (Carrier X)) C D ↔ C ≤ D := by
  rw [carrier_scott_eq_upper hlocal hweb]
  exact (@specializationLE_iff (Carrier X) (upperTopology (Carrier X)) C D).trans
    (upper_specializes_iff D C)

/-- The full patch correspondence, on the actual patch topology and the
actual inclusion order of closed sets. No continuous-lattice hypothesis on
Gamma(X) is used to infer this upper-open description. -/
theorem canonical_isOpen_iff_patch_upper (hlocal : IsLocallyCompact X)
    (hweb : IsWebSpace X) (U : Set (Carrier X)) :
    IsOpen[scottTopology (Carrier X)] U ↔
      IsOpen[canonicalPatchTopology X] U ∧ IsUpperSet U := by
  letI : TopologicalSpace (Carrier X) := scottTopology (Carrier X)
  have hstable := carrier_scott_isStablyCompact hlocal hweb
  have hcompact : @CompactSpace (Carrier X) (@patchTopology (Carrier X)
      (scottTopology (Carrier X))) := canonicalPatch_compactSpace hlocal hweb
  have h := Patch.isOpen_iff_patch_upper hstable.2.1 hcompact U
  refine h.trans ?_
  constructor
  · rintro ⟨hU,hu⟩
    refine ⟨hU,?_⟩
    intro C D hCD hC
    exact hu C D ((carrier_specializationLE_iff hlocal hweb C D).mpr hCD) hC
  · rintro ⟨hU,hu⟩
    exact ⟨hU,fun C D hCD hC => hu ((carrier_specializationLE_iff hlocal hweb C D).mp hCD) hC⟩

omit [T0Space X] in
theorem canonical_eta_le_eta_iff (x y : X) : eta x ≤ eta y ↔ SpecializationLE x y := by
  constructor
  · intro h
    exact h (subset_closure (mem_singleton x))
  · intro h
    exact closure_minimal (singleton_subset_iff.mpr h) isClosed_closure

def canonicalEtaOrderEmbedding (X : Type u) [TopologicalSpace X] [T0Space X] :
    letI : PartialOrder X := specializationOrder X
    X ↪o Carrier X := by
  letI : PartialOrder X := specializationOrder X
  refine { toFun := eta, inj' := eta_injective, map_rel_iff' := ?_ }
  intro x y
  exact (canonical_eta_le_eta_iff x y).trans (specializationLE_iff x y)

theorem canonical_eta_isEmbedding (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Topology.IsEmbedding X (Carrier X) ‹TopologicalSpace X› (scottTopology (Carrier X)) eta := by
  have h := eta_isEmbedding (X := X)
  rw [lowerVietoris_eq_upper (X := X),← carrier_scott_eq_upper hlocal hweb] at h
  exact h

omit [T0Space X] in
theorem eta_saturation_hit (U : Opens X) :
    {C : Carrier X | ∃ x ∈ (U : Set X), eta x ≤ C}=hit U :=
  (hitting_eq_upper_eta (U : Set X)).symm

/-- The full original statement of `prop:canonical`, with its actual patch
topology, proved by the separately recorded dual-continuity repair. The
source's sobriety hypothesis is retained and the literal eta map is used.
-/
theorem source_canonical_repaired [QuasiSober X]
    (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @IsStablyCompact (Carrier X) (scottTopology (Carrier X)) ∧
      @CompactSpace (Carrier X) (canonicalPatchTopology X) ∧
      @T2Space (Carrier X) (canonicalPatchTopology X) ∧
      @OrderClosedTopology (Carrier X) (canonicalPatchTopology X) (inferInstance) ∧
      @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
        (@instTopologicalSpaceProd (Carrier X) (Carrier X)
          (canonicalPatchTopology X) (canonicalPatchTopology X))
        (canonicalPatchTopology X) (fun p => p.1 ⊓ p.2) ∧
      @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
        (@instTopologicalSpaceProd (Carrier X) (Carrier X)
          (canonicalPatchTopology X) (canonicalPatchTopology X))
        (canonicalPatchTopology X) (fun p => p.1 ⊔ p.2) ∧
      (∀ U : Set (Carrier X), IsOpen[scottTopology (Carrier X)] U ↔
        IsOpen[canonicalPatchTopology X] U ∧ IsUpperSet U) ∧
      @Topology.IsEmbedding X (Carrier X) ‹TopologicalSpace X› (scottTopology (Carrier X)) eta ∧
      (∀ x y : X, eta x ≤ eta y ↔ SpecializationLE x y) ∧
      (∀ U : Opens X, {C : Carrier X | ∃ x ∈ (U : Set X), eta x ≤ C}=hit U) :=
  ⟨carrier_scott_isStablyCompact hlocal hweb,canonicalPatch_compactSpace hlocal hweb,
    canonicalPatch_t2Space hlocal hweb,canonicalPatch_orderClosed hlocal hweb,
    canonicalPatch_continuous_inf hlocal hweb,canonicalPatch_continuous_sup hlocal hweb,
    canonical_isOpen_iff_patch_upper hlocal hweb,canonical_eta_isEmbedding hlocal hweb,
    canonical_eta_le_eta_iff,eta_saturation_hit⟩

/-- Actual product continuity on the original Scott topology, descended
from the proved compact ordered patch product bridge. Product-patch
compatibility is not silently assumed as a certificate. -/
theorem canonical_scott_continuous_inf (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (scottTopology (Carrier X)) (scottTopology (Carrier X)))
      (scottTopology (Carrier X)) (fun p => p.1 ⊓ p.2) := by
  letI : TopologicalSpace (Carrier X) := canonicalPatchTopology X
  letI : CompactSpace (Carrier X) := canonicalPatch_compactSpace hlocal hweb
  letI : OrderClosedTopology (Carrier X) := canonicalPatch_orderClosed hlocal hweb
  exact Patch.continuous_prod_mono_to_upper
    (P := Carrier X) (Q := Carrier X) (R := Carrier X)
    (scottTopology (Carrier X)) (scottTopology (Carrier X)) (scottTopology (Carrier X))
    (canonical_isOpen_iff_patch_upper hlocal hweb)
    (canonical_isOpen_iff_patch_upper hlocal hweb)
    (canonical_isOpen_iff_patch_upper hlocal hweb)
    (fun p => p.1 ⊓ p.2) (canonicalPatch_continuous_inf hlocal hweb)
    (fun _ _ h => inf_le_inf h.1 h.2)

theorem canonical_scott_continuous_sup (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @Continuous ((Carrier X) × (Carrier X)) (Carrier X)
      (@instTopologicalSpaceProd (Carrier X) (Carrier X)
        (scottTopology (Carrier X)) (scottTopology (Carrier X)))
      (scottTopology (Carrier X)) (fun p => p.1 ⊔ p.2) := by
  letI : TopologicalSpace (Carrier X) := canonicalPatchTopology X
  letI : CompactSpace (Carrier X) := canonicalPatch_compactSpace hlocal hweb
  letI : OrderClosedTopology (Carrier X) := canonicalPatch_orderClosed hlocal hweb
  exact Patch.continuous_prod_mono_to_upper
    (P := Carrier X) (Q := Carrier X) (R := Carrier X)
    (scottTopology (Carrier X)) (scottTopology (Carrier X)) (scottTopology (Carrier X))
    (canonical_isOpen_iff_patch_upper hlocal hweb)
    (canonical_isOpen_iff_patch_upper hlocal hweb)
    (canonical_isOpen_iff_patch_upper hlocal hweb)
    (fun p => p.1 ⊔ p.2) (canonicalPatch_continuous_sup hlocal hweb)
    (fun _ _ h => sup_le_sup h.1 h.2)

/-- The exact lower-relation openness needed by source Lemma fc-core,
lines833--850, through the literal map (a,b) ↦ eta(a) ∩ eta(b). -/
theorem canonical_lowerRelation_isOpen (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X)
    (U : Set X) (hU : IsOpen U) :
    IsOpen {p : X × X | ∃ c ∈ U, SpecializationLE c p.1 ∧ SpecializationLE c p.2} := by
  letI : TopologicalSpace (Carrier X) := scottTopology (Carrier X)
  have heta : Continuous (eta : X → Carrier X) :=
    (canonical_eta_isEmbedding hlocal hweb).continuous
  have hE : Continuous (fun p : X × X => (eta p.1,eta p.2)) :=
    (heta.comp continuous_fst).prodMk (heta.comp continuous_snd)
  have hF : Continuous (fun p : X × X => eta p.1 ⊓ eta p.2) :=
    (canonical_scott_continuous_inf hlocal hweb).comp hE
  have hhit : IsOpen (hit (⟨U,hU⟩ : Opens X)) := by
    change IsOpen[scottTopology (Carrier X)] _
    rw [carrier_scott_eq_upper hlocal hweb]
    exact hit_isOpen_upper ⟨U,hU⟩
  have hpre := hhit.preimage hF
  have heq : (fun p : X × X => eta p.1 ⊓ eta p.2) ⁻¹' hit (⟨U,hU⟩ : Opens X)=
      {p : X × X | ∃ c ∈ U, SpecializationLE c p.1 ∧ SpecializationLE c p.2} := by
    ext p
    constructor
    · rintro ⟨c,⟨hca,hcb⟩,hcU⟩
      exact ⟨c,hcU,hca,hcb⟩
    · rintro ⟨c,hcU,hca,hcb⟩
      exact ⟨c,⟨hca,hcb⟩,hcU⟩
  rwa [heq] at hpre

end ClosedLattice
end ScottSpectraReviewed
