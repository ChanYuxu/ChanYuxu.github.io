import ScottSpectraReviewed.TopologicalModels

/-! The frame part of source `lem:hyperspace-scott`, lines 522--538.
The proof is the printed web/common-lower-bound argument on the actual
closed subsets, including the empty family. It is not the full numbered
lemma: local compactness and the Scott/upper equality are separate obligations.
-/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace ClosedLattice

variable {X : Type u} [TopologicalSpace X]

/-- Closed sets form a frame in every web space. No sobriety, countability,
or assumption that its closed-set lattice is continuous is used. -/
theorem isFrame_of_web (hX : IsWebSpace X) : IsFrame (Carrier X) := by
  intro F S
  apply le_antisymm
  · intro x hx
    obtain ⟨hxF,hxS⟩ := hx
    have hxcl : x ∈ closure (⋃₀ ((fun C : Carrier X => (C : Set X)) '' S)) := by
      simpa only [Closeds.coe_sSup] using hxS
    change x ∈ ((sSup ((fun C : Carrier X => F ⊓ C) '' S) : Carrier X) : Set X)
    rw [Closeds.coe_sSup,mem_closure_iff]
    intro U hU hxU
    obtain ⟨W,hWU,hW⟩ := hX x U (hU.mem_nhds hxU)
    obtain ⟨V,hVW,hV,hxV⟩ := mem_nhds_iff.mp hW.1
    obtain ⟨y,hyV,hyunion⟩ := mem_closure_iff.mp hxcl V hV hxV
    obtain ⟨_,⟨C,hCS,rfl⟩,hyC⟩ := hyunion
    obtain ⟨z,hzW,hzx,hzy⟩ := hW.2 y (hVW hyV)
    have hzF : z ∈ F :=
      closure_minimal (singleton_subset_iff.mpr hxF) F.isClosed hzx
    have hzC : z ∈ C :=
      closure_minimal (singleton_subset_iff.mpr hyC) C.isClosed hzy
    exact ⟨z,hWU hzW,(F ⊓ C : Set X),⟨F ⊓ C,⟨C,hCS,rfl⟩,rfl⟩,⟨hzF,hzC⟩⟩
  · apply sSup_le
    rintro _ ⟨C,hCS,rfl⟩
    exact inf_le_inf_left F (le_sSup hCS)

end ClosedLattice
end ScottSpectraReviewed
