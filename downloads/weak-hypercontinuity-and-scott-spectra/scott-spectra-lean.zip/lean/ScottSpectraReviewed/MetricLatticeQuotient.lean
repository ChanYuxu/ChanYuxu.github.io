import ScottSpectraReviewed.MetricLatticeQuotientImage

/-! Exact source lem:metric-quotient, lines889--943. The witness is the
actual evaluation image of the countable partition/translation coordinate
closure, equipped with its proved quotient complete-lattice structure and its
ordinary product-subspace topology. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed

open MetricLatticeQuotient

/-- Every countable family of continuous real-valued functions on an actual
compact Hausdorff topological complete lattice factors continuously through
an actual continuous surjective complete lattice homomorphism onto a compact
metrizable topological lattice, constructed by the printed evaluation route. -/
theorem source_metric_quotient {M : Type u} [TopologicalSpace M] [CompleteLattice M]
    [CompactSpace M] [T2Space M] [ContinuousInf M] [ContinuousSup M]
    (F₀ : Set C(M, ℝ)) (hF : F₀.Countable) :
    ∃ (Q : Type u) (tQ : TopologicalSpace Q) (lQ : CompleteLattice Q),
      letI : TopologicalSpace Q := tQ
      letI : CompleteLattice Q := lQ
      CompactSpace Q ∧ T2Space Q ∧ MetrizableSpace Q ∧ ContinuousInf Q ∧ ContinuousSup Q ∧
        ∃ q : CompleteLatticeHom M Q, Function.Surjective q ∧ Continuous q ∧
          ∀ f ∈ F₀, ∃ g : C(Q, ℝ), ∀ a : M, g (q a) = f a := by
  refine ⟨CoordinateImage F₀, inferInstance, inferInstance,
    inferInstance, inferInstance, coordinateImage_metrizable F₀ hF,
    inferInstance, inferInstance, evaluationCompleteLatticeHom F₀,
    evaluation_surjective F₀, continuous_evaluation F₀, ?_⟩
  intro f hf
  exact ⟨coordinateFactor F₀ ⟨f, subset_closedFamily F₀ hf⟩, fun a => rfl⟩

end ScottSpectraReviewed
