import ScottSpectraReviewed.TopologicalModels
import ScottSpectraReviewed.UpperTopologySobriety
import Mathlib.Topology.Bases

/-! Source `lem:lower-vietoris-locally-compact`, lines 488--514.
The compact neighborhoods are the literal finite intersections of H(K),
with H(K) the upper saturation of eta(K). Empty intersections use compactness
of the upper topology. The original space need not be Hausdorff or sober. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace ClosedLattice

variable {X : Type u} [TopologicalSpace X]

def hitting (K : Set X) : Set (Carrier X) :=
  {C | ((C : Set X) ∩ K).Nonempty}

theorem hitting_isUpperSet (K : Set X) : IsUpperSet (hitting K) := by
  intro C D hCD hC
  obtain ⟨x,hxC,hxK⟩ := hC
  exact ⟨x,hCD hxC,hxK⟩

theorem hitting_eq_upper_eta (K : Set X) :
    hitting K = {C | ∃ x ∈ K, eta x ≤ C} := by
  ext C
  constructor
  · rintro ⟨x,hxC,hxK⟩
    exact ⟨x,hxK,closure_minimal (singleton_subset_iff.mpr hxC) C.isClosed⟩
  · rintro ⟨x,hxK,hxC⟩
    exact ⟨x,hxC (subset_closure (mem_singleton x)),hxK⟩

theorem hit_isOpen_upper (U : Opens X) :
    IsOpen[upperTopology (Carrier X)] (hit U) := by
  rw [hit_eq_compl_Iic]
  exact isOpen_generateFrom_of_mem ⟨U.compl,rfl⟩

theorem eta_continuous_upper :
    @Continuous X (Carrier X) ‹TopologicalSpace X› (upperTopology (Carrier X)) eta := by
  rw [← lowerVietoris_eq_upper]
  letI : TopologicalSpace (Carrier X) := lowerVietorisTopology X
  exact eta_isInducing.continuous

/-- Compactness of the actual saturation H(K), proved by the source's
continuous eta image and the open-upper finite-cover argument. -/
theorem hitting_isCompact (K : Set X) (hK : IsCompact K) :
    @IsCompact (Carrier X) (upperTopology (Carrier X)) (hitting K) := by
  letI : TopologicalSpace (Carrier X) := upperTopology (Carrier X)
  letI : Topology.IsUpper (Carrier X) := ⟨rfl⟩
  have hetaK : IsCompact (eta '' K) := hK.image eta_continuous_upper
  apply isCompact_of_finite_subcover
  intro ι U hU hcover
  have hη : eta '' K ⊆ hitting K := by
    rintro _ ⟨x,hx,rfl⟩
    exact ⟨x,subset_closure (mem_singleton x),hx⟩
  obtain ⟨F,hF⟩ := hetaK.elim_finite_subcover U hU (hη.trans hcover)
  refine ⟨F,?_⟩
  intro C hC
  obtain ⟨x,hxK,hxC⟩ := (Set.ext_iff.mp (hitting_eq_upper_eta K) C).mp hC
  obtain ⟨i,hi,hxi⟩ := mem_iUnion₂.mp (hF ⟨x,hxK,rfl⟩)
  exact mem_iUnion₂.mpr ⟨i,hi,(Topology.IsUpper.isUpperSet_of_isOpen (hU i)) hxC hxi⟩

/-- Exact numbered source statement on the specified lower Vietoris topology. -/
theorem source_lowerVietoris_locallyCompact [T0Space X] (hX : IsLocallyCompact X) :
    @IsLocallyCompact (Carrier X) (lowerVietorisTopology X) := by
  rw [lowerVietoris_eq_upper]
  letI : TopologicalSpace (Carrier X) := upperTopology (Carrier X)
  letI : CompactSpace (Carrier X) := upper_compactSpace (Carrier X)
  intro U C hCU
  have hB := isTopologicalBasis_of_subbasis
    (t := upperTopology (Carrier X)) (lowerVietoris_eq_upper (X := X)).symm
  obtain ⟨_,⟨F,⟨hF,hFsub⟩,rfl⟩,hCF,hFU⟩ :=
    hB.exists_subset_of_mem_open hCU U.isOpen
  letI : Fintype F := hF.fintype
  choose A hA using (fun i : F => hFsub i.property)
  have hCA : ∀ i : F, C ∈ hit (A i) := by
    intro i
    rw [hA i]
    exact mem_sInter.mp hCF i.val i.property
  choose x hxC hxA using hCA
  choose V K hxV hVK hKA hK hKs using (fun i : F => hX (A i) (x i) (hxA i))
  let O : Set (Carrier X) := ⋂ i : F, hit (V i)
  let H : Set (Carrier X) := ⋂ i : F, hitting (K i)
  have hO : IsOpen O := isOpen_iInter_of_finite (fun i => hit_isOpen_upper (V i))
  have hHup : IsUpperSet H := by
    intro D E hDE hD
    apply mem_iInter.mpr
    intro i
    exact hitting_isUpperSet (K i) hDE (mem_iInter.mp hD i)
  have hHcompact : IsCompact H := by
    have hf : ∀ J : Finset F, IsCompact (⋂ i ∈ J, hitting (K i)) := by
      intro J
      induction J using Finset.induction_on with
      | empty => simpa using (isCompact_univ : IsCompact (Set.univ : Set (Carrier X)))
      | @insert i J hi ih =>
        rw [Finset.set_biInter_insert]
        apply upper_isCompact_inter (hitting_isUpperSet (K i))
          (fun D E hDE hD => ?_) (hitting_isCompact (K i) (hK i)) ih
        exact mem_iInter₂.mpr (fun j hj => hitting_isUpperSet (K j) hDE
          (mem_iInter₂.mp hD j hj))
    simpa only [Finset.mem_univ, iInter_true] using hf Finset.univ
  refine ⟨⟨O,hO⟩,H,?_,?_,?_,hHcompact,(upper_isSaturated_iff H).mpr hHup⟩
  · exact mem_iInter.mpr (fun i => ⟨x i,hxC i,hxV i⟩)
  · intro D hD
    exact mem_iInter.mpr (fun i => by
      obtain ⟨z,hzD,hzV⟩ := mem_iInter.mp hD i
      exact ⟨z,hzD,hVK i hzV⟩)
  · apply subset_trans ?_ hFU
    intro D hD
    apply mem_sInter.mpr
    intro Z hZF
    let i : F := ⟨Z,hZF⟩
    have hZi : Z = hit (A i) := (hA i).symm
    rw [hZi]
    obtain ⟨z,hzD,hzK⟩ := mem_iInter.mp hD i
    exact ⟨z,hzD,hKA i hzK⟩

end ClosedLattice
end ScottSpectraReviewed
