import ScottSpectraReviewed.TopologicalModels
import ScottSpectraReviewed.BorelCoreCantor
import ScottSpectraReviewed.CantorMinimal
import Mathlib.Topology.Compactness.Lindelof
import Mathlib.Topology.Bases

/-! Exact source specification of Lemma `lem:borel-subset`, lines659--715.
This proposition definition is a translation target, not a proof. In particular
it does not assume Cantor continuity of e or any source Hausdorff/sobriety
hypothesis. The actual source construction is implemented below only as its
obligations are proved. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace BorelCore

def SourceStatement (X : Type u) [TopologicalSpace X] [T0Space X]
    [SecondCountableTopology X] : Prop :=
  letI : PartialOrder X := specializationOrder X
  ∃ (e : X ↪o Cantor) (G : Set X),
    @MeasurableSet Cantor (borel Cantor) (e '' G) ∧
      (∀ U : Set X, IsOpen U → ∃ V : Set Cantor, IsOpen V ∧ e ⁻¹' V = U) ∧
      (∀ (x : X) (U : Set X), IsOpen U → x ∈ U →
        ∃ g ∈ G, g ∈ U ∧ g ≤ x)

/-- The printed coordinate map: nth coordinate records membership in B_n. -/
def code {X : Type u} (B : ℕ → Set X) (x : X) : Cantor := by
  classical
  exact fun n => decide (x ∈ B n)

@[simp] theorem code_apply_eq_true {X : Type u} (B : ℕ → Set X) (x : X) (n : ℕ) :
    code B x n = true ↔ x ∈ B n := by
  classical
  simp [code]

theorem code_le_iff {X : Type u} (B : ℕ → Set X) (x y : X) :
    code B x ≤ code B y ↔ ∀ n : ℕ, x ∈ B n → y ∈ B n := by
  constructor
  · intro h n hx
    exact (code_apply_eq_true B y n).mp
      ((bool_le_iff_true_imp _ _).mp (h n) ((code_apply_eq_true B x n).mpr hx))
  · intro h n
    apply (bool_le_iff_true_imp _ _).mpr
    intro hx
    exact (code_apply_eq_true B y n).mpr (h n ((code_apply_eq_true B x n).mp hx))

theorem code_le_iff_specialization {X : Type u} [TopologicalSpace X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (Set.range B)) (x y : X) :
    code B x ≤ code B y ↔ SpecializationLE x y := by
  constructor
  · intro h
    apply mem_closure_iff.mpr
    intro U hU hxU
    obtain ⟨V, ⟨n, rfl⟩, hxV, hVU⟩ := hB.exists_subset_of_mem_open hxU hU
    exact ⟨y, hVU ((code_le_iff B x y).mp h n hxV), mem_singleton y⟩
  · intro hxy
    apply (code_le_iff B x y).mpr
    intro n hx
    exact isOpen_upper_specialization (hB.isOpen (mem_range_self n)) hxy hx

def basisEmbedding {X : Type u} [TopologicalSpace X] [T0Space X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (Set.range B)) :
    letI : PartialOrder X := specializationOrder X
    X ↪o Cantor := by
  letI : PartialOrder X := specializationOrder X
  refine { toFun := code B, inj' := ?_, map_rel_iff' := ?_ }
  · intro x y hxy
    have hle : x ≤ y := (specializationLE_iff x y).mp
      ((code_le_iff_specialization B hB x y).mp hxy.le)
    have hge : y ≤ x := (specializationLE_iff y x).mp
      ((code_le_iff_specialization B hB y x).mp hxy.symm.le)
    exact le_antisymm hle hge
  · intro x y
    exact (code_le_iff_specialization B hB x y).trans (specializationLE_iff x y)

/-- Every original open is the inverse image of the printed Cantor-open
union of positive cylinders. This is not Cantor continuity of the code. -/
theorem code_open_preimage {X : Type u} [TopologicalSpace X]
    (B : ℕ → Set X) (hB : IsTopologicalBasis (Set.range B))
    (U : Set X) (hU : IsOpen U) :
    ∃ V : Set Cantor, IsOpen V ∧ code B ⁻¹' V = U := by
  let V : Set Cantor := ⋃ n : ℕ, ⋃ (_ : B n ⊆ U), positive n
  have hV : IsOpen V := isOpen_iUnion (fun n =>
    isOpen_iUnion (fun _ => (positive_isClopen n).2))
  refine ⟨V, hV, ?_⟩
  ext x
  simp only [V, mem_preimage, mem_iUnion, positive, mem_setOf_eq, exists_prop]
  constructor
  · rintro ⟨n, hBnU, hxn⟩
    exact hBnU ((code_apply_eq_true B x n).mp hxn)
  · intro hxU
    obtain ⟨W, ⟨n, rfl⟩, hxW, hWU⟩ := hB.exists_subset_of_mem_open hxU hU
    exact ⟨n, hWU, (code_apply_eq_true B x n).mpr hxW⟩

/-- Actual continuity into the full intrinsic Scott topology, by its proved
finite-mask neighborhoods. No negative-coordinate preimage is assumed open. -/
theorem code_scottContinuous {X : Type u} [TopologicalSpace X]
    (B : ℕ → Set X) (hBopen : ∀ n, IsOpen (B n)) :
    Continuous[‹TopologicalSpace X›, scottTopology Cantor] (code B) := by
  apply continuous_def.mpr
  intro U hU
  apply isOpen_iff_mem_nhds.mpr
  intro x hxU
  obtain ⟨F, hFx, hFU⟩ := exists_finiteMask_of_mem_isScottOpen U hU hxU
  let V : Set X := ⋂ n ∈ F, B n
  have hV : IsOpen V := F.finite_toSet.isOpen_biInter (fun n _ => hBopen n)
  have hxV : x ∈ V := mem_iInter₂.mpr (fun n hn =>
    (code_apply_eq_true B x n).mp ((finiteMask_le_iff F (code B x)).mp hFx n hn))
  apply Filter.mem_of_superset (hV.mem_nhds hxV)
  intro y hy
  apply hFU
  apply (finiteMask_le_iff F (code B y)).mpr
  intro n hn
  exact (code_apply_eq_true B y n).mpr (mem_iInter₂.mp hy n hn)

theorem exists_nat_open_basis (X : Type u) [TopologicalSpace X]
    [SecondCountableTopology X] [Nonempty X] :
    ∃ B : ℕ → Set X, IsTopologicalBasis (Set.range B) ∧ ∀ n, IsOpen (B n) := by
  classical
  let x : X := Classical.arbitrary X
  have hbne : (countableBasis X).Nonempty := by
    obtain ⟨U, hU, _, _⟩ := (isBasis_countableBasis X).exists_subset_of_mem_open
      (mem_univ x) isOpen_univ
    exact ⟨U, hU⟩
  obtain ⟨B, hB⟩ := (countable_countableBasis X).exists_eq_range hbne
  refine ⟨B, hB ▸ isBasis_countableBasis X, ?_⟩
  intro n
  exact isOpen_of_mem_countableBasis (hB.symm ▸ mem_range_self n)

/-- The actual countable nonempty compact-saturated family from the source:
Lindelof is applied separately to the interiors of the chosen neighborhoods
inside each basis open, and only those countable chosen indices are enumerated.
There is no Countable X premise. -/
theorem exists_compact_saturated_family {X : Type u} [TopologicalSpace X]
    [SecondCountableTopology X] [Nonempty X] (hX : IsLocallyCompact X)
    (B : ℕ → Set X) (hB : IsTopologicalBasis (Set.range B)) :
    ∃ K : ℕ → Set X,
      (∀ j, (K j).Nonempty ∧ IsCompact (K j) ∧ IsSaturated (K j)) ∧
      ∀ (U : Set X), IsOpen U → ∀ x ∈ U,
        ∃ j : ℕ, x ∈ interior (K j) ∧ K j ⊆ U := by
  classical
  choose V K hxV hVK hKBi hKcompact hKsaturated using
    (fun (n : ℕ) (x : B n) =>
      hX ⟨B n, hB.isOpen (mem_range_self n)⟩ x.1 x.2)
  have hxInt : ∀ (n : ℕ) (x : B n), x.1 ∈ interior (K n x) := by
    intro n x
    exact interior_maximal (hVK n x) (V n x).isOpen (hxV n x)
  have hcover : ∀ n : ℕ, B n ⊆ ⋃ x : B n, interior (K n x) := by
    intro n x hx
    exact mem_iUnion.mpr ⟨⟨x, hx⟩, hxInt n ⟨x, hx⟩⟩
  have hcountCover : ∀ n : ℕ, ∃ r : Set (B n), r.Countable ∧
      B n ⊆ ⋃ x ∈ r, interior (K n x) := by
    intro n
    have hlin : IsLindelof (B n) := IsLindelof.of_coe
    exact hlin.elim_countable_subcover (fun x : B n => interior (K n x))
      (fun _ => isOpen_interior) (hcover n)
  choose r hrCount hrCover using hcountCover
  let I := Σ n : ℕ, r n
  letI : ∀ n : ℕ, Countable (r n) := fun n => (hrCount n).to_subtype
  letI : Countable I := inferInstance
  have hI : Nonempty I := by
    let x : X := Classical.arbitrary X
    obtain ⟨U, ⟨n, rfl⟩, hxU, _⟩ := hB.exists_subset_of_mem_open (mem_univ x) isOpen_univ
    obtain ⟨y, hy, _⟩ := mem_iUnion₂.mp (hrCover n hxU)
    exact ⟨⟨n, ⟨y, hy⟩⟩⟩
  letI : Nonempty I := hI
  obtain ⟨enum, henum⟩ := (Set.to_countable (Set.univ : Set I)).exists_eq_range
    (Set.univ_nonempty : (Set.univ : Set I).Nonempty)
  let K' : ℕ → Set X := fun j => K (enum j).1 (enum j).2.1
  refine ⟨K', ?_, ?_⟩
  · intro j
    exact ⟨⟨(enum j).2.1.1, hVK _ _ (hxV _ _)⟩,
      hKcompact _ _, hKsaturated _ _⟩
  · intro U hU x hxU
    obtain ⟨W, ⟨n, rfl⟩, hxW, hWU⟩ := hB.exists_subset_of_mem_open hxU hU
    obtain ⟨y, hy, hxy⟩ := mem_iUnion₂.mp (hrCover n hxW)
    have hi : (⟨n, ⟨y, hy⟩⟩ : I) ∈ Set.range enum := henum ▸ mem_univ _
    obtain ⟨j, hj⟩ := hi
    have hKj : K' j = K n y := congrArg (fun i : I => K i.1 i.2.1) hj
    refine ⟨j, ?_, ?_⟩
    · rw [hKj]
      exact hxy
    · rw [hKj]
      exact (hKBi n y).trans hWU

theorem upwardHull_isScottCompact (S : Set Cantor)
    (hS : @IsCompact Cantor (scottTopology Cantor) S) :
    @IsCompact Cantor (scottTopology Cantor) (CantorMinimal.upwardHull S) := by
  letI : TopologicalSpace Cantor := scottTopology Cantor
  apply isCompact_of_finite_subcover
  intro ι U hU hcover
  obtain ⟨J, hJ⟩ := hS.elim_finite_subcover U hU
    ((CantorMinimal.subset_upwardHull S).trans hcover)
  refine ⟨J, ?_⟩
  rintro a ⟨s, hs, hsa⟩
  obtain ⟨i, hi, hsi⟩ := mem_iUnion₂.mp (hJ hs)
  exact mem_iUnion₂.mpr ⟨i, hi, ((isScottOpen_iff (U i)).mp (hU i)).1 hsa hsi⟩

theorem compact_upward_code_isClosed {X : Type u} [TopologicalSpace X]
    (B : ℕ → Set X) (hBopen : ∀ n, IsOpen (B n)) (K : Set X) (hK : IsCompact K) :
    IsClosed (CantorMinimal.upwardHull (code B '' K)) := by
  have himage : @IsCompact Cantor (scottTopology Cantor) (code B '' K) := by
    letI : TopologicalSpace Cantor := scottTopology Cantor
    exact hK.image (code_scottContinuous B hBopen)
  exact scottCompact_upper_isCantorClosed _ (CantorMinimal.upwardHull_isUpperSet _)
    (upwardHull_isScottCompact _ himage)

/-- Exact source-facing Lemma borel-subset. Every named source construction
is actual: basis membership code, Lindelof-selected compact saturated family,
upward code hulls, compact-order minimal points, and their preimage union. -/
theorem source_borel_subset (X : Type u) [TopologicalSpace X] [T0Space X]
    [SecondCountableTopology X] (hX : IsLocallyCompact X) : SourceStatement X := by
  classical
  letI : PartialOrder X := specializationOrder X
  by_cases hempty : IsEmpty X
  · letI : IsEmpty X := hempty
    let e : X ↪o Cantor :=
      { toFun := fun x => isEmptyElim x
        inj' := by intro x y h; exact isEmptyElim x
        map_rel_iff' := by intro x y; exact isEmptyElim x }
    refine ⟨e, ∅, ?_, ?_, ?_⟩
    · simp only [Set.image_empty]
      exact @MeasurableSet.empty Cantor (borel Cantor)
    · intro U hU
      refine ⟨∅, isOpen_empty, ?_⟩
      ext x
      exact isEmptyElim x
    · intro x U hU hxU
      exact isEmptyElim x
  · haveI : Nonempty X := not_isEmpty_iff.mp hempty
    letI : MetricSpace Cantor := PiNat.metricSpace
    letI : OrderClosedTopology Cantor := cantor_orderClosedTopology
    letI : MeasurableSpace Cantor := borel Cantor
    letI : BorelSpace Cantor := ⟨rfl⟩
    obtain ⟨B, hB, hBopen⟩ := exists_nat_open_basis X
    let e : X ↪o Cantor := basisEmbedding B hB
    obtain ⟨K, hK, hKcore⟩ := exists_compact_saturated_family hX B hB
    let H : ℕ → Set Cantor := fun j => CantorMinimal.upwardHull (code B '' K j)
    have hHclosed : ∀ j, IsClosed (H j) :=
      fun j => compact_upward_code_isClosed B hBopen (K j) (hK j).2.1
    have hHcompact : ∀ j, IsCompact (H j) := fun j => (hHclosed j).isCompact
    let M : Set Cantor := ⋃ j : ℕ, {a | Minimal (· ∈ H j) a}
    have hMrange : M ⊆ Set.range e := by
      intro a ha
      obtain ⟨j, hmin⟩ := mem_iUnion.mp ha
      obtain ⟨x, hxK, hxa⟩ := CantorMinimal.minimal_upwardHull_mem hmin
      exact ⟨x, hxa⟩
    let G : Set X := e ⁻¹' M
    have heG : e '' G = M := by
      ext a
      constructor
      · rintro ⟨x, hx, rfl⟩
        exact hx
      · intro ha
        obtain ⟨x, hxa⟩ := hMrange ha
        refine ⟨x, ?_, hxa⟩
        change e x ∈ M
        rw [hxa]
        exact ha
    refine ⟨e, G, ?_, ?_, ?_⟩
    · rw [heG]
      exact MeasurableSet.iUnion (fun j =>
        (CantorMinimal.minimal_isGdelta (hHcompact j)).measurableSet)
    · intro U hU
      exact code_open_preimage B hB U hU
    · intro x U hU hxU
      obtain ⟨j, hxInt, hKU⟩ := hKcore U hU x hxU
      have hxH : e x ∈ H j := ⟨e x, ⟨x, interior_subset hxInt, rfl⟩, le_rfl⟩
      obtain ⟨m, hmin, hmex⟩ := CantorMinimal.compact_exists_minimal_le (hHcompact j) hxH
      obtain ⟨g, hgK, hgm⟩ := CantorMinimal.minimal_upwardHull_mem hmin
      refine ⟨g, ?_, hKU hgK, ?_⟩
      · change code B g ∈ M
        apply mem_iUnion.mpr
        refine ⟨j, ?_⟩
        rw [hgm]
        exact hmin
      · have hcode : code B g ≤ code B x := by
          rw [hgm]
          exact hmex
        exact (specializationLE_iff g x).mp ((code_le_iff_specialization B hB g x).mp hcode)

end BorelCore
end ScottSpectraReviewed
