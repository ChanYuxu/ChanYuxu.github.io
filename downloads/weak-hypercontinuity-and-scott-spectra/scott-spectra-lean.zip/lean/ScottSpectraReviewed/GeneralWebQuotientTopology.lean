import ScottSpectraReviewed.CompleteQuotients
import ScottSpectraReviewed.CompactOrdered
import ScottSpectraReviewed.CompactSemilattice
import Mathlib.Topology.Bases
import Mathlib.Topology.Metrizable.Basic

/-! Source thm:web, lines1034--1045: Scott opens of the actual compact
metric complete-lattice quotient are original-open upper sets; upper closures
of its actual countable metric open basis form a countable Scott basis. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace GeneralWeb

theorem scottOpen_isOpen_of_quotient {M : Type u} {Q : Type v}
    [CompleteLattice M] [TopologicalSpace M] [CompactSpace M]
    [CompleteLattice Q] [TopologicalSpace Q] [T2Space Q]
    (q : CompleteLatticeHom M Q) (hq : Function.Surjective q) (hc : Continuous q)
    (hM : ∀ U : Set M, IsOpen[scottTopology M] U → IsOpen U)
    (U : Set Q) (hU : IsOpen[scottTopology Q] U) : IsOpen U := by
  have hquot : Topology.IsQuotientMap q :=
    _root_.IsQuotientMap.of_surjective_continuous hq hc
  exact hquot.isCoinducing.isOpen_preimage.mp
    (hM (q ⁻¹' U) (CompleteHom.preimage_isScottOpen q U hU))

theorem scott_isOpen_iff_original_upper {M : Type u} {Q : Type v}
    [CompleteLattice M] [TopologicalSpace M] [CompactSpace M]
    [CompleteLattice Q] [TopologicalSpace Q] [CompactSpace Q] [T2Space Q]
    [OrderClosedTopology Q]
    (q : CompleteLatticeHom M Q) (hq : Function.Surjective q) (hc : Continuous q)
    (hM : ∀ U : Set M, IsOpen[scottTopology M] U → IsOpen U) (U : Set Q) :
    IsOpen[scottTopology Q] U ↔ IsOpen U ∧ IsUpperSet U := by
  constructor
  · intro hU
    exact ⟨scottOpen_isOpen_of_quotient q hq hc hM U hU, ((isScottOpen_iff U).mp hU).1⟩
  · rintro ⟨hU, hupper⟩
    exact CompactOrdered.isScottOpen_of_isOpen_upper hU hupper

/-- Exactly the upper closures of an actual countable original-open basis.
The topology of Q itself is not replaced or silently identified with Scott. -/
theorem scott_secondCountable_of_open_upper {Q : Type v} [Lattice Q]
    [TopologicalSpace Q] [CompactSpace Q] [OrderClosedTopology Q]
    [ContinuousInf Q] [SecondCountableTopology Q]
    (hS : ∀ U : Set Q, IsOpen[scottTopology Q] U → IsOpen U) :
    @SecondCountableTopology Q (scottTopology Q) := by
  classical
  let B : Set (Set Q) := (fun V : Set Q => (upperClosure V : Set Q)) '' countableBasis Q
  have hBcount : B.Countable := (countable_countableBasis Q).image _
  have hBopen : ∀ U ∈ B, IsOpen[scottTopology Q] U := by
    rintro U ⟨V, hV, rfl⟩
    exact CompactOrdered.isScottOpen_of_isOpen_upper
      (CompactSemilattice.isOpen_upperClosure_of_separate
        (fun a : Q => continuous_const.inf continuous_id) (isOpen_of_mem_countableBasis hV))
      (upperClosure V).upper
  have hBlocal : ∀ (x : Q) (U : Set Q), x ∈ U → IsOpen[scottTopology Q] U →
      ∃ V ∈ B, x ∈ V ∧ V ⊆ U := by
    intro x U hxU hU
    obtain ⟨V, hV, hxV, hVU⟩ := (isBasis_countableBasis Q).exists_subset_of_mem_open
      hxU (hS U hU)
    exact ⟨upperClosure V, ⟨V, hV, rfl⟩, subset_upperClosure hxV,
      upperClosure_min hVU ((isScottOpen_iff U).mp hU).1⟩
  have hBasis : @IsTopologicalBasis Q (scottTopology Q) B := by
    letI : TopologicalSpace Q := scottTopology Q
    exact isTopologicalBasis_of_isOpen_of_nhds hBopen hBlocal
  letI : TopologicalSpace Q := scottTopology Q
  exact ⟨⟨B, hBcount, hBasis.eq_generateFrom⟩⟩

theorem scott_secondCountable_of_compactMetricQuotient {M : Type u} {Q : Type v}
    [CompleteLattice M] [TopologicalSpace M] [CompactSpace M]
    [CompleteLattice Q] [TopologicalSpace Q] [CompactSpace Q] [MetrizableSpace Q]
    [OrderClosedTopology Q] [ContinuousInf Q]
    (q : CompleteLatticeHom M Q) (hq : Function.Surjective q) (hc : Continuous q)
    (hM : ∀ U : Set M, IsOpen[scottTopology M] U → IsOpen U) :
    @SecondCountableTopology Q (scottTopology Q) := by
  haveI : SecondCountableTopology Q := inferInstance
  exact scott_secondCountable_of_open_upper (scottOpen_isOpen_of_quotient q hq hc hM)

end GeneralWeb
end ScottSpectraReviewed
