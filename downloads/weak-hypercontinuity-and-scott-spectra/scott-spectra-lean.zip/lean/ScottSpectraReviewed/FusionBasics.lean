import ScottSpectraReviewed.TopologicalModels
import Mathlib.Data.Finset.Order

/-! Source `lem:fusion`, lines 628--649: the finite-lower-cover argument and
Scott closedness of the actual tail sets E_N. These are only prerequisites
of the full fusion identity, not a proof of the whole numbered lemma. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed

/-- The finite-union fact printed in the fusion proof, using a common upper
bound of finitely many chosen witnesses. -/
theorem directed_finite_lower_cover {P : Type u} [Preorder P] {ι : Type v}
    (D : Set P) (hD : NonemptyDirected D) (J : Finset ι) (C : ι → Set P)
    (hlower : ∀ i ∈ J, IsLowerSet (C i))
    (hcover : D ⊆ ⋃ i ∈ J, C i) : ∃ i ∈ J, D ⊆ C i := by
  classical
  letI : Nonempty D := hD.1.to_subtype
  letI : IsDirectedOrder D := hD.2.isDirectedOrder
  by_contra hnone
  have hbad : ∀ i : J, ∃ d : D, (d : P) ∉ C i := by
    intro i
    by_contra h
    apply hnone
    refine ⟨i,i.property,?_⟩
    intro d hd
    by_contra hdC
    exact h ⟨⟨d,hd⟩,hdC⟩
  choose f hf using hbad
  obtain ⟨d,hd⟩ := (Finset.univ.image f).exists_le
  obtain ⟨i,hi,hdi⟩ := mem_iUnion₂.mp (hcover d.property)
  exact hf ⟨i,hi⟩ (hlower i hi
    (hd (f ⟨i,hi⟩) (Finset.mem_image.mpr ⟨⟨i,hi⟩,Finset.mem_univ _,rfl⟩)) hdi)

namespace ClosedLattice

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance fusionTailSpecializationOrder : PartialOrder X := specializationOrder X

theorem eta_le_iff (x : X) (C : Carrier X) : eta x ≤ C ↔ x ∈ C := by
  constructor
  · intro h
    exact h (subset_closure (mem_singleton x))
  · intro h
    exact closure_minimal (singleton_subset_iff.mpr h) C.isClosed

theorem eta_le_eta_iff (x y : X) : eta x ≤ eta y ↔ x ≤ y := by
  rw [eta_le_iff]
  exact specializes_iff_mem_closure.symm

/-- The literal tail set E_N in source equation following line 625. -/
def fusionTail (F : Carrier X) (b : ℕ → X) (N : ℕ) : Set (Carrier X) :=
  {C | C ≤ F ∨ ∃ n, N ≤ n ∧ C ≤ eta (b n)}

theorem fusionTail_isLowerSet (F : Carrier X) (b : ℕ → X) (N : ℕ) :
    IsLowerSet (fusionTail F b N) := by
  intro C D hCD hD
  rcases hD with hDF | ⟨n,hn,hDn⟩
  · exact Or.inl (hCD.trans hDF)
  · exact Or.inr ⟨n,hn,hCD.trans hDn⟩

/-- Exactly the cofinal finite-principal-lower argument of the source.
Neither eta continuity nor core compactness is needed for this internal step. -/
theorem fusionTail_isScottClosed (A : ℕ → Set X) (hA : Antitone A)
    (hlower : ∀ n, IsLowerSet (A n)) (U : Opens X)
    (houtside : ∀ x ∈ U, ∃ n, x ∉ A n)
    (b : ℕ → X) (hb : ∀ n, b n ∈ A n) (N : ℕ) :
    IsClosed[scottTopology (Carrier X)] (fusionTail U.compl b N) := by
  classical
  apply (isScottClosed_iff _).mpr
  refine ⟨fusionTail_isLowerSet _ _ _, ?_⟩
  intro D hDE hne hdir C hC
  by_cases hCF : C ≤ U.compl
  · exact Or.inl hCF
  have hex : ∃ C₀ ∈ D, ¬C₀ ≤ U.compl := by
    by_contra h
    apply hCF
    apply hC.2
    intro Q hQ
    by_contra hQF
    exact h ⟨Q,hQ,hQF⟩
  obtain ⟨C₀,hC₀D,hC₀F⟩ := hex
  have hexpoint : ∃ e, e ∈ C₀ ∧ e ∈ U := by
    by_contra h
    apply hC₀F
    intro e heC heU
    exact h ⟨e,heC,heU⟩
  obtain ⟨e,heC₀,heU⟩ := hexpoint
  obtain ⟨m,hem⟩ := houtside e heU
  let D' : Set (Carrier X) := D ∩ Ici C₀
  have hD' : NonemptyDirected D' := by
    refine ⟨⟨C₀,?_⟩, ?_⟩
    · change C₀ ∈ D ∧ C₀ ≤ C₀
      exact ⟨hC₀D,le_rfl⟩
    · intro Q hQ R hR
      obtain ⟨S,hSD,hQS,hRS⟩ := hdir Q hQ.1 R hR.1
      exact ⟨S,⟨hSD,hQ.2.trans hQS⟩,hQS,hRS⟩
  let J := (Finset.range m).filter (fun n => N ≤ n)
  have hcover : D' ⊆ ⋃ n ∈ J, Iic (eta (b n)) := by
    intro Q hQ
    rcases hDE hQ.1 with hQF | ⟨n,hNn,hQn⟩
    · exact False.elim (hC₀F (hQ.2.trans hQF))
    · have hen : e ≤ b n := specializes_iff_mem_closure.mpr (hQn (hQ.2 heC₀))
      have hnm : n < m := by
        by_contra h
        have hmn : m ≤ n := Nat.le_of_not_gt h
        exact hem (hlower m hen (hA hmn (hb n)))
      exact mem_iUnion₂.mpr ⟨n,Finset.mem_filter.mpr ⟨Finset.mem_range.mpr hnm,hNn⟩,hQn⟩
  obtain ⟨n,hnJ,hbound⟩ := directed_finite_lower_cover D' hD' J
    (fun n => Iic (eta (b n))) (fun n _ => isLowerSet_Iic _) hcover
  refine Or.inr ⟨n,(Finset.mem_filter.mp hnJ).2,?_⟩
  apply hC.2
  intro Q hQD
  obtain ⟨R,hRD,hQR,hC₀R⟩ := hdir Q hQD C₀ hC₀D
  exact hQR.trans (hbound ⟨hRD,hC₀R⟩)

theorem eta_preimage_fusionTail (F : Carrier X) (b : ℕ → X) (N : ℕ) :
    eta ⁻¹' fusionTail F b N = (F : Set X) ∪ ⋃ n ≥ N, Iic (b n) := by
  ext x
  have hm : ∀ y : X, x ∈ eta y ↔ x ≤ y := fun y => specializes_iff_mem_closure.symm
  simp only [mem_preimage, fusionTail, mem_setOf_eq, eta_le_iff,
    hm,mem_union, mem_iUnion, mem_Iic,exists_prop]
  rfl

end ClosedLattice
end ScottSpectraReviewed
