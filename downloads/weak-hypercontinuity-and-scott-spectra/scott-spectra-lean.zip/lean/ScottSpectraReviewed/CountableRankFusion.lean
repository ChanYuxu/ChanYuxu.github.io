import ScottSpectraReviewed.Fusion
import ScottSpectraReviewed.CountableOrdinals
import Mathlib.Order.SuccPred.CompleteLinearOrder

/-! Source thm:countable, lines768--823: the actual neighborhood-rank
minima, ordinal stabilization, zero/successor/limit cases and final fusion
contradiction. This is an internal conditional helper: the actual Borel
relation, well-founded rank and its countable bound are constructed separately.
No conditional helper is presented as the source-facing countable theorem. -/

noncomputable section
open Set TopologicalSpace Ordinal Order
open scoped Topology Cardinal
universe u

namespace ScottSpectraReviewed
namespace Countable

def level {X : Type u} (G S : Set X) (V : ℕ → Set X) (n : ℕ) : Set X :=
  (G ∩ S) ∩ V n

def lowerHull {X : Type u} [Preorder X] (T : Set X) : Set X :=
  {b | ∃ a ∈ T, b ≤ a}

theorem lowerHull_isLowerSet {X : Type u} [Preorder X] (T : Set X) :
    IsLowerSet (lowerHull T) := by
  rintro b c hbc ⟨a, ha, hca⟩
  exact ⟨a, ha, hbc.trans hca⟩

def neighborhoodRank {X : Type u} (r : X → Ordinal) (T U : Set X) : Ordinal :=
  sSup (r '' (T ∩ U))

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance countableRankSpecializationOrder : PartialOrder X := specializationOrder X

/-- The exact source rank/fusion argument, before the actual analytic rank
is supplied. All ordinal suprema are genuine bounded suprema, including ranks
over uncountable sets of points. -/
theorem rank_fusion_impossible (hcore : IsCoreCompact X)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (x : X) (G S : Set X) (hS : IsLowerSet S) (V : ℕ → Set X)
    (hV : ∀ n, IsOpen (V n)) (hxV : ∀ n, x ∈ V n) (hVanti : Antitone V)
    (hclosure : ∀ n, x ∈ closure (level G S V n))
    (hGcore : ∀ (y : X) (U : Set X), IsOpen U → y ∈ U →
      ∃ g ∈ G, g ∈ U ∧ g ≤ y)
    (r : ℕ → X → Ordinal) (γbound : Ordinal) (hγbound : γbound < ω₁)
    (hbound : ∀ n a, r n a < γbound)
    (hstep : ∀ n a b, a ∈ level G S V n → b ∈ level G S V (n + 1) →
      a ≤ b → r (n + 1) b < r n a) : False := by
  classical
  let T : ℕ → Set X := level G S V
  have hTanti : Antitone T := by
    intro n m hnm a ha
    exact ⟨ha.1, hVanti hnm ha.2⟩
  let ρ : ℕ → Set X → Ordinal := fun n U => neighborhoodRank (r n) (T n) U
  have hrangeBound (n : ℕ) (U : Set X) : BddAbove (r n '' (T n ∩ U)) := by
    refine ⟨γbound, ?_⟩
    rintro _ ⟨a, ha, rfl⟩
    exact (hbound n a).le
  have hρbound (n : ℕ) (U : Set X) : ρ n U ≤ γbound := by
    apply csSup_le'
    rintro _ ⟨a, ha, rfl⟩
    exact (hbound n a).le
  have hrle (n : ℕ) (U : Set X) {a : X} (haT : a ∈ T n) (haU : a ∈ U) :
      r n a ≤ ρ n U :=
    le_csSup (hrangeBound n U) ⟨a, ⟨haT, haU⟩, rfl⟩
  have hρmono (n : ℕ) {U W : Set X} (hUW : U ⊆ W) : ρ n U ≤ ρ n W := by
    apply csSup_le_csSup' (hrangeBound n W)
    rintro _ ⟨a, ⟨haT, haU⟩, rfl⟩
    exact ⟨a, ⟨haT, hUW haU⟩, rfl⟩
  have hminExists : ∀ n : ℕ, ∃ U : Set X, IsOpen U ∧ x ∈ U ∧
      ∀ W : Set X, IsOpen W → x ∈ W → ρ n U ≤ ρ n W := by
    intro n
    let values : Set Ordinal := {α | ∃ U : Set X, IsOpen U ∧ x ∈ U ∧ ρ n U = α}
    have hne : values.Nonempty := ⟨ρ n univ, univ, isOpen_univ, mem_univ x, rfl⟩
    obtain ⟨α, ⟨U, hU, hxU, rfl⟩, hmin⟩ := Ordinal.lt_wf.has_min values hne
    exact ⟨U, hU, hxU, fun W hW hxW =>
      le_of_not_gt (hmin (ρ n W) ⟨W, hW, hxW, rfl⟩)⟩
  choose U hU hxU hmin using hminExists
  let β : ℕ → Ordinal := fun n => ρ n (U n)
  have hlocal (n : ℕ) (W : Set X) (hW : IsOpen W) (hxW : x ∈ W) (hWU : W ⊆ U n) :
      ρ n W = β n :=
    le_antisymm (hρmono n hWU) (hmin n W hW hxW)
  have hβstep : ∀ n : ℕ, β (n + 1) ≤ β n := by
    intro n
    have heq := hlocal (n + 1) (U n ∩ U (n + 1))
      ((hU n).inter (hU (n + 1))) ⟨hxU n, hxU (n + 1)⟩ inter_subset_right
    rw [← heq]
    apply csSup_le'
    rintro _ ⟨a, ⟨haT, haU⟩, rfl⟩
    have haTprev : a ∈ T n := hTanti (Nat.le_succ n) haT
    exact (hstep n a a haTprev haT le_rfl).le.trans (hrle n (U n) haTprev haU.1)
  obtain ⟨N, hstable⟩ := CountableRank.antitone_eventually_constant β
    (antitone_nat_of_succ_le hβstep)
  let limitOrdinal : Ordinal := β N
  have hLimitCountable : limitOrdinal < ω₁ := (hρbound N (U N)).trans_lt hγbound
  have hβN : β N = limitOrdinal := rfl
  have hβN1 : β (N + 1) = limitOrdinal := hstable (N + 1) (Nat.le_succ N)
  let W : Set X := U N ∩ U (N + 1)
  have hW : IsOpen W := (hU N).inter (hU (N + 1))
  have hxW : x ∈ W := ⟨hxU N, hxU (N + 1)⟩
  have hρW : ρ (N + 1) W = limitOrdinal :=
    (hlocal (N + 1) W hW hxW inter_subset_right).trans hβN1
  have hLimit : IsSuccLimit limitOrdinal := by
    rcases Ordinal.zero_or_succ_or_isSuccLimit limitOrdinal with hzero | ⟨α, hsucc⟩ | hlim
    · obtain ⟨a, haW, haT⟩ := mem_closure_iff.mp (hclosure (N + 1)) W hW hxW
      have hlt : r (N + 1) a < limitOrdinal :=
        (hstep N a a (hTanti (Nat.le_succ N) haT) haT le_rfl).trans_le
          (hrle N (U N) (hTanti (Nat.le_succ N) haT) haW.1)
      exact False.elim (not_lt_of_ge (zero_le _) (hzero ▸ hlt))
    · have hα : α < ρ (N + 1) W := by
        rw [hρW, ← hsucc]
        exact Order.lt_succ α
      obtain ⟨_, ⟨a, ⟨haT, haW⟩, rfl⟩, hαa⟩ :=
        (lt_csSup_iff' (hrangeBound (N + 1) W)).mp hα
      have hLimitLe : limitOrdinal ≤ r (N + 1) a := hsucc ▸ Order.succ_le_of_lt hαa
      have hlt : r (N + 1) a < limitOrdinal :=
        (hstep N a a (hTanti (Nat.le_succ N) haT) haT le_rfl).trans_le
          (hrle N (U N) (hTanti (Nat.le_succ N) haT) haW.1)
      exact False.elim (not_lt_of_ge hLimitLe hlt)
    · exact hlim
  obtain ⟨γ, hγmono, hγlt, hγcofinal, hγsup⟩ :=
    CountableRank.exists_monotone_cofinal_sequence limitOrdinal hLimit hLimitCountable
  let n : ℕ := N + 1
  have hβnext : β (n + 1) = limitOrdinal := hstable (n + 1) (by dsimp [n]; omega)
  have hstrict {g : X} (hgT : g ∈ T n) (hgU : g ∈ U N) : r n g < limitOrdinal := by
    exact (hstep N g g (hTanti (Nat.le_succ N) hgT) hgT le_rfl).trans_le
      (hrle N (U N) (hTanti (Nat.le_succ N) hgT) hgU)
  let thresholds : ℕ → Set X := fun k =>
    {a | a ∈ T (n + 1) ∧ a ∈ U (n + 1) ∧ γ k ≤ r (n + 1) a}
  let A : ℕ → Set X := fun k => lowerHull (thresholds k)
  have hAanti : Antitone A := by
    intro k l hkl b hb
    obtain ⟨a, ha, hba⟩ := hb
    exact ⟨a, ⟨ha.1, ha.2.1, (hγmono hkl).trans ha.2.2⟩, hba⟩
  have hAlower : ∀ k, IsLowerSet (A k) := fun k => lowerHull_isLowerSet _
  have hAS : ∀ k, A k ⊆ S := by
    rintro k b ⟨a, ha, hba⟩
    exact hS hba ha.1.1.2
  have hxA : ∀ k, x ∈ closure (A k) := by
    intro k
    apply mem_closure_iff.mpr
    intro O hO hxO
    have hρO : ρ (n + 1) (O ∩ U (n + 1)) = limitOrdinal :=
      (hlocal (n + 1) _ (hO.inter (hU (n + 1)))
        ⟨hxO, hxU (n + 1)⟩ inter_subset_right).trans hβnext
    have hγρ : γ k < ρ (n + 1) (O ∩ U (n + 1)) := hρO ▸ hγlt k
    obtain ⟨_, ⟨a, ⟨haT, haO⟩, rfl⟩, hγa⟩ :=
      (lt_csSup_iff' (hrangeBound (n + 1) (O ∩ U (n + 1)))).mp hγρ
    exact ⟨a, haO.1, a, ⟨haT, haO.2, hγa.le⟩, le_rfl⟩
  have hxFusion : x ∈ closure (⋂ k, A k) := by
    rw [source_fusion hcore hη A hAanti hAlower]
    exact mem_iInter.mpr hxA
  obtain ⟨b, hbU, hbA⟩ := mem_closure_iff.mp hxFusion
    (U N ∩ V n) ((hU N).inter (hV n)) ⟨hxU N, hxV n⟩
  obtain ⟨g, hgG, hgU, hgb⟩ := hGcore b (U N ∩ V n)
    ((hU N).inter (hV n)) hbU
  have hgS : g ∈ S := hS hgb (hAS 0 (mem_iInter.mp hbA 0))
  have hgT : g ∈ T n := ⟨⟨hgG, hgS⟩, hgU.2⟩
  have hgrank : r n g < limitOrdinal := hstrict hgT hgU.1
  have hγrank : ∀ k, γ k + 1 ≤ r n g := by
    intro k
    obtain ⟨a, ha, hba⟩ := mem_iInter.mp hbA k
    have hlt : r (n + 1) a < r n g := hstep n g a hgT ha.1 (hgb.trans hba)
    exact add_one_le_iff.mpr (ha.2.2.trans_lt hlt)
  have hLimitRank : limitOrdinal ≤ r n g := by
    rw [← hγsup]
    exact Ordinal.iSup_le hγrank
  exact not_lt_of_ge hLimitRank hgrank

end Countable
end ScottSpectraReviewed
