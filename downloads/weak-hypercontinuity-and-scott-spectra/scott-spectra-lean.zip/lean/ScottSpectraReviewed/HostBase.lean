import ScottSpectraReviewed.HostDefinitions
import ScottSpectraReviewed.ContinuousProducts
import ScottSpectraReviewed.ContinuousFrame
import ScottSpectraReviewed.CompactOrdered
import ScottSpectraReviewed.Separation
import Mathlib.Order.SupClosed
import Mathlib.Topology.Order.Lattice

/-! The exact Lawson-closure host in source Lemma `lem:hostbase`.
The carrier and subspace topology are those of `HostDefinitions`; completeness
is constructed from proved closure under pointwise arbitrary meets, not stored
in a model assumption. The complete-lattice definition depends explicitly on
the original three standing hypotheses and retains the pointwise subtype order.
-/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace HostCarrier

variable {L : Type u} [CompleteLattice L]

theorem ambientTopology_eq_lawson (hL : HostSectionContext L) :
    hostAmbientTopology L = lawsonTopology (L → L) :=
  (continuousLattice_endofunction_lawsonTopology_eq hL.1).symm

theorem ambient_compactSpace (hL : HostSectionContext L) :
    @CompactSpace (L → L) (hostAmbientTopology L) := by
  rw [ambientTopology_eq_lawson hL]
  exact lawson_compactSpace

theorem ambient_t2Space (hL : HostSectionContext L) :
    @T2Space (L → L) (hostAmbientTopology L) := by
  rw [ambientTopology_eq_lawson hL]
  exact lawson_t2Space (continuousLattice_endofunction hL.1)

theorem ambient_orderClosed (hL : HostSectionContext L) :
    @OrderClosedTopology (L → L) (hostAmbientTopology L) _ := by
  rw [ambientTopology_eq_lawson hL]
  exact lawson_orderClosed (continuousLattice_endofunction hL.1)

theorem ambient_continuous_inf (hL : HostSectionContext L) :
    @Continuous ((L → L) × (L → L)) (L → L)
      (@instTopologicalSpaceProd (L → L) (L → L)
        (hostAmbientTopology L) (hostAmbientTopology L))
      (hostAmbientTopology L) (fun p => p.1 ⊓ p.2) := by
  rw [ambientTopology_eq_lawson hL]
  exact continuousLattice_lawson_inf (continuousLattice_endofunction hL.1)

theorem joinTranslation_inf (hL : HostSectionContext L) (a b : L) :
    joinTranslation (a ⊓ b) = joinTranslation a ⊓ joinTranslation b := by
  letI : DistribLattice L := DistribLattice.ofInfSupLe
    (fun x y z => (hL.2.1.isDistributive x y z).le)
  funext x
  exact sup_inf_right a b x

theorem hostSet_infClosed (hL : HostSectionContext L) : InfClosed (hostSet L) := by
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  intro f hf g hg
  change f ⊓ g ∈ closure (range (joinTranslation (L := L)))
  apply map_mem_closure₂ (ambient_continuous_inf hL) hf hg
  rintro _ ⟨a, rfl⟩ _ ⟨b, rfl⟩
  exact ⟨a ⊓ b, joinTranslation_inf hL a b⟩

theorem hostSet_top_mem : (⊤ : L → L) ∈ hostSet L := by
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  apply subset_closure
  refine ⟨⊤, ?_⟩
  funext x
  exact top_sup_eq x

theorem hostSet_sSup_mem (hL : HostSectionContext L) (D : Set (L → L))
    (hD : NonemptyDirected D) (hDT : D ⊆ hostSet L) : sSup D ∈ hostSet L := by
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  letI : CompactSpace (L → L) := ambient_compactSpace hL
  letI : OrderClosedTopology (L → L) := ambient_orderClosed hL
  letI : Nonempty D := hD.1.to_subtype
  letI : IsDirectedOrder D := hD.2.isDirectedOrder
  exact isClosed_hostSet.mem_of_tendsto
    (CompactOrdered.tendsto_directed D hD (isLUB_sSup D))
    (Eventually.of_forall fun d => hDT d.property)

theorem hostSet_sInf_mem (hL : HostSectionContext L) (S : Set (L → L))
    (hST : S ⊆ hostSet L) : sInf S ∈ hostSet L := by
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  letI : CompactSpace (L → L) := ambient_compactSpace hL
  letI : OrderClosedTopology (L → L) := ambient_orderClosed hL
  let D : Set (L → L) := finiteJoins (L := (L → L)ᵒᵈ) S
  have hD : NonemptyFiltered D := finiteJoins_nonemptyDirected (L := (L → L)ᵒᵈ) S
  have hDT : D ⊆ hostSet L := by
    rintro _ ⟨F, hF, hFS, rfl⟩
    exact (hostSet_infClosed hL).sInf_mem hF hostSet_top_mem (hFS.trans hST)
  have hglb : IsGLB D (sInf S) := finiteJoins_isLUB (L := (L → L)ᵒᵈ) S
  letI : Nonempty D := hD.1.to_subtype
  letI : IsCodirectedOrder D := hD.2.isCodirectedOrder
  exact isClosed_hostSet.mem_of_tendsto
    (CompactOrdered.tendsto_filtered D hD hglb)
    (Eventually.of_forall fun d => hDT d.property)

/-- The actual host complete lattice, with pointwise arbitrary meets.
This is an explicit proof-dependent construction, not a global extra premise. -/
@[implicit_reducible]
def completeLattice (hL : HostSectionContext L) : CompleteLattice (HostCarrier L) := by
  letI : InfSet (HostCarrier L) := ⟨fun S =>
    ⟨sInf (Subtype.val '' S), hostSet_sInf_mem hL _ (by
      rintro _ ⟨t, _, rfl⟩
      exact t.property)⟩⟩
  apply completeLatticeOfInf (HostCarrier L)
  intro S
  constructor
  · intro t ht
    change sInf (Subtype.val '' S) ≤ (t : L → L)
    exact sInf_le ⟨t, ht, rfl⟩
  · intro t ht
    change (t : L → L) ≤ sInf (Subtype.val '' S)
    apply le_sInf
    rintro _ ⟨s, hs, rfl⟩
    exact ht hs

theorem coe_sInf (hL : HostSectionContext L) (S : Set (HostCarrier L)) :
    letI := completeLattice hL
    ((sInf S : HostCarrier L) : L → L) = sInf (Subtype.val '' S) := rfl

theorem coe_inf (hL : HostSectionContext L) (s t : HostCarrier L) :
    letI := completeLattice hL
    ((s ⊓ t : HostCarrier L) : L → L) = (s : L → L) ⊓ (t : L → L) := by
  letI := completeLattice hL
  change sInf (Subtype.val '' ({s, t} : Set (HostCarrier L))) = _
  rw [image_pair, sInf_pair]

theorem coe_top (hL : HostSectionContext L) :
    letI := completeLattice hL
    ((⊤ : HostCarrier L) : L → L) = ⊤ := by
  letI := completeLattice hL
  change sInf (Subtype.val '' (∅ : Set (HostCarrier L))) = _
  simp only [image_empty, sInf_empty]

theorem nonemptyDirected_coe (D : Set (HostCarrier L)) (hD : NonemptyDirected D) :
    NonemptyDirected (Subtype.val '' D : Set (L → L)) := by
  refine ⟨hD.1.image _, ?_⟩
  rintro _ ⟨a, ha, rfl⟩ _ ⟨b, hb, rfl⟩
  obtain ⟨c, hc, hac, hbc⟩ := hD.2 a ha b hb
  exact ⟨c.val, ⟨c, hc, rfl⟩, hac, hbc⟩

theorem coe_sSup_of_nonemptyDirected (hL : HostSectionContext L)
    (D : Set (HostCarrier L)) :
    letI := completeLattice hL
    NonemptyDirected D →
      ((sSup D : HostCarrier L) : L → L) = sSup (Subtype.val '' D) := by
  letI := completeLattice hL
  intro hD
  let t : HostCarrier L := ⟨sSup (Subtype.val '' D),
    hostSet_sSup_mem hL _ (nonemptyDirected_coe D hD) (by
      rintro _ ⟨t, _, rfl⟩
      exact t.property)⟩
  have ht : IsLUB D t := by
    constructor
    · intro s hs
      change (s : L → L) ≤ sSup (Subtype.val '' D)
      exact le_sSup ⟨s, hs, rfl⟩
    · intro s hs
      change sSup (Subtype.val '' D) ≤ (s : L → L)
      apply sSup_le
      rintro _ ⟨d, hd, rfl⟩
      exact hs hd
  exact congrArg Subtype.val ((isLUB_sSup D).unique ht)

/-- The source reflection: meet of all host functions above the given full
ambient function. -/
def reflection (hL : HostSectionContext L) (f : L → L) : HostCarrier L :=
  letI := completeLattice hL
  sInf {t : HostCarrier L | f ≤ (t : L → L)}

theorem le_reflection_coe (hL : HostSectionContext L) (f : L → L) :
    f ≤ (reflection hL f : L → L) := by
  change f ≤ sInf (Subtype.val '' {t : HostCarrier L | f ≤ (t : L → L)})
  apply le_sInf
  rintro _ ⟨t, ht, rfl⟩
  exact ht

theorem reflection_le_iff (hL : HostSectionContext L) (f : L → L) (t : HostCarrier L) :
    reflection hL f ≤ t ↔ f ≤ (t : L → L) := by
  constructor
  · intro h
    exact (le_reflection_coe hL f).trans h
  · intro h
    change sInf (Subtype.val '' {s : HostCarrier L | f ≤ (s : L → L)}) ≤ (t : L → L)
    exact sInf_le ⟨t, h, rfl⟩

theorem reflection_coe (hL : HostSectionContext L) (t : HostCarrier L) :
    reflection hL (t : L → L) = t :=
  le_antisymm ((reflection_le_iff hL _ _).mpr le_rfl) (le_reflection_coe hL _)

theorem reflection_mono (hL : HostSectionContext L) : Monotone (reflection hL) := by
  intro f g hfg
  exact (reflection_le_iff hL f _).mpr (hfg.trans (le_reflection_coe hL g))

theorem coe_isLUB_of_nonemptyDirected (hL : HostSectionContext L)
    (D : Set (HostCarrier L)) (t : HostCarrier L) :
    letI := completeLattice hL
    NonemptyDirected D → IsLUB D t → IsLUB (Subtype.val '' D) (t : L → L) := by
  letI := completeLattice hL
  intro hD ht
  have heq : t = sSup D := ht.unique (isLUB_sSup D)
  rw [heq, coe_sSup_of_nonemptyDirected hL D hD]
  exact isLUB_sSup _

theorem reflection_wayBelow (hL : HostSectionContext L) {u : L → L} {t : HostCarrier L}
    (hu : WayBelow u (t : L → L)) :
    letI := completeLattice hL
    WayBelow (reflection hL u) t := by
  letI := completeLattice hL
  intro D hD s hs hts
  obtain ⟨_, ⟨d, hd, rfl⟩, hud⟩ := hu _ (nonemptyDirected_coe D hD) _
    (coe_isLUB_of_nonemptyDirected hL D s hD hs) hts
  exact ⟨d, hd, (reflection_le_iff hL u d).mpr hud⟩

/-- Continuity of the literal host via the source's reflective-sub-dcpo proof. -/
theorem isContinuousLattice (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsContinuousLattice (HostCarrier L) := by
  letI := completeLattice hL
  have hZ := continuousLattice_endofunction hL.1
  refine ⟨completeLattice_isDcpo _, fun t => ?_⟩
  let A : Set (HostCarrier L) := reflection hL '' {u | WayBelow u (t : L → L)}
  have hA : NonemptyDirected A := by
    refine ⟨(hZ.2 (t : L → L)).1.1.image _, ?_⟩
    rintro _ ⟨u, hu, rfl⟩ _ ⟨v, hv, rfl⟩
    obtain ⟨w, hw, huw, hvw⟩ := (hZ.2 (t : L → L)).1.2 u hu v hv
    exact ⟨reflection hL w, ⟨w, hw, rfl⟩,
      reflection_mono hL huw, reflection_mono hL hvw⟩
  have hAsup : IsLUB A t := by
    constructor
    · rintro _ ⟨u, hu, rfl⟩
      exact (reflection_le_iff hL u t).mpr (wayBelow_le hu)
    · intro s hs
      change (t : L → L) ≤ (s : L → L)
      apply (hZ.2 (t : L → L)).2.2
      intro u hu
      exact (le_reflection_coe hL u).trans (hs ⟨u, hu, rfl⟩)
  have hAwb : A ⊆ {s | WayBelow s t} := by
    rintro _ ⟨u, hu, rfl⟩
    exact reflection_wayBelow hL hu
  constructor
  · constructor
    · obtain ⟨s, hs⟩ := hA.1
      exact ⟨s, hAwb hs⟩
    · intro a ha b hb
      obtain ⟨s, hs, has⟩ := ha A hA t hAsup le_rfl
      obtain ⟨r, hr, hbr⟩ := hb A hA t hAsup le_rfl
      obtain ⟨z, hz, hsz, hrz⟩ := hA.2 s hs r hr
      exact ⟨z, hAwb hz, has.trans hsz, hbr.trans hrz⟩
  · exact ⟨fun s hs => wayBelow_le hs, fun s hs => hAsup.2 (fun r hr => hs (hAwb hr))⟩

theorem monotone (hL : HostSectionContext L) (t : HostCarrier L) :
    Monotone (t : L → L) := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  letI : OrderClosedTopology L := lawson_orderClosed hL.1
  intro x y hxy
  exact (closure_minimal
    (by rintro _ ⟨a, rfl⟩; exact sup_le_sup_left hxy a)
    (isClosed_le (continuous_apply x) (continuous_apply y))) t.property

theorem inflationary (hL : HostSectionContext L) (t : HostCarrier L) (x : L) :
    x ≤ (t : L → L) x := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  letI : OrderClosedTopology L := lawson_orderClosed hL.1
  exact (closure_minimal
    (by rintro _ ⟨a, rfl⟩; exact le_sup_right)
    (isClosed_le continuous_const (continuous_apply x))) t.property

theorem preserves_inf (hL : HostSectionContext L) (t : HostCarrier L) (x y : L) :
    (t : L → L) (x ⊓ y) = (t : L → L) x ⊓ (t : L → L) y := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  letI : T2Space L := lawson_t2Space hL.1
  letI : ContinuousInf L := ⟨continuousLattice_lawson_inf hL.1⟩
  letI : DistribLattice L := DistribLattice.ofInfSupLe
    (fun a b c => (hL.2.1.isDistributive a b c).le)
  exact (closure_minimal
    (by rintro _ ⟨a, rfl⟩; exact sup_inf_left a x y)
    (isClosed_eq (continuous_apply (x ⊓ y))
      ((continuous_apply x).inf (continuous_apply y)))) t.property

theorem preserves_top (hL : HostSectionContext L) (t : HostCarrier L) :
    (t : L → L) ⊤ = ⊤ :=
  top_le_iff.mp (inflationary hL t ⊤)

/-- The source's adjunction `h(a) ≤ t ↔ a ≤ t(0)`. -/
theorem translation_le_iff (hL : HostSectionContext L) (a : L) (t : HostCarrier L) :
    translation a ≤ t ↔ a ≤ (t : L → L) ⊥ := by
  constructor
  · intro h
    simpa only [translation_bot] using h ⊥
  · intro h x
    exact sup_le (h.trans (monotone hL t bot_le)) (inflationary hL t x)

theorem translation_galoisConnection (hL : HostSectionContext L) :
    GaloisConnection (translation (L := L)) (fun t : HostCarrier L => (t : L → L) ⊥) :=
  fun a t => translation_le_iff hL a t

theorem translation_sSup (hL : HostSectionContext L) (S : Set L) :
    letI := completeLattice hL
    translation (sSup S) = sSup (translation '' S) := by
  letI := completeLattice hL
  simpa only [sSup_image] using (translation_galoisConnection hL).l_sSup (s := S)

theorem translation_inf (hL : HostSectionContext L) (a b : L) :
    letI := completeLattice hL
    translation (a ⊓ b) = translation a ⊓ translation b := by
  letI := completeLattice hL
  apply Subtype.ext
  rw [coe_inf hL]
  exact joinTranslation_inf hL a b

theorem translation_top (hL : HostSectionContext L) :
    letI := completeLattice hL
    translation (⊤ : L) = ⊤ := by
  letI := completeLattice hL
  apply Subtype.ext
  rw [coe_top hL]
  funext x
  exact top_sup_eq x

/-- The actual join-translation map, bundled with proved frame-hom laws. -/
def frameHom (hL : HostSectionContext L) :
    letI := completeLattice hL
    FrameHom L (HostCarrier L) := by
  letI := completeLattice hL
  exact { toFun := translation
          map_top' := translation_top hL
          map_inf' := translation_inf hL
          map_sSup' := translation_sSup hL }

theorem translation_wayBelow (hL : HostSectionContext L) {a b : L} (hab : WayBelow a b) :
    letI := completeLattice hL
    WayBelow (translation a) (translation b) := by
  letI := completeLattice hL
  intro D hD t ht hbt
  have hDr : NonemptyDirected ((fun s : HostCarrier L => (s : L → L) ⊥) '' D) := by
    simpa only [image_image, Function.comp_def] using
      nonemptyDirected_pi_eval (Subtype.val '' D) (nonemptyDirected_coe D hD) (⊥ : L)
  have htr : IsLUB ((fun s : HostCarrier L => (s : L → L) ⊥) '' D) ((t : L → L) ⊥) := by
    simpa only [image_image, Function.comp_def] using
      (isLUB_pi.mp (coe_isLUB_of_nonemptyDirected hL D t hD ht)) (⊥ : L)
  obtain ⟨_, ⟨d, hd, rfl⟩, had⟩ :=
    hab _ hDr _ htr ((translation_le_iff hL b t).mp hbt)
  exact ⟨d, hd, (translation_le_iff hL a d).mpr had⟩

/-- The source's left adjoint to evaluation at a fixed coordinate. -/
def evaluationLeftAdjoint (hL : HostSectionContext L) (x a : L) : HostCarrier L :=
  letI := completeLattice hL
  sInf {t : HostCarrier L | a ≤ (t : L → L) x}

theorem le_evaluationLeftAdjoint (hL : HostSectionContext L) (x a : L) :
    a ≤ (evaluationLeftAdjoint hL x a : L → L) x := by
  change a ≤ (sInf (Subtype.val '' {t : HostCarrier L | a ≤ (t : L → L) x})) x
  rw [sInf_apply_eq_sInf_image]
  apply le_sInf
  rintro _ ⟨f, ⟨t, ht, rfl⟩, rfl⟩
  exact ht

theorem evaluationLeftAdjoint_le_iff (hL : HostSectionContext L) (x a : L)
    (t : HostCarrier L) :
    evaluationLeftAdjoint hL x a ≤ t ↔ a ≤ (t : L → L) x := by
  constructor
  · intro h
    exact (le_evaluationLeftAdjoint hL x a).trans (h x)
  · intro h
    change sInf (Subtype.val '' {s : HostCarrier L | a ≤ (s : L → L) x}) ≤ (t : L → L)
    exact sInf_le ⟨t, h, rfl⟩

theorem evaluation_isLUB_of_nonemptyDirected (hL : HostSectionContext L) (x : L)
    (D : Set (HostCarrier L)) (t : HostCarrier L) :
    letI := completeLattice hL
    NonemptyDirected D → IsLUB D t →
      IsLUB ((fun s : HostCarrier L => (s : L → L) x) '' D) ((t : L → L) x) := by
  letI := completeLattice hL
  intro hD ht
  simpa only [image_image, Function.comp_def] using
    (isLUB_pi.mp (coe_isLUB_of_nonemptyDirected hL D t hD ht)) x

theorem evaluation_nonemptyDirected (x : L) (D : Set (HostCarrier L))
    (hD : NonemptyDirected D) :
    NonemptyDirected ((fun s : HostCarrier L => (s : L → L) x) '' D) := by
  simpa only [image_image, Function.comp_def] using
    nonemptyDirected_pi_eval (Subtype.val '' D) (nonemptyDirected_coe D hD) x

theorem continuous_scott_evaluation (hL : HostSectionContext L) (x : L) :
    letI := completeLattice hL
    @Continuous (HostCarrier L) L (scottTopology (HostCarrier L)) (scottTopology L)
      (fun t : HostCarrier L => (t : L → L) x) := by
  letI := completeLattice hL
  apply continuous_def.mpr
  intro U hU
  apply (isScottOpen_iff _).mpr
  constructor
  · intro s t hst hs
    exact ((isScottOpen_iff U).mp hU).1 (hst x) hs
  · intro D hDne hDdir t ht htU
    have hDi := evaluation_nonemptyDirected x D ⟨hDne, hDdir⟩
    obtain ⟨_, ⟨d, hd, rfl⟩, hdU⟩ :=
      ((isScottOpen_iff U).mp hU).2 hDi.1 hDi.2
        (evaluation_isLUB_of_nonemptyDirected hL x D t ⟨hDne, hDdir⟩ ht) htU
    exact ⟨d, hd, hdU⟩

theorem continuous_lawson_evaluation (hL : HostSectionContext L) (x : L) :
    letI := completeLattice hL
    @Continuous (HostCarrier L) L (lawsonTopology (HostCarrier L)) (lawsonTopology L)
      (fun t : HostCarrier L => (t : L → L) x) := by
  letI := completeLattice hL
  have hscott : @Continuous (HostCarrier L) L (lawsonTopology (HostCarrier L))
      (scottTopology L) (fun t : HostCarrier L => (t : L → L) x) :=
    continuous_le_dom
      (show lawsonTopology (HostCarrier L) ≤ scottTopology (HostCarrier L) from inf_le_right)
      (continuous_scott_evaluation hL x)
  have hlower : @Continuous (HostCarrier L) L (lawsonTopology (HostCarrier L))
      (Topology.lower L) (fun t : HostCarrier L => (t : L → L) x) := by
    apply continuous_generateFrom_iff.mpr
    rintro _ ⟨a, rfl⟩
    have hpre : (fun t : HostCarrier L => (t : L → L) x) ⁻¹' (Ici a)ᶜ =
        (Ici (evaluationLeftAdjoint hL x a))ᶜ := by
      ext t
      change (¬a ≤ (t : L → L) x) ↔ ¬evaluationLeftAdjoint hL x a ≤ t
      exact not_congr (evaluationLeftAdjoint_le_iff hL x a t).symm
    rw [hpre]
    exact isLawsonOpen_compl_Ici (evaluationLeftAdjoint hL x a)
  change @Continuous (HostCarrier L) L (lawsonTopology (HostCarrier L))
    (Topology.lower L ⊓ scottTopology L) (fun t : HostCarrier L => (t : L → L) x)
  exact continuous_inf_rng.mpr ⟨hlower, hscott⟩

/-- Intrinsic Lawson topology agrees with the exact product-Lawson subspace
topology of the source's closure carrier. -/
theorem lawsonTopology_eq_subspace (hL : HostSectionContext L) :
    letI := completeLattice hL
    lawsonTopology (HostCarrier L) = (inferInstance : TopologicalSpace (HostCarrier L)) := by
  letI := completeLattice hL
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  letI : T2Space (L → L) := ambient_t2Space hL
  have hinc : @Continuous (HostCarrier L) (L → L)
      (lawsonTopology (HostCarrier L)) (hostAmbientTopology L) Subtype.val :=
    @continuous_pi (HostCarrier L) L (fun _ => L) (lawsonTopology (HostCarrier L))
      (fun _ => lawsonTopology L) Subtype.val (fun x => continuous_lawson_evaluation hL x)
  have hId : @Continuous (HostCarrier L) (HostCarrier L)
      (lawsonTopology (HostCarrier L)) (inferInstance : TopologicalSpace (HostCarrier L)) id := by
    change @Continuous (HostCarrier L) (HostCarrier L) (lawsonTopology (HostCarrier L))
      (TopologicalSpace.induced Subtype.val (hostAmbientTopology L)) id
    exact continuous_induced_rng.mpr hinc
  have ht2 : T2Space (HostCarrier L) := inferInstance
  have hinv : @Continuous (HostCarrier L) (HostCarrier L)
      (inferInstance : TopologicalSpace (HostCarrier L)) (lawsonTopology (HostCarrier L)) id :=
    @Continuous.continuous_symm_of_equiv_compact_to_t2 (HostCarrier L) (HostCarrier L)
      (lawsonTopology (HostCarrier L)) (inferInstance : TopologicalSpace (HostCarrier L))
      lawson_compactSpace ht2 (Equiv.refl _) hId
  exact le_antisymm (continuous_id_iff_le.mp hId) (continuous_id_iff_le.mp hinv)

/-- Exact public interface of the printed host-base lemma. The only premises
are the three original section hypotheses. All host laws are proved above. -/
theorem source_hostbase (hL : HostSectionContext L) :
    letI := completeLattice hL
    IsContinuousLattice (HostCarrier L) ∧
    (∀ S : Set (HostCarrier L),
      ((sInf S : HostCarrier L) : L → L) = sInf (Subtype.val '' S)) ∧
    (∀ D : Set (HostCarrier L), NonemptyDirected D →
      ((sSup D : HostCarrier L) : L → L) = sSup (Subtype.val '' D)) ∧
    lawsonTopology (HostCarrier L) = (inferInstance : TopologicalSpace (HostCarrier L)) ∧
    Function.Injective (translation (L := L)) ∧
    (∀ S : Set L, translation (sSup S) = sSup (translation '' S)) ∧
    (∀ a b : L, translation (a ⊓ b) = translation a ⊓ translation b) ∧
    translation (⊤ : L) = ⊤ ∧
    (∀ a b : L, WayBelow a b → WayBelow (translation a) (translation b)) := by
  letI := completeLattice hL
  exact ⟨isContinuousLattice hL, coe_sInf hL, coe_sSup_of_nonemptyDirected hL,
    lawsonTopology_eq_subspace hL, translation_injective, translation_sSup hL,
    translation_inf hL, translation_top hL, fun _ _ h => translation_wayBelow hL h⟩

end HostCarrier
end ScottSpectraReviewed
