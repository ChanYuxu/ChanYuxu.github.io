import ScottSpectraReviewed.HostDefinitions
import ScottSpectraReviewed.LawsonBasics
import Mathlib.Topology.ClusterPt

/-! Source Lemma `lem:escape`. The sequence indices are the printed positive
natural numbers. Compactness is applied to the genuine sequence as an auxiliary
net only; no first-countability or sequential closure principle is assumed.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace HostCarrier

variable {L : Type u} [CompleteLattice L]

/-- The operative consequence of the actual dual-topology equality preceding
the escape lemma. -/
theorem isLawsonClosed_of_upper_filteredInfClosed (hL : HostSectionContext L)
    (E : Set L) (hupper : IsUpperSet E)
    (hInf : ∀ D : Set L, D ⊆ E → NonemptyFiltered D → sInf D ∈ E) :
    IsClosed[lawsonTopology L] E := by
  letI : TopologicalSpace L := lawsonTopology L
  have hdual : IsClosed[scottTopology Lᵒᵈ] E := by
    apply (isScottClosed_iff (P := Lᵒᵈ) E).mpr
    constructor
    · intro a b hab hb
      exact hupper hab hb
    · intro D hDE hne hdir x hx
      have heq : (x : L) = sInf (α := L) D :=
        (show IsGLB (α := L) D x from hx).unique (isGLB_sInf (α := L) D)
      rw [heq]
      exact hInf D hDE ⟨hne, hdir⟩
  have heq : scottTopology Lᵒᵈ = upperTopology Lᵒᵈ := hL.2.2
  rw [heq] at hdual
  exact isOpen_compl_iff.mp (Topology.lawson_le_lower _ hdual.isOpen_compl)

/-- Exactly `↑r ∪ ⋃ n ≥ 1, ↑dₙ` from the source. -/
def escapeUpper (r : L) (d : ℕ → L) : Set L :=
  {x | r ≤ x ∨ ∃ n : ℕ, 1 ≤ n ∧ d n ≤ x}

theorem escapeUpper_isClosed (hL : HostSectionContext L) (r : L) (d : ℕ → L)
    (hpair : ∀ n m : ℕ, 1 ≤ n → 1 ≤ m → n ≠ m → r ≤ d n ⊔ d m) :
    IsClosed[lawsonTopology L] (escapeUpper r d) := by
  apply isLawsonClosed_of_upper_filteredInfClosed hL
  · intro x y hxy hx
    rcases hx with hr | ⟨n, hn, hdn⟩
    · exact Or.inl (hr.trans hxy)
    · exact Or.inr ⟨n, hn, hdn.trans hxy⟩
  · intro D hDE hD
    by_cases hr : r ≤ sInf D
    · exact Or.inl hr
    have hex : ∃ z ∈ D, ¬r ≤ z := by
      by_contra! h
      exact hr (le_sInf h)
    obtain ⟨z, hz, hrz⟩ := hex
    have hzn : ∃ n : ℕ, 1 ≤ n ∧ d n ≤ z := by
      rcases hDE hz with h | h
      · exact False.elim (hrz h)
      · exact h
    obtain ⟨n, hn, hdnz⟩ := hzn
    refine Or.inr ⟨n, hn, le_sInf ?_⟩
    intro y hy
    obtain ⟨w, hw, hwy, hwz⟩ := hD.2 y hy z hz
    have hwr : ¬r ≤ w := fun h => hrz (h.trans hwz)
    have hwm : ∃ m : ℕ, 1 ≤ m ∧ d m ≤ w := by
      rcases hDE hw with h | h
      · exact False.elim (hwr h)
      · exact h
    obtain ⟨m, hm, hdmw⟩ := hwm
    have hnm : n = m := by
      by_contra hne
      exact hrz ((hpair n m hn hm hne).trans (sup_le hdnz (hdmw.trans hwz)))
    subst m
    exact hdmw.trans hwy

theorem no_excluded_sequence (hL : HostSectionContext L) (r : L) (d : ℕ → L)
    (hpair : ∀ n m : ℕ, 1 ≤ n → 1 ≤ m → n ≠ m → r ≤ d n ⊔ d m)
    (Wstar : Set L) (W : ℕ → Set L)
    (_hWstar : IsOpen[lawsonTopology L] Wstar)
    (_hW : ∀ n : ℕ, 1 ≤ n → IsOpen[lawsonTopology L] (W n))
    (hmem : ∀ n : ℕ, 1 ≤ n → d n ∈ Wstar ∧
      ∀ i : ℕ, 1 ≤ i → i < n → d n ∈ W i)
    (hstar : @closure L (lawsonTopology L) Wstar ∩ Ici r = ∅)
    (hsep : ∀ n : ℕ, 1 ≤ n → @closure L (lawsonTopology L) (W n) ∩ Ici (d n) = ∅) :
    False := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : CompactSpace L := lawson_compactSpace
  let f : ℕ → L := fun n => d (n + 1)
  obtain ⟨z, hz⟩ := exists_clusterPt_of_compactSpace (map f atTop)
  have hzE : z ∈ escapeUpper r d :=
    (escapeUpper_isClosed hL r d hpair).mem_of_mapClusterPt hz
      (Eventually.of_forall fun n => Or.inr ⟨n + 1, Nat.succ_le_succ (Nat.zero_le n), le_rfl⟩)
  have hzstar : z ∈ closure Wstar :=
    isClosed_closure.mem_of_mapClusterPt hz (Eventually.of_forall fun n =>
      subset_closure (hmem (n + 1) (Nat.succ_le_succ (Nat.zero_le n))).1)
  have hzW : ∀ n : ℕ, 1 ≤ n → z ∈ closure (W n) := by
    intro n hn
    apply isClosed_closure.mem_of_mapClusterPt hz
    apply (eventually_ge_atTop n).mono
    intro m hnm
    exact subset_closure ((hmem (m + 1) (Nat.succ_le_succ (Nat.zero_le m))).2
      n hn (Nat.lt_succ_of_le hnm))
  rcases hzE with hrz | ⟨n, hn, hdnz⟩
  · have h : z ∈ closure Wstar ∩ Ici r := ⟨hzstar, hrz⟩
    rw [hstar] at h
    exact h
  · have h : z ∈ closure (W n) ∩ Ici (d n) := ⟨hzW n hn, hdnz⟩
    rw [hsep n hn] at h
    exact h

/-- Exact original-facing escape lemma, including all original positive-index
and open-neighborhood requirements. -/
theorem source_escape (hL : HostSectionContext L) (r : L) (d : ℕ → L)
    (hpair : ∀ n m : ℕ, 1 ≤ n → 1 ≤ m → n ≠ m → r ≤ d n ⊔ d m) :
    IsClosed[lawsonTopology L] (escapeUpper r d) ∧
    ¬∃ (Wstar : Set L) (W : ℕ → Set L),
      IsOpen[lawsonTopology L] Wstar ∧
      (∀ n : ℕ, 1 ≤ n → IsOpen[lawsonTopology L] (W n)) ∧
      (∀ n : ℕ, 1 ≤ n → d n ∈ Wstar ∧
        ∀ i : ℕ, 1 ≤ i → i < n → d n ∈ W i) ∧
      (@closure L (lawsonTopology L) Wstar ∩ Ici r = ∅) ∧
      (∀ n : ℕ, 1 ≤ n → @closure L (lawsonTopology L) (W n) ∩ Ici (d n) = ∅) := by
  refine ⟨escapeUpper_isClosed hL r d hpair, ?_⟩
  rintro ⟨Wstar, W, hWstar, hW, hmem, hstar, hsep⟩
  exact no_excluded_sequence hL r d hpair Wstar W hWstar hW hmem hstar hsep

end HostCarrier
end ScottSpectraReviewed
