import ScottSpectraReviewed.PrimeElements

/-! The full source prime-element description (frozen TeX lines 226--243):
the two constructions are inverse, filter inclusion reverses prime-element
order, and the spectrum of Qᵒᵈ is the ordered space of nonzero coprimes of Q.
The coprime topology is specified by its own opens, not defined by transport. -/

noncomputable section
open Set
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace Spectrum

variable {L : Type u} [CompleteLattice L]

theorem compl_eq_Iic_primeElement (F : Spectrum L) :
    (F : Set L)ᶜ = Set.Iic F.primeElement := by
  ext a
  constructor
  · exact fun ha => le_sSup ha
  · exact fun hap ha => (F.mem_iff_not_le_primeElement a).mp ha hap

/-- The missing reverse identity for the source's explicit constructions. -/
@[simp] theorem primeElement_ofPrimeElement (p : L) (hp : IsProperMeetPrime p) :
    (ofPrimeElement p hp).primeElement = p := by
  classical
  apply le_antisymm
  · apply sSup_le
    intro a ha
    change ¬ ¬ a ≤ p at ha
    exact not_not.mp ha
  · apply le_sSup
    change ¬ ¬ p ≤ p
    exact not_not_intro le_rfl

theorem primeElement_le_iff (F G : Spectrum L) :
    F.primeElement ≤ G.primeElement ↔ G ≤ F := by
  constructor
  · intro hp a haG
    apply (F.mem_iff_not_le_primeElement a).mpr
    intro hap
    exact (G.mem_iff_not_le_primeElement a).mp haG (hap.trans hp)
  · intro hGF
    apply sSup_le
    intro a haF
    exact le_sSup (fun haG => haF (hGF haG))

/-- The genuine order anti-isomorphism with proper meet-prime elements. -/
def primeElementOrderIso : Spectrum L ≃o OrderDual {p : L // IsProperMeetPrime p} where
  toFun F := OrderDual.toDual ⟨F.primeElement, F.primeElement_isProperMeetPrime⟩
  invFun p := ofPrimeElement (OrderDual.ofDual p).1 (OrderDual.ofDual p).2
  left_inv := ofPrimeElement_primeElement
  right_inv p := by
    apply Subtype.ext
    exact primeElement_ofPrimeElement _ _
  map_rel_iff' := by
    intro F G
    exact primeElement_le_iff G F

@[simp] theorem primeElementOrderIso_apply (F : Spectrum L) :
    (OrderDual.ofDual (primeElementOrderIso F)).1 = F.primeElement := rfl

end Spectrum

/-- Source-facing inverse-construction and order statement on a frame. -/
theorem source_primeElement_equivalence {L : Type u} [CompleteLattice L]
    (hL : IsFrame L) :
    (∀ F : Spectrum L,
      Spectrum.ofPrimeElement F.primeElement F.primeElement_isProperMeetPrime = F) ∧
    (∀ (p : L) (hp : IsProperMeetPrime p),
      (Spectrum.ofPrimeElement p hp).primeElement = p) ∧
    (∀ F G : Spectrum L, F ≤ G ↔ G.primeElement ≤ F.primeElement) := by
  clear hL
  exact ⟨Spectrum.ofPrimeElement_primeElement, Spectrum.primeElement_ofPrimeElement,
    fun F G => (Spectrum.primeElement_le_iff G F).symm⟩

/-- Source equation `eq:cop-definition`: nonzero binary join-prime elements. -/
def IsCoprime {Q : Type u} [CompleteLattice Q] (p : Q) : Prop :=
  p ≠ ⊥ ∧ ∀ a b : Q, p ≤ a ⊔ b → p ≤ a ∨ p ≤ b

/-- The source's Pc(Q), with the inherited order from Q. -/
abbrev CoprimeElements (Q : Type u) [CompleteLattice Q] := {p : Q // IsCoprime p}

theorem isProperMeetPrime_dual_iff {Q : Type u} [CompleteLattice Q] (p : Q) :
    IsProperMeetPrime (OrderDual.toDual p) ↔ IsCoprime p := by
  change ((⊥ : Q) < p ∧ ∀ a b : Q, p ≤ a ⊔ b → p ≤ a ∨ p ≤ b) ↔ _
  rw [bot_lt_iff_ne_bot]
  rfl

/-- The specified prime-element map from Spec(Qᵒᵈ) to Pc(Q). -/
def spectrumCoprimeOrderIso (Q : Type u) [CompleteLattice Q] :
    Spectrum (OrderDual Q) ≃o CoprimeElements Q where
  toFun F := ⟨OrderDual.ofDual F.primeElement,
    (isProperMeetPrime_dual_iff _).mp F.primeElement_isProperMeetPrime⟩
  invFun p := Spectrum.ofPrimeElement (OrderDual.toDual p.1)
    ((isProperMeetPrime_dual_iff p.1).mpr p.2)
  left_inv F := Spectrum.ofPrimeElement_primeElement F
  right_inv p := by
    apply Subtype.ext
    exact Spectrum.primeElement_ofPrimeElement (L := OrderDual Q) _ _
  map_rel_iff' := by
    intro F G
    exact Spectrum.primeElement_le_iff G F

@[simp] theorem spectrumCoprimeOrderIso_apply {Q : Type u} [CompleteLattice Q]
    (F : Spectrum (OrderDual Q)) :
    (spectrumCoprimeOrderIso Q F).1 = OrderDual.ofDual F.primeElement := rfl

namespace CoprimeElements

variable {Q : Type u} [CompleteLattice Q]

/-- The explicit complement of a principal downset printed in the source. -/
def hat (a : Q) : Set (CoprimeElements Q) := {p | ¬ p.1 ≤ a}

@[simp] theorem hat_bot : hat (⊥ : Q) = Set.univ := by
  ext p
  simp only [hat, mem_setOf_eq, mem_univ, iff_true]
  intro hp
  exact p.2.1 (le_bot_iff.mp hp)

@[simp] theorem hat_top : hat (⊤ : Q) = ∅ := by
  ext p
  simp only [hat, mem_setOf_eq, mem_empty_iff_false, iff_false]
  exact not_not_intro le_top

theorem hat_sup (a b : Q) : hat (a ⊔ b) = hat a ∩ hat b := by
  ext p
  change (¬ p.1 ≤ a ⊔ b) ↔ (¬ p.1 ≤ a) ∧ ¬ p.1 ≤ b
  constructor
  · intro hp
    exact ⟨fun ha => hp (ha.trans le_sup_left), fun hb => hp (hb.trans le_sup_right)⟩
  · rintro ⟨ha, hb⟩ hp
    exact (p.2.2 a b hp).elim ha hb

theorem hat_sInf (S : Set Q) : hat (sInf S) = ⋃ a ∈ S, hat a := by
  classical
  ext p
  simp only [hat, mem_setOf_eq, le_sInf_iff, not_forall, mem_iUnion, exists_prop]

/-- Independently specified hull-kernel topology: its opens are exactly the
complements of principal downsets restricted to actual coprime elements. -/
@[implicit_reducible]
def hullKernelTopology : TopologicalSpace (CoprimeElements Q) where
  IsOpen U := ∃ a : Q, hat a = U
  isOpen_univ := ⟨⊥, hat_bot⟩
  isOpen_inter := by
    rintro U V ⟨a, rfl⟩ ⟨b, rfl⟩
    exact ⟨a ⊔ b, hat_sup a b⟩
  isOpen_sUnion := by
    intro S hS
    choose a ha using hS
    refine ⟨sInf (Set.range (fun U : S => a U.1 U.2)), ?_⟩
    rw [hat_sInf]
    ext p
    simp only [mem_iUnion, mem_range, mem_sUnion]
    constructor
    · rintro ⟨_, ⟨U, rfl⟩, hp⟩
      exact ⟨U.1, U.2, (Set.ext_iff.mp (ha U.1 U.2) p).mp hp⟩
    · rintro ⟨U, hU, hp⟩
      exact ⟨a U hU, ⟨⟨U, hU⟩, rfl⟩, (Set.ext_iff.mp (ha U hU) p).mpr hp⟩

end CoprimeElements

theorem spectrumCoprimeOrderIso_preimage_hat {Q : Type u} [CompleteLattice Q] (a : Q) :
    spectrumCoprimeOrderIso Q ⁻¹' CoprimeElements.hat a =
      Spectrum.hat (OrderDual.toDual a) := by
  ext F
  exact (F.mem_iff_not_le_primeElement (OrderDual.toDual a)).symm

/-- The independently defined coprime topology is the actual transported
hull-kernel topology, proved from the explicit hat formula. -/
theorem spectrumCoprimeOrderIso_isOpen_iff {Q : Type u} [CompleteLattice Q]
    (W : Set (CoprimeElements Q)) :
    IsOpen[CoprimeElements.hullKernelTopology] W ↔
      IsOpen[Spectrum.hullKernelTopology]
        (spectrumCoprimeOrderIso Q ⁻¹' W) := by
  constructor
  · rintro ⟨a, rfl⟩
    exact ⟨OrderDual.toDual a, (spectrumCoprimeOrderIso_preimage_hat a).symm⟩
  · rintro ⟨a, ha⟩
    refine ⟨OrderDual.ofDual a, ?_⟩
    apply Set.ext
    intro p
    obtain ⟨F, rfl⟩ := (spectrumCoprimeOrderIso Q).surjective p
    exact (F.mem_iff_not_le_primeElement a).symm.trans (Set.ext_iff.mp ha F)

/-- Source-facing form of the full prime-element/coprime description. The
frame premise is retained from the source domain; the bridge is proved more
generally for complete lattices. -/
theorem source_coprime_spectrum {Q : Type u} [CompleteLattice Q]
    (hQ : IsFrame (OrderDual Q)) :
    ∃ e : Spectrum (OrderDual Q) ≃o CoprimeElements Q,
      (∀ a : Q, e ⁻¹' CoprimeElements.hat a = Spectrum.hat (OrderDual.toDual a)) ∧
      (∀ W : Set (CoprimeElements Q),
        IsOpen[CoprimeElements.hullKernelTopology] W ↔
          IsOpen[Spectrum.hullKernelTopology] (e ⁻¹' W)) := by
  clear hQ
  exact ⟨spectrumCoprimeOrderIso Q, spectrumCoprimeOrderIso_preimage_hat,
    spectrumCoprimeOrderIso_isOpen_iff⟩

end ScottSpectraReviewed
