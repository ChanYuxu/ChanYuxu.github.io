import ScottSpectraReviewed.SpectrumLocalCompact
import ScottSpectraReviewed.PrimeElementEquivalence
import ScottSpectraReviewed.CoprimeDirected
import ScottSpectraReviewed.UpperScottEq

/-! Source thm:web, lines1084--1106: the actual coprime spectrum with its
independently specified hull-kernel topology, its ambient Scott-subspace bridge,
and the specified theta(a)=Cop(Q) intersect down(a) complete-order representation.
No equality with the intrinsic Scott topology of Cop(Q) is assumed here. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace GeneralWeb

theorem homeomorph_isSaturated_image {P : Type u} {R : Type v}
    [TopologicalSpace P] [TopologicalSpace R] (e : P ≃ₜ R) {K : Set P}
    (hK : IsSaturated K) : IsSaturated (e '' K) := by
  apply (isSaturated_iff_specialization_upper _).mpr
  rintro _ y hxy ⟨x, hxK, rfl⟩
  have hspecial : e.symm y ⤳ x := by
    simpa only [e.symm_apply_apply] using
      ((specializationLE_iff (e x) y).mp hxy).map e.symm.continuous
  exact ⟨e.symm y, (isSaturated_iff_specialization_upper K).mp hK x (e.symm y)
    ((specializationLE_iff x (e.symm y)).mpr hspecial) hxK, e.apply_symm_apply y⟩

theorem homeomorph_isLocallyCompact {P : Type u} {R : Type v}
    [TopologicalSpace P] [TopologicalSpace R] (e : P ≃ₜ R)
    (hP : IsLocallyCompact P) : IsLocallyCompact R := by
  intro U y hyU
  let W : Opens P := ⟨e ⁻¹' (U : Set R), U.isOpen.preimage e.continuous⟩
  have hyW : e.symm y ∈ W := by
    change e (e.symm y) ∈ U
    simpa only [e.apply_symm_apply] using hyU
  obtain ⟨V, K, hxV, hVK, hKW, hKcompact, hKsat⟩ := hP W (e.symm y) hyW
  let V' : Opens R := ⟨e '' (V : Set P), e.isOpenMap _ V.isOpen⟩
  refine ⟨V', e '' K, ⟨e.symm y, hxV, e.apply_symm_apply y⟩, ?_, ?_,
    hKcompact.image e.continuous, homeomorph_isSaturated_image e hKsat⟩
  · rintro _ ⟨x, hxV, rfl⟩
    exact ⟨x, hVK hxV, rfl⟩
  · rintro _ ⟨x, hxK, rfl⟩
    exact hKW hxK

variable (Q : Type u) [CompleteLattice Q]

local instance generalWebSpectrumHK : TopologicalSpace (Spectrum Qᵒᵈ) :=
  Spectrum.hullKernelTopology
local instance generalWebCoprimeHK : TopologicalSpace (CoprimeElements Q) :=
  CoprimeElements.hullKernelTopology

def spectrumCoprimeHomeomorph : Spectrum Qᵒᵈ ≃ₜ CoprimeElements Q where
  toEquiv := (spectrumCoprimeOrderIso Q).toEquiv
  continuous_toFun := continuous_def.mpr (fun U hU =>
    (spectrumCoprimeOrderIso_isOpen_iff U).mp hU)
  continuous_invFun := by
    apply continuous_def.mpr
    intro U hU
    apply (spectrumCoprimeOrderIso_isOpen_iff _).mpr
    change IsOpen ((spectrumCoprimeOrderIso Q) ⁻¹'
      ((spectrumCoprimeOrderIso Q).symm ⁻¹' U))
    simpa only [preimage_preimage, Function.comp_def,
      OrderIso.symm_apply_apply, preimage_id'] using hU

theorem coprimeHullKernel_t0 : T0Space (CoprimeElements Q) := by
  letI : T0Space (Spectrum Qᵒᵈ) := Spectrum.hullKernel_t0
  exact (spectrumCoprimeHomeomorph Q).t0Space

theorem coprimeHullKernel_quasiSober : QuasiSober (CoprimeElements Q) := by
  letI : QuasiSober (Spectrum Qᵒᵈ) := Spectrum.hullKernel_quasiSober
  exact (spectrumCoprimeHomeomorph Q).symm.isOpenEmbedding.quasiSober

theorem coprimeHullKernel_isLocallyCompact (hframe : IsFrame Qᵒᵈ)
    (hcont : IsContinuousLattice Qᵒᵈ) : IsLocallyCompact (CoprimeElements Q) :=
  homeomorph_isLocallyCompact (spectrumCoprimeHomeomorph Q)
    (Spectrum.hullKernel_isLocallyCompact hframe hcont)

theorem coprimeHullKernel_eq_induced_upper :
    CoprimeElements.hullKernelTopology (Q := Q) =
      TopologicalSpace.induced Subtype.val (upperTopology Q) := by
  apply le_antisymm
  · exact @le_induced_generateFrom (CoprimeElements Q) Q CoprimeElements.hullKernelTopology
      {U : Set Q | ∃ a : Q, (Iic a)ᶜ = U} Subtype.val
      (by rintro U ⟨a, rfl⟩; exact ⟨a, rfl⟩)
  · intro U hU
    obtain ⟨a, rfl⟩ := hU
    letI : TopologicalSpace Q := upperTopology Q
    letI : TopologicalSpace (CoprimeElements Q) :=
      TopologicalSpace.induced Subtype.val (upperTopology Q)
    have haOpen : IsOpen[upperTopology Q] ((Iic a)ᶜ) :=
      isOpen_generateFrom_of_mem ⟨a, rfl⟩
    exact haOpen.preimage (@continuous_subtype_val Q (upperTopology Q) IsCoprime)

theorem coprimeHullKernel_eq_induced_scott (heq : scottTopology Q = upperTopology Q) :
    CoprimeElements.hullKernelTopology (Q := Q) =
      TopologicalSpace.induced Subtype.val (scottTopology Q) := by
  rw [heq]
  exact coprimeHullKernel_eq_induced_upper Q

def coprimeClosedIic (a : Q) : Closeds (CoprimeElements Q) :=
  ⟨{p | p.1 ≤ a}, ⟨a, rfl⟩⟩

theorem coprimeHullKernel_closure_singleton (p : CoprimeElements Q) :
    closure ({p} : Set (CoprimeElements Q)) = Set.Iic p := by
  apply subset_antisymm
  · exact closure_minimal (singleton_subset_iff.mpr le_rfl) (coprimeClosedIic Q p.1).isClosed
  · intro q hqp
    apply mem_closure_iff.mpr
    rintro U ⟨a, rfl⟩ hqa
    exact ⟨p, fun hpa => hqa (hqp.trans hpa), mem_singleton p⟩

local instance generalWebCoprimeT0 : T0Space (CoprimeElements Q) := coprimeHullKernel_t0 Q

theorem coprimeHullKernel_specializationOrder_eq :
    specializationOrder (CoprimeElements Q) = (inferInstance : PartialOrder (CoprimeElements Q)) := by
  apply PartialOrder.ext
  intro p q
  change (q ⤳ p) ↔ p ≤ q
  rw [specializes_iff_mem_closure, coprimeHullKernel_closure_singleton]
  rfl

theorem coprime_hat_subset_hat_iff (hframe : IsFrame Qᵒᵈ)
    (hcont : IsContinuousLattice Qᵒᵈ) (a b : Q) :
    CoprimeElements.hat a ⊆ CoprimeElements.hat b ↔ b ≤ a := by
  constructor
  · intro h
    apply (Spectrum.hat_subset_hat_iff hframe hcont (OrderDual.toDual a) (OrderDual.toDual b)).mp
    intro F ha
    rw [← spectrumCoprimeOrderIso_preimage_hat a] at ha
    rw [← spectrumCoprimeOrderIso_preimage_hat b]
    exact h ha
  · intro hba p hpa hpb
    exact hpa (hpb.trans hba)

theorem coprimeClosedIic_le_iff (hframe : IsFrame Qᵒᵈ)
    (hcont : IsContinuousLattice Qᵒᵈ) (a b : Q) :
    coprimeClosedIic Q a ≤ coprimeClosedIic Q b ↔ a ≤ b := by
  constructor
  · intro h
    apply (coprime_hat_subset_hat_iff Q hframe hcont b a).mp
    intro p hpb hpa
    exact hpb (h hpa)
  · intro hab p hpa
    exact hpa.trans hab

/-- The actual specified spectral complete-order isomorphism. Its value at
a is literally the coprimes below a, not an arbitrary representation. -/
def theta (hframe : IsFrame Qᵒᵈ) (hcont : IsContinuousLattice Qᵒᵈ) :
    Q ≃o Closeds (CoprimeElements Q) := by
  have hinj : Function.Injective (coprimeClosedIic Q) := by
    intro a b hab
    apply le_antisymm
    · exact (coprimeClosedIic_le_iff Q hframe hcont a b).mp hab.le
    · exact (coprimeClosedIic_le_iff Q hframe hcont b a).mp hab.ge
  have hsurj : Function.Surjective (coprimeClosedIic Q) := by
    intro C
    obtain ⟨a, ha⟩ := C.isClosed.isOpen_compl
    refine ⟨a, ?_⟩
    apply Closeds.ext
    ext p
    exact not_iff_not.mp (Set.ext_iff.mp ha p)
  exact { toEquiv := Equiv.ofBijective _ ⟨hinj, hsurj⟩
          map_rel_iff' := by intro a b; exact coprimeClosedIic_le_iff Q hframe hcont a b }

@[simp] theorem theta_apply (hframe : IsFrame Qᵒᵈ) (hcont : IsContinuousLattice Qᵒᵈ) (a : Q) :
    ((theta Q hframe hcont a) : Set (CoprimeElements Q)) = {p | p.1 ≤ a} := rfl

theorem theta_coprime_eq_eta (hframe : IsFrame Qᵒᵈ) (hcont : IsContinuousLattice Qᵒᵈ)
    (p : CoprimeElements Q) : theta Q hframe hcont p.1 = ClosedLattice.eta p := by
  apply Closeds.ext
  change {q : CoprimeElements Q | q.1 ≤ p.1} = closure ({p} : Set (CoprimeElements Q))
  rw [coprimeHullKernel_closure_singleton]
  rfl

/-- Eta continuity is derived from the actual theta and the proved ambient
Scott-subspace bridge, before intrinsic Scott equality on Cop(Q) is known. -/
theorem coprime_eta_continuous (hframe : IsFrame Qᵒᵈ) (hcont : IsContinuousLattice Qᵒᵈ)
    (heq : scottTopology Q = upperTopology Q) :
    @Continuous (CoprimeElements Q) (ClosedLattice.Carrier (CoprimeElements Q))
      (CoprimeElements.hullKernelTopology (Q := Q))
      (scottTopology (ClosedLattice.Carrier (CoprimeElements Q))) ClosedLattice.eta := by
  have hval : @Continuous (CoprimeElements Q) Q CoprimeElements.hullKernelTopology
      (scottTopology Q) Subtype.val := by
    rw [coprimeHullKernel_eq_induced_scott Q heq]
    exact @continuous_subtype_val Q (scottTopology Q) IsCoprime
  letI : TopologicalSpace Q := scottTopology Q
  letI : TopologicalSpace (ClosedLattice.Carrier (CoprimeElements Q)) :=
    scottTopology (ClosedLattice.Carrier (CoprimeElements Q))
  have hθ := (OrderIsoTransfer.continuous_scott (theta Q hframe hcont)).comp hval
  have hfun : (fun p : CoprimeElements Q => theta Q hframe hcont p.1) = ClosedLattice.eta :=
    funext (theta_coprime_eq_eta Q hframe hcont)
  exact hfun ▸ hθ

end GeneralWeb
end ScottSpectraReviewed
