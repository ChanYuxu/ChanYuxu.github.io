import ScottSpectraReviewed.GeneralWebSpectrum
import ScottSpectraReviewed.CountableSpace

/-! Source thm:web, lines1090--1108: apply the actual countable-space
theorem to the actual hull-kernel coprime space. Its eta continuity comes from
the specified theta representation; its intrinsic Scott topology is obtained
only at the end, not assumed as the ambient Scott-subspace topology. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace GeneralWeb

variable (Q : Type u) [CompleteLattice Q]
local instance generalWebCountableCopHK : TopologicalSpace (CoprimeElements Q) :=
  CoprimeElements.hullKernelTopology
local instance generalWebCountableCopT0 : T0Space (CoprimeElements Q) := coprimeHullKernel_t0 Q

theorem coprime_val_preimage_isScottOpen (U : Set Q) (hU : IsOpen[scottTopology Q] U) :
    IsOpen[scottTopology (CoprimeElements Q)] (Subtype.val ⁻¹' U) := by
  obtain ⟨hupper, hinacc⟩ := (isScottOpen_iff U).mp hU
  apply (isScottOpen_iff _).mpr
  refine ⟨hupper.preimage (fun _ _ h => h), ?_⟩
  intro D hne hdir p hp hpU
  have hD : NonemptyDirected D := ⟨hne, hdir⟩
  have hvalD := CoprimeElements.val_image_nonemptyDirected D hD
  have hvalSup : IsLUB (Subtype.val '' D) p.1 := by
    have hpeq := hp.unique (CoprimeElements.directedSup_isLUB D hD)
    rw [hpeq]
    exact CoprimeElements.val_directedSup_isLUB D hD
  obtain ⟨_, ⟨d, hd, rfl⟩, hdU⟩ := hinacc hvalD.1 hvalD.2 hvalSup hpU
  exact ⟨d, hd, hdU⟩

theorem coprimeHullKernel_isDSpace (heq : scottTopology Q = upperTopology Q) :
    IsDSpace (CoprimeElements Q) := by
  unfold IsDSpace
  rw [coprimeHullKernel_specializationOrder_eq Q]
  refine ⟨CoprimeElements.isDcpo, ?_⟩
  intro U hU
  change IsOpen[CoprimeElements.hullKernelTopology] U at hU
  rw [coprimeHullKernel_eq_induced_scott Q heq] at hU
  obtain ⟨W, hW, rfl⟩ :=
    (@isOpen_induced_iff (CoprimeElements Q) Q (scottTopology Q) U Subtype.val).mp hU
  exact coprime_val_preimage_isScottOpen Q W hW

theorem coprimeHullKernel_secondCountable (heq : scottTopology Q = upperTopology Q)
    (hcount : @SecondCountableTopology Q (scottTopology Q)) :
    SecondCountableTopology (CoprimeElements Q) := by
  change @SecondCountableTopology (CoprimeElements Q) CoprimeElements.hullKernelTopology
  rw [coprimeHullKernel_eq_induced_scott Q heq]
  exact @secondCountableTopology_induced (CoprimeElements Q) Q (scottTopology Q) hcount Subtype.val

/-- The source countable theorem is applied with no additional assumptions
on Cop(Q): the actual LC, T0, d-space, second countability and eta continuity
have all been proved from the displayed genuine lattice data. -/
theorem coprimeHullKernel_eq_intrinsic_scott (hframe : IsFrame Qᵒᵈ)
    (hcont : IsContinuousLattice Qᵒᵈ) (heq : scottTopology Q = upperTopology Q)
    (hcount : @SecondCountableTopology Q (scottTopology Q)) :
    CoprimeElements.hullKernelTopology (Q := Q) = scottTopology (CoprimeElements Q) := by
  letI : SecondCountableTopology (CoprimeElements Q) := coprimeHullKernel_secondCountable Q heq hcount
  have h := source_countable (coprimeHullKernel_isLocallyCompact Q hframe hcont)
    (coprimeHullKernel_isDSpace Q heq) (coprime_eta_continuous Q hframe hcont heq)
  change CoprimeElements.hullKernelTopology =
    @scottTopology (CoprimeElements Q) (specializationOrder (CoprimeElements Q)).toPreorder at h
  rw [coprimeHullKernel_specializationOrder_eq Q] at h
  exact h

end GeneralWeb
end ScottSpectraReviewed
