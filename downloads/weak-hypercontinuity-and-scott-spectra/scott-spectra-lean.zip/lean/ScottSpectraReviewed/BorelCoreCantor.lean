import Mathlib.Data.Fintype.Order
import Mathlib.Topology.MetricSpace.PiNat
import Mathlib.Topology.Metrizable.Basic
import Mathlib.Topology.Metrizable.Uniformity
import Mathlib.Topology.Order.OrderClosed
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import ScottSpectraReviewed.OrderBasics

/-! Literal Cantor model for source Lemma borel-subset: all functions from
Nat to Bool, with the standard product of discrete Bool topologies and the
pointwise order false < true. The Scott topology will always be named
explicitly and is not silently identified with this Cantor topology. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace BorelCore

abbrev Cantor := ℕ → Bool

theorem cantor_compactSpace : CompactSpace Cantor := by infer_instance

theorem cantor_t2Space : T2Space Cantor := by infer_instance

theorem cantor_metrizableSpace : MetrizableSpace Cantor := by
  letI : MetricSpace Cantor := PiNat.metricSpace
  infer_instance

theorem cantor_orderClosedTopology : OrderClosedTopology Cantor := by
  letI : OrderClosedTopology Bool := ⟨isClosed_discrete _⟩
  infer_instance

theorem bool_le_iff_true_imp (a b : Bool) : a ≤ b ↔ (a = true → b = true) := by
  cases a <;> cases b <;> simp

def positive (n : ℕ) : Set Cantor := {a | a n = true}

theorem positive_isClopen (n : ℕ) : IsClopen (positive n) := by
  change IsClopen ((fun a : Cantor => a n) ⁻¹' ({true} : Set Bool))
  exact ⟨(isClosed_discrete ({true} : Set Bool)).preimage (continuous_apply n),
    (isOpen_discrete ({true} : Set Bool)).preimage (continuous_apply n)⟩

/-- A finite subset of Nat as its literal Bool membership mask. -/
def finiteMask (F : Finset ℕ) : Cantor := fun n => decide (n ∈ F)

theorem finiteMask_le_iff (F : Finset ℕ) (a : Cantor) :
    finiteMask F ≤ a ↔ ∀ n ∈ F, a n = true := by
  constructor
  · intro h n hn
    exact (bool_le_iff_true_imp _ _).mp (h n) (by simp [finiteMask, hn])
  · intro h n
    apply (bool_le_iff_true_imp _ _).mpr
    intro hn
    exact h n (of_decide_eq_true hn)

theorem finiteMask_mono {F J : Finset ℕ} (hFJ : F ⊆ J) : finiteMask F ≤ finiteMask J :=
  (finiteMask_le_iff _ _).mpr (fun n hn => by simp [finiteMask, hFJ hn])

def finiteMasksBelow (a : Cantor) : Set Cantor :=
  {d | ∃ F : Finset ℕ, finiteMask F ≤ a ∧ finiteMask F = d}

theorem finiteMasksBelow_nonemptyDirected (a : Cantor) :
    NonemptyDirected (finiteMasksBelow a) := by
  refine ⟨⟨finiteMask ∅, ∅, (finiteMask_le_iff ∅ a).mpr (by simp), rfl⟩, ?_⟩
  rintro _ ⟨F, hFa, rfl⟩ _ ⟨J, hJa, rfl⟩
  have hUnion : finiteMask (F ∪ J) ≤ a := by
    apply (finiteMask_le_iff _ _).mpr
    intro n hn
    rcases Finset.mem_union.mp hn with hn | hn
    · exact (finiteMask_le_iff F a).mp hFa n hn
    · exact (finiteMask_le_iff J a).mp hJa n hn
  exact ⟨finiteMask (F ∪ J), ⟨F ∪ J, hUnion, rfl⟩,
    finiteMask_mono Finset.subset_union_left, finiteMask_mono Finset.subset_union_right⟩

theorem finiteMasksBelow_isLUB (a : Cantor) : IsLUB (finiteMasksBelow a) a := by
  constructor
  · rintro _ ⟨F, hF, rfl⟩
    exact hF
  · intro z hz n
    cases han : a n with
    | false => simp
    | true =>
      have hsingle : finiteMask {n} ≤ a := by
        apply (finiteMask_le_iff _ _).mpr
        intro m hm
        simpa only [Finset.mem_singleton.mp hm] using han
      have hmask : finiteMask {n} ≤ z := hz ⟨{n}, hsingle, rfl⟩
      simpa [finiteMask, han] using hmask n

/-- The finite positive-coordinate neighborhoods are extracted from the full
intrinsic Scott-open condition using the actual finite-mask directed LUB. -/
theorem exists_finiteMask_of_mem_isScottOpen (U : Set Cantor)
    (hU : IsOpen[scottTopology Cantor] U) {a : Cantor} (ha : a ∈ U) :
    ∃ F : Finset ℕ, finiteMask F ≤ a ∧ ∀ b : Cantor, finiteMask F ≤ b → b ∈ U := by
  have hScott := (isScottOpen_iff U).mp hU
  obtain ⟨_, ⟨F, hFa, rfl⟩, hFU⟩ := hScott.2
    (finiteMasksBelow_nonemptyDirected a).1 (finiteMasksBelow_nonemptyDirected a).2
    (finiteMasksBelow_isLUB a) ha
  exact ⟨F, hFa, fun b hFb => hScott.1 hFb hFU⟩

theorem positive_isScottOpen (n : ℕ) : IsOpen[scottTopology Cantor] (positive n) := by
  rw [isScottOpen_iff]
  refine ⟨?_, ?_⟩
  · intro a b hab ha
    exact (bool_le_iff_true_imp _ _).mp (hab n) ha
  · intro D hne hdir a ha han
    by_contra hnone
    have hfalse : a n ≤ false := ((isLUB_pi.mp ha) n).2 (by
      rintro _ ⟨d, hd, rfl⟩
      cases hdn : d n with
      | false => simp [hdn]
      | true => exact False.elim (hnone ⟨d, hd, hdn⟩))
    have hcontra : (false : Bool) = true := (bool_le_iff_true_imp _ _).mp hfalse han
    cases hcontra

/-- Exact source Scott-compact-upper to Cantor-closed argument. The finite
subcover is taken in the intrinsic Scott topology; the separating clopen
neighborhood is then formed in the explicitly different Cantor topology. -/
theorem scottCompact_upper_isCantorClosed (H : Set Cantor) (hupper : IsUpperSet H)
    (hcompact : @IsCompact Cantor (scottTopology Cantor) H) : IsClosed H := by
  classical
  apply isOpen_compl_iff.mp
  apply isOpen_iff_mem_nhds.mpr
  intro a ha
  have hcover : H ⊆ ⋃ i : {n : ℕ // a n = false}, positive i.1 := by
    intro b hb
    have hnot : ¬ b ≤ a := fun hba => ha (hupper hba hb)
    have hex : ∃ n : ℕ, b n = true ∧ a n = false := by
      by_contra hex
      apply hnot
      intro n
      apply (bool_le_iff_true_imp _ _).mpr
      intro hbn
      cases han : a n with
      | false => exact False.elim (hex ⟨n, hbn, han⟩)
      | true => rfl
    obtain ⟨n, hbn, han⟩ := hex
    exact mem_iUnion.mpr ⟨⟨n, han⟩, hbn⟩
  have hfinite : ∃ J : Finset {n : ℕ // a n = false},
      H ⊆ ⋃ i ∈ J, positive i.1 := by
    letI : TopologicalSpace Cantor := scottTopology Cantor
    exact hcompact.elim_finite_subcover (fun i : {n : ℕ // a n = false} => positive i.1)
      (fun i => positive_isScottOpen i.1) hcover
  obtain ⟨J, hJ⟩ := hfinite
  have hclosed : IsClosed (⋃ i ∈ J, positive i.1) :=
    J.finite_toSet.isClosed_biUnion (fun i _ => (positive_isClopen i.1).1)
  have haJ : a ∈ (⋃ i ∈ J, positive i.1)ᶜ := by
    intro hamem
    obtain ⟨i, hi, hai⟩ := mem_iUnion₂.mp hamem
    have hcontra : (false : Bool) = true := i.2.symm.trans hai
    cases hcontra
  exact Filter.mem_of_superset (hclosed.isOpen_compl.mem_nhds haJ)
    (fun b hb hbH => hb (hJ hbH))

end BorelCore
end ScottSpectraReviewed
