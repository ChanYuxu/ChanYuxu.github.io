import ScottSpectraReviewed.OrderBasics
import Mathlib.Topology.Closure
import Mathlib.Topology.Constructions

/-! The literal section-4 model of the frozen manuscript, lines 1147--1159.
The carrier is the product-Lawson closure of the actual join translations.
No nucleus, completeness, coframe or approximation conclusion is built into
the carrier or into the standing source hypotheses. -/

noncomputable section
open Set
universe u

namespace ScottSpectraReviewed

/-- Exactly the three standing hypotheses of section 4. This is a predicate
on the source lattice, not a record containing any host theorem. -/
def HostSectionContext (L : Type u) [CompleteLattice L] : Prop :=
  IsContinuousLattice L ∧ IsFrame L ∧ DualTopologyEquality L

def joinTranslation {L : Type u} [CompleteLattice L] (a : L) : L → L :=
  fun x => a ⊔ x

/-- The full function space with the product of coordinate Lawson topologies. -/
@[implicit_reducible] def hostAmbientTopology (L : Type u) [CompleteLattice L] :
    TopologicalSpace (L → L) :=
  @Pi.topologicalSpace L (fun _ => L) (fun _ => lawsonTopology L)

/-- The exact subset T in the source, not an unspecified retract/coframe. -/
def hostSet (L : Type u) [CompleteLattice L] : Set (L → L) :=
  @closure (L → L) (hostAmbientTopology L) (range (joinTranslation (L := L)))

abbrev HostCarrier (L : Type u) [CompleteLattice L] := ↥(hostSet L)

namespace HostCarrier

variable {L : Type u} [CompleteLattice L]

/-- The subspace topology of the specified product topology. -/
instance : TopologicalSpace (HostCarrier L) :=
  TopologicalSpace.induced Subtype.val (hostAmbientTopology L)

def translation (a : L) : HostCarrier L :=
  ⟨joinTranslation a, @subset_closure (L → L) (hostAmbientTopology L) _ _ (mem_range_self a)⟩

@[simp] theorem translation_apply (a x : L) :
    (translation a : L → L) x = a ⊔ x := rfl

@[simp] theorem translation_bot (a : L) :
    (translation a : L → L) ⊥ = a := sup_bot_eq a

theorem translation_injective : Function.Injective (translation (L := L)) := by
  intro a b hab
  have h := congrArg (fun t : HostCarrier L => (t : L → L) ⊥) hab
  simpa only [translation_bot] using h

theorem isClosed_hostSet : @IsClosed (L → L) (hostAmbientTopology L) (hostSet L) :=
  @isClosed_closure (L → L) (hostAmbientTopology L) _

end HostCarrier
end ScottSpectraReviewed
