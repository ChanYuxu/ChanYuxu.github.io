import ScottSpectraReviewed.SpectrumComap
import ScottSpectraReviewed.Separation

/-! Source Theorem `thm:transfer` (frozen TeX lines 1609--1666).
The construction and route are the written ones: H_F, its Scott openness,
prime-element separation giving surjectivity, then descent of upper opens. -/

noncomputable section
open Set
open scoped Topology
universe u v

namespace ScottSpectraReviewed

variable {L : Type u} {A : Type v} [CompleteLattice L] [CompleteLattice A]

/-- An injective frame homomorphism reflects order, using its actual finite
meet preservation. -/
theorem frameHom_le_iff_of_injective (e : FrameHom L A) (he : Function.Injective e)
    (a b : L) : e a ≤ e b ↔ a ≤ b := by
  constructor
  · intro hab
    apply inf_eq_left.mp
    apply he
    rw [map_inf, inf_eq_left.mpr hab]
  · intro hab
    exact OrderHomClass.monotone e hab

namespace Spectrum

/-- The exact upward-generated filter H_F printed in the transfer proof. -/
def upwardImage (e : FrameHom L A) (F : Spectrum L) : Order.PFilter A :=
  (Order.IsPFilter.of_def (F := {u : A | ∃ a ∈ F, e a ≤ u})
    (by exact ⟨⊤, ⊤, F.top_mem, le_top⟩)
    (by
      rintro u ⟨a, ha, hau⟩ v ⟨b, hb, hbv⟩
      refine ⟨e (a ⊓ b), ⟨a ⊓ b, (F.inf_mem_iff a b).mpr ⟨ha, hb⟩, le_rfl⟩,
        ?_, ?_⟩
      · exact (OrderHomClass.monotone e inf_le_left).trans hau
      · exact (OrderHomClass.monotone e inf_le_right).trans hbv)
    (by
      rintro u v huv ⟨a, ha, hau⟩
      exact ⟨a, ha, hau.trans huv⟩)).toPFilter

@[simp] theorem mem_upwardImage (e : FrameHom L A) (F : Spectrum L) (u : A) :
    u ∈ upwardImage e F ↔ ∃ a ∈ F, e a ≤ u := Iff.rfl

theorem image_mem_upwardImage (e : FrameHom L A) (F : Spectrum L)
    {a : L} (ha : a ∈ F) : e a ∈ upwardImage e F :=
  ⟨a, ha, le_rfl⟩

theorem upwardImage_subset_iff (e : FrameHom L A) (F : Spectrum L) (G : Spectrum A) :
    (upwardImage e F : Set A) ⊆ G ↔ F ≤ comap e G := by
  constructor
  · intro h a ha
    exact h (image_mem_upwardImage e F ha)
  · rintro h u ⟨a, ha, hau⟩
    exact G.mem_of_le hau (h ha)

/-- Continuity and complete primality give the approximant in F used in the
source proof. No continuity premise on the target lattice A is involved. -/
theorem exists_mem_wayBelow (F : Spectrum L) (hcont : IsContinuousLattice L)
    (a : L) (ha : a ∈ F) : ∃ b ∈ F, WayBelow b a := by
  have hs : sSup {b : L | WayBelow b a} = a :=
    (isLUB_sSup _).unique (hcont.2 a).2
  obtain ⟨b, hba, hbF⟩ := F.completely_prime {b : L | WayBelow b a} (hs.symm ▸ ha)
  exact ⟨b, hbF, hba⟩

theorem upwardImage_isScottOpen (e : FrameHom L A)
    (hcont : IsContinuousLattice L)
    (hWB : ∀ a b, WayBelow a b → WayBelow (e a) (e b)) (F : Spectrum L) :
    IsOpen[scottTopology A] (upwardImage e F : Set A) := by
  rw [isScottOpen_iff]
  refine ⟨?_, ?_⟩
  · intro u v huv hu
    exact Order.PFilter.mem_of_le huv hu
  · intro D hne hdir x hx hxH
    obtain ⟨a, ha, hea⟩ := hxH
    obtain ⟨b, hb, hba⟩ := exists_mem_wayBelow F hcont a ha
    obtain ⟨d, hd, hebd⟩ := hWB b a hba D ⟨hne, hdir⟩ x hx hea
    exact ⟨d, hd, b, hb, hebd⟩

theorem primeElement_image_not_mem_upwardImage (e : FrameHom L A)
    (he : Function.Injective e) (F : Spectrum L) :
    e F.primeElement ∉ upwardImage e F := by
  rintro ⟨a, ha, hea⟩
  exact (F.mem_iff_not_le_primeElement a).mp ha
    ((frameHom_le_iff_of_injective e he a F.primeElement).mp hea)

/-- Surjectivity is proved by the source's prime-element and Scott-open-filter
separation argument, not placed in a hypothesis. -/
theorem comap_surjective (hA : IsFrame A) (hcont : IsContinuousLattice L)
    (e : FrameHom L A) (he : Function.Injective e)
    (hWB : ∀ a b, WayBelow a b → WayBelow (e a) (e b)) :
    Function.Surjective (comap e) := by
  intro F
  obtain ⟨G, hHG, hpG⟩ := source_separation hA (upwardImage e F)
    (upwardImage_isScottOpen e hcont hWB F) (e F.primeElement)
    (primeElement_image_not_mem_upwardImage e he F)
  refine ⟨G, ?_⟩
  apply SetLike.ext
  intro a
  constructor
  · intro haG
    by_contra ha
    have hap : a ≤ F.primeElement := le_sSup ha
    exact hpG (G.mem_of_le (OrderHomClass.monotone e hap) haG)
  · intro ha
    exact hHG (image_mem_upwardImage e F ha)

/-- The local hat contained in W is the descent step of the printed proof. -/
theorem exists_hat_subset_of_preimage_hat (hA : IsFrame A)
    (hcont : IsContinuousLattice L) (e : FrameHom L A) (he : Function.Injective e)
    (hWB : ∀ a b, WayBelow a b → WayBelow (e a) (e b))
    (W : Set (Spectrum L)) (hW : IsUpperSet W) (v : A)
    (hpre : comap e ⁻¹' W = hat v) (F : Spectrum L) (hFW : F ∈ W) :
    ∃ a ∈ F, hat a ⊆ W := by
  have hvH : v ∈ upwardImage e F := by
    by_contra hvH
    obtain ⟨G, hHG, hvG⟩ := source_separation hA (upwardImage e F)
      (upwardImage_isScottOpen e hcont hWB F) v hvH
    have hFsub : F ≤ comap e G := (upwardImage_subset_iff e F G).mp hHG
    have hGW : comap e G ∈ W := hW hFsub hFW
    exact hvG ((Set.ext_iff.mp hpre G).mp hGW)
  obtain ⟨a, haF, heav⟩ := hvH
  refine ⟨a, haF, ?_⟩
  intro F' haF'
  obtain ⟨G', hG'⟩ := comap_surjective hA hcont e he hWB F'
  have heaG' : e a ∈ G' := by
    change a ∈ comap e G'
    rw [hG']
    exact haF'
  have hvG' : v ∈ G' := G'.mem_of_le heav heaG'
  have hpreG' : comap e G' ∈ W := (Set.ext_iff.mp hpre G').mpr hvG'
  rwa [hG'] at hpreG'

theorem isHullKernelOpen_of_upper_of_preimage_hat (hA : IsFrame A)
    (hcont : IsContinuousLattice L) (e : FrameHom L A) (he : Function.Injective e)
    (hWB : ∀ a b, WayBelow a b → WayBelow (e a) (e b))
    (W : Set (Spectrum L)) (hW : IsUpperSet W) (v : A)
    (hpre : comap e ⁻¹' W = hat v) : IsOpen[hullKernelTopology (L := L)] W := by
  refine ⟨sSup {a : L | hat a ⊆ W}, ?_⟩
  apply Set.ext
  intro F
  constructor
  · intro hF
    obtain ⟨a, ha, haF⟩ := F.completely_prime {a : L | hat a ⊆ W} hF
    exact ha haF
  · intro hFW
    obtain ⟨a, haF, haW⟩ :=
      exists_hat_subset_of_preimage_hat hA hcont e he hWB W hW v hpre F hFW
    exact F.mem_of_le (le_sSup haW) haF

end Spectrum

/-- Exact source-facing Theorem `thm:transfer`.
Both frame hypotheses are exposed; only L is assumed continuous. -/
theorem source_transfer (hL : IsFrame L) (hA : IsFrame A)
    (hcont : IsContinuousLattice L) (e : FrameHom L A) (he : Function.Injective e)
    (hWB : ∀ a b, WayBelow a b → WayBelow (e a) (e b))
    (hASpec : SpectrumIsScott A) : SpectrumIsScott L := by
  -- This printed source hypothesis is retained even though the internal
  -- transfer argument only invokes the target frame law through separation.
  clear hL
  apply le_antisymm
  · intro W hW
    have hpre := Spectrum.comap_preimage_isScottOpen e W hW
    change Spectrum.hullKernelTopology (L := A) = scottTopology (Spectrum A) at hASpec
    rw [← hASpec] at hpre
    obtain ⟨v, hv⟩ := hpre
    exact Spectrum.isHullKernelOpen_of_upper_of_preimage_hat hA hcont e he hWB
      W ((isScottOpen_iff W).mp hW).1 v hv.symm
  · exact Spectrum.scott_le_hullKernel

end ScottSpectraReviewed
