import Mathlib.Topology.PartitionOfUnity
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Topology.CompactOpen
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! Source lem:metric-quotient, lines896--909: the actual finite
partition-of-unity uniform approximation for a jointly continuous binary
operation on a compact Hausdorff space. Both lattice operations will later be
substituted into this proved generic construction. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology BigOperators
universe u

namespace ScottSpectraReviewed
namespace MetricLatticeQuotient

theorem abs_sub_partition_sum_lt {ι : Type*} [Fintype ι] (w : ι → ℝ)
    (hwnonneg : ∀ i, 0 ≤ w i) (hwone : ∑ i, w i = 1)
    (c : ℝ) (d : ι → ℝ) (ε : ℝ)
    (hclose : ∀ i, w i ≠ 0 → |c - d i| < ε) :
    |c - ∑ i, w i * d i| < ε := by
  classical
  have hnonzero : ∃ i, w i ≠ 0 := by
    by_contra h
    push Not at h
    have h01 : (0 : ℝ) = 1 := by simpa only [h, Finset.sum_const_zero] using hwone
    exact zero_ne_one h01
  have hterm : ∀ i, |w i * (c - d i)| ≤ w i * ε := by
    intro i
    by_cases hi : w i = 0
    · simp only [hi, zero_mul, abs_zero, le_refl]
    · rw [abs_mul, abs_of_nonneg (hwnonneg i)]
      exact mul_le_mul_of_nonneg_left (hclose i hi).le (hwnonneg i)
  have hstrict : ∃ i ∈ (Finset.univ : Finset ι), |w i * (c - d i)| < w i * ε := by
    obtain ⟨i, hi⟩ := hnonzero
    refine ⟨i, Finset.mem_univ i, ?_⟩
    rw [abs_mul, abs_of_nonneg (hwnonneg i)]
    exact mul_lt_mul_of_pos_left (hclose i hi) (lt_of_le_of_ne (hwnonneg i) (Ne.symm hi))
  have heq : c - ∑ i, w i * d i = ∑ i, w i * (c - d i) := by
    simp_rw [mul_sub]
    rw [Finset.sum_sub_distrib, ← Finset.sum_mul, hwone, one_mul]
  rw [heq]
  calc
    |∑ i, w i * (c - d i)| ≤ ∑ i, |w i * (c - d i)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ < ∑ i, w i * ε := Finset.sum_lt_sum (fun i _ => hterm i) hstrict
    _ = ε := by rw [← Finset.sum_mul, hwone, one_mul]

variable {M : Type u} [TopologicalSpace M]

def operationFunction (f : C(M, ℝ)) (op : M → M → M)
    (hop : Continuous fun p : M × M => op p.1 p.2) : C(M × M, ℝ) :=
  f.comp ⟨fun p => op p.1 p.2, hop⟩

def translation (f : C(M, ℝ)) (op : M → M → M)
    (hop : Continuous fun p : M × M => op p.1 p.2) (a : M) : C(M, ℝ) :=
  (operationFunction f op hop).curry a

@[simp] theorem operationFunction_apply (f : C(M, ℝ)) (op : M → M → M)
    (hop : Continuous fun p : M × M => op p.1 p.2) (a b : M) :
    operationFunction f op hop (a, b) = f (op a b) := rfl

@[simp] theorem translation_apply (f : C(M, ℝ)) (op : M → M → M)
    (hop : Continuous fun p : M × M => op p.1 p.2) (a b : M) :
    translation f op hop a b = f (op a b) := rfl

def finiteApproximation (f : C(M, ℝ)) (op : M → M → M)
    (hop : Continuous fun p : M × M => op p.1 p.2) {r : ℕ}
    (centers : Fin r → M) (φ : PartitionOfUnity (Fin r) M) : C(M × M, ℝ) where
  toFun p := ∑ i, φ i p.1 * translation f op hop (centers i) p.2
  continuous_toFun := continuous_finset_sum _ (fun i _ =>
    ((φ i).continuous.comp continuous_fst).mul
      ((translation f op hop (centers i)).continuous.comp continuous_snd))

@[simp] theorem finiteApproximation_apply (f : C(M, ℝ)) (op : M → M → M)
    (hop : Continuous fun p : M × M => op p.1 p.2) {r : ℕ}
    (centers : Fin r → M) (φ : PartitionOfUnity (Fin r) M) (a b : M) :
    finiteApproximation f op hop centers φ (a, b) =
      ∑ i, φ i a * f (op (centers i) b) := rfl

/-- The actual finite open cover, centers and subordinate partition of unity
from the source. The final norm is the genuine uniform norm on continuous
functions on compact M times M, not merely a pointwise error certificate. -/
theorem exists_partition_approximation [CompactSpace M] [T2Space M]
    (f : C(M, ℝ)) (op : M → M → M)
    (hop : Continuous fun p : M × M => op p.1 p.2) (ε : ℝ) (hε : 0 < ε) :
    ∃ (r : ℕ) (centers : Fin r → M) (V : Fin r → Set M)
      (φ : PartitionOfUnity (Fin r) M),
      (∀ i, IsOpen (V i)) ∧ univ ⊆ ⋃ i, V i ∧ φ.IsSubordinate V ∧
      (∀ i a, a ∈ V i →
        ‖translation f op hop a - translation f op hop (centers i)‖ < ε) ∧
      ‖operationFunction f op hop - finiteApproximation f op hop centers φ‖ < ε := by
  classical
  let g : C(M, C(M, ℝ)) := (operationFunction f op hop).curry
  let W : M → Set M := fun a => {x | ‖g x - g a‖ < ε}
  have hW : ∀ a, IsOpen (W a) := fun a =>
    isOpen_lt (g.continuous.sub continuous_const).norm continuous_const
  have hcover : (univ : Set M) ⊆ ⋃ a : M, W a := by
    intro x hx
    exact mem_iUnion.mpr ⟨x, by simpa only [W, mem_setOf_eq, sub_self, norm_zero] using hε⟩
  obtain ⟨J, hJ⟩ := isCompact_univ.elim_finite_subcover W hW hcover
  let enum : Fin (Fintype.card J) ≃ J := (Fintype.equivFin J).symm
  let centers : Fin (Fintype.card J) → M := fun i => (enum i).1
  let V : Fin (Fintype.card J) → Set M := fun i => W (centers i)
  have hV : ∀ i, IsOpen (V i) := fun i => hW (centers i)
  have hVcover : (univ : Set M) ⊆ ⋃ i, V i := by
    intro x hx
    obtain ⟨a, ha, hxa⟩ := mem_iUnion₂.mp (hJ hx)
    refine mem_iUnion.mpr ⟨enum.symm ⟨a, ha⟩, ?_⟩
    simpa only [V, centers, Equiv.apply_symm_apply] using hxa
  obtain ⟨φ, hφsub⟩ := PartitionOfUnity.exists_isSubordinate isClosed_univ V hV hVcover
  refine ⟨Fintype.card J, centers, V, φ, hV, hVcover, hφsub, ?_, ?_⟩
  · intro i a ha
    exact ha
  · apply (ContinuousMap.norm_lt_iff _ hε).mpr
    rintro ⟨a, b⟩
    have hsum : ∑ i, φ i a = 1 := by
      simpa only [finsum_eq_sum_of_fintype] using φ.sum_eq_one (mem_univ a)
    have hclose : ∀ i, φ i a ≠ 0 → |f (op a b) - f (op (centers i) b)| < ε := by
      intro i hi
      have haV : a ∈ V i := hφsub i (subset_closure hi)
      have hnorm : ‖translation f op hop a - translation f op hop (centers i)‖ < ε := haV
      have hpoint := (translation f op hop a - translation f op hop (centers i)).norm_coe_le_norm b
      have hpoint' : |f (op a b) - f (op (centers i) b)| ≤
          ‖translation f op hop a - translation f op hop (centers i)‖ := by
        simpa only [ContinuousMap.sub_apply, translation_apply, Real.norm_eq_abs] using hpoint
      exact hpoint'.trans_lt hnorm
    simpa only [ContinuousMap.sub_apply, operationFunction_apply,
      finiteApproximation_apply, Real.norm_eq_abs] using
      abs_sub_partition_sum_lt (fun i => φ i a) (fun i => φ.nonneg i a) hsum
        (f (op a b)) (fun i => f (op (centers i) b)) ε hclose

end MetricLatticeQuotient
end ScottSpectraReviewed
