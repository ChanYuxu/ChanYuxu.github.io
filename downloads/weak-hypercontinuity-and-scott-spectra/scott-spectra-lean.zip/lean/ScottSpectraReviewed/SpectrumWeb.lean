import ScottSpectraReviewed.ClosedLatticeHyperspace
import ScottSpectraReviewed.SpectrumLocalCompact

/-! The literal web construction in source cor:coframe, lines1131--1144.
It uses the actual closed-set frame, fixed intersection continuity for the
upper/lower-Vietoris topology, and the actual principal-closure eta map.
The general web-space theorem is not assumed in this construction. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed

theorem isWebSpace_of_closedLattice_frame {X : Type u} [TopologicalSpace X]
    (hframe : IsFrame (ClosedLattice.Carrier X)) : IsWebSpace X := by
  letI closedUpperSpace : TopologicalSpace (ClosedLattice.Carrier X) :=
    upperTopology (ClosedLattice.Carrier X)
  have hη : Continuous (ClosedLattice.eta : X → ClosedLattice.Carrier X) := by
    change @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (upperTopology (ClosedLattice.Carrier X)) ClosedLattice.eta
    rw [← ClosedLattice.lowerVietoris_eq_upper]
    exact @Topology.IsInducing.continuous X (ClosedLattice.Carrier X)
      ClosedLattice.eta (ClosedLattice.lowerVietorisTopology X)
      ‹TopologicalSpace X› ClosedLattice.eta_isInducing
  intro x N hN
  obtain ⟨U,hUN,hU,hxU⟩ := mem_nhds_iff.mp hN
  let V : Opens X := ⟨U,hU⟩
  have hhit : IsOpen (ClosedLattice.hit V) := by
    change IsOpen[upperTopology (ClosedLattice.Carrier X)] (ClosedLattice.hit V)
    rw [← ClosedLattice.lowerVietoris_eq_upper]
    exact isOpen_generateFrom_of_mem ⟨V,rfl⟩
  have hf : Continuous (fun y : X => ClosedLattice.eta x ⊓ ClosedLattice.eta y) :=
    (upper_continuous_inf_left hframe (ClosedLattice.eta x)).comp hη
  let W : Set X := (fun y : X => ClosedLattice.eta x ⊓ ClosedLattice.eta y) ⁻¹'
    ClosedLattice.hit V
  have hW : IsOpen W := hhit.preimage hf
  have hxW : x ∈ W := by
    refine ⟨x,⟨?_,?_⟩,hxU⟩ <;> exact subset_closure (mem_singleton x)
  have hWU : W ⊆ U := by
    rintro y ⟨z,⟨_,hzy⟩,hzU⟩
    exact isOpen_upper_specialization hU hzy hzU
  refine ⟨W,hWU.trans hUN,hW.mem_nhds hxW,?_⟩
  rintro y ⟨z,⟨hzx,hzy⟩,hzU⟩
  refine ⟨z,?_,hzx,hzy⟩
  exact ⟨z,⟨hzx,subset_closure (mem_singleton z)⟩,hzU⟩

namespace Spectrum
variable {L : Type u} [CompleteLattice L]

/-- Full specialization order of the actual hull-kernel space is exactly
the original inclusion order on proper completely prime filters. -/
theorem hullKernel_specializationOrder_eq :
    @specializationOrder (Spectrum L) hullKernelTopology hullKernel_t0 =
      (inferInstance : PartialOrder (Spectrum L)) := by
  letI : TopologicalSpace (Spectrum L) := hullKernelTopology
  apply PartialOrder.ext
  intro F G
  change G ⤳ F ↔ F ≤ G
  rw [specializes_iff_mem_closure,hullKernel_closure_singleton G]
  rfl

/-- The actual complement/hat representation used in cor:coframe. -/
def closedOrderIsoDual (hframe : IsFrame L) (hcont : IsContinuousLattice L) :
    letI : TopologicalSpace (Spectrum L) := hullKernelTopology
    ClosedLattice.Carrier (Spectrum L) ≃o Lᵒᵈ := by
  letI : TopologicalSpace (Spectrum L) := hullKernelTopology
  exact (ClosedLattice.complementOrderIso (Spectrum L)).trans
    (openOrderIso hframe hcont).dual.symm

theorem hullKernel_isWebSpace (hframe : IsFrame L) (hcont : IsContinuousLattice L)
    (hcoframe : IsCoframe L) :
    @IsWebSpace (Spectrum L) hullKernelTopology := by
  letI : TopologicalSpace (Spectrum L) := hullKernelTopology
  apply isWebSpace_of_closedLattice_frame
  exact OrderIsoTransfer.isFrame (closedOrderIsoDual hframe hcont).symm
    (show IsFrame Lᵒᵈ from hcoframe)

end Spectrum
end ScottSpectraReviewed
