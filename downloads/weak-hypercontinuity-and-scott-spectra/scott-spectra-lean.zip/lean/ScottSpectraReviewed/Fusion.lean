import ScottSpectraReviewed.FusionBasics

/-! Exact source `lem:fusion`, lines 608--655. The proof preserves the
printed decreasing-lower-tail argument and the arbitrary-directed definition
of V ≪ U in O(X). No sober/web/first-countable assumption is added. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance fusionSourceSpecializationOrder : PartialOrder X := specializationOrder X

/-- Exact source-facing fusion identity, with eta the actual principal
closure and the codomain the full intrinsic Scott topology of Gamma(X). -/
theorem source_fusion (hcore : IsCoreCompact X)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (A : ℕ → Set X) (hA : Antitone A) (hlower : ∀ n, IsLowerSet (A n)) :
    closure (⋂ n, A n) = ⋂ n, closure (A n) := by
  classical
  apply subset_antisymm
  · intro x hx
    exact mem_iInter.mpr (fun n => closure_mono (iInter_subset A n) hx)
  · intro x hx
    apply mem_closure_iff.mpr
    intro U hU hxU
    by_contra hdisjoint
    let Uo : Opens X := ⟨U,hU⟩
    have houtside : ∀ y ∈ Uo, ∃ n, y ∉ A n := by
      intro y hy
      by_contra h
      have hyAll : y ∈ ⋂ n, A n := mem_iInter.mpr (fun n => by
        by_contra hyn
        exact h ⟨n,hyn⟩)
      exact hdisjoint ⟨y,hy,hyAll⟩
    obtain ⟨V,hxV,hVU⟩ := coreCompact_iff_neighborhood.mp hcore Uo x hxU
    have hchoices : ∀ n : ℕ, ∃ b : X, b ∈ V ∧ b ∈ A n := by
      intro n
      exact mem_closure_iff.mp (mem_iInter.mp hx n) V V.isOpen hxV
    choose b hbV hbA using hchoices
    letI : TopologicalSpace (ClosedLattice.Carrier X) :=
      scottTopology (ClosedLattice.Carrier X)
    let C : ℕ → Set X := fun N => ClosedLattice.eta ⁻¹'
      ClosedLattice.fusionTail Uo.compl b N
    have hC : ∀ N, IsClosed (C N) := by
      intro N
      exact (ClosedLattice.fusionTail_isScottClosed A hA hlower Uo houtside b hbA N).preimage hη
    let O : ℕ → Opens X := fun N => ⟨(C N)ᶜ,(hC N).isOpen_compl⟩
    have hmono : Monotone O := by
      intro N M hNM y hy hyM
      apply hy
      rcases hyM with hyF | ⟨n,hnM,hyn⟩
      · exact Or.inl hyF
      · exact Or.inr ⟨n,hNM.trans hnM,hyn⟩
    let D : Set (Opens X) := range O
    have hD : NonemptyDirected D := by
      refine ⟨range_nonempty O, ?_⟩
      rintro _ ⟨N,rfl⟩ _ ⟨M,rfl⟩
      exact ⟨O (max N M),⟨max N M,rfl⟩,hmono (le_max_left N M),hmono (le_max_right N M)⟩
    have hcover : Uo ≤ sSup D := by
      intro y hy
      obtain ⟨m,hym⟩ := houtside y hy
      apply Opens.mem_sSup.mpr
      refine ⟨O m,⟨m,rfl⟩,?_⟩
      intro hyC
      rcases hyC with hyF | ⟨n,hmn,hyn⟩
      · exact ((ClosedLattice.eta_le_iff y Uo.compl).mp hyF) hy
      · have hybn : y ≤ b n := (ClosedLattice.eta_le_eta_iff y (b n)).mp hyn
        exact hym (hlower m hybn (hA hmn (hbA n)))
    obtain ⟨_,⟨N,rfl⟩,hVON⟩ := hVU D hD (sSup D) (isLUB_sSup D) hcover
    have hBN : b N ∈ C N := Or.inr ⟨N,le_rfl,le_rfl⟩
    exact hVON (hbV N) hBN

end ScottSpectraReviewed
