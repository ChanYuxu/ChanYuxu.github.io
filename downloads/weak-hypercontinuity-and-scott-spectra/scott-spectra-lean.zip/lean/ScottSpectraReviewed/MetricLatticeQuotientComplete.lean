import ScottSpectraReviewed.CompactOrdered
import Mathlib.Topology.Order.Lattice
import Mathlib.Data.Finset.Lattice.Fold

/-! Source lem:metric-quotient, lines931--940: arbitrary finite-join and
finite-meet nets, actual compact closed-order convergence, quotient
completeness and preservation of every supremum/infimum including empty
operations. These are proved from a continuous surjective lattice homomorphism,
not assumed as properties of the eventual metric quotient. -/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace MetricLatticeQuotient

section IncompleteTarget

variable {A : Type u} {B : Type v} [CompleteLattice A] [TopologicalSpace A]
variable [CompactSpace A] [OrderClosedTopology A]
variable [Lattice B] [TopologicalSpace B] [OrderClosedTopology B]

/- The arbitrary-set finite-join net in the source complete lattice has its
actual supremum as LUB, and therefore converges by compact closed order. -/
omit [TopologicalSpace A] [CompactSpace A] [OrderClosedTopology A] in
theorem finiteJoins_isLUB (S : Set A) :
    IsLUB (Set.range (fun F : Finset S => F.sup (fun a => (a : A)))) (sSup S) := by
  classical
  constructor
  · rintro _ ⟨F, rfl⟩
    exact Finset.sup_le (fun a ha => le_sSup a.2)
  · intro z hz
    apply sSup_le
    intro a ha
    have h := hz (mem_range_self ({⟨a, ha⟩} : Finset S))
    simpa only [Finset.sup_singleton] using h

/-- The finite-join convergence argument proves the entire arbitrary-image
LUB property. Surjectivity supplies the empty-join bound as printed. -/
theorem continuous_surjective_latticeHom_isLUB (q : LatticeHom A B)
    (hq : Function.Surjective q) (hc : Continuous q) (S : Set A) :
    IsLUB (q '' S) (q (sSup S)) := by
  classical
  let f : Finset S → A := fun F => F.sup (fun a => (a : A))
  have hf : Monotone f := fun F G hFG => Finset.sup_mono hFG
  have hlim : Tendsto f atTop (𝓝 (sSup S)) :=
    CompactOrdered.tendsto_of_monotone_isLUB hf (finiteJoins_isLUB S)
  constructor
  · rintro _ ⟨a, ha, rfl⟩
    exact OrderHomClass.monotone q (le_sSup ha)
  · intro z hz
    have hqbot : q (⊥ : A) ≤ z := by
      obtain ⟨a, rfl⟩ := hq z
      exact OrderHomClass.monotone q bot_le
    have hfinite : ∀ F : Finset S, q (f F) ≤ z := by
      intro F
      induction F using Finset.induction_on with
      | empty => simpa only [f, Finset.sup_empty] using hqbot
      | @insert a F ha ih =>
        simpa only [f, Finset.sup_insert, SupHomClass.map_sup] using
          sup_le (hz ⟨a.1, a.2, rfl⟩) ih
    exact (isClosed_Iic : IsClosed (Set.Iic z)).mem_of_tendsto
      (hc.continuousAt.tendsto.comp hlim) (Eventually.of_forall hfinite)

theorem continuous_surjective_latticeHom_isGLB (q : LatticeHom A B)
    (hq : Function.Surjective q) (hc : Continuous q) (S : Set A) :
    IsGLB (q '' S) (q (sInf S)) := by
  letI : TopologicalSpace Aᵒᵈ := ‹TopologicalSpace A›
  letI : CompactSpace Aᵒᵈ := ‹CompactSpace A›
  letI : OrderClosedTopology Aᵒᵈ := inferInstance
  letI : TopologicalSpace Bᵒᵈ := ‹TopologicalSpace B›
  letI : OrderClosedTopology Bᵒᵈ := inferInstance
  exact @continuous_surjective_latticeHom_isLUB Aᵒᵈ Bᵒᵈ _ _ _ _ _ _ _
    q.dual hq hc S

/-- A source compact complete lattice quotient acquires its actual complete
lattice structure from genuine suprema, retaining its existing finite lattice
operations definitionally. -/
@[implicit_reducible] def quotientCompleteLattice (q : LatticeHom A B) (hq : Function.Surjective q)
    (hc : Continuous q) : CompleteLattice B := by
  letI : SupSet B := ⟨fun T => q (sSup (q ⁻¹' T))⟩
  have hSup : ∀ T : Set B, IsLUB T (sSup T) := by
    intro T
    have himage : q '' (q ⁻¹' T) = T := Set.image_preimage_eq T hq
    change IsLUB T (q (sSup (q ⁻¹' T)))
    simpa only [himage] using continuous_surjective_latticeHom_isLUB q hq hc (q ⁻¹' T)
  exact { toLattice := ‹Lattice B›, __ := completeLatticeOfSup B hSup }

end IncompleteTarget

section CompleteTarget

variable {A : Type u} {B : Type v} [CompleteLattice A] [TopologicalSpace A]
variable [CompactSpace A] [OrderClosedTopology A]
variable [CompleteLattice B] [TopologicalSpace B] [OrderClosedTopology B]

/-- The map is the original q, upgraded after the actual net argument proves
preservation of all operations. -/
def quotientCompleteLatticeHom (q : LatticeHom A B) (hq : Function.Surjective q)
    (hc : Continuous q) : CompleteLatticeHom A B where
  toFun := q
  map_sSup' S := (continuous_surjective_latticeHom_isLUB q hq hc S).unique (isLUB_sSup _)
  map_sInf' S := (continuous_surjective_latticeHom_isGLB q hq hc S).unique (isGLB_sInf _)

end CompleteTarget

end MetricLatticeQuotient
end ScottSpectraReviewed
