import ScottSpectraReviewed.FirstCountableCoreConstruction

/-! The directed first-countable core conclusion of source `lem:fc-core`.
The internal lower-relation premise is separated from a final source wrapper;
it must be supplied by the actual canonical construction, not assumed there.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace FirstCountableCore

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance : PartialOrder X := specializationOrder X

/-- All and only points with an actually countably generated neighborhood
filter. No instance of first countability on the entire space is imposed. -/
def firstCountablePoints (X : Type u) [TopologicalSpace X] : Set X :=
  {x | (𝓝 x).IsCountablyGenerated}

def firstCountableBelow (x : X) : Set X := firstCountablePoints X ∩ Iic x

variable [QuasiSober X]

theorem firstCountableBelow_nonemptyDirected (hX : IsLocallyCompact X)
    (hrel : LowerRelationOpen X) (x : X) : NonemptyDirected (firstCountableBelow x) := by
  obtain ⟨m, hmx, _, hm⟩ := exists_firstCountable_of_lowerRelation hX hrel x
    (fun _ => univ) (fun _ => univ_mem)
  refine ⟨⟨m, hm, hmx⟩, ?_⟩
  intro a ha b hb
  letI : (𝓝 a).IsCountablyGenerated := ha.1
  letI : (𝓝 b).IsCountablyGenerated := hb.1
  obtain ⟨A, hA⟩ := Filter.exists_antitone_basis (𝓝 a)
  obtain ⟨B, hB⟩ := Filter.exists_antitone_basis (𝓝 b)
  have hU : ∀ n, A n ∩ B n ∈ 𝓝 x := fun n =>
    inter_mem (ha.2.nhds_le_nhds (hA.mem n)) (hb.2.nhds_le_nhds (hB.mem n))
  obtain ⟨g, hgx, hgU, hg⟩ := exists_firstCountable_of_lowerRelation hX hrel x
    (fun n => A n ∩ B n) hU
  refine ⟨g, ⟨hg, hgx⟩, ?_, ?_⟩
  · exact hA.toHasBasis.specializes_iff.mpr (fun n _ => (hgU n).1)
  · exact hB.toHasBasis.specializes_iff.mpr (fun n _ => (hgU n).2)

theorem self_mem_closure_firstCountableBelow (hX : IsLocallyCompact X)
    (hrel : LowerRelationOpen X) (x : X) : x ∈ closure (firstCountableBelow x) := by
  apply mem_closure_iff.mpr
  intro U hU hxU
  obtain ⟨m, hmx, hmU, hm⟩ := exists_firstCountable_of_lowerRelation hX hrel x
    (fun _ => U) (fun _ => hU.mem_nhds hxU)
  exact ⟨m, hmU 0, hm, hmx⟩

/-- The source's supremum argument: sobriety supplies the directed supremum;
closedness of its principal lower set and the actual closure relation force
that supremum to be x. -/
theorem firstCountableBelow_isLUB (hX : IsLocallyCompact X)
    (hrel : LowerRelationOpen X) (x : X) : IsLUB (firstCountableBelow x) x := by
  have hdir := firstCountableBelow_nonemptyDirected hX hrel x
  obtain ⟨s, hs, _⟩ := sober_directed_generic_sup hdir
  have hsx : s ≤ x := hs.2 (fun y hy => hy.2)
  have hxs : x ≤ s := (closure_minimal hs.1 (isClosed_principalLower s))
    (self_mem_closure_firstCountableBelow hX hrel x)
  exact (le_antisymm hsx hxs : s = x) ▸ hs

/-- Full internal fc-core conclusion with the actual displayed relation
openness dependency explicit. This is not a source-facing theorem with an
extra premise silently introduced into the paper. -/
theorem of_lowerRelation (hX : IsLocallyCompact X) (hrel : LowerRelationOpen X) :
    (∀ (x : X) (U : ℕ → Set X), (∀ n, U n ∈ 𝓝 x) →
      ∃ m : X, m ≤ x ∧ (∀ n, m ∈ U n) ∧ (𝓝 m).IsCountablyGenerated) ∧
    ∀ x : X, NonemptyDirected (firstCountableBelow x) ∧ IsLUB (firstCountableBelow x) x :=
  ⟨exists_firstCountable_of_lowerRelation hX hrel,
    fun x => ⟨firstCountableBelow_nonemptyDirected hX hrel x,
      firstCountableBelow_isLUB hX hrel x⟩⟩

end FirstCountableCore
end ScottSpectraReviewed
