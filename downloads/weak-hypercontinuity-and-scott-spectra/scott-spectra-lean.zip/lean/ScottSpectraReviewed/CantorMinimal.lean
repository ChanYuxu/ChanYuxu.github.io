import Mathlib.Topology.Order.OrderClosed
import Mathlib.Topology.Compactness.Compact
import Mathlib.Topology.GDelta.MetrizableSpace
import Mathlib.Topology.MetricSpace.Polish
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import Mathlib.Order.Zorn
import Mathlib.Tactic.Positivity

/-! Source borel-subset lines697--708: actual compact closed-order Zorn
minima and the separated-lower-pair compact projections proving that the
minimal-point set is G-delta, hence Borel.

The generic separatedLowerPairs/lowerPairImage mechanism is adapted from
`CoreCompactNonSober/simplified/CoreCompactSimplified/HeZhangRepresentationPolish.lean`,
SHA256 `2eaedc6cf256e554d0f3dcd99769bc19390e9be69f8c468de870ee3dd77b029f`.
Only its MetricSpace/PartialOrder/closed-order argument is adapted, not its
Scott-closed-lattice model, project imports, hypotheses or acceptance status.
The Zorn argument and the generic nonminimal-point identity are newly written.
-/

noncomputable section
open Set TopologicalSpace
universe u

namespace ScottSpectraReviewed
namespace CantorMinimal

def upwardHull {M : Type u} [Preorder M] (S : Set M) : Set M :=
  {b | ∃ a ∈ S, a ≤ b}

theorem upwardHull_isUpperSet {M : Type u} [Preorder M] (S : Set M) :
    IsUpperSet (upwardHull S) := by
  rintro a b hab ⟨s, hs, hsa⟩
  exact ⟨s, hs, hsa.trans hab⟩

theorem subset_upwardHull {M : Type u} [Preorder M] (S : Set M) : S ⊆ upwardHull S :=
  fun a ha => ⟨a, ha, le_rfl⟩

theorem minimal_upwardHull_mem {M : Type u} [PartialOrder M] {S : Set M} {m : M}
    (hm : Minimal (· ∈ upwardHull S) m) : m ∈ S := by
  obtain ⟨s, hs, hsm⟩ := hm.1
  have hms : m ≤ s := hm.2 (subset_upwardHull S hs) hsm
  exact (le_antisymm hsm hms) ▸ hs

section CompactOrdered

variable {M : Type u} [PartialOrder M] [TopologicalSpace M]
variable [OrderClosedTopology M] [T2Space M]

/-- The source's compactness/closed-order lower-bound argument for arbitrary
chains, followed by actual Zorn. No countability of a chain is assumed. -/
theorem compact_exists_minimal_le {H : Set M} (hH : IsCompact H) {h : M} (hh : h ∈ H) :
    ∃ m : M, Minimal (· ∈ H) m ∧ m ≤ h := by
  classical
  have hchains : ∀ C ⊆ H, IsChain (· ≥ ·) C →
      ∀ y ∈ C, ∃ lb ∈ H, ∀ z ∈ C, lb ≤ z := by
    intro C hCH hchain y hy
    letI : Nonempty C := ⟨⟨y, hy⟩⟩
    have hfiltered : DirectedOn (· ≥ ·) C := by
      intro a ha b hb
      by_cases hab : a = b
      · exact ⟨b, hb, hab.ge, le_rfl⟩
      · rcases hchain ha hb hab with hab | hba
        · exact ⟨b, hb, hab, le_rfl⟩
        · exact ⟨a, ha, le_rfl, hba⟩
    let t : C → Set M := fun c => H ∩ Set.Iic c.1
    have htd : Directed (· ⊇ ·) t := by
      intro a b
      obtain ⟨c, hc, hca, hcb⟩ := hfiltered a.1 a.2 b.1 b.2
      exact ⟨⟨c, hc⟩, fun x hx => ⟨hx.1, hx.2.trans hca⟩,
        fun x hx => ⟨hx.1, hx.2.trans hcb⟩⟩
    obtain ⟨m, hm⟩ := IsCompact.nonempty_iInter_of_directed_nonempty_isCompact_isClosed
      t htd (fun c => ⟨c.1, hCH c.2, le_rfl⟩)
      (fun c => hH.inter_right isClosed_Iic)
      (fun c => hH.isClosed.inter isClosed_Iic)
    exact ⟨m, (mem_iInter.mp hm ⟨y, hy⟩).1,
      fun z hz => (mem_iInter.mp hm ⟨z, hz⟩).2⟩
  obtain ⟨m, hmh, hm⟩ := @zorn_le_nonempty₀ (OrderDual M) _ H hchains h hh
  exact ⟨m, hm, hmh⟩

end CompactOrdered

section OrderedMetric

variable {M : Type u} [MetricSpace M] [PartialOrder M] [OrderClosedTopology M]

/-- The source parameter k≥1 is encoded by n+1, including every positive
integer threshold in the exact printed compact-pair construction. -/
def separatedLowerPairs (H : Set M) (n : ℕ) : Set (M × M) :=
  ((H ×ˢ H) ∩ {p | p.1 ≤ p.2}) ∩ {p | 1 / (n + 1 : ℝ) ≤ dist p.1 p.2}

def lowerPairImage (H : Set M) (n : ℕ) : Set M :=
  Prod.snd '' separatedLowerPairs H n

theorem separatedLowerPairs_isCompact {H : Set M} (hH : IsCompact H) (n : ℕ) :
    IsCompact (separatedLowerPairs H n) :=
  ((hH.prod hH).inter_right isClosed_le_prod).inter_right
    (isClosed_le continuous_const (continuous_fst.dist continuous_snd))

theorem lowerPairImage_isClosed {H : Set M} (hH : IsCompact H) (n : ℕ) :
    IsClosed (lowerPairImage H n) :=
  ((separatedLowerPairs_isCompact hH n).image continuous_snd).isClosed

omit [OrderClosedTopology M] in
theorem nonminimal_eq_iUnion_lowerPairImage (H : Set M) :
    H \ {b | Minimal (· ∈ H) b} = ⋃ n : ℕ, lowerPairImage H n := by
  classical
  ext b
  constructor
  · rintro ⟨hb, hbnot⟩
    have hex : ∃ a ∈ H, a ≤ b ∧ a ≠ b := by
      by_contra hex
      apply hbnot
      refine ⟨hb, ?_⟩
      intro a ha hab
      by_cases heq : a = b
      · exact heq.ge
      · exact False.elim (hex ⟨a, ha, hab, heq⟩)
    obtain ⟨a, ha, hab, hne⟩ := hex
    obtain ⟨n, hn⟩ := exists_nat_one_div_lt (dist_pos.mpr hne)
    exact mem_iUnion.mpr ⟨n, (a, b), ⟨⟨⟨ha, hb⟩, hab⟩, hn.le⟩, rfl⟩
  · intro hb
    obtain ⟨n, ⟨⟨a, b'⟩, ⟨⟨⟨ha, hb'⟩, hab⟩, hdist⟩, rfl⟩⟩ := mem_iUnion.mp hb
    refine ⟨hb', ?_⟩
    intro hmin
    have heq : b' = a := hmin.eq_of_ge ha hab
    have hpos : (0 : ℝ) < 1 / (n + 1 : ℝ) := by positivity
    change 1 / (n + 1 : ℝ) ≤ dist a b' at hdist
    rw [heq, dist_self] at hdist
    exact (not_le_of_gt hpos) hdist

theorem minimal_isGdelta {H : Set M} (hH : IsCompact H) :
    IsGδ {b : M | Minimal (· ∈ H) b} := by
  classical
  have hmin : {b : M | Minimal (· ∈ H) b} =
      H ∩ ⋂ n : ℕ, (lowerPairImage H n)ᶜ := by
    rw [← compl_iUnion, ← nonminimal_eq_iUnion_lowerPairImage H]
    ext b
    simp only [mem_setOf_eq, mem_inter_iff, mem_compl_iff, mem_diff]
    exact ⟨fun h => ⟨h.1, fun hn => hn.2 h⟩,
      fun ⟨hb, hn⟩ => by_contra fun hnot => hn ⟨hb, hnot⟩⟩
  rw [hmin]
  exact hH.isClosed.isGδ.inter
    (IsGδ.iInter_of_isOpen fun n => (lowerPairImage_isClosed hH n).isOpen_compl)

theorem minimal_measurableSet [MeasurableSpace M] [BorelSpace M]
    {H : Set M} (hH : IsCompact H) :
    MeasurableSet {b : M | Minimal (· ∈ H) b} :=
  (minimal_isGdelta hH).measurableSet

end OrderedMetric
end CantorMinimal
end ScottSpectraReviewed
