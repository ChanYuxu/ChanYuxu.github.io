import ScottSpectraReviewed.CompactSemilattice
import Mathlib.Topology.Sets.VietorisTopology

/-! The finite-product upper-open bridge needed by source833--850. For
compact closed-ordered Hausdorff spaces, open upper subsets of the product
have a basis of products of open upper subsets. Consequently a genuinely
continuous monotone map descends to the corresponding upper-open topologies.
No product-patch equality or desired continuity is assumed as a certificate. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v w

namespace ScottSpectraReviewed
namespace Patch

variable {P : Type u} {Q : Type v} [PartialOrder P] [PartialOrder Q]
variable [topP : TopologicalSpace P] [topQ : TopologicalSpace Q]
variable [compactP : CompactSpace P] [compactQ : CompactSpace Q]
variable [closedP : OrderClosedTopology P] [closedQ : OrderClosedTopology Q]

theorem exists_upper_rectangle {U : Set (P × Q)} (hU : IsOpen U)
    (hu : IsUpperSet U) {p : P × Q} (hp : p ∈ U) :
    ∃ V : Set P, ∃ W : Set Q, IsOpen V ∧ IsUpperSet V ∧
      IsOpen W ∧ IsUpperSet W ∧ p.1 ∈ V ∧ p.2 ∈ W ∧ V ×ˢ W ⊆ U := by
  have hprod : Ici p.1 ×ˢ Ici p.2 ⊆ U := by
    rintro ⟨a,b⟩ ⟨ha,hb⟩
    exact hu ⟨ha,hb⟩ hp
  obtain ⟨A,B,hA,hB,hPA,hQB,hAB⟩ := generalized_tube_lemma
    (isClosed_Ici.isCompact : IsCompact (Ici p.1))
    (isClosed_Ici.isCompact : IsCompact (Ici p.2)) hU hprod
  let V : Set P := (lowerClosure Aᶜ : Set P)ᶜ
  let W : Set Q := (lowerClosure Bᶜ : Set Q)ᶜ
  have hV : IsOpen V :=
    (CompactSemilattice.isClosed_lowerClosure hA.isClosed_compl).isOpen_compl
  have hW : IsOpen W :=
    (CompactSemilattice.isClosed_lowerClosure hB.isClosed_compl).isOpen_compl
  have hVu : IsUpperSet V := by
    rintro a b hab ha ⟨z,hz,hbz⟩
    exact ha ⟨z,hz,hab.trans hbz⟩
  have hWu : IsUpperSet W := by
    rintro a b hab ha ⟨z,hz,hbz⟩
    exact ha ⟨z,hz,hab.trans hbz⟩
  have hpV : p.1 ∈ V := by
    rintro ⟨z,hz,hpz⟩
    exact hz (hPA hpz)
  have hpW : p.2 ∈ W := by
    rintro ⟨z,hz,hpz⟩
    exact hz (hQB hpz)
  have hVA : V ⊆ A := by
    intro a ha
    by_contra hn
    exact ha ⟨a,hn,le_rfl⟩
  have hWB : W ⊆ B := by
    intro b hb
    by_contra hn
    exact hb ⟨b,hn,le_rfl⟩
  exact ⟨V,W,hV,hVu,hW,hWu,hpV,hpW,(Set.prod_mono hVA hWB).trans hAB⟩

include compactP compactQ closedP closedQ in
/-- Explicit topological descent on binary products. The supplied
characterizations refer to independently given topologies, not definitions
strengthened with the map's desired continuity. -/
theorem continuous_prod_mono_to_upper
    {R : Type w} [Preorder R] [topR : TopologicalSpace R]
    (tP : TopologicalSpace P) (tQ : TopologicalSpace Q) (tR : TopologicalSpace R)
    (hP : ∀ U : Set P, IsOpen[tP] U ↔ @IsOpen P topP U ∧ IsUpperSet U)
    (hQ : ∀ U : Set Q, IsOpen[tQ] U ↔ @IsOpen Q topQ U ∧ IsUpperSet U)
    (hR : ∀ U : Set R, IsOpen[tR] U ↔ @IsOpen R topR U ∧ IsUpperSet U)
    (f : P × Q → R)
    (hf : @Continuous (P × Q) R (@instTopologicalSpaceProd P Q topP topQ) topR f)
    (hm : Monotone f) :
    @Continuous (P × Q) R (@instTopologicalSpaceProd P Q tP tQ) tR f := by
  apply continuous_def.mpr
  intro U hU
  have hU' := (hR U).mp hU
  have hpre : @IsOpen (P × Q) (@instTopologicalSpaceProd P Q topP topQ) (f ⁻¹' U) :=
    (continuous_def.mp hf) U hU'.1
  have hpreu : IsUpperSet (f ⁻¹' U) := by
    intro a b hab ha
    exact hU'.2 (hm hab) ha
  apply (@isOpen_iff_forall_mem_open (P × Q)
    (@instTopologicalSpaceProd P Q tP tQ) (f ⁻¹' U)).mpr
  intro p hp
  obtain ⟨V,W,hV,hVu,hW,hWu,hpV,hpW,hsub⟩ :=
    @exists_upper_rectangle P Q _ _ topP topQ compactP compactQ closedP closedQ
      (f ⁻¹' U) hpre hpreu p hp
  exact ⟨V ×ˢ W,hsub,@IsOpen.prod P Q tP tQ V W
    ((hP V).mpr ⟨hV,hVu⟩) ((hQ W).mpr ⟨hW,hWu⟩),hpV,hpW⟩

end Patch
end ScottSpectraReviewed
