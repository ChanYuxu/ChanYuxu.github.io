import ScottSpectraReviewed.HostNuclei

/-! Source Lemma `lem:selfapprox`, statement lines 1333--1340 and proof
1341--1398. This module keeps the one-coordinate obstruction and finite-coordinate
meet reduction. Neighborhoods are genuine ambient product-Lawson neighborhoods;
no countability or sequential-density assumption is used.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace HostCarrier

variable {L : Type u} [CompleteLattice L]

theorem exists_translation_mem_nhds (t : HostCarrier L) (U : Set (L → L))
    (hU : U ∈ @nhds (L → L) (hostAmbientTopology L) (t : L → L)) :
    ∃ a : L, joinTranslation a ∈ U := by
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  have hf : ∃ᶠ f in 𝓝 (t : L → L), f ∈ range (joinTranslation (L := L)) :=
    mem_closure_iff_frequently.mp t.property
  obtain ⟨_, ⟨a, rfl⟩, haU⟩ := (hf.and_eventually hU).exists
  exact ⟨a, haU⟩

theorem one_coordinate_approx (hL : HostSectionContext L) (t : HostCarrier L)
    (U : Set (L → L))
    (hU : U ∈ @nhds (L → L) (hostAmbientTopology L) (t : L → L))
    (x u : L) (hub : ¬u ≤ (t : L → L) x) :
    ∃ a : L, joinTranslation a ∈ U ∧ ¬u ≤ (t : L → L) (a ⊔ x) := by
  classical
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  by_contra! hbad
  let b := (t : L → L) x
  have hr : ∃ r : L, WayBelow r u ∧ ¬r ≤ b := by
    by_contra! h
    exact hub ((hL.1.2 u).2.2 h)
  obtain ⟨r, hru, hrb⟩ := hr
  obtain ⟨Wstar, hWstar, hbWstar, hstar⟩ :=
    exists_open_closure_avoiding_principalUpper hL b r hrb
  let Good : (L × Set L) → Prop := fun p =>
    (¬p.1 ≤ b) ∧ WayBelow r ((t : L → L) p.1) ∧
      IsOpen p.2 ∧ b ∈ p.2 ∧ closure p.2 ∩ Ici p.1 = ∅
  let Hist : Type u := {F : Finset (L × Set L) // ∀ p ∈ F, Good p}
  have hchoose : ∀ H : Hist, ∃ p : L × Set L, Good p ∧ p.1 ∈ Wstar ∧
      ∀ q ∈ H.val, p.1 ∈ q.2 ∧ r ≤ q.1 ⊔ p.1 := by
    intro H
    let B : Set (L → L) :=
      (Function.eval x ⁻¹' Wstar) ∩
        ⋂ q ∈ (H.val : Set (L × Set L)),
          (Function.eval x ⁻¹' q.2) ∩
            (Function.eval q.1 ⁻¹' {z | WayBelow r z})
    have hBopen : IsOpen B := (hWstar.preimage (continuous_apply x)).inter
      (H.val.finite_toSet.isOpen_biInter fun q hq =>
        ((H.property q hq).2.2.1.preimage (continuous_apply x)).inter
          ((isLawsonOpen_wayAbove hL.1 r).preimage (continuous_apply q.1)))
    have htB : (t : L → L) ∈ B := by
      refine ⟨hbWstar, mem_iInter₂.mpr ?_⟩
      intro q hq
      exact ⟨(H.property q hq).2.2.2.1, (H.property q hq).2.1⟩
    obtain ⟨a, haV⟩ := exists_translation_mem_nhds t (U ∩ B)
      (inter_mem hU (hBopen.mem_nhds htB))
    let z := a ⊔ x
    have hutz : u ≤ (t : L → L) z := hbad a haV.1
    have hzb : ¬z ≤ b := by
      intro h
      exact hub (hutz.trans ((monotone hL t h).trans_eq (idempotent hL t x)))
    have hrzt : WayBelow r ((t : L → L) z) := wayBelow_mono le_rfl hru hutz
    obtain ⟨W, hW, hbW, hsep⟩ :=
      exists_open_closure_avoiding_principalUpper hL b z hzb
    refine ⟨(z, W), ⟨hzb, hrzt, hW, hbW, hsep⟩, haV.2.1, ?_⟩
    intro q hq
    have hqV := mem_iInter₂.mp haV.2.2 q hq
    refine ⟨hqV.1, (wayBelow_le hqV.2).trans ?_⟩
    exact sup_le (le_sup_of_le_right le_sup_left) le_sup_left
  let next : Hist → L × Set L := fun H => Classical.choose (hchoose H)
  have hnext : ∀ H : Hist, Good (next H) ∧ (next H).1 ∈ Wstar ∧
      ∀ q ∈ H.val, (next H).1 ∈ q.2 ∧ r ≤ q.1 ⊔ (next H).1 :=
    fun H => Classical.choose_spec (hchoose H)
  let extend : Hist → Hist := fun H =>
    ⟨insert (next H) H.val, by
      intro p hp
      rcases Finset.mem_insert.mp hp with hp | hp
      · subst p
        exact (hnext H).1
      · exact H.property p hp⟩
  let hist : ℕ → Hist := Nat.rec ⟨∅, by simp⟩ (fun _ H => extend H)
  have hOldmem : ∀ m n : ℕ, m < n → next (hist m) ∈ (hist n).val := by
    intro m n
    induction n with
    | zero => intro hmn; exact False.elim (Nat.not_lt_zero m hmn)
    | succ n ih =>
        intro hmn
        change next (hist m) ∈ insert (next (hist n)) (hist n).val
        by_cases hmn' : m < n
        · exact Finset.mem_insert_of_mem (ih hmn')
        · have hm : m = n := le_antisymm (Nat.le_of_lt_succ hmn) (Nat.le_of_not_lt hmn')
          subst m
          exact Finset.mem_insert_self _ _
  let d : ℕ → L := fun n => (next (hist n)).1
  let W : ℕ → Set L := fun n => (next (hist n)).2
  have hpair : ∀ n m : ℕ, 1 ≤ n → 1 ≤ m → n ≠ m → r ≤ d n ⊔ d m := by
    intro n m _ _ hne
    by_cases hnm : n < m
    · exact ((hnext (hist m)).2.2 (next (hist n)) (hOldmem n m hnm)).2
    · have hmn : m < n := lt_of_le_of_ne (le_of_not_gt hnm) (Ne.symm hne)
      have h := ((hnext (hist n)).2.2 (next (hist m)) (hOldmem m n hmn)).2
      change r ≤ d m ⊔ d n at h
      exact h.trans_eq (sup_comm (d m) (d n))
  apply no_excluded_sequence hL r d hpair Wstar W hWstar
  · intro n _
    exact (hnext (hist n)).1.2.2.1
  · intro n _
    refine ⟨(hnext (hist n)).2.1, ?_⟩
    intro i _ hin
    exact ((hnext (hist n)).2.2 (next (hist i)) (hOldmem i n hin)).1
  · exact hstar
  · intro n _
    exact (hnext (hist n)).1.2.2.2.2

/-- The source's set of genuinely bad coordinate/upper-bound pairs. -/
abbrev SelfApproxBadPair (t : HostCarrier L) :=
  {p : L × L // ¬p.2 ≤ (t : L → L) p.1}

/-- Source finite-coordinate reduction. Binary joint-meet neighborhoods
iterate the source's finite-meet neighborhood argument, including the empty case. -/
theorem finite_coordinate_approx (hL : HostSectionContext L) (t : HostCarrier L)
    (U : Set (L → L))
    (hU : U ∈ @nhds (L → L) (hostAmbientTopology L) (t : L → L))
    (F : Finset (SelfApproxBadPair t)) :
    ∃ a : L, joinTranslation a ∈ U ∧
      ∀ p ∈ F, ¬p.val.2 ≤ (t : L → L) (a ⊔ p.val.1) := by
  classical
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  induction F using Finset.induction_on generalizing U with
  | empty =>
      obtain ⟨a, ha⟩ := exists_translation_mem_nhds t U hU
      exact ⟨a, ha, by simp⟩
  | @insert p F hp ih =>
      have hpre : {q : (L → L) × (L → L) | q.1 ⊓ q.2 ∈ U} ∈
          𝓝 ((t : L → L), (t : L → L)) :=
        (ambient_continuous_inf hL).tendsto ((t : L → L), (t : L → L)) |>.eventually
          (by simpa only [inf_idem] using hU)
      obtain ⟨V, hV, W, hW, hVW⟩ := mem_nhds_prod_iff.mp hpre
      obtain ⟨a, haV, hpa⟩ := one_coordinate_approx hL t V hV p.val.1 p.val.2 p.property
      obtain ⟨b, hbW, hFb⟩ := ih W hW
      refine ⟨a ⊓ b, ?_, ?_⟩
      · rw [joinTranslation_inf hL]
        exact hVW (show (joinTranslation a, joinTranslation b) ∈ V ×ˢ W from ⟨haV, hbW⟩)
      · intro q hq hqbad
        rcases Finset.mem_insert.mp hq with hq | hq
        · subst q
          exact hpa (hqbad.trans (monotone hL t (sup_le_sup inf_le_left le_rfl)))
        · exact hFb q hq (hqbad.trans (monotone hL t (sup_le_sup inf_le_right le_rfl)))

/-- The printed `(U,F)` net index: ambient neighborhoods ordered by shrinking,
and finite bad-coordinate sets ordered by enlargement. -/
abbrev SelfApproxIndex (t : HostCarrier L) :=
  (OrderDual {U : Set (L → L) //
    U ∈ @nhds (L → L) (hostAmbientTopology L) (t : L → L)}) ×
      Finset (SelfApproxBadPair t)

instance selfApproxIndex_nonempty (t : HostCarrier L) : Nonempty (SelfApproxIndex t) :=
  ⟨(⟨univ, univ_mem⟩, ∅)⟩

instance selfApproxIndex_directed (t : HostCarrier L) : IsDirectedOrder (SelfApproxIndex t) := by
  classical
  refine ⟨fun i j => ?_⟩
  refine ⟨(⟨i.1.val ∩ j.1.val, inter_mem i.1.property j.1.property⟩, i.2 ∪ j.2), ?_, ?_⟩
  · exact ⟨inter_subset_left, Finset.subset_union_left⟩
  · exact ⟨inter_subset_right, Finset.subset_union_right⟩

def selfApproxNet (hL : HostSectionContext L) (t : HostCarrier L)
    (i : SelfApproxIndex t) : L :=
  Classical.choose (finite_coordinate_approx hL t i.1.val i.1.property i.2)

theorem selfApproxNet_spec (hL : HostSectionContext L) (t : HostCarrier L)
    (i : SelfApproxIndex t) :
    joinTranslation (selfApproxNet hL t i) ∈ i.1.val ∧
      ∀ p ∈ i.2, ¬p.val.2 ≤ (t : L → L) (selfApproxNet hL t i ⊔ p.val.1) :=
  Classical.choose_spec (finite_coordinate_approx hL t i.1.val i.1.property i.2)

theorem selfApproxNet_translation_tendsto (hL : HostSectionContext L) (t : HostCarrier L) :
    Tendsto (fun i : SelfApproxIndex t => joinTranslation (selfApproxNet hL t i)) atTop
      (@nhds (L → L) (hostAmbientTopology L) (t : L → L)) := by
  apply tendsto_def.mpr
  intro U hU
  let j : SelfApproxIndex t := (⟨U, hU⟩, ∅)
  apply (eventually_ge_atTop j).mono
  intro i hji
  exact hji.1 (selfApproxNet_spec hL t i).1

theorem selfApproxNet_coordinate_tendsto (hL : HostSectionContext L)
    (t : HostCarrier L) (x : L) :
    Tendsto (fun i : SelfApproxIndex t => (t : L → L) (selfApproxNet hL t i ⊔ x)) atTop
      (@nhds L (lawsonTopology L) ((t : L → L) x)) := by
  have hscott : Tendsto
      (fun i : SelfApproxIndex t => (t : L → L) (selfApproxNet hL t i ⊔ x)) atTop
      (@nhds L (scottTopology L) ((t : L → L) x)) := by
    letI : TopologicalSpace L := scottTopology L
    apply (nhds_basis_opens ((t : L → L) x)).tendsto_right_iff.mpr
    intro U hU
    exact Eventually.of_forall fun i => ((isScottOpen_iff U).mp hU.2).1
      (monotone hL t le_sup_right) hU.1
  have hlower : Tendsto
      (fun i : SelfApproxIndex t => (t : L → L) (selfApproxNet hL t i ⊔ x)) atTop
      (@nhds L (Topology.lower L) ((t : L → L) x)) := by
    apply tendsto_nhds_generateFrom_iff.mpr
    rintro _ ⟨u, rfl⟩ hu
    let p : SelfApproxBadPair t := ⟨(x, u), hu⟩
    let j : SelfApproxIndex t := (⟨univ, univ_mem⟩, {p})
    apply (eventually_ge_atTop j).mono
    intro i hji
    exact (selfApproxNet_spec hL t i).2 p (hji.2 (Finset.mem_singleton_self p))
  change Tendsto
    (fun i : SelfApproxIndex t => (t : L → L) (selfApproxNet hL t i ⊔ x)) atTop
    (@nhds L (Topology.lower L ⊓ scottTopology L) ((t : L → L) x))
  rw [@nhds_inf L (Topology.lower L) (scottTopology L) ((t : L → L) x)]
  exact tendsto_inf.mpr ⟨hlower, hscott⟩

theorem selfApproxNet_tendsto (hL : HostSectionContext L) (t : HostCarrier L) :
    letI := completeLattice hL
    Tendsto (fun i : SelfApproxIndex t => translation (selfApproxNet hL t i)) atTop
      (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) t) ∧
    Tendsto (fun i : SelfApproxIndex t => composeTranslation (selfApproxNet hL t i) t) atTop
      (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) t) := by
  letI := completeLattice hL
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  have hfirst : Tendsto (fun i : SelfApproxIndex t => translation (selfApproxNet hL t i))
      atTop (𝓝 t) :=
    tendsto_subtype_rng.mpr (selfApproxNet_translation_tendsto hL t)
  have hsecondAmbient : Tendsto
      (fun i : SelfApproxIndex t => ((composeTranslation (selfApproxNet hL t i) t : HostCarrier L) : L → L))
      atTop (𝓝 (t : L → L)) :=
    tendsto_pi_nhds.mpr (fun x => selfApproxNet_coordinate_tendsto hL t x)
  have hsecond : Tendsto
      (fun i : SelfApproxIndex t => composeTranslation (selfApproxNet hL t i) t) atTop (𝓝 t) :=
    tendsto_subtype_rng.mpr hsecondAmbient
  rw [lawsonTopology_eq_subspace hL]
  exact ⟨hfirst, hsecond⟩

/-- Exact source net-existence interface, with a genuine arbitrary directed
nonempty index preorder and both simultaneous Lawson limits. -/
theorem source_selfapprox (hL : HostSectionContext L) (t : HostCarrier L) :
    letI := completeLattice hL
    ∃ (ι : Type u) (p : Preorder ι),
      letI := p
      IsDirectedOrder ι ∧ Nonempty ι ∧
      ∃ a : ι → L,
        Tendsto (fun i => translation (a i)) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) t) ∧
        Tendsto (fun i => composeTranslation (a i) t) atTop
          (@nhds (HostCarrier L) (lawsonTopology (HostCarrier L)) t) := by
  letI := completeLattice hL
  exact ⟨SelfApproxIndex t, inferInstance, inferInstance, inferInstance,
    selfApproxNet hL t, selfApproxNet_tendsto hL t⟩

end HostCarrier
end ScottSpectraReviewed
