import ScottSpectraReviewed.GeneralWebCoprimeCountable
import ScottSpectraReviewed.CoprimeAdjoints

/-! Source thm:web, lines1109--1121: the literal B'=eta_X(B), its trace on
the actual left-adjoint coprime image Z, preservation of arbitrary directed
suprema, and the actual fixed-point sequence convergence contradiction.
The original Scott-closed B is never replaced by a different closed set. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace GeneralWeb

theorem coprime_leftAdjoint_continuous {A : Type u} {Q : Type v}
    [CompleteLattice A] [CompleteLattice Q] (q : CompleteLatticeHom A Q)
    (hq : Function.Surjective q) :
    @Continuous (CoprimeElements Q) (CoprimeElements A)
      (scottTopology (CoprimeElements Q)) (scottTopology (CoprimeElements A))
      (CompleteHom.leftAdjointCoprimeEmbedding q hq) := by
  letI : TopologicalSpace (CoprimeElements Q) := scottTopology (CoprimeElements Q)
  letI : TopologicalSpace (CoprimeElements A) := scottTopology (CoprimeElements A)
  apply continuous_def.mpr
  intro U hU
  obtain ⟨hupper, hinacc⟩ := (isScottOpen_iff U).mp hU
  apply (isScottOpen_iff _).mpr
  let f := CompleteHom.leftAdjointCoprimeEmbedding q hq
  refine ⟨hupper.preimage f.monotone, ?_⟩
  intro D hne hdir p hp hpU
  have hD : NonemptyDirected D := ⟨hne, hdir⟩
  have hE : NonemptyDirected (f '' D) :=
    CompleteHom.monotone_image_nonemptyDirected f f.monotone D hD
  have hfSup : IsLUB (f '' D) (f p) := by
    rw [hp.unique (CoprimeElements.directedSup_isLUB D hD),
      CompleteHom.leftAdjointCoprime_directedSup q hq D hD]
    exact CoprimeElements.directedSup_isLUB (f '' D) hE
  obtain ⟨_, ⟨d, hd, rfl⟩, hdU⟩ := hinacc hE.1 hE.2 hfSup hpU
  exact ⟨d, hd, hdU⟩

section EtaOrder

variable {X : Type u} [TopologicalSpace X] [T0Space X] [QuasiSober X]
local instance generalWebTraceSpecializationOrder : PartialOrder X := specializationOrder X

def etaCoprime (x : X) : CoprimeElements (ClosedLattice.Carrier X) :=
  ⟨ClosedLattice.eta x, ClosedLattice.pointClosure_isCoprime x⟩

/-- The source's actual eta order isomorphism P to Y=Cop(Gamma X),
using actual sobriety to identify precisely the irreducible closed sets. -/
def etaCoprimeOrderIso : X ≃o CoprimeElements (ClosedLattice.Carrier X) := by
  have hinj : Function.Injective (etaCoprime (X := X)) := by
    intro x y h
    exact ClosedLattice.eta_injective (congrArg Subtype.val h)
  have hsurj : Function.Surjective (etaCoprime (X := X)) := by
    intro p
    have hp : p.1 ∈ Set.range (ClosedLattice.pointClosure (X := X)) := by
      rw [ClosedLattice.range_pointClosure_eq_coprimes]
      exact p.2
    obtain ⟨x, hx⟩ := hp
    exact ⟨x, Subtype.ext hx⟩
  exact { toEquiv := Equiv.ofBijective _ ⟨hinj, hsurj⟩
          map_rel_iff' := by intro x y; exact ClosedLattice.eta_le_eta_iff x y }

@[simp] theorem etaCoprimeOrderIso_apply (x : X) :
    (etaCoprimeOrderIso (X := X) x).1 = ClosedLattice.eta x := rfl

/-- Literal source B' pulled back from the actual section image. This is
not a new choice or closure of B: the displayed set is eta_X '' B. -/
def etaTrace {Q : Type v} [CompleteLattice Q]
    (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q) (B : Set X) :
    Set (CoprimeElements Q) :=
  {p | CompleteHom.leftAdjoint q p.1 ∈ ClosedLattice.eta '' B}

omit [T0Space X] [QuasiSober X] in
theorem etaTrace_eq_pullback_intersection {Q : Type v} [CompleteLattice Q]
    (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q) (B : Set X) :
    (fun p : CoprimeElements Q => CompleteHom.leftAdjoint q p.1) ⁻¹'
      ((ClosedLattice.eta '' B) ∩
        CompleteHom.leftAdjoint q '' {a : Q | IsCoprime a}) = etaTrace q B := by
  ext p
  exact ⟨fun h => h.1, fun hp => ⟨hp, p.1, p.2, rfl⟩⟩

theorem etaTrace_isScottClosed {Q : Type v} [CompleteLattice Q]
    (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q) (hq : Function.Surjective q)
    (B : Set X) (hB : IsClosed[scottTopology X] B) :
    IsClosed[scottTopology (CoprimeElements Q)] (etaTrace q B) := by
  let e := etaCoprimeOrderIso (X := X)
  let f := CompleteHom.leftAdjointCoprimeEmbedding q hq
  let ψ : CoprimeElements Q → X := fun p => e.symm (f p)
  have hψ : @Continuous (CoprimeElements Q) X (scottTopology (CoprimeElements Q))
      (scottTopology X) ψ := by
    exact @Continuous.comp (CoprimeElements Q) (CoprimeElements (ClosedLattice.Carrier X)) X
      (scottTopology (CoprimeElements Q))
      (scottTopology (CoprimeElements (ClosedLattice.Carrier X))) (scottTopology X)
      f e.symm (OrderIsoTransfer.continuous_scott e.symm) (coprime_leftAdjoint_continuous q hq)
  have heq : ψ ⁻¹' B = etaTrace q B := by
    ext p
    constructor
    · intro hp
      refine ⟨ψ p, hp, ?_⟩
      exact congrArg Subtype.val (e.apply_symm_apply (f p))
    · rintro ⟨x, hxB, hx⟩
      have hx' : e x = f p := Subtype.ext hx
      have hψx : ψ p = x := by
        change e.symm (f p) = x
        rw [← hx', e.symm_apply_apply]
      change ψ p ∈ B
      rw [hψx]
      exact hxB
  have hpre : IsClosed[scottTopology (CoprimeElements Q)] (ψ ⁻¹' B) :=
    @IsClosed.preimage (CoprimeElements Q) X (scottTopology (CoprimeElements Q))
      (scottTopology X) ψ hψ B hB
  exact heq ▸ hpre

end EtaOrder

section FixedPoints

variable {X : Type u} [TopologicalSpace X] [T0Space X]
variable {Q : Type v} [CompleteLattice Q]

def fixedPointCoprime (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q)
    (hq : Function.Surjective q) (x : X)
    (hfix : CompleteHom.leftAdjoint q (q (ClosedLattice.eta x)) = ClosedLattice.eta x) :
    CoprimeElements Q :=
  ⟨q (ClosedLattice.eta x), (CompleteHom.isCoprime_leftAdjoint_iff q hq _).mpr
    (hfix.symm ▸ ClosedLattice.pointClosure_isCoprime x)⟩

omit [T0Space X] in
@[simp] theorem fixedPointCoprime_val (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q)
    (hq : Function.Surjective q) (x : X)
    (hfix : CompleteHom.leftAdjoint q (q (ClosedLattice.eta x)) = ClosedLattice.eta x) :
    (fixedPointCoprime q hq x hfix).1 = q (ClosedLattice.eta x) := rfl

theorem fixedPointCoprime_mem_etaTrace_iff [QuasiSober X]
    (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q) (hq : Function.Surjective q)
    (x : X) (hfix : CompleteHom.leftAdjoint q (q (ClosedLattice.eta x)) = ClosedLattice.eta x)
    (B : Set X) : fixedPointCoprime q hq x hfix ∈ etaTrace q B ↔ x ∈ B := by
  change CompleteHom.leftAdjoint q (q (ClosedLattice.eta x)) ∈ ClosedLattice.eta '' B ↔ x ∈ B
  rw [hfix]
  constructor
  · rintro ⟨y, hyB, hyx⟩
    exact ClosedLattice.eta_injective hyx ▸ hyB
  · intro hxB
    exact ⟨x, hxB, rfl⟩

omit [T0Space X] in
theorem fixedPointCoprime_tendsto (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q)
    (hq : Function.Surjective q)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (heq : scottTopology Q = upperTopology Q) (g : X) (c : ℕ → X)
    (hc : Tendsto c atTop (𝓝 g))
    (hfixg : CompleteHom.leftAdjoint q (q (ClosedLattice.eta g)) = ClosedLattice.eta g)
    (hfixc : ∀ n, CompleteHom.leftAdjoint q (q (ClosedLattice.eta (c n))) = ClosedLattice.eta (c n)) :
    @Tendsto ℕ (CoprimeElements Q)
      (fun n => fixedPointCoprime q hq (c n) (hfixc n)) atTop
      (@nhds (CoprimeElements Q) CoprimeElements.hullKernelTopology
        (fixedPointCoprime q hq g hfixg)) := by
  rw [coprimeHullKernel_eq_induced_scott Q heq]
  letI : TopologicalSpace Q := scottTopology Q
  letI : TopologicalSpace (CoprimeElements Q) :=
    TopologicalSpace.induced Subtype.val (scottTopology Q)
  letI : TopologicalSpace (ClosedLattice.Carrier X) := scottTopology (ClosedLattice.Carrier X)
  apply Topology.IsInducing.subtypeVal.tendsto_nhds_iff.mpr
  have hqcont : Continuous q := continuous_def.mpr (CompleteHom.preimage_isScottOpen q)
  have hcomp : Continuous (q ∘ ClosedLattice.eta) := hqcont.comp hη
  exact hcomp.continuousAt.tendsto.comp hc

/-- Exact source closed-trace sequence contradiction. All supplied lattice
data are constructed from the metric quotient in the final source theorem. -/
theorem closedTrace_sequence_contradiction [QuasiSober X]
    (q : CompleteLatticeHom (ClosedLattice.Carrier X) Q) (hq : Function.Surjective q)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (hframe : IsFrame Qᵒᵈ) (hcont : IsContinuousLattice Qᵒᵈ)
    (heq : scottTopology Q = upperTopology Q)
    (hcount : @SecondCountableTopology Q (scottTopology Q))
    (B : Set X) (hB : letI : PartialOrder X := specializationOrder X;
      IsClosed[scottTopology X] B)
    (g : X) (c : ℕ → X) (hgB : g ∉ B) (hcB : ∀ n, c n ∈ B)
    (hc : Tendsto c atTop (𝓝 g))
    (hfixg : CompleteHom.leftAdjoint q (q (ClosedLattice.eta g)) = ClosedLattice.eta g)
    (hfixc : ∀ n, CompleteHom.leftAdjoint q (q (ClosedLattice.eta (c n))) = ClosedLattice.eta (c n)) :
    False := by
  letI : TopologicalSpace (CoprimeElements Q) := CoprimeElements.hullKernelTopology
  have hclosed : IsClosed (etaTrace q B) := by
    change IsClosed[CoprimeElements.hullKernelTopology] (etaTrace q B)
    rw [coprimeHullKernel_eq_intrinsic_scott Q hframe hcont heq hcount]
    exact etaTrace_isScottClosed q hq B hB
  have hseq := fixedPointCoprime_tendsto q hq hη heq g c hc hfixg hfixc
  have hmem : fixedPointCoprime q hq g hfixg ∈ etaTrace q B :=
    hclosed.mem_of_tendsto hseq (Eventually.of_forall fun n =>
      (fixedPointCoprime_mem_etaTrace_iff q hq (c n) (hfixc n) B).mpr (hcB n))
  exact hgB ((fixedPointCoprime_mem_etaTrace_iff q hq g hfixg B).mp hmem)

end FixedPoints
end GeneralWeb
end ScottSpectraReviewed
