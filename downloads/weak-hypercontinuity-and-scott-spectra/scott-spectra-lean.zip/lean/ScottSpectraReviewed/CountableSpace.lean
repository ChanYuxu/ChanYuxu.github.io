import ScottSpectraReviewed.CountableCoding

/-! Exact source thm:countable, lines717--826. The actual Borel core and
membership-code embedding, ambient Polish Borel relation, well-foundedness,
countable analytic rank bound and source rank/fusion contradiction are all
constructed and proved. No additional rank condition, countability of X,
Hausdorffness or sobriety is assumed in the source-facing wrapper. -/

noncomputable section
open Set TopologicalSpace Ordinal Order
open scoped Topology Cardinal
universe u

namespace ScottSpectraReviewed

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance countableSourceSpecializationOrder : PartialOrder X := specializationOrder X

namespace Countable

/-- The source proof's main closed-set assertion, using the actual ambient
Polish relation rather than assuming a rank assignment on X. -/
theorem scottClosed_isClosed [SecondCountableTopology X] (hX : IsLocallyCompact X)
    (hd : IsDSpace X)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta)
    (B : Set X) (hB : IsClosed[scottTopology X] B) : IsClosed B := by
  classical
  apply isClosed_of_closure_subset
  intro x hxClosure
  by_contra hxB
  obtain ⟨e, G, hG, hopen, hGcore⟩ := BorelCore.source_borel_subset X hX
  obtain ⟨V, hV, hVanti, hVbasis⟩ := exists_decreasing_open_localBasis x
  have hchoices : ∀ n : ℕ, ∃ b : X, b ∈ V n ∧ b ∈ B := by
    intro n
    exact mem_closure_iff.mp hxClosure (V n) (hV n).1 (hV n).2
  choose b hbV hbB using hchoices
  choose O hO hpreimage using (fun n => hopen (V n) (hV n).1)
  let S : Set X := sequenceLowerSet b
  have hSlower : IsLowerSet S := sequenceLowerSet_isLowerSet b
  have hlevelClosure : ∀ n : ℕ, x ∈ closure (level G S V n) := by
    intro n
    apply mem_closure_iff.mpr
    intro U hU hxU
    obtain ⟨k, hk⟩ := hVbasis (U ∩ V n) (hU.inter (hV n).1) ⟨hxU, (hV n).2⟩
    let m : ℕ := max n k
    have hVm : V m ⊆ U ∩ V n := (hVanti (le_max_right n k)).trans hk
    obtain ⟨g, hgG, hgVm, hgb⟩ := hGcore (b m) (V m) (hV m).1 (hbV m)
    exact ⟨g, (hVm hgVm).1,
      ⟨⟨hgG, mem_iUnion.mpr ⟨m, hgb⟩⟩, (hVm hgVm).2⟩⟩
  let C : ℕ → Set BorelCore.Cantor := codedLevel e G b O
  have hCimage : ∀ n, C n = e '' level G S V n :=
    fun n => codedLevel_eq_image e G b O V hpreimage n
  have hCmeas : ∀ n,
      @MeasurableSet BorelCore.Cantor (borel BorelCore.Cantor) (C n) :=
    fun n => codedLevel_measurable e G b O hG hO n
  have hwf : WellFounded (codedRelation C) := codedRelation_wellFounded hd.1 e B hB x hxB
    V (fun n => (hV n).1) hVanti hVbasis G b hbB C hCimage
  letI : PolishSpace RankCarrier := rankCarrier_polishSpace
  obtain ⟨γbound, hγbound, hrankBound⟩ := AnalyticRank.source_borel_rank_bounded
    (codedRelation C) (codedRelation_measurable C hCmeas) hwf
  let r : ℕ → X → Ordinal := fun n a => (hwf.apply (n, e a)).rank
  apply rank_fusion_impossible (locallyCompact_isCoreCompact hX) hη x G S hSlower
    V (fun n => (hV n).1) (fun n => (hV n).2) hVanti hlevelClosure hGcore
    r γbound hγbound (fun n a => hrankBound (n, e a))
  intro n a b' ha hb' hab'
  have hrel : codedRelation C (n + 1, e b') (n, e a) := by
    refine ⟨rfl, ?_, ?_, e.monotone hab'⟩
    · rw [hCimage n]
      exact ⟨a, ha, rfl⟩
    · rw [hCimage (n + 1)]
      exact ⟨b', hb', rfl⟩
  exact Acc.rank_lt_of_rel (hwf.apply (n, e a)) hrel

end Countable

/-- Exact countably based locally compact d-space theorem from the reviewed
source. Eta is the actual principal-closure map into the full intrinsic Scott
topology of the actual closed-set lattice. -/
theorem source_countable [SecondCountableTopology X] (hX : IsLocallyCompact X)
    (hd : IsDSpace X)
    (hη : @Continuous X (ClosedLattice.Carrier X) ‹TopologicalSpace X›
      (scottTopology (ClosedLattice.Carrier X)) ClosedLattice.eta) :
    ‹TopologicalSpace X› = scottTopology X := by
  apply TopologicalSpace.ext_isClosed
  intro B
  constructor
  · intro hB
    have hopen : IsOpen[scottTopology X] Bᶜ := hd.2 Bᶜ hB.isOpen_compl
    exact @IsClosed.mk X (scottTopology X) B hopen
  · exact Countable.scottClosed_isClosed hX hd hη B

end ScottSpectraReviewed
