import ScottSpectraReviewed.PrimeElementEquivalence
import Mathlib.Topology.Sets.Closeds
import Mathlib.Topology.Sober

/-! Source operative paragraph at frozen TeX lines 1051--1059: actual coprimes
are closed under nonempty directed suprema, and the coprimes of the actual
closed-set lattice are exactly the nonempty irreducible closed sets. Sobriety
identifies these with actual closures of points, not an assumed representation.
-/

noncomputable section
open Set
open scoped Topology
universe u

namespace ScottSpectraReviewed

/-- The source's two-witness directed argument for coprimality of the actual
ambient supremum. Nonemptiness also keeps that supremum nonzero. -/
theorem isCoprime_sSup_of_nonemptyDirected {R : Type u} [CompleteLattice R]
    (D : Set R) (hD : NonemptyDirected D) (hCop : ∀ d ∈ D, IsCoprime d) :
    IsCoprime (sSup D) := by
  classical
  refine ⟨?_, ?_⟩
  · intro hp
    obtain ⟨d, hd⟩ := hD.1
    exact (hCop d hd).1 (le_bot_iff.mp (hp ▸ le_sSup hd))
  · intro a b hp
    by_contra hn
    push Not at hn
    have ha : ∃ d ∈ D, ¬ d ≤ a := by
      by_contra ha
      apply hn.1
      apply sSup_le
      intro d hd
      by_contra hda
      exact ha ⟨d, hd, hda⟩
    have hb : ∃ d ∈ D, ¬ d ≤ b := by
      by_contra hb
      apply hn.2
      apply sSup_le
      intro d hd
      by_contra hdb
      exact hb ⟨d, hd, hdb⟩
    obtain ⟨d₁, hd₁, hd₁a⟩ := ha
    obtain ⟨d₂, hd₂, hd₂b⟩ := hb
    obtain ⟨d, hd, hd₁d, hd₂d⟩ := hD.2 d₁ hd₁ d₂ hd₂
    rcases (hCop d hd).2 a b ((le_sSup hd).trans hp) with hda | hdb
    · exact hd₁a (hd₁d.trans hda)
    · exact hd₂b (hd₂d.trans hdb)

namespace CoprimeElements

variable {R : Type u} [CompleteLattice R]

theorem val_image_nonemptyDirected (D : Set (CoprimeElements R))
    (hD : NonemptyDirected D) : NonemptyDirected (Subtype.val '' D) := by
  refine ⟨hD.1.image Subtype.val, ?_⟩
  rintro _ ⟨d, hd, rfl⟩ _ ⟨e, he, rfl⟩
  obtain ⟨f, hf, hdf, hef⟩ := hD.2 d hd e he
  exact ⟨f.1, ⟨f, hf, rfl⟩, hdf, hef⟩

/-- The actual ambient supremum, now proved to remain in the coprime subtype. -/
def directedSup (D : Set (CoprimeElements R)) (hD : NonemptyDirected D) :
    CoprimeElements R :=
  ⟨sSup (Subtype.val '' D),
    isCoprime_sSup_of_nonemptyDirected _ (val_image_nonemptyDirected D hD)
      (by rintro _ ⟨d, hd, rfl⟩; exact d.2)⟩

@[simp] theorem val_directedSup (D : Set (CoprimeElements R)) (hD : NonemptyDirected D) :
    (directedSup D hD).1 = sSup (Subtype.val '' D) := rfl

theorem directedSup_isLUB (D : Set (CoprimeElements R)) (hD : NonemptyDirected D) :
    IsLUB D (directedSup D hD) := by
  constructor
  · intro d hd
    exact le_sSup (mem_image_of_mem Subtype.val hd)
  · intro p hp
    apply sSup_le
    rintro _ ⟨d, hd, rfl⟩
    exact hp hd

theorem val_directedSup_isLUB (D : Set (CoprimeElements R)) (hD : NonemptyDirected D) :
    IsLUB (Subtype.val '' D) (directedSup D hD).1 := isLUB_sSup _

theorem isDcpo : IsDcpo (CoprimeElements R) :=
  fun D hD => ⟨directedSup D hD, directedSup_isLUB D hD⟩

end CoprimeElements

namespace ClosedLattice

variable {X : Type u} [TopologicalSpace X]

/-- Coprimality in the actual lattice of all closed sets is precisely
nonempty irreducibility. No sobriety or local compactness is needed here. -/
theorem isCoprime_iff_isIrreducible (C : TopologicalSpace.Closeds X) :
    IsCoprime C ↔ IsIrreducible (C : Set X) := by
  constructor
  · intro hC
    refine ⟨TopologicalSpace.Closeds.coe_nonempty.mpr hC.1, ?_⟩
    rw [isPreirreducible_iff_isClosed_union_isClosed]
    intro z₁ z₂ hz₁ hz₂ hsub
    exact hC.2 ⟨z₁, hz₁⟩ ⟨z₂, hz₂⟩ hsub
  · intro hC
    refine ⟨TopologicalSpace.Closeds.coe_nonempty.mp hC.1, ?_⟩
    intro a b hab
    exact (isPreirreducible_iff_isClosed_union_isClosed.mp hC.2)
      a b a.isClosed b.isClosed hab

/-- The order correspondence changes no closed-set carrier. -/
def coprimeIrreducibleOrderIso (X : Type u) [TopologicalSpace X] :
    CoprimeElements (TopologicalSpace.Closeds X) ≃o TopologicalSpace.IrreducibleCloseds X where
  toFun C := ⟨(C.1 : Set X), (isCoprime_iff_isIrreducible C.1).mp C.2, C.1.isClosed⟩
  invFun C := ⟨⟨(C : Set X), C.isClosed⟩,
    (isCoprime_iff_isIrreducible _).mpr C.isIrreducible⟩
  left_inv C := by
    apply Subtype.ext
    apply TopologicalSpace.Closeds.ext
    rfl
  right_inv C := by
    apply TopologicalSpace.IrreducibleCloseds.ext
    rfl
  map_rel_iff' := by intro C D; rfl

/-- The source's eta_X, written as its actual topological closure rather than
relying on an unproved representation of the specialization order. -/
def pointClosure (x : X) : TopologicalSpace.Closeds X :=
  TopologicalSpace.Closeds.closure {x}

theorem pointClosure_carrier (x : X) :
    (pointClosure x : Set X) = {y : X | x ⤳ y} := by
  ext y
  exact specializes_iff_mem_closure.symm

theorem pointClosure_isCoprime (x : X) : IsCoprime (pointClosure x) :=
  (isCoprime_iff_isIrreducible _).mpr isIrreducible_singleton.closure

/-- Quasi-sobriety supplies the generic point; uniqueness is not needed for
the range equality, so the source's sober result has this stronger helper. -/
theorem range_pointClosure_eq_coprimes [QuasiSober X] :
    Set.range (pointClosure (X := X)) =
      {C : TopologicalSpace.Closeds X | IsCoprime C} := by
  ext C
  constructor
  · rintro ⟨x, rfl⟩
    exact pointClosure_isCoprime x
  · intro hC
    have hirr := (isCoprime_iff_isIrreducible C).mp hC
    obtain ⟨x, hx⟩ := QuasiSober.sober hirr C.isClosed
    refine ⟨x, ?_⟩
    apply TopologicalSpace.Closeds.ext
    exact hx.def

end ClosedLattice

/-- Exact source directed-supremum closure assertion, with nonempty directed
sets as stipulated throughout the manuscript. -/
theorem source_coprime_directedClosed (R : Type u) [CompleteLattice R]
    (D : Set R) (hD : NonemptyDirected D) (hCop : ∀ d ∈ D, IsCoprime d) :
    IsCoprime (sSup D) := isCoprime_sSup_of_nonemptyDirected D hD hCop

/-- Source sobriety conclusion Y = Pc(Gamma(X)), with the actual Gamma(X)
and actual point closures. In Mathlib, sober is QuasiSober plus T0Space. -/
theorem source_sober_coprime_range (X : Type u) [TopologicalSpace X]
    [T0Space X] [QuasiSober X] :
    Set.range (ClosedLattice.pointClosure (X := X)) =
      {C : TopologicalSpace.Closeds X | IsCoprime C} :=
  ClosedLattice.range_pointClosure_eq_coprimes

end ScottSpectraReviewed
