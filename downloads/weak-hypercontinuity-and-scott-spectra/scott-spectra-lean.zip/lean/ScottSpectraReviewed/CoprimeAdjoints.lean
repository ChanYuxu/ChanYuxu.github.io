import ScottSpectraReviewed.CoprimeDirected
import ScottSpectraReviewed.CompleteQuotients
import Mathlib.Topology.Constructions

/-! Source lines 1061--1082: the actual left adjoint of a surjective complete
lattice homomorphism preserves and reflects nonzero coprimality and embeds
the resulting coprime subspaces. No spectral representation, theta map,
quotient sobriety or equality of intrinsic and subspace Scott topologies is
assumed here. -/

noncomputable section
open Set
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace CompleteHom

variable {A : Type u} {B : Type v} [CompleteLattice A] [CompleteLattice B]

@[simp] theorem leftAdjoint_bot (q : CompleteLatticeHom A B) : leftAdjoint q ⊥ = ⊥ := by
  simpa only [sSup_empty, Set.image_empty] using leftAdjoint_map_sSup q ∅

theorem leftAdjoint_sup (q : CompleteLatticeHom A B) (a b : B) :
    leftAdjoint q (a ⊔ b) = leftAdjoint q a ⊔ leftAdjoint q b :=
  (leftAdjoint_gc q).l_sup

theorem leftAdjoint_le_iff (q : CompleteLatticeHom A B) (hq : Function.Surjective q)
    (a b : B) : leftAdjoint q a ≤ leftAdjoint q b ↔ a ≤ b := by
  constructor
  · intro h
    simpa only [q_leftAdjoint q hq] using OrderHomClass.monotone q h
  · exact fun h => leftAdjoint_monotone q h

def leftAdjointOrderEmbedding (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    B ↪o A where
  toFun := leftAdjoint q
  inj' := by
    intro a b h
    have hqeq := congrArg q h
    simpa only [q_leftAdjoint q hq] using hqeq
  map_rel_iff' := leftAdjoint_le_iff q hq _ _

theorem leftAdjoint_ne_bot_iff (q : CompleteLatticeHom A B) (hq : Function.Surjective q)
    (b : B) : leftAdjoint q b ≠ ⊥ ↔ b ≠ ⊥ := by
  constructor
  · intro hb hzero
    exact hb (hzero ▸ leftAdjoint_bot q)
  · intro hb hzero
    have hqzero := congrArg q hzero
    exact hb (by simpa only [q_leftAdjoint q hq, map_bot] using hqzero)

/-- The exact source equivalence, including preservation and reflection of
the nonzero condition rather than merely binary primality. -/
theorem isCoprime_leftAdjoint_iff (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) (b : B) :
    IsCoprime b ↔ IsCoprime (leftAdjoint q b) := by
  constructor
  · intro hb
    refine ⟨(leftAdjoint_ne_bot_iff q hq b).mpr hb.1, ?_⟩
    intro m n hmn
    have hqmn : b ≤ q m ⊔ q n := by
      simpa only [q_leftAdjoint q hq, map_sup] using OrderHomClass.monotone q hmn
    rcases hb.2 (q m) (q n) hqmn with hbm | hbn
    · exact Or.inl ((leftAdjoint_gc q) b m |>.mpr hbm)
    · exact Or.inr ((leftAdjoint_gc q) b n |>.mpr hbn)
  · intro hb
    refine ⟨(leftAdjoint_ne_bot_iff q hq b).mp hb.1, ?_⟩
    intro c d hcd
    have hleft : leftAdjoint q b ≤ leftAdjoint q c ⊔ leftAdjoint q d := by
      rw [← leftAdjoint_sup]
      exact leftAdjoint_monotone q hcd
    rcases hb.2 (leftAdjoint q c) (leftAdjoint q d) hleft with hbc | hbd
    · exact Or.inl ((leftAdjoint_le_iff q hq b c).mp hbc)
    · exact Or.inr ((leftAdjoint_le_iff q hq b d).mp hbd)

theorem leftAdjoint_coprime_image (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) :
    leftAdjoint q '' {b : B | IsCoprime b} =
      {a : A | IsCoprime a} ∩ Set.range (leftAdjoint q) := by
  ext a
  constructor
  · rintro ⟨b, hb, rfl⟩
    exact ⟨(isCoprime_leftAdjoint_iff q hq b).mp hb, ⟨b, rfl⟩⟩
  · rintro ⟨ha, b, rfl⟩
    exact ⟨b, (isCoprime_leftAdjoint_iff q hq b).mpr ha, rfl⟩

def leftAdjointCoprimeEmbedding (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    CoprimeElements B ↪o CoprimeElements A where
  toFun b := ⟨leftAdjoint q b.1, (isCoprime_leftAdjoint_iff q hq b.1).mp b.2⟩
  inj' := by
    intro b c h
    apply Subtype.ext
    exact (leftAdjointOrderEmbedding q hq).injective (congrArg Subtype.val h)
  map_rel_iff' := leftAdjoint_le_iff q hq _ _

theorem leftAdjoint_scottContinuous (q : CompleteLatticeHom A B) :
    ScottContinuous (leftAdjoint q) := by
  intro D _ _ b hb
  exact leftAdjoint_isLUB q D b hb

theorem leftAdjoint_preimage_isScottOpen (q : CompleteLatticeHom A B)
    (W : Set A) (hW : IsOpen[scottTopology A] W) :
    IsOpen[scottTopology B] (leftAdjoint q ⁻¹' W) := by
  rw [isScottOpen_iff] at hW ⊢
  refine ⟨?_, ?_⟩
  · intro b c hbc hb
    exact hW.1 (leftAdjoint_monotone q hbc) hb
  · intro D hne hdir b hb hleft
    have hD := monotone_image_nonemptyDirected (leftAdjoint q)
      (leftAdjoint_monotone q) D ⟨hne, hdir⟩
    obtain ⟨_, ⟨d, hd, rfl⟩, hld⟩ :=
      hW.2 hD.1 hD.2 (leftAdjoint_isLUB q D b hb) hleft
    exact ⟨d, hd, hld⟩

/-- The full Scott-space embedding is derived from the actual continuous
section/retraction maps; no intrinsic/subspace topology equality is assumed. -/
theorem leftAdjoint_isEmbedding (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    @Topology.IsEmbedding B A (scottTopology B) (scottTopology A) (leftAdjoint q) := by
  letI : TopologicalSpace A := scottTopology A
  letI : TopologicalSpace B := scottTopology B
  have hleft : Function.LeftInverse q (leftAdjoint q) := q_leftAdjoint q hq
  exact hleft.isEmbedding ⟨preimage_isScottOpen q⟩ ⟨leftAdjoint_preimage_isScottOpen q⟩

/-- Restriction to actual coprime subspaces of the ambient Scott spaces. This
does not identify either subspace topology with its intrinsic Scott topology. -/
theorem leftAdjointCoprime_isEmbedding (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) :
    @Topology.IsEmbedding (CoprimeElements B) (CoprimeElements A)
      (TopologicalSpace.induced Subtype.val (scottTopology B))
      (TopologicalSpace.induced Subtype.val (scottTopology A))
      (leftAdjointCoprimeEmbedding q hq) := by
  letI : TopologicalSpace A := scottTopology A
  letI : TopologicalSpace B := scottTopology B
  exact (leftAdjoint_isEmbedding q hq).restrict
    (fun b hb => (isCoprime_leftAdjoint_iff q hq b).mp hb)

theorem leftAdjointCoprime_directedSup (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) (D : Set (CoprimeElements B)) (hD : NonemptyDirected D) :
    leftAdjointCoprimeEmbedding q hq (CoprimeElements.directedSup D hD) =
      CoprimeElements.directedSup (leftAdjointCoprimeEmbedding q hq '' D)
        (monotone_image_nonemptyDirected _ (leftAdjointCoprimeEmbedding q hq).monotone D hD) := by
  apply Subtype.ext
  change leftAdjoint q (sSup (Subtype.val '' D)) =
    sSup (Subtype.val '' (leftAdjointCoprimeEmbedding q hq '' D))
  rw [leftAdjoint_map_sSup]
  congr 1
  simp only [Set.image_image]
  rfl

/-- The source image Z is closed under actual ambient directed suprema.
Together with coprime ambient-sup preservation, this is the inclusion step
Z into Y from the source, not merely continuity of an abstract isomorphic map. -/
theorem leftAdjoint_coprime_image_directedClosed (q : CompleteLatticeHom A B)
    (hq : Function.Surjective q) (D : Set A) (hD : NonemptyDirected D)
    (hDZ : D ⊆ leftAdjoint q '' {b : B | IsCoprime b}) :
    sSup D ∈ leftAdjoint q '' {b : B | IsCoprime b} := by
  let E : Set B := {b | IsCoprime b ∧ leftAdjoint q b ∈ D}
  have himage : leftAdjoint q '' E = D := by
    ext a
    constructor
    · rintro ⟨b, hb, rfl⟩
      exact hb.2
    · intro ha
      obtain ⟨b, hb, rfl⟩ := hDZ ha
      exact ⟨b, ⟨hb, ha⟩, rfl⟩
  have hE : NonemptyDirected E := by
    refine ⟨?_, ?_⟩
    · obtain ⟨a, ha⟩ := hD.1
      obtain ⟨b, hb, hba⟩ := hDZ ha
      exact ⟨b, hb, hba.symm ▸ ha⟩
    · intro b hb c hc
      obtain ⟨a, ha, hba, hca⟩ := hD.2 (leftAdjoint q b) hb.2 (leftAdjoint q c) hc.2
      obtain ⟨d, hd, hda⟩ := hDZ ha
      exact ⟨d, ⟨hd, hda.symm ▸ ha⟩,
        (leftAdjoint_le_iff q hq b d).mp (hda.symm ▸ hba),
        (leftAdjoint_le_iff q hq c d).mp (hda.symm ▸ hca)⟩
  refine ⟨sSup E, isCoprime_sSup_of_nonemptyDirected E hE (fun b hb => hb.1), ?_⟩
  rw [leftAdjoint_map_sSup, himage]

/-- The source's literal Y = eta_X(X) specialization of the image identity,
using the proved actual closed-lattice sobriety bridge. -/
theorem leftAdjoint_closedCoprime_image {X : Type u} [TopologicalSpace X]
    [T0Space X] [QuasiSober X]
    (q : CompleteLatticeHom (TopologicalSpace.Closeds X) B) (hq : Function.Surjective q) :
    leftAdjoint q '' {b : B | IsCoprime b} =
      Set.range (ClosedLattice.pointClosure (X := X)) ∩ Set.range (leftAdjoint q) := by
  rw [ClosedLattice.range_pointClosure_eq_coprimes]
  exact leftAdjoint_coprime_image q hq

/-- Exact source adjoint/coprime identity, independent of the later spectral
and theta representation assertions. -/
theorem source_coprime_adjoint (q : CompleteLatticeHom A B) (hq : Function.Surjective q) :
    (∀ b : B, IsCoprime b ↔ IsCoprime (leftAdjoint q b)) ∧
      (leftAdjoint q '' {b : B | IsCoprime b} =
        {a : A | IsCoprime a} ∩ Set.range (leftAdjoint q)) :=
  ⟨isCoprime_leftAdjoint_iff q hq, leftAdjoint_coprime_image q hq⟩

end CompleteHom
end ScottSpectraReviewed
