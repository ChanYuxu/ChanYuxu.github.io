import ScottSpectraReviewed.HostEscape
import Mathlib.Topology.Separation.Regular

/-! Source Lemma `lem:diagonal`. The countable recursion is the auxiliary
construction printed in the proof, not an assumption that general closure
can be tested by sequences. Every choice uses an actual Lawson neighborhood
meeting the actual closure set. Finite histories are just recursion bookkeeping.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace HostCarrier

variable {L : Type u} [CompleteLattice L]

theorem joinLeft_isLUB (b : L) (D : Set L) (hD : NonemptyDirected D)
    (x : L) (hx : IsLUB D x) :
    IsLUB ((fun a => b ⊔ a) '' D) (b ⊔ x) := by
  constructor
  · rintro _ ⟨d, hd, rfl⟩
    exact sup_le_sup_left (hx.1 hd) b
  · intro z hz
    obtain ⟨d, hd⟩ := hD.1
    apply sup_le
    · exact le_sup_left.trans (hz ⟨d, hd, rfl⟩)
    · apply hx.2
      intro a ha
      exact le_sup_right.trans (hz ⟨a, ha, rfl⟩)

theorem continuous_scott_joinLeft (b : L) :
    @Continuous L L (scottTopology L) (scottTopology L) (fun a => b ⊔ a) := by
  apply continuous_def.mpr
  intro U hU
  apply (isScottOpen_iff _).mpr
  constructor
  · intro x y hxy hx
    exact ((isScottOpen_iff U).mp hU).1 (sup_le_sup_left hxy b) hx
  · intro D hne hdir x hx hbx
    have hD : NonemptyDirected ((fun a => b ⊔ a) '' D) := by
      refine ⟨hne.image _, ?_⟩
      rintro _ ⟨a, ha, rfl⟩ _ ⟨c, hc, rfl⟩
      obtain ⟨d, hd, had, hcd⟩ := hdir a ha c hc
      exact ⟨b ⊔ d, ⟨d, hd, rfl⟩, sup_le_sup_left had b, sup_le_sup_left hcd b⟩
    obtain ⟨_, ⟨d, hd, rfl⟩, hdU⟩ := ((isScottOpen_iff U).mp hU).2
      hD.1 hD.2 (joinLeft_isLUB b D ⟨hne, hdir⟩ x hx) hbx
    exact ⟨d, hd, hdU⟩

theorem exists_open_closure_avoiding_principalUpper (hL : HostSectionContext L)
    (b a : L) (hab : ¬a ≤ b) :
    ∃ W : Set L, IsOpen[lawsonTopology L] W ∧ b ∈ W ∧
      @closure L (lawsonTopology L) W ∩ Ici a = ∅ := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : CompactSpace L := lawson_compactSpace
  letI : T2Space L := lawson_t2Space hL.1
  obtain ⟨W, ⟨hbW, hW⟩, hsub⟩ := (hasBasis_opens_closure b).mem_iff.mp
    ((isLawsonOpen_compl_Ici a).mem_nhds hab)
  refine ⟨W, hW, hbW, ?_⟩
  ext z
  constructor
  · intro hz
    exact False.elim (hsub hz.1 hz.2)
  · intro hz
    exact False.elim hz

/-- The source's non-continuity obstruction is impossible. Closure remains
general Lawson closure; no sequential-closure equivalence enters the proof. -/
theorem diagonal_not_mem_badClosure (hL : HostSectionContext L) (b u : L)
    (hub : ¬u ≤ b) :
    b ∉ @closure L (lawsonTopology L) {a | u ≤ b ⊔ a} := by
  classical
  letI : TopologicalSpace L := lawsonTopology L
  let G : Set L := {a | u ≤ b ⊔ a}
  intro hbG
  have hr : ∃ r : L, WayBelow r u ∧ ¬r ≤ b := by
    by_contra! h
    exact hub ((hL.1.2 u).2.2 h)
  obtain ⟨r, hru, hrb⟩ := hr
  obtain ⟨Wstar, hWstar, hbWstar, hstar⟩ :=
    exists_open_closure_avoiding_principalUpper hL b r hrb
  let O : L → Set L := fun a => {z | WayBelow r (a ⊔ z)}
  have hOopen : ∀ a : L, IsOpen (O a) := by
    intro a
    apply Topology.lawson_le_scott _
    exact (@continuous_def L L (scottTopology L) (scottTopology L)
      (fun z => a ⊔ z)).mp (continuous_scott_joinLeft a) _ (isScottOpen_wayAbove hL.1 r)
  have hOb : ∀ a ∈ G, b ∈ O a := by
    intro a ha
    change WayBelow r (a ⊔ b)
    exact wayBelow_mono le_rfl hru ((show u ≤ b ⊔ a from ha).trans_eq (sup_comm b a))
  have hnot : ∀ a ∈ G, ¬a ≤ b := by
    intro a ha hab
    apply hub
    have hua : u ≤ b ⊔ a := ha
    rwa [sup_eq_left.mpr hab] at hua
  let Good : (L × Set L) → Prop := fun p =>
    p.1 ∈ G ∧ IsOpen p.2 ∧ b ∈ p.2 ∧ closure p.2 ∩ Ici p.1 = ∅
  let Hist : Type u := {F : Finset (L × Set L) // ∀ p ∈ F, Good p}
  have hchoose : ∀ H : Hist, ∃ p : L × Set L, Good p ∧ p.1 ∈ Wstar ∧
      ∀ q ∈ H.val, p.1 ∈ q.2 ∧ r ≤ q.1 ⊔ p.1 := by
    intro H
    let V : Set L := Wstar ∩ ⋂ q ∈ (H.val : Set (L × Set L)), q.2 ∩ O q.1
    have hVopen : IsOpen V := hWstar.inter
      (H.val.finite_toSet.isOpen_biInter fun q hq =>
        ((H.property q hq).2.1).inter (hOopen q.1))
    have hbV : b ∈ V := by
      refine ⟨hbWstar, mem_iInter₂.mpr ?_⟩
      intro q hq
      exact ⟨(H.property q hq).2.2.1, hOb q.1 (H.property q hq).1⟩
    have hfre : ∃ᶠ a in 𝓝 b, a ∈ G := mem_closure_iff_frequently.mp hbG
    obtain ⟨a, haG, haV⟩ := (hfre.and_eventually (hVopen.mem_nhds hbV)).exists
    obtain ⟨W, hW, hbW, hsep⟩ :=
      exists_open_closure_avoiding_principalUpper hL b a (hnot a haG)
    refine ⟨(a, W), ⟨haG, hW, hbW, hsep⟩, haV.1, ?_⟩
    intro q hq
    have hqV := mem_iInter₂.mp haV.2 q hq
    exact ⟨hqV.1, wayBelow_le hqV.2⟩
  let next : Hist → L × Set L := fun H => Classical.choose (hchoose H)
  have hnext : ∀ H : Hist, Good (next H) ∧ (next H).1 ∈ Wstar ∧
      ∀ q ∈ H.val, (next H).1 ∈ q.2 ∧ r ≤ q.1 ⊔ (next H).1 :=
    fun H => Classical.choose_spec (hchoose H)
  let extend : Hist → Hist := fun H =>
    ⟨insert (next H) H.val, by
      intro p hp
      rcases Finset.mem_insert.mp hp with hp | hp
      · subst p
        exact (hnext H).1
      · exact H.property p hp⟩
  let hist : ℕ → Hist := Nat.rec
    ⟨∅, by simp⟩
    (fun _ H => extend H)
  have hOldmem : ∀ m n : ℕ, m < n → next (hist m) ∈ (hist n).val := by
    intro m n
    induction n with
    | zero => intro hmn; exact False.elim (Nat.not_lt_zero m hmn)
    | succ n ih =>
        intro hmn
        change next (hist m) ∈ insert (next (hist n)) (hist n).val
        by_cases hmn' : m < n
        · exact Finset.mem_insert_of_mem (ih hmn')
        · have hm : m = n := le_antisymm (Nat.le_of_lt_succ hmn) (Nat.le_of_not_lt hmn')
          subst m
          exact Finset.mem_insert_self _ _
  let d : ℕ → L := fun n => (next (hist n)).1
  let W : ℕ → Set L := fun n => (next (hist n)).2
  have hpair : ∀ n m : ℕ, 1 ≤ n → 1 ≤ m → n ≠ m → r ≤ d n ⊔ d m := by
    intro n m _ _ hne
    by_cases hnm : n < m
    · exact ((hnext (hist m)).2.2 (next (hist n)) (hOldmem n m hnm)).2
    · have hmn : m < n := lt_of_le_of_ne (le_of_not_gt hnm) (Ne.symm hne)
      have h := ((hnext (hist n)).2.2 (next (hist m)) (hOldmem m n hmn)).2
      change r ≤ d m ⊔ d n at h
      exact h.trans_eq (sup_comm (d m) (d n))
  apply no_excluded_sequence hL r d hpair Wstar W hWstar
  · intro n _
    exact (hnext (hist n)).1.2.1
  · intro n _
    refine ⟨(hnext (hist n)).2.1, ?_⟩
    intro i _ hin
    exact ((hnext (hist n)).2.2 (next (hist i)) (hOldmem i n hin)).1
  · exact hstar
  · intro n _
    exact (hnext (hist n)).1.2.2.2

/-- Exact source-facing diagonal continuity statement. -/
theorem source_diagonal (hL : HostSectionContext L) (b : L) :
    @ContinuousAt L L (lawsonTopology L) (lawsonTopology L) (fun a => b ⊔ a) b := by
  letI : TopologicalSpace L := lawsonTopology L
  have hscott : Tendsto (fun a : L => b ⊔ a) (𝓝 b)
      (@nhds L (scottTopology L) (b ⊔ b)) :=
    @Continuous.continuousAt L L (lawsonTopology L) (scottTopology L) (fun a => b ⊔ a) b
      (continuous_le_dom
      (show lawsonTopology L ≤ scottTopology L from inf_le_right)
      (continuous_scott_joinLeft b))
  have hlower : Tendsto (fun a : L => b ⊔ a) (𝓝 b)
      (@nhds L (Topology.lower L) (b ⊔ b)) := by
    apply tendsto_nhds_generateFrom_iff.mpr
    rintro _ ⟨u, rfl⟩ hu
    have hub : ¬u ≤ b := by simpa only [mem_compl_iff, mem_Ici, sup_idem] using hu
    change {a : L | ¬u ≤ b ⊔ a} ∈ 𝓝 b
    by_contra hn
    exact diagonal_not_mem_badClosure hL b u hub (mem_closure_iff_frequently.mpr hn)
  change Tendsto (fun a : L => b ⊔ a) (𝓝 b)
    (@nhds L (Topology.lower L ⊓ scottTopology L) (b ⊔ b))
  rw [@nhds_inf L (Topology.lower L) (scottTopology L) (b ⊔ b)]
  exact tendsto_inf.mpr ⟨hlower, hscott⟩

end HostCarrier
end ScottSpectraReviewed
