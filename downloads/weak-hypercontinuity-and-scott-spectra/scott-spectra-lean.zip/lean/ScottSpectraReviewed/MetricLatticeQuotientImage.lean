import ScottSpectraReviewed.MetricLatticeQuotientFamily
import ScottSpectraReviewed.MetricLatticeQuotientComplete
import Mathlib.Topology.Maps.Basic
import Mathlib.Topology.Metrizable.Basic

/-! Source lem:metric-quotient, lines925--943: Q is the actual evaluation
image in the product of actual coordinate ranges f(M). Its lattice operations
are induced by the proved coordinate congruence, continuous by the actual
compact-to-Hausdorff quotient product, and complete by the proved finite-net
argument. Its order is the quotient lattice order, not the unrelated pointwise
order of arbitrary real-valued coordinates. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology BigOperators
universe u

namespace ScottSpectraReviewed
namespace MetricLatticeQuotient

theorem orderClosedTopology_of_continuousInf {P : Type*} [Lattice P]
    [TopologicalSpace P] [T2Space P] [ContinuousInf P] : OrderClosedTopology P := by
  constructor
  have heq : {p : P × P | p.1 ≤ p.2} = {p | p.1 ⊓ p.2 = p.1} := by
    ext p
    simp only [mem_setOf_eq, inf_eq_left]
  rw [heq]
  exact isClosed_eq continuous_inf continuous_fst

variable {M : Type u} [TopologicalSpace M] [CompleteLattice M]
variable [CompactSpace M] [T2Space M] [ContinuousInf M] [ContinuousSup M]

def coordinates (F₀ : Set C(M, ℝ)) (a : M) :
    ∀ f : closedFamily F₀, Set.range (f.1 : M → ℝ) :=
  fun f => ⟨f.1 a, a, rfl⟩

/-- A non-reducible type alias of the literal evaluation range prevents Lean
from silently giving Q the ambient real-coordinate order. Its topology below
is still exactly the ordinary subtype topology of this literal range. -/
def CoordinateImage (F₀ : Set C(M, ℝ)) : Type u := Set.range (coordinates F₀)

instance coordinateImageTopologicalSpace (F₀ : Set C(M, ℝ)) :
    TopologicalSpace (CoordinateImage F₀) :=
  inferInstanceAs (TopologicalSpace (Set.range (coordinates F₀)))

instance coordinateImageT2Space (F₀ : Set C(M, ℝ)) : T2Space (CoordinateImage F₀) :=
  inferInstanceAs (T2Space (Set.range (coordinates F₀)))

def evaluation (F₀ : Set C(M, ℝ)) (a : M) : CoordinateImage F₀ :=
  ⟨coordinates F₀ a, a, rfl⟩

theorem evaluation_surjective (F₀ : Set C(M, ℝ)) : Function.Surjective (evaluation F₀) := by
  rintro ⟨y, a, rfl⟩
  exact ⟨a, rfl⟩

theorem continuous_coordinates (F₀ : Set C(M, ℝ)) : Continuous (coordinates F₀) :=
  continuous_pi fun f => f.1.continuous.subtype_mk _

theorem continuous_evaluation (F₀ : Set C(M, ℝ)) : Continuous (evaluation F₀) :=
  (continuous_coordinates F₀).subtype_mk _

instance coordinateImageCompactSpace (F₀ : Set C(M, ℝ)) : CompactSpace (CoordinateImage F₀) :=
  isCompact_iff_compactSpace.mp (isCompact_range (continuous_coordinates F₀))

theorem coordinateImage_metrizable (F₀ : Set C(M, ℝ)) (hF : F₀.Countable) :
    MetrizableSpace (CoordinateImage F₀) := by
  letI : Countable (closedFamily F₀) := (closedFamily_countable hF).to_subtype
  exact inferInstanceAs (MetrizableSpace (Set.range (coordinates F₀)))

theorem evaluation_eq_iff (F₀ : Set C(M, ℝ)) (a b : M) :
    evaluation F₀ a = evaluation F₀ b ↔ SameCoordinates (closedFamily F₀) a b := by
  constructor
  · intro h f hf
    have hcoord := congrFun (congrArg Subtype.val h) ⟨f, hf⟩
    exact congrArg Subtype.val hcoord
  · intro h
    apply Subtype.ext
    funext f
    apply Subtype.ext
    exact h f.1 f.2

def representative (F₀ : Set C(M, ℝ)) (z : CoordinateImage F₀) : M :=
  Classical.choose z.2

theorem evaluation_representative (F₀ : Set C(M, ℝ)) (z : CoordinateImage F₀) :
    evaluation F₀ (representative F₀ z) = z :=
  Subtype.ext (Classical.choose_spec z.2)

def imageInf (F₀ : Set C(M, ℝ)) (x y : CoordinateImage F₀) : CoordinateImage F₀ :=
  evaluation F₀ (representative F₀ x ⊓ representative F₀ y)

def imageSup (F₀ : Set C(M, ℝ)) (x y : CoordinateImage F₀) : CoordinateImage F₀ :=
  evaluation F₀ (representative F₀ x ⊔ representative F₀ y)

theorem imageInf_evaluation (F₀ : Set C(M, ℝ)) (a b : M) :
    imageInf F₀ (evaluation F₀ a) (evaluation F₀ b) = evaluation F₀ (a ⊓ b) := by
  apply (evaluation_eq_iff F₀ _ _).mpr
  exact sameCoordinates_operation F₀
    ((evaluation_eq_iff F₀ _ _).mp (evaluation_representative F₀ (evaluation F₀ a)))
    ((evaluation_eq_iff F₀ _ _).mp (evaluation_representative F₀ (evaluation F₀ b))) false

theorem imageSup_evaluation (F₀ : Set C(M, ℝ)) (a b : M) :
    imageSup F₀ (evaluation F₀ a) (evaluation F₀ b) = evaluation F₀ (a ⊔ b) := by
  apply (evaluation_eq_iff F₀ _ _).mpr
  exact sameCoordinates_operation F₀
    ((evaluation_eq_iff F₀ _ _).mp (evaluation_representative F₀ (evaluation F₀ a)))
    ((evaluation_eq_iff F₀ _ _).mp (evaluation_representative F₀ (evaluation F₀ b))) true

instance coordinateImageMin (F₀ : Set C(M, ℝ)) : Min (CoordinateImage F₀) := ⟨imageInf F₀⟩
instance coordinateImageMax (F₀ : Set C(M, ℝ)) : Max (CoordinateImage F₀) := ⟨imageSup F₀⟩

@[simp] theorem image_inf_evaluation (F₀ : Set C(M, ℝ)) (a b : M) :
    evaluation F₀ a ⊓ evaluation F₀ b = evaluation F₀ (a ⊓ b) := imageInf_evaluation F₀ a b

@[simp] theorem image_sup_evaluation (F₀ : Set C(M, ℝ)) (a b : M) :
    evaluation F₀ a ⊔ evaluation F₀ b = evaluation F₀ (a ⊔ b) := imageSup_evaluation F₀ a b

instance coordinateImageLattice (F₀ : Set C(M, ℝ)) : Lattice (CoordinateImage F₀) :=
  Lattice.mk'
    (by
      intro x y
      obtain ⟨a, rfl⟩ := evaluation_surjective F₀ x
      obtain ⟨b, rfl⟩ := evaluation_surjective F₀ y
      simp only [image_sup_evaluation, sup_comm])
    (by
      intro x y z
      obtain ⟨a, rfl⟩ := evaluation_surjective F₀ x
      obtain ⟨b, rfl⟩ := evaluation_surjective F₀ y
      obtain ⟨c, rfl⟩ := evaluation_surjective F₀ z
      simp only [image_sup_evaluation, sup_assoc])
    (by
      intro x y
      obtain ⟨a, rfl⟩ := evaluation_surjective F₀ x
      obtain ⟨b, rfl⟩ := evaluation_surjective F₀ y
      simp only [image_inf_evaluation, inf_comm])
    (by
      intro x y z
      obtain ⟨a, rfl⟩ := evaluation_surjective F₀ x
      obtain ⟨b, rfl⟩ := evaluation_surjective F₀ y
      obtain ⟨c, rfl⟩ := evaluation_surjective F₀ z
      simp only [image_inf_evaluation, inf_assoc])
    (by
      intro x y
      obtain ⟨a, rfl⟩ := evaluation_surjective F₀ x
      obtain ⟨b, rfl⟩ := evaluation_surjective F₀ y
      simp only [image_sup_evaluation, image_inf_evaluation, sup_inf_self])
    (by
      intro x y
      obtain ⟨a, rfl⟩ := evaluation_surjective F₀ x
      obtain ⟨b, rfl⟩ := evaluation_surjective F₀ y
      simp only [image_sup_evaluation, image_inf_evaluation, inf_sup_self])

def evaluationLatticeHom (F₀ : Set C(M, ℝ)) : LatticeHom M (CoordinateImage F₀) where
  toFun := evaluation F₀
  map_inf' a b := (image_inf_evaluation F₀ a b).symm
  map_sup' a b := (image_sup_evaluation F₀ a b).symm

theorem isQuotientMap_evaluation_product (F₀ : Set C(M, ℝ)) :
    Topology.IsQuotientMap
      (fun p : M × M => (evaluation F₀ p.1, evaluation F₀ p.2)) := by
  apply _root_.IsQuotientMap.of_surjective_continuous
  · rintro ⟨x, y⟩
    obtain ⟨a, rfl⟩ := evaluation_surjective F₀ x
    obtain ⟨b, rfl⟩ := evaluation_surjective F₀ y
    exact ⟨(a, b), rfl⟩
  · exact ((continuous_evaluation F₀).comp continuous_fst).prodMk
      ((continuous_evaluation F₀).comp continuous_snd)

instance coordinateImageContinuousInf (F₀ : Set C(M, ℝ)) :
    ContinuousInf (CoordinateImage F₀) := by
  constructor
  apply (isQuotientMap_evaluation_product F₀).continuous_iff.mpr
  simpa only [Function.comp_def, image_inf_evaluation] using
    (continuous_evaluation F₀).comp continuous_inf

instance coordinateImageContinuousSup (F₀ : Set C(M, ℝ)) :
    ContinuousSup (CoordinateImage F₀) := by
  constructor
  apply (isQuotientMap_evaluation_product F₀).continuous_iff.mpr
  simpa only [Function.comp_def, image_sup_evaluation] using
    (continuous_evaluation F₀).comp continuous_sup

instance coordinateImageOrderClosedTopology (F₀ : Set C(M, ℝ)) :
    OrderClosedTopology (CoordinateImage F₀) := orderClosedTopology_of_continuousInf

instance coordinateImageCompleteLattice (F₀ : Set C(M, ℝ)) :
    CompleteLattice (CoordinateImage F₀) := by
  letI : OrderClosedTopology M := orderClosedTopology_of_continuousInf
  exact quotientCompleteLattice (evaluationLatticeHom F₀)
    (evaluation_surjective F₀) (continuous_evaluation F₀)

def evaluationCompleteLatticeHom (F₀ : Set C(M, ℝ)) :
    CompleteLatticeHom M (CoordinateImage F₀) := by
  letI : OrderClosedTopology M := orderClosedTopology_of_continuousInf
  exact quotientCompleteLatticeHom (evaluationLatticeHom F₀)
    (evaluation_surjective F₀) (continuous_evaluation F₀)

@[simp] theorem evaluationCompleteLatticeHom_apply (F₀ : Set C(M, ℝ)) (a : M) :
    evaluationCompleteLatticeHom F₀ a = evaluation F₀ a := rfl

/-- A useful explicit check that the order is the quotient lattice order,
not the generally unrelated pointwise order of real coordinates. -/
theorem evaluation_le_iff (F₀ : Set C(M, ℝ)) (a b : M) :
    evaluation F₀ a ≤ evaluation F₀ b ↔
      SameCoordinates (closedFamily F₀) (a ⊓ b) a := by
  rw [← inf_eq_left, image_inf_evaluation, evaluation_eq_iff]

def coordinateFactor (F₀ : Set C(M, ℝ)) (f : closedFamily F₀) :
    C(CoordinateImage F₀, ℝ) where
  toFun z := (z.1 f).1
  continuous_toFun := continuous_subtype_val.comp
    ((continuous_apply f).comp continuous_subtype_val)

@[simp] theorem coordinateFactor_evaluation (F₀ : Set C(M, ℝ)) (f : closedFamily F₀) (a : M) :
    coordinateFactor F₀ f (evaluation F₀ a) = f.1 a := rfl

end MetricLatticeQuotient
end ScottSpectraReviewed
