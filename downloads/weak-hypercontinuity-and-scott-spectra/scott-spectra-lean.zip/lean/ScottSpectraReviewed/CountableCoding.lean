import ScottSpectraReviewed.BorelCore
import ScottSpectraReviewed.CountableRankFusion
import ScottSpectraReviewed.AnalyticRank

/-! Source thm:countable, lines723--766: decreasing actual open local
bases, the literal countable union of principal ideals, its Borel core code,
and the actual Borel well-founded relation on Nat times Cantor space. -/

noncomputable section
open Set TopologicalSpace Filter Ordinal Order
open scoped Topology Cardinal
universe u

namespace ScottSpectraReviewed
namespace Countable

open BorelCore

abbrev RankCarrier := ℕ × Cantor

theorem rankCarrier_polishSpace : PolishSpace RankCarrier := by
  letI : MetricSpace Cantor := PiNat.metricSpace
  infer_instance

theorem exists_decreasing_open_localBasis {X : Type u} [TopologicalSpace X]
    [FirstCountableTopology X] (x : X) :
    ∃ V : ℕ → Set X, (∀ n, IsOpen (V n) ∧ x ∈ V n) ∧ Antitone V ∧
      ∀ U : Set X, IsOpen U → x ∈ U → ∃ n, V n ⊆ U := by
  obtain ⟨V, hV, hbase⟩ := (nhds_basis_opens x).exists_antitone_subbasis
  refine ⟨V, fun n => ⟨(hV n).2, (hV n).1⟩, hbase.antitone, ?_⟩
  intro U hU hxU
  obtain ⟨n, _, hn⟩ := hbase.1.mem_iff.mp (hU.mem_nhds hxU)
  exact ⟨n, hn⟩

def sequenceLowerSet {X : Type u} [Preorder X] (b : ℕ → X) : Set X :=
  ⋃ n, Set.Iic (b n)

theorem sequenceLowerSet_isLowerSet {X : Type u} [Preorder X] (b : ℕ → X) :
    IsLowerSet (sequenceLowerSet b) := by
  intro a c hac hc
  obtain ⟨n, hcn⟩ := mem_iUnion.mp hc
  exact mem_iUnion.mpr ⟨n, hac.trans hcn⟩

theorem sequenceLowerSet_subset {X : Type u} [Preorder X]
    (b : ℕ → X) {B : Set X} (hB : IsLowerSet B) (hbB : ∀ n, b n ∈ B) :
    sequenceLowerSet b ⊆ B := by
  intro a ha
  obtain ⟨n, han⟩ := mem_iUnion.mp ha
  exact hB han (hbB n)

/-- The source H intersect V_n, represented as an actual ambient Cantor set.
The open-code sets O_n need only have the prescribed preimages: continuity
of e into Cantor is neither assumed nor needed. -/
def codedLevel {X : Type u} [PartialOrder X] (e : X ↪o Cantor)
    (G : Set X) (b : ℕ → X) (O : ℕ → Set Cantor) (n : ℕ) : Set Cantor :=
  ((e '' G) ∩ ⋃ m, Set.Iic (e (b m))) ∩ O n

theorem codedLevel_eq_image {X : Type u} [PartialOrder X] (e : X ↪o Cantor)
    (G : Set X) (b : ℕ → X) (O : ℕ → Set Cantor) (V : ℕ → Set X)
    (hO : ∀ n, e ⁻¹' O n = V n) (n : ℕ) :
    codedLevel e G b O n = e '' level G (sequenceLowerSet b) V n := by
  ext a
  constructor
  · rintro ⟨⟨⟨g, hgG, rfl⟩, hgS⟩, hgO⟩
    obtain ⟨m, hgm⟩ := mem_iUnion.mp hgS
    have hgV : g ∈ V n := by
      rw [← hO n]
      exact hgO
    exact ⟨g, ⟨⟨hgG, mem_iUnion.mpr ⟨m, e.le_iff_le.mp hgm⟩⟩, hgV⟩, rfl⟩
  · rintro ⟨g, ⟨⟨hgG, hgS⟩, hgV⟩, rfl⟩
    obtain ⟨m, hgm⟩ := mem_iUnion.mp hgS
    have hgO : e g ∈ O n := by
      change g ∈ e ⁻¹' O n
      rw [hO n]
      exact hgV
    exact ⟨⟨⟨g, hgG, rfl⟩, mem_iUnion.mpr ⟨m, e.monotone hgm⟩⟩, hgO⟩

theorem codedLevel_measurable {X : Type u} [PartialOrder X] (e : X ↪o Cantor)
    (G : Set X) (b : ℕ → X) (O : ℕ → Set Cantor)
    (hG : @MeasurableSet Cantor (borel Cantor) (e '' G))
    (hO : ∀ n, IsOpen (O n)) (n : ℕ) :
    @MeasurableSet Cantor (borel Cantor) (codedLevel e G b O n) := by
  letI : OrderClosedTopology Cantor := cantor_orderClosedTopology
  letI : MeasurableSpace Cantor := borel Cantor
  letI : BorelSpace Cantor := ⟨rfl⟩
  exact (hG.inter (MeasurableSet.iUnion fun m =>
    (isClosed_Iic : IsClosed (Set.Iic (e (b m)))).measurableSet)).inter
      (hO n).measurableSet

/-- Literal source relation: (n+1,b) R (n,a) iff a is at level n,
b is at level n+1 and a is pointwise below b. -/
def codedRelation (C : ℕ → Set Cantor) (w z : RankCarrier) : Prop :=
  w.1 = z.1 + 1 ∧ z.2 ∈ C z.1 ∧ w.2 ∈ C w.1 ∧ z.2 ≤ w.2

theorem codedRelation_measurable (C : ℕ → Set Cantor)
    (hC : ∀ n, @MeasurableSet Cantor (borel Cantor) (C n)) :
    @MeasurableSet (RankCarrier × RankCarrier) (borel (RankCarrier × RankCarrier))
      {p | codedRelation C p.1 p.2} := by
  classical
  letI : OrderClosedTopology Cantor := cantor_orderClosedTopology
  letI : MeasurableSpace Cantor := borel Cantor
  letI : BorelSpace Cantor := ⟨rfl⟩
  have heq : {p : RankCarrier × RankCarrier | codedRelation C p.1 p.2} =
      (⋃ n : ℕ, (({n + 1} : Set ℕ) ×ˢ C (n + 1)) ×ˢ
        (({n} : Set ℕ) ×ˢ C n)) ∩ {p | p.2.2 ≤ p.1.2} := by
    ext ⟨w, z⟩
    constructor
    · rintro ⟨hidx, hz, hw, hle⟩
      refine ⟨mem_iUnion.mpr ⟨z.1, ?_⟩, hle⟩
      exact ⟨⟨hidx, hidx ▸ hw⟩, ⟨rfl, hz⟩⟩
    · rintro ⟨hp, hle⟩
      obtain ⟨n, ⟨⟨hwidx, hw⟩, ⟨hzidx, hz⟩⟩⟩ := mem_iUnion.mp hp
      have hwidx' : w.1 = n + 1 := mem_singleton_iff.mp hwidx
      have hzidx' : z.1 = n := mem_singleton_iff.mp hzidx
      refine ⟨?_, ?_, ?_, hle⟩
      · change w.1 = z.1 + 1
        omega
      · simpa only [hzidx'] using hz
      · simpa only [hwidx'] using hw
  have hm : MeasurableSet {p : RankCarrier × RankCarrier | codedRelation C p.1 p.2} := by
    rw [heq]
    apply MeasurableSet.inter
    · exact MeasurableSet.iUnion (fun n =>
        ((isClosed_singleton : IsClosed ({n + 1} : Set ℕ)).measurableSet.prod (hC (n + 1))).prod
          ((isClosed_singleton : IsClosed ({n} : Set ℕ)).measurableSet.prod (hC n)))
    · exact (isClosed_le continuous_snd.snd continuous_fst.snd).measurableSet
  exact BorelSpace.measurable_eq (α := RankCarrier × RankCarrier) ▸ hm

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance countableCodingSpecializationOrder : PartialOrder X := specializationOrder X

/-- The actual source infinite-chain contradiction. The directed supremum
is taken in X, not the ambient Cantor space, and Scott closedness of B is
applied to its actual increasing range. -/
theorem codedRelation_wellFounded (hdcpo : IsDcpo X) (e : X ↪o Cantor)
    (B : Set X) (hB : IsClosed[scottTopology X] B) (x : X) (hxB : x ∉ B)
    (V : ℕ → Set X) (hV : ∀ n, IsOpen (V n)) (hVanti : Antitone V)
    (hVbasis : ∀ U : Set X, IsOpen U → x ∈ U → ∃ n, V n ⊆ U)
    (G : Set X) (b : ℕ → X) (hbB : ∀ n, b n ∈ B)
    (C : ℕ → Set Cantor)
    (hC : ∀ n, C n = e '' level G (sequenceLowerSet b) V n) :
    WellFounded (codedRelation C) := by
  classical
  have hBclosed := (isScottClosed_iff B).mp hB
  have hSB := sequenceLowerSet_subset b hBclosed.1 hbB
  apply wellFounded_iff_isEmpty_descending_chain.mpr
  constructor
  rintro ⟨z, hz⟩
  have hindex : ∀ k, (z k).1 = (z 0).1 + k := by
    intro k
    induction k with
    | zero => simp
    | succ k ih => rw [(hz k).1, ih]; omega
  have hchoices : ∀ k : ℕ, ∃ a : X,
      a ∈ level G (sequenceLowerSet b) V (z k).1 ∧ e a = (z k).2 := by
    intro k
    have hk : (z k).2 ∈ C (z k).1 := (hz k).2.1
    rw [hC (z k).1] at hk
    exact hk
  choose a haLevel hae using hchoices
  have hmono : Monotone a := by
    apply monotone_nat_of_le_succ
    intro k
    apply e.le_iff_le.mp
    rw [hae k, hae (k + 1)]
    exact (hz k).2.2.2
  have hD : NonemptyDirected (Set.range a) := by
    refine ⟨range_nonempty a, ?_⟩
    rintro _ ⟨k, rfl⟩ _ ⟨l, rfl⟩
    exact ⟨a (max k l), ⟨max k l, rfl⟩, hmono (le_max_left k l), hmono (le_max_right k l)⟩
  obtain ⟨sup, hsup⟩ := hdcpo (range a) hD
  have hsupB : sup ∈ B := hBclosed.2 (by
    rintro _ ⟨k, rfl⟩
    exact hSB (haLevel k).1.2) hD.1 hD.2 hsup
  have hsupV : ∀ k, sup ∈ V k := by
    intro k
    have hkindex : k ≤ (z k).1 := by rw [hindex k]; omega
    have hak : a k ∈ V k := hVanti hkindex (haLevel k).2
    exact isOpen_upper_specialization (hV k)
      ((specializationLE_iff (a k) sup).mpr (hsup.1 (mem_range_self k))) hak
  have hxSup : x ≤ sup := by
    apply (specializationLE_iff x sup).mp
    apply mem_closure_iff.mpr
    intro U hU hxU
    obtain ⟨k, hk⟩ := hVbasis U hU hxU
    exact ⟨sup, hk (hsupV k), mem_singleton sup⟩
  exact hxB (hBclosed.1 hxSup hsupB)

end Countable
end ScottSpectraReviewed
