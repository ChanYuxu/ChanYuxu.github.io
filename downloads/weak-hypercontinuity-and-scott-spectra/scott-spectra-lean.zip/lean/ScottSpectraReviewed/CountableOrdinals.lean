import Mathlib.SetTheory.Ordinal.FundamentalSequence
import Mathlib.SetTheory.Cardinal.Ordinal

/-! The elementary ordinal steps used at source lines 777--816: stabilization
of a decreasing ordinal sequence and an increasing cofinal sequence in a
nonzero countable limit ordinal. These are actual ordinal results; no source
rank bound or topology conclusion is assumed or included in a definition. -/

noncomputable section
open Set Ordinal Order Cardinal
universe u

namespace ScottSpectraReviewed
namespace CountableRank

theorem antitone_eventually_constant (β : ℕ → Ordinal.{u}) (hβ : Antitone β) :
    ∃ N : ℕ, ∀ n, N ≤ n → β n = β N := by
  obtain ⟨_,⟨N,rfl⟩,hmin⟩ := Ordinal.lt_wf.has_min (range β) (range_nonempty β)
  refine ⟨N,?_⟩
  intro n hn
  exact le_antisymm (hβ hn) (le_of_not_gt (hmin (β n) (mem_range_self n)))

/-- Exactly the monotone/cofinal sequence used in the source limit case,
with the explicit successor-supremum identity required at the final step. -/
theorem exists_monotone_cofinal_sequence (limitOrdinal : Ordinal.{u})
    (hlim : IsSuccLimit limitOrdinal) (hcountable : limitOrdinal < ω₁) :
    ∃ γ : ℕ → Ordinal.{u}, Monotone γ ∧ (∀ n, γ n < limitOrdinal) ∧
      (∀ a < limitOrdinal, ∃ n, a ≤ γ n) ∧ (⨆ n, γ n + 1) = limitOrdinal := by
  have hcof : limitOrdinal.cof.ord = ω := by
    rw [Ordinal.cof_eq_aleph0_of_isSuccLimit hlim hcountable]
    simp
  obtain ⟨f,hf⟩ := Ordinal.exists_isFundamentalSeq hcof
  let γ : ℕ → Ordinal.{u} := fun n => (f ⟨n,Ordinal.natCast_lt_omega0 n⟩).val
  have hmono : Monotone γ := by
    intro n m hnm
    apply hf.strictMono.monotone
    change (n : Ordinal.{u}) ≤ (m : Ordinal.{u})
    exact_mod_cast hnm
  have hγ : ∀ n, γ n < limitOrdinal := fun n => (f ⟨n,Ordinal.natCast_lt_omega0 n⟩).property
  have hcofinal : ∀ a < limitOrdinal, ∃ n, a ≤ γ n := by
    intro a ha
    obtain ⟨_,⟨j,rfl⟩,haj⟩ := hf.isCofinal_range ⟨a,ha⟩
    obtain ⟨n,hn⟩ := Ordinal.lt_omega0.mp j.property
    have hj : j = ⟨n,Ordinal.natCast_lt_omega0 n⟩ := Subtype.ext hn
    refine ⟨n,?_⟩
    change a ≤ (f j).val at haj
    change a ≤ (f ⟨n,Ordinal.natCast_lt_omega0 n⟩).val
    rw [← hj]
    exact haj
  refine ⟨γ,hmono,hγ,hcofinal,?_⟩
  apply le_antisymm
  · apply Ordinal.iSup_le
    intro n
    exact add_one_le_iff.mpr (hγ n)
  · apply le_of_forall_lt
    intro a ha
    obtain ⟨n,han⟩ := hcofinal a ha
    exact han.trans_lt ((lt_add_one (γ n)).trans_le
      (Ordinal.le_iSup (fun n => γ n + 1) n))

end CountableRank
end ScottSpectraReviewed
