import ScottSpectraReviewed.MetricLatticeQuotientApprox
import Mathlib.Topology.Order.Lattice
import Mathlib.Data.Set.Countable
import Mathlib.Tactic.Positivity

/-! Source lem:metric-quotient, lines910--925: the actual countable
closure under all partition weights and translations, for both lattice
operations and every positive reciprocal threshold. The evaluation kernel is
proved to be a lattice congruence using the actual uniform approximations. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology BigOperators
universe u

namespace ScottSpectraReviewed
namespace MetricLatticeQuotient

variable {M : Type u} [TopologicalSpace M]

/-- Finite actual approximation data, not a proof certificate: the uniform
approximation theorem is an external proved property of the chosen data. -/
abbrev ApproximationData (M : Type u) [TopologicalSpace M] :=
  Σ r : ℕ, (Fin r → M) × (Fin r → Set M) × PartitionOfUnity (Fin r) M

def latticeOperation [Lattice M] : Bool → M → M → M
  | false => (· ⊓ ·)
  | true => (· ⊔ ·)

theorem latticeOperation_continuous [Lattice M] [ContinuousInf M] [ContinuousSup M]
    (o : Bool) : Continuous fun p : M × M => latticeOperation o p.1 p.2 := by
  cases o
  · exact continuous_inf
  · exact continuous_sup

variable [Lattice M] [CompactSpace M] [T2Space M] [ContinuousInf M] [ContinuousSup M]

theorem approximationData_exists (f : C(M, ℝ)) (o : Bool) (n : ℕ) :
    ∃ d : ApproximationData M,
      (∀ i, IsOpen (d.2.2.1 i)) ∧ univ ⊆ ⋃ i, d.2.2.1 i ∧
        d.2.2.2.IsSubordinate d.2.2.1 ∧
        (∀ i a, a ∈ d.2.2.1 i →
          ‖translation f (latticeOperation o) (latticeOperation_continuous o) a -
            translation f (latticeOperation o) (latticeOperation_continuous o) (d.2.1 i)‖ <
              1 / (n + 1 : ℝ)) ∧
        ‖operationFunction f (latticeOperation o) (latticeOperation_continuous o) -
          finiteApproximation f (latticeOperation o) (latticeOperation_continuous o) d.2.1 d.2.2.2‖ <
            1 / (n + 1 : ℝ) := by
  obtain ⟨r, centers, V, φ, hV, hcover, hsub, hlocal, herror⟩ :=
    exists_partition_approximation f (latticeOperation o) (latticeOperation_continuous o)
      (1 / (n + 1 : ℝ)) (by positivity)
  exact ⟨⟨r, centers, V, φ⟩, hV, hcover, hsub, hlocal, herror⟩

def approximationData (f : C(M, ℝ)) (o : Bool) (n : ℕ) : ApproximationData M :=
  Classical.choose (approximationData_exists f o n)

theorem approximationData_cover_spec (f : C(M, ℝ)) (o : Bool) (n : ℕ) :
    let d := approximationData f o n
    (∀ i, IsOpen (d.2.2.1 i)) ∧ univ ⊆ ⋃ i, d.2.2.1 i ∧
      d.2.2.2.IsSubordinate d.2.2.1 ∧
      ∀ i a, a ∈ d.2.2.1 i →
        ‖translation f (latticeOperation o) (latticeOperation_continuous o) a -
          translation f (latticeOperation o) (latticeOperation_continuous o) (d.2.1 i)‖ <
            1 / (n + 1 : ℝ) := by
  have h := Classical.choose_spec (approximationData_exists f o n)
  exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2.1⟩

theorem approximationData_spec (f : C(M, ℝ)) (o : Bool) (n : ℕ) :
    ‖operationFunction f (latticeOperation o) (latticeOperation_continuous o) -
      finiteApproximation f (latticeOperation o) (latticeOperation_continuous o)
        (approximationData f o n).2.1 (approximationData f o n).2.2.2‖ <
          1 / (n + 1 : ℝ) :=
  (Classical.choose_spec (approximationData_exists f o n)).2.2.2.2

def approximationWeight (f : C(M, ℝ)) (o : Bool) (n : ℕ) :
    Fin (approximationData f o n).1 → C(M, ℝ) :=
  (approximationData f o n).2.2.2

def approximationTranslate (f : C(M, ℝ)) (o : Bool) (n : ℕ) :
    Fin (approximationData f o n).1 → C(M, ℝ) :=
  fun i => translation f (latticeOperation o) (latticeOperation_continuous o)
    ((approximationData f o n).2.1 i)

def chosenApproximation (f : C(M, ℝ)) (o : Bool) (n : ℕ) : C(M × M, ℝ) :=
  finiteApproximation f (latticeOperation o) (latticeOperation_continuous o)
    (approximationData f o n).2.1 (approximationData f o n).2.2.2

@[simp] theorem chosenApproximation_apply (f : C(M, ℝ)) (o : Bool) (n : ℕ) (a b : M) :
    chosenApproximation f o n (a, b) =
      ∑ i, approximationWeight f o n i a * approximationTranslate f o n i b := rfl

def familyStep (F : Set C(M, ℝ)) : Set C(M, ℝ) :=
  F ∪ ⋃ f ∈ F, ⋃ o : Bool, ⋃ n : ℕ,
    (Set.range (approximationWeight f o n) ∪ Set.range (approximationTranslate f o n))

def familyStage (F₀ : Set C(M, ℝ)) : ℕ → Set C(M, ℝ) :=
  Nat.rec F₀ (fun _ F => familyStep F)

def closedFamily (F₀ : Set C(M, ℝ)) : Set C(M, ℝ) :=
  ⋃ k : ℕ, familyStage F₀ k

theorem familyStep_countable {F : Set C(M, ℝ)} (hF : F.Countable) :
    (familyStep F).Countable := by
  exact hF.union (hF.biUnion fun f _hf => countable_iUnion fun o =>
    countable_iUnion fun n => (countable_range (approximationWeight f o n)).union
      (countable_range (approximationTranslate f o n)))

theorem familyStage_countable {F₀ : Set C(M, ℝ)} (hF : F₀.Countable) (k : ℕ) :
    (familyStage F₀ k).Countable := by
  induction k with
  | zero => exact hF
  | succ k ih => exact familyStep_countable ih

theorem closedFamily_countable {F₀ : Set C(M, ℝ)} (hF : F₀.Countable) :
    (closedFamily F₀).Countable := countable_iUnion (familyStage_countable hF)

theorem subset_closedFamily (F₀ : Set C(M, ℝ)) : F₀ ⊆ closedFamily F₀ :=
  fun _f hf => mem_iUnion.mpr ⟨0, hf⟩

theorem approximationWeight_mem_closedFamily {F₀ : Set C(M, ℝ)} {f : C(M, ℝ)}
    (hf : f ∈ closedFamily F₀) (o : Bool) (n : ℕ)
    (i : Fin (approximationData f o n).1) :
    approximationWeight f o n i ∈ closedFamily F₀ := by
  obtain ⟨k, hfk⟩ := mem_iUnion.mp hf
  refine mem_iUnion.mpr ⟨k + 1, Or.inr ?_⟩
  exact mem_iUnion₂.mpr ⟨f, hfk, mem_iUnion.mpr
    ⟨o, mem_iUnion.mpr ⟨n, Or.inl (mem_range_self i)⟩⟩⟩

theorem approximationTranslate_mem_closedFamily {F₀ : Set C(M, ℝ)} {f : C(M, ℝ)}
    (hf : f ∈ closedFamily F₀) (o : Bool) (n : ℕ)
    (i : Fin (approximationData f o n).1) :
    approximationTranslate f o n i ∈ closedFamily F₀ := by
  obtain ⟨k, hfk⟩ := mem_iUnion.mp hf
  refine mem_iUnion.mpr ⟨k + 1, Or.inr ?_⟩
  exact mem_iUnion₂.mpr ⟨f, hfk, mem_iUnion.mpr
    ⟨o, mem_iUnion.mpr ⟨n, Or.inr (mem_range_self i)⟩⟩⟩

def SameCoordinates (F : Set C(M, ℝ)) (a b : M) : Prop :=
  ∀ f ∈ F, f a = f b

/-- Source congruence, derived from the actual approximation data and the
actual all-n countable closure. It is not an input certificate. -/
theorem sameCoordinates_operation (F₀ : Set C(M, ℝ)) {a a' b b' : M}
    (ha : SameCoordinates (closedFamily F₀) a a')
    (hb : SameCoordinates (closedFamily F₀) b b') (o : Bool) :
    SameCoordinates (closedFamily F₀)
      (latticeOperation o a b) (latticeOperation o a' b') := by
  intro f hf
  have hsum (n : ℕ) : chosenApproximation f o n (a, b) =
      chosenApproximation f o n (a', b') := by
    simp only [chosenApproximation_apply]
    apply Finset.sum_congr rfl
    intro i hi
    exact congrArg₂ (· * ·)
      (ha _ (approximationWeight_mem_closedFamily hf o n i))
      (hb _ (approximationTranslate_mem_closedFamily hf o n i))
  have herror (n : ℕ) (c d : M) :
      |f (latticeOperation o c d) - chosenApproximation f o n (c, d)| <
        1 / (n + 1 : ℝ) := by
    have hpoint := (operationFunction f (latticeOperation o) (latticeOperation_continuous o) -
      chosenApproximation f o n).norm_coe_le_norm (c, d)
    have hpoint' : |f (latticeOperation o c d) - chosenApproximation f o n (c, d)| ≤
        ‖operationFunction f (latticeOperation o) (latticeOperation_continuous o) -
          chosenApproximation f o n‖ := by
      simpa only [ContinuousMap.sub_apply, operationFunction_apply, Real.norm_eq_abs] using hpoint
    exact hpoint'.trans_lt (approximationData_spec f o n)
  have hdiff (n : ℕ) :
      |f (latticeOperation o a b) - f (latticeOperation o a' b')| <
        1 / (n + 1 : ℝ) + 1 / (n + 1 : ℝ) := by
    have hsecond : |chosenApproximation f o n (a, b) - f (latticeOperation o a' b')| <
        1 / (n + 1 : ℝ) := by
      rw [hsum n, abs_sub_comm]
      exact herror n a' b'
    exact (abs_sub_le _ _ _).trans_lt (add_lt_add (herror n a b) hsecond)
  by_contra hne
  have hpos : 0 < |f (latticeOperation o a b) - f (latticeOperation o a' b')| :=
    abs_pos.mpr (sub_ne_zero.mpr hne)
  obtain ⟨n, hn⟩ := exists_nat_one_div_lt (half_pos hpos)
  have hcontra := hdiff n
  linarith

end MetricLatticeQuotient
end ScottSpectraReviewed
