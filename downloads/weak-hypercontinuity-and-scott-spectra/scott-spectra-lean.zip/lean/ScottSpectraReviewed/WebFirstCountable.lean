import ScottSpectraReviewed.FirstCountableCore
import ScottSpectraReviewed.CanonicalRepair

/-! The exact source-facing fc-core wrapper. The lower-relation premise of
the internal construction is supplied by the actual canonical construction;
it is not an additional paper hypothesis. Countable families are zero-based,
equivalently reindexed from the source's positive integers. -/

noncomputable section
open Set TopologicalSpace Filter
open scoped Topology
universe u

namespace ScottSpectraReviewed

variable {X : Type u} [TopologicalSpace X] [T0Space X]
local instance webFcSpecializationOrder : PartialOrder X := specializationOrder X

theorem web_lowerRelationOpen (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    FirstCountableCore.LowerRelationOpen X := by
  intro U hU
  have h := ClosedLattice.canonical_lowerRelation_isOpen hlocal hweb U hU
  convert h using 1
  ext p
  change (∃ z ∈ U, p.1 ⤳ z ∧ p.2 ⤳ z) ↔
    (∃ z ∈ U, SpecializationLE z p.1 ∧ SpecializationLE z p.2)
  simp only [specializationLE_iff]

/-- Full source lemma fc-core, including all and only actually
first-countable points below x, their directedness and their actual LUB. -/
theorem source_fc_core [QuasiSober X] (hlocal : IsLocallyCompact X)
    (hweb : IsWebSpace X) :
    (∀ (x : X) (U : ℕ → Set X), (∀ n, U n ∈ 𝓝 x) →
      ∃ m : X, m ≤ x ∧ (∀ n, m ∈ U n) ∧ (𝓝 m).IsCountablyGenerated) ∧
    ∀ x : X, NonemptyDirected (FirstCountableCore.firstCountableBelow x) ∧
      IsLUB (FirstCountableCore.firstCountableBelow x) x :=
  FirstCountableCore.of_lowerRelation hlocal (web_lowerRelationOpen hlocal hweb)

end ScottSpectraReviewed
