import ScottSpectraReviewed.HostBase
import ScottSpectraReviewed.HostDiagonal
import Mathlib.Order.Nucleus

/-! Exact source Lemma `lem:nuclei` on the literal closure host.
The general closure-convergence argument is expressed with the nonbottom
pullback-neighborhood filter of join translations. It is not a sequential
density claim. Actual nucleus proofs are derived; no carrier field is added.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u

namespace ScottSpectraReviewed
namespace HostCarrier

variable {L : Type u} [CompleteLattice L]

theorem idempotent (hL : HostSectionContext L) (t : HostCarrier L) (x : L) :
    (t : L → L) ((t : L → L) x) = (t : L → L) x := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  letI : T2Space L := lawson_t2Space hL.1
  let F : Filter L := comap (joinTranslation (L := L)) (𝓝 (t : L → L))
  haveI : NeBot F := comap_neBot_iff_frequently.mpr
    (mem_closure_iff_frequently.mp t.property)
  have hc : Tendsto (joinTranslation (L := L)) F (𝓝 (t : L → L)) := map_comap_le
  let b : L := (t : L → L) x
  have hxb : x ≤ b := inflationary hL t x
  have hz : Tendsto (fun a : L => a ⊔ x) F (𝓝 b) :=
    ((continuous_apply x).tendsto (t : L → L)).comp hc
  have hzb : Tendsto (fun a : L => a ⊔ b) F (𝓝 ((t : L → L) b)) :=
    ((continuous_apply b).tendsto (t : L → L)).comp hc
  have hdiag := (source_diagonal hL b).tendsto.comp hz
  have hfun : (fun a : L => b ⊔ (a ⊔ x)) = (fun a : L => a ⊔ b) := by
    funext a
    rw [sup_left_comm, sup_eq_left.mpr hxb]
  have hlim : Tendsto (fun a : L => a ⊔ b) F (𝓝 b) := by
    change Tendsto (fun a : L => b ⊔ (a ⊔ x)) F (𝓝 (b ⊔ b)) at hdiag
    simpa only [hfun, sup_idem] using hdiag
  exact tendsto_nhds_unique hzb hlim

/-- A genuine Mathlib nucleus with exactly the original host function as its
underlying map, constructed from proved host laws. -/
def nucleus (hL : HostSectionContext L) (t : HostCarrier L) : Nucleus L where
  toFun := (t : L → L)
  map_inf' := preserves_inf hL t
  idempotent' := fun x => (idempotent hL t x).le
  le_apply' := inflationary hL t

@[simp] theorem nucleus_apply (hL : HostSectionContext L) (t : HostCarrier L) (x : L) :
    nucleus hL t x = (t : L → L) x := rfl

/-- Right composition with a fixed translation is continuous for the original
full product topology, so it preserves the actual closure host. -/
def composeTranslation (a : L) (t : HostCarrier L) : HostCarrier L := by
  letI : TopologicalSpace L := lawsonTopology L
  letI : TopologicalSpace (L → L) := hostAmbientTopology L
  refine ⟨(t : L → L) ∘ joinTranslation a, ?_⟩
  change (t : L → L) ∘ joinTranslation a ∈ closure (range (joinTranslation (L := L)))
  have hR : Continuous (fun f : L → L => f ∘ joinTranslation a) :=
    continuous_pi (fun x => continuous_apply (a ⊔ x))
  apply map_mem_closure hR t.property
  rintro _ ⟨b, rfl⟩
  refine ⟨a ⊔ b, ?_⟩
  funext x
  change (a ⊔ b) ⊔ x = b ⊔ (a ⊔ x)
  exact (sup_assoc a b x).trans (sup_left_comm a b x)

@[simp] theorem composeTranslation_apply (a : L) (t : HostCarrier L) (x : L) :
    (composeTranslation a t : L → L) x = (t : L → L) (a ⊔ x) := rfl

/-- The actual intrinsic host join, not a pointwise surrogate join. -/
theorem generator_join (hL : HostSectionContext L) (a : L) (t : HostCarrier L) :
    letI := completeLattice hL
    translation a ⊔ t = composeTranslation a t := by
  letI := completeLattice hL
  apply le_antisymm
  · apply sup_le
    · intro x
      exact inflationary hL t (a ⊔ x)
    · intro x
      exact monotone hL t le_sup_right
  · let s : HostCarrier L := translation a ⊔ t
    have hts : t ≤ s := le_sup_right
    have has : translation a ≤ s := le_sup_left
    intro x
    have hx : a ⊔ x ≤ (s : L → L) x := has x
    exact (hts (a ⊔ x)).trans ((monotone hL s hx).trans_eq (idempotent hL s x))

theorem generator_join_apply (hL : HostSectionContext L) (a : L) (t : HostCarrier L) (x : L) :
    letI := completeLattice hL
    ((translation a ⊔ t : HostCarrier L) : L → L) x = (t : L → L) (a ⊔ x) := by
  letI := completeLattice hL
  exact congrArg (fun s : HostCarrier L => (s : L → L) x) (generator_join hL a t)

/-- Joining with each actual generator preserves all host meets, including
the empty meet, by the proved composition formula and pointwise meets. -/
theorem generator_join_sInf (hL : HostSectionContext L) (a : L) (S : Set (HostCarrier L)) :
    letI := completeLattice hL
    translation a ⊔ sInf S = sInf ((fun t : HostCarrier L => translation a ⊔ t) '' S) := by
  letI := completeLattice hL
  apply Subtype.ext
  funext x
  rw [generator_join_apply hL, coe_sInf hL, coe_sInf hL,
    sInf_apply_eq_sInf_image, sInf_apply_eq_sInf_image]
  apply congrArg sInf
  ext y
  constructor
  · rintro ⟨f, ⟨t, ht, rfl⟩, hty⟩
    refine ⟨((translation a ⊔ t : HostCarrier L) : L → L),
      ⟨translation a ⊔ t, ⟨t, ht, rfl⟩, rfl⟩, ?_⟩
    exact (generator_join_apply hL a t x).trans hty
  · rintro ⟨f, ⟨t, ⟨s, hs, rfl⟩, rfl⟩, hsy⟩
    exact ⟨(s : L → L), ⟨s, hs, rfl⟩, (generator_join_apply hL a s x).symm.trans hsy⟩

/-- Exact original-facing nucleus/generator-join lemma. Every bundled nucleus
has exactly the literal host map as its underlying function. -/
theorem source_nuclei (hL : HostSectionContext L) :
    letI := completeLattice hL
    (∀ t : HostCarrier L, ∃ n : Nucleus L, (n : L → L) = (t : L → L)) ∧
    (∀ (a : L) (t : HostCarrier L), translation a ⊔ t = composeTranslation a t) ∧
    (∀ (a : L) (S : Set (HostCarrier L)),
      translation a ⊔ sInf S = sInf ((fun t : HostCarrier L => translation a ⊔ t) '' S)) := by
  letI := completeLattice hL
  exact ⟨fun t => ⟨nucleus hL t, rfl⟩, generator_join hL, generator_join_sInf hL⟩

end HostCarrier
end ScottSpectraReviewed
