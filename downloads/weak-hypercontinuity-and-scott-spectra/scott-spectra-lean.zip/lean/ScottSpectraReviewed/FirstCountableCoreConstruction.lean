import ScottSpectraReviewed.SoberWellFiltered
import Mathlib.Topology.Bases

/-! The actual compact-saturated neighborhood recursion in source Lemma
`lem:fc-core`, lines 833--887. The lower-relation openness input is kept
explicit in internal helpers until the canonical construction proves it.
No global first-countability, Hausdorffness or complete lattice is assumed.
-/

noncomputable section
open Set Filter TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed
namespace FirstCountableCore

variable {X : Type u} [TopologicalSpace X]

theorem saturated_iInter {ι : Type v} (K : ι → Set X)
    (hK : ∀ i, IsSaturated (K i)) : IsSaturated (⋂ i, K i) := by
  apply (isSaturated_iff_specialization_upper _).mpr
  intro x y hxy hx
  exact mem_iInter.mpr fun i =>
    (isSaturated_iff_specialization_upper _).mp (hK i) x y hxy (mem_iInter.mp hx i)

theorem exists_compact_saturated_nhds_subset (hX : IsLocallyCompact X)
    {x : X} {U : Set X} (hU : U ∈ 𝓝 x) :
    ∃ K : Set X, IsCompact K ∧ IsSaturated K ∧ K ∈ 𝓝 x ∧ K ⊆ U := by
  obtain ⟨O, hOU, hO, hxO⟩ := mem_nhds_iff.mp hU
  obtain ⟨V, K, hxV, hVK, hKO, hK, hKs⟩ := hX ⟨O, hO⟩ x hxO
  exact ⟨K, hK, hKs, mem_of_superset (V.isOpen.mem_nhds hxV) hVK, hKO.trans hOU⟩

/-- The full sober well-filtered open test applied to an arbitrary decreasing
compact-saturated sequence. The family is nonempty even when a member is empty. -/
theorem wellFiltered_antitone_test [QuasiSober X]
    (K : ℕ → Set X) (hK : ∀ n, IsCompact (K n) ∧ IsSaturated (K n))
    (hanti : Antitone K) {U : Set X} (hU : IsOpen U)
    (hinter : (⋂ n, K n) ⊆ U) : ∃ n, K n ⊆ U := by
  have hdir : DirectedOn (fun A B : Set X => B ⊆ A) (range K) := by
    rintro _ ⟨m, rfl⟩ _ ⟨n, rfl⟩
    exact ⟨K (max m n), mem_range_self _, hanti (le_max_left _ _), hanti (le_max_right _ _)⟩
  have hinter' : ⋂₀ range K ⊆ U := by
    intro x hx
    exact hinter (mem_iInter.mpr fun n => mem_sInter.mp hx _ (mem_range_self n))
  obtain ⟨_, ⟨n, rfl⟩, hn⟩ := WellFiltered.source_sober_wellFiltered
    (range K) (range_nonempty K) (by rintro _ ⟨n, rfl⟩; exact hK n) hdir U hU hinter'
  exact ⟨n, hn⟩

/-- The source open-cover proof of compactness of the filtered intersection.
No coherence of arbitrary compact-saturated intersections is assumed. -/
theorem wellFiltered_intersection_compact [QuasiSober X]
    (K : ℕ → Set X) (hK : ∀ n, IsCompact (K n) ∧ IsSaturated (K n))
    (hanti : Antitone K) : IsCompact (⋂ n, K n) := by
  apply isCompact_of_finite_subcover
  intro ι U hU hcover
  obtain ⟨n, hn⟩ := wellFiltered_antitone_test K hK hanti (isOpen_iUnion hU) hcover
  obtain ⟨F, hF⟩ := (hK n).1.elim_finite_subcover U hU hn
  exact ⟨F, (iInter_subset K n).trans hF⟩

variable [T0Space X]
local instance : PartialOrder X := specializationOrder X

/-- Actual openness of the displayed source relation, not a first-countable
core or canonical-embedding conclusion. This is only an internal dependency. -/
def LowerRelationOpen (X : Type u) [TopologicalSpace X] [T0Space X] : Prop :=
  ∀ O : Set X, IsOpen O →
    IsOpen {p : X × X | ∃ z ∈ O, z ≤ p.1 ∧ z ≤ p.2}

/-- The printed compact-saturated sequence conditions, zero-indexed.
Compactness/filteredness of its intersection and its minimum are not fields. -/
structure CompactSaturatedSequence (x : X) where
  sets : ℕ → Set X
  compact : ∀ n, IsCompact (sets n)
  saturated : ∀ n, IsSaturated (sets n)
  nhds : ∀ n, sets n ∈ 𝓝 x
  nested : ∀ n, sets (n + 1) ⊆ interior (sets n)
  lower : ∀ n, ∀ a ∈ sets (n + 1), ∀ b ∈ sets (n + 1),
    ∃ c ∈ sets n, c ≤ a ∧ c ≤ b

theorem exists_compactSaturatedSequence (hX : IsLocallyCompact X)
    (hrel : LowerRelationOpen X) (x : X) (U : ℕ → Set X)
    (hU : ∀ n, U n ∈ 𝓝 x) :
    ∃ C : CompactSaturatedSequence x, ∀ n, C.sets n ⊆ U n := by
  classical
  let Stage := {K : Set X // IsCompact K ∧ IsSaturated K ∧ K ∈ 𝓝 x}
  have hinit : ∃ K : Stage, K.val ⊆ U 0 := by
    obtain ⟨K, hK, hKs, hKn, hKU⟩ := exists_compact_saturated_nhds_subset hX (hU 0)
    exact ⟨⟨K, hK, hKs, hKn⟩, hKU⟩
  have hstep : ∀ n (K : Stage), ∃ K' : Stage,
      K'.val ⊆ U (n + 1) ∧ K'.val ⊆ interior K.val ∧
      ∀ a ∈ K'.val, ∀ b ∈ K'.val, ∃ c ∈ K.val, c ≤ a ∧ c ≤ b := by
    intro n K
    have hxK : x ∈ interior K.val := mem_interior_iff_mem_nhds.mpr K.property.2.2
    have hR := (hrel (interior K.val) isOpen_interior).mem_nhds
      (show (x, x) ∈ {p : X × X | ∃ z ∈ interior K.val, z ≤ p.1 ∧ z ≤ p.2}
        from ⟨x, hxK, le_rfl, le_rfl⟩)
    obtain ⟨V, hV, W, hW, hVW⟩ := mem_nhds_prod_iff.mp hR
    have hN : (V ∩ W) ∩ (interior K.val ∩ U (n + 1)) ∈ 𝓝 x :=
      inter_mem (inter_mem hV hW)
        (inter_mem (interior_mem_nhds.mpr K.property.2.2) (hU (n + 1)))
    obtain ⟨K', hK', hKs', hKn', hK'N⟩ := exists_compact_saturated_nhds_subset hX hN
    refine ⟨⟨K', hK', hKs', hKn'⟩, fun a ha => (hK'N ha).2.2,
      fun a ha => (hK'N ha).2.1, ?_⟩
    intro a ha b hb
    have hab : (a, b) ∈ V ×ˢ W := ⟨(hK'N ha).1.1, (hK'N hb).1.2⟩
    obtain ⟨c, hc, hca, hcb⟩ := hVW hab
    exact ⟨c, interior_subset hc, hca, hcb⟩
  let step : ℕ → Stage → Stage := fun n K => Classical.choose (hstep n K)
  let stages : ℕ → Stage := Nat.rec (Classical.choose hinit) (fun n K => step n K)
  let C : CompactSaturatedSequence x :=
    { sets := fun n => (stages n).val
      compact := fun n => (stages n).property.1
      saturated := fun n => (stages n).property.2.1
      nhds := fun n => (stages n).property.2.2
      nested := fun n => (Classical.choose_spec (hstep n (stages n))).2.1
      lower := fun n => (Classical.choose_spec (hstep n (stages n))).2.2 }
  refine ⟨C, ?_⟩
  intro n
  cases n with
  | zero => exact Classical.choose_spec hinit
  | succ n => exact (Classical.choose_spec (hstep n (stages n))).1

theorem isClosed_principalLower (a : X) : IsClosed (Iic a) := by
  have heq : Iic a = closure ({a} : Set X) := by
    ext y
    exact specializes_iff_mem_closure
  rw [heq]
  exact isClosed_closure

/-- The compact-filtered minimum argument in the specialization partial
order, using closed principal lowers, not a Hausdorff/closed-order premise. -/
theorem compact_filtered_hasLeast {K : Set X} (hK : IsCompact K)
    (hfiltered : NonemptyFiltered K) : ∃ m, IsLeast K m := by
  classical
  have hfinite : ∀ S : Finset K, ∃ z ∈ K, ∀ k ∈ S, z ≤ (k : X) := by
    intro S
    induction S using Finset.induction_on with
    | empty =>
        obtain ⟨z, hz⟩ := hfiltered.1
        exact ⟨z, hz, by simp⟩
    | @insert k S hk ih =>
        obtain ⟨z, hzK, hz⟩ := ih
        obtain ⟨w, hwK, hwk, hwz⟩ := hfiltered.2 k k.property z hzK
        refine ⟨w, hwK, ?_⟩
        intro l hl
        rcases Finset.mem_insert.mp hl with rfl | hl
        · exact hwk
        · exact hwz.trans (hz l hl)
  have hnonempty : (K ∩ ⋂ k : K, Iic (k : X)).Nonempty :=
    hK.inter_iInter_nonempty (fun k : K => Iic (k : X)) (fun k => isClosed_principalLower (k : X))
      (fun S => by
        obtain ⟨z, hzK, hz⟩ := hfinite S
        exact ⟨z, hzK, mem_iInter₂.mpr hz⟩)
  obtain ⟨m, hmK, hm⟩ := hnonempty
  exact ⟨m, hmK, fun k hk => mem_iInter.mp hm ⟨k, hk⟩⟩

namespace CompactSaturatedSequence

def kernel {x : X} (C : CompactSaturatedSequence x) : Set X := ⋂ n, C.sets n

theorem antitone {x : X} (C : CompactSaturatedSequence x) : Antitone C.sets :=
  antitone_nat_of_succ_le fun n => (C.nested n).trans interior_subset

theorem self_mem_kernel {x : X} (C : CompactSaturatedSequence x) : x ∈ C.kernel :=
  mem_iInter.mpr fun n => mem_of_mem_nhds (C.nhds n)

theorem isSaturated_kernel {x : X} (C : CompactSaturatedSequence x) : IsSaturated C.kernel :=
  saturated_iInter C.sets C.saturated

variable [QuasiSober X]

theorem isCompact_kernel {x : X} (C : CompactSaturatedSequence x) : IsCompact C.kernel :=
  wellFiltered_intersection_compact C.sets (fun n => ⟨C.compact n, C.saturated n⟩) C.antitone

theorem filtered_kernel {x : X} (C : CompactSaturatedSequence x) : NonemptyFiltered C.kernel := by
  refine ⟨⟨x, C.self_mem_kernel⟩, ?_⟩
  intro a ha b hb
  let F : Set X := Iic a ∩ Iic b
  have hFclosed : IsClosed F := (isClosed_principalLower a).inter (isClosed_principalLower b)
  by_contra hno
  have hinter : C.kernel ⊆ Fᶜ := by
    intro c hc hcf
    exact hno ⟨c, hc, hcf.1, hcf.2⟩
  obtain ⟨n, hn⟩ := wellFiltered_antitone_test C.sets
    (fun n => ⟨C.compact n, C.saturated n⟩) C.antitone hFclosed.isOpen_compl hinter
  obtain ⟨c, hc, hca, hcb⟩ := C.lower n a (mem_iInter.mp ha (n + 1))
    b (mem_iInter.mp hb (n + 1))
  exact (hn hc) ⟨hca, hcb⟩

def minimum {x : X} (C : CompactSaturatedSequence x) : X :=
  Classical.choose (compact_filtered_hasLeast C.isCompact_kernel C.filtered_kernel)

theorem minimum_isLeast {x : X} (C : CompactSaturatedSequence x) : IsLeast C.kernel C.minimum :=
  Classical.choose_spec (compact_filtered_hasLeast C.isCompact_kernel C.filtered_kernel)

theorem kernel_eq_principalUpper {x : X} (C : CompactSaturatedSequence x) :
    C.kernel = Ici C.minimum := by
  apply subset_antisymm
  · exact C.minimum_isLeast.2
  · intro y hy
    exact (isSaturated_iff_specialization_upper _).mp C.isSaturated_kernel C.minimum y
      ((specializationLE_iff C.minimum y).mpr hy) C.minimum_isLeast.1

/-- The actual countable open local basis at the newly constructed minimum.
This proves pointwise countable generation, not first countability of X. -/
theorem minimum_nhds_hasBasis {x : X} (C : CompactSaturatedSequence x) :
    (𝓝 C.minimum).HasBasis (fun _ : ℕ => True) (fun n => interior (C.sets n)) := by
  constructor
  intro U
  constructor
  · intro hU
    obtain ⟨O, hOU, hO, hmO⟩ := mem_nhds_iff.mp hU
    have hKO : C.kernel ⊆ O := by
      intro y hy
      exact (C.minimum_isLeast.2 hy).mem_open hO hmO
    obtain ⟨n, hn⟩ := wellFiltered_antitone_test C.sets
      (fun n => ⟨C.compact n, C.saturated n⟩) C.antitone hO hKO
    exact ⟨n, trivial, interior_subset.trans (hn.trans hOU)⟩
  · rintro ⟨n, _, hn⟩
    apply mem_of_superset (isOpen_interior.mem_nhds ?_) hn
    exact C.nested n (mem_iInter.mp C.minimum_isLeast.1 (n + 1))

theorem minimum_firstCountable {x : X} (C : CompactSaturatedSequence x) :
    (𝓝 C.minimum).IsCountablyGenerated :=
  C.minimum_nhds_hasBasis.isCountablyGenerated

end CompactSaturatedSequence

/-- The first conclusion of source `lem:fc-core`, internally conditional only
on the displayed lower-relation openness that canonical assembly must prove. -/
theorem exists_firstCountable_of_lowerRelation [QuasiSober X]
    (hX : IsLocallyCompact X) (hrel : LowerRelationOpen X)
    (x : X) (U : ℕ → Set X) (hU : ∀ n, U n ∈ 𝓝 x) :
    ∃ m : X, m ≤ x ∧ (∀ n, m ∈ U n) ∧ (𝓝 m).IsCountablyGenerated := by
  obtain ⟨C, hC⟩ := exists_compactSaturatedSequence hX hrel x U hU
  exact ⟨C.minimum, C.minimum_isLeast.2 C.self_mem_kernel,
    fun n => hC n (mem_iInter.mp C.minimum_isLeast.1 n), C.minimum_firstCountable⟩

end FirstCountableCore
end ScottSpectraReviewed
