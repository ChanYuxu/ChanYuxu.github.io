import ScottSpectraReviewed.UpperScottEq
import ScottSpectraReviewed.ClosedLatticeWeb
import ScottSpectraReviewed.ClosedLatticeLocalCompact

/-! Full source `lem:hyperspace-scott`, including the actual complement
order isomorphism and the continuous-frame/coframe conclusion about O(X).
The proof does not assert continuity of the closed-set lattice Gamma(X),
which does not follow from these hypotheses. -/

noncomputable section
open Set TopologicalSpace
open scoped Topology
universe u v

namespace ScottSpectraReviewed

namespace OrderIsoTransfer
variable {P : Type u} {Q : Type v} [Preorder P] [Preorder Q]

/-- Actual way-below transport, quantifying over every existing nonempty
directed supremum. It is not a sequential/countable approximation surrogate.
-/
theorem wayBelow_map (e : P ≃o Q) {a b : P} (hab : WayBelow a b) :
    WayBelow (e a) (e b) := by
  intro D hD x hx hbx
  have hE : NonemptyDirected (e.symm '' D) :=
    ⟨hD.1.image e.symm,directedOn_image.mpr (hD.2.mono e.symm.monotone)⟩
  have hb : b ≤ e.symm x := by
    simpa only [e.symm_apply_apply] using e.symm.monotone hbx
  obtain ⟨_,⟨d,hd,rfl⟩,had⟩ := hab (e.symm '' D) hE (e.symm x)
    (e.symm.isLUB_image'.mpr hx) hb
  refine ⟨d,hd,?_⟩
  simpa only [e.apply_symm_apply] using e.monotone had

theorem wayBelow_map_iff (e : P ≃o Q) (a b : P) :
    WayBelow (e a) (e b) ↔ WayBelow a b := by
  constructor
  · intro h
    simpa only [e.symm_apply_apply] using wayBelow_map e.symm h
  · exact wayBelow_map e

end OrderIsoTransfer

namespace OrderIsoTransfer
variable {P : Type u} {Q : Type v} [CompleteLattice P] [CompleteLattice Q]

theorem isContinuousLattice (e : P ≃o Q) (hP : IsContinuousLattice P) :
    IsContinuousLattice Q := by
  refine ⟨completeLattice_isDcpo Q,?_⟩
  intro y
  have hset : {b : Q | WayBelow b y}=e '' {a : P | WayBelow a (e.symm y)} := by
    ext b
    constructor
    · intro hb
      exact ⟨e.symm b,wayBelow_map e.symm hb,e.apply_symm_apply b⟩
    · rintro ⟨a,ha,rfl⟩
      simpa only [e.apply_symm_apply] using wayBelow_map e ha
  rw [hset]
  have hx := hP.2 (e.symm y)
  refine ⟨⟨hx.1.1.image e,directedOn_image.mpr (hx.1.2.mono e.monotone)⟩,?_⟩
  simpa only [e.apply_symm_apply] using (e.isLUB_image'.mpr hx.2)

end OrderIsoTransfer

namespace ClosedLattice

variable {X : Type u} [TopologicalSpace X]

theorem opens_isFrame (X : Type u) [TopologicalSpace X] : IsFrame (Opens X) := by
  intro U S
  rw [sSup_image]
  exact inf_sSup_eq

/-- The source's complement-isomorphism argument, with the full arbitrary
coframe law, including the empty family. No sobriety is needed internally.
-/
theorem opens_isCoframe_of_web (hweb : IsWebSpace X) : IsCoframe (Opens X) :=
  show IsFrame (Opens X)ᵒᵈ from
    OrderIsoTransfer.isFrame (complementOrderIso X) (isFrame_of_web hweb)

/-- Continuity here is continuity of the actual open-set lattice, from
the original compact-saturated neighborhood sandwich. It is not a claim
that Gamma(X) is continuous. -/
theorem opens_isContinuousFrame (hlocal : IsLocallyCompact X) :
    IsContinuousLattice (Opens X) ∧ IsFrame (Opens X) :=
  ⟨locallyCompact_isCoreCompact hlocal,opens_isFrame X⟩

/-- The genuine continuity statement available for the canonical repair:
the order dual of Gamma(X), not Gamma(X), is isomorphic to continuous O(X).
-/
theorem carrier_dual_isContinuous (hlocal : IsLocallyCompact X) :
    IsContinuousLattice ((Carrier X)ᵒᵈ) :=
  OrderIsoTransfer.isContinuousLattice (complementOrderIso X).dual.symm
    (locallyCompact_isCoreCompact hlocal)

section T0
variable [T0Space X]

theorem carrier_upper_locallyCompact (hlocal : IsLocallyCompact X) :
    @IsLocallyCompact (Carrier X) (upperTopology (Carrier X)) := by
  have h := source_lowerVietoris_locallyCompact hlocal
  rwa [lowerVietoris_eq_upper] at h

/-- The actual Scott and upper topologies on the specified lattice of all
closed sets, obtained from the complete upper-topology lemma. -/
theorem carrier_scott_eq_upper (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    scottTopology (Carrier X)=upperTopology (Carrier X) :=
  (upper_eq_scott_of_frame_locallyCompact (isFrame_of_web hweb)
    (carrier_upper_locallyCompact hlocal)).symm

/-- The exact dual topology equality on O(X), transported by actual
complementation, not by a separately postulated space representation. -/
theorem opens_dualTopologyEquality (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    DualTopologyEquality (Opens X) :=
  OrderIsoTransfer.scott_eq_upper (complementOrderIso X)
    (carrier_scott_eq_upper hlocal hweb)

/-- A useful canonical-construction consequence, without the false
intermediate assertion that Gamma(X) is a continuous lattice. -/
theorem carrier_scott_isStablyCompact (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    @IsStablyCompact (Carrier X) (scottTopology (Carrier X)) := by
  rw [carrier_scott_eq_upper hlocal hweb]
  exact upper_isStablyCompact (carrier_upper_locallyCompact hlocal)

/-- Full numbered source `lem:hyperspace-scott`. Sobriety in its final
conditional clause means actual quasi-sobriety plus the standing T0
assumption; no stronger order-theoretic model is substituted. -/
theorem source_hyperspace_scott (hlocal : IsLocallyCompact X) (hweb : IsWebSpace X) :
    IsFrame (Carrier X) ∧
      scottTopology (Carrier X)=upperTopology (Carrier X) ∧
      (QuasiSober X → IsContinuousLattice (Opens X) ∧ IsFrame (Opens X) ∧
        IsCoframe (Opens X) ∧ DualTopologyEquality (Opens X)) :=
  ⟨isFrame_of_web hweb,carrier_scott_eq_upper hlocal hweb,fun _ =>
    ⟨(opens_isContinuousFrame hlocal).1,(opens_isContinuousFrame hlocal).2,
      opens_isCoframe_of_web hweb,opens_dualTopologyEquality hlocal hweb⟩⟩

end T0
end ClosedLattice
end ScottSpectraReviewed
