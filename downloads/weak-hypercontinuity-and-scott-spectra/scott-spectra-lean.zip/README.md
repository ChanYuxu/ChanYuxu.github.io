# Scott spectra of distributive continuous lattices — Lean 4

Lean proof of the main characterization in arXiv:2611.14412v1, Theorem 1.1. The proof comes from an earlier manuscript version with the same main statement; it is not a line-by-line formalization of arXiv v1. The library proves the biconditional without countability or algebraicity assumptions.

Extract the ZIP and open [index.html](index.html) to read the proof files
offline, or use an editor in the `lean/` folder. The reader never runs Lean.

With Elan and Git installed, compile the project from the extracted folder:

    cd lean
    lake build

Alternatively run `sh Check.command` on macOS/Linux or `Check.cmd` on Windows.
The first build needs network access if the pinned Lean toolchain or
dependencies are not already available. To use Mathlib's precompiled cache,
run `lake exe cache get` from `lean/` before `lake build`.

- Lean: `leanprover/lean4:v4.30.0-rc2`
- Mathlib: `5450b53e5ddc75d46418fabb605edbf36bd0beb6` (the other dependency commits are in the lockfile).
- 94 project and supporting Lean modules. No Mathlib copy, compiled
  files, or manuscript sources are included.
- `SHA256SUMS` covers every other file in the archive.
- Verification of the encoded proofs is separate from verification of the
  written manuscript. Independent human review is pending.
