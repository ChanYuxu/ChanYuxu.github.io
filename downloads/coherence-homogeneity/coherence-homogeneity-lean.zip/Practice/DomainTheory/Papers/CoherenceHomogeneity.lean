import Practice.DomainTheory.Papers.CoherenceHomogeneity.Main

/-! Public facade for the coherence-space homogeneity formalization. -/
