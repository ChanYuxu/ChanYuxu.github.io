import Mathlib.ModelTheory.Fraisse
import Mathlib.ModelTheory.Graph
import Mathlib.Combinatorics.SimpleGraph.Maps

/-!
# Coherence graphs, induced embeddings, and retract equations

The loops of a coherence relation carry no information beyond reflexivity, so
the formal development represents a coherence space by its underlying simple
graph of coherent *distinct* events.  `Coherent G x y` restores the loops.
-/

open scoped FirstOrder

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

universe u v

/-- The reflexive coherence relation associated with a simple graph. -/
def Coherent {V : Type u} (G : SimpleGraph V) (x y : V) : Prop :=
  x = y ∨ G.Adj x y

theorem coherent_refl {V : Type u} (G : SimpleGraph V) (x : V) : Coherent G x x :=
  Or.inl rfl

theorem coherent_symm {V : Type u} {G : SimpleGraph V} {x y : V}
    (h : Coherent G x y) : Coherent G y x := by
  rcases h with rfl | h
  · exact coherent_refl G x
  · exact Or.inr h.symm

/-- An induced embedding of the loop-free graphs is exactly an induced
embedding of the associated coherence spaces. -/
abbrev InducedEmbedding {V : Type u} {W : Type v} (G : SimpleGraph V)
    (H : SimpleGraph W) := G ↪g H

/-- States are cliques for the reflexive coherence relation. -/
def IsState {V : Type u} (G : SimpleGraph V) (X : Set V) : Prop :=
  ∀ ⦃x⦄, x ∈ X → ∀ ⦃y⦄, y ∈ X → Coherent G x y

theorem image_isState {V : Type u} {W : Type v} {G : SimpleGraph V}
    {H : SimpleGraph W} (f : G ↪g H) {X : Set V} (hX : IsState G X) :
    IsState H (f '' X) := by
  rintro _ ⟨x, hx, rfl⟩ _ ⟨y, hy, rfl⟩
  rcases hX hx hy with hxy | hxy
  · exact Or.inl (congrArg f hxy)
  · exact Or.inr (f.map_rel_iff.mpr hxy)

theorem preimage_isState {V : Type u} {W : Type v} {G : SimpleGraph V}
    {H : SimpleGraph W} (f : G ↪g H) {Y : Set W} (hY : IsState H Y) :
    IsState G (f ⁻¹' Y) := by
  intro x hx y hy
  rcases hY hx hy with hxy | hxy
  · exact Or.inl (f.injective hxy)
  · exact Or.inr (f.map_rel_iff.mp hxy)

/-- Direct image along an induced embedding. -/
def stateSection {V : Type u} {W : Type v} {G : SimpleGraph V}
    {H : SimpleGraph W} (f : G ↪g H) (X : Set V) : Set W :=
  f '' X

/-- Inverse image along an induced embedding. -/
def stateRetraction {V : Type u} {W : Type v} {G : SimpleGraph V}
    {H : SimpleGraph W} (f : G ↪g H) (Y : Set W) : Set V :=
  f ⁻¹' Y

theorem stateRetraction_stateSection {V : Type u} {W : Type v}
    {G : SimpleGraph V} {H : SimpleGraph W} (f : G ↪g H) (X : Set V) :
    stateRetraction f (stateSection f X) = X := by
  ext x
  simp [stateRetraction, stateSection, f.injective.eq_iff]

theorem stateSection_stateRetraction_subset {V : Type u} {W : Type v}
    {G : SimpleGraph V} {H : SimpleGraph W} (f : G ↪g H) (Y : Set W) :
    stateSection f (stateRetraction f Y) ⊆ Y := by
  rintro y ⟨x, hx, rfl⟩
  exact hx

/-- The endomap associated with a section--retraction pair. -/
def retractIdempotent {A : Type u} {U : Type v} (i : A → U) (p : U → A) : U → U :=
  i ∘ p

theorem retractIdempotent_idem {A : Type u} {U : Type v} (i : A → U) (p : U → A)
    (hpi : Function.LeftInverse p i) :
    retractIdempotent i p ∘ retractIdempotent i p = retractIdempotent i p := by
  funext x
  change i (p (i (p x))) = i (p x)
  rw [hpi (p x)]

/-- Encoding a typed map as an endomap of a common retract carrier. -/
def encodeTyped {A : Type u} {B : Type v} {U : Type*}
    (iB : B → U) (f : A → B) (pA : U → A) : U → U :=
  iB ∘ f ∘ pA

theorem encodeTyped_karoubi {A : Type u} {B : Type v} {U : Type*}
    (iA : A → U) (pA : U → A) (iB : B → U) (pB : U → B)
    (hA : Function.LeftInverse pA iA) (hB : Function.LeftInverse pB iB)
    (f : A → B) :
    retractIdempotent iB pB ∘ encodeTyped iB f pA ∘ retractIdempotent iA pA =
      encodeTyped iB f pA := by
  funext x
  change iB (pB (iB (f (pA (iA (pA x)))))) = iB (f (pA x))
  rw [hA (pA x), hB (f (pA x))]

theorem decode_encodeTyped {A : Type u} {B : Type v} {U : Type*}
    (iA : A → U) (pA : U → A) (iB : B → U) (pB : U → B)
    (hA : Function.LeftInverse pA iA) (hB : Function.LeftInverse pB iB)
    (f : A → B) :
    pB ∘ encodeTyped iB f pA ∘ iA = f := by
  funext x
  change pB (iB (f (pA (iA x)))) = f x
  rw [hA x, hB (f x)]

theorem encode_decodeTyped {A : Type u} {B : Type v} {U : Type*}
    (iA : A → U) (pA : U → A) (iB : B → U) (pB : U → B)
    (g : U → U)
    (hg : g = retractIdempotent iB pB ∘ g ∘ retractIdempotent iA pA) :
    encodeTyped iB (pB ∘ g ∘ iA) pA = g := by
  funext x
  change iB (pB (g (iA (pA x)))) = g x
  exact (congrFun hg x).symm

end Practice.DomainTheory.Papers.CoherenceHomogeneity
