# Source audit and theorem graph

## Source boundary

The paper and Lean development began from the following three user-supplied
sources.  The PDFs remain outside the repository and are not copied into the
project.

| Source | SHA-256 | Role |
|---|---|---|
| `07_coherence_qualitative_domain_reconstructed.tex` | `f3242de9dcf15872e0fde9216aa836173e1777875ba5f365b71be51fabff0138` | 2015 construction of the universal coherence space and the linear-retract interpretation |
| `rado_vs_comega_homogeneity_note.pdf` | `736878f7335802bec825e2003c3566d9533f3085c555b3c771fd0b474ec4ea2e` | concise proofs of non-ultrahomogeneity of `C_omega` and the Rado replacement |
| `coherence_qualitative_universal_retract_english.pdf` | `11370fd0b8f29638335d776817e7ff63cd62f64ec405e106ae06b7fc7fa3bd52` | expanded coherence-space, state-domain, linear-logic, and universal-retract account |

The 440-line TeX source and all 27 PDF pages were read.  Both PDFs were also
rendered and visually inspected page by page.

The later novelty audit added two primary references that materially change
the attribution boundary:

| Source | Role |
|---|---|
| R. Rado, *Universal graphs and universal functions*, Acta Arith. 9 (1964), 331--340 | Theorem 1 already gives the direct binary-digit graph on the natural numbers used in `Rado.lean`; the object is explicit, while the universality proof constructs an embedding inductively |
| P. Boldi, F. Cardone, M. Droste, *Universal homogeneous graph-like structures and domains*, MSCS 12 (2002), 91--109 | Prior explicit construction of universal homogeneous objects in coherence spaces and qualitative domains |

## Historical claim

The 2015 work of Hui Kou and Haoran Zhao constructs the coherence space

`C_omega = (Fn_<omega>(omega, 2), coherence)`,

where two distinct finite partial binary functions are coherent precisely when
they conflict at a common coordinate.  It proves that every at-most-countable
coherence space is an induced subspace of `C_omega`, and hence that every state
domain is a linear retract of `D(C_omega)`.  The supplied reconstructed source
does not analyse whether `C_omega` is ultrahomogeneous, but it also does not
state that issue as an explicit open problem.  Its conclusion says more
generally that properties of the corresponding domain remain to be studied.

The arithmetic Rado construction, its extension property, and its universal
homogeneous isomorphism type are prior results.  Adding reflexive loops merely
translates the simple graph into the coherence-space convention.  They must be
presented as background and comparison, not as a new construction.

## Main theorem graph

1. **Coherence spaces and induced embeddings.**
   An induced embedding preserves and reflects coherence.  Its direct-image
   and inverse-image maps on states form a linear section--retraction pair.

2. **Universality of `C_omega`.**
   Coding an event at its own coordinate by `1` and each earlier coherent
   event by `0` gives an induced embedding of every at-most-countable coherence
   space into `C_omega`.

3. **Failure of ultrahomogeneity.**
   The empty partial function is the unique event of `C_omega` adjacent to no
   distinct event.  Every nonempty partial function has a conflicting
   neighbour.  A one-point isomorphism from the empty function to a nonempty
   function therefore cannot extend to an automorphism.

4. **The classical Rado coherence space.**
   On `omega`, distinct `m < n` are coherent exactly when the `m`-th binary
   digit of `n` is `1`.  For finite disjoint sets `A,B`, a fresh integer whose
   lower one-bits are exactly `A` realizes coherence with `A` and incoherence
   with `B`.

5. **Consequences of the extension property.**
   Recursive embedding gives countable universality.  Back-and-forth gives
   ultrahomogeneity and uniqueness up to isomorphism.  Conversely, finite
   universality together with ultrahomogeneity gives the extension property.

6. **Linear-logic appendix.**
   Standard coherence-space operations preserve countability.  Consequently
   each formula interpretation induced-embeds into the Rado coherence space.
   Direct and inverse image give a linear retraction, and the resulting
   idempotents encode typed maps by the usual Karoubi equation
   `g = e_B * g * e_A`.

## Terminology decisions

- `ultrahomogeneous` is used for extension of every isomorphism between finite
  induced substructures.  The paper does not introduce a new substitute term.
- The phrase `coherence-generated qualitative domain` from the expanded PDF is
  not used as a new domain-theoretic class.  The paper refers to state domains
  of coherence spaces and, when discussing the 2015 source, to conditionally
  complete qualitative domains.
- `countably universal` replaces the note's phrase `weakly universal`.
- The classical comparison object is called the Rado coherence space,
  following standard Rado graph terminology.  The phrase "homogeneous
  replacement" is not used as a novelty claim.

## Formalization boundary

The Lean development is required to prove the graph-theoretic core without
`sorry`, `admit`, or custom axioms: the exceptional empty point of `C_omega`,
non-ultrahomogeneity, and a formalized comparison with the classical Rado
extension property, countable universality, ultrahomogeneity, and uniqueness.
It also checks the section--retraction and Karoubi idempotent equations used in
the linear-logic appendix.  Machine checking does not turn the classical Rado
results into new mathematics.

The complete categorical coherence proof for every connective and every
cut-elimination equation is standard background in the supplied expanded PDF;
it is not presented as a newly formalized result.  The final paper and blog
must state this boundary explicitly.

The Cantor-cylinder and ideal-completion descriptions of the coordinate state
domain in Appendix C are also mathematical exposition drawn from the supplied
expanded PDF.  They are not added to the Lean claim boundary.
