# A coordinate universal coherence space and the classical Rado comparison

This directory contains the paper source and the corresponding Lean 4
formalization.  Start with `Main.lean` for the theorem facade and
`FORMALIZATION_STATUS.md` for the exact claim boundary.

Build the formalization with:

```text
lake build Practice.DomainTheory.Papers.CoherenceHomogeneity
lake build Practice.DomainTheory.Papers.CoherenceHomogeneity.AxiomAudit
```

Compile the paper with:

```text
latexmk -g -pdf -interaction=nonstopmode -halt-on-error Manuscript.tex
```
