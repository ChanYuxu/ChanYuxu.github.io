import Practice.DomainTheory.Papers.CoherenceHomogeneity.Basic
import Mathlib.Combinatorics.Colex

/-!
# The arithmetic Rado coherence graph

The graph on `ℕ` reads adjacency of distinct `m < n` from membership of `m`
in the finite set of one-bit positions of `n`.
-/

open scoped BigOperators FirstOrder

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

/-- The finite extension property for a simple graph. -/
def HasRadoExtensionProperty {V : Type*} (G : SimpleGraph V) : Prop :=
  ∀ (A B : Finset V), Disjoint A B →
    ∃ z, z ∉ A ∧ z ∉ B ∧
      (∀ a ∈ A, G.Adj z a) ∧ (∀ b ∈ B, ¬G.Adj z b)

/-- The loop-free graph underlying the Rado coherence space. -/
def radoGraph : SimpleGraph ℕ where
  Adj m n :=
    (m < n ∧ m ∈ Finset.equivBitIndices n) ∨
      (n < m ∧ n ∈ Finset.equivBitIndices m)
  symm m n h := by
    rcases h with h | h
    · exact Or.inr h
    · exact Or.inl h
  loopless := ⟨by
    intro n h
    rcases h with h | h
    · exact (Nat.lt_irrefl n) h.1
    · exact (Nat.lt_irrefl n) h.1⟩

theorem radoGraph_adj_iff_of_lt {m n : ℕ} (h : m < n) :
    radoGraph.Adj m n ↔ m ∈ Finset.equivBitIndices n := by
  simp [radoGraph, h, Nat.not_lt_of_ge h.le]

private theorem lt_sum_union_succ {A B : Finset ℕ} {x : ℕ} (hx : x ∈ A ∪ B) :
    x < (∑ y ∈ A ∪ B, y) + 1 := by
  have hxle : x ≤ ∑ y ∈ A ∪ B, y :=
    Finset.single_le_sum (fun y _ ↦ Nat.zero_le y) hx
  omega

/-- An explicit natural number whose lower one-bit positions are the supplied
finite set and which also has a fresh high one-bit. -/
noncomputable def radoWitness (A B : Finset ℕ) : ℕ :=
  let N := (∑ y ∈ A ∪ B, y) + 1
  Finset.equivBitIndices.symm (insert N A)

theorem radoWitness_bits (A B : Finset ℕ) :
    Finset.equivBitIndices (radoWitness A B) =
      insert ((∑ y ∈ A ∪ B, y) + 1) A := by
  simp [radoWitness]

theorem radoWitness_high_lt (A B : Finset ℕ) :
    (∑ y ∈ A ∪ B, y) + 1 < radoWitness A B := by
  let N := (∑ y ∈ A ∪ B, y) + 1
  have hNfin : N ∈ Finset.equivBitIndices (radoWitness A B) := by
    rw [radoWitness_bits]
    exact Finset.mem_insert_self N A
  have hNlist : N ∈ (radoWitness A B).bitIndices := by
    exact (List.mem_toFinset.mp hNfin)
  exact N.lt_two_pow_self.trans_le (Nat.two_pow_le_of_mem_bitIndices hNlist)

theorem radoGraph_has_extension_property : HasRadoExtensionProperty radoGraph := by
  classical
  intro A B hAB
  let N := (∑ y ∈ A ∪ B, y) + 1
  let z := radoWitness A B
  have hNz : N < z := radoWitness_high_lt A B
  have hbits : Finset.equivBitIndices z = insert N A := radoWitness_bits A B
  have hlt (x : ℕ) (hx : x ∈ A ∪ B) : x < N := by
    exact lt_sum_union_succ hx
  refine ⟨z, ?_, ?_, ?_, ?_⟩
  · intro hzA
    have hzN : z < N := hlt z (Finset.mem_union_left B hzA)
    exact (Nat.not_lt_of_ge hNz.le) hzN
  · intro hzB
    have hzN : z < N := hlt z (Finset.mem_union_right A hzB)
    exact (Nat.not_lt_of_ge hNz.le) hzN
  · intro a ha
    have haN : a < N := hlt a (Finset.mem_union_left B ha)
    have haz : a < z := haN.trans hNz
    apply SimpleGraph.Adj.symm
    apply (radoGraph_adj_iff_of_lt haz).2
    rw [hbits]
    exact Finset.mem_insert_of_mem ha
  · intro b hb hzb
    have hbN : b < N := hlt b (Finset.mem_union_right A hb)
    have hbz : b < z := hbN.trans hNz
    have hbmem : b ∈ Finset.equivBitIndices z :=
      (radoGraph_adj_iff_of_lt hbz).1 hzb.symm
    rw [hbits] at hbmem
    rcases Finset.mem_insert.mp hbmem with hbeq | hbA
    · omega
    · exact (Finset.disjoint_left.mp hAB hbA hb)

end Practice.DomainTheory.Papers.CoherenceHomogeneity
