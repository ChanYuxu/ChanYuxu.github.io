import Practice.DomainTheory.Papers.CoherenceHomogeneity.Universality

/-!
# Converse extension theorem

Finite universality together with ultrahomogeneity implies the Rado extension
property.  This supplies the standard uniqueness formulation in terms of
universality and ultrahomogeneity, rather than extension property alone.
-/

open scoped FirstOrder
open FirstOrder
open FirstOrder.Language

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

universe u v

/-- Universality for finite graphs in the same universe. -/
def FinitelyUniversal {M : Type u} (G : SimpleGraph M) : Prop :=
  ∀ {V : Type u} [Finite V] (H : SimpleGraph V),
    Nonempty (@Language.Embedding Language.graph V M H.structure G.structure)

/-- Add one vertex to the induced graph on `A ∪ B`, adjacent exactly to `A`. -/
def onePointExtensionGraph {M : Type u} [DecidableEq M]
    (G : SimpleGraph M) (A B : Finset M) :
    SimpleGraph (Unit ⊕ ↥(A ∪ B)) where
  Adj x y :=
    match x, y with
    | Sum.inl _, Sum.inl _ => False
    | Sum.inl _, Sum.inr y => y.1 ∈ A
    | Sum.inr x, Sum.inl _ => x.1 ∈ A
    | Sum.inr x, Sum.inr y => G.Adj x.1 y.1
  symm x y h := by
    cases x with
    | inl x =>
        cases y with
        | inl y => exact h.elim
        | inr y => exact h
    | inr x =>
        cases y with
        | inl y => exact h
        | inr y => exact h.symm
  loopless := ⟨by
    intro x h
    cases x with
    | inl x => exact h.elim
    | inr x => exact G.loopless.irrefl x.1 h⟩

@[simp]
theorem onePointExtensionGraph_adj_new_old {M : Type u} [DecidableEq M]
    (G : SimpleGraph M)
    (A B : Finset M) (x : ↥(A ∪ B)) :
    (onePointExtensionGraph G A B).Adj (Sum.inl ()) (Sum.inr x) ↔ x.1 ∈ A :=
  Iff.rfl

@[simp]
theorem onePointExtensionGraph_adj_old_old {M : Type u} [DecidableEq M]
    (G : SimpleGraph M)
    (A B : Finset M) (x y : ↥(A ∪ B)) :
    (onePointExtensionGraph G A B).Adj (Sum.inr x) (Sum.inr y) ↔ G.Adj x.1 y.1 :=
  Iff.rfl

/-- Finite universality and ultrahomogeneity yield every finite adjacency
pattern. -/
theorem extension_of_finitelyUniversal_ultrahomogeneous {M : Type u}
    (G : SimpleGraph M) (huniv : FinitelyUniversal G)
    (hhom : @Language.IsUltrahomogeneous Language.graph M G.structure) :
    HasRadoExtensionProperty G := by
  classical
  letI : Language.graph.Structure M := G.structure
  intro A B hAB
  let F := onePointExtensionGraph G A B
  letI : Language.graph.Structure (Unit ⊕ ↥(A ∪ B)) := F.structure
  letI : Finite (Unit ⊕ ↥(A ∪ B)) := inferInstance
  obtain ⟨e⟩ := huniv F
  let S : Language.graph.Substructure M := {
    carrier := (A ∪ B : Finset M)
    fun_mem := by
      intro n fn
      exact isEmptyElim fn
  }
  have hSfinite : Set.Finite (S : Set M) := by
    change Set.Finite (↑(A ∪ B) : Set M)
    exact (A ∪ B).finite_toSet
  letI : Finite S := hSfinite.to_subtype
  have hSfg : S.FG := Substructure.FG.of_finite
  let old : S → Unit ⊕ ↥(A ∪ B) := fun s ↦ Sum.inr ⟨s.1, s.2⟩
  let f : S ↪[Language.graph] M := {
    toFun := fun s ↦ e (old s)
    inj' := by
      intro x y hxy
      have hold : old x = old y := e.injective hxy
      apply Subtype.ext
      exact congrArg (fun q ↦ match q with | Sum.inl _ => x.1 | Sum.inr t => t.1) hold
    map_fun' := by
      intro n fn
      exact isEmptyElim fn
    map_rel' := by
      intro n r xs
      cases r
      have he := e.map_rel Language.adj ![old (xs 0), old (xs 1)]
      change G.Adj (e (old (xs 0))) (e (old (xs 1))) ↔
        F.Adj (old (xs 0)) (old (xs 1)) at he
      simpa [F, old, onePointExtensionGraph] using he
  }
  obtain ⟨g, hfg⟩ := hhom S hSfg f
  have hg_old (s : S) : g s.1 = e (old s) := by
    have heval := congrArg (fun k : S ↪[Language.graph] M ↦ k s) hfg
    change e (old s) = g s.1 at heval
    exact heval.symm
  let new : Unit ⊕ ↥(A ∪ B) := Sum.inl ()
  let z : M := g.symm (e new)
  have gz : g z = e new := by
    simp [z]
  have hzUnion : z ∉ A ∪ B := by
    intro hz
    let sz : S := ⟨z, hz⟩
    have hzold : g z = e (old sz) := hg_old sz
    have heq : e new = e (old sz) := gz.symm.trans hzold
    have hnewold : new = old sz := e.injective heq
    exact Sum.inl_ne_inr hnewold
  have hzA : z ∉ A := fun hz ↦ hzUnion (Finset.mem_union_left B hz)
  have hzB : z ∉ B := fun hz ↦ hzUnion (Finset.mem_union_right A hz)
  refine ⟨z, hzA, hzB, ?_, ?_⟩
  · intro a ha
    have haUnion : a ∈ A ∪ B := Finset.mem_union_left B ha
    let sa : S := ⟨a, haUnion⟩
    have hga : g a = e (old sa) := hg_old sa
    have heRel := e.map_rel Language.adj ![new, old sa]
    change G.Adj (e new) (e (old sa)) ↔ F.Adj new (old sa) at heRel
    have hF : F.Adj new (old sa) := by
      simpa [F, new, old, onePointExtensionGraph] using ha
    have htarget : G.Adj (g z) (g a) := by
      simpa [gz, hga] using heRel.mpr hF
    have hgRel := g.map_rel Language.adj ![z, a]
    change G.Adj (g z) (g a) ↔ G.Adj z a at hgRel
    exact hgRel.mp htarget
  · intro b hb hzb
    have hbUnion : b ∈ A ∪ B := Finset.mem_union_right A hb
    let sb : S := ⟨b, hbUnion⟩
    have hgb : g b = e (old sb) := hg_old sb
    have hgRel := g.map_rel Language.adj ![z, b]
    change G.Adj (g z) (g b) ↔ G.Adj z b at hgRel
    have htarget : G.Adj (e new) (e (old sb)) := by
      simpa [gz, hgb] using hgRel.mpr hzb
    have heRel := e.map_rel Language.adj ![new, old sb]
    change G.Adj (e new) (e (old sb)) ↔ F.Adj new (old sb) at heRel
    have hF : F.Adj new (old sb) := heRel.mp htarget
    have hbA : b ∈ A := by
      simpa [F, new, old, onePointExtensionGraph] using hF
    exact Finset.disjoint_left.mp hAB hbA hb

/-- The Rado graph is finitely universal. -/
theorem radoGraph_finitelyUniversal : FinitelyUniversal radoGraph := by
  intro V inst F
  letI : Countable V := inferInstance
  exact radoGraph_countablyUniversal F

/-- Any two countable finitely universal ultrahomogeneous graphs are
isomorphic. -/
theorem equiv_of_finitelyUniversal_ultrahomogeneous
    {M : Type u} {N : Type v} (G : SimpleGraph M) (H : SimpleGraph N)
    [Countable M] [Countable N]
    (hGu : FinitelyUniversal G)
    (hGh : @Language.IsUltrahomogeneous Language.graph M G.structure)
    (hHu : FinitelyUniversal H)
    (hHh : @Language.IsUltrahomogeneous Language.graph N H.structure) :
    Nonempty (@Language.Equiv Language.graph M N G.structure H.structure) :=
  equiv_of_extension G H
    (extension_of_finitelyUniversal_ultrahomogeneous G hGu hGh)
    (extension_of_finitelyUniversal_ultrahomogeneous H hHu hHh)

end Practice.DomainTheory.Papers.CoherenceHomogeneity
