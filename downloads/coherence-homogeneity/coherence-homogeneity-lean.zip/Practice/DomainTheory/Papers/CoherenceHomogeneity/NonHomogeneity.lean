import Practice.DomainTheory.Papers.CoherenceHomogeneity.Homogeneity

/-!
# Non-ultrahomogeneity of the coordinate coherence space

The one-point partial isomorphism from the unique isolated vertex to a
non-isolated vertex cannot extend to an automorphism.
-/

open scoped FirstOrder
open FirstOrder
open FirstOrder.Language

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

open FinitePartialBool

/-- A nonempty one-coordinate partial function. -/
def markedCode : FinitePartialBool := singleton 0 true

/-- The opposite one-coordinate partial function. -/
def oppositeCode : FinitePartialBool := singleton 0 false

theorem markedCode_adj_oppositeCode :
    coordinateGraph.Adj markedCode oppositeCode := by
  refine ⟨0, ?_, ?_, ?_⟩
  · simp [markedCode, FinitePartialBool.singleton]
  · simp [oppositeCode, FinitePartialBool.singleton]
  · left
    constructor <;> simp [markedCode, oppositeCode, FinitePartialBool.singleton]

/-- The coordinate graph is not ultrahomogeneous in mathlib's standard
first-order definition. -/
theorem coordinateGraph_not_ultrahomogeneous :
    ¬(@Language.IsUltrahomogeneous Language.graph FinitePartialBool
      coordinateGraph.structure) := by
  intro hhom
  letI : Language.graph.Structure FinitePartialBool := coordinateGraph.structure
  let S : Language.graph.Substructure FinitePartialBool := {
    carrier := {empty}
    fun_mem := by
      intro n fn
      exact isEmptyElim fn
  }
  have hSfinite : Set.Finite (S : Set FinitePartialBool) := by
    change (Set.singleton empty).Finite
    exact Set.finite_singleton empty
  letI : Finite S := hSfinite.to_subtype
  have hSfg : S.FG := Substructure.FG.of_finite
  let f : S ↪[Language.graph] FinitePartialBool := {
    toFun := fun _ ↦ markedCode
    inj' := by
      intro x y _
      apply Subtype.ext
      have hxmem := x.2
      change x.1 ∈ ({empty} : Set FinitePartialBool) at hxmem
      have hymem := y.2
      change y.1 ∈ ({empty} : Set FinitePartialBool) at hymem
      have hx : x.1 = empty := Set.mem_singleton_iff.mp hxmem
      have hy : y.1 = empty := Set.mem_singleton_iff.mp hymem
      exact hx.trans hy.symm
    map_fun' := by
      intro n fn
      exact isEmptyElim fn
    map_rel' := by
      intro n r xs
      cases r
      change coordinateGraph.Adj markedCode markedCode ↔
        coordinateGraph.Adj (xs 0).1 (xs 1).1
      constructor
      · intro h
        exact (coordinateGraph.loopless.irrefl markedCode h).elim
      · intro h
        have hxmem := (xs 0).2
        change (xs 0).1 ∈ ({empty} : Set FinitePartialBool) at hxmem
        have hymem := (xs 1).2
        change (xs 1).1 ∈ ({empty} : Set FinitePartialBool) at hymem
        have hx : (xs 0).1 = empty := Set.mem_singleton_iff.mp hxmem
        have hy : (xs 1).1 = empty := Set.mem_singleton_iff.mp hymem
        have : coordinateGraph.Adj empty empty := by simpa [hx, hy] using h
        exact (coordinateGraph.loopless.irrefl empty this).elim
  }
  obtain ⟨g, hfg⟩ := hhom S hSfg f
  let e0 : S := ⟨empty, by
    change empty ∈ ({empty} : Set FinitePartialBool)
    exact Set.mem_singleton empty⟩
  have hgEmpty : g empty = markedCode := by
    have heval := congrArg (fun k : S ↪[Language.graph] FinitePartialBool ↦ k e0) hfg
    change markedCode = g empty at heval
    exact heval.symm
  have hmap := g.map_rel Language.adj ![g.symm oppositeCode, empty]
  change coordinateGraph.Adj (g (g.symm oppositeCode)) (g empty) ↔
    coordinateGraph.Adj (g.symm oppositeCode) empty at hmap
  have hleft : coordinateGraph.Adj (g (g.symm oppositeCode)) (g empty) := by
    simpa [hgEmpty] using markedCode_adj_oppositeCode.symm
  have hright : coordinateGraph.Adj (g.symm oppositeCode) empty := hmap.mp hleft
  exact empty_not_adj_rev (g.symm oppositeCode) hright

end Practice.DomainTheory.Papers.CoherenceHomogeneity
