import Practice.DomainTheory.Papers.CoherenceHomogeneity.Basic

/-!
# The finite-partial-function coherence graph

`FinitePartialBool` stores a finite domain and the subset on which the partial
function has value `true`.  Its graph adjacency is finite conflict.
-/

open scoped FirstOrder

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

/-- A finite partial function from `ℕ` to `Bool`. -/
structure FinitePartialBool where
  dom : Finset ℕ
  ones : Finset ℕ
  ones_subset_dom : ones ⊆ dom
  deriving DecidableEq

namespace FinitePartialBool

@[ext]
theorem ext {s t : FinitePartialBool} (hdom : s.dom = t.dom) (hones : s.ones = t.ones) :
    s = t := by
  cases s
  cases t
  simp_all

/-- The empty partial function. -/
def empty : FinitePartialBool where
  dom := ∅
  ones := ∅
  ones_subset_dom := by simp

/-- A one-coordinate partial function. -/
def singleton (i : ℕ) (b : Bool) : FinitePartialBool where
  dom := {i}
  ones := if b then {i} else ∅
  ones_subset_dom := by
    by_cases hb : b
    · simp [hb]
    · simp [hb]

/-- Two finite partial functions conflict when they take different values at
a common coordinate. -/
def Conflict (s t : FinitePartialBool) : Prop :=
  ∃ i, i ∈ s.dom ∧ i ∈ t.dom ∧
    ((i ∈ s.ones ∧ i ∉ t.ones) ∨ (i ∉ s.ones ∧ i ∈ t.ones))

theorem conflict_symm {s t : FinitePartialBool} (h : Conflict s t) : Conflict t s := by
  rcases h with ⟨i, his, hit, hdiff⟩
  refine ⟨i, hit, his, ?_⟩
  rcases hdiff with hdiff | hdiff
  · exact Or.inr ⟨hdiff.2, hdiff.1⟩
  · exact Or.inl ⟨hdiff.2, hdiff.1⟩

theorem not_conflict_self (s : FinitePartialBool) : ¬ Conflict s s := by
  rintro ⟨i, -, -, hdiff⟩
  rcases hdiff with ⟨hi, hni⟩ | ⟨hni, hi⟩
  · exact hni hi
  · exact hni hi

/-- The loop-free graph underlying the coordinate coherence space `C_ω`. -/
def coordinateGraph : SimpleGraph FinitePartialBool where
  Adj := Conflict
  symm _ _ := conflict_symm
  loopless := ⟨not_conflict_self⟩

theorem empty_not_adj (s : FinitePartialBool) :
    ¬ coordinateGraph.Adj empty s := by
  rintro ⟨i, hi, -, -⟩
  simpa [empty] using hi

theorem empty_not_adj_rev (s : FinitePartialBool) :
    ¬ coordinateGraph.Adj s empty := by
  intro h
  exact empty_not_adj s h.symm

theorem dom_nonempty_of_ne_empty {s : FinitePartialBool} (hs : s ≠ empty) :
    s.dom.Nonempty := by
  by_contra h
  have hdom : s.dom = ∅ := Finset.not_nonempty_iff_eq_empty.mp h
  have hones : s.ones = ∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro i hi
    have : i ∈ s.dom := s.ones_subset_dom hi
    simpa [hdom] using this
  apply hs
  exact FinitePartialBool.ext (by simp [empty, hdom]) (by simp [empty, hones])

/-- Flip the value of `s` at one coordinate. -/
def oppositeAt (s : FinitePartialBool) (i : ℕ) : FinitePartialBool :=
  singleton i (!(i ∈ s.ones))

theorem conflict_oppositeAt {s : FinitePartialBool} {i : ℕ} (hi : i ∈ s.dom) :
    Conflict s (oppositeAt s i) := by
  classical
  refine ⟨i, hi, ?_, ?_⟩
  · simp [oppositeAt, singleton]
  · by_cases hio : i ∈ s.ones
    · left
      constructor
      · exact hio
      · simp [oppositeAt, singleton, hio]
    · right
      constructor
      · exact hio
      · simp [oppositeAt, singleton, hio]

theorem nonempty_has_neighbor {s : FinitePartialBool} (hs : s ≠ empty) :
    ∃ t, coordinateGraph.Adj s t := by
  obtain ⟨i, hi⟩ := dom_nonempty_of_ne_empty hs
  exact ⟨oppositeAt s i, conflict_oppositeAt hi⟩

theorem isolated_iff_eq_empty (s : FinitePartialBool) :
    (∀ t, ¬ coordinateGraph.Adj s t) ↔ s = empty := by
  constructor
  · intro h
    by_contra hs
    obtain ⟨t, ht⟩ := nonempty_has_neighbor hs
    exact h t ht
  · rintro rfl t
    exact empty_not_adj t

end FinitePartialBool

end Practice.DomainTheory.Papers.CoherenceHomogeneity
