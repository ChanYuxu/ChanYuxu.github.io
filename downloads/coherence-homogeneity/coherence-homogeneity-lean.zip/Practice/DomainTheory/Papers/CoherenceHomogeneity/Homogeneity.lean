import Practice.DomainTheory.Papers.CoherenceHomogeneity.Coordinate
import Practice.DomainTheory.Papers.CoherenceHomogeneity.Rado

/-!
# Universality, ultrahomogeneity, and uniqueness

The finite extension property is connected to mathlib's first-order graph
language.  Mathlib's countable back-and-forth construction then supplies the
global embeddings and automorphisms.
-/

open scoped FirstOrder
open FirstOrder
open FirstOrder.Language

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

universe u v

/-- A finite-extension graph is an extension target for every graph. -/
theorem hasRadoExtensionProperty_isExtensionPair {M : Type u} {N : Type v}
    (G : SimpleGraph M) (H : SimpleGraph N) (hH : HasRadoExtensionProperty H) :
    @Language.IsExtensionPair Language.graph M N G.structure H.structure := by
  classical
  letI : Language.graph.Structure M := G.structure
  letI : Language.graph.Structure N := H.structure
  rw [Language.isExtensionPair_iff_exists_embedding_closure_singleton_sup]
  intro S S_fg f m
  have hSfinite : Finite S := (S.fg_iff_structure_fg.1 S_fg).finite
  letI : Fintype S := Fintype.ofFinite S
  let T : Language.graph.Substructure M := {
    carrier := Set.insert m (S : Set M)
    fun_mem := by
      intro n fn
      exact isEmptyElim fn
  }
  have hT : Substructure.closure Language.graph {m} ⊔ S = T := by
    apply le_antisymm
    · apply sup_le
      · rw [Substructure.closure_le]
        intro x hx
        have hxm : x = m := Set.mem_singleton_iff.mp hx
        subst x
        exact Set.mem_insert m (S : Set M)
      · intro x hx
        exact Set.mem_insert_of_mem m hx
    · intro x hx
      have hx' : x = m ∨ x ∈ S := by
        simpa [T] using hx
      rcases hx' with hxm | hxS
      · have hmcl : m ∈ Substructure.closure Language.graph ({m} : Set M) :=
          Substructure.subset_closure (Set.mem_singleton m)
        have hxcl : x ∈ Substructure.closure Language.graph ({m} : Set M) := by
          simpa [hxm] using hmcl
        exact (le_sup_left : Substructure.closure Language.graph ({m} : Set M) ≤
          Substructure.closure Language.graph {m} ⊔ S)
          hxcl
      · exact (le_sup_right : S ≤ Substructure.closure Language.graph {m} ⊔ S) hxS
  have hUT : Substructure.closure Language.graph {m} ⊔ S ≤ T := le_of_eq hT
  by_cases hmS : m ∈ S
  · have hTS : T ≤ S := by
      intro x hx
      have hx' : x = m ∨ x ∈ S := by
        simpa [T] using hx
      exact hx'.elim (fun h ↦ h.symm ▸ hmS) id
    let gT : T ↪[Language.graph] N :=
      f.comp (Substructure.inclusion hTS)
    let g : ↥(Substructure.closure Language.graph {m} ⊔ S) ↪[Language.graph] N :=
      gT.comp (Substructure.inclusion hUT)
    refine ⟨g, ?_⟩
    ext x
    rfl
  · let A : Finset N :=
      (Finset.univ.filter fun s : S ↦ G.Adj m s.1).image f
    let B : Finset N :=
      (Finset.univ.filter fun s : S ↦ ¬G.Adj m s.1).image f
    have hAB : Disjoint A B := by
      apply Finset.disjoint_left.mpr
      intro y hyA hyB
      rcases Finset.mem_image.mp hyA with ⟨a, ha, rfl⟩
      rcases Finset.mem_image.mp hyB with ⟨b, hb, hfab⟩
      have hab : a = b := f.injective hfab.symm
      subst b
      have haAdj : G.Adj m a.1 := (Finset.mem_filter.mp ha).2
      have hnaAdj : ¬G.Adj m a.1 := (Finset.mem_filter.mp hb).2
      exact hnaAdj haAdj
    obtain ⟨z, hzA, hzB, hzAdj, hzNonadj⟩ := hH A B hAB
    have memA_of_adj (s : S) (hs : G.Adj m s.1) : f s ∈ A := by
      apply Finset.mem_image.mpr
      exact ⟨s, Finset.mem_filter.mpr ⟨Finset.mem_univ s, hs⟩, rfl⟩
    have memB_of_not_adj (s : S) (hs : ¬G.Adj m s.1) : f s ∈ B := by
      apply Finset.mem_image.mpr
      exact ⟨s, Finset.mem_filter.mpr ⟨Finset.mem_univ s, hs⟩, rfl⟩
    have memS_of_ne (x : T) (hx : x.1 ≠ m) : x.1 ∈ S := by
      have hxT := x.2
      change x.1 ∈ Set.insert m (S : Set M) at hxT
      exact (Set.mem_insert_iff.mp hxT).resolve_left hx
    let gFun : T → N := fun x ↦
      if hx : x.1 = m then z else f ⟨x.1, memS_of_ne x hx⟩
    have hz_iff (s : S) : H.Adj z (f s) ↔ G.Adj m s.1 := by
      by_cases hs : G.Adj m s.1
      · exact ⟨fun _ ↦ hs, fun _ ↦ hzAdj (f s) (memA_of_adj s hs)⟩
      · constructor
        · intro hzs
          exact (hzNonadj (f s) (memB_of_not_adj s hs) hzs).elim
        · intro hms
          exact (hs hms).elim
    have gFun_injective : Function.Injective gFun := by
      intro x y hxy
      by_cases hx : x.1 = m
      · by_cases hy : y.1 = m
        · apply Subtype.ext
          exact hx.trans hy.symm
        · let sy : S := ⟨y.1, memS_of_ne y hy⟩
          have heq : z = f sy := by
            simpa [gFun, hx, hy, sy] using hxy
          exfalso
          by_cases hadj : G.Adj m sy.1
          · apply hzA
            simpa [heq] using memA_of_adj sy hadj
          · apply hzB
            simpa [heq] using memB_of_not_adj sy hadj
      · by_cases hy : y.1 = m
        · let sx : S := ⟨x.1, memS_of_ne x hx⟩
          have heq : f sx = z := by
            simpa [gFun, hx, hy, sx] using hxy
          exfalso
          by_cases hadj : G.Adj m sx.1
          · apply hzA
            simpa [← heq] using memA_of_adj sx hadj
          · apply hzB
            simpa [← heq] using memB_of_not_adj sx hadj
        · let sx : S := ⟨x.1, memS_of_ne x hx⟩
          let sy : S := ⟨y.1, memS_of_ne y hy⟩
          have hfxy : f sx = f sy := by
            simpa [gFun, hx, hy, sx, sy] using hxy
          have hsxy : sx = sy := f.injective hfxy
          apply Subtype.ext
          exact congrArg (fun s : S ↦ s.1) hsxy
    let gT : T ↪[Language.graph] N := {
      toFun := gFun
      inj' := gFun_injective
      map_fun' := by
        intro n fn
        exact isEmptyElim fn
      map_rel' := by
        intro n r xs
        cases r
        change H.Adj (gFun (xs 0)) (gFun (xs 1)) ↔
          G.Adj (xs 0).1 (xs 1).1
        by_cases hx : (xs 0).1 = m
        · by_cases hy : (xs 1).1 = m
          · constructor
            · intro hout
              have : H.Adj z z := by simpa [gFun, hx, hy] using hout
              exact (H.loopless.irrefl z this).elim
            · intro hin
              have : G.Adj m m := by simpa [hx, hy] using hin
              exact (G.loopless.irrefl m this).elim
          · let sy : S := ⟨(xs 1).1, memS_of_ne (xs 1) hy⟩
            simpa [gFun, hx, hy, sy] using hz_iff sy
        · by_cases hy : (xs 1).1 = m
          · let sx : S := ⟨(xs 0).1, memS_of_ne (xs 0) hx⟩
            constructor
            · intro hout
              have hzfs : H.Adj z (f sx) := by
                simpa [gFun, hx, hy, sx] using hout.symm
              have hms : G.Adj m sx.1 := (hz_iff sx).mp hzfs
              simpa [hy] using hms.symm
            · intro hin
              have hms : G.Adj m sx.1 := by
                simpa [hy] using hin.symm
              have hzfs : H.Adj z (f sx) := (hz_iff sx).mpr hms
              simpa [gFun, hx, hy, sx] using hzfs.symm
          · let sx : S := ⟨(xs 0).1, memS_of_ne (xs 0) hx⟩
            let sy : S := ⟨(xs 1).1, memS_of_ne (xs 1) hy⟩
            have hf := f.map_rel Language.adj ![sx, sy]
            change H.Adj (f sx) (f sy) ↔ G.Adj sx.1 sy.1 at hf
            simpa [gFun, hx, hy, sx, sy] using hf
    }
    let g : ↥(Substructure.closure Language.graph {m} ⊔ S) ↪[Language.graph] N :=
      gT.comp (Substructure.inclusion hUT)
    refine ⟨g, ?_⟩
    ext x
    have hxne : (x.1 : M) ≠ m := by
      intro hxm
      exact hmS (hxm ▸ x.2)
    change f x = gFun ⟨x.1, _⟩
    simp [gFun, hxne]

/-- Every countably generated graph embeds in a graph with the Rado extension
property. -/
theorem countable_graph_embeds_of_extension {M : Type u} {N : Type v}
    (G : SimpleGraph M) (H : SimpleGraph N) [Countable M]
    (hH : HasRadoExtensionProperty H) :
    Nonempty (@Language.Embedding Language.graph M N G.structure H.structure) := by
  letI : Language.graph.Structure M := G.structure
  letI : Language.graph.Structure N := H.structure
  letI : IsEmpty (Language.graph.Relations 0) := ⟨fun r ↦ nomatch r⟩
  obtain ⟨f, -⟩ := Language.embedding_from_cg Language.Structure.cg_of_countable default
    (hasRadoExtensionProperty_isExtensionPair G H hH)
  exact ⟨f⟩

/-- A countable graph with the Rado extension property is ultrahomogeneous in
the standard first-order sense. -/
theorem ultrahomogeneous_of_extension {M : Type u} (G : SimpleGraph M)
    [Countable M] (hG : HasRadoExtensionProperty G) :
    @Language.IsUltrahomogeneous Language.graph M G.structure := by
  letI : Language.graph.Structure M := G.structure
  exact (Language.isUltrahomogeneous_iff_IsExtensionPair
    Language.Structure.cg_of_countable).2
    (hasRadoExtensionProperty_isExtensionPair G G hG)

/-- Two countable extension graphs are isomorphic by the library's
back-and-forth construction. -/
theorem equiv_of_extension {M : Type u} {N : Type v} (G : SimpleGraph M)
    (H : SimpleGraph N) [Countable M] [Countable N]
    (hG : HasRadoExtensionProperty G) (hH : HasRadoExtensionProperty H) :
    Nonempty (@Language.Equiv Language.graph M N G.structure H.structure) := by
  letI : Language.graph.Structure M := G.structure
  letI : Language.graph.Structure N := H.structure
  letI : IsEmpty (Language.graph.Relations 0) := ⟨fun r ↦ nomatch r⟩
  obtain ⟨e, -⟩ := Language.equiv_between_cg Language.Structure.cg_of_countable
    Language.Structure.cg_of_countable default
    (hasRadoExtensionProperty_isExtensionPair G H hH)
    (hasRadoExtensionProperty_isExtensionPair H G hG)
  exact ⟨e⟩

/-- The explicit arithmetic Rado graph is universal for countable graphs. -/
theorem radoGraph_countablyUniversal {M : Type u} (G : SimpleGraph M) [Countable M] :
    Nonempty (@Language.Embedding Language.graph M ℕ G.structure radoGraph.structure) :=
  countable_graph_embeds_of_extension G radoGraph radoGraph_has_extension_property

/-- The explicit arithmetic Rado graph is ultrahomogeneous. -/
theorem radoGraph_ultrahomogeneous :
    @Language.IsUltrahomogeneous Language.graph ℕ radoGraph.structure :=
  ultrahomogeneous_of_extension radoGraph radoGraph_has_extension_property

/-- Any countable extension graph is isomorphic to the explicit arithmetic
Rado graph. -/
theorem radoGraph_unique {M : Type u} (G : SimpleGraph M) [Countable M]
    (hG : HasRadoExtensionProperty G) :
    Nonempty (@Language.Equiv Language.graph M ℕ G.structure radoGraph.structure) :=
  equiv_of_extension G radoGraph hG radoGraph_has_extension_property

end Practice.DomainTheory.Papers.CoherenceHomogeneity
