# Formalization status

## Result

The graph-theoretic theorem graph and the algebraic retract equations used in
the paper are formalized in Lean 4 without `sorry`, `admit`, or custom axioms.

## Modules

| Module | Content |
|---|---|
| `Basic.lean` | reflexive coherence relation, states, induced-embedding image/preimage, section--retraction and Karoubi equations |
| `Coordinate.lean` | exact finite partial Boolean functions, conflict graph, empty isolated point, every nonempty code has a neighbour |
| `Rado.lean` | arithmetic Rado graph and explicit finite-pattern witness |
| `Homogeneity.lean` | extension-pair bridge, countable embeddings, ultrahomogeneity, back-and-forth uniqueness |
| `NonHomogeneity.lean` | one-point partial isomorphism proving the coordinate graph is not ultrahomogeneous |
| `Universality.lean` | explicit induced embedding of every countable graph into the coordinate graph |
| `Converse.lean` | finite universality plus ultrahomogeneity implies the extension property |
| `Main.lean` | paper-facing theorem facade |
| `AxiomAudit.lean` | `#print axioms` checks for all main declarations |

## Claim boundary

The formalization proves the non-ultrahomogeneity of the specific coordinate
space and checks its comparison with the classical Rado graph, together with
the set-level section--retraction and endomap identities used by the
linear-logic appendix.  It uses mathlib's first-order graph language and its
proved countable back-and-forth theorem for the passage from finite extension
steps to automorphisms and isomorphisms.  The arithmetic Rado construction and
its universal homogeneous properties are prior mathematics, not novelty claims
of this development.

The formalization does not claim to rebuild the complete categorical model of
all propositional linear-logic rules.  Appendix A's linear-trace category,
additives, exponential structure, proof interpretation, and soundness theorem
are mathematical exposition.  Appendix C's Cantor-cylinder and
ideal-completion descriptions are likewise outside the Lean boundary.  These
appendices explain the semantic application and the coordinate state domain;
the Lean development remains unchanged.

## Verification commands

```text
lake build Practice.DomainTheory.Papers.CoherenceHomogeneity
lake build Practice.DomainTheory.Papers.CoherenceHomogeneity.AxiomAudit
```

The exact toolchain is `leanprover/lean4:v4.30.0-rc2` with the repository's
pinned mathlib dependency.
