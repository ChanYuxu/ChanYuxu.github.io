import Practice.DomainTheory.Papers.CoherenceHomogeneity.Converse

/-!
# Main results

This facade collects the formal statements corresponding to the paper's main
comparison and its retract appendix.
-/

open scoped FirstOrder
open FirstOrder

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

/-- The old finite-partial-function carrier is universal for countable
coherence graphs but is not ultrahomogeneous. -/
theorem coordinate_main_result :
    (∀ {V : Type} (G : SimpleGraph V) [Countable V],
      Nonempty (G ↪g FinitePartialBool.coordinateGraph)) ∧
    ¬(@FirstOrder.Language.IsUltrahomogeneous FirstOrder.Language.graph
      FinitePartialBool FinitePartialBool.coordinateGraph.structure) := by
  constructor
  · intro V G inst
    exact coordinateGraph_countablyUniversal G
  · exact coordinateGraph_not_ultrahomogeneous

/-- The arithmetic Rado carrier has the extension property, is universal for
countable coherence graphs, and is ultrahomogeneous. -/
theorem rado_main_result :
    HasRadoExtensionProperty radoGraph ∧
    (∀ {V : Type} (G : SimpleGraph V) [Countable V],
      Nonempty (@FirstOrder.Language.Embedding FirstOrder.Language.graph V ℕ
        G.structure radoGraph.structure)) ∧
    @FirstOrder.Language.IsUltrahomogeneous FirstOrder.Language.graph ℕ
      radoGraph.structure := by
  exact ⟨radoGraph_has_extension_property,
    fun G inst ↦ radoGraph_countablyUniversal G,
    radoGraph_ultrahomogeneous⟩

/-- The standard uniqueness form: finite universality and ultrahomogeneity
determine a unique countable isomorphism type. -/
theorem homogeneous_universal_unique
    {M N : Type} (G : SimpleGraph M) (H : SimpleGraph N)
    [Countable M] [Countable N]
    (hGu : FinitelyUniversal G)
    (hGh : @FirstOrder.Language.IsUltrahomogeneous FirstOrder.Language.graph M
      G.structure)
    (hHu : FinitelyUniversal H)
    (hHh : @FirstOrder.Language.IsUltrahomogeneous FirstOrder.Language.graph N
      H.structure) :
    Nonempty (@FirstOrder.Language.Equiv FirstOrder.Language.graph M N
      G.structure H.structure) :=
  equiv_of_finitelyUniversal_ultrahomogeneous G H hGu hGh hHu hHh

end Practice.DomainTheory.Papers.CoherenceHomogeneity
