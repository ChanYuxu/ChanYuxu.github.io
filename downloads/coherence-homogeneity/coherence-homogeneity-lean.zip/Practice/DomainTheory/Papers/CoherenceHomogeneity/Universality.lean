import Practice.DomainTheory.Papers.CoherenceHomogeneity.NonHomogeneity

/-!
# Countable universality of the coordinate graph

Each vertex is assigned its own `true` coordinate and a `false` coordinate for
each earlier adjacent vertex.  Conflict of the resulting partial functions is
therefore exactly adjacency in the source graph.
-/

namespace Practice.DomainTheory.Papers.CoherenceHomogeneity

open FinitePartialBool

universe u

/-- A canonical partial function with one distinguished `true` coordinate and
a finite set of `false` coordinates. -/
def coordinateCode (head : ℕ) (zeros : Finset ℕ) : FinitePartialBool where
  dom := insert head zeros
  ones := {head}
  ones_subset_dom := by
    intro i hi
    exact Finset.mem_insert.mpr (Or.inl (Finset.mem_singleton.mp hi))

theorem coordinateCode_conflict_iff_of_lt {a b : ℕ} {A B : Finset ℕ}
    (hA : ∀ i ∈ A, i < a) (hab : a < b) :
    Conflict (coordinateCode a A) (coordinateCode b B) ↔ a ∈ B := by
  constructor
  · rintro ⟨i, hiA, hiB, hdiff⟩
    rcases hdiff with hdiff | hdiff
    · have hia : i = a := Finset.mem_singleton.mp hdiff.1
      subst i
      rcases Finset.mem_insert.mp hiB with hab' | haB
      · exact (hab.ne hab').elim
      · exact haB
    · have hib : i = b := Finset.mem_singleton.mp hdiff.2
      subst i
      rcases Finset.mem_insert.mp hiA with hba | hbA
      · exact (hab.ne hba.symm).elim
      · exact False.elim ((Nat.not_lt_of_ge hab.le) (hA b hbA))
  · intro haB
    refine ⟨a, ?_, ?_, ?_⟩
    · exact Finset.mem_insert_self a A
    · exact Finset.mem_insert.mpr (Or.inr haB)
    · left
      constructor
      · exact Finset.mem_singleton_self a
      · change a ∉ ({b} : Finset ℕ)
        simpa only [Finset.mem_singleton] using hab.ne

/-- Earlier coordinates at which the code for `x` takes value `false`. -/
noncomputable def graphZeros {V : Type u} (G : SimpleGraph V) (c : V ↪ ℕ)
    (x : V) : Finset ℕ := by
  classical
  exact (Finset.range (c x)).filter fun n ↦ ∃ y, c y = n ∧ G.Adj y x

theorem graphZeros_lt {V : Type u} (G : SimpleGraph V) (c : V ↪ ℕ)
    (x : V) {n : ℕ} (hn : n ∈ graphZeros G c x) : n < c x := by
  classical
  rw [graphZeros] at hn
  exact Finset.mem_range.mp (Finset.mem_filter.mp hn).1

/-- The finite-coordinate code assigned to a vertex. -/
noncomputable def graphCode {V : Type u} (G : SimpleGraph V) (c : V ↪ ℕ)
    (x : V) : FinitePartialBool :=
  coordinateCode (c x) (graphZeros G c x)

theorem graphCode_injective {V : Type u} (G : SimpleGraph V) (c : V ↪ ℕ) :
    Function.Injective (graphCode G c) := by
  intro x y hxy
  have hones := congrArg FinitePartialBool.ones hxy
  change ({c x} : Finset ℕ) = {c y} at hones
  exact c.injective (Finset.singleton_inj.mp hones)

theorem graphCode_conflict_iff {V : Type u} (G : SimpleGraph V) (c : V ↪ ℕ)
    (x y : V) :
    Conflict (graphCode G c x) (graphCode G c y) ↔ G.Adj x y := by
  classical
  by_cases hxy : x = y
  · subst y
    exact ⟨fun h ↦ (not_conflict_self _ h).elim,
      fun h ↦ (G.loopless.irrefl x h).elim⟩
  have hcne : c x ≠ c y := fun h ↦ hxy (c.injective h)
  rcases lt_or_gt_of_ne hcne with hlt | hgt
  · rw [graphCode, graphCode,
      coordinateCode_conflict_iff_of_lt
        (fun i hi ↦ graphZeros_lt G c x hi) hlt]
    constructor
    · intro hx
      rw [graphZeros] at hx
      rcases Finset.mem_filter.mp hx with ⟨-, u, hu, huy⟩
      have hux : u = x := c.injective hu
      simpa [hux] using huy
    · intro hxyAdj
      rw [graphZeros]
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_range.mpr hlt, x, rfl, hxyAdj⟩
  · constructor
    · intro hconf
      have hrev : Conflict (graphCode G c y) (graphCode G c x) := conflict_symm hconf
      change Conflict (coordinateCode (c y) (graphZeros G c y))
        (coordinateCode (c x) (graphZeros G c x)) at hrev
      have hymem : c y ∈ graphZeros G c x :=
        (coordinateCode_conflict_iff_of_lt
          (fun i hi ↦ graphZeros_lt G c y hi) hgt).mp hrev
      rw [graphZeros] at hymem
      rcases Finset.mem_filter.mp hymem with ⟨-, u, hu, hux⟩
      have huy : u = y := c.injective hu
      simpa [huy] using hux.symm
    · intro hAdj
      apply conflict_symm
      change Conflict (coordinateCode (c y) (graphZeros G c y))
        (coordinateCode (c x) (graphZeros G c x))
      apply (coordinateCode_conflict_iff_of_lt
        (fun i hi ↦ graphZeros_lt G c y hi) hgt).mpr
      rw [graphZeros]
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_range.mpr hgt, y, rfl, hAdj.symm⟩

/-- The explicit induced embedding into the finite-partial-function graph. -/
noncomputable def coordinateEmbedding {V : Type u} (G : SimpleGraph V) (c : V ↪ ℕ) :
    G ↪g coordinateGraph where
  toFun := graphCode G c
  inj' := graphCode_injective G c
  map_rel_iff' := graphCode_conflict_iff G c _ _

/-- Every countable graph induced-embeds into the coordinate graph. -/
noncomputable def countableCoordinateEmbedding {V : Type u} (G : SimpleGraph V)
    [Countable V] : G ↪g coordinateGraph :=
  letI : Encodable V := Encodable.ofCountable V
  coordinateEmbedding G (Encodable.encode' V)

theorem coordinateGraph_countablyUniversal {V : Type u} (G : SimpleGraph V)
    [Countable V] : Nonempty (G ↪g coordinateGraph) :=
  ⟨countableCoordinateEmbedding G⟩

end Practice.DomainTheory.Papers.CoherenceHomogeneity
