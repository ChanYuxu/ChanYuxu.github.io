# RB function-space characterization in Lean 4

This archive is an extract from the Domain Theory Lean 4 project. It accompanies the manuscript **A function space characterization of RB-domains** by Yuxu Chen.

## Formalized scope

The archive contains the public aggregate import and eight component modules (9 Lean files, 1,857 lines). The formalization follows the manuscript through `thm:rb-characterization`:

- an RB-domain `X` has a continuous function space `[X → E]` for every domain `E`;
- conversely, continuity of all such function spaces implies that `X` is an RB-domain;
- the constructed algebraic domain `A_X` is a single test target: continuity of `[X → A_X]` implies that `X` is an RB-domain.

The later countably based uniform-test theorem and the manuscript's FS-domain section are intentionally outside this archive's formalized source boundary.

Aligned LaTeX source SHA-256:

```text
05f491994ac8fd569ac3dbfc565db9ebd30c0cac4c686aa7429284dd5e4c2e54
```

## Toolchain and build

- Lean: `v4.30.0-rc2`
- Mathlib: `v4.30.0-rc2`

This is not a standalone Lean package. Place the files at the paths shown here inside the full `DomainTheory_Lean4_texbook` checkout, then run:

```sh
lake build Practice.DomainTheory.Papers.RBFunctionSpaceCharacterization
```

The focused build passed when this archive was prepared.

## Verification and trust boundary

The archived Lean files contain no `sorry`, `admit`, `opaque`, or `unsafe`. They declare exactly two project-local external axioms:

1. `RBFunctionSpace.rb_functionSpace_continuous`, the published forward implication that an RB source has continuous function space into every domain target.
2. `RBFunctionSpace.continuous_functionSpace_compact_or_pointedComponents`, the function-space compactness/pointed-components dichotomy used from Abramsky--Jung, Lemma 4.3.6.

Consequently, the final characterization is checked relative to these two cited mathematical inputs; it is not reported as a zero-external-axiom theorem. The internally proved constructions, including `finiteCoverExtraction` and `AX.functionSpaceRetract`, use only Lean/Mathlib's standard logical dependencies (`propext`, `Classical.choice`, and `Quot.sound`) in the current axiom audit.

The source archive preserves the module layout so these dependencies and the extraction argument can be inspected directly.
