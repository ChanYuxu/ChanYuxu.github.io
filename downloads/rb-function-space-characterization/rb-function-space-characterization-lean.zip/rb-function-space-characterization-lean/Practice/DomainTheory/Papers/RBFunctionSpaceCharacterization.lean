import Practice.DomainTheory.Papers.RBFunctionSpace.Characterization

/-!
# RB function-space characterization

Public aggregate import for the RB-only formalization of
`Function_space_characterizations_RB_FS_intro_narrative.tex`.

The formalized source boundary ends with `thm:rb-characterization`.
The later countably based uniform test and the FS-domain section are
intentionally excluded.
-/
