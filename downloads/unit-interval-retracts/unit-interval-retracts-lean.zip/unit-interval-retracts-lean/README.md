# Unit-interval retracts: Lean 4 source bundle

This bundle contains the Lean 4 sources used for the formalization case study
“Unit-interval retracts of quasicontinuous domains: a counterexample.”  The
formal development constructs a concrete complete lattice `P` and verifies the
properties collected in `UnitIntervalRetracts.mainCounterexample`.

## Contents

- `Practice/DomainTheory/Papers/UnitIntervalRetracts.lean` is the public
  aggregate import.
- `Practice/DomainTheory/Papers/UnitIntervalRetracts/*.lean` contains the 16
  component modules (3,809 lines in total together with the aggregate import).

## Required project and versions

These files are an extract from `DomainTheory_Lean4_texbook`, not a standalone
Lean project. They import shared domain-theory modules from that repository and
should retain the included paths inside a complete project checkout.

- Lean: `v4.30.0-rc2`
- Mathlib: `v4.30.0-rc2`

From the root of `DomainTheory_Lean4_texbook`, build with:

```console
lake build Practice.DomainTheory.Papers.UnitIntervalRetracts
```

## Verification record

Checked on 2026-08-01:

- the focused Lake build completed successfully;
- no occurrence of `sorry`, `admit`, a local `axiom`, `opaque`, or `unsafe`
  appears in this bundle; and
- `#print axioms` for `mainCounterexample`, `negativeAnswers`, and
  `finiteGridChoices_give_scottContinuous_section` reports only `propext`,
  `Classical.choice`, and `Quot.sound`.

The source manuscript used for alignment has SHA-256:

```text
00c59c1953e50628793d3f7a789187aa3051405999b4d72ddfbd29af41c00b04
```

The bundle formalizes the mathematical declarations; it is not a formalization
of the manuscript's prose, bibliography, or publication formatting.
