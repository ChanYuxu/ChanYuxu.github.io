import Practice.DomainTheory.Papers.UnitIntervalRetracts.Main
import Practice.DomainTheory.Papers.UnitIntervalRetracts.FiniteGrid

/-!
# Sparse unit-interval retract counterexample

Public aggregate import for the Lean formalization of
`unit_interval_retracts_quasicontinuous_domains_style_matched_副本.tex`.
-/
