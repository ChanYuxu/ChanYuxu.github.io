# Lipschitz Yoneda final topology: Lean 4 source bundle

This archive is the source extract accompanying the mechanization of
`lipschitz_yoneda_final_topology_paper_fifth_audit.tex`.  The manuscript
itself is not included in the Lean archive.

The headline theorem is an actual Lean declaration:

```lean
theorem QuasiMetric.IsContinuous.propertyD
    (hcontinuous : d.IsContinuous)
    (hcomplete : d.IsYonedaComplete) :
    d.PropertyD
```

The proof contains no `sorry`, `admit`, project-specific `axiom`, `opaque`,
or `unsafe` declaration.  Its `#print axioms` output contains only the
standard Lean/Mathlib principles `propext`, `Classical.choice`, and
`Quot.sound`.

From the root of the surrounding `DomainTheory_Lean4_texbook` repository,
run:

```sh
lake build Practice.DomainTheory.Papers.LipschitzYonedaFinalTopology
lake env lean Practice/DomainTheory/Papers/LipschitzYonedaFinalTopology/AxiomAudit.lean
```

This is a source extract, not a standalone Lake package; it uses Mathlib and
the surrounding repository.  Read `FORMALIZATION_STATUS.md` for the source
hash, theorem-by-theorem ledger, remaining manuscript boundary, and exact
verification commands.
