# PointCentralFubini — 本次稿件的 Lean 4 形式化

原稿：*Point-Continuous and Central Valuations: Countable Spaces and the Sorgenfrey–Smyth dcpo*。
范围为正文第 2、3、4、5 节；附录不形式化。审核绑定到私有原稿快照，论文 TeX 源码不随公开包提供。
本项目与旧的 `CountableDcpoFubini_Lean` 独立，只依赖固定版本 mathlib。

公开下载包只包含可构建的 Lean 源码、固定工具链、形式化状态和审计元数据；
不包含论文的 TeX 源文件、PDF、`.git`、`.lake` 或本机缓存。

**当前状态：正文请求范围全部具有 Lean 实现，证明相对于登记的文献公理成立。**
可数 dcpo、Scott 拓扑第二可数 dcpo 和 Sorgenfrey–Smyth dcpo 的 Fubini 结论均已证明。
正文 23 个带编号的数学条目中，19 项为定理证明、3 项为原文明确引用的文献公理、1 项为定义。
第四节的 4.2 测度关联恒等式、4.4 full Vietoris 提升和 4.7 主定理已闭合；
主定理不再以未证明的本稿命题为参数。没有 `sorry`、`admit`，也没有本稿内部命题公理。

目前保留 10 项明确登记的文献公理，**未在本项目内重证，因此不是完全自足的形式化**。
其中包括 4.4 原文引用的 AJK Theorem 27；紧化、像外零测度、迹测度传输及 Radon 测度的 τ 光滑性均在本项目证明。
反包含紧集形成 dcpo 的断言也已在本项目证明。
其中 JLMZ 导入的只是开集、次概率版本；归一化和推广到任意质量、任意非负积分函数的步骤已在 Lean 中证明。
详细清单见 `external-sources.json`，逐项状态见 `FORMALIZATION_STATUS.md`。

## 主要入口

| 内容 | 声明/文件 |
|---|---|
| 可数空间上的点连续性 | `Countable.lean` 中 `countable_valuation_pointContinuous` |
| 原文的可数共初开集推广 | `CountableDcpo.lean`、`Central.lean` 中 `coinitial_classes` |
| 可数 dcpo 的 Fubini 结论 | `Central.lean` 中 `countable_fubini` |
| 关联恒等式与下降 | `Incidence.lean` 中 `central_iff_incidence`、`fubini_descent` |
| 第二可数 Scott 空间的 Fubini 结论 | `SecondCountable.lean` 中 `second_countable_fubini` |
| 归一化、有限/次概率测试 | `Normalization.lean` |
| Scott–Fatou 引理 | `Fatou.lean` 中 `scott_fatou` |
| 测度关联积分恒等式 | `MeasureSource.lean` 中 `measure_source_incidence` |
| 不可测子集的 full-outer 迹测度 | `OuterTrace.lean` 中 `full_outer_trace` |
| full Vietoris 测度提升 | `VietorisLift.lean` 中 `full_vietoris_lift` |
| 极值观测与完整 Vietoris 拓扑 | `ExtremalObservations.lean` 中 `extremal_observables` |
| 可数内逼近族 | `InnerSkeleton.lean` 中 `sorgenfrey_inner_skeleton` |
| Borel 限制、支撑及关联评价 LSC | `MeasureIncidence.lean` |
| 反包含紧集的 dcpo 构造 | `SmythDcpo.lean` |
| 第四节的具体空间及命题类型 | `SourceStatements.lean` |
| Sorgenfrey–Smyth dcpo 的 Fubini 结论 | `SorgenfreyFubini.lean` 中 `sorgenfrey_fubini` |
| 保留兼容的条件组装接口 | `Sorgenfrey.lean` |

以上 Lean 文件均位于 `PointCentralFubini/`。统一导入：

```lean
import PointCentralFubini
```

## 构建和公开审计

```sh
lake exe cache get
lake build
lake env lean PointCentralFubini/AxiomAudit.lean
```

`source-map.json` 保留原文标签、编号、哈希、对应声明及证明状态；
`audit/verification.json` 是在绑定的原稿快照和实际 Lean 环境中生成的机器可读审计记录。
为避免公开论文 TeX 源码，本下载包不包含原稿快照及依赖它的内部审计脚本，
因此可以独立重建 Lean 项目并检查公理边界，但不能仅凭此公开包重新生成完整的原稿忠实性审计。
`FORMALIZATION_STATUS.md`、`external-sources.json` 和 `review.json` 记录了证明范围、文献公理和待复核状态。

工具链：Lean/mathlib `v4.30.0-rc2`。首次在新机器构建时运行 `lake update`、`lake exe cache get`，再构建。
当前 `.lake/packages` 复用本机同版本缓存；该目录不跟踪，也不改变源代码依赖。
独立复核和人工批准均仍待进行。
